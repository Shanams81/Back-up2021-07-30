<?php
	session_start();
	include_once("../conn/pri_sch_connect.inc");
	if(isset($_POST['CmdSave'])){
	 	$reqno=isset($_POST['TxtReqNo'])?trim(strip_tags($_POST['TxtReqNo'])):0;
	 	$date=date('Y-m-d'); $yr=date('Y');	$addb=$_SESSION['username']." (".$_SESSION['priviledge'].")";
	 	$rmks=isset($_POST['TxtRmks'])?strtoupper(trim(strip_tags($_POST['TxtRmks']))):0;
	 	if (strlen($rmks)<10){
			print "SERVER ERROR <font color=\"#cc0000\">Ensure the reason for cancelling request is validly entered before saving</font><br>";
		}else{
			$amt=preg_replace("/[^0-9^\.]/","",$amt);	$amtper=preg_replace("/[^0-9^\.]/","",$amtper);
			if ($amtper<($amt/$per)) $amtper=ceil(($amt/$per));
			mysqli_query($conn,"INSERT INTO acc_advrej VALUES (null,'$reqno','$date','$yr','$rmks','$addb',0)") or die(mysqli_error($conn)." Sorry, salary advance request 
			was not rejected successfully. Click <a href=\"saladvreq.php\">Here</a> to go back.");
			$i=mysqli_affected_rows($conn);
			if ($i==1) mysqli_query($conn,"UPDATE acc_advreq SET adv_status=2 WHERE reqno LIKE '$reqno'") or die(mysqli_error($conn)." Sorry, salary advance request 
			failed to update successfully. Click <a href=\"saladvreq.php\">Here</a> to go back.");
			header("location:saladvreq.php?action=1-$i");
		}
		exit();		
	}
	$adno=$_REQUEST['advno'];
	$rsAdv=mysqli_query($conn,"SELECT r.reqno,r.reqdate,r.amt,concat(r.ded_period,' Month(s)') as per, r.amtperded,sd.idno,sd.payrollno FROM acc_advreq r Inner Join 
	acc_saldef sd USING (payrollno) WHERE r.reqno LIKE '$adno'");
	list($reqno,$reqdate,$amt,$per,$amtper,$idn,$payno)=mysqli_fetch_row($rsAdv); mysqli_free_result($rsAdv);
	$rsStf=mysqli_query($conn,"SELECT concat(s.surname,' ',s.onames,' (',s.designation,')') as nam FROM stf s  WHERE s.idno LIKE '$idn'");
	list($nam)=mysqli_fetch_row($rsStf); mysqli_free_result($rsStf);	
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Salary Advance Manager</title>
	<script type="text/javascript" src="../self/tpl/saladvreq.js"></script>
</head>
<body background="img/bg3.gif" onload="document.frmAdvReq.TxtRmks.focus();">
	<?php 
		print "<br><br><form name=\"frmAdvReq\" method=\"Post\" action=\"advreqdeny.php\" onsubmit=\"return validateFormOnSubmit(this)\"><table align=\"center\" 
		cellspacing=\"0\" cellpadding=\"2\" border=\"1\"><tr><td><input type=\"hidden\" name=\"TxtReqNo\" value=\"$reqno\"><table align=\"center\" cellspacing=\"3\" 
		cellpadding=\"5\" border=\"0\" style=\"font-size:11pt;font-color:#0000dd\"><tr><td bgcolor=\"#ff00cc\">Rejection/ denying salary advance request <b>$reqno
		</b></td></tr>";
		print "<tr><td>This is to reject/ deny salary advance request made by ".ucwords(strtolower($nam)).", <br>of ID No. <b>$idn</b> and Payroll No. <b>$payno</b>
		</td></tr>";
		print "<tr><td>The advance request was for the sum of Kshs. ".number_format($amt,2)." and made on ".date('l j, F Y',strtotime($reqdate))."</td></tr>
		<tr><td>to be recovered in $per at a rate of Kshs.".number_format($amtper,2)." a month from his/ her salary.</td></tr>";
		print "<tr><td valign=\"top\">Reason given for rejecting <textarea name=\"TxtRmks\" id=\"TxtRmks\" cols=\"78\" rows=\"3\" maxlength=\"250\"></textarea></td>
		</tr><tr bgcolor=\"#ff00cc\"><td align=\"center\"><button name=\"CmdSave\" type=\"submit\">Reject Request</button> &nbsp;&nbsp;&nbsp;&nbsp;<a 
		href=\"saladvreq.php\"><button type=\"button\" name=\"CmdClose\">Close</button></a></td></tr></table>";
		print "</td></tr></table>";
		mysqli_close($conn);
	?></h2>
</body>
</html>