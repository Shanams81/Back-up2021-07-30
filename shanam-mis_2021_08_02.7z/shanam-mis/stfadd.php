<?php
	include_once('shanam.php');
	if ($_SERVER["REQUEST_METHOD"]==="POST"){
		$idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):Null;  		$dob=$_POST['cboYr']."-".$_POST['cboMon']."-".$_POST['cboDays'];
		$surname=isset($_POST['txtSurname'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtSurname']))):'';
		$onames=isset($_POST['txtONames'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtONames']))):'';
		$gender=isset($_POST['cboGender'])?strtoupper(sanitize($_POST['cboGender'])):'FEMALE';	$address=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):Null;
		$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):Null; 	$const=isset($_POST['cboConst'])?sanitize($_POST['cboConst']):0;
		$county=isset($_POST['cboCounty'])?sanitize($_POST['cboCounty']):0;		$ward=isset($_POST['cboWard'])?sanitize($_POST['cboWard']):0;
		$email=isset($_POST['txtEMail'])?sanitize($_POST['txtEMail']):Null;		$desig=isset($_POST['cboDesignation'])?strtoupper(sanitize($_POST['cboDesignation'])):'TEACHER';
		$stfgrp=isset($_POST['cboStfGrp'])?strtoupper(sanitize($_POST['cboStfGrp'])):'TEACHING STAFF';	$terms=isset($_POST['cboTerms'])?strtoupper(sanitize($_POST['cboTerms'])):'PERMANENT';
		$status=isset($_POST['chkStatus'])?sanitize($_POST['chkStatus']):0;		$subloc=isset($_POST['txtSubLocation'])?strtoupper(sanitize($_POST['txtSubLocation'])):'';
		$village=isset($_POST['txtVillage'])?strtoupper(sanitize($_POST['txtVillage'])):'';
		$employer=isset($_POST['cboEmployer'])?strtoupper(sanitize($_POST['cboEmployer'])):'BoG';	$un=$_SESSION['username']." (".$_SESSION['priviledge'].")"; $regdon=date("Y-m-d H:n:s");
		$illness=isset($_POST['txtIllness'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtIllness']))):null;
		$allergy=isset($_POST['txtAllergy'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAllergy']))):null;
		$pwdrmks=isset($_POST['txtPWDRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPWDRmks']))):null;
		$kra=isset($_POST['txtKRA'])?strtoupper(sanitize($_POST['txtKRA'])):null;	$pwd=isset($_POST['chkPWD'])?sanitize($_POST['chkPWD']):0;
		if (strlen($surname)<3||strlen($onames)<5||strlen($idno)<6||strlen($subloc)<4||strlen($village)<4||strlen($county)<3||strlen($const)<3||strlen($ward)<2){
			print "DATA ERROR: <font color=\"#cc0000\">Ensure member of staff's details  are validly entered before saving</font>.<br>Click <a href=\"stfadd.php\">
			HERE</a> to try again.";	exit(0);
		}else{
			if (mysqli_query($conn,"INSERT INTO stf (IdNo,SurName,ONames,Address,Telno,Employer,Designation,Gender,StaffGrp,DOB,PIN,AddedBy,email,RegdOn,countyNo,ConstituencyNo,
			wardno,sublocation,village,pwd,pwdrmks,st_type,present,illness,allergy) VALUES ('$idno',".var_export($surname,true).",".var_export($onames,true).",".var_export($address,true).",".
			var_export($telno,true).",'$employer','$desig','$gender','$stfgrp','$dob',".var_export($kra,true).",'$un',".var_export($email,true).",curdate(),'$empon[2]-$empon[1]-$empon[0]',
			'$jg','$county','$const','$ward',".var_export($subloc,true).",".var_export($village,true).",$pwd,".var_export($pwdrmks,true).",'$terms',1,".var_export($illness,true).",
			".var_export($allergy,true).")") or die(mysqli_error($conn)." Staff record not saved. Click <a href=\"stf.php\">Here</a> to go back.")){
				header("location:stf.php?action=1-1");
			}else {
				print "SERVER ERROR: Member of staff's details are already the system or ID No. is already registered.</font>.<br>Click <a href=\"stfadd.php\">HERE</a> to try again.";
				exit(0);
			}
		}
	}else{
		mysqli_multi_query($conn,"SELECT county,constituency,ward FROM ss; SELECT staff FROM grps WHERE staff is not null ORDER BY staff ASC; SELECT code,name FROM county ORDER BY name ASC;
		SELECT code,name,codecounty FROM constituency ORDER BY codecounty,name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC; SELECT code,name,codeconst FROM ward
		ORDER BY codeconst,name ASC;"); 	$optCounty=$optGrp=$optMP=$optMCA='';	$i=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0) $code=mysqli_fetch_row($rs);
				elseif($i==1) while($r=mysqli_fetch_row($rs)) $optGrp.="<option>$r[0]</option>";
				elseif($i==2) while (list($s,$n)=mysqli_fetch_row($rs)) $optCounty.="<option ".($code[0]==$s?"selected":"")." value=\"$s\">$n</option>";
				elseif($i==3){ $mp=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
					$mp.=($a==0?"":",")."new Consti(\"$s\",\"$n\",\"$c\")"; if($code[0]==$c) $optMP.="<option ".($code[1]==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;
				}}else{ $mca=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
	   				$mca.=($a==0?"":",")."new MCA(\"$s\",\"$n\",\"$c\")"; if($c==$code[1]) $optMCA.="<option ".($code[2]==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;
	  			}} 	mysqli_free_result($rs);
			} $i++;
		}while(mysqli_next_result($conn));
	}
	headings('<link rel="stylesheet" type="text/css" href="../date/tcal.css" />',0,0,1);
?><BR>
<div class="w-50 p-3" style="background-color:#eee;margin:auto;border-radius:10px;padding:0px;width:fit-content;"><form name="frmStf" id="frmStf" method="post" action="stfadd.php"
onsubmit="return validateFormOnSubmit(this);">
<!-- Circles which indicates the steps of the form: -->
<div style="margin-top:2px;margin-bottom:2px;color:#aaf;font-size:10px;" class="form-row">
	<div class="col-md-6 mb-3" style="text-align:left;">Step <span id="spStep0" class="step active" style="color:#fff;font-weight:bold;text-align:center;">1</span></div>
	<div class="col-md-6 mb-3" style="text-align:right;">Step <span id="spStep1" class="step" style="color:#fff;font-weight:bold;text-align:center;">2</span></div>
</div>
<!-- One "tab" for each step in the form: -->
<div class="tab">
<H1>PERSONAL DETAILS FOR MEMBER OF STAFF</H1>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="txtIDNo">ID/Passport No. *</label>
      <input type="text" id="txtIDNo" placeholder="000000" value="" required name="txtIDNo" maxlength="10" onkeyup="checkData(0,this)">
    </div><div class="col-md-3 mb-3">
      <label for="cboGender">Gender *</label>
	    <select id="cboGender" name="cboGender">
	      <option value="Male" selected>Male</option>
	      <option value="Female">Female</option>
	    </select>
    </div><div class="col-md-6 mb-3">
      <label for="cboYr">Date of Birth *</label>
      <div class="input-group">
        <SELECT name="cboYr" size="1" id="cboYr" onchange="filldays('CboDays')" style="width:20%;">
		<?php $a=(date('Y')-18); for($i=$a; $i>($a-60);$i--) print "<option>$i</option>"; ?>
		</SELECT>-<SELECT name="cboMon" size="1" id="cboMon" onchange="filldays('cboDays')" style="width:45%;"><OPTION value="01">January</OPTION><OPTION value="02">February</OPTION><OPTION
		value="03">March</OPTION><OPTION value="04">April</OPTION><OPTION value="05">May</OPTION><OPTION value="06">June</OPTION><OPTION value="07">July</OPTION><OPTION value="08">August
		</OPTION><OPTION value="09">September</OPTION><OPTION value="10">October</OPTION><OPTION value="11">November</OPTION><OPTION value="12">December</OPTION></SELECT>-<SELECT
		name="cboDays" style="width:20%;" size="1" id="cboDays">
		<?php $a=date('t',strtotime($a.'-01-01')); $b=date("d"); for($i=$a;$i>0;$i--) print "<option ".(($b==$i)?"selected":"").">$i</option>";?></SELECT>
      </div>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="txtSurname">Surname *</label>
      <input type="text" id="txtSurname" name="txtSurname" placeholder="Nama" required maxlength="12"  onkeyup="checkData(1,this)">
    </div><div class="col-md-9 mb-3">
      <label for="txtONames">Other Names *</label>
      <input type="text" name="txtONames" id="txtONames" placeholder="M. Shab" required maxlength="30" onkeyup="checkData(1,this)">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="cboDesignation">Staff Designation *</label>
      <SELECT name="cboDesignation" id="cboDesignation" size="1" required><option>Accounts Clerk</Option><option>Boarding Master</Option><option>Boarding Mistress</Option>
	  <option>Bursar</Option><option>Cateress</Option><option>Caterer</Option><option>Cook</Option><option>Copy Typist</Option><option>Data Clerk</Option><option>Deputy Principal</Option>
	  <option>Director</Option><option>Driver</Option><option>Farm Attendant</Option><option>Groundsman</Option><option>H . O . D</Option><option>Kitchen Assistant</Option><option>Lab
	  Assistant</Option><option>Lab Technician</Option><option>Librarian</Option><option>Matron</Option><option>Messenger</Option><option>Nurse</Option><option>Principal</Option><option>
	  Secretary</Option><option>Store Keeper</Option><option>Teacher</Option><option>Watchman</Option></SELECT>
    </div><div class="col-md-5 mb-3">
      <label for="cboStfGrp">Staff Group *</label>
      <SELECT name="cboStfGrp" id="cboStfGrp" size="1" required>
		<?php echo $optGrp; ?></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboJG">Job Group *</label>
      <SELECT name="cboJG" id="cboJG" size="1" required><option>D</option><option>E</option><option>F</option><option>G</option><option>H</option><option selected>J</option><option>
	  K</option><option>L</option><option>M</option><option>N</option><option>P</option><option>Q</option><option>R</option><option>S</option><option>T</option></Select>
    </div>
  </div>
  <div class="form-row">
  	<div class="col-md-3 mb-3" style="text-align:left;">
		<label for="chkPWD" style="font-size:10px;">Person With Disability?</label>
      	<INPUT type="checkbox" id="chkPWD" name="chkPWD" value="1" onclick="enablePWD(this)" title="Yes">
	</div><div class="col-md-9 mb-3">
      <label for="txtPWD">Form of Disability </label>
      <INPUT type="text" name="txtPWD" id="txtPWD" readonly value="" placeholder="Person with Visual Impairment" maxlength="100" onkeyup="checkData(1,this)">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="txtEmpOn">KRA PIN NO.</label>
      <INPUT type="text" name="txtKRA" name="txtKRA" maxlength="14" value="" placeholder="A00000000Z" onkeyup="checkData(1,this)">
    </div><div class="col-md-3 mb-3">
      <label for="txtEmpOn">Employed On</label>
      <INPUT type="text" name="txtEmpOn" name="txtEmpOn" class="tcal" readonly <?php print "value=\"".date("d-m-Y")."\""; ?> >
    </div><div class="col-md-4 mb-3">
	  <label for="chkStatus">Present at Work ? *</label>
      <INPUT type="checkbox" id="chkStatus" name="chkStatus" value="1" Checked title="Yes">
	</div><div class="col-md-2 mb-3">
    </div>
   </div><div class="form-row"><div class="col-md-12 mb-3"><hr style="border:0.5px dotted blue;background-color:#5af;"/></div></div>
</div>
<!-- One "tab" for each step in the form: -->
<div class="tab">
  <H1>CONTACT ADDRESSES AND OTHER DETAILS</H1>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="txtTelNo">Mobile/ Tel. No. *</label>
      <input type="text" id="txtTelNo" name="txtTelNo" placeholder="+25470" required maxlength="14" onkeyup="checkData(0,this)">
    </div><div class="col-md-8 mb-3">
      <label for="txtAddress">Postal Address * </label>
      <input type="text" id="txtAddress" name="txtAddress" placeholder="P.O BOX " required value="P.O BOX " maxlength="30" required  onkeyup="checkData(1,this)">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="txtEMail">E-Mail Address</label>
      <input type="text" id="txtEMail" name="txtEMail" placeholder="someone@website.com" style="text-transform:lowercase;" maxlength="25">
    </div><div class="col-md-4 mb-3">
      <label for="cboTerms">Form of Employment *</label>
      <SELECT name="cboTerms" id="cboTerms" size="1" required><option selected>Permanent</option><Option>Temporary</option><Option>Casual</option></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboEmployer">Employer *</label>
      <SELECT name="cboEmployer" id="cboEmployer" size="1" required><option selected>BOM</option><Option>TSC</option></SELECT>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="cboCounty">Home County *</label>
      <SELECT name="cboCounty" id="cboCounty" size="1" required onChange="loadConstituency(this)"><?php echo $optCounty;?></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboConst">Constituency *</label>
      <SELECT name="cboConst" id="cboConst" size="1" onChange="loadWards(this)" required><?php echo $optMP; ?></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboWard">County Ward *</label>
      <SELECT name="cboWard" id="cboWard" size="1" required><?php echo $optMCA; ?></SELECT>
    </div>
  </div>
  <div class="form-row">
	<div class="col-md-6 mb-3">
      <label for="txtSubLocation">Sub-Location *</label>
      <input type="text" id="txtSubLocation" name="txtSubLocation" placeholder="Bulimbo" required value="" maxlength="30" onkeyup="checkData(1,this)">
    </div><div class="col-md-6 mb-3">
      <label for="txtVillage">Village/ Town</label>
      <input type="text" id="txtVillage" name="txtVillage" placeholder="Lukusi" value="" maxlength="30" onkeyup="checkData(1,this)">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="txtIllness">Historical Illness *</label>
      <textarea id="txtIllness" name="txtIllness" placeholder="Historical Illnesses" rows=3 maxlength=150 onkeyup="checkData(1,this)"></textarea>
    </div>
   <div class="col-md-6 mb-3">
      <label for="txtAllergy">Historical Allergies *</label>
      <textarea id="txtAllergy" name="txtAllergy" placeholder="Historical Allergies" rows=3 maxlength=150  onkeyup="checkData(1,this)"></textarea>
    </div>
  </div><div class="form-row"><div class="col-md-12 mb-3"><hr style="border:0.5px dotted blue;background-color:#5af;"/></div></div>
</DIV>
<div style="overflow:auto;">
	<div style="float:right;">
	  <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
	  <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
	  <a href="stf.php"><button type="button" id="cmdClose" style="background-color:#aaa;color:#fff;">Close/ Cancel</button></a>
	</div>
</div>
</form></div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/iebc.js"></script>
<script type="text/javascript" src="tpl/js/stfadd.js"></script>
<?php
	echo '<script type="text/javascript"> var currentTab = 0; showTab(currentTab);';
	if(isset($mp) && strlen($mp)>0){
		echo 'var mp=['.$mp.'];';
		if(strlen($mca)>0) echo 'var mca=['.$mca.'];';

	}echo '</script>';mysqli_close($conn);footer();
?>
