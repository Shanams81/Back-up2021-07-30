<?php
    include_once('shanam.php');
    class VBal{
        private $vno,$bal;
        public function __construct($n,$b){$this->vno=$n;	$this->bal=$b;}	public function valVNo(){return $this->vno;}	public function valBal(){return $this->bal;}
    }
    if(isset($_POST['btnSave'])){
        $tkn=isset($_POST['txtTkn'])?sanitize($_POST['txtTkn']):0;			     $recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0;
        $date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('d-m-Y');	$date=preg_split('/\-/',$date);	$date=$date[2].'-'.$date[1].'-'.$date[0];
        $ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;				       $tranche=isset($_POST['txtTranchNo'])?sanitize($_POST['txtTranchNo']):0;
        $ben=isset($_POST['txtNOB'])?sanitize($_POST['txtNOB']):0;			     $mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'EFT';
        $cheno=isset($_POST['txtCheNo'])?sanitize($_POST['txtCheNo']):null;	 $amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0; $cheno=strlen($cheno)>0?$cheno:null;
        $bal=isset($_POST['txtBal'])?sanitize($_POST['txtBal']):0;			     $nov=isset($_POST['txtNOV'])?sanitize($_POST['txtNOV']):0;
        $bank=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;		     $amt=preg_replace('/[^0-9\.]/','',$amt);	$bal=preg_replace('/[^0-9\.]/','',$bal);
        $info=isset($_POST['cboACBank'])?sanitize($_POST['cboACBank']):'0-0-0-0';   $info=preg_split('/\-/',$info); //[0] A/C [1] Bank A/C [2] Trancge No [3] Prev No. Of Beneficiaries
        if($_SESSION['tkn']!=$tkn || $ac==0 || $tranche==0 || $ben==0 || (strcasecmp($mode,'cheque')==0 && strlen($cheno)==0) || $bal!=0 || $amt<1 || $bank==0){
            echo 'FSE Receipt Record has errors. Can not be saved as entered. Click <a href="fsefees.php">HERE</a> to go back'; unset($_SESSION['tkn']); exit(0);
        }else{
            $sql="UPDATE acc_fseincome SET noofstud='$ben',recon='$date',batchno='$tranche',acc='$ac',acsno='$bank',amt=".($amt*$ben).",mode='$mode',modeno=".var_export($cheno,true)." WHERE
            recno LIKE '$recno';";
            for($i=0;$i<$nov;$i++){
                $v=isset($_POST['txtVote_'.$i])?sanitize($_POST['txtVote_'.$i]):'0-0';	$v=preg_split('/\-/',$v); //[0] Vote No. [1] Acc
                $pamt=isset($_POST['txtPAmt_'.$i])?sanitize($_POST['txtPAmt_'.$i]):0;	$pamt=preg_replace('/[^0-9\.]/','',$pamt);
                $camt=isset($_POST['txtCAmt_'.$i])?sanitize($_POST['txtCAmt_'.$i]):0;	$camt=preg_replace('/[^0-9\.]/','',$camt);
                if ($camt>0 && $pamt==0) $sql.="INSERT INTO acc_fsevotes (recno,acc,voteno,amt) VALUES ($recno,$v[1],$v[0],".($camt*$ben).");";
                elseif($camt==0 && $pamt>0) $sql="DELETE FROM acc_fsevotes WHERE recno LIKE $recno and acc LIKE '$v[1]' and voteno LIKE '$v[0]';";
                else $sql.="UPDATE acc_fseVotes SET amt=".($camt*$ben)." WHERE recno LIKE $recno and acc LIKE '$v[1]' and voteno LIKE '$v[0]';";
            }
            //beneficiaries
            if($ben!=$info[3]) $sql.="DELETE FROM acc_fseben WHERE recno=$recno and acc=$ac; INSERT INTO acc_fseben(recno,acc,admno,amt) SELECT $recno,$ac,admno,$amt FROM stud WHERE
            markdel=0 and present=1 ORDER BY admno ASC LIMIT 0,$ben;";
            else $sql.="UPDATE acc_fseben SET amt=$amt WHERE recno=$recno and acc=$ac;";
            $sql.="UPDATE acc_banking SET acsno=$bank,amt=".($amt*$ben)." WHERE transtype=0 and transno=$recno;";
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fsefees.php">HERE</a> to go back'); $i=0;
            do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=($i>0?1:0);
            unset($_SESSION['tkn']); header("location:fsefees.php?action=1-$i"); exit(0);
        }
    }elseif(isset($_POST['btnDel'])){
        $recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0; $rmks=isset($_POST['txtDel'])?sanitize($_POST['txtDel']):''; $ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;
        if($recno==0 || strlen($rmks)<20){
            echo 'FSE Receipt Record Can not be deleted until a valid reason is given. Click <a href="fsefees.php">HERE</a> to go back'; unset($_SESSION['tkn']); exit(0);
        }else{
            $sql="UPDATE acc_fseincome SET markdel=1, delreason='$rmks' WHERE recno LIKE '$recno'; UPDATE acc_fsevotes SET markdel=1 WHERE recno LIKE '$recno' and acc LIKE '$ac'; UPDATE
            acc_fseben SET markdel=1 WHERE recno=$recno and acc=$ac; UPDATE acc_banking SET markdel=1, delreason='$rmks' WHERE transtype=0 and transno=$recno;";
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fsefees.php">HERE</a> to go back'); $i=0;
            do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=($i>0?1:0);
            unset($_SESSION['tkn']); header("location:fsefees.php?action=2-$i"); exit(0);
        }
    }$rec=isset($_REQUEST['rec'])?sanitize($_REQUEST['rec']):'0-0';     $rec=preg_split('/\-/',$rec); //[0] receipt number, [1] - ACC [2] unique id
    $_SESSION['tkn']=$tkn=uniqid();
    $sql="SELECT acno,descr from acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 and acno LIKE  '$rec[1]' ORDER BY acno ASC; SELECT a.sno,concat(b.abbr,' - A/C ',a.accno) as acc FROM
    acc_accounts a Inner Join acc_banks b ON (a.bankno=b.sno) WHERE accacc LIKE '$rec[1]'; SELECT gofeedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT count(admno)
    FROM stud GROUP BY markdel,present HAVING markdel=0 and present=1; SELECT f.voteno,(f.t3-if(isnull(i.vamt),0,(i.vamt))) as bal FROM acc_votes v INNER JOIN acc_feestruct f ON
    (v.sno=f.voteno) LEFT JOIN (SELECT v.voteno,sum(v.amt/i.noofstud) as vamt FROM acc_fseincome i INNER JOIN acc_fsevotes v USING (recno,acc) GROUP BY v.acc,v.voteno,v.markdel HAVING
    v.markdel=0 and v.acc LIKE '$rec[1]')i using (voteno) WHERE v.fs_defined=1 and v.acc LIKE '$rec[1]'; SELECT noofstud,recon,batchno,acc,acsno,(amt/noofstud) as am,mode,modeno,rmks FROM
    acc_fseincome WHERE recno LIKE '$rec[0]'; SELECT v.acc,v.sno as voteno,v.descr,if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v LEFT JOIN (SELECT v.acc,v.voteno,(v.amt/i.noofstud) as
    amt FROM acc_fseincome i INNER JOIN acc_fsevotes v USING (recno,acc) WHERE v.markdel=0 and v.recno LIKE '$rec[0]')f ON (v.acc=f.acc and v.sno=f.voteno) WHERE v.markdel=0 and v.fs_defined=1
    and v.acc IN (SELECT acc FROM acc_fseincome WHERE recno LIKE '$rec[0]');";
    mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"fsefees.php\">HERE</a> to go back."); 	$nostud=$i=$viu=$del=0; $optBanks=$optACs='';
    headings('<link rel="stylesheet" type="text/css" href="../date/tcal.css" />',0,0,1);
?>
<br><br><div class="container" style="margin:auto;max-width:900px;background:#eee;border-radius:20px;padding:0px 0px 10px 0px;padding:10px;font-size:0.7rem;">
<form name="frmNewIncome" method="post" action="FSEFeeRecEdit.php" onsubmit="return validateData(this)"><INPUT name="txtTkn" type="hidden" size=4 value="<?php echo $tkn;?>" id="txtTkn">
    <div class="form-row"><div class="col-md-12" style="font-size:12pt;font-weight:bold;letter-spacing:3px;word-spacing:5px;text-align:center;">FREE SECONDARY EDUCATION (FSE) RECEIPT EDITOR</div
    </div><div class="form-row"><div class="col-md-5" style="border:3px solid #fff;border-radius:10px 10px 0px 0px;">
        <div class="form-row"><div class="col-md-12" style="font-size:11pt;font-weight:bold;letter-spacing:2px;padding:5px;word-spacing:3px;text-decoration:underline double #fff;
        background-color:#777;border-radius:5px 5px 0 0;color:#fff;">FSE RECEIPT DETAILS</div></div>
    <?php
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){while($d=mysqli_fetch_row($rs)) $optACs.='<option value="'.$d[0].'">'.$d[1].'</option>';
            }elseif($i==1){while($d=mysqli_fetch_row($rs)) $optBanks.='<option value="'.$d[0].'">'.$d[1].'</option>';
            }elseif($i==2){if(mysqli_num_rows($rs)>0) list($del)=mysqli_fetch_row($rs);
            }elseif($i==3){if(mysqli_num_rows($rs)>0) list($nostud)=mysqli_fetch_row($rs);
            }elseif($i==4){if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $vbal[]=new VBal($d[0],$d[1]);
            }elseif($i==5){if(mysqli_num_rows($rs)>0) $fee=mysqli_fetch_row($rs);
                echo '<div class="form-row"><div class="col-md-6"><label for="txtRecNo">Receipt No. *</label><input type="text" name="txtRecNo" id="txtRecNo" readonly value="'.$rec[0].'"
                class="dis" placeholder="Auto"></div><div class="col-md-6"><label for="dtpDate">Received On *</label><input type="text" name="dtpDate" id="dtpDate" readonly value="'.
                date('d-m-Y',strtotime($fee[1])).'" size=8 class="tcal"></div></div>';
                echo '<div class="form-row"><div class="col-md-6"><label for="cboAC">Votehead A/C Credited *</label><SELECT name="cboAC" id="cboAC" size=1>'.$optACs.'</SELECT></div>
                <div class="col-md-6"><label for="txtTranchNo">Tranche No. *</label><input type="text" name="txtTranchNo" id="txtTranchNo" value="'.$fee[2].'" style="text-align:center;
                background-color:#ddd;" onchange=\"return checkTranche(this)\" onkeyup="checkData(0,this)"><input type="hidden" name="txtACBank" id="txtACBank" value="'.$fee[3].'-'.$fee[4].
                '-'.$fee[2].'-'.$fee[0].'"></div></div>';
                echo '<div class="form-row"><div class="col-md-6"><label for="txtNOB">No. of Beneficiaries *</label><input type="text" name="txtNOB" id="txtNOB" value="'.$fee[0].'"
                onkeyup="checkData(0,this)" onchange="confirmNo(this)" style="text-align:center;"></div><div class="col-md-6"><label for="txtTtlStud">Registered Students</label><input type="text"
                name="txtTtlStud" id="txtTtlStud" readonly value="'.$nostud.'" style="text-align:center;background-color:#ddd;"></div></div>';
                echo '<div class="form-row"><div class="col-md-6"><label for="cboMode">Mode of Receipt *</label><SELECT name="cboMode" id="cboMode" size=1 onchange="enableTransNo(this)"><option '
                . 'value="EFT" '.(strcasecmp($fee[6],'eft')==0?'selected':'').'>E . F . T</option><option value="Cheque" '.(strcasecmp($fee[6],'cheque')==0?'selected':'').'>Cheque</option>
                </SELECT></div><div class="col-md-6"><label for="txtCheNo">Trans/ Cheque No. </label><input type="text" name="txtCheNo" id="txtCheNo" value="'.$fee[7].'" maxlength=15></div></div>';
                echo '<div class="form-row"><div class="col-md-6"><label for="cboBank">Bank A/C Credited *</label><SELECT name="cboBank" id="cboBank" size=1>'.$optBanks.'</SELECT></div>
                <div class="col-md-6"><label for="txtAmt">Amount Per Student *</label><input type="text" name="txtAmt" id="txtAmt" value="'.number_format($fee[5],2).'" maxlength=10
                style="text-align:right;font-weight:bold;letter-spacing:2px;" onkeyup="checkData(1,this)" onchange="distributeVotes(this)"></div></div>';
                echo '</div><div class="col-md-7" style="border:3px solid #fff;border-radius:10px 10px 0px 0px;">';
                echo '<div class="form-row"><div class="col-md-12" style="font-size:11pt;font-weight:bold;letter-spacing:5px;word-spacing:6px;padding:5px;text-decoration:underline double #fff;'
                . 'background-color:#777;color:#fff;border-radius:5px 5px 0 0;">VOTEHEAD DISTRIBUTION DETAILS</div></div>';
                echo '<div class="form-row" style="font-weight:bold;"><div class="col-md-4">VOTEHEAD</div><div class="col-md-2">BALANCE</div><div class="col-md-3">INITIAL AMOUNT</div><div '
                . 'class="col-md-3">NEW AMOUNT</div></div>';
            }else{
                $nov=mysqli_num_rows($rs); echo '<input name="txtNOV" id="txtNOV" type="hidden" value="'.$nov.'">'; $c=$ttl[0]=$ttl[1]=0;
                while ($dat=mysqli_fetch_row($rs)){ $bal=0;
                    if(isset($vbal)) foreach($vbal as $b){if($b->valVNo()==$dat[1]){$bal=$b->valBal(); break;}}
                    echo '<div class="form-row" style="border-bottom:0.5px dotted #c0f;margin:2px 0px 2px 0px;"><div class="col-md-4">'.$dat[2].'<input type="hidden" name="txtVote_'.$c.'" '
                    . 'id="txtVote_'.$c.'" value="'.$dat[1].'-'.$dat[0].'"></div>';
                    echo '<div class="col-md-2"><input type="text" name="txtBal_'.$c.'" id="txtBal_'.$c.'" value="'.number_format($bal,2).'" readonly style="text-align:right;font-weight:bold;
                    background-color:#ddd;"></div>';
                    echo '<div class="col-md-3"><input type="text" name="txtPAmt_'.$c.'" id="txtPAmt_'.$c.'" value="'.number_format($dat[3],2).'" style="text-align:right;
                    font-weight:bold;background-color:#ddd;" readonly></div>';
                    echo '<div class="col-md-3"><input type="text" name="txtCAmt_'.$c.'" id="txtCAmt_'.$c.'" value="'.number_format($dat[3],2).'" onkeyup="checkData(1,this)"
                     style="text-align:right;color:#00b;" onchange="confirmBal('.$c.')"></div></div>';	$ttl[0]+=$bal; 		$ttl[1]+=$dat[3]; $c++;
                }echo '<div class="form-row"><div class="col-md-4" style="font-weight:bold;">TOTAL AMOUNT</div><div class="col-md-2"><input type="text" name="txtTtlBal" id="txtTtlBal" value="'.
                number_format($ttl[0],2).'" readonly style="text-align:right;font-weight:bold;background-color:#ddd;"></div><div class="col-md-3"><input type="text" name="txtPAmt" id="txtPAmt" '
                . 'readonly value="'.number_format($ttl[1],2).'" style="text-align:right;font-weight:bold;background-color:#ddd;"></div><div class="col-md-3"><input type="text" name="txtCAmt" '
                . 'id="txtCAmt" readonly value="'.number_format($ttl[1],2).'" style="text-align:right;font-weight:bold;background-color:#ddd;"></div></div>';
            } mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
?></div></div></div>
<div class="form-inline"><div class="col-md-12" style="font-size:11pt;font-weight:bold;letter-spacing:5px;word-spacing:6px;padding:5px 1px 5px 1px"><label for="txtBal" class="form-control"
style="background-color:inherit;border:0;padding:2px;">BALANCE TO BE DISTRIBUTED</label><input type="text" name="txtBal" id="txtBal" readonly value="0.00" style="text-align:right;
font-size:11pt;
font-weight:bold;background-color:#ddd;padding:2px;" class="form-control"></div></div>
<hr style="border:0;border-top:1px dashed #00f;height:0px;magrin:2px">
<div class="form-row"><div class="col-md-6" style="text-align: center;"><button type="submit" name="btnSave" id="btnSave">Save Changes</button></div><div class="col-md-3">
<button id="btnDelShow" name="btnDelShow" type="button" onclick="confirmDel()" <?php echo $del==1?"":"disabled";?>>Delete</button></div><div class="col-md-3" style="text-align:right;">
<a href="fsefees.php"><button type="button" name="btnClose" id="btnClose">Close</button></a></div></div>
<hr style="border:0;border-top:1px dashed #00f;height:0px;margin:2px">
<div class="form-row" id="spDel" style="display:none;"><div class="col-md-9"><label for="txtDel">Reason for Deleting *<textarea rows="4" name="txtDel" id="txtDel"  disabled class="del"
 style="text-transform:uppercase;letter-spacing:2px;word-spacing:3px;color:#d00;" placeholder="FSE Receipt Details Erroneously captured" onkeyup="enableDelete(this)"></textarea></div>
<div class="col-md-3" style="text-align: center;"><button name="btnDel" id="btnDel" type="submit">Delete Receipt</button></div></div></form></div>
<script type="text/javascript" src="tpl/js/fsefeeedit.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript">
    function setACBank(){
        var acbank=document.getElementById('txtACBank').value.trim().split(/\-/g);
        var ac=Number(acbank[0]),bank=Number(acbank[1]); ac=isNaN(ac)?0:ac;	bank=isNaN(bank)?0:bank;
        document.getElementById('cboAC').value=ac;	document.getElementById('cboBank').value=bank;
        document.getElementById('txtNOB').focus();
    }setACBank();
</script>
</body></html>
