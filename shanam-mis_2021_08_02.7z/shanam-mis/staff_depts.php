<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['act'])?$_REQUEST['act']:'0-0';    $act=preg_split('/\-/',$act);     $dept=isset($_REQUEST['cboDept']) ? strip_tags($_REQUEST['cboDept']): "%";
    mysqli_multi_query($conn,"SELECT deptview,deptadd,deptedit FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT deptno,deptname FROM depts WHERE markdel=0 ORDER BY deptno Asc;");
    $vie=$add=$edi=$i=0; $opt=''; $deptname='All';
    do{
      if($rs=mysqli_store_result($conn)){
         if($i==0){if(mysqli_num_rows($rs)==1) list($vie,$add,$edi)=mysqli_fetch_row($rs);}
         else{if(mysqli_num_rows($rs)>0) while ($data=mysqli_fetch_row($rs)){if($data[0]==$dept) $deptname=$data[1]; $opt.="<option value=\"$data[0]\">$data[0] - $data[1]</option>";}}
         mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
    if ($vie==0) header("location:vague.php");
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css"/>',$act[0],$act[1],2);
?>
<div class="head"><form method="post" action="staff_depts.php"><a href="stf_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;<label for="cboDept">
View Members Of </label> <select name="cboDept" id="cboDept" size="1"><option selected value="%">All</option><?php echo $opt;?></select> Department&nbsp;&nbsp;<button type="submit" name="Staff"
<?php if ($vie==0) print "disabled"; else print "-"; ?>>Show Members</button></form></div>
<div class="container" style="width:fit-content">
<?php
    if (isset($_POST["Staff"])){
        if (strcasecmp($dept,"%")==0) $h= "Members of all departments";
        else $h= "Staff Members of $deptname Department";
    }else $h= "Members of All Departments";
    print "<br><h5 style=\"text-decoration:underline overline double #fff; color:#fff;font-weight:bold;text-align:center;letter-spacing:3px;word-spacing:4px;\">".strtoupper($h)."</h5>";
?>
<span style="background:#fff;border:0.5px dotted green;border-radius:10px;padding:6px;display:block;width:fit-content;font-size:12px;margin:auto;"><form name="frmFind" action="staff_depts.php"
method="post">Find Staff Members By &nbsp;<input type="radio" name="radFind" id="radIDNo" value="idno" onclick="clrText()">Adm. No.&nbsp;<input type="radio" name="radFind"
id="radDeptNo" value="deptno" onclick="clrText()">Department No.&nbsp; <input type="radio" name="radFind" id="radName" value="st_names" checked  onclick="clrText()">Names
&nbsp; &nbsp; <input type="text" maxlength="17" size="30" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Type/ Enter what to Find" style="border:0px;
border-bottom:1px solid blue;color:#00d;"></form></span>
<div style="border:0.5px groove #007;border-radius:10px;min-height:100px;max-height:600px;max-width:1000px;min-width:100px;overflow-y:scroll;background-color:#fff;">
<?php
    if (isset($_POST['Staff'])) $sql="SELECT s.idno,concat(s.surname,' ',s.onames) as st_names,s.gender,s.telno,s.designation FROM stf s LEFT JOIN stf_depts d ON s.idno=d.stfno WHERE
    (s.markdel=0 AND s.present=1 AND d.deptno LIKE '%$dept%') Order By s.surname,s.onames Asc";
    else $sql="SELECT s.idno,concat(s.surname,' ',s.onames) as st_names,s.gender,s.telno,s.designation FROM stf s LEFT JOIN stf_depts d ON s.idno=d.stfno WHERE (s.markdel=0 AND s.present=1) "
    . "Order By s.surname,s.onames Asc";
    $rsStf=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"stf_manager.php\">HERE</a> to try again.");
?>
<table class="table table-striped table-hover table-sm table-bordered"><thead class="thead-dark"><tr><th colspan="5">STAFF DETAILS</th><th colspan="4">DEPARTMENT DETAILS</th><th colspan="2">
Dept Action</th></tr><tr><th>ID No.</th><th>Staff's Names</th><th>Gender</th><th>Tel. No.</th><th>Designation</th><th>Dept No.</th><th>Name</th><th>Staff Title</th><th>Section</th><th>
Existing Member</th><th>New Member</th></tr></thead><tbody>
<?php
    if (mysqli_num_rows($rsStf)==0):
        print "<tr><td colspan=\"11\">No staff members are currently available for viewing</td><tr>";
    else:
        while (list($idno,$names,$gender,$tel,$desig)=mysqli_fetch_row($rsStf)):
            $rsDep=mysqli_query($conn,"SELECT ds.deptno,d.deptname,ds.title,ds.section FROM depts d INNER JOIN stf_depts ds USING (deptno) WHERE (ds.stfno LIKE
            '$idno' and d.markdel=0) ORDER BY ds.deptno ASC");
            $nben=mysqli_num_rows($rsDep); $rows=($nben==0?1:$nben);
            print "<tr><td rowspan=\"$rows\" align=\"right\">$idno</td><td rowspan=\"$rows\">$names</td><td rowspan=\"$rows\">$gender</td><td rowspan=\"$rows\">$tel
            </td><td rowspan=\"$rows\">$desig</td>";
            $start=0;
            if ($nben>0):
                while (list($depno,$depname,$title,$sect)=mysqli_fetch_row($rsDep)):
                    if ($start==0):
                        $start=1; print "<td>$depno</td><td>$depname</td><td>$title</td><td>$sect</td><td align=\"center\"><a onclick=\"return canedit($edi);\"
                        href=\"Dept_staffing.php?action=1-$depno-$idno\">Edit</a></td><td align=\"center\" valign=\"middle\" rowspan=\"$rows\"><a
                        onclick=\"return canadd($add);\" href=\"dept_staffing.php?action=0-$depno-$idno\">Register</a></td></tr>";
                    else:
                        print "<tr><td>$depno</td><td>$depname</td><td>$title</td><td>$sect</td><td align=\"center\"><a onclick=\"return canedit($edi);\"
                        href=\"dept_staffing.php?action=1-$depno-$idno\">Edit</a></td></tr>";
                    endif;
                endwhile;
            else:
                print "<td colspan=\"5\">This member does not belong to any department!!<br>Click <b>Register</b> assign him/her to a department</td><td
                align=\"center\"><a onclick=\"return canadd($add);\" href=\"dept_staffing.php?action=0-0-$idno\">Register</a></td></tr>";
            endif; mysqli_free_result($rsDep);
        endwhile;
    endif;
    print "</tbody></table></div></div>";
    mysqli_free_result($rsStf);
    mysqli_close($conn); footer();
?>
