<?php
	include_once('../conn/pri_sch_connect.inc');
	include_once('tpl/printing.tpl');
	include_once('../mpdf/mpdf.php');
	$rs=mysqli_query($conn,"SELECT finyr FROM ss"); list($yr)=mysqli_fetch_row($rs); $yr=isset($yr)?$yr:date('Y'); mysqli_free_result($rs);
	$cls=isset($_REQUEST['CboCls'])?strip_tags($_REQUEST['CboCls']):"%";
	$strm=isset($_REQUEST['CboStream'])?strip_tags($_REQUEST['CboStream']):"%";
	$adno=isset($_REQUEST['TxtAdmNo'])?strip_tags($_REQUEST['TxtAdmNo']):"%";	
	//Query balances
	if (strcasecmp($adno,"%")!=0) $sql="SELECT s.admno,s.names,s.cls,s.ttl,s.prep,if((f.maint1-s.amtp)<1,(s.specialmedical+s.bbf+s.t1trans),(f.maint1-s.amtp+s.specialmedical+s.bbf+
	s.t1trans)) as t1bal,if((f.maint2-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))<1,s.t2trans,(f.maint2+s.t2trans-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))) as t2bal,
	if((f.maint3-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))<1,s.t3trans,(f.maint3+s.t3trans-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))) as t3bal,(f.maint3+s.specialmedical
	+s.bbf+s.t1trans+s.t2trans+s.t3trans-s.amtp) as bal,if((f.misct1-s.misamtp)<1,(s.miscbf+s.unifrm),(f.misct1-s.misamtp+s.miscbf+s.unifrm)) as t1misbal,if((f.misct2-s.misamtp-if((f.misct1
	-s.misamtp)<1,0,(f.misct1-s.misamtp)))<1,0,(f.misct2-s.misamtp-if((f.misct1-s.misamtp)<1,0,(f.misct1-s.misamtp)))) as t2misbal,if((f.misct3-s.misamtp-if((f.misct2-s.misamtp)<1,0,
	(f.misct2-s.misamtp)))<1,0,(f.misct3-s.misamtp-if((f.misct2-s.misamtp)<1,0,(f.misct2-s.misamtp)))) as t3misbal,(f.misct3+s.miscbf+s.unifrm-s.misamtp) as misbal FROM (SELECT s.admno,
	concat(s.surname,' ',s.onames) As names,c.clsno,concat(cn.clsname,'-',c.stream) As cls,c.curr_year,c.feegrp,c.lvlno,c.bbf,c.specialmedical,c.t1trans,c.t2trans,c.t3trans,c.miscbf,
	c.unifrm,if(isnull(f.amtpaid),0,f.amtpaid) as amtp,if(isnull(f.amtprep),0,f.amtprep) as prep,(if(isnull(f.ttlpaid),0,f.ttlpaid)+if(isnull(m.ttlamt),0,m.ttlamt)) as ttl,
	if(isnull(m.amtpaid),0,m.amtpaid) as misamtp FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT admno,curr_year,sum(amt-
	arrears-refunds-spemed-transport-prep) As amtpaid,sum(prep) As amtprep,sum(amt+bankcharges) As ttlpaid FROM acc_feerec f GROUP BY f.admno,f.curr_year,f.markdel Having (f.admno LIKE 
	'$adno' and f.markdel LIKE '0' and f.curr_year LIKE '$yr'))f On (s.admno=f.admno and s.curr_year=f.curr_year) LEFT JOIN (SELECT payeesno,curr_year,sum(amt-arrears-uni) as amtpaid,
	sum(amt+bankcharges) as ttlamt FROM acc_miscfeepyts GROUP BY payeesno,curr_year,markdel HAVING (markdel=0 and curr_year LIKE '$yr' and payeesno LIKE '$adno'))m On (s.admno=m.payeesno 
	and s.curr_year=m.curr_year) WHERE (s.`admno` Like '$adno' and s.curr_year LIKE '$yr'))s Inner JOIN acc_feeoutline f USING (curr_year,lvlno,feegrp)";
	else $sql="SELECT s.admno,s.names,s.cls,s.ttl,s.prep,if((f.maint1-s.amtp)<1,(s.specialmedical+s.bbf+s.t1trans),(f.maint1-s.amtp+s.specialmedical+s.bbf+s.t1trans)) as t1bal,if((f.maint2
	-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))<1,s.t2trans,(f.maint2+s.t2trans-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))) as t2bal,if((f.maint3-s.amtp-if((f.maint2-
	s.amtp)<1,0,(f.maint2-s.amtp)))<1,s.t3trans,(f.maint3+s.t3trans-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))) as t3bal,(f.maint3+s.specialmedical+s.bbf+s.t1trans+s.t2trans+
	s.t3trans-s.amtp) as bal,if((f.misct1-s.misamtp)<1,(s.miscbf+s.unifrm),(f.misct1-s.misamtp+s.miscbf+s.unifrm)) as t1misbal,if((f.misct2-s.misamtp-if((f.misct1-s.misamtp)<1,0,(f.misct1-
	s.misamtp)))<1,0,(f.misct2-s.misamtp-if((f.misct1-s.misamtp)<1,0,(f.misct1-s.misamtp)))) as t2misbal,if((f.misct3-s.misamtp-if((f.misct2-s.misamtp)<1,0,(f.misct2-s.misamtp)))<1,0,
	(f.misct3-s.misamtp-if((f.misct2-s.misamtp)<1,0,(f.misct2-s.misamtp)))) as t3misbal,(f.misct3+s.miscbf+s.unifrm-s.misamtp) as misbal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) 
	As names,c.clsno,concat(cn.clsname,'-',c.stream) As cls,c.curr_year,c.feegrp,c.lvlno,c.bbf,c.specialmedical,c.t1trans,c.t2trans,c.t3trans,c.miscbf,c.unifrm,if(isnull(f.amtpaid),0,
	f.amtpaid) as amtp,if(isnull(f.amtprep),0,f.amtprep) as prep,(if(isnull(f.ttlpaid),0,f.ttlpaid)+if(isnull(m.ttlamt),0,m.ttlamt)) as ttl,if(isnull(m.amtpaid),0,m.amtpaid) as misamtp 
	FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT admno,curr_year,sum(amt-arrears-refunds-spemed-transport-prep) As 
	amtpaid,sum(prep) As amtprep,sum(amt+bankcharges) As ttlpaid FROM acc_feerec f GROUP BY f.admno,curr_year,f.markdel Having (f.markdel LIKE '0' and f.curr_year LIKE '$yr'))f On 
	(s.admno=f.admno and s.curr_year=f.curr_year) LEFT JOIN (SELECT payeesno,curr_year,sum(amt-arrears-uni) as amtpaid,sum(amt+bankcharges) as ttlamt FROM acc_miscfeepyts GROUP BY 
	payeesno,curr_year,markdel HAVING (markdel=0 and curr_year LIKE '$yr'))m On (s.admno=m.payeesno and s.curr_year=f.curr_year) WHERE (c.`clsno` Like '$cls' and c.`stream` Like '$strm' 
	and s.curr_year LIKE '$yr'))s Inner JOIN acc_feeoutline f USING (curr_year,lvlno,feegrp) Order By cls, names Asc";
	$rsBal=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsBal);
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,mission,motto FROM ss"); 
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mis,$mot)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	//start pdf file
	if (strcasecmp($adno,"%")==0) $mpdf=new mPDF('c','A4','','',10,10,12,12,10,10); else $mpdf=new mPDF('c','A5','','',10,10,12,12,10,10); 
	$mpdf->useOnlyCoreFonts = true;    // false is default
	$mpdf->SetWatermarkText("Fee Notice");
	$mpdf->showWatermarkText = true;
	$mpdf->watermark_font = 'DejaVuSansCondensed';
	$mpdf->watermarkTextAlpha = 0.1;
	$mpdf->SetDisplayMode('fullpage');
	$mpdf->SetFooter('Page {PAGENO} of {nbpg} Pages');
	$html='<html><head><title>Fees Notice</title><style> 
			table.hide {border:0px;border-collapse:collapse;font-size:8pt;font-weight:bold;} td.hide,th.hide{border:0px;}
			table.pay,td.pay{border:0px;border-collapse:collapse;font-weight:normal;font-size:10pt;text-align:justify;}	
			table.gen,td,th {border:1.5px dashed blue;border-collapse:collapse;padding:2px 4px 2px 4px;}
			table.bal,td.bal,th.bal {border:1px solid blue;border-collapse:collapse;font-weight:normal;}
	</style></head><body>'; $a=1;
	if ($nor>0){
		$i=1; $html.='<table class="gen" cellpadding="4" cellspacing="4">';
		while (list($admno,$names,$cls,$ttl,$prep,$t1bal,$t2bal,$t3bal,$ybal,$t1misbal,$t2misbal,$t3misbal,$ymisbal)=mysqli_fetch_array($rsBal,MYSQLI_NUM)){
		 	if ($i%2==1) $html.='</tr><tr><td width="50%">'; else $html.='<td width="50%">';
			$html.='<table class="hide"><tr><td rowspan="3" valign="middle" width="80" align="center" class="hide"><img src="img/logo1.jpg" width="60" height="60" vspace="1" hspace="1"></td>
			<td class="hide">'.$scnm.'</td></tr><tr><td class="hide">'.$scadd.'</td></tr><tr><td class="hide">'.$mot.'</td></tr><tr><td colspan="2" class="hide"><hr><b 
			style="font-size:12px;">FEES BALANCE NOTICE &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Printed On:'.date("D d-M-Y").'<hr></td><br>';
			$html.='<tr><td class="pay" colspan="2"><b><u>'.$names.'</u></b> of admission number </b> '.$admno.' in class '.$cls.' has school fees balance below:<br><table class="bal" 
			cellpadding="2" align="center"><tr><th class="bal"></th><th class="bal"><b>Term I</b></th><th class="bal"><b>Term II</b></th><th class="bal"><b>Term III</b></th><th class="bal">
			<b>Years Bal</b></th></tr><tr><td class="bal" nowrap>Main A/C Balance</td><td align="right" class="bal">'.number_format($t1bal,2).'</td><td align="right" class="bal">'.
			number_format($t2bal,2).'</td><td align="right" class="bal">'.number_format($t3bal,2).'</td><td class="bal" align="right"><b>'.number_format($ybal,2).'</b></td></tr><tr><td 
			class="bal">Misc A/C Balance</td><td align="right" class="bal">'.number_format($t1misbal,2).'</td><td align="right" class="bal">'.number_format($t2misbal,2).'</td><td 
			align="right" class="bal">'.number_format($t3misbal,2).'</td><td align="right" class="bal"><b>'.number_format($ymisbal,2).'</b></td></tr><tr><td class="bal"><b>Total	Balance
			</b></td><td align="right" class="bal"><b>'.number_format(($t1bal+$t1misbal),2).'</b></td><td align="right" class="bal"><b>'.number_format(($t2bal+$t2misbal),2).'</b></td><td 
			align="right" class="bal"><b>'.number_format(($t3bal+$t3misbal),2).'</b></td><td align="right" class="bal"><b>'.number_format(($ybal+$ymisbal),2).'</b></td></tr></table><br><br>
			Having paid school fee of the sum of Kshs. '.number_format($ttl,2).' and prepaid the sum of Kshs. '.number_format($prep,2).'<br><br>Yours faithfully,<br><br>____________________
			<br>The Busar/ Accounts Clerk</td></tr><tr><td style="font-size:9px;color:#999999" class="pay" colspan="2"><hr style="border-color:#eeeeee;"><p style="font-size:8px;">
			Accounts Department wishes you and pupil a happy holiday.<br>Designed by Shanams Digital Solutions, Tel +254736732168</p></td></tr></table></td>';
			$i++;
		}
	}
	$html.='</td></tr></table></body></html>';
	$mpdf->WriteHTML($html);
	$mpdf->Output();
	mysqli_close($conn);
?>