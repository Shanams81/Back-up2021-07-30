<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['CmdDefine']))header ("Location:FeeStruAdd.php");
	else{
		
		$rsPriv=mysqli_query($conn,"SELECT struadd,struedit,struview FROM Acc_Priv WHERE uname LIKE '".$_SESSION['username']."'");
		if (mysqli_num_rows($rsPriv)==1) list($stad,$sted,$stvi)=mysqli_fetch_row($rsPriv);	mysqli_free_result($rsPriv);
		$s=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; $s=preg_split("/\-/",$s);
		$yr=isset($_POST['cboYr'])?strip_tags($_POST['cboYr']):(date('Y')-1);				$ac=isset($_POST['cboAC'])?strip_tags($_POST['cboAC']):1;
		$fgrp=isset($_POST['cboFeeGrp'])?strip_tags($_POST['cboFeeGrp']):'%';	$flvl=isset($_POST['cboLvl'])?strip_tags($_POST['cboLvl']):'%';
	}
?>
<html>
<head>
	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css"/><link href="tpl/headers.css" rel="stylesheet" type="text/css"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/> <title>Fee Structure</title>
	<script type="text/javascript" src="tpl/actionmessage.js"></script><script type="text/javascript" src="ajax/js/showFeeStruct.js"></script>
</head>
<body background="img/bg3.gif" <?php print "onload=\"actiondone($s[0],$s[1])\"";?>><div class="head">
<form method="post" action="archFeeStruct.php"><a href="pupil_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a> View <SELECT name="cboYr" 
id="cboYr" size="1">
<?php $rs=mysqli_query($conn,"SELECT DISTINCT curr_year FROM arch_feeoutline ORDER BY curr_year DESC");
while($year=mysqli_fetch_row($rs)) print "<option>$year[0]</option>"; mysqli_free_result($rs);?></SELECT>-
<SELECT name="cboAC" id="cboAC" size="1"><option value="1">Main Account</option><option value="2">Misc Account</option></select> Fee Structure Of <select name="cboLvl" id="cboLvl" 
size="1"><option selected value="%">All</option>
<?php
	$rs=mysqli_query($conn,"SELECT lvlno,lvlname FROM ClassLvl Order BY lvlno ASC"); 
	if (mysqli_num_rows($rs)>0) while (list($lno,$lname)=mysqli_fetch_row($rs)) print "<option value=\"$lno\">$lname</option>"; 	mysqli_free_result($rs);
	print "</select> &nbsp;&nbsp;&nbsp;Fee Group <SELECT name=\"cboFeeGrp\" id=\"cboFeeGrp\" size=\"1\"><option selected value=\"%\">All</option>";
	$cour=mysqli_query($conn,"SELECT fee FROM grps WHERE (fee is not null and fee not like '') Order BY fee ASC"); 
	if (mysqli_num_rows($cour)>0) while (list($cona)=mysqli_fetch_row($cour)) print "<option>$cona</option>"; 	mysqli_free_result($cour);
	print "</select>&nbsp;&nbsp;&nbsp;&nbsp;<button type=\"submit\" name=\"cmdView\" ".(($stvi==0)?"disabled":"").">View Fee Structures</button></form></div>";
	if (isset($_POST['cmdView'])){
	 	$account=$ac==1?"MAIN A/C":"MISC A/C"; $h=$yr.' '.$account;
	 	if ((strcasecmp($fgrp,"%")==0) && (strcasecmp($flvl,"%")==0)) $h="ALL ".$h;
		elseif ((strcasecmp($fgrp,"%")!=0) && (strcasecmp($flvl,"%")==0)) $h="ALL $h $fgrp ";
		elseif ((strcasecmp($fgrp,"%")==0) && (strcasecmp($flvl,"%")!=0)) $h="ALL $h $flvl ";
		else $h="$h $fgrp $flvl "; $h=strtoupper($h)."FEE STRUCTURES";
		if ($ac==1) $sql="SELECT f.curr_year,f.feegrp,c.lvlno,c.lvlname,f.tui,f.board,f.act,f.ltt,f.rmi,f.ewc,f.exam,f.adm,f.lib,f.med,f.pemol,f.olevies,f.maint3 FROM arch_feeoutline f 
		inner join classlvl c using (lvlno) WHERE f.curr_year LIKE '$yr' and f.feegrp LIKE '$fgrp' and f.lvlno LIKE '$flvl' Order By curr_year,lvlno,feegrp DESC";
		else $sql="SELECT f.curr_year,f.feegrp,f.lvlno,c.lvlname,f.misidcard,f.misqa,f.misremedial,f.misht,f.misgrad,f.mistrip,f.misole,f.misct3 FROM arch_feeoutline f Inner Join 
		classlvl c USING (lvlno) WHERE (f.feegrp LIKE '$fgrp' and f.lvlno LIKE '$flvl' and curr_year LIKE '$yr') Order By f.curr_year,f.lvlno,f.feegrp Desc";
	}else{
		$h="ALL PREVOUS YEARS' FEE STRUCTURES";
		$ac==1; $sql="SELECT f.curr_year,f.feegrp,c.lvlno,c.lvlname,f.tui,f.board,f.act,f.ltt,f.rmi,f.ewc,f.exam,f.adm,f.lib,f.med,f.pemol,f.olevies,f.maint3 FROM arch_feeoutline f 
		inner join classlvl c using (lvlno) Order By curr_year,lvlno,feegrp Asc";
	}$rsFeeStr=mysqli_query($conn,$sql);		$nofs=mysqli_num_rows($rsFeeStr);
	print"<h2 style=\"font-weight:strong;letter-spacing:4px;word-spacing:7px;background-color:#000;color:#fff;text-align:center;\">$h FEE STRUCTURES</h2>";
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\" Align=\"center\"><tr align=\"middle\" bgcolor=\"#eeeeee\"><th colspan=\"3\">Fee Structure Details</th><th 
	colspan=\"".($ac==1?13:8)."\" style=\"word-spacing:4px;letter-spacing:6px;\">Votehead Distribution</th><th rowspan=\"2\">View<br>Printable</th></tr><tr><th>Year</th><th>Fee Group
	</th><th>Level</th>";
	if ($ac==1){
		print "<th>Tuition</th><th>Boarding &amp; Meals</th><th>Activity</th><th>L . T &amp; T</th><th>R . M . I</th><th>E . W . C</th><th>Exams/ CATs</th><th>Admin Costs</th><th>
		Library</th><th>Medical</th><th>Personal Emol</th><th>Other Levies</th><th>Total</th></tr>";
		if ($nofs>0){
			$i=0;
			while (list($yr,$grp,$lvlno,$lvl,$tui,$boa,$act,$ltt,$rmi,$ewc,$exa,$adm,$lib,$med,$pem,$ole,$ttl)=mysqli_fetch_row($rsFeeStr)):
				if ($i%2==1) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">";
				print "<td>$yr</td><td>$grp</td><td>$lvl</td><td align=\"right\">".number_format($tui,2)."</td><td align=\"right\">".number_format($boa,2)."</td><td 
				align=\"right\">".number_format($act,2)."</td><td align=\"right\">".number_format($ltt,2)."</td><td align=\"right\">".number_format($rmi,2)."</td><td 
				align=\"right\">".number_format($ewc,2)."</td><td align=\"right\">".number_format($exa,2)."</td><td align=\"right\">".number_format($adm,2)."</td><td 
				align=\"right\">".number_format($lib,2)."</td><td align=\"right\">".number_format($med,2)."</td><td align=\"right\">".number_format($pem,2)."</td><td 
				align=\"right\">".number_format($ole,2)."</td><td align=\"right\" bgcolor=\"#eeeeee\"><b>".number_format($ttl,2)."</b></td>";
				print "<td align=\"center\"><a href=\"ArchViewFeeStruct.php?adm=$ac-$yr-$grp-$lvlno\">View</a></td></tr>"; 
				$i++;
			endwhile;
		}else print "<tr><td colspan=\"20\">There are no Archived Fee Structure(s)</td></tr>";									
		print "<tr><td colspan=\"20\">$nofs Main Account Fee Structure(s)</td></tr></table>";
	}else{
		echo "<th>ID Card</th><th>Quality Assurance</th><th>Remedial</th><th>Holiday Tuition</th><th>Graduation</th><th>Academic Trip</th><th>Other Levies</th><th>Total</th></tr>";
		if ($nofs>0){
			$i=0;
			while (list($yr,$grp,$lvlno,$lvl,$id,$qa,$rem,$ht,$gra,$tri,$ole,$ttl)=mysqli_fetch_row($rsFeeStr)):
				if ($i%2==1) echo "<tr>"; else echo "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">";
				echo "<td>$yr</td><td>$grp</td><td>$lvl</td><td align=\"right\">".number_format($id,2)."</td><td align=\"right\">".number_format($qa,2)."</td><td 
				align=\"right\">".number_format($rem,2)."</td><td align=\"right\">".number_format($ht,2)."</td><td align=\"right\">".number_format($gra,2)."</td><td 
				align=\"right\">".number_format($tri,2)."</td><td align=\"right\">".number_format($ole,2)."</td><td align=\"right\" bgcolor=\"#eeeeee\"><b>".
				number_format($ttl,2)."</b></td>";
				echo "<td align=\"center\"><a href=\"ArchViewFeeStruct.php?adm=$ac-$yr-$grp-$lvlno\">View</a></td></tr>"; 
				$i++;
			endwhile;
		}else print "<tr><td colspan=\"12\">There are no Archived Fee Structure(s)</td></tr>";									
		echo "<tr><td colspan=\"12\">$nofs Miscellaneous Account Fee Structure(s)</td></tr></table>";
	}		
	mysqli_close($conn);
?></BODY></HTML>