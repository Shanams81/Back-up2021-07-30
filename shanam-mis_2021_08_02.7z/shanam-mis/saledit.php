<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['CmdSave'])){
		$info=isset($_POST['TxtInfo'])?$_POST['TxtInfo']:"0-0-0"; 		$info=preg_split('/\-/',$info);
		$pp=isset($_POST['TxtPP'])?trim(strip_tags($_POST['TxtPP'])):"";					$bsal=isset($_POST['TxtBSal'])?trim(strip_tags($_POST['TxtBSal'])):0;
		$hou=isset($_POST['TxtHousing'])?trim(strip_tags($_POST['TxtHousing'])):0;			$nss=isset($_POST['TxtNSSF'])?trim(strip_tags($_POST['TxtNSSF'])):0;
		$med=isset($_POST['TxtMedical'])?trim(strip_tags($_POST['TxtMedical'])):0;			$nhi=isset($_POST['TxtNHIF'])?trim(strip_tags($_POST['TxtNHIF'])):0;
		$overt=isset($_POST['TxtCommuter'])?trim(strip_tags($_POST['TxtCommuter'])):0;		$sac=isset($_POST['TxtSACCO'])?trim(strip_tags($_POST['TxtSACCO'])):0;
		$empn=isset($_POST['TxtEmpNSSF'])?trim(strip_tags($_POST['TxtEmpNSSF'])):0;			$wel=isset($_POST['TxtWelfare'])?trim(strip_tags($_POST['TxtWelfare'])):0;
		$uni=isset($_POST['TxtUnion'])?trim(strip_tags($_POST['TxtUnion'])):0;				$adv=isset($_POST['TxtAdvance'])?trim(strip_tags($_POST['TxtAdvance'])):0;
		$paye=isset($_POST['TxtPAYE'])?trim(strip_tags($_POST['TxtPAYE'])):0;				$mpr=isset($_POST['TxtMPR'])?trim(strip_tags($_POST['TxtMPR'])):0;
		$ole=isset($_POST['TxtOle'])?trim(strip_tags($_POST['TxtOle'])):0;
		$bsal=preg_replace('/[^0-9^\.]/','',$bsal);			$hou=preg_replace('/[^0-9^\.]/','',$hou);		$nss=preg_replace('/[^0-9^\.]/','',$nss);
		$med=preg_replace('/[^0-9^\.]/','',$med);			$nhi=preg_replace('/[^0-9^\.]/','',$nhi);		$overt=preg_replace('/[^0-9^\.]/','',$overt);
		$sac=preg_replace('/[^0-9^\.]/','',$sac);			$empn=preg_replace('/[^0-9^\.]/','',$empn);		$wel=preg_replace('/[^0-9^\.]/','',$wel);
		$uni=preg_replace('/[^0-9^\.]/','',$uni);			$adv=preg_replace('/[^0-9^\.]/','',$adv);		$paye=preg_replace('/[^0-9^\.]/','',$paye);
		$mpr=preg_replace('/[^0-9^\.]/','',$mpr);			$ole=preg_replace('/[^0-9^\.]/','',$ole);
		if ($paye<=1162){ $mpr=0;	$paye=0;}
		$ns=($bsal+$hou+$med+$overt)-($tded=$nss+$nhi+$ole+($paye-$mpr)+$sac+$wel+$uni+$adv);
		if ((strlen($pp)==0 )||($ns<1)){
		 	print "<font size=4 color=\"#dd0000\">These salary changes are unrealistic. They have therefore been discarded. Click <a href=\"payroll.php\">
			 here</a> to try again.";
			exit();
		}else{
			mysqli_query($conn,"UPDATE acc_salpyt SET bsalary='$bsal',housingallow1='$hou',medicalallow1='$med',travelallow1='$overt',nssffee1='$nss',nhiffee1='$nhi',
			otherlevies1='$ole',empnssf='$empn',paye1='$paye',mpr1='$mpr',union1='$uni',sacco1='$sac',welfare1='$wel',advance='$adv',paypoint='$pp' WHERE payrollno LIKE 
			'$info[0]' and sal_month LIKE '$info[1]' and sal_year LIKE '$info[2]'") or die(mysqli_error($conn)." Salary changes not effected. Click <a href=\"payroll.php\">
			here</a> to try again");
			$i=mysqli_affected_rows($conn);
			header("location:payroll.php?action=1-$i");
		}
	}elseif (isset($_POST['CmdDel'])){
		$info=isset($_POST['TxtInfo'])?$_POST['TxtInfo']:"0-0-0"; 		$info=preg_split('/\-/',$info);
		mysqli_query($conn,"UPDATE acc_salpyt SET markdel=1 WHERE payrollno LIKE '$info[0]' and sal_month LIKE '$info[1]' and sal_year LIKE '$info[2]'") or 
		die(mysqli_error($conn)." Salary not deleted. Click <a href=\"payroll.php\">here</a> to try again.");
		$i=mysqli_affected_rows($conn);
		header("location:payroll.php?action=2-$i");	
	}else{
		$act=isset($_REQUEST['action'])?$_REQUEST['action']:'0-Jan-2000'; $act=preg_split("/\-/",$act);
		$rsSal=mysqli_query($conn,"SELECT sd.idno,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.payrollno,sp.processedon,sp.bsalary,sp.housingallow1,sp.medicalallow1,
		sp.travelallow1,sp.nssffee1,
		sp.nhiffee1,sp.otherlevies1,sp.empnssf,sp.paye1,sp.mpr1,sp.union1,sp.sacco1,sp.welfare1,sp.advance,sp.paypoint FROM stf s Inner Join acc_saldef sd USING (idno) Inner Join 
		Acc_salpyt sp On (sd.payrollno=sp.payrollno) WHERE (sp.payrollno LIKE '$act[0]' and sp.sal_month LIKE '$act[1]' and sp.sal_year LIKE '$act[2]')") or die(mysqli_error($conn).
		". Click <a href=\"payroll.php\">here</a> to try again");
		$addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')'; 	$date=date('Y-m-d');
		list($id,$nam,$desi,$payno,$procon,$bsal,$hou,$med,$trav,$nss,$nhi,$ole,$empn,$paye,$mpr,$uni,$sac,$wel,$adv,$pp)=mysqli_fetch_row($rsSal);
		$gs=$bsal+$hou+$med+$trav;	$tded=$nss+$nhi+$ole+($paye-$mpr)+$sac+$wel+$uni+$adv;	$ns=$gs-$tded;
	}
	mysqli_close($conn);
?>
<html lang="eng-us" content="html">
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Salary Editing</title>
	<script type="text/javascript" src="tpl/saledit.js"></script>
</head>
<body background="img/bg3.gif">
<?php
	print "<table cellpadding=3 cellspacing=0 border=1 bordercolor=\"#dddddd\" align=\"center\"><tr><td><form method=\"post\" action=\"saledit.php\" name=\"frmSalEdit\" 
	onsubmit=\"return validateFormOnSubmit(this)\"><table cellpadding=4 cellspacing=0 border=0><tr bgcolor=\"#eeeeee\"><th colspan=\"6\">Salary For $nam ($desi) ID No. $id</th></tr>";
	print "<tr><td align=\"right\">Basic Salary</td><td><input name=\"TxtBSal\" id=\"TxtBSal\" type=\"text\" size=\"10\" maxlength=\"10\" value=\"".number_format($bsal,2)."\" 
	style=\"text-align:right\" onkeyup=\"checkInput(this)\" onChange=\"Compute()\"></td><td align=\"right\">Salary For</td><td>$act[1]-$act[2]<input type=\"hidden\" name=\"TxtInfo\" 
	value=\"$act[0]-$act[1]-$act[2]\"></td><td align=\"right\">Pay point</td><td><input name=\"TxtPP\" id=\"TxtPP\" type=\"Text\" size=\"30\" maxlength=\"32\" value=\"$pp\"></td></tr>
	<tr><th colspan=\"6\"><table cellpadding=4 cellspacing=0 border=1 bordercolor=\"#dddddd\" align=\"center\">";
	print "<tr bgcolor=\"#eeeeee\" style=\"word-spacing:3px;letter-spacing:2px;\"><td Colspan=\"2\">MONTH'S SALARY ALLOWANCES</td><td Colspan=\"2\">SALARY DEDUCTIONS</td></tr>";
	print "<tr><td align=\"right\">Housing Allowance</td><td><input name=\"TxtHousing\" id=\"TxtHousing\" size=\"10\" maxlength=\"10\" type=\"text\" onkeyup=\"checkInput(this)\" 
	style=\"text-align:right;\" value=\"".number_format($hou,2)."\" onChange=\"Compute()\"></td><td align=\"right\">N . S . S . F</td><td><input name=\"TxtNSSF\" id=\"TxtNSSF\" 
	size=\"10\" maxlength=\"10\" value=\"".number_format($nss,2)."\" type=\"text\" onkeyup=\"checkInput(this)\" onChange=\"Compute()\" style=\"text-align:right;\"></td></tr>";
	print "<tr><td align=\"right\">Medical Allowance</td><td><input name=\"TxtMedical\" id=\"TxtMedical\" size=\"10\" maxlength=\"10\" type=\"text\" onkeyup=\"checkInput(this)\" 
	style=\"text-align:right;\" value=\"".number_format($med,2)."\" onChange=\"Compute()\"></td><td align=\"right\">N . H . I . F</td><td><input name=\"TxtNHIF\" id=\"TxtNHIF\" 
	size=\"10\" maxlength=\"10\" value=\"".number_format($nhi,2)."\" type=\"text\" onkeyup=\"checkInput(this)\" onChange=\"Compute()\" style=\"text-align:right;\"></td></tr>";
	print "<tr><td align=\"right\">Commuter Allowance</td><td><input name=\"TxtCommuter\" id=\"TxtCommuter\" size=\"10\" maxlength=\"10\" type=\"text\" onkeyup=\"checkInput(this)\" 
	style=\"text-align:right;\" value=\"".number_format($trav,2)."\" onChange=\"Compute()\"></td><td align=\"right\">S.A.C.C.O</td><td><input name=\"TxtSACCO\" id=\"TxtSACCO\" 
	size=\"10\" maxlength=\"10\" value=\"".number_format($sac,2)."\" type=\"text\" onkeyup=\"checkInput(this)\" style=\"text-align:right;\" onChange=\"Compute()\"></td></tr>";
	print "<tr><td align=\"right\">Employer NSSF Contribution</td><td><input name=\"TxtEmpNSSF\" id=\"TxtEmpNSSF\" size=\"10\" maxlength=\"10\" type=\"text\" onkeyup=\"checkInput(this)\" 
	style=\"text-align:right;\" value=\"".number_format($empn,2)."\"></td><td align=\"right\">Welfare</td><td><input name=\"TxtWelfare\" id=\"TxtWelfare\" size=\"10\" maxlength=\"10\" 
	value=\"".number_format($wel,2)."\" type=\"text\" onkeyup=\"checkInput(this)\" style=\"text-align:right;\" onChange=\"Compute()\"></td></tr>";
	print "<tr><td rowspan=\"4\" colspan=\"2\"></td><td align=\"right\">Union Fee</td><td><input name=\"TxtUnion\" id=\"TxtUnion\" size=\"10\" maxlength=\"10\" type=\"text\" 
	onkeyup=\"checkInput(this)\" style=\"text-align:right;\" value=\"".number_format($uni,2)."\" onChange=\"Compute()\"></td></tr>";
	print "<tr><td align=\"right\">Salary Advance</td><td><input name=\"TxtAdvance\" id=\"TxtAdvance\" size=\"10\" value=\"".number_format($adv,2)."\" maxlength=\"10\" type=\"text\" 
	onkeyup=\"checkInput(this)\" style=\"text-align:right\" onChange=\"Compute()\"></td></tr>";
	print "<tr><td align=\"right\" valign=\"top\">Payable PAYE</td><td><input name=\"TxtPAYE\" id=\"TxtPAYE\" size=\"10\" value=\"".number_format($paye,2)."\" maxlength=\"10\" type=\"text\" 
	onkeyup=\"checkInput(this)\" style=\"text-align:right\" onChange=\"Compute()\"> MPR <input name=\"TxtMPR\" id=\"TxtMPR\" size=\"8\" value=\"".number_format($mpr,2)."\" maxlength=\"7\" 
	type=\"text\" onChange=\"Compute()\" onkeyup=\"checkInput(this)\" style=\"text-align:right\"><br><br><span style=\"background-color:#dddddd;font-weight:bold;text-align:right\">PAYE 
	Auto<input type=\"text\" name=\"TxtPayeAuto\" id=\"TxtPayeAuto\" size=\"8\" disabled value=\"".number_format(($paye-$mpr),2)."\" style=\"text-align:right;background-color:#dddddd;\">
	</span></td></tr>";
	print "<tr><td align=\"right\">Other Deductions</td><td><input name=\"TxtOle\" id=\"TxtOle\" size=\"10\" value=\"".number_format($adv,2)."\" maxlength=\"10\" type=\"text\" 
	onkeyup=\"checkInput(this)\" style=\"text-align:right\" onChange=\"Compute()\"></td></tr>";
	print "</table></td></tr><tr><td colspan=6><hr></td></tr>";
	print "<tr><td align=\"right\"><b>Gross Salary</b></td><td><input name=\"TxtGS\" id=\"TxtGS\" size=\"10\" type=\"text\" disabled style=\"text-align:right;font-weight:bold;
	background-color:#eeeeee;\" value=\"".number_format($gs,2)."\"></td><td align=\"right\"><b>Total Deductions</b></td><td><input name=\"TxtDed\" id=\"TxtDed\" size=\"10\" maxlength=\"10\" 
	type=\"text\" style=\"text-align:right;font-weight:bold;background-color:#eeeeee;\" disabled value=\"".number_format($tded,2)."\"></td><td align=\"right\"><b>Net Salary</b></td><td>
	<input name=\"TxtNS\" id=\"TxtNS\" size=\"10\" type=\"text\" disabled style=\"text-align:right;font-weight:bold;background-color:#eeeeee;\" value=\"".number_format($ns,2)."\"></td></tr>
	<tr><td colspan=6><hr></td></tr>";
	print "<tr><td colspan=2 align=\"center\"><button name=\"CmdSave\" type=\"submit\">Save the Salary Changes</button></td><td colspan=2 align=\"right\"><button name=\"CmdDel\" 
	type=\"submit\">Delete this Salary</button></td><td colspan=2 align=\"center\"><a href=\"payroll.php\"><button name=\"CmdClose\" type=\"button\">Cancel and Close</button></a>
	</td></table></form></td></tr></table>";
?>
</body></html>