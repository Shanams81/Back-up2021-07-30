<?php
	include_once('shanam.php');
	if (isset($_POST['CmdSave'])){
		$admno=isset($_POST['txtAdmNo'])?sanitize($_POST['txtAdmNo']):Null; 		$county=isset($_POST['cboCounty'])?sanitize($_POST['cboCounty']):'001';
		$admno=((strcasecmp($admno,"auto")==0)||(strlen($admno)==0))?Null:$admno;	$lvl=isset($_POST['cboLevel'])?strtoupper(sanitize($_POST['cboLevel'])):'';
		$birthno=isset($_POST['txtBirthNo'])?trim(strip_tags($_POST['txtBirthNo'])):'xxxxx'; $mp=isset($_POST['cboConst'])?sanitize($_POST['cboConst']):'001';
		$dob=$_POST['cboYr']."-".$_POST['cboMon']."-".$_POST['cboDays']; 			$acyr=isset($_POST['cboAcYr'])?trim(strip_tags($_POST['cboAcYr'])):date('Y');
		$surname=isset($_POST['txtSurname'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtSurname']))):'';  $mca=isset($_POST['cboWard'])?sanitize($_POST['cboWard']):'0001';
		$onames=isset($_POST['txtONames'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtONames']))):'';
		$admda=isset($_POST['dtpAdmDate'])?sanitize($_POST['dtpAdmDate']):date('d-m-Y'); $admda=preg_split("/\-/",$admda);  	$admdate=$admda[2].'-'.$admda[1].'-'.$admda[0];
		$form=isset($_POST['cboForm'])?strtoupper(sanitize($_POST['cboForm'])):''; 	$strm=isset($_POST['cboStream'])?strtoupper(sanitize($_POST['cboStream'])):'';
		$guard=isset($_POST['txtGuardian'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtGuardian']))):'';
		$relation=isset($_POST['cboRelation'])?strtoupper(sanitize($_POST['cboRelation'])):'FATHER';	$occup=isset($_POST['cboOccup'])?strtoupper(sanitize($_POST['cboOccup'])):'TEACHER';
		$address=isset($_POST['txtPAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPAddress']))):Null;
		$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):Null; $locat=isset($_POST['txtLocation'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtLocation']))):'';
		$sublocat=isset($_POST['txtSubLocation'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtSubLocation']))):''; $regdon=date("Y-m-d H:n:s");
		$village=isset($_POST['txtVillage'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtVillage']))):'';	$un=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		$illness=isset($_POST['txtIllness'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtIllness']))):'None';$illness=strlen($illness)<5?'None':$illness;
		$allergy=isset($_POST['txtAllergy'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAllergy']))):'None';$allergy=strlen($allergy)<5?'None':$allergy;
		$nemis=isset($_POST['txtNEMISNo'])?strtoupper(sanitize($_POST['txtNEMISNo'])):Null;	 $nemis=is_null($nemis)?null:preg_replace('/[^a-zA-Z0-9]/g','',$nemis);
		if(strlen($surname)<3 || strlen($onames)<5 || strlen($form)==0|| strlen($strm)==0 || strlen($lvl)==0 || strlen($county)==0 || strlen($mp)==0 || strlen($mca)==0 || strlen($guard)<8){
			print "SERVER ERROR <font color=\"#cc0000\">Ensure student's names, guardian's names, class/form, county, constituency, location, sub-location and village fields are validly
			entered before trying to saving</font>";			exit(0);
		}else{
			mysqli_autocommit($conn,FALSE);
			if ((strlen($admno)==0)||(strcasecmp($admno,"auto")==0)){
				if (mysqli_query($conn,"INSERT INTO stud (admno,nemisno,surname,onames,address,telno,guardian,relation,admdate,dob,addedby,curr_year,regdon,countyno,constituencyno,wardno,
				location,sublocation,village,illness,alergies,occupation,birthcertno) VALUES (NULL,".var_export($nemis,true).",'$surname','$onames','$address','$telno','$guard','$relation',
				'$admdate','$dob','$un','$acyr','$regdon','$county','$mp','$mca','$locat','$sublocat','$village','$illness','$allergy','$occup','$birthno')")===TRUE){
					//$admno=mysqli_insert_id($conn);
					mysqli_multi_query($conn,"INSERT INTO class (admno,curr_year,clsno,stream,lvlno) VALUES (LAST_INSERT_ID(),'$acyr','$form','$strm','$lvl'); INSERT IGNORE INTO clsfee
					(admno,curr_year,voteno,t1,t2,t3) SELECT LAST_INSERT_ID(),$acyr,voteno,t1,t2,t3 FROM acc_feestruct WHERE lvlno LIKE '$lvl' and yr LIKE '$acyr';") or
					die(mysqli_error($conn)." Student of Admission No. $admno form's details were not saved. Click <a href=\"student.php?action=0-0\">HERE</a> to go back.");
					while(mysqli_next_result($conn)){}			$i=1;
				}
				if (!mysqli_commit($conn)){}
			}else{
				if (mysqli_query($conn,"INSERT INTO stud (admno,nemisno,surname,onames,address,telno,guardian,relation,admdate,dob,constituencyno,addedby,curr_year,regdon,countyno,wardno,
				location,sublocation,village,illness,alergies,occupation,birthcertno) VALUES ('$admno',".var_export($nemis,true).",'$surname','$onames','$address','$telno','$guard',
				'$relation','$admdate','$dob','$mp','$un','$acyr','$regdon','$county','$wardno','$locat','$sublocat','$village','$illness','$allergy','$occup','$birthno')")===TRUE){
				 	mysqli_multi_query($conn,"INSERT INTO Class (admno,curr_year,clsno,stream,lvlno) VALUES ('$admno','$acyr','$form','$strm','$lvl'); INSERT IGNORE INTO clsfee (admno,
					curr_year,voteno,t1,t2,t3) SELECT $admno,$acyr,voteno,t1,t2,t3 FROM acc_feestruct WHERE lvlno LIKE '$lvl' and yr LIKE '$acyr';") or die(mysqli_error($conn)." Student
					Form details were not successfully saved. Click <a href=\"student.php?action=0-0\">HERE</a> to go back."); while(mysqli_next_result($conn)){}
					$i=1;
				}
				if (!mysqli_commit($conn)){}
			}
			header("location:student.php?action=1-$i");	exit(0);
		}
	}
	headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css" /><link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css"/>',0,0,2);
	mysqli_multi_query($conn,"select county,constituency,ward FROM `ss`;SELECT code,name FROM county ORDER BY name ASC; SELECT code,name,codecounty FROM constituency ORDER BY codecounty,
	name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC;"); $i=0; $optCounty=$optMP=$optMCA='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){
				if (mysqli_num_rows($rs)>0)	list($gov,$const,$ward)=mysqli_fetch_row($rs);else{	$gov='001';		$mp='001';	$mca='0001';}
			}if($i==1) while (list($s,$n)=mysqli_fetch_row($rs)) $optCounty.="<option ".($gov==$s?"selected":"")." value=\"$s\">$n</option>";
			elseif($i==2){ $mp=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
				$mp.=($a==0?"":",")."new Consti(\"$s\",\"$n\",\"$c\")"; if($gov==$c) $optMP.="<option ".($const==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
			}else{ $mca=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
	   			$mca.=($a==0?"":",")."new MCA(\"$s\",\"$n\",\"$c\")"; if($c==$const) $optMCA.="<option ".($ward==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
	  		}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
?>
<br><form method="post" action="studadd.php" onsubmit="return validateFormOnSubmit(this);">
<div class="container" style="width:fit-content;background-color:#e6e6f6;"><div class="divheadings">STUDENT REGISTRATION	INTERFACE</div>
	<ul class="nav nav-tabs" id="myTabs">
	    <li class="nav-item active"><a class="nav-link active" data-toggle="tab" id="details-tab" href="#details">Student Details</a></li>
	    <li class="nav-item"><a class="nav-link" data-toggle="tab" id="other-tab" href="#other">Other Details</a></li>
	</ul>
	<div class="tab-content" id="myTabContent">
	    <div id="details" class="tab-pane fade show active" role="tabpanel" aria-labelledby="details-tab">
			<div class="form-row">
				<div class="col-md-3"><label for="txtAdmNo">Admission No. </label><input type="text" name="txtAdmNo" id="txtAdmNo" maxlength="5" value="" placeholder="Auto generated"
					class="modalinput"></div>
				<div class="col-md-2"><label for="txtNEMISNo">NEMIS No. </label><input type="text" name="txtNEMISNo" id="txtNEMISNo" maxlength="5" value="" placeholder="A0001"
					class="modalinput"></div>
				<div class="col-md-3"><label for="txtBirthNo">Birth Certificate No.</label><Input type="text" name="txtBirthNo" id="txtBirthNo" maxlength="10" value="" placeholder="0000000"
					class="modalinput"></div>
				<div class="col-md-4"><label for="cboYr">Date of Birth</label><div class="controls form-inline"><SELECT name="cboYr" size="1" id="cboYr" onchange="filldays('cboDays')"
					class="col-md-4 modalinput"><?php $a=(date('Y')-2); for($i=$a; $i>($a-20);$i--) print "<option>$i</option>"; ?></SELECT>-<SELECT name="cboMon" size="1" id="cboMon"
					class="col-md-4 modalinput" onchange="filldays('cboDays')"><OPTION value="01">Jan</OPTION><OPTION value="02">Feb</OPTION><OPTION value="03">Mar</OPTION><OPTION value="04">Apr
					</OPTION><OPTION value="05">May</OPTION><OPTION value="06">Jun</OPTION><OPTION value="07">Jul</OPTION><OPTION value="08">Aug</OPTION><OPTION value="09">Sep</OPTION><OPTION
					value="10">Oct</OPTION><OPTION	value="11">Nov</OPTION><OPTION value="12">Dec</OPTION></SELECT>-<SELECT name="cboDays" size="1" id="cboDays" class="col-md-3 modalinput"><?php
					$a=date('t',strtotime($a.'-01-01')); $b=date("d");	for($i=$a;$i>0;$i--) print "<option ".(($b==$i)?"selected":"").">$i</option>";?></SELECT></div></div>
			</div><div class="form-row">
				<div class="col-md-3"><label for="txtSurname">Surname *</label><input type="text" name="txtSurname" id="txtSurname" maxlength="12" value="" placeholder="Shanam" required
					class="modalinput"></div>
				<div class="col-md-7"><label for="txtONames">Other Names *</label><input type="text" name="txtONames" id="txtONames" value="" maxlength="30" placeholder="Shanam"
				 required class="modalinput"></div>
				<div class="col-md-2"><label for="dtpAdmDate">Admitted On *</label><input type="text" size="8" name="dtpAdmDate" class="tcal modalinput" <?php print "value=\"".
				date("d-m-Y")."\"";?> readonly></div>
			</div><br><div class="form-row">
				<div class="col-md-12 divsubheading">DETAILS OF STUDENT CLASS AND STREAM</div>
			</div><div class="form-row">
				<div class="col-md-3"><label for="cboLevel">Level *</level><SELECT name="cboLevel" id="cboLevel" size="4" onchange="loadClasses(this)" required class="modalinput">
				<?php
					mysqli_multi_query($conn,"SELECT lvlno,lvlname FROM classlvl ORDER BY lvlno; SELECT clsno,clsname FROM classnames WHERE lvlno LIKE '1' ORDER BY clsno; SELECT strm FROM
					grps WHERE strm is not null;") or die(mysqli_error($conn).' Error in database connection'); $i=0;
					do{
						if($rs=mysqli_store_result($conn)){
							if($i==0){
								if (mysqli_num_rows($rs)>0) while (list($lvl,$lvlname)=mysqli_fetch_row($rs)) echo "<option value=\"$lvl\" selected>$lvlname</option>";
								echo '</SELECT></div>';
							}elseif($i==1){
								print'<div class="col-md-3"><label for="cboForm">Class/ Form *</level><span id="clsNames"><SELECT name="cboForm" id="cboForm" size="4" required class="modalinput">';
								$a=0; if (mysqli_num_rows($rs)>0) while (list($cls,$clsname)=mysqli_fetch_row($rs)){
								 	echo "<option ".($a==0?"selected":"")." value=\"$cls\">$clsname</option>";	$a++;
								}echo '</SELECT></span></div>';
							}else{
								echo '<div class="col-md-3"><label for="cboStream">Stream *</level><SELECT name="cboStream" id="cboStream" size="4" required class="modalinput">';
								if (mysqli_num_rows($rs)>0) while (list($strm)=mysqli_fetch_row($rs)) echo "<option selected>$strm</option>";
								echo "</SELECT></div>";
							} mysqli_free_result($rs);
						} $i++;
					}while(mysqli_next_result($conn));
					print '<div class="col-md-3"><label for="cboAcYr">Academic Year</label><SELECT name="cboAcYr" id="cboAcYr" size="4" required class="modalinput">';	$i=date("Y");
					for ($a=$i;$a>($i-6);$a--) print "<option ".(($a==$i)?"selected":"").">$a</option>";
				?></SELECT></div>
			</div><div class="form-row"><br><div class="col-md-12 divsubheading">DETAIL OF THE GUARDIAN/PARENT</div>
			</div>
			<div class="form-row">
				<div class="col-md-7"><label for="txtGuardian">Name of Parent/Guardian *</label><input type="text" maxlength="30" name="txtGuardian" value="" placeholder="Were xxxxxx"
				style="text-transform:uppercase;" id="txtGuardian" required class="modalinput"></div>
				<div class="col-md-3"><label for="cboOccup">Occupation *</label><SELECT name="cboOccup" id="cboOccup" size="1" class="modalinput"><option>Accountant</option><option>
					Administrator</option><option>Banker</option><option>Businessman</option><option>Civil Servant</option><option>Doctor</option><option>Driver</option><option>Engineer
					</option><option selected>Farmer</option><option>Manager</option><option>Nurse</option><option>Politician</option><option>Secretary</option><option>Self Employed</option>
					<option>Teacher</option><option>Technician</option></select></div>
				<div class="col-md-2"><label for="cboRelation">Relationship</label><td><SELECT name="cboRelation" id="cboRelation" size="1" class="modalinput"><option selected>Father</option>
					<option>Mother</option><option>Brother</option><option>Sister</option><option>Uncle</option><option>Aunt</option><option>In-law</option><option>Other</option></SELECT></div>
			</div><div class="form-row">
				<div class="col-md-7"><label for="txtAddress">Postal Address</label><TEXTAREA rows="2" maxlength="35" name="txtPAddress" id="txtPAddress" class="modalinput">P.O Box </textarea></div>
				<div class="col-md-5"><label for="txtTelNo">Tel No.</label><input type="text" maxlength="13" name="txtTelNo" id="txtTelNo" value="" placeholder="0700000000" class="modalinput"></div>
			</div>
		</div>
		<div id="other" class="tab-pane fade" role="tabpanel" aria-labelledby="other-tab">
			<div class="form-row">
		    	<div class="col-md-4"><label for="cboCounty">Home County *</label><SELECT name="cboCounty" id="cboCounty" size="1" required onChange="loadConstituency(this)" class="modalinput">
				<?php echo $optCounty; ?></SELECT></div>
				<div class="col-md-4"><label for="cboConst">Constituency *</label><SELECT name="cboConst" id="cboConst" size="1" onChange="loadWards(this)" required class="modalinput"><?php
				echo $optMP; ?></SELECT></div>
				<div class="col-md-4"><label for="cboWard">County Ward *</label><SELECT name="cboWard" id="cboWard" size="1" required class="modalinput"><?php echo $optMCA; ?></SELECT></div>
		  	</div>
			<div class="form-row">
		    <div class="col-md-4"><label for="txtLocation">Home Location</label><input name="txtLocation" id="txtLocation" maxlength="25" type="text" value="XXXXXXXXX" class="modalinput"
				placeholder="Kholera"></div>
				<div class="col-md-4"><label for="txtSubLocation">Sub-Location</label><input type="text" name="txtSubLocation" id="txtSubLocation" maxlength="25" class="modalinput"
				value="XXXXXXXX" placeholder="Bulimbo"></div>
				<div class="col-md-4"><label for="txtVillage">Village/ Town</label><Input type="text" name="txtVillage" id="txtVillage" class="modalinput"	maxlength="25" value="XXXXXXXXXX"
					placeholder="Lukusi"></div>
			</div><br><div class="form-row"><div class="col-md-12 divsubheading">HISTORICAL ILLNESS OR ALLERGIES OF THE STUDENT</div></div>
			<div class="form-row">
		    	<div class="col-md-12"><label for="txtIllness">Illnesses</label><textarea name="txtIllness" id="txtIllness" rows="2" maxlength="80" class="modalinput">None</textarea></div>
			</div><div class="form-row">
		    	<div class="col-md-12"><label for="txtAllergy">Allergies</label><textarea name="txtAllergy" id="txtAllergy" cols="100" rows="2" maxlength="80" class="modalinput">None</textarea>
					</div>
			</div></div>
		</div><br><div class="form-row">
			<div class="col-md-6"><button type="submit" name="CmdSave" id="save" class="btn btn-md btn-block btn-primary">Save Student Details</button></div>
			<div class="col-md-6" style="text-align:right;"><button class="btn btn-info btn-md" onclick="window.open('student.php','_self')" type="button" name="CmdClose">Cancel/Close
			</button></div><br>.
		</div>
</div></form>
<?php
	if(isset($mp) && strlen($mp)>0){
		echo '<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/iebc.js"></script><script type="text/javascript"
		src="tpl/js/studadd.js"></script><script type="text/javascript">var mp=['.$mp.'];';
		if(strlen($mca)>0) echo 'var mca=['.$mca.'];';
		echo '</script>';
	}	mysqli_close($conn); footer();
?>
