<?php
	include_once('shanam.php');
	$rs=mysqli_query($conn,"SELECT accadd,accedit,accdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$add=0; $edit=0; $del=0; if (mysqli_num_rows($rs)>0) list($add,$edit,$del)=mysqli_fetch_row($rs);	$act="0-0";
	$sno=isset($_REQUEST['sno'])?sanitize($_REQUEST['sno']):'0-0'; 	$sno=preg_split('/\-/',$sno);
	$from=isset($_REQUEST['from'])?sanitize($_REQUEST['from']):0;
	class Accounts{
		private $sno,$name,$type,$acc,$acabbr,$acno,$date,$bankno,$bank,$branch,$fa;
		public function __construct($sn,$na,$ty,$ac,$aa,$an,$da,$bn,$ba,$br,$f){$this->sno=$sn; $this->name=$na; $this->type=strtolower($ty); $this->acc=$ac; $this->acabbr=$aa;
		$this->acno=$an;$this->bankno=$bn;$this->date=$da; $this->bank=$ba; $this->branch=$br; $this->fa=$f;}	public function __destruct(){}
		public function valSNo(){return $this->sno;}		public function valName(){return $this->name;}			public function valType(){return $this->type;}
		public function valAcc(){return $this->acc;}		public function valAcAbbr(){return $this->acabbr;}	public function valACNo(){return $this->acno;}
		public function valDate(){return $this->date;}	public function valBank(){return $this->bank;}			public function valBranch(){return $this->branch;}
		public function valFA(){return $this->fa;}			public function valBankNo(){return $this->bankno;}
	}class Banks{
		private $sno,$abbr,$descr,$addr,$tel,$code,$swift;
		public function __construct($s,$a,$d,$ad,$te,$co,$sw){$this->sno=$s;$this->abbr=$a;$this->descr=$d;$this->addr=$ad;$this->tel=$te;$this->code=$co;$this->swift=$sw;}
		public function valSNo(){return $this->sno;}			public function valAbbr(){return $this->abbr;}	public function valDescr(){return $this->descr;}
		public function valRegd(){return $this->regdon;}	public function valAddr(){return $this->addr;}	public function valTel(){return $this->tel;}
		public function valCode(){return $this->code;}		public function valSwift(){return $this->swift;}
	}
	if (isset($_POST['cmdSave']) || isset($_POST['btnSaveEdit0'])){
		if (isset($_POST['cmdSave'])){
			$tkn=isset($_POST["txtTknAcc"])?sanitize($_POST["txtTknAcc"]):0;
			$name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName']))):"";
			$type=isset($_POST['cboType'])?strtoupper(sanitize($_POST['cboType'])):"";	$fee=isset($_POST['chkFA'])?sanitize($_POST['chkFA']):0;
			$acc=isset($_POST['cboAcc'])?sanitize($_POST['cboAcc']):0; 		$acno=isset($_POST['txtAC'])?sanitize($_POST['txtAC']):"";
			$date=strip_tags($_POST['txtDate']); 					$bank=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;
			$branch=isset($_POST['txtBranch'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBranch']))):""; $date=preg_split('/\-/',$date);
			$sql="INSERT INTO acc_accounts(sno,acctype,accname,accacc,accno,accdate,bankno,branch,fa) VALUES (0,'$type',".var_export($name,true).",'$acc','$acno',
			'$date[2]-$date[1]-$date[0]','$bank',".var_export($branch,true).",'$fee')";
		}else{
			$tkn=isset($_POST["txtTknAcc1"])?sanitize($_POST["txtTknAcc1"]):0;
			$name=isset($_POST['txtName1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName1']))):"";
			$type=isset($_POST['cboType1'])?strtoupper(sanitize($_POST['cboType1'])):"";	$sno=sanitize($_POST['txtSNo1']);
			$acc=isset($_POST['cboAcc1'])?sanitize($_POST['cboAcc1']):0; 		$acno=isset($_POST['txtAC1'])?trim(strip_tags($_POST['txtAC1'])):"";
			$date=sanitize($_POST['txtDate1']); 					$bank=isset($_POST['cboBank1'])?sanitize($_POST['cboBank1']):0;
			$branch=isset($_POST['txtBranch1'])?strtoupper(sanitize($_POST['txtBranch1'])):""; $date=preg_split('/\-/',$date);
			$fee=isset($_POST['chkFA1'])?sanitize($_POST['chkFA1']):0;
			$sql="UPDATE acc_accounts SET acctype='$type',accname='$name', accacc='$acc', accno='$acno', accdate='$date[2]-$date[1]-$date[0]', bankno='$bank',
			branch='$branch', fa='$fee' WHERE sno LIKE '$sno'";
		}
		if ($_SESSION['accsTkn']!==$tkn || strlen($name)<10 || $acc==0 || strlen($acno)==0 || $bank==0 || strlen($branch)==0 || strlen($type)==0){
			print "<h4 style=\"color:#f00;text-align:center;letter-spacing:2px;word-spacing:4px;\">You must enter valid account details before saving.</h4>";
			$act="1-0";
		}else{
			mysqli_query($conn,$sql) or die(mysqli_error($conn). ". Bank Account detail were not saved. Click <a href=\"accounts.php\">here</a> to go try again.");
			$act="1-".mysqli_affected_rows($conn);
		}unset($_SESSION['accsTkn']);
	}elseif(isset($_POST['btnSaveBank']) || isset($_POST['btnSaveEditBank'])){
		if(isset($_POST['btnSaveBank'])){//new
			$tkn=isset($_POST["txtTknBank"])?sanitize($_POST["txtTknBank"]):0;
			$sno=0; $name=isset($_POST['txtBankName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankName']))):"";
			$abbr=isset($_POST['txtBankAbbr'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankAbbr']))):"";
			$address=isset($_POST['txtBankAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankAddress']))):""; 	$address=strlen($address)>0?$address:null;
			$telno=isset($_POST['txtBankTel'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankTel']))):"";						$telno=strlen($telno)>0?$telno:null;
			$code=isset($_POST['txtBankCode'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankCode']))):"";						$code=strlen($code)>0?$code:null;
			$swift=isset($_POST['txtBankSwift'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankSwift']))):"";				$swift=strlen($swift)>0?$swift:null;
			$sql="INSERT INTO acc_banks(sno,abbr,descr,regdon,paddress,telno,bankcode,swiftcode) VALUES (0,".var_export($abbr,true).",".var_export($name,true).",curdate(),".
			var_export($address,true).",".var_export($telno,true).",".var_export($code,true).",".var_export($swift,true).")";
		}else{//edit
			$tkn=isset($_POST["txtTknBank1"])?sanitize($_POST["txtTknBank1"]):0;
			$sno=isset($_POST['txtBSNo1'])?sanitize($_POST['txtBSNo1']):0;
			$name=isset($_POST['txtBankName1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankName1']))):"";
			$abbr=isset($_POST['txtBankAbbr1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankAbbr1']))):"";
			$address=isset($_POST['txtBankAddress1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankAddress1']))):""; 	$address=strlen($address)>0?$address:null;
			$telno=isset($_POST['txtBankTel1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankTel1']))):"";						$telno=strlen($telno)>0?$telno:null;
			$code=isset($_POST['txtBankCode1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankCode1']))):"";						$code=strlen($code)>0?$code:null;
			$swift=isset($_POST['txtBankSwift1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtBankSwift1']))):"";				$swift=strlen($swift)>0?$swift:null;
			$sql="UPDATE acc_banks SET abbr=".var_export($abbr,true).",descr=".var_export($name,true).",paddress=".var_export($address,true).",telno=".var_export($telno,true).
			",bankcode=".var_export($code,true).",swiftcode=".var_export($swift,true)." WHERE sno LIKE '$sno'";
		}if ($_SESSION['accsTkn']!==$tkn || strlen($name)<10 || strlen($abbr)<2){
			print "<h4 style=\"color:#f00;text-align:center;letter-spacing:2px;word-spacing:4px;\">You must enter valid Bank details before saving.</h4>";
			$act="1-0";
		}else{
			mysqli_query($conn,$sql) or die(mysqli_error($conn). ".New bank detail were not saved. Click <a href=\"accounts.php\">here</a> to go try again.");
			$act="1-".mysqli_affected_rows($conn);
		} unset($_SESSION['accsTkn']);
	}elseif($sno[0]==1|| $sno[0]==2){//delete
		if ($sno[0]==1) $sql="UPDATE acc_accounts SET markdel=0 WHERE sno LIKE '$sno[1]'"; else $sql="UPDATE acc_banks SET markdel=0 WHERE sno LIKE '$sno[1]'";
		mysqli_query($conn,$sql);	$act="2-".mysqli_affected_rows($conn);
	}
	mysqli_multi_query($conn,"SELECT sno,abbr,descr,paddress,telno,bankcode,swiftcode FROM acc_banks WHERE markdel=0 ORDER BY abbr ASC; SELECT a.sno,a.accname,a.acctype,a.accacc,
	v.abbr,a.accno,a.accdate,a.bankno,b.descr,a.branch,a.fa FROM acc_accounts a Inner Join acc_banks b On (a.bankno=b.sno) Inner Join acc_voteacs v On (a.accacc=v.acno) WHERE
	a.markdel=0 Order By a.sno ASC");
	$act=preg_split('/\-/',$act); $i=0; $tkn=$_SESSION['accsTkn']=uniqid();
	do{
		if($rs=mysqli_store_result($conn)){
			if ($i==0) while($data=mysqli_fetch_row($rs)) $banks[]=new Banks($data[0],$data[1],$data[2],$data[3],$data[4],$data[5],$data[6]);
			else while($data=mysqli_fetch_row($rs)) $accounts[]=new Accounts($data[0],$data[1],$data[2],$data[3],$data[4],$data[5],date("d-m-Y",strtotime($data[6])),$data[7],$data[8],
			$data[9],$data[10]);
			mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css" /><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet"
	href="tpl/css/inputsettings.css"/>',$act[0],$act[1],2);
?>
<div class="container" style="width:fit-content;"><div style="border:1px dashed #fff;border-radius:10px;background-color:#d6d6d6;padding:10px;max-width:950px;">
	<ul class="nav nav-tabs" id="myTabs">
	    <li class="nav-item active"><a class="nav-link active" data-toggle="tab" id="bank-tab" href="#Banks">LIST OF BANKS</a></li>
	    <li class="nav-item"><a class="nav-link" data-toggle="tab" id="accounts-tab" href="#Accounts">INSTITUTE ACCOUNTS</a></li>
	</ul>
	<div class="tab-content" id="myTabContent">
			<div id="Banks" class="tab-pane fade show active" role="tabpanel" aria-labelledby="bank-tab" style="border:0.2px dotted blue;border-radius:10px;padding:6px;">
				<div class="form-row"><div class="col-md-12">
					<div class="container" style="width:fit-content;max-width:700px;margin:5px auto;background-color:#ccebdd;border-radius:10px;"><FORM action="accounts.php" name="FrmBanks"
						Method="POST" onsubmit="return validateBanks(this)">
						<div class="form-row"><div class="col-md-12" style="color:#fff;word-spacing:4px;background:#444;letter-spacing:2px;font-size:13pt;font-weight:bold;text-align:center;">
								NEW BANK DETAILS</div><input name="txtTknBank" type="hidden" value="<?php echo $tkn;?>">
						</div><div class="form-row">
								<div class="col-md-9">
									<div class="form-row">
										<div class="col-md-6"><label for="txtBankAbbr">Bank Name (Abbreviation)* </label><Input name="txtBankAbbr" id="txtBankAbbr" type="text" value="" required
											maxlength=10 placeholder="KCB" class="modalinput"></div>
										<div class="col-md-6"><label for="txtBankSwift">Bank Swift Code *</label><Input name="txtBankSwift" id="txtBankSwift" type="text" value="" maxlength="15"
										placeholder="BCL000000" class="modalinput"></div>
									</div><div class="form-row">
										<div class="col-md-12"><label for="txtBankName">Bank Name (in Full)*</label><Input name="txtBankName" id="txtBankName" type="text" value="" required maxlength=50
											placeholder="Kenya Commercial Bank" class="modalinput"></div>
									</div><div class="form-row">
										<div class="col-md-12"><label for="txtBankAddress">Postal Address *</label><Input name="txtBankAddress" id="txtBankAdress" type="text" value="" maxlength="150"
											placeholder="P.O Box " class="modalinput"></div>
									</div><div class="form-row">
										<div class="col-md-6"><label for="txtBankTel">Telephone/ Mobile No. *</label><Input name="txtBankTel" id="txtBankTel" type="text" value="" maxlength="50"
										placeholder="+2547xxxxx" class="modalinput"></div>
										<div class="col-md-6"><label for="txtBankCode">Bank Code No. *</label><Input name="txtBankCode" id="txtBankCode" type="text" value="" maxlength="15"
										placeholder="2111000" class="modalinput"></div>
									</div>
								</div>
								<div class="col-md-3"><br><br><br><br>
									<div class="form-row"><div class="col-md-12"><button type="submit" name="btnSaveBank" <?php print($add==0?"disabled":"");?> class="btn btn-primary btn-md
										btn-block">Save Bank Details</button></div></div><br><br><br><br><br>
									<div class="form-row"><div class="col-md-12" style="text-align:right"><button type="button" name="btnClose" onclick="window.open('settings_manager.php','_self');"
										class="btn btn-info btn-md" >Close</button></div></div>
								</div>
						</div></form>
					</div></div>
				</div><div class="form-row">
					<div class="col-md-12" style="max-height:270px;overflow-y:scroll;"><table class="table table-hover table-bordered table-striped table-sm"><thead class="thead-dark"><tr><th
						colspan="8" style="word-spacing:6px;letter-spacing:4px;font-weight:bold;text-align:center;">LIST OF REGISTERED BANKS</th></tr><tr><th>#</th><th>SHORT NAME</th><th>FULL
						NAME</th><th>ADDRESS</th><th>TEL NO.</th><th>BANK CODE</th><th>SWIFT CODE</th><th>ACTION</th></tr></thead><tbody>
					<?php
						if (isset($banks)){ $i=1;
							foreach($banks as $b){ print "<tr><td>$i</td><td>".($b->valAbbr())."</td><td>".($b->valDescr())."</td><td>".($b->valAddr())."</td><td>".($b->valTel())."</td><td>".($b->valCode()).
							"</td><td>".($b->valSwift())."</td><td align=\"center\" class=\"n\">".($edit==1?"<a onclick=\"showModal(0,".($b->valSNo()).",$del)\" href=\"#\">Edit</a>":"-")."</td></tr>"; $i++;}
						}
					?></tbody></table>
			</div></div>
	</div>
	<div id="Accounts" class="tab-pane fade show" role="tabpanel" aria-labelledby="accounts-tab" style="border:0.2px dotted blue;border-radius:10px;background-color:#d6d6d6;
	padding:6px;">
		<div class="container">
			<div class="form-row">
				<div class="col-md-12">
						<div class="container" style="width:fit-content;max-width:700px;margin:5px auto;background-color:#ccebdd;border-radius:10px;"><FORM action="accounts.php" name="frmAccounts"
							method="POST" onsubmit="return validateFormOnSubmit(this)">
							<div class="form-row"><div class="col-md-12" style="color:#fff;word-spacing:4px;background:#444;letter-spacing:2px;font-size:13pt;font-weight:bold;text-align:center;">
									NEW BANK ACCOUNT DETAILS</div><input name="txtTknBank" type="hidden" value="<?php echo $tkn;?>">
							</div>
							<div class="form-row"><input name="txtTknAcc" type="hidden" value="<?php echo $tkn;?>">
								<div class="col-md-9">
									<div class="form-row"><div class="col-md-12"><label for="txtName">Account Name *</label><Input name="txtName" id="txtName" type="text" value="" class="modalinput"
										required maxlength=50></div>
									</div><div class="form-row">
										<div class="col-md-6"><label for="cboType">Type of Account *</label><SELECT size="1" name="cboType" id="cboType" required class="modalinput"><option selected>
										Current Account</option><option>Savings Account</option><option>Fixed Account</option></SELECT></div>
										<div class="col-md-6"><label for="cboType">Financial Account *</label><SELECT size=1 name="cboAcc" id="cboAcc" class="modalinput">
											<?php
												$rs=mysqli_query($conn,"SELECT acno, descr FROM acc_voteacs WHERE markdel=0 ORDER BY acno"); $optAcc="";
												while ($dat=mysqli_fetch_row($rs)) $optAcc.="<option value=\"$dat[0]\">$dat[1]</option>"; mysqli_free_result($rs);  print "$optAcc</SELECT>";
											?></div>
									</div><div class="form-row">
										<div class="col-md-6"><label for="txtAC">Account No.</label><Input name="txtAC" id="txtAC" type="text" value="" maxlength=15 class="modalinput" required
										onkeyup="checkInput(this)"></div>
										<div class="col-md-6"><label for="txtDate">A/C Opened On</label><Input name="txtDate" id="txtDate" type="text" value="<?php echo date("d-m-Y");?>" maxlength="10"
										class="tcal modalinput" readonly></div>
									</div><div class="form-row">
										<div class="col-md-6"><label for="cboBank">Name of Bank *</label><SELECT name="cboBank" id="cboBank" size=1 class="modalinput"><?php echo $optBanks='';
										foreach($banks as $b) $optBanks.="<option value=\"".$b->valSNo()."\">".$b->valDescr()."</option>"; print "$optBanks</SELECT>";
										?></div>
										<div class="col-md-6"><label for="txtBranch">Bank Branch * </label><Input name="txtBranch" id="txtBranch" type="text" value="" maxlength=30 class="modalinput">
										</div>
									</div><div class="form-row">
										<div class="col-md-12"><label class="checkbox-inline">Fees Payable through A/C <input type="checkbox" value=1 name="chkFA" id="chkFA">Yes</label></div>
									</div>
								</div><div class="col-md-3">
									<br><br>
									<div class="form-row"><div class="col-md-12"><button type="submit" name="cmdSave" <?php echo ($add==0?"disabled":"");?> class="btn btn-primary btn-md btn-block">
										Save A/C Details</button></div></div><br><br>
									<div class="form-row"><div class="col-md-12" style="text-align:right"><button type="button" name="btnClose" class="btn btn-info btn-md"
										onclick="window.open(<?php echo $from==0?"'withdrawborrow.php'":"'settings_manager.php'";?>,'_self');">Close</button></div></div>
								</div>
						</div></form></div>
						<div class="form-row">
								<div class="col-md-12" style="overflow-y:scroll;max-height:250px;">
								<table class="table table-striped table-hover table-sm"><thead class="thead-dark"><tr><th colspan=8 style="word-spacing:6px;letter-spacing:4px;text-align:center;">
								LIST OF INSTITUTE'S	BANK ACCOUNTS</th></tr><tr><th>ACCOUNT NAME</th><th>A/C TYPE</th><th>FINANCIAL A/C</th><th>BANK DETAILS</th><th>A/C NO.</th><th nowrap>FEE A/C</th>
								<th>ACTION</th></tr></thead><tbody>
									<?php
										if (isset($accounts)){
											foreach($accounts as $acc) print "<tr><td class=\"n\">".($acc->valName())."</td><td class=\"n\">".strtoupper($acc->valType())."</td><td class=\"n\">".
											($acc->valAcAbbr())."</td><td class=\"n\">".($acc->valBank())." - ".($acc->valBranch())."</td><td class=\"n\">".($acc->valACNo())."</td><td class=\"n\"
											align=\"center\">".($acc->valFA()==1?"&#x2611; Yes":"&#x274c; No")."</td><td align=\"center\" class=\"n\">".($edit==1?"<a onclick=\"showModal(1,".
											($acc->valSNo()).",$del)\" href=\"#\">Edit</a>":"-")."</td></tr>";
										}
									?></tbody></table>
						</div>
				</div>
		</div>
	</div></div>
</div>
<div id="bankEdit" class="modal">
	<FORM action="accounts.php" name="frmBankEdit" Method="POST" onsubmit="return validateBanks1(this)">
	<div class="imgcontainer"><span onclick="document.getElementById('bankEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
	<div class="container divmodalmain"><input name="txtTknBank1" type="hidden" value="<?php echo $tkn;?>">
		<div class="form-row">
				<div class="col-md-12" style="word-spacing:4px;letter-spacing:2px;text-align:center;">BANK DETAIL EDITOR<input name="txtBSNo1" id="txtBSNo1" type="hidden" value=""></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="txtBankAbbr1">Bank Name (Abbreviation)*</label><Input name="txtBankAbbr1" id="txtBankAbbr1" type="text" value="" class="modalinput" required
			maxlength="10" placeholder="KCB"></div>
			<div class="col-md-6"><label for="txtBankAbbr1">Bank Swift Code *</label><Input name="txtBankSwift1" id="txtBankSwift1" type="text" value="" class="modalinput" maxlength="15"
			placeholder="BCL000000"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtBankName1">Bank Name (in Full) *</label><Input name="txtBankName1" id="txtBankName1" type="text" value="" class="modalinput" required
			maxlength="50" placeholder="KCB"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtBankAdress1">Postal Address *</label><Input name="txtBankAddress1" id="txtBankAddress1" type="text" value="" class="modalinput"
				maxlength="150" placeholder="P.O Box "></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="txtBankTel1">Telephone/ Mobile No. *</label><Input name="txtBankTel1" id="txtBankTel1" type="text" value="" class="modalinput" maxlength="50"
				placeholder="+2547xxxxx"	onkeyup="checkInput(this)"></div>
			<div class="col-md-6"><label for="txtBankCode1">Bank Code No. *</label><Input name="txtBankCode1" id="txtBankCode1" type="text" value="" class="modalinput" maxlength="15"
				placeholder="2111000"></div>
		</div><div class="form-row">
			<div class="col-md-6"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSaveEditBank">Save Bank Changes</button></div>
			<div class="col-md-3" id="btnDeleteBank" style="text-align:center"></div>
			<div class="col-md-3" style="text-align:right;"><button type="button" onclick="document.getElementById('bankEdit').style.display='none'" class="cancelbtn">Cancel</button></div>
		</div>
	</div></form>
</div>
<div id="accountEdit" class="modal">
	<FORM action="accounts.php" name="FrmAdding" Method="POST" onsubmit="return validateFormOnSubmit1(this)">
	<div class="imgcontainer"><span onclick="document.getElementById('accountEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
	<div class="container divmodalmain"><input name="txtSNo1" id="txtSNo1" type="hidden" value="<?php print $act[0];?>">
		<div class="form-row"><input name="txtTknAcc1" type="hidden" value="<?php echo $tkn;?>">
			<div class="col-md-12" style="color:#fff;background-color:#333;word-spacing:4px;letter-spacing:2px;font-size:13pt;font-weight:bold;text-align:center;">BANK ACCOUNT EDITOR</div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtName1">Account Name *</label><Input name="txtName1" id="txtName1" type="text" value="" class="modalinput" required maxlength="50"></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="cboType1">Type of Account *</label><SELECT size="1" name="cboType1" id="cboType1" required class="modalinput"><option value="current">
			Current Account</option><option value="savings">Savings	Account</option><option value="fixed">Fixed Account</option></SELECT></div>
			<div class="col-md-6"><label for="cboAcc1">Financial Account *</label><SELECT size="1" name="cboAcc1" id="cboAcc1" required class="modalinput"><?php print $optAcc; ?></SELECT>
			</div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="txtAC1">Account No.*</label><Input name="txtAC1" id="txtAC1" type="text" maxlength="15" value="" required	onkeyup="checkInput(this)"
				class="modalinput"></div>
			<div class="col-md-6"><label for="txtDate1">A/C Opened On *</label><Input name="txtDate1" id="txtDate1" type="text" value="" maxlength="10" class="tcal modalinput" readonly>
			</div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="cboBank1">Name of Bank *</label><SELECT name="cboBank1" id="cboBank1" size=1 class="modalinput"><?php print $optBanks;?></select></div>
			<div class="col-md-6"><label for="cboBranch1">Bank Branch *</label><Input name="txtBranch1" id="txtBranch1" type="text" value="" maxlength="30" class="modalinput"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label class="checkbox-inline">Fee Payable Through A/C <input type="checkbox" value=1 name="chkFA1" id="chkFA1"> Yes</label></div>
		</div><hr><div class="form-row">
			<div class="col-md-6"><button type="submit" class="btn btn-primary btn-block btn-md" name="btnSaveEdit0">Save Changes</button></div>
			<div class="col-md-3" id="btnDelete" style="text-align:center"></div>
			<div class="col-md-3" style="text-align:right;"><button type="button" onclick="document.getElementById('accountEdit').style.display='none'" class="btn btn-info btn-md">
				Cancel/Close</button></div>
		</div>
	</div>
  </form>
</div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/accadd.js"></script>
<script type="text/javascript">
	<?php
		if (isset($accounts)){$arr=""; $i=0;
			foreach($accounts as $acc){$arr.=($i==0?"":",")."new Accounts(".($acc->valSNo()).",\"".($acc->valName())."\",\"".($acc->valType())."\",".($acc->valAcc()).",\"".
			($acc->valACNo())."\",\"".($acc->valDate())."\",".($acc->valBankNo()).",\"".($acc->valBranch())."\",".($acc->valFA()).")"; $i++;
			}if (strlen($arr)>0) print "accounts.push($arr);";
		}if (isset($banks)){$arr=""; $i=0;
			foreach($banks as $b){$arr.=($i==0?"":",")."new Banks(".($b->valSNo()).",\"".($b->valAbbr())."\",\"".($b->valDescr())."\",\"".($b->valAddr())."\",\"".($b->valTel())."\",\"".
			($b->valCode())."\",\"".($b->valSwift())."\")"; $i++;
			}if (strlen($arr)>0) print "banks.push($arr);";
		}
	?>
</script>
<?php mysqli_close($conn);	footer();?>
