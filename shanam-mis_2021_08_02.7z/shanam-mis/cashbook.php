<?php
	include_once('shanam.php');
	headings('<link rel="stylesheet" href="/date/tcal.css" /><link rel="stylesheet"  href="tpl/css/inputsettings.css" /><link href="tpl/css/spinner.css" rel="stylesheet" /><link href="tpl/css/modalfrm.css"
  rel="stylesheet" />',0,0,2);
?>
<form method="post" action="pytrpts.php">
<div class="container" style="background-color:#eee;margin:70px auto;border-radius:10px;padding:5px;width:30%"><div class="form-row"><div class="col-md-12 divheadings">ACCOUNTS CASHBOOK REPORTS</div></div>
  <div class="form-row"><div class="col-md-8">
    <div class="form-row">
      <div class="col-md-6"><label for="txtStart">Starting From</label><input type="text" name="txtStart" id="txtStart" class="modalinput tcal" value="<?php echo date('d-m-Y',strtotime('-30days'));?>"
        readonly></div>
      <div class="col-md-6"><label for="txtEnd">Ending On</label><input type="text" name="txtEnd" id="txtEnd" class="modalinput tcal" value="<?php echo date('d-m-Y');?>" readonly></div>
    </div><div class="form-row">
      <div class="col-md-12"><label for="cboAC">Account Payment Incurred</label><select class="modalinput" name="cboAC" id="cboAC" size="3">
        <?php $rs=mysqli_query($conn,"SELECT acno,descr FROM acc_voteacs WHERE pyt_assoc=1 ORDER BY acno ASC"); while($d=mysqli_fetch_row($rs)) echo "<option value=\"$d[0]\">$d[1]</option>"; mysqli_free_result($rs);?>
      </select></div>
    </div>
  </div><div class="col-md-4">
    <div class="form-row"><div class="col-md-12"><button type="button" name="btnShow" id="btnShow" class="btn btn-md btn-primary btn-block" onclick="showReport(0)">Show Cashbook</button></div></div><br>
		<div class="form-row"><div class="col-md-12"><button type="button" name="btnShow" id="btnShow" class="btn btn-md btn-primary btn-block" onclick="showReport(1)">Export Cashbook<br>To MS Excel</button></div></div><br>
    <div class="form-row"><div class="col-md-12"><button type="button" name="btnClose" id="btnClose" class="btn btn-md btn-info btn-block" onclick="winClose()">Close</button></div></div>
  </div></div>
</div></form>
<div id="busyWait" class="modal"  onclick="document.querySelector('#busyWait').style.display='none'"><div class="loader"></div></div>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript">
  function showReport(opt){let st=document.querySelector("#txtStart").value,en=document.querySelector("#txtEnd").value,ac=parseFloat(document.querySelector("#cboAC").value);
		if(ac>0){st=st.split('-'); st=st[2]+'-'+st[1]+'-'+st[0]; en=en.split('-'); en=en[2]+'-'+en[1]+'-'+en[0];
	    if(opt==0) window.open('rpts/cashbook.php?r='+ac+'~'+st+'~'+en,'_blank');  else window.open('xls/xlscashbook.php?r='+ac+'~'+st+'~'+en,'_blank');
			document.querySelector('#busyWait').style.display='block';
		}else{alert('Select Account whose cashbook is to be viewed.');}
  }function winClose(){window.open('home.php','_self');}
</script>
<?php mysqli_close($conn); footer(); ?>
