<?php
	session_start();
	if (!(isset($_SEESION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Balance Sheet</title>
		<link href="tpl/acc.css" rel="stylesheet" type="text/css"/>
    </head>
<body background="../gen_img/bg3.gif">
	<form method="post" action="balancesheet.php">
        &nbsp;<button type="submit" accesskey="s" name="main">Main A/C Balance Sheet</button>&nbsp;&nbsp;&nbsp;<button type="submit" 
		accesskey="s" name="tuition">Tuition A/C Balance Sheet</button>&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name=
		"operation">Operation A/C Balance Sheet</button>&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name="misc">Misc. A/C 
		Balance Sheet</button>
	</form>
	<?php
		if (isset($_POST["main"]))
    		$h="Main Account Balance Sheet";
    	elseif (isset($_POST["tuition"]))
    		$h="Tuition Account Balance Sheet";
    	elseif (isset($_POST["operation"]))
    		$h="Operation Account Balance Sheet";
    	elseif (isset($_POST["misc"]))
    		$h="Miscellaneous Account ";
    	else
    		$h="Balance Sheet Manual";
		print "<h2>".strtoupper($h." As On ".date("D d-M-Y"))."</h2></center><hr>";
	?>
</body>
</html>
<?php
if (isset($_POST["main"])):
	
elseif (isset($_POST["tuition"])):
	
elseif (isset($_POST["operation"])):
	
elseif (isset($_POST["misc"])):
	
else:
	print "<p class=\"g\">Sorry, This web page is under construction.</p>";
endif;
mysqli_close($conn);
?>