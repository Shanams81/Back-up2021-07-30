<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['admno'])?$_REQUEST['admno']:"0-0-0"; $act=preg_split('/\-/',$act); $yr=date('Y');
    mysqli_multi_query($conn,"SELECT struview,struadd,struedit,strudel,uniadd FROM acc_priv Where Uname LIKE '".$_SESSION['username']."'; SELECT finyr FROM ss;");
    $vie=0; $add=0; $edi=0; $del=0; $finyr=date('Y'); $i=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if ($i==0) list($vie,$add,$edi,$del,$uniadd)=mysqli_fetch_row($rs);
            else list($finyr)=mysqli_fetch_row($rs);
            mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
    if($vie==0) {header("location:vague.php"); exit(0);}
    if(isset($_POST['btnNewOrder'])){ //new uniform purchase order
        $vote=isset($_POST['txtVote'])?sanitize($_POST['txtVote']):'0-0-0'; $vote=preg_split('/\-/',$vote); //[0]-Financial Year, [1]- Votehead and [2]-Account
        $admno=isset($_POST['txtAdmNo'])?sanitize($_POST['txtAdmNo']):0;    $user=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
        mysqli_query($conn,"INSERT INTO unifrmpurchase(purchno,admno,purchasedon,acc,voteno,addedby) VALUE (0,'$admno',curdate(),$vote[2],$vote[1],'$user')");
        $act[1]=mysqli_affected_rows($conn);  if($act[1]>0)  $orderno=mysqli_insert_id($conn); else $orderno=0;
    }elseif (isset($_POST['cmdAddUniItem'])){
        $orderno=isset($_POST['txtPurchNo'])?sanitize($_POST['txtPurchNo']):0;          $date=isset($_POST['txtPurchDate'])?sanitize($_POST['txtPurchDate']):date('Y-m-d');
        $unifrm=isset($_POST['cboUnifrm'])?sanitize($_POST['cboUnifrm']):0;		$qty=isset($_POST['txtQty'])?sanitize($_POST['txtQty']):0;
        $date=preg_split('/\-/',$date); $qty=preg_replace("/[^0-9^\.]/","",$qty);	$admno=isset($_POST['txtAdmNoUni'])?sanitize($_POST['txtAdmNoUni']):0;
        $admno=preg_split('/\-/',$admno); //[0] - Adm No, [1] - Vote No, [2] - Accounts
        if ($unifrm>0 && $qty>0 && $admno[0]>0){
            if (mysqli_query($conn,"INSERT INTO unipurchdetails (purchno,unifrmno,purchdate,curr_year,qty) VALUES ('$orderno','$unifrm','$date[2]-$date[1]-$date[0]','$finyr','$qty')")
            or die(mysqli_error($conn)." uniform details not added. Click <a href=\"unifrmpurch.php?admno=$orderno-1\">here</a> to go back.")){
                $act[1]=mysqli_affected_rows($conn);
                if ($act[1]>0){//if uniform details were updated
                    $rs=mysqli_query($conn,"SELECT amt FROM uniforms WHERE unifrmno LIKE '$unifrm';"); $amt=0;
                    if (mysqli_num_rows($rs)>0) list($amt)=mysqli_fetch_row($rs); mysqli_free_result($rs);
                    $ttl=$amt*$qty; //uniform purchase amount to be updated.
                    //@mysqli_query($conn,"UPDATE clsfee SET t1=t1+$ttl WHERE admno LIKE '$admno[0]' and voteno LIKE '$admno[1]';");
                    @mysqli_query($conn,"UPDATE class SET unifrm=unifrm+$ttl WHERE admno LIKE '$admno[0]' and curr_year LIKE '$finyr';");
                }
            }
        }else{
            print "<font size=\"+2\" color=\"#f00\">Ensure uniform description and unit price are validly entered before saving</font>";
            $act[1]=0;
        }
        $act[0]=1;
    }elseif(isset($_POST['cmdSaveEdit'])){
        $datano=isset($_POST['txtUniAmt'])?sanitize($_POST['txtUniAmt']):'0-0-0';   $datano=preg_Split('/\-/',$datano);//[0]-AdmNo, [1]-VoteNo, [2]-Acc
        $purchno=isset($_POST['txtPurchNo1'])?sanitize($_POST['txtPurchNo1']):0;    $uni=isset($_POST['cboUnifrm1'])?sanitize($_POST['cboUnifrm1']):0;
        $qty=isset($_POST['txtQty1'])?sanitize($_POST['txtQty1']):0;                $orig=isset($_POST['txtInfo1'])?sanitize($_POST['txtInfo1']):'0-0-0';
        $orig=preg_split('/\-/',$orig); //Original [0]- purchase No., [1] - Uniform purchased and [2] quantity
        $orderno=$orig[0];  $ttl=0;
        if (($uni!=$orig[1] || $qty!=$orig[2])){//there is a change in either uniform or quantity purchased
            $sql='UPDATE unipurchdetails SET purchno='.$purchno.',qty='.$qty.',unifrmno='.$uni.' WHERE purchno='.$orig[0].' and unifrmno='.$orig[1].';';
            $ok=false;//only true if uniform amt does make uniform balance of a student negative
            if ($uni==$orig[1] && $qty!=$orig[2]) {
                $rs=mysqli_query($conn,"SELECT amt FROM uniforms WHERE unifrmno LIKE '$orig[1]'"); $amt=0;
                if (mysqli_num_rows($rs)>0) list($amt)=mysqli_fetch_row($rs); mysqli_free_result($rs);
                $ttl=($qty-$orig[2])*$amt;
            }else{
                mysqli_multi_query($conn,"SELECT amt FROM uniforms WHERE unifrmno LIKE '$orig[1]'; SELECT amt FROM uniforms WHERE unifrmno LIKE '$uni';");
                $i=0;   $oriamt=0;    $curamt=0;
                do{
                    if($rs=mysqli_store_result($conn)){
                        if($i==0) list($oriamt)=mysqli_fetch_row($rs);
                        else list($curamt)=mysqli_fetch_row($rs);
                        mysqli_free_result($rs);
                    }$i++;
                }while(mysqli_next_result($conn));
                $ttl=($qty*$curamt)-($orig[2]*$oriamt);
            }
            if ($ttl!=0){
                $ok=true; //$sql.='UPDATE clsFee SET t1=t1+'.$ttl.' WHERE admno='.$datano[0].' and curr_year='.$finyr.' and voteno LIKE '.$datano[1].';';
                $sql.='UPDATE class SET unifrm=unifrm+'.$ttl.' WHERE admno='.$datano[0].' and curr_year='.$finyr.';'; //update form
            }if ($ok){
                mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"uniform.php\">HERE</a> to go back.");
                $act[1]=mysqli_affected_rows($conn); while (mysqli_next_result($conn)){}
            } else {print "<p style=\"color:#f00;font-size:12pt;font-style:bold;\">Sorry, uniform order changes were invalidated (will result in negative uniform balance). The
            student has paid part of the uniform charges.</p>"; $act[1]=0;}
        }$act[0]=1;
    }elseif (isset($_POST['CmdDel'])){
        $datano=isset($_POST['txtUniAmt'])?sanitize($_POST['txtUniAmt']):'0-0-0';   $datano=preg_Split('/\-/',$datano);//[0]-AdmNo, [1]-VoteNo, [2]-Acc
        $orig=isset($_POST['txtInfo1'])?sanitize($_POST['txtInfo1']):'0-0-0';       $orig=preg_split('/\-/',$orig); //Original [0]- purchase No., [1] - Uniform purchased and [2] quantity
        mysqli_multi_query($conn,"UPDATE unipurchdetails SET markdel=1 WHERE purchno='.$orig[0].' and unifrmno='.$orig[1].'; SELECT amt FROM uniforms WHERE unifrmno LIKE '$orig[1]';
        SELECT count(unifrmno) as nos FROM unipurchdetails GROUP BY markdel,purchno HAVING markdel=0 and purchno LIKE '$orig[1]';"); $i=$uniamt=$nou=$nodel=0;
        do{
            if($i==0){ $nodel=mysqli_affected_rows($conn);
            }else{
              if($rs=mysqli_store_result($conn)){
                if($i==1){if(mysqli_num_rows($rs)>0)list($uniamt)=mysqli_fetch_row($rs);} //Unit sale for uniform being deleted
                else{if(mysqli_num_rows($rs)>0)list($nou)=mysqli_fetch_row($rs);} //No. of uniforms in the order after delete
                mysqli_free_result($rs);
              }
            }$i++;
        }while(mysqli_next_result($conn));
        if($nodel>0){
          $uniamt*=$orig[2];
          $sql="UPDATE class SET unifrm=unifrm-$uniamt WHERE admno LIKE '$datano[0]' and curr_year LIKE '$finyr'; ";
          if($nou>0) $sql.="UPDATE unifrmpurchase SET markdel=1 WHERE purchno LIKE '$orig[0]';";
          mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"unifrmpurch.php?admno=0-0-$orig[0]\">HERE</a> to go back."); while(mysqli_next_result($conn)){}
        } $act[0]=2;    $act[1]=$nodel;   $orderno=$orig[0];
    }else $orderno=$act[2];
    $rsPD=mysqli_query($conn,"SELECT u.purchno,u.admno,concat(s.surname,' ',s.onames) as stud_names,concat(u.voteno,'-',u.acc) as vote,concat(cn.clsname,'-',c.stream) As cls,u.purchasedon,
    c.unifrm FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn On (c.clsno=cn.clsno) Inner Join unifrmpurchase u On (s.admno=u.admno) WHERE (u.purchno Like
    '$orderno' and u.markdel=0)");
    list($purchno,$admno,$name,$vote,$cls,$date,$unifrm)=mysqli_fetch_row($rsPD); 		mysqli_free_result($rsPD);
    headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css" /><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet"
    href="tpl/css/inputsettings.css" type="text/css"/>',$act[0],$act[1],1);
?>
<div class="container" style="margin:50px auto;border-radius:20px 20px 0 0;background-color:#e6e6f6;max-width:950px;"><div class="form-row"><div class="col-md-12" style="letter-spacing:4px;
word-spacing:6px;font-weight:bold;background:#555;color:#fff;">UNIFORM PURCHASE BY <?php echo $admno.' <u>'.$name.'</u> GRADE/FORM '.$cls;?></div></div>
<div class="form-row"><div class="col-md-4 divlrborder">
  <form action="unifrmpurch.php" name="Adding" Method="POST" onsubmit="return validateFormOnSubmit(this)">
  <div class="container">
  <div class="form-row"><div class="col-md-12 divsubheading">NEW UNIFORM PURCHASE</div></div><input type="hidden"  name="txtAdmNoUni" id="txtAdmNoUni" value="<?php echo "$admno-$vote";?>">
  <div class="form-row">
    <div class="col-md-6"><label for="txtPurchNo">Purchase No. *</label><input name="txtPurchNo" id="txtPurchNo" value="<?php echo $purchno;?>" readonly class="modalinput"></div>
    <div class="col-md-6" style="text-align:right"><label for="txtPurchDate">Purchased On *</label><input name="txtPurchDate" id="txtPurchDate"
    value="<?php echo date("d-m-Y",strtotime($date));?>"></div>
</div><div class="form-row"><div class="col-md-12"><label for="cboUnifrm">Uniform Description *</label><SELECT name="cboUnifrm" id="cboUnifrm" size="1" class="modalinput">
<?php
    mysqli_multi_query($conn,"SELECT unifrmno,uname FROM uniforms WHERE unifrmno NOT IN (SELECT unifrmno FROM unipurchdetails WHERE purchno LIKE '$purchno') and markdel=0 Order By uname ASC;"
    . "SELECT unifrmno,uname FROM uniforms WHERE markdel=0 Order By uname ASC;");
    $optUni=''; $i=0;
    do{
      if($rs=mysqli_store_result($conn)){
         if($i==0){
            while (list($unno,$uname)=mysqli_fetch_row($rs)) echo "<option value=\"$unno\">$uname</option>";
         }else{
            while (list($unno,$uname)=mysqli_fetch_row($rs)) $optUni.="<option value=\"$unno\">$uname</option>";
         } mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
    print '</SELECT></div>';
?>
</div><div class="form-row">
    <div class="col-md-12"><label for="txtQty">Quantity Purchased *</label><input type="text" name="txtQty" id="txtQty" maxlength="2" value="0" onkeyup="checkInput(this)"
    class="modalinput"><hr style="border:0;border-top:0.5px dotted #f55;"/><button name="cmdAddUniItem" <?php echo ($uniadd==1?" ":"disabled");?> class="btn btn-primary btn-md
    btn-block">Save Uniform Purchase<br>Details</button></div>
</div></div>
</form>
</div><div class="col-md-8 divlrborder">
<table class="table table-striped table-hover table-bordered"><thead class="thead-dark"><tr><th>S/No.</th><th>Uniform Description</th><th>Unit of Sale</th><th>Unit Price</th><th>
Quantity</th><th>Amount</th><th>Admin Action</th></tr></thead><tbody>
<?php
    $rsUni=mysqli_query($conn,"SELECT pd.purchno,pd.unifrmno,u.uname,u.unitsale,u.amt,pd.qty,(u.amt*pd.qty) as ttl FROM uniforms u Inner Join unipurchdetails pd USING (unifrmno)
    Inner Join unifrmpurchase up On (pd.purchno=up.purchno) WHERE up.purchno LIKE '$purchno' and up.markdel=0 and pd.markdel=0");
    $i=mysqli_num_rows($rsUni); $a=1; $ttl=0;   $lstUni='';
    while (list($purcno,$unino,$uniname,$unisale,$uniamt,$uniqty,$unittl)=mysqli_fetch_row($rsUni)){
        $lstUni.=($a==1?"":",")." new Uniform($purchno,$unino,$uniqty)";
        print "<tr><td>$a</td><td>$uniname</td><td>$unisale</td><td align=\"right\">".number_format($uniamt,2)."</td><td align=\"center\">$uniqty</td><td align=\"right\">"
        .number_format($unittl,2)."</td><td align=\"center\">".(($unifrm>0 && $edi==1)?"<a href=\"#\" onclick=\"editPurchDet($purchno,$unino)\">Edit</a>":"-")."</td></tr>";
        $a++;	$ttl+=$unittl;
    }
    print "</tbody><tfoot class=\"thead-light\"><tr><td colspan=\"3\" style=\"letter-spacing:3px;word-spacing:5px;\"><b>$i Uniform Item(s)</b></td><td align=\"right\" colspan=\"2\">
    <b>Total Uniform Amount</b></td><td align=\"right\">".number_format($ttl,2)."</td><td></td></tr></tfoot></table>";
    ?></div></div><hr style="border:0;border-top:0.5px dotted #f55;"/><div class="form-row"><div class="col-md-12" style="text-align:right"><a href="uniform.php"><button name="btnClose"
    type="button">Close Uniform Purchase</button></a></div></div>
</div>
<div id="divEditUP" class="modal">
    <form action="unifrmpurch.php" Method="Post" name="frmUnifrmEdit" onsubmit="return validateFormOnSubmit1(1,this)"><input name="txtUniAmt" id="txtUniAmt" type="hidden"
    value="<?php print $admno.'-'.$vote;?>"><input name="txtInfo1" id="txtInfo1" type="hidden" value="">
    <div class="imgcontainer"><span onclick="document.getElementById('divEditUP').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
    <div class="container divmodalmain" style="font-size:12pt;color:#fff;">Purchase No. *<br><input type="text" name="txtPurchNo1" id="txtPurchNo1" value="" readonly><br><br>Uniform
    Description *<br><SELECT name="cboUnifrm1" id="cboUnifrm1" size="1"><?php print $optUni; ?></select><br><br>Quantity Purchased *<br><input type="text" name="txtQty1"
    id="txtQty1" maxlength="2" value=""><input type="hidden" name="txtOrigQty1" id="txtOrigQty1" value=""><br>
    <br><button name="cmdSaveEdit" class="modBtn">Save Uniform</button><br><br><button type="submit" class="cancelbtn" name="btnDelete" <?php print ($del==0?"disabled":
    "onclick=\"return delConfirm()\"");?>>Delete Uniform</button>
    </div>
    <div class="container" style="text-align:right;"><button type="button" onclick="document.getElementById('divEditUP').style.display='none'" class="cancelbtn">Cancel</button></div>
</div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/unifrmpurch.js"></script>
<script type="text/javascript"><?php if(strlen($lstUni)>0) print "uniforms.push($lstUni);";?></script>
<?php mysqli_close($conn); footer();?>
