<?php
    include_once('shanam.php');
    $un=$_SESSION['username'];   $act=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $act=preg_split("/\-/",$act);
    mysqli_multi_query($conn,"SELECT deptview,deptadd,deptedit,deptdel FROM gen_priv Where Uname LIKE '$un';SELECT max(deptno) as mx FROM depts"); $i=$depno=$vie=$add=$edi=$del=0;
    do{
       if($rs=mysqli_store_result($conn)){
           if($i==0){if (mysqli_num_rows($rs)>0) list($vie,$add,$edi,$del)=mysqli_fetch_row($rs);}
           else{if (mysqli_num_rows($rs)>0) list($depno)=mysqli_fetch_row($rs);}
           mysqli_free_result($rs);
       } $i++;
    }while(mysqli_next_result($conn));
    if($vie==0) header("location:vague.php");
    if (isset($_POST['CmdAdd']) || isset($_POST['cmdsave'])){
        if(isset($_POST['CmdAdd'])){
          $depno=isset($_POST['txtDeptNo'])?sanitize($_POST['txtDeptNo']):0;    $depna=isset($_POST['txtDeptName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtDeptName']))):'';
          $depcat=isset($_POST['cboDeptCat'])?sanitize($_POST['cboDeptCat']):''; $abbr=isset($_POST['txtDeptAbbr'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtDeptAbbr']))):'';
          $hod=isset($_POST['cboHOD'])?sanitize($_POST['cboHOD']):0;
          $sql="INSERT INTO depts(deptno,deptname,hodno,abbr,deptcat) VALUES ('$depno','$depna','$hod','$abbr','$depcat')";
        }else{
          $depno=isset($_POST['txtDeptNo1'])?sanitize($_POST['txtDeptNo1']):0;    $depcat=isset($_POST['cboDeptCat1'])?sanitize($_POST['cboDeptCat1']):'';
          $depna=isset($_POST['txtDeptName1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtDeptName1']))):'';
          $abbr=isset($_POST['txtDeptAbbr1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtDeptAbbr1']))):'';
          $hod=isset($_POST['cboHOD1'])?sanitize($_POST['cboHOD1']):0;            $odepno=isset($_POST['txtInfo1'])?sanitize($_POST['txtInfo1']):0;
          $sql="UPDATE depts SET deptno='$depno',hodno='$hod',deptname='$depna',deptcat='$depcat',abbr='$abbr' WHERE deptno LIKE '$odepno'";
        }
        if ($depno>0 && strlen($depna)>5 && strlen($abbr)>2 && strlen($depcat)>5 && $hod>0){
            mysqli_query($conn,$sql) or die(mysqli_error($conn)." Department not added. Click <a href=\"depts.php\">here</a> to go back.");
            $act[0]=1;   $act[1]=mysqli_affected_rows($conn);
        }else{ echo "<h5 style=\"color:#f00;font-size:14pt;\">THE DATA CONTAINED ERRORS. DEPARTMENT DETAILS NOT SAVED.</h5>";  $act[0]=1;   $act[1]=0;}
    }
    headings('<link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet" href="tpl/css/inputsettings.css" type="text/css"/>',$act[0],$act[1],1); $depno++;
    $rsDept=mysqli_query($conn,"SELECT d.deptno,d.deptname,d.abbr,d.deptcat,d.hodno,concat(s.surname,' ',s.onames) as st_names  FROM depts d Inner Join
     stf s On d.hodno=s.idno WHERE d.markdel=0 Order By d.deptno ASC");
?>
<a href="stf_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a><div class="container" style="max-width:750px;margin:auto;"><div class="row">
<div class="col-md-12"><form Action="depts.php" name="Adding" Method="POST" onsubmit="return validateFormOnSubmit(this)"><div class="container" style="background-color:#eee;margin:auto;
border-radius:10px;padding:5px;width:fit-content;"><div class="form-row"><div class="col-md-12 mb-3" style="letter-spacing:8px;word-spacing:12px;text-weight:bold;font-size:14pt;font-weight:bold;text-align:center;text-decoration:underline
 overline double #fff;background:#000;color:#fff;">INSTITUTION'S DEPARTMENT MANAGER</div></div>
<div class="form-row">
    <div class="col-md-9 mb-3">
        <div class="form-row">
            <div class="col-md-6 mb-3"><label for="txtDeptNo">Department No. *</label><input type="text" name="txtDeptNo" id="txtDeptNo" value="<?php echo $depno;?>"
            maxlength="3" required></div>
            <div class="col-md-6 mb-3"><label for="cboDeptCat">Department Category *</label><Select name="cboDeptCat" id="cboDeptCat" size="1"><option selected>
            Academic</option><option>Administration</option><option>Support</option></select></div>
        </div><div class="form-row">
            <div class="col-md-8 mb-3"><label for="txtDeptName">Department Name *</label><input type="text" name="txtDeptName" id="txtDeptName" maxlength="35" value=""
            style="text-transform:uppercase;"></div>
            <div class="col-md-4 mb-3"><label for="txtDeptAbbr">Dept Abbreviation *</label><input name="txtDeptAbbr" id="txtDeptAbbr" type="text" maxlength="5"
            style="text-transform:uppercase;"></div>
        </div><div class="form-row">
            <div class="col-md-12 mb-3"><label for="cboHOD">Select the HOD *</label><Select name="cboHOD" id="cboHOD" size="1"><option value=0 selected>0 - Not Yet Set</option>
            <?php mysqli_multi_query($conn,"SELECT idno,concat(surname,' ',onames,' - ',designation) as st FROM stf WHERE (markdel=0 AND present=1 AND (idno Not In (SELECT hodno "
                . "FROM depts WHERE markdel=0))) ORDER BY surname,onames ASC; SELECT idno,concat(surname,' ',onames,' - ',designation) as st FROM stf WHERE markdel=0 AND present=1
                ORDER BY surname,onames ASC;"); $optHOD=''; $i=0;
                do{
                  if($rs=mysqli_store_result($conn)){
                    if($i==0){
                      while (list($tno,$nam)=mysqli_fetch_row($rs)) print "<option value=\"$tno\">$nam</option>";
                    }else{
                      while (list($tno,$nam)=mysqli_fetch_row($rs)) $optHOD.="<option value=\"$tno\">$nam</option>";
                    } mysqli_free_result($rs);
                  }$i++;
                }while(mysqli_next_result($conn));
            ?></select></div>
        </div>
    </div><div class="col-md-3 mb-3"><br><br><br><button type="submit" name="CmdAdd" <?php echo ($add==1?" ":"disabled");?> class="btn btn-primary btn-md btn-block">Save Department<br>
    Details</button></div>
</div></div></form></div></div>
<div class="row"><div class="col-md-12" style="background-color: #e6e6e6;">
<table class="table table-striped table-hover table-bordered table-sm" style="background-color:#D6D6D6;"><thead class="thead-dark"><tr><th>DEPT #</th><th>NAME</th><th>ABBREVIATION
</th><th>CATEGORY</th><th>HOD</th><th>ADMIN ACTION</th></tr></thead><tbody>
<?php $i=mysqli_num_rows($rsDept); $lstDept=''; $a=0;
    if ($i>0) while (list($deptno,$deptname,$abb,$cat,$hodno,$names)=mysqli_fetch_row($rsDept)){
       print "<tr><td>$deptno</td><td>$deptname</td><td>$abb</td><td>$cat</td><td>$names</td><td align=\"center\">".($edi==1?"<a onclick=\"findDept('$deptno')\" href=\"#\"><img
       src=\"../gen_img/edit.ico\" height=\"20\" width=\"25\" title=\"Edit\"></a> ":"-")."</td></tr>";
       $lstDept.=(($a==0?"":",")."new Dept($deptno,\"$deptname\",\"$abb\",\"$cat\",\"".(strlen($hodno)>0?$hodno:0)."\")"); $a++;
    }
?>
</tbody><tfoot><tr><td colspan="6" style="letter-spacing:6px;word-spacing:9px;"><?php echo $i; ?> Departments In The Institution</td></tr></tfoot></table></div></div>
<div class="row"><div class="col-md-12" style="text-align:right;"><a href="stf_manager.php?act=0-0"><button type="button" name="close" class="btn btn-info btn-md">Close Department Interface
</button></a></div></div>
</div>
<div id="divEditDept" class="modal">
	<form action="depts.php" Method="Post" name="frmDeptEdit" onsubmit="return validateFormOnSubmit1(this)"><input type="hidden" name='txtInfo1' id='txtInfo1' value="">
	<div class="imgcontainer"><span onclick="document.getElementById('divEditDept').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span>
	<h4 style="color:#fff;text-decoration:underline overline double #fff;word-spacing:5px;letter-spacing:3px;">EDITING OF DEPARTMENT DETAILS</h4></div>
	<div class="container divmodalmain">
      <div class="form-row">
          <div class="col-md-6 mb-3"><label for="txtDeptNo1">Department No. *</label><input type="text" name="txtDeptNo1" id="txtDeptNo1" value=""
          maxlength="3" required class="modalinput"></div>
          <div class="col-md-6 mb-3"><label for="cboDeptCat1">Department Category *</label><Select name="cboDeptCat1" id="cboDeptCat1" size="1" class="modalinput"><option value="Academic">
          Academic</option><option value="Administration">Administration</option><option value="Support">Support</option></select></div>
      </div><div class="form-row">
          <div class="col-md-8 mb-3"><label for="txtDeptName1">Department Name *</label><input type="text" name="txtDeptName1" id="txtDeptName1" maxlength="35" value=""
          class="modalinput"></div>
          <div class="col-md-4 mb-3"><label for="txtDeptAbbr1">Dept Abbreviation *</label><input name="txtDeptAbbr1" id="txtDeptAbbr1" type="text" maxlength="5" value=""
          class="modalinput"></div>
      </div><div class="form-row">
          <div class="col-md-12 mb-3"><label for="cboHOD1">Select the HOD *</label><Select name="cboHOD1" id="cboHOD1" size="1" class="modalinput"><option value="0">0 - Not Yet Set</option>
          <?php echo $optHOD;?></select><hr></div>
      </div><div class="form-row">
          <div class="col-md-5 mb-3"><button type="submit" name="cmdsave" class="btn btn-primary btn-md btn-block">Save Department Changes</button></div><div class="col-md-4 mb-3"
          style="text-align:right;"><button type="button" onclick="confirmDel(<?php echo $del;?>)" name="cmdDel" title="Delete Department" class="btn btn-warning btn-md"><img
          src="/gen_img/del.ico" height="20" width="25">Delete</button></div><div class="col-md-3 mb-3" style="text-align:right;"><button type="button" class="btn btn-info btn-md"
          onclick="document.getElementById('divEditDept').style.display='none'" name="cmdclose">Cancel/Close</button></div>
      </div>
	</div></form>
</div>
<script type="text/javascript" src="tpl/js/depts.js"></script>
<?php if(strlen($lstDept)>0) echo "<script type=\"text/javascript\">depts.push($lstDept);</script>"; mysqli_close($conn); footer(); ?>
