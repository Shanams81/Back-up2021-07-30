<?php
	session_start();
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0]-net salary,[1]- salary no and [2] random
	mysqli_multi_query($conn,"SELECT saladd,saledit,saldel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT staff from grps where staff is not null and staff not like '' 
	Order By staff ASC;SELECT scnm,scadd FROM ss; SELECT concat(sal_month,' - ',sal_year) as mon FROM acc_salaries WHERE salno LIKE '$data[1]';"); $i=0; $optStf='';
	do{
		if ($rs=mysqli_store_result($conn)){
			if ($i==0) list($saladd,$saledit,$saldel)=mysqli_fetch_row($rs);
			elseif($i==1) while ($stf=mysqli_fetch_row($rs)) $optStf.='<option value=\"'.$stf[0].'\">'.$stf[0].'</option>';
			elseif($i==2) $sch=mysqli_fetch_row($rs); else $sper=mysqli_fetch_row($rs);
		}$i++; mysqli_free_result($rs);
	}while (mysqli_next_result($conn)); $i=0;
	echo '<html><head><title>Payroll</title><style>table,td,th{border:0.5px solid blue;font-size:10px;background:inherit;padding:1px;}table{border-collapse:collapse;}
	table.h,td.h,th.h{border:0px;font-size:12px;text-align:left;}button.p{width:content-fit;height:60px;font-size:14pt;font-weight:bold;border:2px groove #ddd;border-radius:20px;}
	</style></head>';
	if ($data[0]>0){
		echo '<span style="background:white;border:0.5px dotted green;border-radius:10px 10px 10px 10px;padding:6px;display:block;width:auto;font-size:12px;height:25px;"><form method="post" 
		action="payroll.php" name="frmPayrollList">View <select name="cboGrp2" id="cboGrp2" size=1 onchange="viewLeanPayroll(0,this)"><option value="%">All Staff</option>';
		echo'</select> or Find Payroll By &nbsp;&nbsp;&nbsp;<input type="radio" name="radFind" id="radPFNo" value="payrollno" onclick="clrText()" checked>PF No.&nbsp;<input type="radio" 
		name="radFind" id="radIDNo" value="idno" onclick="clrText()">ID No.&nbsp;<input type="radio" name="radFind" id="radNames" value="names" onclick="clrText()">Names &nbsp;&nbsp;&nbsp;
		<input type="text" maxlength="13" size="20" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Search for a Payroll" title="Type what to find">&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</form></span>';
		$rs=mysqli_query($conn,"SELECT sp.payrollno,s.idno,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.paypoint,sp.bsalary,(sp.housingallow1+sp.medicalallow1+sp.travelallow1+
		responsallow1+sp.empnssf) as allow,(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1) AS GSal,(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-
		sp.mpr1)+sp.otherlevies1+sp.union1+sp.empnssf+sp.sacco1+sp.welfare1) AS TtlDed,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1)-
		(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1)) AS NetSal FROM Stf s INNER JOIN acc_saldef USING (idno) Inner 
		Join Acc_SalPyt sp USING (payrollno) Where sp.salno LIKE '$data[1]' and sp.markdel=0 ORDER BY s.surname,s.onames ASC");	$gsal=0; $ded=0; $net=0; $nop=mysqli_num_rows($rs);
		echo '<table class="h"><tr><th rowspan=3 class="h"><img src="img/logo1.jpg" height=40 width=35></th><th class="h" colspan=2>'.$sch[0].'</th></tr><tr><th class="h" colspan=2>'.
		$sch[1].'</th></tr><tr><th class="h">'.strtoupper($sper[0]).' SALARY PAYROLL</TH><th class="h" align="right">Date: '.date("D d M, Y").'</th></tr><tr><td colspan=3 class="h">';
		echo '<table><tr><th>PFNO</th><th>ID NO</th><th>NAMES</th><th>DESIGNATION</th><th>PAYPOINT</th><th>BASIC SAL</th><th>ALLOWANCES</th><th>GROSS SAL</th><th>DEDUCTIONS</th><th>NET 
		SAL</th><th>ADMIN ACTION</th></tr>'; $ttl=array(0,0,0,0,0);
		while (list($pfno,$idno,$name,$des,$pp,$bsal,$all,$gsal,$ded,$net)=mysqli_fetch_row($rs)){
			echo '<tr><td>'.$pfno.'</td><td>'.$idno.'</td><td>'.$name.'</td><td>'.$des.'</td><td>'.$pp.'</td><td align="right">'.number_format($bsal,2).'</td><td align="right">'.
			number_format($all,2).'</td><td align="right">'.number_format($gsal,2).'</td><td align="right">'.number_format($ded,2).'</td><td align="right">'.number_format($net,2).'</td>
			<td align="center"><a onclick="return canEdit('.$saledit.')" href="processStaffSalaries.php?salno=1-'.$data[1].'-'.$pfno.'">Edit</a></td></tr>';
			$ttl[0]+=$bsal; 	$ttl[1]+=$all; 	$ttl[2]+=$gsal; 	$ttl[3]+=$ded; 	$ttl[4]+=$net;
		}
		echo '</table></td></tr></table>';
		echo '<p id="parTotals" style="text-align:left;font-weight:bold;">'.$nop.' Staff Salaries. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Basic Salary '.number_format($ttl[0],2).
		'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total Allowances '.number_format($ttl[1],2).'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gross Salary '.number_format($ttl[2],2).'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		Total Deductions '.number_format($ttl[3],2).'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Net Salary '.number_format($ttl[4],2).'.</p>';
	}else{
		echo '<center><a onclick="return canProcess('.$saladd.')" href="processStaffSalaries.php?salno=0-'.$data[1].'-0"><button name="btnProcessAll" id="btnNew" type="button" class="p">
		Process Staff Members\' Salary</button></a></center>'.$data[1];	
	}
	mysqli_close($conn);
?>