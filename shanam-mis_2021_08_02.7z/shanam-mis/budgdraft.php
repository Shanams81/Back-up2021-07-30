<?php
    include_once('shanam.php');
    $vot=isset($_REQUEST['cboVote'])?sanitize($_REQUEST['cboVote']):'%';         $acno=isset($_REQUEST['cboAccount'])?sanitize($_REQUEST['cboAccount']):1;
    $action=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0';	$action=preg_split("/\-/",$action);
    if (isset($_POST['cmdNew'])){
        $i=0;  $rs=mysqli_query($conn,"SELECT budgno FROM acc_budget WHERE markdel=0");  if(mysqli_num_rows($rs)>0) list($i)=mysqli_fetch_row($rs);   mysqli_free_result($rs);
        $aby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';  $bno=0;
        if($i>0){
            mysqli_multi_query($conn,"INSERT IGNORE INTO acc_budgetdraft(budgno,voteno,acc,budg_date,addedby) SELECT budgno,voteno,acc,budg_date,'$aby' as user FROM acc_budget WHERE
            markdel=0;INSERT IGNORE INTO acc_budgitemsdraft(sno,budgno,itmcode,prevqty,prevup,qty,up,markdel) SELECT 0,budgno,itmcode,prevqty,prevup,qty,up,0 FROM acc_budgitems WHERE
            markdel=0;SELECT max(budgno) as bno FROM acc_budgetdraft;"); $i=0;
            while (mysqli_next_result($conn)){if($rs=mysqli_store_result($conn)){if($i==1) list($bno)=mysqli_fetch_row($rs); mysqli_free_result($rs); }$i++; }
        }else{$bno=isset($_POST['txtBugNo'])?sanitize($_POST['txtBugNo']):0;}
        $sql="INSERT IGNORE INTO acc_budgetdraft(budgno,voteno,acc,budg_date,addedby) SELECT (@x:=@x+1) as bno,sno,acc,curdate() as bd,'$aby' FROM `acc_votes` v, (SELECT @x:=$bno)t
        WHERE (pyt_defined=1 and sno>6);";
        mysqli_query($conn,$sql) or die(mysqli_error($conn). "<br> Click <a href=\"budg.php\">HERE</a> to go back"); $action[1]=mysqli_affected_rows($conn); $action[0]=1;
    }
    mysqli_multi_query($conn,"SELECT budgview,budgedit,budgadd FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT finyr FROM ss; SELECT acno,descr FROM acc_voteacs
    WHERE markdel=0; SELECT sno,acc,descr FROM acc_votes WHERE sno>5 and pyt_defined=1 ORDER BY sno; SELECT max(budgno) as bno FROM acc_budgetdraft;");
    $viu=$edi=$add=$i=$maxBNo=0;   $yr=$finyr=date('Y');   $lstVotes=$optAcc=$acname=$optVotes=$votename="";
    do{
       if($rs=mysqli_store_result($conn)){
            if($i===0){list($viu,$edi,$add)=mysqli_fetch_row($rs);
            }elseif($i===1){list($finyr)=mysqli_fetch_row($rs);
            }elseif($i===2){$a=0;while(list($ac,$de)=mysqli_fetch_row($rs)){$optAcc.="<option value=\"$ac\" ".($ac===$acno?"Selected":"").">$de</option>";if($acno==$ac) $acname=$de; $a++; }
            }elseif($i==3){ $a=0;
                while (list($sno,$acc,$desc)=mysqli_fetch_row($rs)){$lstVotes.=($a==0?"":",")."new Votes($sno,$acc,\"$desc\")";
                  if($acc==$acno) $optVotes.="<option value=\"$sno\">$desc</option>";  if($vot==$sno) $votename=$desc;      $a++;
                }
            }else{if(mysqli_num_rows($rs)>0) list($maxBNo)=mysqli_fetch_row($rs);}
       } $i++;
    }while(mysqli_next_result($conn));
    if($viu==0) header("location:vague.php"); $yr=date('Y')+1;
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css"/>',$action[0],$action[1],2);
?><div class="head"><form method="post" action="budgdraft.php"><a href="goodsbudg.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;Budget for
<SELECT name="cboAccount" id="cboAccount" size="1" onchange="fillVotes('cboVote')"><?php echo $optAcc; ?></SELECT> - <SELECT name="cboVote" id="cboVote" size="1"><option value="%" selected>
All</option><?php echo $optVotes; ?></SELECT><input type="hidden" name="txtBugNo" value="<?php echo $maxBNo; ?>">&nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-warning btn-sm"
name="cmdView"><u>V</u>iew <?php echo $yr;?> Draft Budget</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button type="button" class="btn btn-warning btn-sm" name="cmdPrint" onclick="printBudget(1)">
Print <?php echo $yr;?> Draft Budget</button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-info btn-sm" name="cmdNew" id="cmdNew" <?php echo ($add==1?"":"disabled");?>>Refresh <?php echo $yr;?> Budget Voteheads
</button></form></div>
<div style="border-radius:20px 20px 0 0;background-color:#f6f6f6;width:fit-content;padding:3px 5px;margin:1px auto;">
    <h6 style="color:#00f;letter-spacing:2px;word-spacing:3px;"><?php echo strtoupper("$acname Account's $votename Budget As On ".date("D d-M-Y"));?></h6>
    <div style="overflow-y:scroll;max-height:650px;"><table class="table table-striped table-sm table-bordered table-responsive table-hover"><thead class="thead-dark"><tr><th colspan="3">
    ITEM DESCRIPTION</th><th colspan="3">FY<?php echo ($yr-1);?> ACTUALS</th><th colspan="3">FY<?php echo $yr;?> BUDGET ESTIMATES</th><th rowspan="2" colspan="2">ADMIN ACTION</th></tr>
    <tr><th>Votehead</th><th>Budget Item Description</th><th>Units</th><th>Quantity</th><th>Unit Cost</th><th>Amount</th><th>Quantity</th><th>Unit Cost</th><th>Amount</th></tr></thead>
    <tbody>
    <?php
    $rsBud=mysqli_query($conn,"SELECT b.budgno,b.voteno,b.acc,count(bi.sno) As NoRec,v.descr FROM acc_budgetdraft b Inner Join acc_votes v On (b.voteno=v.sno) LEFT JOIN acc_budgitemsdraft
    bi On (b.budgno=bi.budgno) GROUP BY b.budgno,v.descr,b.acc,b.voteno,b.markdel HAVING (b.markdel=0 AND b.acc LIKE '$acno' AND b.voteno LIKE '$vot') ORDER BY b.voteno Asc");
    $gttl=0;	$pgttl=0;
    if (mysqli_num_rows($rsBud)>0):
        while (list($bno,$vno,$ac,$noi,$vote)=mysqli_fetch_row($rsBud)):
            $noi=($noi==0?1:$noi);
            print "<tr><td rowspan=\"$noi\" valign=\"top\" style=\"font-weight:bold;font-size:0.8rem;\">$vote</td>";
            $rsBudDet=mysqli_query($conn,"SELECT b.sno,i.itemname,i.Units,b.prevqty,b.prevup,(b.prevqty*b.prevup) as pamt,b.Qty,b.Up,(b.qty*b.up) AS TtlAmt FROM acc_budgitemsdraft b Inner
            Join items i On (b.itmcode=i.itmcode) WHERE (b.markdel=0 AND b.budgno LIKE '$bno') ORDER BY itemname ASC;");
            $ttl=0; $pttl=0; $a=0;
            if (mysqli_num_rows($rsBudDet)>0){
                while ((list($sno,$itm,$uni,$pqty,$pup,$pamt,$qty,$up,$amt)=mysqli_fetch_row($rsBudDet))):
                    if ($a!=0) print "<tr>";
                    print "<td>$itm</td><td>$uni</td><td align=\"right\">".number_format($pqty,2)."</td><td align=\"right\">".number_format($pup,2)."</td><td align=\"right\"><b>".
                    number_format($pamt,2)."</b></td><td align=\"right\">".number_format($qty,2)."</td><td align=\"right\">".number_format($up,2)."</td><td align=\"right\"><b>".
                    number_format($amt,2)."</b></td><td align=\"center\">".($edi==1?"<a href=\"budgeteditdraft.php?action=$sno\">Edit Item</a>":"")."</td>";
                    if($a==0) print "<td align=\"center\" rowspan=\"$noi\">".($add==1?"<a href=\"budgetadddraft.php?action=$vno-$ac\">New Item</a>":"")."</td></tr>";
                    $a++;	$ttl+=$amt;	$pttl+=$pamt;
                endwhile;
            }else print "<td colspan=\"8\">No $acname ($vote) Budget Item has been defined</td>";
            if($a==0) print "<td align=\"center\" rowspan=\"$noi\">".($add==1?"<a href=\"budgetadddraft.php?action=$vno-$ac\">New Item</a>":"")."</td></tr>";
            mysqli_free_result($rsBudDet);	$gttl+=$ttl;	$pgttl+=$pttl;
        endwhile;
    else:
        print "<tr><td colspan=\"11\">No budget items defined for the $votename votehead</td></tr>";
    endif;
    ?>
  </tbody><tfoot class=<tr style="letter-spacing:2px;word-spacing:4px;font-size:13px;align:right;"><td colspan="3" align="right"><b>GRAND TOTAL AMOUNT (KSHS.)</b></td><td
  colspan="3" align="right"><b><?php echo number_format($pgttl,2);?></b></td><td colspan="3" align="right"><b><?php echo number_format($gttl,2);?></b></td><td align="right">
  </td></table></div>
</div>
<script type="text/javascript" src="tpl/js/budgview.js"></script>
<?php
    if(strlen($lstVotes)>0) echo "<script type=\"text/javascript\"> votes.push($lstVotes);</script>";
    mysqli_close($conn); footer();
?>
