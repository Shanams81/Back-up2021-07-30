<?php
	declare(strict_types=1);
	include_once('shanam.php');
	$action=isset($_REQUEST['act'])?$_REQUEST['act']:"0-0"; $action=preg_split('/\-/',$action); $vno=isset($_REQUEST['vno'])?$_REQUEST['vno']:0;
	$rs=mysqli_query($conn,"SELECT voteview,voteedit,voteadd,votedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'"); $view=0; $edit=0; $add=0; $delete=0;
	if (mysqli_num_rows($rs)>0) list($view,$edit,$add,$delete)=mysqli_fetch_row($rs);	mysqli_free_result($rs);
	if($view==0) header("location:vague.php");
	class Votes{
    private $vno,$abb,$des,$acc,$order,$fs,$stud,$other,$pyt,$prot,$lfn;
    public function __construct($n,$a,$d,$ac,$o,$f,$st,$ot,$p,$pr,$l){$this->vno=$n; $this->abb=$a; $this->des=$d; $this->acc=$ac; $this->fs=$f; $this->pyt=$p; $this->prot=$pr; $this->lfn=$l;
    $this->order=$o;	$this->stud=$st;	$this->other=$ot;}
    public function valVNo(){return $this->vno;}		public function valAbbr(){return $this->abb;}	public function valDes(){return $this->des;}
    public function valAcc(){return $this->acc;}		public function valFS(){return $this->fs;}		public function valPyt(){return $this->pyt;}
    public function valProt(){return $this->prot;}		public function valStud(){return $this->stud;}	public function valOther(){return $this->other;}
    public function valOrder(){return $this->order;} 	public function valLFN(){return $this->lfn;}  	public function __destruct(){}//release memory
	}class VoteAccs{
    private $vno,$des;
    public function __construct($n,$d){$this->vno=$n; $this->des=$d;}
    public function valVNo(){return $this->vno;}		public function valDes(){return $this->des;} 	public function __destruct(){}//release memory
	}
	if(isset($_POST['btnSaveEdit0'])){//adding editing votehead
    $sno=isset($_POST['txtNo1'])?sanitize($_POST['txtNo1']):'0-0'; 					$sno=preg_split('/\-/',$sno); //[0] 0 add 1 edit, [1] original voteno
    $abbr=isset($_POST['txtAbbr1'])?strtoupper(sanitize($_POST['txtAbbr1'])):''; 	$descr=isset($_POST['txtDescr1'])?strtoupper(sanitize($_POST['txtDescr1'])):'';
    $ac=isset($_POST['cboAccount1'])?sanitize($_POST['cboAccount1']):0;				$fs=isset($_POST['chkFee1'])?sanitize($_POST['chkFee1']):0;
    $pyt=isset($_POST['chkPyt1'])?sanitize($_POST['chkPyt1']):0;					$voteno=isset($_POST['txtVoteNo1'])?sanitize($_POST['txtVoteNo1']):0;
    $order=isset($_POST['txtOrder1'])?sanitize($_POST['txtOrder1']):0; 				$stud=isset($_POST['chkStud1'])?sanitize($_POST['chkStud1']):0;
    $other=isset($_POST['chkOtherInco1'])?sanitize($_POST['chkOtherInco1']):0;	$lfn=isset($_POST['txtLFN1'])?sanitize($_POST['txtLFN1']):'';  $lfn=strlen($lfn)>0?$lfn:null;
    if ($voteno>0 && strlen($abbr)>2 && strlen($descr)>4 && $ac>0 && $order>0){
        if ($sno[0]==0) $sql="INSERT INTO acc_votes(sno,lfn,abbr,descr,expabbr,expdescr,acc,fs_defined,stud_fee,other_inco,pyt_defined,orderno) VALUES($voteno,".var_export($lfn,true).",'$abbr','$descr','$abbr',
        '$descr',$ac,$fs,$stud,$other,$pyt,$order);";
        else $sql="UPDATE acc_votes SET sno=$voteno,lfn=".var_export($lfn,true).",abbr='$abbr',descr='$descr',expabbr='$abbr',expdescr='$descr',acc=$ac,fs_defined=$fs,stud_fee=$stud,other_inco=$other,
        pyt_defined=$pyt,orderno=$order WHERE sno LIKE '$sno[1]';";
        mysqli_query($conn,$sql) or die(mysqli_error($conn).". Votehead record not saved. Click <a href=\"votes.php\">HERE</a> to try again.");
        $action[1]=mysqli_affected_rows($conn);
    }else $action[1]=0; $action[0]=1;
	}elseif($vno>0){//deleting vvotehead
		mysqli_query($conn,"UPDATE acc_votes SET markdel=1 WHERE sno LIKE '$vno'") or die(mysqli_error($conn).". Votehead record not saved. Click <a href=\"votes.php\">HERE</a> to
		try again."); $action[1]=mysqli_affected_row($conn);	$action[0]=2;
	}
	mysqli_multi_query($conn,"SELECT sno,abbr,descr,acc,orderno,fs_defined,stud_fee,other_inco,pyt_defined,protected,lfn FROM acc_votes WHERE markdel=0 ORDER BY acc,orderno ASC; SELECT max(sno)
	as vno FROM acc_votes; SELECT acno,descr FROM acc_voteacs");
	$i=0;
	do{
		if ($rs=mysqli_store_result($conn)){
			if($i==0){$nv=mysqli_num_rows($rs); if ($nv>0) while($d=mysqli_fetch_row($rs)) $votes[]=new Votes($d[0],$d[1],$d[2],$d[3],$d[4],$d[5],$d[6],$d[7],$d[8],$d[9],$d[10]);}
			elseif($i==1){if(mysqli_num_rows($rs)>0) list($nvotno)=mysqli_fetch_row($rs); else $nvotno=0; $nvotno++;}
			else{$noacc=mysqli_num_rows($rs); if($noacc>0) while($acc=mysqli_fetch_row($rs)) $voteaccs[]=new VoteAccs($acc[0],$acc[1]);}
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet" href="tpl/css/inputsettings.css" type="text/css"/>',$action[0],$action[1],2);
?>
<div class="container divmain">
    <h4 style="font-size:12pt;color:#00f;letter-spacing:2px;word-spacing:4px;text-align:center;font-weight:bold;">VOTEHEADS IN RESPECTIVE ACCOUNT</h4>
    <ul class="nav nav-tabs" id="myTabs">
        <?php $i=1;	$optAcc=''; $counter=1;
            foreach ($voteaccs as $va){
                if($i%2==1){
                    echo "<li class=\"nav-item ".($counter==1?"active":"")."\"><a class=\"nav-link ".($counter==1?"active":"")."\" data-toggle=\"tab\" id=\"Page$counter-tab\"
                    href=\"#Page$counter\">PAGE $counter</a></li>"; $counter++;
                }$optAcc.="<option value=\"".$va->valVNo()."\">".$va->valDes()."</option>"; $i++;
            }
        ?>
    </ul><div class="tab-content" id="myTabContent">
<?php $index=1; $counter=1;
    foreach ($voteaccs as $va){
        if($index%2==1){
            print "<div id=\"Page$counter\" class=\"tab-pane fade show".($counter==1?" active":"")."\" role=\"tabpanel\" aria-labelledby=\"Page$counter-tab\"><div
            class=\"form-row\"><div class=\"col-md-6\" style=\"max-height:650px;overflow-y:scroll;\">"; $counter++;
        }else print "<div class=\"col-md-6\" style=\"max-height:650px;overflow-y:scroll;\">";
        print "<div class=\"form-row\"><div class=\"col-md-12\" style=\"background:#444;color:#fff;font-weight:bold;padding:4px;\">
        ".$va->valDes()."</div></div><div class=\"form-row\"><div class=\"col-md-12\"><table class=\"table table-striped table-sm table-hover table-bordered\"><thead class=\"thead-dark\"><tr><th
				title=\"Ledger Folio No.\">LFN</th><th title=\"Abbreviation of Votehead\">Abbrev</th><th title=\"Full Name of Votehead\">Name</th><th title=\"Fee Distribution Order No.\">Order</th><th
				title=\"Fees Structure Votehead\">F.S.V</th><th title=\"Votehead for Student Fee\">V.S.F</th><th title=\"Votehead for Other Incomes\">V.O.I</th><th title=\"Payment Votehead\">PV</th><th>Action</th></tr></thead>";
        if (isset($votes)){
            foreach($votes as $val) if($val->valAcc()==$va->valVNo()) print "<tr><td>".($val->valLFN())."</td><td>".($val->valAbbr())."</td><td>".($val->valDes())."</td><td align\"center\">".($val->valOrder()).
						"</td><td align=\"center\">".($val->valFS()==1?"&#x2611;":"&#x274c;")."</td><td align=\"center\">".($val->valStud()==1?"&#x2611;":"&#x274c;")."</td><td align=\"center\">".($val->valOther()==1?"&#x2611;":
						"&#x274c;")."</td><td align=\"center\">".($val->valPyt()==1?"&#x2611;":"&#x274c;")."</td><td align=\"center\">".($val->valProt()==0?"<span	onclick=\"showEdit(1,$edit,".$val->valAcc().",".$val->valVNo().
						",$delete)\" Title=\"Edit\" class=\"spedit\">&#x270d;</span>":"")."</td></tr>";
        }print "</table></div></div></div>".($index%2==0?"</div></div>":"");$index++;
    }
?></div><hr><div class="form-row"><div class="col-md-4"><buttton type="button" onclick="showEdit(0,<?php echo "$add,1,$nvotno,$delete";?>)" class="btn btn-primary btn-block btn-md" name="btnNewVote">&#x270d; New
	Votehead</button></div><div class="col-md-6"></div><div class="col-md-2" style="text-align:right"><button onclick="window.open('settings_manager.php','_self');" type="button" name="btnClose" class="btn btn-md
	btn-info">Close</button></div></div></div>
</div><div id="votesEdit" class="modal">
	<form name="frmVotes" method="post" action="votes.php"><input type="hidden" name="txtNo1" id="txtNo1" value="">
	<div class="imgcontainer"><span onclick="document.getElementById('votesEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
	<div class="container divmodalmain">
		<div class="form-row">
			<div class="col-md-4"><label for="txtVoteNo1">Votehead Serial No. *</label><input type="text" name="txtVoteNo1" id="txtVoteNo1" required readonly class="modalinput"  onkeyup="checkNumber(this)"></div>
			<div class="col-md-4"><label for="txtLFN1">Ledger Folio No. *</label><input type="text" name="txtLFN1" id="txtLFN1" class="modalinput" onkeyup="checkNumber(this)" maxlength="4"></div>
			<div class="col-md-4"><label for="txtOrder1">Fee Distribution No.*</label><input type="text" name="txtOrder1" id="txtOrder1" maxlength=11 required onkeyup="checkNumber(this)" class="modalinput"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtAbbr1">Votehead Abbreviation *</label><input type="text" name="txtAbbr1" id="txtAbbr1" maxlength=11 required onkeyup="checkValue(this)"
			class="modalinput"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtDescr1">Votehead Full Name *</label><input type="text" name="txtDescr1" id="txtDescr1" maxlength=40 required onkeyup="checkValue(this)"
			class="modalinput"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="cboAccount1">Account Costed*</label><select name="cboAccount1" id="cboAccount1" size=1 class="modalinput" required>
			<?php
				print $optAcc;
			?></select></div>
		</div><div class="form-row">
			<div class="col-md-12"><label class="checkbox-inline">Type of Votehead *<br> <input type="checkbox" name="chkFee1" id="chkFee1" value=1>Fee Structure&nbsp;&nbsp;&nbsp;<input
			type="checkbox" name="chkStud1" id="chkStud1" value=1>Student Fee Vote&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="chkOtherInco1" id="chkOtherInco1" value=1>Other
			Income Vote&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="chkPyt1" id="chkPyt1"	value=1>Payment Vote</label></div>
		</div><br><hr><br>
		<div class="form-row">
			<div class="col-md-6"><button type="submit" class="btn btn-primary btn-block btn-md" name="btnSaveEdit0">Save Changes</button></div>
			<div class="col-md-3" style="text-align:center;" id="spDelete"></div>
			<div class="col-md-3" style="text-align:right;"><button type="button" onclick="document.getElementById('votesEdit').style.display='none'" class="btn btn-info btn-md">Close
			</button></div>
		</div>
	</div></form>
</div>
<script type="text/javascript" src="tpl/js/votes.js"></script>
<script type="text/javascript">
<?php
	$dat="";
	if(isset($votes)){ $i=0;
		foreach($votes as $v){$dat.=($i==0?"":",")."new Votes(".$v->valVNo().",\"".$v->valLFN()."\",\"".$v->valAbbr()."\",\"".$v->valDes()."\",".$v->valAcc().",".$v->valOrder().",".$v->valFS().",".$v->valStud().",".
			$v->valOther().",".$v->valPyt().")"; $i++;}
	}if(strlen($dat)>0) print "votes.push($dat);";
?></script>
<?php mysqli_close($conn); footer(); ?>
