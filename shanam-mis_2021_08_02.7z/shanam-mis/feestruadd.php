<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['CmdSave'])){
	 	//capture data
		$feegrp=isset($_POST['CboFeeGrp'])?$_POST['CboFeeGrp']:Null; 			$lvl=isset($_POST['CboLvl'])?$_POST['CboLvl']:Null; $yr=date('Y');
		$tui1=isset($_POST['TxtTui1'])?strip_tags($_POST['TxtTui1']):0; 		$tui2=isset($_POST['TxtTui2'])?strip_tags($_POST['TxtTui2']):0;
		$tui3=isset($_POST['TxtTui3'])?strip_tags($_POST['TxtTui3']):0; 		$boa1=isset($_POST['TxtBoa1'])?strip_tags($_POST['TxtBoa1']):0;
		$boa2=isset($_POST['TxtBoa2'])?strip_tags($_POST['TxtBoa2']):0; 		$boa3=isset($_POST['TxtBoa3'])?strip_tags($_POST['TxtBoa3']):0;
		$act1=isset($_POST['TxtAct1'])?strip_tags($_POST['TxtAct1']):0; 		$act2=isset($_POST['TxtAct2'])?strip_tags($_POST['TxtAct2']):0;
		$act3=isset($_POST['TxtAct3'])?strip_tags($_POST['TxtAct3']):0;			$ltt1=isset($_POST['TxtLTT1'])?strip_tags($_POST['TxtLTT1']):0;
		$ltt2=isset($_POST['TxtLTT2'])?strip_tags($_POST['TxtLTT2']):0;			$ltt3=isset($_POST['TxtLTT3'])?strip_tags($_POST['TxtLTT3']):0;
		$rmi1=isset($_POST['TxtRMI1'])?strip_tags($_POST['TxtRMI1']):0; 		$rmi2=isset($_POST['TxtRMI2'])?strip_tags($_POST['TxtRMI2']):0;
		$rmi3=isset($_POST['TxtRMI3'])?strip_tags($_POST['TxtRMI3']):0;			$ewc1=isset($_POST['TxtEWC1'])?strip_tags($_POST['TxtEWC1']):0;
		$ewc2=isset($_POST['TxtEWC2'])?strip_tags($_POST['TxtEWC2']):0;			$ewc3=isset($_POST['TxtEWC3'])?strip_tags($_POST['TxtEWC3']):0;
		$exa1=isset($_POST['TxtExam1'])?strip_tags($_POST['TxtExam1']):0;		$exa2=isset($_POST['TxtExam2'])?strip_tags($_POST['TxtExam2']):0;
		$exa3=isset($_POST['TxtExam3'])?strip_tags($_POST['TxtExam3']):0;		$adm1=isset($_POST['TxtAdm1'])?strip_tags($_POST['TxtAdm1']):0;
		$adm2=isset($_POST['TxtAdm2'])?strip_tags($_POST['TxtAdm2']):0;			$adm3=isset($_POST['TxtAdm3'])?strip_tags($_POST['TxtAdm3']):0;
		$lib1=isset($_POST['TxtLib1'])?strip_tags($_POST['TxtLib1']):0; 		$lib2=isset($_POST['TxtLib2'])?strip_tags($_POST['TxtLib2']):0;
		$lib3=isset($_POST['TxtLib3'])?strip_tags($_POST['TxtLib3']):0;			$med1=isset($_POST['TxtMed1'])?strip_tags($_POST['TxtMed1']):0;
		$med2=isset($_POST['TxtMed2'])?strip_tags($_POST['TxtMed2']):0;			$med3=isset($_POST['TxtMed3'])?strip_tags($_POST['TxtMed3']):0;
		$pem1=isset($_POST['TxtPem1'])?strip_tags($_POST['TxtPem1']):0; 		$pem2=isset($_POST['TxtPem2'])?strip_tags($_POST['TxtPem2']):0;
		$pem3=isset($_POST['TxtPem3'])?strip_tags($_POST['TxtPem3']):0; 		$ole1=isset($_POST['TxtOle1'])?strip_tags($_POST['TxtOle1']):0;
		$ole2=isset($_POST['TxtOle2'])?strip_tags($_POST['TxtOle2']):0;			$ole3=isset($_POST['TxtOle3'])?strip_tags($_POST['TxtOle3']):0;
		//capture misc fees
		$mid1=isset($_POST['TxtID1'])?strip_tags($_POST['TxtID1']):0; 			$mid2=isset($_POST['TxtID2'])?strip_tags($_POST['TxtID2']):0;
		$mid3=isset($_POST['TxtID3'])?strip_tags($_POST['TxtID3']):0;			$mqa1=isset($_POST['TxtQA1'])?strip_tags($_POST['TxtQA1']):0;
		$mqa2=isset($_POST['TxtQA2'])?strip_tags($_POST['TxtQA2']):0;			$mqa3=isset($_POST['TxtQA3'])?strip_tags($_POST['TxtQA3']):0;
		$mrem1=isset($_POST['TxtRem1'])?strip_tags($_POST['TxtRem1']):0; 		$mrem2=isset($_POST['TxtRem2'])?strip_tags($_POST['TxtRem2']):0;
		$mrem3=isset($_POST['TxtRem3'])?strip_tags($_POST['TxtRem3']):0;		$mht1=isset($_POST['TxtHT1'])?strip_tags($_POST['TxtHT1']):0;
		$mht2=isset($_POST['TxtHT2'])?strip_tags($_POST['TxtHT2']):0;			$mht3=isset($_POST['TxtHT3'])?strip_tags($_POST['TxtHT3']):0;
		$mtr1=isset($_POST['TxtTrip1'])?strip_tags($_POST['TxtTrip1']):0; 		$mtr2=isset($_POST['TxtTrip2'])?strip_tags($_POST['TxtTrip2']):0;
		$mtr3=isset($_POST['TxtTrip3'])?strip_tags($_POST['TxtTrip3']):0;		$mole1=isset($_POST['TxtMOle1'])?strip_tags($_POST['TxtMOle1']):0;
		$mole2=isset($_POST['TxtMOle2'])?strip_tags($_POST['TxtMOle2']):0;		$mole3=isset($_POST['TxtMOle3'])?strip_tags($_POST['TxtMOle3']):0;
		//remove commas
		$tui1=preg_replace('/[^0-9^\.]/','',$tui1); 	$tui2=preg_replace('/[^0-9^\.]/','',$tui2);		$tui3=preg_replace('/[^0-9^\.]/','',$tui3);
		$boa1=preg_replace('/[^0-9^\.]/','',$boa1);		$boa2=preg_replace('/[^0-9^\.]/','',$boa2);		$boa3=preg_replace('/[^0-9^\.]/','',$boa3);
		$act1=preg_replace('/[^0-9^\.]/','',$act1); 	$act2=preg_replace('/[^0-9^\.]/','',$act2);		$act3=preg_replace('/[^0-9^\.]/','',$act3);
		$ltt1=preg_replace('/[^0-9^\.]/','',$ltt1);		$ltt2=preg_replace('/[^0-9^\.]/','',$ltt2);		$ltt3=preg_replace('/[^0-9^\.]/','',$ltt3);
		$rmi1=preg_replace('/[^0-9^\.]/','',$rmi1); 	$rmi2=preg_replace('/[^0-9^\.]/','',$rmi2);		$rmi3=preg_replace('/[^0-9^\.]/','',$rmi3);
		$ewc1=preg_replace('/[^0-9^\.]/','',$ewc1);		$ewc2=preg_replace('/[^0-9^\.]/','',$ewc2);		$ewc3=preg_replace('/[^0-9^\.]/','',$ewc3);
		$exa1=preg_replace('/[^0-9^\.]/','',$exa1);		$exa2=preg_replace('/[^0-9^\.]/','',$exa2);		$exa3=preg_replace('/[^0-9^\.]/','',$exa3);
		$adm1=preg_replace('/[^0-9^\.]/','',$adm1); 	$adm2=preg_replace('/[^0-9^\.]/','',$adm2);		$adm3=preg_replace('/[^0-9^\.]/','',$adm3);
		$lib1=preg_replace('/[^0-9^\.]/','',$lib1);		$lib2=preg_replace('/[^0-9^\.]/','',$lib2);		$lib3=preg_replace('/[^0-9^\.]/','',$lib3);
		$med1=preg_replace('/[^0-9^\.]/','',$med1);		$med2=preg_replace('/[^0-9^\.]/','',$med2);		$med3=preg_replace('/[^0-9^\.]/','',$med3);
		$pem1=preg_replace('/[^0-9^\.]/','',$pem1);		$pem2=preg_replace('/[^0-9^\.]/','',$pem2);		$pem3=preg_replace('/[^0-9^\.]/','',$pem3);
		$ole1=preg_replace('/[^0-9^\.]/','',$ole1); 	$ole2=preg_replace('/[^0-9^\.]/','',$ole2);		$ole3=preg_replace('/[^0-9^\.]/','',$ole3);
		$mid1=preg_replace('/[^0-9^\.]/','',$mid1); 	$mid2=preg_replace('/[^0-9^\.]/','',$mid2);		$mid3=preg_replace('/[^0-9^\.]/','',$mid3);
		$mqa1=preg_replace('/[^0-9^\.]/','',$mqa1); 	$mqa2=preg_replace('/[^0-9^\.]/','',$mqa2);		$mqa3=preg_replace('/[^0-9^\.]/','',$mqa3);
		$mrem1=preg_replace('/[^0-9^\.]/','',$mrem1); 	$mrem2=preg_replace('/[^0-9^\.]/','',$mrem2);	$mrem3=preg_replace('/[^0-9^\.]/','',$mrem3);
		$mht1=preg_replace('/[^0-9^\.]/','',$mht1); 	$mht2=preg_replace('/[^0-9^\.]/','',$mht2);		$mht3=preg_replace('/[^0-9^\.]/','',$mht3);
		$mtr1=preg_replace('/[^0-9^\.]/','',$mtr1); 	$mtr2=preg_replace('/[^0-9^\.]/','',$mtr2);		$mtr3=preg_replace('/[^0-9^\.]/','',$mtr3);
		$mole1=preg_replace('/[^0-9^\.]/','',$mole1);	$mole2=preg_replace('/[^0-9^\.]/','',$mole2);	$mole3=preg_replace('/[^0-9^\.]/','',$mole3);
		//computation
		$tui2+=$tui1;	$tui3+=$tui2;	$boa2+=$boa1;	$boa3+=$boa2; 	$act2+=$act1;	$act3+=$act2;	$ltt2+=$ltt1;	$ltt3+=$ltt2;
		$rmi2+=$rmi1;	$rmi3+=$rmi2;	$ewc2+=$ewc1;	$ewc3+=$ewc2; 	$exa2+=$exa1;	$exa3+=$exa2;	$adm2+=$adm1;	$adm3+=$adm2;
		$lib2+=$lib1;	$lib3+=$lib2;	$med2+=$med1;	$med3+=$med2; 	$pem2+=$pem1;	$pem3+=$pem2;	$ole2+=$ole1;	$ole3+=$ole2;
		$mid2+=$mid1;	$mid3+=$mid2; 	$mqa2+=$mqa1;	$mqa3+=$mqa2;	$mrem2+=$mrem1;	$mrem3+=$mrem2;	$mht2+=$mht1;	$mht3+=$mht2;
		$mtr2+=$mtr1;	$mtr3+=$mtr2;	$mole2+=$mole1;	$mole3+=$mole2;
		//terms totals
		$t1=$tui1+$boa1+$act1+$ltt1+$rmi1+$ewc1+$exa1+$adm1+$lib1+$med1+$pem1+$tran1+$ole1;	$t2=$tui2+$boa2+$act2+$ltt2+$rmi2+$ewc2+$exa2+$adm2+$lib2+$med2+$pem2+$tran2+$ole2;
		$t3=$tui3+$boa3+$act3+$ltt3+$rmi3+$ewc3+$exa3+$adm3+$lib3+$med3+$pem3+$tran3+$ole3;	$mt1=$mid1+$mqa1+$mrem1+$mht1+$mtr1+$mole1;	$mt2=$mid2+$mqa2+$mrem2+$mht2+$mtr2+$mole2;
		$mt3=$mid3+$mqa3+$mrem3+$mht3+$mtr3+$mole3;
		if ($t3<1){
			print "<font color=\"#dd0000\" size=\"+2\">YOU CANNOT DEFINE A FEE STRUCTURE WHOSE TOTAL AMOUNT IS ZERO!!!!!</FONT><BR>";
		}else{
			@mysqli_query($conn,"INSERT INTO acc_feeoutline (curr_year,feegrp,lvlNO,t1tui,t1board,t1act,t1ltt,t1rmi,t1ewc,t1exam,t1adm,t1lib,t1med,t1pemol,t1olevies,maint1,
			t2tui,t2board,t2act,t2ltt,t2rmi,t2ewc,t2exam,t2adm,t2lib,t2med,t2pemol,t2olevies,maint2,tui,board,act,ltt,rmi,ewc,exam,adm,lib,med,pemol,olevies,maint3,t1misidcard,t1misqa,
			t1misremedial,t1misht,t1mistrip,t1misole,misct1,t2misidcard,t2misqa,t2misremedial,t2misht,t2mistrip,t2misole,misct2,misidcard,misqa,misremedial,misht,mistrip,misole,misct3)
			VALUES ('$yr','$feegrp','$lvl','$tui1','$boa1','$act1','$ltt1','$rmi1','$ewc1','$exa1','$adm1','$lib1','$med1','$pem1','$ole1','$t1','$tui2','$boa2','$act2','$ltt2','$rmi2',
			'$ewc2','$exa2','$adm2','$lib2','$med2','$pem2','$ole2','$t2','$tui3','$boa3','$act3','$ltt3','$rmi3','$ewc3','$exa3','$adm3','$lib3','$med3','$pem3','$ole3','$t3','$mid1',
			'$mqa1','$mrem1','$mht1','$mtr1','$mole1','$mt1','$mid2','$mqa2','$mrem2','$mht2','$mtr2','$mole2','$mt2','$mid3','$mqa3','$mrem3','$mht3','$mtr3','$mole1','$mt3')") or
			die(mysqli_error($conn)." Fee structure not saved. Click <a href=\"feestruct.php\">here</a> to try again.");
			$i=mysqli_affected_rows($conn); header("location:feestruct.php?action=1-$i");
		}
	}else{
		$rsCo=mysqli_query($conn,"SELECT t1tui,t1board,t1act,t1ltt,t1rmi,t1ewc,t1exam,t1adm,t1lib,t1med,t1pemol,t1olevies,maint1,(t2tui-t1tui) as tui2,(t2board-t1board) as boa2,
		(t2act-t1act) as act2, (t2ltt-t1ltt) as ltt2,(t2rmi-t1rmi) as rmi2,(t2ewc-t1ewc) as ewc2,(t2exam-t1exam)as exa2,(t2adm-t1adm) as adm2,(t2lib-t1lib) as lib2,(t2med-t1med) as
		med2,(t2pemol-t1pemol) as pem2,(t2olevies-t1olevies) as ole2,(maint2-maint1) as ttl2,(tui-t2tui) as tui3,(board-t2board) as boa3,(act-t2act) as act3, (ltt-t2ltt) as ltt3,
		(rmi-t2rmi) as rmi3,(ewc-t2ewc) as ewc3,(exam-t2exam)as exa3,(adm-t2adm) as adm3,(lib-t2lib) as lib3,(med-t2med) as med3,(pemol-t2pemol) as pem3,(olevies-t2olevies) as ole3,
		(maint3-maint2) as ttl3, tui,board,act,ltt,rmi,ewc,exam,adm,lib,med,pemol,olevies,maint3,t1misidcard,t1misqa,t1misremedial,t1misht,t1misgrad,t1mistrip,t1misole,misct1,
		(t2misidcard-t1misidcard) as id2,(t2misqa-t1misqa) as qa2,(t2misremedial-t1misremedial) as rem2,(t2misht-t1misht) as ht2,(t2misgrad-t1misgrad) as grad2,(t2mistrip-t1mistrip) as
		trip2,(t2misole-t1misole) as mole2,(misct2-misct1) as mttl2,(misidcard-t2misidcard) as id3,(misqa-t2misqa) as qa3, (misremedial-t2misremedial) as rem3,(misht-t2misht) as ht3,
		(misgrad-t2misgrad) as grad3,(mistrip-t2mistrip) as trip3,(misole-t2misole) as mole3,(misct3-misct2) as mttl3,misidcard,misqa,misremedial,misht,misgrad,mistrip,misole,misct3 FROM
		acc_feeoutline limit 0,1");
		//initialize the values
		$t1tui=0;$t1boa=0;$t1act=0;$t1ltt=0;$t1rmi=0;$t1ewc=0;$t1exa=0;$t1adm=0;$t1lib=0;$t1med=0;$t1pem=0;$t1ole=0;$t1=0;$t2tui=0;$t2boa=0;$t2act=0;$t2ltt=0;$t2rmi=0;$t2ewc=0;$t2exa=0;
		$t2adm=0;$t2lib=0;$t2med=0;$t2pem=0;$t2ole=0;$t2=0;$t3tui=0;$t3boa=0;$t3act=0;$t3ltt=0;	$t3rmi=0;$t3ewc=0;$t3exa=0;$t3adm=0;$t3lib=0;$t3med=0;$t3pem=0;$t3ole=0;$t3=0;$tui=0;
		$boa=0;$act=0;$ltt=0;$rmi=0;$ewc=0;$exa=0;$adm=0;$lib=0;$med=0;$pem=0;$ole=0;$yt=0;$t1id=0;$t1qa=0;$t1rem=0;$t1grad=0;$t1trip=0;$t1mole=0;$mt1=0;$t2id=0;$t2qa=0;$t2rem=0;
		$t2ht=0;$t2grad=0;$t2trip=0;$t2mole=0;$mt2=0;$t3id=0;$t3qa=0;$t3rem=0;$t3ht=0;$t3grad=0;$t3trip=0;$t3mole=0;$mt3=0;$id=0;$qa=0;$rem=0;$ht=0;$grad=0;$trip=0;$mole=0;$myt=0;
		//fetch fee data from database
		if (mysqli_num_rows($rsCo)>0) list($t1tui,$t1boa,$t1act,$t1ltt,$t1rmi,$t1ewc,$t1exa,$t1adm,$t1lib,$t1med,$t1pem,$t1ole,$t1,$t2tui,$t2boa,$t2act,$t2ltt,$t2rmi,$t2ewc,$t2exa,
		$t2adm,$t2lib,$t2med,$t2pem,$t2ole,$t2,$t3tui,$t3boa,$t3act,$t3ltt,$t3rmi,$t3ewc,$t3exa,$t3adm,$t3lib,$t3med,$t3pem,$t3ole,$t3,$tui,$boa,$act,$ltt,$rmi,$ewc,$exa,$adm,$lib,
		$med,$pem,$ole,$yt,$t1id,$t1qa,$t1rem,$t1ht,$t1grad,$t1trip,$t1mole,$mt1,$t2id,$t2qa,$t2rem,$t2ht,$t2grad,$t2trip,$t2mole,$mt2,$t3id,$t3qa,$t3rem,$t3ht,$t3grad,$t3trip,$t3mole,
		$mt3,$id,$qa,$rem,$ht,$grad,$trip,$mole,$myt)=mysqli_fetch_row($rsCo); mysqli_free_result($rsCo);
	}
?>
<html>
<head>
	<link href="tpl/fmtForms.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Fee Structure</title>
	<script type="text/javascript" src="tpl/feestruct.js"></script>
</head>
<body background="img/bg3.gif">
	<?php
		$h= "Fees Structure Definition";
		print "<center><h2>".strtoupper($h)."</h2></center><hr>";
		print "<form method=\"post\" action=\"FeeStruAdd.php\" name=\"feestruct\" onsubmit=\"return validateFormOnSubmit(this)\"><center><table><tr><td colspan=\"5\"
		style=\"text-align:center;background-color:#000;color:#fff;letter-spacing:3px;word-spacing:5px;\"><b>MAIN ACCOUNT FEE STRUCTURE</b></td><td bgcolor=\"#555555\">-</td><td
		colspan=\"5\" style=\"text-align:center;background-color:#000;color:#fff;letter-spacing:3px;word-spacing:5px;\"><b>MISCELLANEOUS ACCOUNT FEE STRUCTURE</b></td></tr><tr><td
		colspan=\"11\" align=\"center\">-<br><b>Fee Structure Of </b><select name=\"CboLvl\" size=\"1\" id=\"course\">";
		$rs=mysqli_query($conn,"SELECT lvlno,lvlname FROM ClassLvl Order BY lvlno ASC");
		if (mysqli_num_rows($rs)>0) while (list($lno,$lname)=mysqli_fetch_row($rs)) print "<option value=\"$lno\">$lname</option>"; 	mysqli_free_result($rs);
		print "</select> - <select name=\"CboFeeGrp\" size=\"1\" id=\"course\">";
		$cour=mysqli_query($conn,"SELECT fee FROM grps WHERE (fee is not null and fee not like '') Order BY fee ASC");
		if (mysqli_num_rows($cour)>0) while (list($cona)=mysqli_fetch_row($cour)) print "<option>$cona</option>";
		mysqli_free_result($cour);
		print "</select><br>-</td></tr>";
		print "<tr bgcolor=\"#eeeeee\"><td><b>Votehead</b></td><td align=\"center\"><b>Term I</b></td><td align=\"center\"><b>Term II</b></td><td align=\"center\"><b>Term III</b></td><td
		align=\"center\"><b>Total</b></td><td rowspan=\"14\" bgcolor=\"#555555\">-</td><td><b>Votehead</b></td><td align=\"center\"><b>Term I</b></td><td align=\"center\"><b>Term II</b>
		</td><td align=\"center\"><b>Term III</b></td><td align=\"center\"><b>Total</b></td></tr>";
		print "<tr><td>Tuition</td><td><input name=\"TxtTui1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1tui,2)."\" style=\"text-align:right;\" id=\"TxtVal_1_1\"
		onChange=\"Compute(1,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTui2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2tui,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_1_2\" onChange=\"Compute(1,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTui3\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t3tui,2)."\" style=\"text-align:right;\" id=\"TxtVal_1_3\" onChange=\"Compute(1,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTui4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($tui,2)."\" style=\"text-align:right;\" id=\"TxtVal_1\" disabled class=\"bg\"></td><td>ID Card</td><td><input name=\"TxtID1\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t1id,2)."\" style=\"text-align:right;\" id=\"TxtMis_1_1\" onChange=\"MisCompute(1,1)\" onkeyup=\"checkInput(this)\"></td><td>
		<input name=\"TxtID2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2id,2)."\" style=\"text-align:right;\" id=\"TxtMis_1_2\" onChange=\"MisCompute(1,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtID3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3id,2)."\" style=\"text-align:right;\" id=\"TxtMis_1_3\"
		onChange=\"MisCompute(1,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtID4\" maxlength=\"9\" size=\"9\" value=\"".number_format($id,2)."\" style=\"text-align:right;\"
		id=\"TxtMis_1\" disabled  class=\"bg\"></td></tr>";
		print "<tr><td>Boarding &amp; Meals</td><td><input name=\"TxtBoa1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1boa,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_2_1\" onChange=\"Compute(2,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtBoa2\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2boa,2)."\" style=\"text-align:right;\" id=\"TxtVal_2_2\" onChange=\"Compute(2,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtBoa3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3boa,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_2_3\" onChange=\"Compute(2,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtBoa4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($boa,2)."\" style=\"text-align:right;\" id=\"TxtVal_2\" disabled class=\"bg\"></td><td>Quality
		Assurance</td><td><input name=\"TxtQA1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1qa,2)."\" style=\"text-align:right;\"
		id=\"TxtMis_2_1\" onChange=\"MisCompute(2,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtQA2\" maxlength=\"9\" size=\"9\"
		value=\"".number_format($t2qa,2)."\" style=\"text-align:right;\" id=\"TxtMis_2_2\" onChange=\"MisCompute(2,2)\" onkeyup=\"checkInput(this)\"></td>
		<td><input name=\"TxtQA3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3qa,2)."\" style=\"text-align:right;\" id=\"TxtMis_2_3\"
		onChange=\"MisCompute(2,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtQA4\" maxlength=\"9\" size=\"9\" value=\"".number_format($qa,2).
		"\" style=\"text-align:right;\" id=\"TxtMis_2\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Activity</td><td><input name=\"TxtAct1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1act,2)."\" style=\"text-align:right;\"
		id=\"TxtVal_3_1\" onChange=\"Compute(3,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAct2\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t2act,2)."\" style=\"text-align:right;\" id=\"TxtVal_3_2\" onChange=\"Compute(3,2)\" onkeyup=\"checkInput(this)\"></td><td><input
		name=\"TxtAct3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3act,2)."\" style=\"text-align:right;\" id=\"TxtVal_3_3\"
		onChange=\"Compute(3,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAct4\" maxlength=\"9\" size=\"9\" value=\"".number_format($act,2).
		"\" style=\"text-align:right;\" id=\"TxtVal_3\" disabled class=\"bg\"></td><td>Remedial</td><td><input name=\"TxtRem1\" maxlength=\"9\" size=\"9\"
		value=\"".number_format($t1rem,2)."\" style=\"text-align:right;\" id=\"TxtMis_3_1\" onChange=\"MisCompute(3,1)\" onkeyup=\"checkInput(this)\"></td>
		<td><input name=\"TxtRem2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2rem,2)."\" style=\"text-align:right;\" id=\"TxtMis_3_2\"
		onChange=\"MisCompute(3,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRem3\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t3rem,2)."\" style=\"text-align:right;\" id=\"TxtMis_3_3\" onChange=\"MisCompute(3,3)\" onkeyup=\"checkInput(this)\"></td><td><input
		name=\"TxtRem4\" maxlength=\"9\" size=\"9\" value=\"".number_format($rem,2)."\" style=\"text-align:right;\" id=\"TxtMis_3\" disabled class=\"bg\"
		></td></tr>";
		print "<tr><td>L . T &amp; T</td><td><input name=\"TxtLTT1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ltt,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_4_1\" onChange=\"Compute(4,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLTT2\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2ltt,2)."\" style=\"text-align:right;\" id=\"TxtVal_4_2\" onChange=\"Compute(4,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLTT3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3ltt,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_4_3\" onChange=\"Compute(4,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLTT4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($ltt,2)."\" style=\"text-align:right;\" id=\"TxtVal_4\" disabled class=\"bg\"></td><td>Holiday
		Tuition</td><td><input name=\"TxtHT1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ht,2)."\" style=\"text-align:right;\" id=\"TxtMis_4_1\"
		onChange=\"MisCompute(4,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtHT2\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t2ht,2)."\" style=\"text-align:right;\" id=\"TxtMis_4_2\" onChange=\"MisCompute(4,2)\" onkeyup=\"checkInput(this)\"></td><td><input
		name=\"TxtHT3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3ht,2)."\" style=\"text-align:right;\" id=\"TxtMis_4_3\"
		onChange=\"MisCompute(4,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtHT4\" maxlength=\"9\" size=\"9\" value=\"".number_format($ht,
		2)."\" style=\"text-align:right;\" id=\"TxtMis_4\" disabled  class=\"bg\"></td></tr>";
		print "<tr><td>R . M . I</td><td><input name=\"TxtRMI1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1rmi,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_5_1\" onChange=\"Compute(5,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRMI2\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2rmi,2)."\" style=\"text-align:right;\" id=\"TxtVal_5_2\" onChange=\"Compute(5,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRMI3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3rmi,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_5_3\" onChange=\"Compute(5,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRMI4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($rmi,2)."\" style=\"text-align:right;\" id=\"TxtVal_5\" disabled class=\"bg\"></td><td>Graduation Fee</td><td><input
		name=\"TxtGrad1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1grad,2)."\" style=\"text-align:right;\" id=\"TxtMis_5_1\" onChange=\"MisCompute(5,1)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtGrad2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2grad,2)."\" style=\"text-align:right;\" id=\"TxtMis_5_2\"
		onChange=\"MisCompute(5,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtGrad3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3grad,2)."\"
		style=\"text-align:right;\" id=\"TxtMis_5_3\" onChange=\"MisCompute(5,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtGrad4\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($grad,2)."\" style=\"text-align:right;\" id=\"TxtMis_5\" disabled class=\"bg\"></td></tr>";
		//row six
		print "<tr><td>E . W . C</td><td><input name=\"TxtEWC1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ewc,2)."\" style=\"text-align:right;\" id=\"TxtVal_6_1\"
		onChange=\"Compute(6,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtEWC2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2ewc,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_6_2\" onChange=\"Compute(6,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtEWC3\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t3ewc,2)."\" style=\"text-align:right;\" id=\"TxtVal_6_3\" onChange=\"Compute(6,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtEWC4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($ewc,2)."\" style=\"text-align:right;\" id=\"TxtVal_6\" disabled class=\"bg\"></td><td>Academic Trip</td><td><input
		name=\"TxtTrip1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1trip,2)."\" style=\"text-align:right;\" id=\"TxtMis_6_1\" onChange=\"MisCompute(6,1)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTrip2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2trip,2)."\" style=\"text-align:right;\" id=\"TxtMis_6_2\"
		onChange=\"MisCompute(6,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTrip3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3trip,2)."\"
		style=\"text-align:right;\" id=\"TxtMis_6_3\" onChange=\"MisCompute(6,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTrip4\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($trip,2)."\" style=\"text-align:right;\" id=\"TxtMis_6\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Examination/ CATs</td><td><input name=\"TxtExam1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1exa,2)."\" style=\"text-align:right;\" id=\"TxtVal_7_1\"
		onChange=\"Compute(7,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtExam2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2exa,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_7_2\" onChange=\"Compute(7,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtExam3\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t3exa,2)."\" style=\"text-align:right;\" id=\"TxtVal_7_3\" onChange=\"Compute(7,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtExam4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($exa,2)."\" style=\"text-align:right;\" id=\"TxtVal_7\" disabled class=\"bg\"></td><td>Other Levies</td><td><input
		name=\"TxtMOle1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1mole,2)."\" style=\"text-align:right;\" id=\"TxtMis_7_1\" onChange=\"MisCompute(7,1)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMole2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2mole,2)."\" style=\"text-align:right;\" id=\"TxtMis_7_2\"
		onChange=\"MisCompute(7,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMOle3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3mole,2)."\"
		style=\"text-align:right;\" id=\"TxtMis_5_3\" onChange=\"MisCompute(7,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMole4\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($mole,2)."\" style=\"text-align:right;\" id=\"TxtMis_7\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Administrative Costs</td><td><input name=\"TxtAdm1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1adm,2)."\" style=\"text-align:right;\" id=\"TxtVal_8_1\"
		onChange=\"Compute(8,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAdm2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2adm,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_8_2\" onChange=\"Compute(8,2)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAdm3\" maxlength=\"9\" size=\"9\"
		value=\"".number_format($t3adm,2)."\" style=\"text-align:right;\" id=\"TxtVal_8_3\" onChange=\"Compute(8,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAdm4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($adm,2)."\" style=\"text-align:right;\" id=\"TxtVal_8\" disabled class=\"bg\"></td><td rowspan=\"5\"></td><td rowspan=\"5\">
		</td><td rowspan=\"5\"></td><td rowspan=\"5\"></td><td rowspan=\"5\"></td></tr>";
		print "<tr><td>Library</td><td><input name=\"TxtLib1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1lib,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_9_1\" onChange=\"Compute(9,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLib2\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2lib,2)."\" style=\"text-align:right;\" id=\"TxtVal_9_2\" onChange=\"Compute(9,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLib3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3lib,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_9_3\" onChange=\"Compute(9,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLib4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($lib,2)."\" style=\"text-align:right;\" id=\"TxtVal_9\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Medical</td><td><input name=\"TxtMed1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1med,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_10_1\" onChange=\"Compute(10,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMed2\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2med,2)."\" style=\"text-align:right;\" id=\"TxtVal_10_2\" onChange=\"Compute(10,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMed3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3med,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_10_3\" onChange=\"Compute(10,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMed4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($med,2)."\" style=\"text-align:right;\" id=\"TxtVal_10\" disabled class=\"bg\"></tr>";
		//row 11
		print "<tr><td>Personal Emolument</td><td><input name=\"TxtPem1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1pem,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_11_1\" onChange=\"Compute(11,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtPem2\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2pem,2)."\" style=\"text-align:right;\" id=\"TxtVal_11_2\" onChange=\"Compute(11,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtPem3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3pem,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_11_3\" onChange=\"Compute(11,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtPem4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($pem,2)."\" style=\"text-align:right;\" id=\"TxtVal_11\" disabled class=\"bg\"></tr>";
		print "<tr><td>Other Levies</td><td><input name=\"TxtOle1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ole,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_12_1\" onChange=\"Compute(12,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtOle2\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2ole,2)."\" style=\"text-align:right;\" id=\"TxtVal_12_2\" onChange=\"Compute(12,2)\"
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtOle3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3ole,2)."\"
		style=\"text-align:right;\" id=\"TxtVal_12_3\" onChange=\"Compute(12,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtOle4\"
		maxlength=\"9\" size=\"9\" value=\"".number_format($ole,2)."\" style=\"text-align:right;\" id=\"TxtVal_12\" disabled class=\"bg\"></tr>";
		print "<tr><td><b>Total Fees</b></td><td><input name=\"TxtTotal1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1,2)."\"  id=\"TxtTotal1\"
		style=\"text-align:right;\" disabled class=\"bg\"></td><td><input name=\"TxtTotal2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2,2)."\"
		style=\"text-align:right;\" id=\"TxtTotal2\" disabled class=\"bg\"></td><td><input name=\"TxtTotal3\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t3,2)."\" style=\"text-align:right;\" id=\"TxtTotal3\" disabled class=\"bg\"></td><td><input name=\"TxtTotal\" maxlength=\"9\"
		size=\"9\" value=\"".number_format($yt,2)."\" style=\"text-align:right;\" id=\"TxtTotal\" disabled class=\"bg\"></td><td><b>Total Fees</b></td><td><input
		name=\"TxtMTotal1\" maxlength=\"9\" size=\"9\" value=\"".number_format($mt1,2)."\" style=\"text-align:right;\" id=\"TxtMTotal1\" disabled
		class=\"bg\"></td><td><input name=\"TxtMTotal2\" maxlength=\"9\" size=\"9\" value=\"".number_format($mt2,2)."\" style=\"text-align:right;\"
		id=\"TxtMTotal2\" disabled class=\"bg\"></td><td><input name=\"TxtMTotal3\" maxlength=\"9\" size=\"9\" value=\"".number_format($mt3,2)."\"
		style=\"text-align:right;\" id=\"TxtMTotal3\" disabled class=\"bg\"></td><td><input name=\"TxtMTotal\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($myt,2)."\" style=\"text-align:right;\" id=\"TxtMTotal\" disabled class=\"bg\"></td></tr>";
		mysqli_close($conn);
	?><tr><td colspan="12" align="center"><br>
	<hr><button type="submit" name="CmdSave">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Save Fee Structure&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="feestruct.php?action=0-0"><button type="button" name="CmdClose">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Close&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</button></a><br>.</center></form></td></tr></table>
</body>
</html>
