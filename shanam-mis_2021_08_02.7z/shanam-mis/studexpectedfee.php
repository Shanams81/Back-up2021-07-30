<?php
  include_once('shanam.php');
  $rfs=isset($_REQUEST['reloadfs'])?sanitize($_REQUEST['reloadfs']):'0-0-0'; $rfs=preg_split('/\-/',$rfs); //[0] 1 refresh, 0 no refres [1] adm no, [2] year [3] lvlno
  $s=isset($_REQUEST['admno'])?$_REQUEST['admno']:'0-0'; $s=preg_split("/\-/",$s); //[0] admno, [1] curr financial year
  class Accounts{
    private $vno,$vname; public function __construct($s,$na){$this->vno=$s; $this->vname=$na;} public function valVNo(){return $this->vno;}	public function valVName(){return $this->vname;}	public function __destruct(){}
  }if($rfs[0]==1){//refresh fee structure voteheads
    mysqli_multi_query($conn,"DELETE FROM clsfee WHERE admno LIKE '$rfs[1]' and curr_year LIKE '$rfs[2]'; INSERT IGNORE INTO clsfee (admno,curr_year,voteno,t1,t2,t3) SELECT $rfs[1],$rfs[2],voteno,t1,t2,t3 FROM
    acc_feestruct WHERE lvlno LIKE '$rfs[3]';");  while(mysqli_next_result($conn)){} $s[0]=$rfs[1];	$s[1]=$rfs[2];
  }if (isset($_POST['btnSaveFS1'])){
   $sql='';$data=isset($_POST['txtNoAcc'])?sanitize($_POST['txtNoAcc']):'0-0-0-0';     $data=explode('-',$data); //[0] admno, [1] yr, [2] A/C No.
   for($a=0;$a<$data[2];$a++){  $nfs=isset($_POST['txtNo_'.$a])?sanitize($_POST['txtNo_'.$a]):0;
      for($i=0;$i<$nfs;$i++){ $votno=isset($_POST['txtV_'.$a.'_'.$i])?sanitize($_POST['txtV_'.$a.'_'.$i]):0; $t1=isset($_POST['txtT1_'.$a.'_'.$i])?sanitize($_POST['txtT1_'.$a.'_'.$i]):0;
          $t2=isset($_POST['txtT2_'.$a.'_'.$i])?sanitize($_POST['txtT2_'.$a.'_'.$i]):0;  $t3=isset($_POST['txtT3_'.$a.'_'.$i])?sanitize($_POST['txtT3_'.$a.'_'.$i]):0;
          $t1=preg_replace('/[^0-9^\.]/','',$t1);    $t2=preg_replace('/[^0-9^\.]/','',$t2);  $t3=preg_replace('/[^0-9^\.]/','',$t3);   $t3+=$t2+$t1;    $t2+=$t1;
          $sql.="UPDATE clsfee SET t1=$t1,t2=$t2,t3=$t3 WHERE curr_year LIKE '$data[1]' and voteno LIKE '$votno' and admno LIKE '$data[0]'; ";
      }
    }$i=0;
    if(strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)." Click <a href=\"student.php\">HERE</a> to try again.");
      while(mysqli_next_result($conn)){$i+=mysqli_affected_rows($conn);}
    }header("location:student.php?action:1-$i"); exit(0);
  }mysqli_multi_query($conn,"SELECT struedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT concat(s.surname,' ',s.onames) as `stud_names`,concat(c.`clsname`,'-',
  sf.`stream`) As frm,sf.lvlno FROM stud s Left Join class sf USING (admno,curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) WHERE sf.admno LIKE '$s[0]' and sf.curr_year LIKE '$s[1]';
  SELECT acno, ucase(abbr) FROM acc_voteacs WHERE stud_assoc=1 ORDER BY acno ASC;"); $sted=$i=0;
    do{
        if($rs=mysqli_Store_result($conn)){
            if ($i==0){if (mysqli_num_rows($rs)==1) list($sted)=mysqli_fetch_row($rs);}
            elseif ($i==1) list($name,$cls,$lvl)=mysqli_fetch_row($rs);
            else {$noAcc=mysqli_num_rows($rs); while($dt=mysqli_fetch_row($rs)) $accounts[]=new Accounts($dt[0],$dt[1]); } mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));  if($sted==0){header("location:vague.php");	exit(0);}
    headings('<link rel="stylesheet" href="tpl/css/inputsettings.css" type="text/css"/>',0,0,2);
?><form method="post" action="studexpectedfee.php" name="frmSFS"><div class="container divmain">
<?php
	echo "<div class=\"form-row\"><div class=\"col-md-12 divsubheading\" style=\"font-size:1.2rem;font-weight:bold;\"\>ADM NO. $s[0] <u>$name</u> IN GRADE $cls</div></div><div class=\"form-row\">";
	$noac=0;
	foreach($accounts as $acc){
    $rsV=mysqli_query($conn,"SELECT f.voteno,v.descr,f.t1,(f.t2-f.t1) as term2, (f.t3-f.t2) as term3,t3 FROM clsfee f inner join acc_votes v on (f.voteno=v.sno) WHERE (f.curr_year
    LIKE '$s[1]' and f.admno LIKE '$s[0]' and v.acc LIKE '".$acc->valVNo()."') Order By v.acc, f.voteno Asc");	$nofs=mysqli_num_rows($rsV);
    echo "<div class=\"col-md-6 divlrborder\"><div class=\"form-row\"><div class=\"col-md-12 divsubheading\" style=\"border-radius:10px 10px 0 0;\">".$acc->valVName().
    " FEE STRUCTURE ".($noac==0?"<img onclick=\"window.open('studexpectedfee.php?reloadfs=1-$s[0]-$s[1]-$lvl','_self')\" src=\"../gen_img/refresh.jpg\" width=\"20\" height=\"20\" "
    . "align=\"right\" title=\"Refresh Feestructure Votes\"></a>":"")."</div></div>";
    echo "<div class=\"form-row\" style=\"font-weight:bold;\"><div class=\"col-md-4\">VOTEHEAD</div><div class=\"col-md-2\">TERM I</div><div class=\"col-md-2\">TERM II</div><div "
    . "class=\"col-md-2\">TERM III</div><div class=\"col-md-2\">TOTAL</div></div>";
    $i=0; $ttlAmt=array(0,0,0,0);
    while (list($voteno,$vote,$t1,$t2,$t3,$ttl)=mysqli_fetch_row($rsV)):
        echo '<div class="form-row"><div class="col-md-4"><input type="hidden" name="txtV_'.$noac.'_'.$i.'" id="txtV_'.$noac.'_'.$i.'" value="'.$voteno.'">'.$vote.'</div><div '
        . 'class="col-md-2"><input type="text" name="txtT1_'.$noac.'_'.$i.'" id="txtT1_'.$noac.'_'.$i.'" value="'.number_format($t1,2).'" required onkeyup="checkData(this)" '
        . 'onblur="getTotal('.$noac.','.$i.','.$nofs.')" class="modalinput numbersinput" readonly></div><div class="col-md-2"><input type="text" name="txtT2_'.$noac.'_'.$i.'" '
        . 'id="txtT2_'.$noac.'_'.$i.'" value="'.number_format($t2,2).'" onblur="getTotal('.$noac.','.$i.','.$nofs.')" onkeyup="checkData(this)" class="modalinput numbersinput"
        required readonly></div><div class="col-md-2"><input type="text" name="txtT3_'.$noac.'_'.$i.'" id="txtT3_'.$noac.'_'.$i.'" value="'.number_format($t3,2).'" required '
        . 'onkeyup="checkData(this)" onblur="getTotal('.$noac.','.$i.','.$nofs.')" class="modalinput numbersinput" readonly></div><div class="col-md-2"><input type="text" '
        . 'name="txtTtl_'.$noac.'_'.$i.'" id="txtTtl_'.$noac.'_'.$i.'" value="'.number_format($ttl,2).'" required class="modalinput numbersinput disabled" readonly>'
        . '</div></div>';
        $ttlAmt[0]+=$t1; $ttlAmt[1]+=$t2; $ttlAmt[2]+=$t3; $ttlAmt[3]+=$ttl; $i++;
    endwhile;
    echo '<div class="form-row"><div class="col-md-4" style="text-align:right;font-weight:bold;letter-spacing:2px; word-spacing:3px;">TERM\'S TOTAL</b></div>'; $i=0;
    foreach ($ttlAmt as $amt){
        echo '<div class="col-md-2"><input type="text" name="txtTermTtl_'.$noac.'_'.$i.'" id="txtTermTtl_'.$noac.'_'.$i.'" value="'.number_format($amt,2).'" readonly
        class="modalinput numbersinput"></div>'; $i++;
    } echo '<input type="hidden" name="txtNo_'.$noac.'" id="txtNo_'.$noac.'" value="'.$nofs.'"></div></div>'; $noac++;
	}
    echo '</div><br><hr><div class="form-row"><div class="col-md-4"><input type="hidden" name="txtNoAcc" id="txtNoAcc" value="'.$s[0].'-'.$s[1].'-'.$noAcc.'"><button type="button" '.
	($sted==1?'':'disabled').' name="btnEdit1" id="btnEdit1" onclick="allowEdit()" class="btn btn-info disabled btn-md">Edit Fee Structure</button></div><div class="col-md-4"><button
        type="submit" name="btnSaveFS1" id="btnSaveFS1" disabled class="btn btn-primary btn-block btn-md">Save Fee  Structure</button></div><div class="col-md-4" style="text-align:right;">
        <button type="button" class="btn btn-info disabled btn-md" onclick="window.open(\'student.php\',\'_self\')" name="btnCloseFS">Cancel/ Close</button></div></div><div></form>';
	mysqli_free_result($rsV);
?>
<script type="text/javascript" src="tpl/js/studexpectedfee.js"></script>
<?php
    mysqli_close($conn); footer();
?>
