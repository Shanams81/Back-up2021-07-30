<?php
    declare(strict_types=1);   include_once('shanam.php');
    class NoVotes{
      private $acc,$name,$nov; public function __construct($a,$na,$no){$this->acc=$a; $this->name=$na; $this->nov=$no;} public function valAcc(){return $this->acc;} public function valVotes(){return $this->nov;}
      public function valName(){return $this->name;}
    }class Balance{
      private $vno,$vote,$orderno,$acc,$t1,$t2,$t3,$ttl;
      public function __construct($v,$vna,$o,$ac,$b1,$b2,$b3,$t){$this->vno=$v;$this->vote=$vna;$this->orderno=$o;$this->acc=$ac;$this->t1=$b1;$this->t2=$b2;$this->t3=$b3;$this->ttl=$t;}
      public function valVSNo(){return $this->vno;} 	public function valOrderNo(){return $this->orderno;}	public function valBalTTl(){return $this->ttl;} public function valAcc(){return $this->acc;}
      public function valBalT1(){return $this->t1;}		public function valBalT2(){return $this->t2;}         public function valBalT3(){return $this->t3;}		public function valVName(){return $this->vote;}
    }
    if(isset($_POST['btnSaveFee'])){
     	$nac=isset($_POST['txtNoV'])?sanitize($_POST['txtNoV']):0;   $token=sanitize($_POST['txtToken']); $rectype=sanitize($_POST['txtRecType']);  $admno=isset($_POST['txtAdmNo'])?sanitize($_POST['txtAdmNo']):0;
      $date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('Y-m-d');$paidby=isset($_POST['cboPaidBy'])?sanitize($_POST['cboPaidBy']):"Parent";$bursno=isset($_POST['txtBursNo'])?sanitize($_POST['txtBursNo']):null;
      $bursbal=isset($_POST['txtBursBal'])?sanitize($_POST['txtBursBal']):0; $pytfrm=isset($_POST['cboPytFrm'])?strtoupper(sanitize($_POST['cboPytFrm'])):'DIRECT BANKING';
      $cheno=isset($_POST['txtCheNo'])?strtoupper(sanitize($_POST['txtCheNo'])):null;  $bankno=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0; $fee=isset($_POST['txtTtlFee'])?sanitize($_POST['txtTtlFee']):0;
      $addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';     $kind=isset($_POST['txtKind'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtKind']))):null; $ttlamt=0;
      $bc=isset($_POST['txtBC'])?sanitize($_POST['txtBC']):0;  $idno=isset($_POST['txtIDNo'])?strtoupper(sanitize($_POST['txtIDNo'])):null; 	$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):'+2547';
      $parent=isset($_POST['txtParent'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtParent']))):null; $mdbal=isset($_POST['txtVoteBal_0'])?sanitize($_POST['txtVoteBal_0']):0;
      $addr=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):null; $midbal=isset($_POST['txtMVoteBal_0'])?sanitize($_POST['txtMVoteBal_0']):0;
      $mdbal=floatval(preg_replace('/[^0-9\.]/','',$mdbal));  $midbal=floatval(preg_replace('/[^0-9\.]/','',$midbal));	 $bankno=($bankno>0?$bankno:null); $fee=floatval(preg_replace('/[^0-9\.]/','',$fee));
      $date=preg_split('/\-/',$date);    $bc=floatval(preg_replace('/[^0-9\.]/','',$bc));	$cheno=strlen($cheno)>0?$cheno:null; $bursno=strlen($bursno)>0?$bursno:null; $kind=strlen($kind)>0?$kind:null;
      for($i=0;$i<$nac;$i++){$sqlinco=$sqlvotes=$sqlarr=$sqlmed=$sqluni=$sqlprep=""; //loop through account
          $amt=isset($_POST['txtFee_'.$i])?sanitize($_POST['txtFee_'.$i]):0;	$amt=floatval(preg_replace('/[^0-9\.]/','',$amt)); $ttlamt+=$amt; $prep=$ref=$spemed=$start=$uni=0; $sqlvote="";
          if($amt>0){ //process only is amt i higher than 0
              $lmt=isset($_POST["txtLimit_$i"])?sanitize($_POST["txtLimit_$i"]):'0-0-0-0-0-0-0-0-0'; $main=$amt; $sqlvote.='INSERT INTO acc_incovotes (recno,acc,voteno,amt,markdel) VALUES '; $sql='';
              $count=0; $lmt=preg_split('/\-/',$lmt);//[0] lvl,[1] no.votes,[2] classofstudy,[3] curr a/c,[4] spemed a/c,[5] unifrm a/c,[6]-no. a/c,[7]-no. of all votes,[8] 1 lastclass,0 continuingclass
              for($a=0;$a<$lmt[7];$a++){ $vamt=isset($_POST['txtAmt_'.$i.'_'.$a])?sanitize($_POST['txtAmt_'.$i.'_'.$a]):0; if($vamt!=0){$vamt=floatval(preg_replace('/[^0-9\.]/','',$vamt));} $start=0;
                if (intval($lmt[3])==intval($lmt[4])){
                  if($a===0){$prep=$vamt;}elseif($a===1){$arr=$vamt;}elseif($a===2){$spemed=$vamt;}elseif($lmt[3]==$lmt[5] && $a===3){$uni=$vamt;$start=4;}elseif($a===$start){$ref=$vamt;}
                }else{if($a===0){$arr=$vamt;}elseif($a==1 && $lmt[4]!=$lmt[5]){$uni=$vamt;}}
                if ($vamt>0){$v=sanitize($_POST["txtVote_$i"."_$a"]); $v=preg_split('/\-/',$v); $sql.=($count==0?"":",")."({RECNO},'$v[0]','$v[1]',$vamt,0)"; $count++;}
              }$sqlvote.=$sql.";";
              if ($lmt[3]==$lmt[4]){$sqlinco.="INSERT INTO acc_incorecno0 (recno,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm) VALUES (0,{SNO},'$lmt[3]',$bc,$amt,$arr,$spemed,$ref,$prep,$uni);";
                $sql="SELECT curr_year,bbf FROM class WHERE admno LIKE '$admno' and bbf>0 ORDER BY curr_year ASC;";
                if($spemed>0) $sql.="SELECT b.billno,(b.amt-if(isnull(c.clr),0,c.clr)) bal FROM `acc_hospbills` b Left Join (SELECT billNo,sum(amt) as clr FROM acc_hospunibillclr GROUP BY markdel,billNo,
                admno,transtype HAVING transtype=0 and markdel=0 and admno LIKE '$admno')c USING (billNo) WHERE  b.admno LIKE '$admno' and (b.amt-if(isnull(c.clr),0,c.clr))>0 and b.markdel=0; SELECT curr_year,
                spemed FROM class WHERE admno LIKE '$admno' and spemed>0 ORDER BY curr_year ASC;"; else $sql.="SELECT 0;SELECT 0;";
                if($uni>0 && $lmt[3]==$lmt[5]) $sql.="SELECT b.purchno,(u.ttl-if(isnull(c.clr),0,c.clr)) bal FROM `unifrmpurchase` b Inner Join (SELECT up.purchno,sum(u.amt*up.qty) as ttl FROM unipurchdetails up Inner Join
                uniforms u USING (unifrmno) GROUP BY up.purchno,up.markdel HAVING up.markdel=0)u USING (purchno) Left Join (SELECT billNo as purchno,sum(amt) as clr FROM acc_hospunibillclr GROUP BY markdel,billNo,
                admno,transtype HAVING transtype=1 and markdel=0 and admno LIKE '$admno')c USING (purchNo) WHERE  b.admno LIKE '$admno' and (u.ttl-if(isnull(c.clr),0,c.clr))>0; SELECT curr_year,unifrm FROM class
                WHERE admno LIKE '$admno' and unifrm>0 ORDER BY curr_year ASC;"; elseif($lmt[3]==$lmt[5]) $sql.="SELECT 0;SELECT 0;";
                $sql.="SELECT c.voteno,(c.t3-if(isnull(f.ttl),0,f.ttl)) as bal FROM clsfee c Inner Join acc_votes v On (c.voteno=v.sno) Inner Join acc_voteacs a On (v.acc=a.acno)
                LEFT JOIN (SELECT i.admno, f.acc,v.voteno,sum(v.amt) as ttl FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) Inner Join acc_incoprep v USING (recno) GROUP BY i.admno,f.acc,
                v.voteno,i.markdel HAVING markdel=0 and f.acc=1  and i.admno='$admno')f USING (admno,voteno) WHERE c.admno='$admno' and v.acc=1";
              }else{$sqlinco.="INSERT INTO acc_incorecno1(recno,sno,acc,bc,amt,arrears,spemed,unifrm) VALUES (0,{SNO},'$lmt[3]',$bc,$amt,$arr,$spemed,$uni);";
                $sql="SELECT curr_year,miscbf FROM class WHERE admno LIKE '$admno' and miscbf>0 ORDER BY curr_year ASC;SELECT 0;SELECT 0;";
                if($uni>0 && $lmt[3]==$lmt[5])$sql.="SELECT b.purchno,(u.ttl-if(isnull(c.clr),0,c.clr)) bal FROM `unifrmpurchase` b Inner Join (SELECT up.purchno,sum(u.amt*up.qty) as ttl FROM unipurchdetails up Inner Join
                uniforms u USING (unifrmno) GROUP BY up.purchno,up.markdel HAVING up.markdel=0)u USING (purchno) Left Join (SELECT billNo as purchno,sum(amt) as clr FROM acc_hospunibillclr GROUP BY markdel,billNo,
                admno,transtype HAVING transtype=1 and markdel=0 and admno LIKE '$admno')c USING (purchNo) WHERE  b.admno LIKE '$admno' and (u.ttl-if(isnull(c.clr),0,c.clr))>0; SELECT curr_year,unifrm FROM class
                WHERE admno LIKE '$admno' and unifrm>0 ORDER BY curr_year ASC;"; elseif($lmt[3]==$lmt[5]) $sql.="SELECT 0;SELECT 0;";
                $sql.="SELECT 0";
              }mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"feerec.php?cod=$admno-2020\">HERE</a> to try again."); $index=0; $sql=$sqlclr="";
              do{if($rs=mysqli_store_result($conn)){
                  if($index===0 && $arr>0){$tharr=$arr;// Arrears
                    $sqlarr.="INSERT INTO acc_arrrefclr(clrno,recno,arr_year,ac,clron,admno,amt,transtype) VALUES "; $count=0;
                    while(($d=mysqli_fetch_row($rs)) && ($tharr>0)){ $sql.="UPDATE class SET ";
                      if ($lmt[3]===$lmt[4]){  if(floatval($d[1])>=$tharr){$sql.="bbf=bbf-$tharr "; $sqlclr.=($count==0?"":",")."(0,{RECNO},$d[0],'$lmt[3]',curdate(),'$admno',$tharr,0)";   $tharr=0; $count++;}
                        else{$sql.="bbf=bbf-$d[1]"; $sqlclr.=($count==0?"":",")."(0,{RECNO},$d[0],'$lmt[3]',curdate(),'$admno',$d[1],0)"; $tharr-=floatval($d[1]); $count++;}
                      }else{ if(floatval($d[1])>=$tharr){$sql.="miscbf=miscbf-$tharr "; $sqlclr.=($count==0?"":",")."(0,{RECNO},$d[0],'$lmt[3]',curdate(),'$admno',$tharr,0)"; $tharr=0; $count++;}
                        else{$sql.="miscbf=miscbf-$d[1]"; $sqlclr.=($count==0?"":",")."(0,{RECNO},$d[0],'$lmt[3]',curdate(),'$admno',$d[1],0)";  $tharr-=floatval($d[1]); $count++;}
                      }$sql.="WHERE admno LIKE '$admno' and curr_year LIKE '$d[0]';";
                    } $sqlarr.=$sqlclr.";".$sql;     $sql=$sqlclr="";
                  }elseif(($index===1 || $index===2) && $spemed>0){
                    if($index===1) $sqlmed='INSERT INTO acc_hospunibillclr(clrno,billno,recno,acc,clrdon,admno,amt,transtype) VALUES '; //Special medical
                    if($index===1){ $med=$spemed; $count=0;
                      while(($med>0) && ($d=mysqli_fetch_row($rs))){if($d[1]>$med){$sql.=($count==0?"":",")."(0,$d[0],{RECNO},'$lmt[3]',curdate(),'$admno',$med,2)"; $med=0;
                        }else{$sql.=($count==0?"":",")."(0,$d[0],{RECNO},'$lmt[3]',curdate(),'$admno',$d[1],2)"; $med-=floatval($d[1]); $sqlclr.="UPDATE acc_hospbills SET clrd=1 WHERE billno LIKE '$d[0]';";} $count++;
                      }$sqlmed.=$sql.";";
                    }else{while(($d=mysqli_fetch_row($rs)) && ($spemed>0)){ $sqlclr.="UPDATE class SET spemed=spemed-";
                      if (floatval($d[1])>=$spemed) {$sqlclr.="$spemed"; $spemed=0;}else{$sqlclr.="$d[1]"; $spemed-=floatval($d[1]);} $sqlclr.=" WHERE admno LIKE '$admno' and curr_year LIKE '$d[0]';";
                    }$sqlmed.=$sqlclr;}$sql=$sqlclr='';
                  }elseif(($index===3 || $index===4) && $uni>0){
                    if($index===3)$sqluni='INSERT INTO acc_hospunibillclr(clrno,billno,recno,acc,clrdon,admno,amt,transtype) VALUES ';//Extra Uniforms
                    if($index===3){ $bill=$uni; $count=0;
                      while(($bill>0) && ($d=mysqli_fetch_row($rs))){
                        if($d[1]>$bill){$sql.=($count==0?"":",")."(0,$d[0],{RECNO},'$lmt[3]',curdate(),'$admno',$bill,1)"; $bill=0;
                        }else{$sql.=($count==0?"":",")."(0,$d[0],{RECNO},'$lmt[3]',curdate(),'$admno',$d[1],1)"; $sqlclr.="UPDATE unifrmpurchase SET clrd=1 WHERE purchno LIKE '$d[0]';"; $bill-=floatval($d[1]);} $count++;
                      }$sqluni.=$sql.";";
                    }else{while(($d=mysqli_fetch_row($rs)) && ($uni>0)){ $sqlclr.="UPDATE class SET unifrm=unifrm-";
                      if ($d[1]>=$uni){$sql.="$uni ";  $uni=0;}else{$sql.="$d[1]"; $uni-=$d[1];} $sqlclr.=" WHERE admno LIKE '$admno' and curr_year LIKE '$d[0]';";
                    }$sqluni.=$sqlclr;} $sql=$sqlclr='';
                  }elseif(($index===5) && $prep>0){
                    $sqlprep='INSERT INTO acc_incoprep(recno,acc,voteno,amt) VALUES ';//Prepayment
                    while(($d=mysqli_fetch_row($rs)) && ($prep>0)){$amtprep=0;
                      if($d[1]>0){if ($d[1]>=$prep){$amtprep=$prep; $prep=0;}else{$amtprep=$d[1]; $prep-=floatval($d[1]);} $sql.=($count==0?"":",")."({RECNO},'$lmt[3]',$d[0],$amtprep)"; $count++;}
                    } if($prep>0){$sql.=($count==0?"":",")."({RECNO},'$lmt[3]',4,$prep)";} $sqlprep.=$sql.";";
                  } mysqli_free_result($rs);
                }$index++;
              }while(mysqli_next_result($conn));
              if($ref>0){$sqlprep.="UPDATE class c Inner Join ss s On (c.curr_year=s.finyr) SET c.refunds=c.refunds+$ref WHERE admno LIKE '$admno'";}//update refunds
          }$sqlincome[]=$sqlinco; $sqlvotehead[]=$sqlvote; $sqluniform[]=$sqluni; $sqlarrears[]=$sqlarr; $sqlmedical[]=$sqlmed; $sqlprepaid[]=$sqlprep;
      }
      if ($fee==0 || ($mdbal!=0 && $midbal!=0) || ((strcasecmp($pytfrm,"Cash")!=0 && strcasecmp($pytfrm,"Kind")!=0) && strlen($cheno)==0) || (strcasecmp($pytfrm,"Kind")==0  &&
      strlen($kind)<10 && strlen($idno)<7 && strlen($parent)<8 && strlen($telno)<7) || ((strcasecmp($pytfrm,"cheque")==0 || strcasecmp($pytfrm,"direct banking")==0) && (is_null($bankno)
      || is_null($cheno))) || (strcasecmp($pytfrm,"mfees")==0 && is_null($cheno)) || ($_SESSION['form_token']!=$token)){
        print "Sorry, the fee receipt record had errors. The reciept was not sucessfully saved. Click <a href=\"studfee.php\">here</a> to try again"; unset($_SESSION['form_token']); exit(0);
      }else{
          $recno=$sno=$vono=0;     unset($_SESSION['form_token']);
          if (mysqli_query($conn,"INSERT INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,kinddescr,addedby) VALUES(0,'$admno','$date[2]-$date[1]-$date[0]','$paidby','$pytfrm',".var_export($cheno,
          true).",".var_export($bursno,true).",".var_export($bankno,true).",".var_export($kind,true).",'$addby')") or die(mysqli_error($conn).". Click <a href=\"feerec.php?cod=$admno-2020\">HERE</a> to try again.")){
              $sno=mysqli_insert_id($conn);  $i=0;
              foreach($sqlincome as $inco){//loop through account
                  if(strlen($inco)>0){
                    if(mysqli_query($conn,str_replace("{SNO}",strval($sno),$inco)) or die(mysqli_error($conn).". Click <a href=\"feerec.php?cod=$admno-2020\">HERE</a> to try again.")){
                        $recno=mysqli_insert_id($conn); $sql=str_replace("{RECNO}",strval($recno),$sqlvotehead[$i]);
                        if(strlen($sqlarrears[$i])>0){$sql.=str_replace("{RECNO}",strval($recno),$sqlarrears[$i]);}
                        if(strlen($sqlmedical[$i])>0){$sql.=str_replace("{RECNO}",strval($recno),$sqlmedical[$i]);}
                        if(strlen($sqluniform[$i])>0){$sql.=str_replace("{RECNO}",strval($recno),$sqluniform[$i]);}
                        if(strlen($sqlprepaid[$i])>0){$sql.=str_replace("{RECNO}",strval($recno),$sqlprepaid[$i]);}
                    }mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"studfee.php\">HERE </a> to go back."); while(mysqli_next_result($conn)){}}$i++;
              }if(!is_null($kind) && $ttlamt>0){//Fee payment in kind
                mysqli_multi_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno'; SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '1';SELECT voteno FROM acc_votesassigned WHERE name LIKE
                '%kind%'; SELECT sno FROM acc_votes WHERE acc=1 and (descr LIKE '%lunch%' or descr LIKE '%board%');");  $i=0; $payno=0; $vote=0;
                do{
                  if($rs=mysqli_store_result($conn)){
                    if($i==0){$no=mysqli_num_rows($rs); if ($no>0) list($payno)=mysqli_fetch_row($rs);}elseif($i==1){$no=mysqli_num_rows($rs); if ($no>0) list($vono)=mysqli_fetch_row($rs);
                    }elseif($i==2){$no=mysqli_num_rows($rs); if ($no>0) list($vote)=mysqli_fetch_row($rs);}
                    else{$no=mysqli_num_rows($rs); if ($vote==0 && $no>0) list($vote)=mysqli_fetch_row($rs);} mysqli_free_result($rs);//only when fee in Kind vote not defined
                  }$i++;
                }while(mysqli_next_result($conn)); $vono++;
                if($payno==0){//paye details are not in the system
                  if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES(0,curdate(),'$parent','$idno',".var_export($addr,true).",'$telno','$addby')")){
                    $payno=mysqli_insert_id($conn);}
                }
                mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,pytfrm,acc,caamt,rmks,expno,addedby,recsno) values ($vono,curdate(),'Cash',1,$ttlamt,'BEING PAYMENT FOR FEES IN-KIND OF $kind',$payno,'$addby'
                ,$sno); INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,1,$vote,$ttlamt);") or die(mysqli_error($conn).". Click <a href=\"studfee.php\">HERE </a> to go back.");
            }
          } header("location:rpts/".($rectype==0?"receipt":"receiptcopy").".php?recno=$sno-0-0-$vono-".uniqid()); exit(0);
        }
    }else{
        $info=isset($_REQUEST['cod']) ? strip_tags($_REQUEST['cod']): "0-0"; 	$info=preg_split('/\-/',$info); //[0] admno, [1] year
        $form_token=uniqid();  	$_SESSION['form_token']=$form_token;
        mysqli_multi_query($conn,"SELECT v.acc,a.abbr,count(v.sno) FROM acc_votes v Inner Join acc_voteacs a On (v.acc=a.acno) GROUP BY v.acc,v.stud_fee,a.stud_assoc,a.markdel HAVING v.stud_fee=1 and a.stud_assoc=1
        and a.markdel=0;SELECT c.voteno,v.descr,v.orderno,v.acc,if((c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl)))) as t1bal,(if((c.t2-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,
        0,(c.t2-if(isnull(sum(f.ttl)),0,sum(f.ttl))))-if((c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl))))) as t2bal,(if((c.t3-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t3-
        if(isnull(sum(f.ttl)),0,sum(f.ttl))))-if((c.t2-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t2-if(isnull(sum(f.ttl)),0,sum(f.ttl))))) as t3bal FROM clsfee c Inner Join acc_votes v On (c.voteno=v.sno) Inner Join
        acc_voteacs a On (v.acc=a.acno) INNER JOIN ss ON (c.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,f.acc,v.voteno,sum(v.amt) as ttl FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) Inner Join acc_incovotes v
        USING (recno,acc) GROUP BY i.admno,f.acc,v.voteno,i.markdel HAVING markdel=0 and f.acc=1  and i.admno LIKE '$info[0]' UNION SELECT i.admno,f.acc,v.voteno,sum(v.amt) as ttl FROM acc_incofee i Inner Join acc_incorecno1 f
        USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY i.admno,f.acc,v.voteno,i.markdel HAVING markdel=0 and  f.acc!=1  and i.admno LIKE '$info[0]')f USING (admno,voteno) GROUP BY c.admno,c.curr_year,
        c.voteno,v.descr,v.orderno,v.acc,v.stud_fee,v.fs_defined,a.stud_assoc,a.markdel HAVING stud_fee=1 and v.fs_defined=1 and a.stud_assoc=1 and a.markdel=0  and c.admno LIKE '$info[0]' ORDER BY v.acc,v.orderno ASC;
        SELECT finyr,receipt FROM ss; SELECT concat(sum(case when name='bbf' then acc else 0 end),'-',sum(case when name='bbf' then voteno else 0 end)) as bbf,concat(sum(case when name='miscbf' then acc else 0 end),'-',
        sum(case when name='miscbf' then voteno else 0 end)) as miscbf,concat(sum(case when name='spemed' then acc else 0 end),'-',sum(case when name='spemed' then voteno else 0 end)) as spemed,concat(sum(case when
        name='unifrm' then acc else 0 end),'-',sum(case when name='unifrm' then voteno else 0 end)) as unifrm FROM `acc_votesassigned`; SELECT sno,descr FROM acc_banks WHERE markdel=0 ORDER BY descr Asc; SELECT tno FROM
        terms WHERE curdate() BETWEEN starts and ends;");  $rectype=$i=$noacs=0; $sql=$optBanks=''; $tno=1;
        do{
            if($rs=mysqli_store_result($conn)){
                if ($i==0){$noacs=mysqli_num_rows($rs); while($d=mysqli_fetch_row($rs)) $novotes[]=new NoVotes($d[0],$d[1],$d[2]);
                }elseif($i==1){while($d=mysqli_fetch_row($rs)) $balances[]=new Balance($d[0],$d[1],$d[2],$d[3],$d[4],$d[5],$d[6],($d[5]+$d[6]+$d[4]));
                }elseif($i==2) list($finyr,$rectype)=mysqli_fetch_row($rs); elseif($i==3) $spevote=mysqli_fetch_row($rs);	//[0] bbf A/C & Vote [1] Misc Arr & Vote [2] Spemed AC & Vote [3] Unifrm A/C & Vote
                elseif($i==4){ while ($d=mysqli_fetch_row($rs)) $optBanks.="<option value=\"$d[0]\">$d[1]</option>";} else list($tno)=mysqli_fetch_row($rs);    mysqli_free_result($rs);
            }$i++;
        }while(mysqli_next_result($conn));
        $sql="SELECT s.admno, s.stud_names, s.cls, ar.arbf, ".($noacs==1?"0":"ar.marbf")." as marbf,ar.med,ar.uni,ar.acspemed,ar.acunifrm,if(((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-
        if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))) as t1bal,if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,
        f.fee)-if((s.t1f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,f.fee))))) as t2bal,if((s.t3f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t3f-if(isnull(f.fee),0,f.fee)-if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,
        0,(s.t2f-if(isnull(f.fee),0,f.fee))))) as t3bal,(s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0)-if(isnull(f.fee),0,f.fee)) as ybal,";
        if ($noacs==1) $sql.="0 as mt1bal,0 as mt2bal,0 as mt3bal,0 as mybal,s.lastyr FROM (SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,s.curr_year,sum(if(v.acc=1,
        cf.T1,0)) as t1f,sum(if(v.acc=1,cf.T2,0)) as t2f,sum(if(v.acc=1,cf.T3,0)) as t3f,if(l.clsno=c.clsno,1,0) as lastyr FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno)
        Inner Join classlvl l ON (c.lvlno=l.lvlno) INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On  (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY s.admno,s.surname,s.onames,
        s.Curr_Year,cn.clsname,c.stream,a.stud_assoc,s.present,s.markdel HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$info[0]')s INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.spemed) as
        med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM
        acc_votesassigned)x GROUP BY admno, markdel HAVING markdel=0 and admno LIKE '$info[0]')ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-
        v.unifrm)) as fee FROM acc_incofee f LEFT JOIN acc_incorecno0 v USING (sno) ";
        else $sql.="if(((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-
        if(isnull(f.mfee),0,f.mfee))) as mt1bal,if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-if(isnull(f.mfee),0,f.mfee)-if((s.mt1f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt1f-if(isnull(f.mfee),0,f.mfee))))) as
        mt2bal,if((s.mt3f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt3f-if(isnull(f.mfee),0,f.mfee)-if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-if(isnull(f.mfee),0,f.mfee))))) as mt3bal,((s.mt3f+ar.marbf+
        if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee)) as mybal,s.lastyr FROM (SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,
        s.curr_year,sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc!=1,cf.T1,0)) as mt1f,sum(if(v.acc=1,cf.T2,0)) as t2f,sum(if(v.acc!=1,cf.T2,0)) as mt2f,sum(if(v.acc=1,cf.T3,0)) as t3f,sum(if(v.acc!=1,cf.T3,0)) as mt3f,
        if(l.clsno=c.clsno,1,0) as lastyr FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) Inner Join classlvl l ON (c.lvlno=l.lvlno) INNER JOIN clsfee cf USING (admno,
        curr_year) INNER JOIN acc_votes v  On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY s.admno,s.surname,s.onames,s.Curr_Year,cn.clsname,c.stream,a.stud_assoc,s.present,s.markdel HAVING
        s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$info[0]')s INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.miscbf) as marbf,sum(c.spemed) as med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm
        FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM `acc_votesassigned`)x GROUP BY admno, markdel HAVING markdel=0
        and admno LIKE '$info[0]')ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm)) as fee,if(isnull(sum(m.amt)),0,sum(m.amt-m.arrears-
        m.spemed-m.unifrm)) as mfee FROM acc_incofee f LEFT JOIN acc_incorecno0 v USING (sno) Left Join acc_incorecno1 m USING (sno)";
        $sql.=" GROUP BY f.admno,f.markdel HAVING f.markdel=0 and f.admno LIKE '$info[0]')f ON (s.admno=f.admno)"; //echo $sql;
        $rs=mysqli_query($conn,$sql); $stud=mysqli_fetch_row($rs); mysqli_free_result($rs);	$curdate=date('d-m-Y');
        $mon=date('m');	$balmisc=($tno==1)?$stud[13]:($tno==2?($stud[13]+$stud[14]):$stud[16]); //current miscellenous balance
    }headings('<link href="../date/tcal.css" rel="stylesheet" type="text/css"/><link href="tpl/css/inputsettings.css" rel="stylesheet" type="text/css"/>',0,0,1);
?>
<div class="container" style="border:1px dashed #fff;border-radius:15px;padding:5px;margin:auto;max-width:1100px;background-color:#e6e6f6;">
<form method="post" action="feerec.php" name="feerecs" onsubmit="return SaveFeeRecord(this);"><input type="hidden" name="txtNoV" id="txtNoV" size="2" value="<?php echo $noacs;?>"><input type="hidden" name="txtRecType"
  id="txtRecType" value="<?php echo $rectype;?>" size="2">
<h3 style="">ADM. NO.<?php print $stud[0]." <u>".$stud[1]."</u> IN GRADE/FORM ".$stud[2];?></h3>
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#fee" role="tab" aria-controls="fee" aria-selected="true">FEE RECEIPTS</a></li>
    <li class="nav-item"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#votes" role="tab" aria-controls="votes" aria-selected="false">VOTEHEAD DISTRIBUTION</a></li>
</ul>
<div class="tab-content" id="myTabContent">
    <div class="tab-pane fade show active" id="fee" role="tabpanel" aria-labelledby="home-tab">
        <div class="container" style="margin:1px;padding:1px;"><input type="hidden" name="txtToken" id="txtToken" value="<?php echo $form_token;?>">
            <div class="form-row"><div class="col-md-6 divcontent">
                <div class="form-row"><div class="col-md-12" style="text-align:right;margin:0;padding:4px;"><b>Today: <?php print date("D d F, Y"); ?></b><hr/></div></div>
                <div class="form-row">
                    <div class="col-md-4"><label for="txtRecNo">Receipt No. *</label><input type="text" name="txtRecNo" size="12" maxlength="5" value="Auto" readonly></div>
                    <div class="col-md-4"><label for="txtAdmNo">Admission No. *</label><Input name="txtAdmNo" id="txtAdmNo" size=7 type="text" readonly value="<?php echo $stud[0];?>"></div>
                    <div class="col-md-4"><label for="dtpDate">Fees Received On. *</label><input type="text" size="15" name="dtpDate" readonly value="<?php echo $curdate; ?>" id="dtpDate" class="tcal"></div>
                </div><br><div class="form-row">
                    <div class="col-md-4"><label for="cboPaidBy">Fee Paid By *</label><SELECT name="cboPaidBy" id="cboPaidBy" size="1"><Option selected>Parent</option><Option>Bursary</option>
                    <Option>Guardian</option><Option>Well Wisher</option></SELECT></div>
                    <div class="col-md-3"><label for="txtBursNo">Bursary No.</label><input type="text" name="txtBursNo" id="txtBursNo" value="" onchange="loadBursaryBal(this)"
                    size=7 maxlength=4 onkeyup="checkInput(1,this)"></div>
                    <div class="col-md-5" style="background-color:#ccc;"><label for="txtBursBal">Bursary Balance (KShs.)</label><input type="text" name="txtBursBal" id="txtBursBal" readonly value="0.00"
                    style="text-align:right;"></div>
                </div><div class="form-row">
                    <div class="col-md-4"><label for="cboPytFrm">Mode of Payment *</label><SELECT name="cboPytFrm" id="cboPytFrm" size=1 onchange="checkPyt(this)"><option value="CASH">Cash
                    </option><option value="CHEQUE">Cheque</option><option value="DIRECT BANKING" selected>Direct Banking</option><option value="KIND">Kind</option><option value="MFEES">
                    M-Fees</option><option value="MONEY ORDER">Money Order</option></SELECT></div>
                    <div class="col-md-3"><label for="cboPytFrm" style="font-size:10px;">Trans/Cheque No.</label><input name="txtCheNo" id="txtCheNo" size=15 maxlength=15 onkeyup="validateTransNo(this)"
                      onchange="verifyDuplicateTransNo(this)"></div>
                    <div class="col-md-5"><label for="cboBank" style="font-size:10px;">Banker(For Cheque/ Money Order)</label><SELECT name="cboBank" id="cboBank" size=1 readonly><option value="0" selected>None</option>
                      <?php echo $optBanks;?></SELECT></div>
                </div><div class="form-row" id="spKind" style="background:#ffe6e6;display:none;">
                    <div class="form-row"><div class="col-md-12 divheadings">DESCRIPTION OF FEES RECEIVED IN KIND</div></div>
                    <div class="form-row"><div class="col-md-4"><label for="txtIDNo"><b>ID No.</b></label><input type="text" name="txtIDNo" id="txtIDNo" maxlength="10" value="" readonly placeholder="ID No."
                      onkeyup="checkInput(1,this)" onchange="showKindDet(this)"></div><div class="col-md-8"><label for="txtParent"><b>Parent/Guardian Names</b></label><input type="text" name="txtParent" id="txtParent"
                      maxlength="40" value="" readonly placeholder="Names of Guardian/ Parent"></div>
                    </div><div class="form-row">
                      <div class="col-md-4"><label for="txtTelNo"><b>Tel No.</b></label><input type="text" name="txtTelNo" id="txtTelNo" maxlength=13 value="" readonly placeholder="+2547"></div><div class="col-md-8">
                      <label for="txtAddress"><b>Postal Address</b></label><input type="text" name="txtAddress" id="txtAddress" maxlength=75 value="" readonly placeholder="P.O Box"></div>
                    </div><div class="form-row">
                      <div class="col-md-12"><label for="txtKind"><b>Narration of Fee Paid in Kind</b></label><textarea name="txtKind" id="txtKind" type="text" rows=2 placeholder="2 90KG BAGS OF MAIZE @4,000"
                        maxlength=150 readonly style="text-transform:uppercase;"></textarea></div>
                    </div>
                </div><BR><div class="form-row">
                    <?php $a=0;
                      foreach($novotes as $nv){
                        $acc=$nv->valAcc(); print "<div class=\"col-md-4\"><label>".$nv->valName()." Fees</label><input type=\"number\" name=\"txtFee_$a\" id=\"txtFee_$a\" maxlength=11 style=\"text-align:right;\"
                        value=\"".($acc==$stud[7]?0:number_format(floatval($balmisc),2))."\" onkeyup=\"ttlFee($noacs)\" onblur=\"calcVotes($a,$acc)\"></div>";             $a++;
                      }
                    ?><div class="col-md-4"><label for="txtBC">Bank Charges</label><INPUT type="number" name="txtBC" id="txtBC" size=10 maxlength=11 style="text-align:right;" value="0.00" readonly
                      onkeyup="ttlFee(<?php echo"$noacs";?>)"></div>
                    <div class="col-md-4" style="background-color:#ccc;"><label for="txtTtlFee">Total Amount Received</label>
                    <input type="text" name="txtTtlFee" id="txtTtlFee" size=13 value="<?php print number_format(floatval($balmisc),2);?>" readonly style="text-align:right;font-weight:bold;"></div>
                    <div class="col-md-8"><TEXTAREA name="txtWords" id="txtWords" rows="3" style="border:0px;font-weight:bold;background:inherit;color:#f0f;" readonly>Zero Shillings and Zero Cents</textarea></div>
                </div><div class="form-row divsubheading">
                    <div class="col-md-6">Main Bal to Distribute <input type="text" name="txtVoteBal_0" id="txtVoteBal_0"
                    value="0.00" style="text-align:center;font-weight:bold;background:inherit;color:#fff;width:100px;" readonly></div>
                    <div class="col-md-6" style="<?php echo ($noacs==1?'display:none;':'');?>">Misc Bal to Distribute <input
                    type="text" name="txtMVoteBal_0" id="txtMVoteBal_0" value="0.00" style="text-align:center;font-weight:bold;background-color:inherit;color:#fff;width:100px;" readonly></div>
                </div>
            </div><div class="col-md-6 divcontent">
                <div id="balShow" style="background:#eee;margin:5px;"><div class="row" style="color:#00f;background:linear-gradient(to right,#eee,#999);padding:1px;text-align:center;">
                  <div class="col-md-3" style="padding:1px;">Main Arrears<br><?php print number_format(floatval($stud[3]),2);?></div><div class="col-md-3" style="padding:1px;">Surcharged Medical<br>
                  <?php print number_format(floatval($stud[5]),2);?></div>
                  <div class="col-md-3" style="padding:1px;">Extra Uniform<br><?php print number_format(floatval($stud[6]),2);?></div><div class="col-md-3" style="padding:1px;<?php echo ($noacs==1?
                  "display:none;":"");?>">Misc Arrears<br><?php echo number_format(floatval($stud[4]),2);?></div>
                </div><div class="row">
                <?php
                    $table='<div class="form-row" style="border-radius:5px 5px 15px 15px;padding:5px;background:#eee;">'; $a=0;
                    foreach($novotes as $nv){
                      $acc=intval($nv->valAcc());     $tcnv=$cnv=intval($nv->valVotes()); if($acc==intval($stud[7])) $acbal=floatval($stud[12]); else $acbal=floatval($stud[16]);
                      print "<div class=\"col-md-".($noacs==1?8:6)."\"><table class=\"table table-condensed table-striped table-sm table-hover table-bordered\"><thead class=\"thead-dark\">
                      <tr style=\"letter-spacing:2px;word-spacing:3px;font-size:0.9rem;\"><th colspan=\"2\">FY$finyr ".$nv->valName()."</th><tr><tr><th>VOTEHEAD</th><th>BALANCE</th></tr>
                      </thead>"; $i=0;
                      $table.="<div class=\"col-md-6\"><table class=\"table table-condensed table-striped table-sm table-hover table-borderless table-responsive\"><thead
                      class=\"thead-dark\"><tr style=\"letter-spacing:2px;word-spacing:3px;\"><th colspan=\"3\">FY$finyr ".$nv->valName()." BALANCES</th><tr><tr><th>VOTEHEAD</th><th>
                      BALANCE</th><th class=\"vote\">AMOUNT</th></tr></thead>";
                      if($acc===intval($stud[7])){//Main A/C  -> prepayment counter at 0, arrear 1 .....
                        $table.="<tr><td>ARREARS B/F</td><td><input type=\"hidden\" name=\"txtVote_$a"."_1\" id=\"txtVote_$a"."_1\" value=\"$spevote[0]\" size=3><input type=\"text\" name=\"txtBal_$a"."_1\"
                        id=\"txtBal_$a"."_1\" style=\"text-align:right;background:#eee;\" value=\"".number_format(floatval($stud[3]),2)."\"></td><td class=\"vote\"><input type=\"text\" name=\"txtAmt_$a"."_1\"
                        id=\"txtAmt_$a"."_1\" readonly style=\"text-align:right;background:#eee;\" value=\"0.00\"></td></tr>"; $tcnv++;
                        $table.="<tr><td>SURCHARGED MEDICAL FEE</td><td><input type=\"hidden\" name=\"txtVote_$a"."_2\" id=\"txtVote_$a"."_2\" value=\"$spevote[2]\"><input type=\"text\" name=\"txtBal_$a"."_2\"
                        id=\"txtBal_$a"."_2\" readonly style=\"text-align:right;background:#eee;\" value=\"".number_format(floatval($stud[5]),2)."\"></td><td><input type=\"text\" name=\"txtAmt_$a"."_2\" id=\"txtAmt_$a"."_2\"
                        style=\"text-align:right;background:#eee;\" value=\"0.00\"></td></tr>"; $i=3; $tcnv++;
                        if ($acc===intval($stud[8])){$table.="<tr><td>EXTRA UNIFORM</td><td><input type=\"hidden\" name=\"txtVote_$a"."_$i\" id=\"txtVote_$a"."_$i\" value=\"$spevote[3]\"><input readonly type=\"text\"
                        name=\"txtBal_$a"."_$i\" id=\"txtBal_$a"."_$i\" style=\"text-align:right;background:#eee;\" value=\"".number_format(floatval($stud[6]),2)."\"></td><td><input type=\"text\" name=\"txtAmt_$a"."_$i\"
                        id=\"txtAmt_$a"."_$i\" readonly style=\"text-align:right;background:#eee;\" value=\"0.00\"></td></tr>"; $i++; $tcnv++;}
                        $table.="<tr><td>REFUNDS</td><td class=\"vote\"><input type=\"hidden\" name=\"txtVote_$a"."_$i\" id=\"txtVote_$a"."_$i\" value=\"$acc-2\"></td><td><input type=\"text\" name=\"txtAmt_$a"."_$i\"
                        id=\"txtAmt_$a"."_$i\" readonly style=\"text-align:right;\" value=\"0.00\"></td></tr>"; $i++; $tcnv++;
                      }else{
                        $table.="<tr><td>ARREARS B/F</td><td><input type=\"text\" name=\"txtBal_$a"."_0\" id=\"txtBal_$a"."_0\" readonly style=\"text-align:right;background:#eee;\" value=\"".number_format(floatval($stud[4]),
                        2)."\"><input type=\"hidden\" name=\"txtVote_$a"."_0\" id=\"txtVote_$a"."_0\" value=\"$spevote[1]\"></td><td><input type=\"text\" name=\"txtAmt_$a"."_0\" id=\"txtAmt_$a"."_0\"
                        style=\"text-align:right;background:#eee;\" readonly 	value=\"0.00\"></td></tr>"; $i=1; $tcnv++;
                        if ($acc==$stud[8]){
                          $table.="<tr><td>EXTRA UNIFORM</td><td><input type=\"text\" name=\"txtBal_$a"."_$i\" id=\"txtBal_$a"."_$i\" style=\"text-align:right;background:#eee;\" value=\"".number_format(floatval($stud[6]),2)."\"
                          readonly><input type=\"hidden\" name=\"txtVote_$a"."_$i\" id=\"txtVote_$a"."_$i\" value=\"$spevote[3]\"></td><td><input type=\"text\" name=\"txtAmt_$a"."_$i\" id=\"txtAmt_$a"."_$i\" readonly
                          style=\"text-align:right;background:#eee;\" value=\"0.00\"></td></tr>";       $i++;  $tcnv++;
                        }
                      }foreach($balances as $bal)if($acc==($bal->valAcc())){
                        print "<tr><td>".$bal->valVName()."</td><td align=\"right\">".number_format($bal->valBalTTl(),2)."</td></tr>";
                        $table.="<tr><td>".$bal->valVName()."</td><td align=\"center\"><INPUT type=\"hidden\" size=\"3\" name=\"txtVote_$a"."_$i\"  id=\"txtVote_$a"."_$i\" value=\"$acc-".$bal->valVSNo()."\"><input
                        name=\"txtBal_$a"."_$i\" id=\"txtBal_$a"."_$i\" type=\"text\" style=\"text-align:right;background:#eee;\" readonly value=\"".number_format(floatval($bal->valBalTTl()),2)."\"></td><td><input
                        name=\"txtAmt_$a"."_$i\" id=\"txtAmt_$a"."_$i\" type=\"text\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(0,this)\" onchange=\"calcTotal($a,$acc,$tcnv,$i)\"></td></tr>"; $i++;
                      }print"<tr><td><b>Total Balance</b></td><td align=\"right\"><b>".number_format($acbal,2)."</b></td></tr></table></div>";
                      if($acc===intval($stud[7])){
                        $table.="<tr><td>FY".($finyr+1)." PREPAYMENT</td><td><INPUT type=\"hidden\" size=\"3\" name=\"txtVote_$a"."_0\" id=\"txtVote_$a"."_0\" onkeyup=\"checkInput(0,this)\" value=\"$acc-4\"></td><td>
                        <input name=\"txtAmt_$a"."_0\" id=\"txtAmt_$a"."_0\" type=\"text\" style=\"text-align:right;\" value=\"0.00\"></td></tr>"; $i++;
                      } $cls=explode('-',$stud[2]);
                      $table.="<tr><td><b>Total Amount</b></td><td class=\"vote\"><input name=\"txtTtlBal_$a\" id=\"txtTtlBal_$a\" type=\"text\" style=\"text-align:right;font-weight:bold;background:#eee;\" value=\"".
                      number_format($acbal,2)."\" readonly></td><td><input name=\"txtTtlAmt_$a\" id=\"txtTtlAmt_$a\" type=\"text\" style=\"text-align:right;font-weight:bold;background:#eee;\" value=\"0.00\" readonly>
                      <input type=\"hidden\" name=\"txtLimit_$a\" id=\"txtLimit_$a\" value=\"$a-$cnv-$cls[0]-$acc-$stud[7]-$stud[8]-$noacs-$i-$stud[17]\"></td></tr></table></div>"; $a++;
                    }print "</div>";
                ?></div>
            </div></div>
        </DIV>
    </div>
  <div class="tab-pane fade" id="votes" role="votes" aria-labelledby="profile-tab">
    <?php
        print $table;
        print "</div><div class=\"form-row\" style=\"letter-spacing:2px;word-spacing:3px;background-color:#555;color:#fff;border-radius:15px;\"><div class=\"col-md-6\" style=\"text-align:center;\"><label
        for=\"txtVoteBal_1\">Balance To Distribute</label><input type=\"text\" name=\"txtVoteBal_1\" id=\"txtVoteBal_1\" value=\"0.00\" style=\"font-weight:bold;background-color:#555;text-align:center;
        color:#fff;width:150px;\" readonly></div>";
        print "<div class=\"col-md-6\" style=\"text-align:center;".($noacs==01?"display:none;":"")."\"><label for=\"txtMVoteBal_1\">Balance To Distribute</label><input type=\"text\" name=\"txtMVoteBal_1\"
        id=\"txtMVoteBal_1\" value=\"0.00\" style=\"font-weight:bold;background-color:#555;color:#fff;text-align:center;width:150px;\" readonly></div>";
        print "</div>";
    ?>
</div>
<hr><div class="form-row"><div class="col-md-6" style="text-align:center;"><button type="submit" name="btnSaveFee" id="CmdSave" class="btn btn-primary btn-md" style="font-weight:bold;font-size:1.5rem;">
SUBMIT FEE RECORD</button></div><div class="col-md-6" style="text-align:right;"><a href="studfee.php"><button type="button" name="btnClose" class="btn btn-info btn-md">Close/ Cancel</button></a></div></div></div>
</form></div><script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/feerec.js"></script>
<script type="text/javascript">
<?php
    $bal='';
    if (isset($balances)){$i=0;foreach($balances as $b){$bal.=($i==0?"":",")."new Balances(".$b->valVSNo().",".$b->valAcc().",".$b->valBalT1().",".$b->valBalT2().",".$b->valBalT3().",".$b->valBalTTl().")"; $i++; }
    }if(strlen($bal)>0) print "balances.push($bal); ";  $bal='';
    if (isset($novotes)){$i=0; foreach($novotes as $b){$bal.=($i==0?"":",")."new NoVotes(".$b->valAcc().",".$b->valVotes().")"; $i++;	}
    }if(strlen($bal)>0) print "novotes.push($bal);"; print "</script>"; footer();
?>
