<?php
  include_once('shanam.php');
  $s=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; $s=explode("-",$s);
  mysqli_multi_query($conn,"SELECT struadd,struedit,struview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT finyr FROM ss;")  or die(mysqli_error($conn)." Click <a
  href=\"feestruct.php\">HERE</a> to try again.");  $stad=$sted=$stvi=$s[0]=$s[1]=$i=0; $finyr=date('Y');
  do{if($rs=mysqli_Store_result($conn)){if($i==0){if (mysqli_num_rows($rs)==1) list($stad,$sted,$stvi)=mysqli_fetch_row($rs);} else list($finyr)=mysqli_fetch_row($rs); mysqli_free_result($rs);}$i++;
  }while(mysqli_next_result($conn));
  if (isset($_POST['btnSaveFS'])){
    $sql=''; $data=isset($_POST['txtData'])?sanitize($_POST['txtData']):'0-0-0-0';     $data=explode('-',$data);//[0] yr, [1] lvlno, [2] A/C No. [3] No. of votes
    for($i=0;$i<$data[3];$i++){
        $votno=isset($_POST['txtVote_'.$i])?sanitize($_POST['txtVote_'.$i]):0; $t1=isset($_POST['txtT1_'.$i])?sanitize($_POST['txtT1_'.$i]):0;    $ot1=isset($_POST['txtOT1_'.$i])?sanitize($_POST['txtOT1_'.$i]):0;
        $t2=isset($_POST['txtT2_'.$i])?sanitize($_POST['txtT2_'.$i]):0; $ot2=isset($_POST['txtOT2_'.$i])?sanitize($_POST['txtOT2_'.$i]):0; $t3=isset($_POST['txtT3_'.$i])?sanitize($_POST['txtT3_'.$i]):0;
        $ot3=isset($_POST['txtOT3_'.$i])?sanitize($_POST['txtOT3_'.$i]):0;  $t1=preg_replace('/[^0-9^\.]/','',$t1); $t2=preg_replace('/[^0-9^\.]/','',$t2); $t3=preg_replace('/[^0-9^\.]/','',$t3);
        $t3+=$t2+$t1;  $t2+=$t1;  $ot1=preg_replace('/[^0-9^\.]/','',$ot1);    $ot2=preg_replace('/[^0-9^\.]/','',$ot2);  $ot3=preg_replace('/[^0-9^\.]/','',$ot3);   $ot3+=$ot2+$ot1; $ot2+=$ot1;
        if ($t3!=$ot3 || $t2!=$ot2 || $t1!=$ot1){$sql.="UPDATE acc_feestruct SET t1=$t1,t2=$t2,t3=$t3 WHERE yr LIKE '$data[0]' and grpno LIKE '$data[1]' and voteno LIKE '$votno';";}
    }$s[0]=1; if(strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)." Click <a href=\"feestruct.php\">HERE</a> to try again."); $i=0;
        do{$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn));     $i=$i>1?1:0;  $s[0]=1;    $s[1]=$i;
    }else $s[1]=0;
  }elseif(isset($_POST['btnRefreshVotes'])){//Delete obsolete and update with new votes
    $data=isset($_POST['txtData'])?sanitize($_POST['txtData']):'0-0-0-0';     $data=explode('-',$data); //[0] yr, [1] lvlno, [2] A/C No. [3] No. of votes
    mysqli_multi_query($conn,"INSERT IGNORE INTO acc_feestruct(yr,grpno,voteno) SELECT $finyr,l.grpno,v.sno FROM acc_feegrps l CROSS JOIN  acc_votes v WHERE v.fs_defined=1 and v.markdel=0 and v.acc IN (select acno FROM
    acc_voteacs WHERE stud_assoc=1 and fee_assoc=1); DELETE from acc_feestruct WHERE voteno NOT IN (SELECT voteno FROM acc_votes where markdel=0 and fs_defined=1) and yr LIKE '$data[0]';") or die(mysqli_error($conn).
    ". Click <a href=\"feestruct.php\">HERE</a> to go back."); do{$s[1]+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $s[0]=1;
  }$ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):1; $grp=isset($_POST['cboGrp'])?sanitize($_POST['cboGrp']):'%';
  headings('<link href="tpl/css/headers.css" rel="stylesheet"/><link href="tpl/css/inputsettings.css" rel="stylesheet"/>',$s[0],$s[1],2);
?><div class="head"><form method="post" action="feestruct.php" name="frmHead"><a href="pupil_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a> View <SELECT name="cboAC" id="cboAC"
  size="1">
<?php
  $grpname="ALL"; $optGrp=""; $i=$nonsfs=0; //nonsfs - non student fee structure
  mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and fee_assoc=1 Order BY acno ASC; SELECT grpno,descr FROM acc_feegrps Order BY grpno ASC;");
  do{
    if($rs=mysqli_store_result($conn)){
      if ($i==0) while ($det=mysqli_fetch_row($rs)){if ($ac==$det[0]){$accno[]=$det[0]; $accname[]=strtoupper($det[1]);} print "<option value=\"$det[0]\" ".($ac==$det[0]?"selected":"").">$det[1]</option>";
      }else while ($det=mysqli_fetch_row($rs)){if($grp==$det[0]) $grpname=strtoupper($det[1]); $optGrp.="<option value=\"$det[0]\" ".($grp==$det[0]?"selected":"").">$det[1]</option>";} mysqli_free_result($rs);
    }$i++;
  }while(mysqli_next_result($conn));
?></select> Fee Structure of &nbsp;<select name="cboGrp" id="cboGrp" size="1"><option <?php echo ($grp=="%"?"selected":"")." value=\"%\">All</option>$optGrp";?></select> Students&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button
type="SUBMIT" name="btnView">Student Fee Structures</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="SUBMIT" name="btnRefreshVotes">Refresh Voteheads</button></form></div>
<div class="container" style="margin:auto;padding:0 5px 0 5px;width:fit-content;background-color:#dedede;border:1px dotted #eee;border-radius:10px;"><h4 style="font-weight:strong;
letter-spacing:4px;word-spacing:7px;background-color:#000;color:#fff;text-align:center;border-radius:10px 10px 0 0;">FEE STRUCTURE DEFINITION</h4><div class="col-md-12">
<?php $an=0;
  foreach($accno as $ac){
    print "<table class=\"table table-striped table-sm table-hover table-bordered\" style=\"margin:center;font-size:0.8rem;\"><CAPTION style=\"font-size:12pt;font-weight:bold;letter-spacing:4px;word-spacing:7px;\">
    $accname[$an]"." - $grpname FEE STRUCTURES</CAPTION><tr class=\"nohover\"><th>Level</th>";
    $rs=mysqli_query($conn,"SELECT sno,abbr FROM acc_votes WHERE acc LIKE '$ac' and fs_defined=1 and markdel=0"); $vot='';
    if(mysqli_num_rows($rs)>0) while ($fs=mysqli_fetch_row($rs)){$vot.=",SUM(IF(f.`voteno`='{$fs[0]}', f.`t3`, 0)) as `{$fs[1]}`"; print "<th>$fs[1]</th>";}
    print"<th>Total</th><th>View</th><th>Edit</th></tr>";
    $sql="SELECT f.yr,f.grpno,c.descr $vot FROM acc_feestruct f Inner Join acc_votes v on (f.voteno=v.sno) Inner Join acc_feegrps c On (f.grpno=c.grpno) GROUP BY f.yr,v.acc,f.grpno,c.descr,v.markdel HAVING f.yr LIKE
    '$finyr' and v.acc LIKE '$ac' and f.grpno LIKE '$grp' and v.markdel=0";    $rsFeeStr=mysqli_query($conn,$sql); $nofs=mysqli_num_rows($rsFeeStr);
    if ($nofs>0) while($fs=mysqli_fetch_row($rsFeeStr)){
      $ttl=$i=0; $data=''; print "<tr>";
      foreach($fs as $s){if($i<3){if($i<2)$data.='-'.$s; if($i==2)print "<td>$s</td>";} else{$ttl+=(float)$s; print"<td align=\"right\">".number_format($s,2)."</td>";} $i++;}
      print "<td align=\"right\">".number_format($ttl,2)."</td><td align=\"center\"><a href=\"#\" onclick=\"showFS('0$data',$ac)\">V I E W</a></td><td align=\"center\"><a
      href=\"#\" onclick=\"canedit('1$data',$ac,$sted)\">E D I T</a></td></tr>";
    }else print "<tr><td colspan=10>NO FEE STRUCTURE DEFINED</td></tr>";
    print "</table>"; $an++;
  }echo '</div><div class="col-md-12" style="border:1px dotted #00a;border-radius:8px;background-color:#e6e6e6;color:#000;font-size:9pt;padding:2px;" id="divFeeStruct">Fee '
  . 'Structure Details</div></div></div>';
  echo '<script type="text/javascript" src="tpl/js/showfeestruct.js"></script><script type="text/javascript" src="tpl/js/printthis.js"></script>';
  mysqli_close($conn); footer();
?>
