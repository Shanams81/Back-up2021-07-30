<?php
	include_once("shanam.php");
	$action=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0'; $action=explode('-',$action); $act=0; //0 - Show to fee transfers, 1 - Start Fees Transfer procee, 2 - Delete Fees
	$act=isset($_POST['txtAction'])?sanitize($_POST["txtAction"]):0;  $ac=isset($_POST['CboAC'])?sanitize($_POST['CboAC']):1;
	$sdate=isset($_POST['dtpFrom'])?sanitize($_POST['dtpFrom']):("01-01-".date("Y"));	$edate=isset($_POST['dtpTo'])?sanitize($_POST['dtpTo']):date("d-m-Y");
	if (isset($_POST['cmdSave'])){
		$recno=isset($_POST['txtReceiptNo'])?sanitize($_POST['txtReceiptNo']):"0"; $soadmno=isset($_POST['txtSourceAdmNo'])?sanitize($_POST['txtSourceAdmNo']):"-";
		$desadmno=isset($_POST['txtDestAdmNo'])?sanitize($_POST['txtDestAdmNo']):"-";		$ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):1;
		$date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date("d-m-Y");				$type=isset($_POST['cboType'])?sanitize($_POST['cboType']):1;
		$rmks=isset($_POST['txtRmks'])?strtoupper(sanitize($_POST['txtRmks'])):"";			$transamt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0;
		$transamt=preg_replace("/[^0-9^\.]/","",$transamt); 	$date=preg_split('/\-/',$date); $inclref=isset($_POST["chkRefunds"])?$_POST["chkRefunds"]:0; $act=2;
		if (strlen($recno)!=0 && strcasecmp($recno,"%")!=0 && strlen($rmks)>14 && ($type!=2 && $transamt>0) && $soadmno==$desadmno){
			$rsStud=mysqli_query($conn,"SELECT admno FROM stud s INNER JOIN form sf USING (admno,curr_year) WHERE s.admno IN ($soadmno,$desadmno)");
			$i=mysqli_num_rows($rsStud); 	mysqli_free_result($rsStud);
			if ($i<2){
				print "<h4 style=\"color:#f00;font-size:14pt;letter-spacing:2px;word-spacing:4px;\">Sorry, Ensure the admission number $soadmno and $desadmno are for validly registered students for the the
				transfer to be effected.<br>Click <a href=\"transferfees.php\">HERE</a> to go back.";			exit(0);
			}$amt=$prep=$arr=$ref=0;
				if ($ac==1){//Main account transfer
					$rsFee=mysqli_query($conn,"SELECT f.paidby,f.pytfrm,f.cheno,f.burno,(i.amt-i.transfer-i.refunds) as fee,i.spemed,i.arrears,i.prep,i.refunds FROM acc_incofee f Inner Join acc_incorecno0 USING (sno) WHERE
					i.recno LIKE '$recno' and f.admno LIKE '$soadmno'"); 	$i=mysqli_num_rows($rsFee); if($i>0) list($paidby,$pytfrm,$cheno,$pytno,$amt,$med,$arr,$prep,$ref)=mysqli_fetch_row($rsFee);
				}else{// Misc Fee Transfer
					$rsFee=mysqli_query($conn,"SELECT f.pytfrm,f.cheno,f.bursno,(i.amt-i.transfer) as fee,i.arrears FROM acc_incofee f Inner Join acc_incorecno0 USING (sno)  WHERE i.recno LIKE '$recno' and i.admno LIKE
					'$soadmno'");			$i=mysqli_num_rows($rsFee); if($i>0) list($pytfrm,$cheno,$pytno,$amt,$arr)=mysqli_fetch_row($rsFee);
				}mysqli_free_result($rsFee);
				if ($i==0){
					print "Sorry, the ".($ac==1?"Main":"Miscellaneous")." Account receipt number $recno paid by student with admission number $soadmno  does not exist<br>Click <a href=\"transferfees.php\">HERE</a> to go back.";
					exit(0);
				}/*if ($type==1){//Whole fee transfer
						if(mysqli_query($conn,"INSERT INTO acc_feetransfer(transno,transdate,recieptno,fromadmno,receiveradmno,amt,rmks,ac,transtype) values(0,'$date[2]-$date[1]-$date[0]','$recno','$soadmno','$desadmno','$amt',
						'$rmks','$ac','$type')")){
							if ($ac=="1"){
							 	mysqli_multi_query($conn,"UPDATE acc_incorecno0 SET arrears=0,spemed=0,prep=0,refund=0,unifrm=0 WHERE recno LIKE '$recno'; UPDATE acc_incorecno1 f Inner Join acc_incofee i USING (sno) SET f.arrears=0,
								f.spemed=0,i.unifrm WHERE i.admno LIKE '$soadmno' and i.sno IN (SELECT sno FROM acc_incorecno0 WHERE recno LIKE '$recno');UPDATE acc_incofee i Inner Join acc_incorecno0 f USING (sno) SET i.admno='$desadmno'
								WHERE f.recno LIKE '$recno'; DELETE FROM acc_incoprep WHERE recno LIKE '$recno'; UPDATE class c Inner Join acc_arrrefclr a On (c.admno=a.admno and c.curr_year=a.arr_year) SET c.bbf=c.bbf+a.amt WHERE a.acc=1
								and a.recno LIKE '$recno' and c.admno LIKE '$soadmno'; UPDATE class c Inner Join acc_arrrefclr a On (c.admno=a.admno and c.curr_year=a.arr_year) Inner Join acc_incorecno1 i ON (a.recno=i.recno and a.ac=i.acc)
								Inner Join acc_incofee f ON (i.sno=f.sno) SET c.miscbf=c.miscbf+a.amt WHERE a.ac!=1 and i.sno IN (SELECT sno FROM acc_incorecno0 WHERE markdel=0 and recno LIKE '$recno') and c.admno LIKE '$soadmno';
								DELETE FROM acc_arrrefclr WHERE recno LIKE '$recno' or recno IN (SELECT m.recno FROM acc_incorecno1 m Inner Join acc_incofee f USING (sno) Inner Join acc_incorecno0 i USING (sno) WHERE i.recno LIKE '$recno');");
								$i=mysqli_affected_rows($conn); while(mysqli_next_result($conn)){$i+=mysqli_affected_rows($conn);}//flush multi_queries
								if ($i>=1 && ($med>0 || $arr>0)) mysqli_query($conn,"UPDATE form SET bbf=bff+$arr,specialmedical=specialmedical+$med WHERE admno
								LIKE '$soadmno' and curr_year IN (SELECT finyr FROM ss)");
						 		header("location:votedistredit.php?action=$desadmno-$recno-1");
							}else{
							 	mysqli_query($conn,"UPDATE acc_miscfeepyts SET payeesno='$desadmno',vote1=vote1+arrears,arrears=0 WHERE recipetno LIKE '$recno'");
								$i=mysqli_affected_rows($conn);
								if ($i==1 && $arr>0) mysqli_query($conn,"UPDATE form SET miscbf=misbf+$arr WHERE admno LIKE '$soadmno' and curr_year IN (SELECT
								finyr FROM ss)");		header("location:miscvotedistredit.php?action=$desadmno-$recno-1");
							}
						}else{print "<h4 style=\"color:#f00;font-size:14pt;letter-spacing:2px;word-spacing:4px;\">Sorry, Receipt transfer was not sucessful.</h4><br> Click <a href=\"transferfees.php\">HERE</a> to go back.";
						 	exit(0);
						}
					}elseif ($type==2){//Part fee fee transfer
						if ($ac==1){
							if($inclref==1) $bal=$amt+$prep-$arr-$med+$ref; else $bal=$amt+$prep-$arr-$med;
						} else $bal=$amt-$arr; $amttrans=$transamt;
						if($transamt<$bal){//Only transfer if amount is less than fee paid
							mysqli_query($conn,"INSERT INTO acc_feetransfer(transno,transdate,recieptno,fromadmno,receiveradmno,amt,rmks,ac,transtype) values(0,
							'$date[2]-$date[1]-$date[0]','$recno','$soadmno','$desadmno','$transamt','$rmks','$ac','$type')"); $i=mysqli_affected_rows($conn);
							if($i>0 ){//update only if transfer record is sucessfully inserted
								if ($ac==1){//Main Account
									$rsFee=mysqli_query($conn,"SELECT sf.bbf,sf.specialmedical,f.tution,f.boarding,f.activity,f.pemolu,f.ltt,f.rmi,f.ewc,f.cont,
									f.eif,f.caut,f.insure,f.medical,f.vote1,f.vote2,f.vote3,f.vote4,f.vote5,f.vote6,f.vote7,f.vote8,f.vote9,f.vote10,f.vote11,
									f.vote12 FROM Acc_feerec f Inner Join form sf USING (admno) WHERE f.recieptno LIKE '$recno' and sf.curr_year IN (SELECT finyr
									FROM ss)");
									list($bbf,$sme,$tui,$boa,$act,$pem,$ltt,$rmi,$ewc,$cont,$eif,$caut,$ins,$med,$v1,$v2,$v3,$v4,$v5,$v6,$v7,$v8,$v9,$v10,$v11,
									$v12)=mysqli_fetch_row($rsFee);		mysqli_free_result($rsFee);
									if($ref>0 && $inclref==1){//Transfer refunds incase of form four
										if ($transamt<$ref){// Amount transfered is less than refundable amount
											mysqli_query($conn,"UPDATE acc_feerec SET refunds=refunds-$transamt,transfer=transfer+$transamt WHERE recieptno LIKE
											'$recno'");		$transamt=0;
										}else{
											mysqli_query($conn,"UPDATE acc_feerec SET refunds=0,transfer=transfer+$ref WHERE recieptno LIKE '$recno'");
											$transamt-=$ref;
										}
									}
									if ($prep>0){//There is prepayment
										if ($transamt<$prep){//Money to be transfered is less than amount prepaid
											$rsFee=mysqli_query($conn,"SELECT f.tution,f.boarding,f.activity,f.pemolu,f.ltt,f.rmi,f.ewc,f.cont,f.eif,f.insure,
											f.medical,f.vote1,f.vote2,f.vote3,f.vote4,f.vote5,f.vote6,f.vote7,f.vote8,f.vote9,f.vote10,f.vote11,f.vote12 FROM
											Acc_prep f WHERE f.recieptno LIKE '$recno'");
											list($ptu,$pbo,$pac,$ppe,$plt,$prm,$pew,$pco,$pei,$pin,$pme,$pv1,$pv2,$pv3,$pv4,$pv5,$pv6,$pv7,$pv8,$pv9,$pv10,$pv11,
											$pv12)=mysqli_fetch_row($rsFee);	mysqli_free_result($rsFee);
											$sql="UPDATE acc_prep SET amt=amt-$transamt ";
											if($ptu>0){if ($ptu>$transamt){$sql.=",tuition=tuition-$transamt"; 		$transamt=0;}else{$sql.=",tuition=0"; 	$transamt-=$ptu;}}
											if($pbo>0){if ($pbo>$transamt){$sql.=",boarding=boarding-$transamt"; 	$transamt=0;}else{$sql.=",boarding=0"; 	$transamt-=$pbo;}}
											if($pac>0){if ($pac>$transamt){$sql.=",activity=activity-$transamt"; 	$transamt=0;}else{$sql.=",activity=0"; 	$transamt-=$pac;}}
											if($ppe>0){if ($ppe>$transamt){$sql.=",pemolu=pemolu-$transamt"; 		$transamt=0;}else{$sql.=",pemolu=0"; 	$transamt-=$ppe;}}
											if($plt>0){if ($plt>$transamt){$sql.=",ltt=ltt-$transamt"; 				$transamt=0;}else{$sql.=",ltt=0"; 		$transamt-=$plt;}}
											if($prm>0){if ($prm>$transamt){$sql.=",rmi=rmi-$transamt"; 				$transamt=0;}else{$sql.=",rmi=0"; 		$transamt-=$prm;}}
											if($pew>0){if ($pew>$transamt){$sql.=",ewc=ewc-$transamt"; 				$transamt=0;}else{$sql.=",ewc=0"; 		$transamt-=$pew;}}
											if($pco>0){if ($pco>$transamt){$sql.=",cont=cont-$transamt"; 			$transamt=0;}else{$sql.=",cont=0"; 		$transamt-=$pco;}}
											if($pei>0){if ($pei>$transamt){$sql.=",eif=eif-$transamt"; 				$transamt=0;}else{$sql.=",eif=0"; 		$transamt-=$pei;}}
											if($pin>0){if ($pin>$transamt){$sql.=",insure=insure-$transamt"; 		$transamt=0;}else{$sql.=",insure=0"; 	$transamt-=$pin;}}
											if($pme>0){if ($pme>$transamt){$sql.=",medical=medical-$transamt"; 		$transamt=0;}else{$sql.=",medical=0"; 	$transamt-=$pme;}}
											if($pv1>0){if ($pv1>$transamt){$sql.=",vote1=vote1-$transamt"; 			$transamt=0;}else{$sql.=",vote1=0"; 	$transamt-=$pv1;}}
											if($pv2>0){if ($pv2>$transamt){$sql.=",vote2=vote2-$transamt"; 			$transamt=0;}else{$sql.=",vote2=0"; 	$transamt-=$pv2;}}
											if($pv3>0){if ($pv3>$transamt){$sql.=",vote3=vote3-$transamt"; 			$transamt=0;}else{$sql.=",vote3=0"; 	$transamt-=$pv3;}}
											if($pv4>0){if ($pv4>$transamt){$sql.=",vote4=vote4-$transamt"; 			$transamt=0;}else{$sql.=",vote4=0"; 	$transamt-=$pv4;}}
											if($pv5>0){if ($pv5>$transamt){$sql.=",vote5=vote5-$transamt"; 			$transamt=0;}else{$sql.=",vote5=0"; 	$transamt-=$pv5;}}
											if($pv6>0){if ($pv6>$transamt){$sql.=",vote6=vote6-$transamt"; 			$transamt=0;}else{$sql.=",vote6=0"; 	$transamt-=$pv6;}}
											if($pv7>0){if ($pv7>$transamt){$sql.=",vote7=vote7-$transamt"; 			$transamt=0;}else{$sql.=",vote7=0"; 	$transamt-=$pv7;}}
											if($pv8>0){if ($pv8>$transamt){$sql.=",vote8=vote8-$transamt"; 			$transamt=0;}else{$sql.=",vote8=0"; 	$transamt-=$pv8;}}
											if($pv9>0){if ($pv9>$transamt){$sql.=",vote9=vote9-$transamt"; 			$transamt=0;}else{$sql.=",vote9=0"; 	$transamt-=$pv9;}}
											if($pv10>0){if ($pv10>$transamt){$sql.=",vote10=vote10-$transamt"; 		$transamt=0;}else{$sql.=",vote10=0"; 	$transamt-=$pv10;}}
											if($pv11>0){if ($pv11>$transamt){$sql.=",vote11=vote11-$transamt"; 		$transamt=0;}else{$sql.=",vote11=0"; 	$transamt-=$pv11;}}
											if($pv12>0){if ($pv12>$transamt){$sql.=",vote12=vote12-$transamt"; 		$transamt=0;}else{$sql.=",vote12=0"; 	$transamt-=$pv12;}}
											$sql.=" WHERE recieptno LIKE '$recno'";
											mysqli_multi_query($conn,"UPDATE acc_feerec SET amt=amt+$transamt,transfer=transfer+$transamt WHERE recieptno LIKE '$recno';$sql;") or
											die(mysqli_error($conn).".<br>Click <a href=\"transferfees.php\">HERE</a> to try again");// update prepayment
											$transamt=0;
										}elseif($transamt==$prep){//Money transfered is equal to prepayment
											mysqli_multi_query($conn,"UPDATE acc_feerec SET amt=amt+$transamt,transfer=transfer+$transamt WHERE recieptno LIKE
											'$recno';DELETE FROM acc_prep WHERE recieptno LIKE '$recno'") or die (mysqli_error($conn).".<br>Click <a
											href=\"transferfees.php\">HERE</a> to try again");	$transamt=0;
										}else{//Transfer is higher than prepaid amount
											mysqli_multi_query($conn,"UPDATE acc_feerec SET amt=amt+$prep,transfer=transfer+$prep WHERE recieptno LIKE '$recno';
											DELETE FROM acc_prep WHERE recieptno LIKE '$recno'") or die (mysqli_error($conn).".<br>Click <a
											href=\"transferfees.php\">HERE</a> to try again"); $transamt-=$prep;
										} while(mysqli_next_result($conn)){;}
									}
									if($transamt>0){//balance after reducing prepayment reduce from normal fees
										$sql="UPDATE acc_feerec SET transfer=transfer+$transamt";
										if($tui>0){if ($tui>$transamt){$sql.=",tuition=tuition-$transamt"; 		$transamt=0;}else{$sql.=",tuition=0"; 	$transamt-=$tui;}}
										if($boa>0){if ($boa>$transamt){$sql.=",boarding=boarding-$transamt"; 	$transamt=0;}else{$sql.=",boarding=0"; 	$transamt-=$boa;}}
										if($act>0){if ($act>$transamt){$sql.=",activity=activity-$transamt"; 	$transamt=0;}else{$sql.=",activity=0"; 	$transamt-=$act;}}
										if($pem>0){if ($pem>$transamt){$sql.=",pemolu=pemolu-$transamt"; 		$transamt=0;}else{$sql.=",pemolu=0"; 	$transamt-=$pem;}}
										if($ltt>0){if ($ltt>$transamt){$sql.=",ltt=ltt-$transamt"; 				$transamt=0;}else{$sql.=",ltt=0"; 		$transamt-=$ltt;}}
										if($rmi>0){if ($rmi>$transamt){$sql.=",rmi=rmi-$transamt"; 				$transamt=0;}else{$sql.=",rmi=0"; 		$transamt-=$rmi;}}
										if($ewc>0){if ($ewc>$transamt){$sql.=",ewc=ewc-$transamt"; 				$transamt=0;}else{$sql.=",ewc=0"; 		$transamt-=$ewc;}}
										if($cont>0){if ($cont>$transamt){$sql.=",cont=cont-$transamt"; 			$transamt=0;}else{$sql.=",cont=0"; 		$transamt-=$cont;}}
										if($eif>0){if ($eif>$transamt){$sql.=",eif=eif-$transamt"; 				$transamt=0;}else{$sql.=",eif=0"; 		$transamt-=$eif;}}
										if($caut>0){if ($caut>$transamt){$sql.=",caut=caut-$transamt"; 			$transamt=0;}else{$sql.=",caut=0"; 		$transamt-=$caut;}}
										if($ins>0){if ($ins>$transamt){$sql.=",insure=insure-$transamt"; 		$transamt=0;}else{$sql.=",insure=0"; 	$transamt-=$ins;}}
										if($med>0){if ($med>$transamt){$sql.=",medical=medical-$transamt"; 		$transamt=0;}else{$sql.=",medical=0"; 	$transamt-=$med;}}
										if($v1>0){if ($v1>$transamt){$sql.=",vote1=vote1-$transamt"; 			$transamt=0;}else{$sql.=",vote1=0"; 	$transamt-=$v1;}}
										if($v2>0){if ($v2>$transamt){$sql.=",vote2=vote2-$transamt"; 			$transamt=0;}else{$sql.=",vote2=0"; 	$transamt-=$v2;}}
										if($v3>0){if ($v3>$transamt){$sql.=",vote3=vote3-$transamt"; 			$transamt=0;}else{$sql.=",vote3=0"; 	$transamt-=$v3;}}
										if($v4>0){if ($v4>$transamt){$sql.=",vote4=vote4-$transamt"; 			$transamt=0;}else{$sql.=",vote4=0"; 	$transamt-=$v4;}}
										if($v5>0){if ($v5>$transamt){$sql.=",vote5=vote5-$transamt"; 			$transamt=0;}else{$sql.=",vote5=0"; 	$transamt-=$v5;}}
										if($v6>0){if ($v6>$transamt){$sql.=",vote6=vote6-$transamt"; 			$transamt=0;}else{$sql.=",vote6=0"; 	$transamt-=$v6;}}
										if($v7>0){if ($v7>$transamt){$sql.=",vote7=vote7-$transamt"; 			$transamt=0;}else{$sql.=",vote7=0"; 	$transamt-=$v7;}}
										if($v8>0){if ($v8>$transamt){$sql.=",vote8=vote8-$transamt"; 			$transamt=0;}else{$sql.=",vote8=0"; 	$transamt-=$v8;}}
										if($v9>0){if ($v9>$transamt){$sql.=",vote9=vote9-$transamt"; 			$transamt=0;}else{$sql.=",vote9=0"; 	$transamt-=$v9;}}
										if($v10>0){if ($v10>$transamt){$sql.=",vote10=vote10-$transamt"; 		$transamt=0;}else{$sql.=",vote10=0"; 	$transamt-=$v10;}}
										if($v11>0){if ($v11>$transamt){$sql.=",vote11=vote11-$transamt"; 		$transamt=0;}else{$sql.=",vote11=0"; 	$transamt-=$v11;}}
										if($v12>0){if ($v12>$transamt){$sql.=",vote12=vote12-$transamt"; 		$transamt=0;}else{$sql.=",vote12=0"; 	$transamt-=$v12;}}
										$sql.=" WHERE recieptno LIKE '$recno'";
										mysqli_query($conn,$sql) or die (mysqli_error($conn).".<br>Click <a href=\"transferfees.php\">HERE</a> to try again");//update fee record
										$transamt=0;
									}
								}
								//UPDATE NEW RECEIPT FROM TRANSFER
								$sql="INSERT INTO acc_feerec(recieptno,admno,pytdate,paytform,cmono,pytno,paidby,kinddescr,amt,arrears,spemed,boarding,addedby) VALUE (0,$desadmno,curdate(),
								'$pytfrm',".(strlen($cheno)>0?"'$cheno'":"null").",".(strlen($pytno)>0?"'$pytno'":"null").",'$paidby','Transfered from Receipt No. $recno','$amttrans',";
								//The student has special medical arrears
								if ($sme>0 && $amttrans>0){
									if($sme>$amttrans){$sql.="'$amttrans',"; $amttrans=0;}
									else{$sql="'$sme',";$amttrans-=$sme;}
								}else $sql.="0,";
								//The student has fee arrears
								if ($bbf>0 && $amttrans>0){
									if($bbf>$amttrans){$sql.="'$amttrans',"; $amttrans=0;}
									else{$sql="'$bbf',";$amttrans-=$bbf;}
								}else $sql.="0,";
								$sql.="'$amttrans','".$_SESSION['username']." (".$_SESSION['priviledge'].")')";
								mysqli_query($conn,$sql) or die (mysqli_error($conn).".<br>Click <a href=\"transferfees.php\">HERE</a> to try again");
								//find inserted receipt no.
								if (mysqli_affected_rows($conn)>0){
									$rsRec=mysqli_query($conn,"SELECT LAST_INSERT_ID()");
									list($newrecno)=mysqli_fetch_row($rsRec); mysqli_free_result($rsRec);
									//Open votehead distribution for further editing
									header("location:votedistredit.php?action=$desadmno-$newrecno-1");
								}else{

								}
							}else{
								print "<h4 style=\"color:#f00;font-size:14pt;letter-spacing:2px;word-spacing:4px;\">Sorry, Receipt transfer was not sucessful.</h4><br>Click <a
								href=\"transferfees.php\">HERE</a> to go back.";
							 	exit(0);
							}
						}else{
							print "<h4 style=\"color:#f00;font-size:14pt;letter-spacing:2px;word-spacing:4px;\">Sorry, The sum of Kshs. ".number_format($transamt,2)." to be transfered is
							higher than receipt amount of Kshs. ".number_format($bal,2)."</h4><br>Click <a href=\"transferfees.php\">HERE</a> to go back.";
						 	exit(0);
						}
					}*/
		}else{
			print "<h4 style=\"color:#f00;font-size:14pt;letter-spacing:2px;word-spacing:4px;\">Sorry, The record has errors to be corrected before saving</h4><br>Click <a href=\"transferfees.php\">HERE</a> to go back.";
		 	exit(0);
		}
	}else{
		mysqli_multi_query($conn,"SELECT s.admno,upper(concat(s.surname,' ',s.onames,' Grade/Form ',c.`clsname`,'-',sf.`stream`)) as nam FROM stud s Left Join class sf USING (admno,curr_year) Inner Join classnames c USING
		(clsno)  Inner Join ss ON (s.curr_year=ss.finyr) order by s.admno; SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0;"); $i=0; $lstStud=$optAC=$acname=$lstAC='';
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){ $nos=mysqli_num_rows($rs); $a=0;	while ($dat=mysqli_fetch_row($rs)){$lstStud.=($a==0?"":",")." new Students($dat[0],'".addslashes($dat[1])."')"; $a++;}
				}else{$a=0; while($dat=mysqli_fetch_row($rs)){if($ac==$dat[0])$acname=$dat[1]; $optAC.="<option value=\"$dat[0]\">$dat[1]</option>";
					$lstAC.=($a==0?"":",")."new Accounts($dat[0],'$dat[1]')"; $a++;}
				} mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn));
	}	headings('<link href="/date/tcal.css" rel="stylesheet"/><link rel="stylesheet" href="tpl/css/headers.css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"/><style>.divb{border:1px dotted #00b;}
	.lih{line-height:75%;font-weight:bold;}</style>',$action[0],$action[1],2);
	if (isset($_POST['cmdTransfer'])){ ?>
		<div class="container" style="background-color:#d6d6d6;max-width:850px;margin:80px auto;border-radius:15px;">
			<ul class="nav nav-tabs" id="myTab" role="tablist">
			    <li class="nav-item lih"><a class="nav-link active" id="stud-tab" data-toggle="tab" href="#tabStudent" role="tab" aria-controls="Inter-Student Fee Transfer" aria-selected="true">INTER-STUDENT FEE TRANSFER</a></li>
			    <li class="nav-item lih"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#tabAccount" role="tab" aria-controls="Inter-Account Fee Transfer" aria-selected="false">INTER-ACCOUNT FEE TRANSFER</a></li>
			</ul>
			<div class="tab-content" id="myTabContent">
			    <div class="tab-pane fade show active" id="tabStudent" role="tabpanel" aria-labelledby="stud-tab"><br><form method="POST" action="transferfees.php" name="frmStudFeeTransfer"><input type="hidden" name="txtAction"
						value="<?php echo $act;?>"><div class="form-row"><div	class="col-md-12 divheadings">DETAILS OF INTER-STUDENT FEE RECEIPT</div></div>
						<div class="form-row"><div class="col-md-12">
							<div class="form-row">
								<div class="col-md-3"><label for="cboAC">Fees A/C Affected</label><select name="cboAC" id="cboAC" size="1" class="modalinput" onchange="enableRecNo(0)"><option value="0" selected>Choose Fee A/C</option>
									<?php echo $optAC;?></select></div>
								<div class="col-md-3"><label for="txtReceiptNo">Receipt No. Transfered</label><input name="txtReceiptNo" id="txtReceiptNo" type="text"	class="modalinput"	value="" maxlength="9" required readonly
									onchange="findReceipt(0,this)" onkeyup="checkInput(this)"></div>
								<div class="col-md-3"><label for="cboType">Type of Transfer</label><select name="cboType" id="cboType" size="1" onchange="setAmt()" class="modalinput"><option value="1" selected>Whole Receipt</option>
									<option value="2">Part of Transfer</option></select></div>
								<div class="col-md-3"><label for="dtpDate">Date of Transfer</label><input name="dtpDate" id="dtpDate" type="text" class="modalinput tcal" disabled value="<?php echo date("d-m-Y");?>"></div>
							</div></div>
					</div><div class="form-row"><div class="col-md-12" id="divRecDetails" style="font-weight:bold;color:#00f;margin-top:10px;"><table class="table table-sm table-hover table-bordered" id="tblStudTransfer"><thead
						class="thead-light"><tr><th>FEES</th><th>PREPAID</th><th>REFUNDS</th><th>MEDICAL</th><th>UNIFORM</th><th>TOTAL</th></tr></thead><tbody><tr><td class="numbersinput">0.00</td><td class="numbersinput">0.00</td><td
						class="numbersinput">0.00</td><td class="numbersinput">0.00</td><td class="numbersinput">0.00</td><td	class="numbersinput">0.00</td></tr></tbody></table></div>
					</div><div class="form-row"><div class="col-md-12">
						<div class="form-row"><div	class="col-md-6 divsubheading divb">FEE RECEIPT TRANSFERRED FROM:</div><div	class="col-md-6 divsubheading divb">FEE RECEIPT TRANSFERRED TO:</div></div>
						<div class="form-row"><div	class="col-md-6 divb">
							<div class="form-row"><div	class="col-md-3"><label for="txtSourceAdmNo">Adm. No.</label><input name="txtSourceAdmNo" id="txtSourceAdmNo" type="text" value="" class="modalinput" maxlength="5" required
								onkeyup="checkInput(this)" onchange="findStud(this,1)"></div><div class="col-md-9" id="divNames_1" style="font-weight:bold;color:#00f"><br>Details of the student appears here</div></div>
							</div><div	class="col-md-6 divb">
								<div class="form-row"><div	class="col-md-3"><label for="txtDestAdmNo">Adm. No.</label><input name="txtDestAdmNo" id="txtDestAdmNo" type="text" value="" class="modalinput" maxlength="5" required
									onkeyup="checkInput(this)" onchange="findStud(this,2)"></div><div class="col-md-9" id="divNames_2" style="font-weight:bold;color:#00f"><br>Details of the student appears here</div></div>
							</div>
						</div></div>
					</div><br><div class="form-row">
						<div class="col-md-3"><label for="txtAmt">Amount Transferred</label><Input name="txtAmt" id="txtAmt" type="text" class="modalinput numbersinput" readonly="readonly" value="0.0" onkeypress="checkInput(this)"
							onblur="confirmAmt(0,this)"></div>
						<div class="col-md-3" style="text-align:center;"><br><Input type="checkbox" name="chkRefunds"	id="chkRefunds" value="1" title="Transfer refunds as part of fees">Include Refunds</div>
						<div class="col-md-6"><label for="txtRmks">Reason for the Transfer</label><textarea name="txtRmks" id="txtRmks" class="modalinput" rows="2" maxlength="150" required></textarea></div>
					</div><hr><div class="form-row">
						<div class="col-md-6"><button name="cmdSave" onclick="return validData(this,0);" type="submit" class="btn btn-primary btn-block btn-md">Continue With the Transfer</button></div>
						<div class="col-md-6" style="text-align:right"><button name="cmdClose" type="button" onclick="window.open('transferfees.php','_self')" class="btn btn-info btn-md">Cancel/ Close</button></div>
					</div></form>
				</div><div class="tab-pane fade show" id="tabAccount" role="tabpanel" aria-labelledby="account-tab"><form method="POST" action="transferfees.php" name="frmACFeeTransfer"><input type="hidden" name="txtAction1"
					value="<?php echo $act;?>"><br><div class="form-row"><div	class="col-md-12 divheadings">SOURCE'S FEE ACCOUNT DETAILS</div></div>
					<div class="form-row">
						<div class="col-md-4"><label for="cboACDebit1">A/C Debited</label><select name="cboACDebit1" id="cboACDebit1" size="1" class="modalinput" onchange="showAcDebit(this)"><option value="0" selected>Choose A/C Debited
							</option><?php echo $optAC;?></select></div>
						<div class="col-md-2"><label for="txtRecNoDebit1">Receipt No.</label><input name="txtRecNoDebit1" id="txtRecNoDebit1" type="text" value="" class="modalinput" maxlength="5" onkeyup="checkInput(this)"
							onchange="findReceipt(1,this)" required readonly></div>
						<div class="col-md-3" style="text-align:center;"><br><Input type="checkbox" name="chkRefunds1" id="chkRefunds1" value="1" title="Transfer refunds as part of fees">Include Refunds</div><div class="col-md-3">-</div>
					</div><div class="form-row">
						<div class="col-md-12" id="divTableFee" style="font-weight:bold;color:#00f;margin-top:10px;"><table class="table table-sm table-hover table-bordered" id="tblACTransfer"><thead class="thead-light"><tr><th>FEES</th>
							<th>PREPAID</th><th>REFUNDS</th><th>MEDICAL</th><th>UNIFORM</th><th>TOTAL</th></tr></thead><tbody><tr><td class="numbersinput">0.00</td><td class="numbersinput">0.00</td><td class="numbersinput">0.00</td><td
							class="numbersinput">0.00</td><td class="numbersinput">0.00</td><td class="numbersinput">0.00</td></tr></tbody></table></div>
					</div><br><div class="form-row"><div	class="col-md-12 divheadings">DETAILS OF STUDENT FROM WHOM THE FEE RECEIPT IS TRANSFERRED FROM</div></div>
					<div class="form-row"><div class="col-md-2"><label for="txtAdmNo1">Adm. No.</label><input name="txtAdmNo1" id="txtAdmNo1" type="text" value="" class="modalinput" maxlength="5" onkeyup="checkInput(this)"
						onchange="findStud(this,3)" required></div><div	class="col-md-10" id="divNames_3" style="font-weight:bold;color:#00f"><br>Details of the student appears here</div>
					</div><div class="form-row"><div	class="col-md-12 divheadings">DESTINATION'S FEE ACCOUNT DETAILS</div>
					</div><div class="form-row">
						<div class="col-md-4"><label for="cboACCredit1">A/C Credited</label><select name="cboACCredit1" id="cboACCredit1" size="1" class="modalinput" onchange="showAcCredit(this)"><option value="0">Choose A/C Credited</option>
						</select></div><div class="col-md-2">-</div>
						<div class="col-md-3"><label for="txtAcBal1">Current A/C Balance</label><input name="txtAcBal1" id="txtAcBal1" type="text" value="" class="modalinput numbersinput" maxlength="5" required readonly></div>
						<div class="col-md-3"><label for="txtCredAmt1">Amount Transferred</label><input name="txtCredAmt1" id="txtCredAmt1" type="text" value="0.00" class="modalinput numbersinput" maxlength="5" onkeypress="checkInput(this)"
							onblur="confirmAmt(1,this)" required></div>
					</div><div class="form-row">
						<div class="col-md-12"><label for="txtRmks1">Reason for the Transfer</label><textarea name="txtRmks1" id="txtRmks1" class="modalinput" rows="2" maxlength="150" required></textarea></div>
					</div><hr><div class="form-row">
						<div class="col-md-6"><button name="cmdSave1" onclick="return validData(this,1);" type="submit" class="btn btn-primary btn-block btn-md">Continue With the Transfer</button></div>
						<div class="col-md-6" style="text-align:right"><button name="cmdClose" type="button" onclick="window.open('transferfees.php','_self')" class="btn btn-info btn-md">Cancel/ Close</button></div>
					</div></form>
				</div>
			</div><hr>
		</div><?php
	}elseif($act==0 || isset($_POST['cmdShow'])){ ?>
		<div class="head"><form method="POST" action="transferfees.php" name="feetransfer"><input type="hidden" name="txtAction" value="<?php echo $act;?>">
		Fee Transfers in <select name="cboAC" size="1"><?php echo $optAC;?></select> Account Between <input name="dtpFrom" type="text" class="tcal" size="8" readonly value="<?php echo date("d-m-Y",strtotime("-30 days"));?>">
		and <input name="dtpTo" type="text" class="tcal" size="8" readonly value="<?php echo date("d-m-Y");?>"> &nbsp;&nbsp;<button type="submit" name="cmdShow" class="btn btn-warning btn-md">Show Transfered Fees</button>
		&nbsp;&nbsp;<button type="submit" name="cmdTransfer" class="btn btn-warning btn-md">Transfer Fees</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="transferfees.php?action=3">---</a></form>
		</div><?php
		print "<div style=\"background-color:#e6e6e6;border:0.5px groove #007;width:fit-content;margin:10px auto;border-radius:15px 15px 0 0;padding:0 5px;\" class=\"container\"><div class=\"form-row\"><div
		class=\"col-md-12\"><h5 style=\"text-align:center;color:#00f;text-decoration:underline dashed #009;margin-top:10px;\">$acname ".strtoupper("Fee Transfers Made Between ".date("D d M, Y",strtotime($sdate))." and ".
		date("D d M, Y",strtotime($edate)))."</h5></div></div>";
		$rsTrans=mysqli_query($conn,"SELECT t.recieptno,f.pytfrm,f.cheno,i.amt,t.transdate,t.rmks,t.transamt,t.fromadmno,t.nam,t.ffrm,t.receiveradmno,concat(s.surname,' ',s.onames) as snam,concat(c.clsname,'-',sf.stream) As
		frm FROM (SELECT t.transno,t.recieptno,t.transtype,t.ac,t.transdate,t.rmks,t.fromadmno,concat(s.surname,' ',s.onames) as nam,concat(c.clsname,'-',sf.stream) As ffrm,t.receiveradmno,t.amt as transamt FROM
		acc_feetransfer t	INNER JOIN stud s On (t.fromadmno=s.admno) Inner Join class sf USING (admno,curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) WHERE t.ac	LIKE '$ac' and t.markdel=0 and (transdate BETWEEN
		'$sdate' AND '$edate'))t	Inner Join ".($ac==1?"acc_incorecno0":"acc_incorecno1")." i ON (t.recieptno=i.recno and t.ac=i.acc) Inner Join acc_incofee f ON (i.sno=f.sno) Inner Join stud s ON (t.receiveradmno=s.admno)
		Inner Join class sf ON (s.admno=sf.admno and s.curr_year=sf.curr_year) Inner Join classnames c USING (clsno)");
		print '<div class="form-row"><div class="col-md-12" style="border:0.5px dotted green;border-radius:10px;padding:6px;"><form name="frmFind" action="transferfees.php" method="post">Find Transfer record
		By &nbsp;<input type="radio" name="radFind" id="radRecNo" value="recno" onclick="clrText()">Receipt No.&nbsp;<input type="radio" name="radFind" id="radAdmNo" value="admnno" onclick="clrText()">Adm. No.&nbsp; <input
		type="radio" name="radFind" id="radModeNo" value="cheno" checked onclick="clrText()">Mode No. &nbsp;&nbsp; <input type="text" maxlength="17" size="30" name="txtFind" id="txtFind" onkeyup="myFunction()" value=""
		placeholder="Type/ Enter what to Find" style="border:0px; border-bottom:1px solid blue;color:#00d;"></form></div></div>';
		print '<div class="form-row"><div class="col-md-12" style="min-height:100px;max-height:550px;overflow-y:scroll;">';
		print "<table class=\"table table-sm table-bordered table-striped\"><tr style=\"font-weight:strong;letter-spacing:3px;word-spacing:5px;\"><th colspan=\"4\" style=\"background-color:#eee;\">RECEIPT BEING TRANSFERRED
		</th><th colspan=\"3\" style=\"background-color:#000;color:#fff;\">FEE TRANSFER DETAILS</th><th colspan=\"3\" style=\"background-color:#eee;\">FEES	TRANSFERRED	FROM</th><th colspan=\"3\" style=\"background-color:#000;
		color:#fff;\">FEES RECEIVED BY</th></tr><tr><th>Receipt<br>No.</th><th>Mode</th><th>Mode No.</th><th>Amount</th><th>Transferred<br>On</th><th>Reason for the<br>Transfer</th><th>Amount</th><th>Adm.<br>No.</th><th>Names
		</th><th>Form</th><th>Adm.<br>No.</th><th>Names</th><th>Form</th></tr>";
		$ttl=0; $ttl1=0; $row=0; $nor=mysqli_num_rows($rsTrans);
		if($nor>0){
			while($dat=mysqli_fetch_row($rsTrans)){
				$i=0; if ($row%2==0) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>";
				foreach ($dat as $val){
					if($i==3){print "<td align=\"right\">".number_format($val,2)."</td>"; $ttl+=$val;} 	elseif($i==4) print "<td align=\"right\">".date("D d M,y",strtotime($val))."</td>";
					elseif($i==6) {print "<td align=\"right\">".number_format($val,2)."</td>"; $ttl1+=$val;} 		else print "<td>$val</td>";		$i++;
				}$row++;
			}
		}else print "<tr><td colspan=\"13\">No Fee Transfer Records Exists</td></tr>";
		print "<tr><td colspan=\"2\"><b>$nor Record(s)</b></td><td align=\"right\"><b>Total Amount</b></td><td align=\"right\"><b>".number_format($ttl,2)."</b></td><td colspan=\"2\"></td><td align=\"right\"><b>".
		number_format($ttl1,2)."</b></td><td colspan=\"6\"></td></tr></table></div></div></div>";
	} else { ?>
		<div class="head"><form method="POST" action="transferfees.php" name="feetransfer"><input type="hidden" name="txtAction" value="<?php echo $act;?>">Fees Account Affected&nbsp;<select name="CboAC" size="1"><?php
		echo $optAC;?>></select>&nbsp;&nbsp;&nbsp;Receipt No. to be Deleted &nbsp;<input name="TxtReceiptNo" id="TxtReceiptNo" type="text" value="0" size="12"	maxlength="9" onkeyup="checkInput(this)"></form></div>
		<?php $sdate=explode('-',$sdate);	$edate=explode('-',$edate); $sdate="$sdate[2]-$sdate[1]-$sdate[0]";	$edate="$edate[2]-$edate[1]-$edate[0]";
			print "<div style=\"background-color:#e6e6e6;border:0.5px groove #007;width:fit-content;margin:10px auto;border-radius:15px 15px 0 0;padding:0 5px;\" class=\"container\"><div class=\"form-row\"><div
			class=\"col-md-12\"><h5 style=\"text-align:center;color:#00f;text-decoration:underline dashed #009;margin-top:10px;\">$acname ".strtoupper("Fee Transfers Made Between ".date("D d M, Y",strtotime($sdate))." and ".
			date("D d M, Y",strtotime($edate)))."</h5></div></div>";
			print "<div class=\"form-row\"><div class=\"col-md-12\"> ----- </div></div></div>";
	}?><script type="text/javascript" src="tpl/js/transferfees.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<?php if(strlen($lstAC)>0) echo "<script type=\"text/javascript\">account.push($lstAC);</script>"; mysqli_close($conn); footer();?>
