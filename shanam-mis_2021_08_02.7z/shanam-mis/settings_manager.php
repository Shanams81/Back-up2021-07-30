<?php
	include_once("shanam.php");
	$rsDet=mysqli_query($conn,"SELECT g.sysdata,g.setupview,a.accview,a.voteview FROM gen_priv g INNER JOIN acc_priv a USING (uname) WHERE g.uname LIKE '".
	$_SESSION['username']."'");	$sys=0; $set=0; $acc=0; $vote=0;
	if (mysqli_num_rows($rsDet)>0) list($sys,$set,$acc,$vote)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	headings('',0,0,0);
?>
<table border="0" cellspacing="2" cellpadding="3" align="center" style="margin:100px auto;">
	<tr><td style="color:#00FF33;text-align:center;background-color:#8888AA;font-style:bold;font-size:12pt;word-spacing:5px;letter-spacing:3px;" colspan="3">SYSTEM SETTINGS MANAGEMENT INTERFACE.<br> Log In Time:
		<?php echo	$_SESSION['logintime']; ?> <a href="transit.php">--</a></td>
	</tr><tr><td width="35%" align="center"><a onclick="return canvi(<?php echo $sys;?>);" href="sysdata.php?action=0-0"><img src="../gen_img/settings.jfif" id="img1" width="120" height="100"
		onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Institution Details</td><td align="center"><a onclick="return canvi(<?php echo $set;?>);" href="sysgroup.php?action=0-0"><img
		src="../gen_img/grps.jfif" id="img4" width="120" height="100"	onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Groups & Term Settings</td><td width="35%" align="center"><a href="voteacs.php"
		onclick="return canvi(<?php echo $acc;?>);"><img src="../gen_img/accounts.jpg" id="img2" width="120"	height="100" onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Votehead A/Cs</td>
	</tr><tr><td width="30%" align="center"><a onclick="return canvi(<?php echo $acc;?>);" href="accounts.php?act=0-0"><img src="../gen_img/banking.jpg" id="img3" width="120"	height="100" onmouseover="img_focus(this)"
		onmouseout="img_blur(this)"></a><br>Bank A/Cs</td><td width="30%" align="center"><a onclick="return canvi(<?php echo $vote;?>);" href="votes.php?act=0-0"><img src="../gen_img/votes.jpg" id="img3" width="120"
		height="100"	onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Voteheads</td><td width="30%" align="center"><a onclick="return canvi(<?php echo $set;?>);" href="classes.php?act=0-0"><img
		src="../gen_img/class.jpg" id="img3" width="120" height="100"	onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Classes/Grades</td>
	</tr><tr><td align="center"><a onclick="return canvi(<?php echo $set;?>);" href="taxbrackets.php"><img src="../gen_img/paye.jpg" id="img5" width="120" height="100"	onmouseover="img_focus(this)" 
		onmouseout="img_blur(this)"></a><br>Tax Brackets</td><td align="center"><a onclick="return canvi(<?php echo $set;?>);" href="nhifbrackets.php"><img src="../gen_img/nhif.jpg" id="img5" width="120" height="100"
		onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>NHIF Rates</td><td align="center"><a onclick="return canvi(<?php echo $set;?>);" href="specialvotes.php"><img src="../gen_img/spevotes.jpg"
		id="img5" width="120" height="100"	onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Special Fee Votes</td>
	</tr><tr><td colspan="3" style="background-color:#88A;color:#00FF33;text-align:center;font-style:bold;font-size:12pt;word-spacing:5px;letter-spacing:3px;color:#0F3;text-align:center;">Shanam's Digital Solutions -
		Bridging Digital Divide</td></tr>
</table><script type="text/javascript" src="tpl/js/menu.js"></script>
<?php	mysqli_close($conn); footer(); ?>
