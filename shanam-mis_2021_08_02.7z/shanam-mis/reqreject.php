<?php
	include_once('shanam.php');
	if(isset($_POST['btnSave'])){
	 	$reqno=isset($_POST['txtReqNo'])?trim(strip_tags($_POST['txtReqNo'])):0;
	 	$date=date('Y-m-d');	$addb=$_SESSION['username']." (".$_SESSION['priviledge'].")";
	 	$rmks=isset($_POST['txtRmks'])?strtoupper(trim(strip_tags($_POST['txtRmks']))):0;
	 	if (strlen($rmks)<10){
			print "SERVER ERROR <font color=\"#cc0000\">Ensure the reason for cancelling request is validly entered before saving</font><br>";
			$rno=$reqno;
		}else{
			mysqli_query($conn,"INSERT INTO acc_reqrej VALUES (0,'$reqno','$date','$rmks','$addb',0)") or die(mysqli_error($conn)." Sorry, the requesition was not rejected successfully.
			Click <a href=\"reqreject.php?reqno=$reqno\">Here</a> to go try again.");
			$i=mysqli_affected_rows($conn);
			if ($i==1) mysqli_query($conn,"UPDATE acc_req SET approved=2 WHERE reqno LIKE '$reqno'") or die(mysqli_error($conn)." Sorry, the requisition failed to be successfully rejected.
			Click <a href=\"requisition.php\">Here</a> to go back.");
			header("location:requisition.php?action=2-$i"); exit(0);
		}
	}
	$reqno=isset($_REQUEST['reqno'])?strip_tags($_REQUEST['reqno']):0; $reqno=isset($rno)?$rno:$reqno;
	$rsAdv=mysqli_query($conn,"SELECT r.reqno,r.idno,r.reqdate,r.rmks,concat(s.surname,' ',s.onames,' - ',s.designation) as nam,sum(c.approvedup*c.approvedqty) as
	amt FROM acc_req r Inner Join stf s USING (idno) Inner Join acc_reqitems c On (r.reqno=c.reqno) GROUP BY r.reqno,r.reqdate,r.rmks,s.surname,s.onames,
	s.designation HAVING r.reqno LIKE '$reqno'");
	list($reqno,$idno,$reqdate,$rmks,$nam,$amt)=mysqli_fetch_row($rsAdv); mysqli_free_result($rsAdv);
	headings('<link href="tpl/css/inputsettings.css" type="text/css" rel="stylesheet"/>',0,0,2);
?>
<div class="container divgen" style="font-size:1rem;"><form name="frmAdvReq" method="Post" action="reqreject.php"><input type="hidden" name="txtReqNo" value="<?php echo "$reqno";?>">
	<div class="form-row"><div class="col-md-12 divsubheading">REJECTION OF REQUISITION NO.	<U><?php echo $reqno;?></U></div></div>
	<div class="form-row"><div class="col-md-12">This is to reject requisition made by<b> <?php  echo ucwords(strtolower($nam))."</b><br>FOR <b>$rmks";?></b>.</div></div>
	<div class="form-row"><div class="col-md-12">The requesition was for total sum of Kshs. <?php echo number_format($amt,2)." and made on ".date('l j, F Y',strtotime($reqdate));?>
	</div></div><br><hr>
	<div class="form-row"><div class="col-md-12"><label for="txtRmks">Reason for the rejecting</label><textarea name="txtRmks" id="txtRmks" class="modalinput" rows="3" maxlength="250"
	required onclick="checkLength(this)" readonly></textarea></div></div><br><hr><br>
	<div class="form-row">
		<div class="col-md-6"><button name="btnSave" type="submit" class="btn btn-primary btn-block btn-md" disabled>Reject Requisition</button></div>
		<div class="col-md-6" style="text-align:right;"><button type="button" name="cmdClose" onclick="window.open('requisition.php?action=0-0','_self')"  class="btn btn-primary btn-md
		disabled">Close</button></div>
	</div>
</div>
<script type="text/javascript">
	function checkLength(txt){
		let val=txt.value.replace(/[^a-z0-9\.\ \,]/gi,'';);
		if(val.length>10){document.querySelector("#txtRmks").readOnly=false;
		}else{document.querySelector("#txtRmks").readOnly=true;}
	}
</script>
<?php	mysqli_close($conn); footer();?>
