<?php
	include_once("shanam.php");
	$rsDet=mysqli_query($conn,"SELECT g.studview,g.leaveoutview,a.feeadd,a.feeview,a.uniadd,a.struview,g.aluview FROM gen_priv g INNER JOIN acc_priv a USING (uname) WHERE g.uname LIKE '".
	$_SESSION['username']."'");	$studv=$addfee=$feev=$unif=$vistru=$vileave=$aluv=0;
	if (mysqli_num_rows($rsDet)>0) list($studv,$vileave,$addfee,$feev,$unif,$vistru,$aluv)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	//number of registered pupils
	$rs=mysqli_query($conn,"SELECT count(admno) as nos FROM stud GROUP BY type,present,markdel HAVING (type=0 and markdel=0 and present=1)");
	$pupno=0; if (mysqli_num_rows($rs)>0) list($pupno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
	headings('',0,0,0);
	print "<table  class=\"table table-responsive table-borderless\"><tr><td colspan=\"4\"><p>STUDENT, UNIFORM AND FEE PAYMENT INTERFACE.<br> Log In Time: ".$_SESSION['logintime'].
        "</p></td></tr>";
 	print "<tr><td width=\"35%\" align=\"center\"><a onclick=\"return canvi($studv);\" href=\"student.php\"><img src=\"../gen_img/stud.jpg\" id=\"img1\"
	width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br><font color=\"#ee0000\">($pupno of 500)</font> Student(s)
	</td>";
	print "<td width=\"35%\" align=\"center\"><a href=\"feestruct.php\" onclick=\"return canvi($vistru);\"><img src=\"../gen_img/feestruct.jpg\" id=\"img2\" width=\"120\" height=\"100\" "
        . "onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Fee Structure</td>";
	print "<td width=\"30%\" align=\"center\"><a onclick=\"return canvi($unif);\" href=\"uniform.php\"><img src=\"../gen_img/unifrm.jpg\" id=\"img5\" width=\"120\"
	height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Uniforms &amp; Definition</td><td width=\"30%\" align=\"center\"><a onclick=\"return canvi($feev);\"
	href=\"arrearsbf.php\"><img src=\"../gen_img/arrears.jpg\" id=\"img5\" width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Arrears B/F
        </td></tr>";
	print "<tr><td align=\"center\"><a onclick=\"return canvi($addfee);\" href=\"studfee.php\"><img src=\"../gen_img/receivefee.jfif\" id=\"img4\" width=\"120\"
	height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Receive Fees</td><td align=\"center\"><a onclick=\"return canvi($feev);\"
	href=\"feecollection.php\"><img src=\"../gen_img/money.jpg\" id=\"img5\" width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\"
	onmouseout=\"img_blur(this)\"></a><br>Fee Collections</td><td align=\"center\"><a onclick=\"return canvi($addfee);\" href=\"spemedical.php\"><img
	src=\"../gen_img/votes1.jfif\" id=\"img6\" width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Surcharged Medical Bills
	</td><td align=\"center\"><a onclick=\"return canvi($aluv);\" href=\"alumni.php\"><img src=\"../gen_img/alumni.jpg\" id=\"img6\" width=\"120\" height=\"100\" "
        . "onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Alumni</td></tr>";
	print "<tr><td align=\"center\"><a onclick=\"return canvi($feev);\" href=\"bursary.php\"><img src=\"../gen_img/burs.jpg\" id=\"img7\" width=\"120\"
	height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Bursaries</td><td align=\"center\"><a onclick=\"return canvi($vileave);\"
	href=\"leaveout.php\"><img src=\"../gen_img/logout.jpeg\" id=\"img5\" width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Leaveouts</td>
	<td align=\"center\"><a onclick=\"return canvi($feev);\" href=\"inquirebal.php\"><img src=\"../gen_img/search1.png\" id=\"img5\" width=\"120\" height=\"100\"
	onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Balance Inquiry</td><td align=\"center\"><a onclick=\"return canvi($feev);\" href=\"prepayments.php\"><img src=\"../gen_img/prepay.jpg\"
	id=\"img6\" width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Prepayments</td></tr>";
	print "<tr><td colspan=\"4\"><p>Shanam's Digital Solutions - Bridging Digital Divide</p></td></tr></table><script type=\"text/javascript\" src=\"tpl/js/menu.js\"></script>";
	mysqli_close($conn);
	footer();
?>
