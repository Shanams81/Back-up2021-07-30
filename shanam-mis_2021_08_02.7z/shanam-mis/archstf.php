<?php
	session_start();
	if (!isset($_SESSION['username']) || ($_SESSION['username'] == ''))	header ("Location:../index.php"); else include_once("../conn/mysqli_connect.inc.tpl");
	$rsDet=mysqli_query($conn,"SELECT g.stfview,g.reqraise,a.impview,a.advview,a.salview FROM gen_priv g INNER JOIN acc_priv a USING (uname) WHERE g.uname LIKE '".
	$_SESSION['username']."'");	$stfv=0; $salv=0; $impv=0; $reqv=0;	$advv=0;	
	if (mysqli_num_rows($rsDet)>0) list($stfv,$reqv,$impv,$advv,$salv)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
?>
<!DOCTYPE html>
<html lang="en">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">	
	<title>School MIS Manager</title>
	<link rel="shortcut icon" href="../gen_img/phone.ico"/>
	<script type="text/javascript" src="tpl/menu.js"></script>
</head>
<body background="../gen_img/bg3.gif" style="background-size:100%;">
<?php
	print "<table border=\"0\" cellspacing=\"2\" cellpadding=\"3\" align=\"center\" style=\"position:relative;top:100px;\"><tr><td style=\"color:#00FF33;
	text-align:center;background-color:#8888AA;font-style:bold;font-size:12pt;word-spacing:5px;letter-spacing:3px;\" colspan=\"3\">ARCHIVED STAFF, SALARY  AND
	IMPRESTS MANAGEMENT INTERFACE.<br> Log In Time: ".$_SESSION['logintime']; 
 	print "</td></tr><tr><td width=\"35%\" align=\"center\"><a onclick=\"return canvi($stfv);\" href=\"arch_staff.php\"><img src=\"../gen_img/stf.jpg\" id=\"img1\" 
	width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Members of Staff</td>";
	print "<td width=\"35%\" align=\"center\"><a href=\"Arch_salary.php\" onclick=\"return canvi($salv);\"><img src=\"../gen_img/archsal.jpg\" id=\"img2\" width=\"120\" 
	height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Salary Definition &amp; Payrolls</td>";
	print "<td width=\"30%\" align=\"center\"><a onclick=\"return canvi($advv);\" href=\"arch_saladv.php?act=0-0\"><img src=\"../gen_img/saladv.jpg\" id=\"img3\" 
	width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Salary Advances</td></tr>";
	print "<tr><td align=\"center\"><a onclick=\"return canvi($advv);\" href=\"subloan.php\"><img src=\"../gen_img/tuifund.jpg\" id=\"img4\" width=\"120\" height=\"100\" 
	onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Subsistence Loans</td><td align=\"center\"><a onclick=\"return canvi($reqv);\" 
	href=\"arch_req.php\"><img src=\"../gen_img/req.jpg\" id=\"img5\" width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a>
	<br>Requisitions</td><td align=\"center\"><a onclick=\"return canvi($impv);\" href=\"Arch_Imp.php\"><img src=\"../gen_img/archimp.jpg\" id=\"img5\" width=\"120\" 
	height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Imprests</td></tr>"; 
	print "<tr><td colspan=\"3\" style=\"background-color:#88A;color:#00FF33;text-align:center;font-style:bold;font-size:12pt;word-spacing:5px;
	letter-spacing:3px;color:#0F3;text-align:center;\">Shanam's Digital Solutions - Bridging Digital Divide</td></tr>";
	mysqli_close($conn);
?>
</table>
</body>
</html>