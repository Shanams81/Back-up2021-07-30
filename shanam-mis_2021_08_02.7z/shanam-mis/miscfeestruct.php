<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else{
		include_once('../conn/pri_sch_connect.inc');
		$dat=isset($_REQUEST['adm'])?$_REQUEST['adm']:"0-0-0"; 	$dat=preg_split('/\-/',$dat);
		$rsCo=mysqli_query($conn,"SELECT t1misidcard,t1misqa,t1misremedial,t1misht,t1misgrad,t1mistrip,t1misole,misct1,(t2misidcard-t1misidcard) as id2,(t2misqa-
		t1misqa) as qa2,(t2misremedial-t1misremedial) as rem2,(t2misht-t1misht) as ht2,(t2misgrad-t1misgrad) as grad2,(t2mistrip-t1mistrip) as trip2,(t2misole-
		t1misole) as mole2,(misct2-misct1) as mttl2,(misidcard-t2misidcard) as id3,(misqa-t2misqa) as qa3, (misremedial-t2misremedial) as rem3,(misht-t2misht) as 
		ht3,(misgrad-t2misgrad) as grad3,(mistrip-t2mistrip) as trip3,(misole-t2misole) as mole3,(misct3-misct2) as mttl3,misidcard,misqa,misremedial,misht,
		misgrad,mistrip,misole,misct3 FROM acc_feeoutline WHERE  curr_year IN (SELECT finyr FROM ss) and feegrp LIKE '$dat[1]' and lvl LIKE '$dat[2]'");
		//fetch fee data from database
		if (mysqli_num_rows($rsCo)>0) list($t1id,$t1qa,$t1rem,$t1ht,$t1grad,$t1trip,$t1mole,$mt1,$t2id,$t2qa,$t2rem,$t2ht,$t2grad,$t2trip,$t2mole,$mt2,$t3id,$t3qa,
		$t3rem,$t3ht,$t3grad,$t1trip,$t3mole,$mt3,$id,$qa,$rem,$ht,$grad,$trip,$mole,$myt)=mysqli_fetch_row($rsCo); mysqli_free_result($rsCo);
	}
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Fee Structure</title>
</head>
<body background="img/bg3.gif">
	<?php
		$h= "Fees Structure Definition";
		print "<center><h2>".strtoupper($h)."</h2></center><hr>";
		print "<table cellspacing=\"0\" cellpadding=\"4\" border=\"1\" bordercolor=\"#cccccc\" align=\"center\"><tr><td colspan=\"5\" ALIGN=\"CENTER\"><b>
		MISCELLANEOUS ACCOUNT FEE STRUCTURE</b></td></tr><tr><td colspan=\"5\" align=\"left\">-<br>$dat[0] $dat[2] Fee Structure Of $dat[1] Pupils<br>-</td>
		</tr>";
		print "<tr bgcolor=\"#eeeeee\"><td><b>Votehead</b></td><td align=\"center\"><b>Term I</b></td><td align=\"center\"><b>Term II</b></td><td 
		align=\"center\"><b>Term III</b></td><td align=\"center\"><b>Total</b></td></tr>";
		print "<tr><td>ID Card</td><td align=\"right\">".number_format($t1id,2)."</td><td align=\"right\">".number_format($t2id,2)."</td><td align=\"right\"
		>".number_format($t3id,2)."</td><td align=\"right\">".number_format($id,2)."</td></tr>";
		print "<tr><td>Quality Assurance</td><td align=\"right\">".number_format($t1qa,2)."</td><td align=\"right\">".number_format($t2qa,2)."</td>
		<td align=\"right\">".number_format($t3qa,2)."</td><td align=\"right\">".number_format($qa,2)."</td></tr>";
		print "<tr><td>Remedial</td><td align=\"right\">".number_format($t1rem,2)."</td><td align=\"right\">".number_format($t2rem,2)."</td><td 
		align=\"right\">".number_format($t3rem,2)."</td><td align=\"right\">".number_format($rem,2)."</td></tr>";
		print "<tr><td>Holiday Tuition</td><td align=\"right\">".number_format($t1ht,2)."</td><td align=\"right\">".number_format($t2ht,2)."</td><td 
		align=\"right\">".number_format($t3ht,2)."</td><td align=\"right\">".number_format($ht,2)."</td></tr>";
		print "<tr><td>Graduation Fee</td><td align=\"right\">".number_format($t1grad,2)."</td><td align=\"right\">".number_format($t2grad,2)."</td><td 
		align=\"right\">".number_format($t3grad,2)."</td><td align=\"right\">".number_format($grad,2)."</td></tr>";
		print "<tr><td>Academic Trip</td><td align=\"right\">".number_format($t1trip,2)."</td><td align=\"right\">".number_format($t2trip,2)."</td><td 
		align=\"right\">".number_format($t3trip,2)."</td><td align=\"right\">".number_format($trip,2)."</td></tr>";
		print "<tr><td>Other Levies</td><td align=\"right\">".number_format($t1mole,2)."</td><td align=\"right\">".number_format($t2mole,2)."</td><td 
		align=\"right\">".number_format($t3mole,2)."</td><td align=\"right\">".number_format($mole,2)."</td></tr>";
		print "<tr><td>Total Fees</td><td align=\"right\">".number_format($mt1,2)."</td><td align=\"right\">".number_format($mt2,2)."</td><td align=\"right\"
		>".number_format($mt3,2)."</td><td align=\"right\">".number_format($myt,2)."</td></tr>";
		mysqli_close($conn);
	?></table>
	</td></tr>
	</table><br><center><a href="feestruct.php">BACK</a>
</body>
</html>