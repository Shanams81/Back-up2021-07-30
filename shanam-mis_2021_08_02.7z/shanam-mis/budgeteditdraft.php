<?php
    include_once('shanam.php');
    if (isset($_POST['CmdSave'])){
        $sno=isset($_POST['txtSNo'])?$_POST['txtSNo']:"0";	$itmcode=isset($_POST['cboItem'])?trim(strip_tags($_POST['cboItem'])):0;
        $pqty=isset($_POST['txtPQty'])?trim(strip_tags($_POST['txtPQty'])):0;	$pup=isset($_POST['txtPUP'])?trim(strip_tags($_POST['txtPUP'])):0;
        $qty=isset($_POST['txtQty'])?trim(strip_tags($_POST['txtQty'])):0;		$up=isset($_POST['txtUP'])?trim(strip_tags($_POST['txtUP'])):0;
        $pqty=preg_replace("/[^0-9^\.]/","",$pqty);		$qty=preg_replace("/[^0-9^\.]/","",$qty);	$pup=preg_replace("/[^0-9^\.]/","",$pup);
        $up=preg_replace("/[^0-9^\.]/","",$up);
        if (($pqty>0) && ($pup>0) && ($qty>0) && ($up>0) && ($itmcode>=0)){
            mysqli_query($conn,"UPDATE acc_budgitemsdraft SET itmcode='$itmcode',prevqty='$pqty',prevup='$pup',qty='$qty',up='$up' WHERE sno LIKE '$sno'") or die(mysqli_error($conn).". Budget item
            details were not saved. Click <a href=\"budgdraft.php\">Here</a> to try again.</center>");
            $i=mysqli_affected_rows($conn);	$noitms+=$i;
        }else$i=0;
        header("location:budgdraft.php?action=1-$i");
    }elseif(isset($_POST['cmdDel'])){
        $sno=strip_tags($_POST['txtSNo']);
        @mysqli_query($conn,"DELETE FROM acc_budgitemsdraft WHERE (sno LIKE '$sno')") or die(mysqli_error($conn).". Budget item not deleted. Click <a href=\"budgdraft.php\">Here</a> to try again");
        $i=mysqli_affected_rows($conn);
        header("location:budgdraft.php?action=2-$i");
    }else{
        $action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0";
        mysqli_multi_query($conn, "SELECT budgdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT finyr FROM ss; SELECT i.itmcode,i.itemname,a.descr,i.Units,b.prevqty,
        b.prevup, (b.prevqty*b.prevup) as pamt, b.Qty, b.Up, (b.qty*b.up) AS TtlAmt, i.unitprice, i.units, v.descr as vote FROM acc_budgetdraft bu Inner Join acc_budgitemsdraft b USING
				(budgno) Inner Join items i On (b.itmcode=i.itmcode) Inner Join acc_votes v On (bu.voteno=v.sno) Inner Join acc_voteacs a On (bu.acc=a.acno) WHERE (bu.markdel=0 AND b.sno LIKE
				'$action');"); 	       $i=$budgdel=0;
        do{
            if($rs=mysqli_store_result($conn)){
                if($i==0){
                    if(mysqli_num_rows($rs)==1) list($budgdel)=mysqli_fetch_row($rs);
                }elseif($i==1){
                    list($yr)=mysqli_fetch_row($rs);
                }else{
                   list($itmco,$itm,$acn,$uni,$pqty,$pup,$pamt,$qty,$up,$amt,$itmup,$itmuni,$votename)=mysqli_fetch_row($rs);
                } mysqli_free_result($rs);
            } $i++;
        }while(mysqli_next_result($conn));
    }
    headings('<link href="tpl/css/inputsettings.css" rel="stylesheet" type="text/css"/>',0,0,2);
?><br><br><div class="container divmodalmain" style="padding-top:0px;"><form method="post" action="budgeteditdraft.php" onsubmit="return validateFormOnSubmit(this);" >
    <div class="form-row" style="margin-top:0px;"><div class="col-md-12 divheadings" style="text-align:center;margin-top:0px;border-radius:15px 15px 0 0;"><?php echo "FY".($yr+1)." $acn -
		$votename <br>EDITING ".strtoupper($itm);?></div><input name="txtSNo" type="hidden" value="<?php echo "$action";?>"><input name="cboItem" id="cboItem" type="hidden"
		value="<?php echo $itmco; ?>">
    </div><div class="form-row">
        <div class="col-md-8"><label for="txtItem">Items Description</label><Input name="txtItem" id="txtItem" size="60" value="<?php echo "$itmco - $itm";?>" disabled class="modalinput"></div>
        <div class="col-md-4"><label for="txtItems">*</label><input type="text" class="modalinput modalinputdisabled" name="txtItems" value="Unit Price <?php echo number_format($itmup,2).
        " per ".$itmuni; ?>"></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="txtPQty"><?php echo $yr;?> Actual Qty</label><input type="text" name="txtPQty" id="txtPQty" class="modalinput numbersinput" maxlength="8" value="<?php
        echo number_format($pqty,2);?>" onkeyup="checkInput(this)" onblur="calcAmt(0)"></div>
        <div class="col-md-4"><label for="txtPUP"><?php echo $yr;?> Actual Unit Cost </label><td><INPUT name="txtPUP" id="txtPUP" class="modalinput numbersinput" maxlength="10" value="<?php
        echo number_format($pup,2);?>" onkeyup="checkInput(this)" onblur="calcAmt(0)"></div>
        <div class="col-md-4"><label for="txtTtlPrev"><?php echo $yr;?> Amount</label><input type="text" class="modalinput numbersinput modalinputdisabled" name="txtTtlPrev" id="txtTtlPrev"
        value="<?php echo number_format($pamt,2);?>" readonly></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="txtQty"><?php echo $yr+1;?> Quantity</label><input type="text" name="txtQty" id="txtQty" class="modalinput numbersinput" maxlength="8" value="<?php
        echo number_format($qty,2);?>" onkeyup="checkInput(this)" onblur="calcAmt(1)"></div>
        <div class="col-md-4"><label for="txtUP"><?php echo $yr+1;?> Unit Cost </label><td><INPUT name="txtUP" id="txtUP" class="modalinput numbersinput" maxlength="10" value="<?php
        echo number_format($up,2);?>" onkeyup="checkInput(this)" onblur="calcAmt(1)"></div>
        <div class="col-md-4"><label for="txtTtlCur"><?php echo $yr+1;?> Amount</label><input type="text" class="modalinput numbersinput modalinputdisabled" name="txtTtlCur" id="txtTtlCur"
        value="<?php echo number_format($amt,2);?>" readonly></div>
    </div><hr><div class="form-row">
        <div class="col-md-4"><button type="submit" name="CmdSave" id="save" class="btn btn-primary btn-block btn-md">Save Details</button></div>
        <div class="col-md-4"style="text-align:right;"><button type="submit" name="cmdDel" id="delete" <?php echo ($budgdel==0?"disabled":"");?> class="btn btn-info btn-md">Delete Item
				</button></div>
        <div class="col-md-4"style="text-align:right;"><a href="budgdraft.php"><button class="btn btn-info btn-md" type="button" name="CmdClose">Cancel/ Close</button></a></div>
    </div></form>
</div>
<script type="text/javascript" src="tpl/js/budgetAdd.js"></script>
<?php
    mysqli_close($conn); footer();
?>
