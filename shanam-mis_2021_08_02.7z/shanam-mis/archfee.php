<!DOCTYPE html>
<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	$ac=isset($_POST['cboAc'])?strip_tags($_POST['cboAc']):1;			$acname=$ac==1?"Main A/C":"Misc A/C";
	$mode=isset($_POST['cboMode'])?strip_tags($_POST['cboMode']):'%';	$modedet=strcasecmp($mode,'%')?"All":$mode; $yr=isset($_POST['CboYr1'])?strip_tags($_POST['CboYr1']):date('Y')-1;
	$sdate= isset($_POST['CboYr1'])?strip_tags($_POST['CboYr1']).'-'.strip_tags($_POST['CboMon1']).'-'.strip_tags($_POST['CboDays1']):date("Y-m-d");
	$edate= isset($_POST['CboYr2'])?strip_tags($_POST['CboYr2']).'-'.strip_tags($_POST['CboMon2']).'-'.strip_tags($_POST['CboDays2']):date("Y-m-d");
	$findby=isset($_POST['RadSearch'])?$_POST['RadSearch']:"recieptno";	$find=isset($_POST['TxtFind'])?$_POST['TxtFind']:"%";
	$find=strlen($find)==0?"%":$find;		$user=$_SESSION['priviledge'];
	$rsPriv=mysqli_query($conn,"SELECT feeview FROM Acc_Priv WHERE uname LIKE '".$_SESSION['username']."'");	
	$feeviu=0; list($feeviu)=mysqli_fetch_row($rsPriv);	mysqli_free_result($rsPriv);	
	if ($feeviu==0) header("location:vague.php");
	$months='<OPTION value="01">Jan</OPTION><OPTION value="02">Feb</OPTION><OPTION value="03" selected>Mar</OPTION><OPTION value="04">Apr</OPTION><OPTION value="05">May</OPTION><OPTION 
	value="06">Jun</OPTION><OPTION value="07">Jul</OPTION><OPTION value="08">Aug</OPTION><OPTION value="09">Sep</OPTION><OPTION value="10">Oct</OPTION><OPTION value="11">Nov</OPTION>
	<OPTION value="12">Dec</OPTION>';
?>
<html>
	<head>
    	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" /><link href="tpl/headers.css" rel="stylesheet" type="text/css" />
    	<link href="tpl/accprint.css" rel="stylesheet" type="text/css" media="print"/>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Main Account Fees</title>
		<script type="text/javascript" src="tpl/js/archfee.js"></script>
    </head>
<body background="img/bg3.gif"><div class="head">
	<form method="post" action="ArchFee.php" onsubmit="return verifyDate(this)">View <SELECT name="cboAc" id="cboAc" size=1><Option value=1 selected>Main</option><Option value=2>Misc.
	</option></SELECT> A/C Fee Paid in <SELECT name="cboMode" size=1><Option value="%" selected>All Modes</option><Option>Cash</option><Option>Direct Banking</option><Option>M-Fees
	</option><Option>Kind</option><Option>Money Order</option></SELECT> between <SELECT name="CboYr1" size="1" id="CboYr1" onchange="filldays('CboDays1')">
	<?php 
		$rs=mysqli_query($conn,"SELECT DISTINCT yr FROM arch_feerec WHERE markdel=0 ORDER BY yr DESC"); $optYr=""; 
		while($dyr=mysqli_fetch_row($rs)) $optYr.="<option>$dyr[0]</option>"; mysqli_free_result($rs); print "$optYr"; 
	?></SELECT>-<SELECT name="CboMon1" size="1" id="CboMon1" onchange="filldays('CboDays1')"><?php print $months;?></SELECT>-<SELECT name="CboDays1" size="1" id="CboDays1">
	<?php	
		$a=date('t',strtotime($yr.'-01-01')); $optDay=""; $ai=0;	for($i=1;$i<=$a;$i++){$optDay.="<option ".($ai==0?"Selected":"").">$i</option>"; $ai++;}
		print $optDay;
	?></SELECT> and <SELECT name="CboYr2" size="1" id="CboYr2" onchange="filldays('CboDays2')"><?php print "$optYr"; ?></SELECT>-<SELECT name="CboMon2" size="1" id="CboMon2" 
	onchange="filldays('CboDays2')"><?php print $months;?></SELECT>-<SELECT name="CboDays2" size="1" id="CboDays2"><?php print "$optDay"; ?></SELECT>
	<label for="TxtAd"> or Find By </label><input type="radio" name="RadSearch" id="RadSearch" value="admno">Adm. No. <input type="radio" name="RadSearch" id="RadSearch" value="recieptno" 
	checked>Receipt No.	<input type="text" maxlength="8" size="5" name="TxtFind" id="TxtFind" value="%"> <button type="submit" accesskey="s" name="Show">&nbsp;&nbsp;View Receipts&nbsp;
	&nbsp;</button></form></div>
    <?php
    	if (isset($_POST["Show"])){
    	 	if (strcmp($find,"%")!=0) $h="Finding $modedet $acname Fees Records";
			else $h="$modedet $acname Fee Receipts From <font color=\"#0000ff\">".date("D d-M-Y",strtotime($sdate))."</font> To <font color=\"#0000ff\">".date("D d-M-Y",
			strtotime($edate))."</font>";
    	}elseif (isset($_POST["Analysis"])) $h= "$acname Fee Analysis From <font color=\"#0000ff\">".date("D d-M-Y",strtotime($sdate))."</font> To <font color=\"#0000ff\">".
		date("D d-M-Y",strtotime($edate))."</font> of All Fee Receipts";
    	else $h="Fees Collection Manual (Please Read)";			
	print "<div id=\"print_content\"><h3>".strtoupper($h)."</h3><hr>";
	if (isset($_POST["Show"])):
		if ($ac==1){
			if (strcasecmp($find,"%")!=0){
				if (strcasecmp($findby,"admno")==0) $fee="SELECT f.recieptno,f.pytdate,f.paytform,f.cmono,s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) 
				As cls,f.bankcharges,f.arrears,f.prep,(f.amt-f.arrears-f.prep) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(m.recipetno),0,m.recipetno) as msrec FROM stud s Inner Join 
				class c Using (admno) Inner Join classnames cn USING (clsno) Inner Join arch_feerec f  On (c.admno=f.admno and c.curr_year=f.yr) Left Join (SELECT recipetno,yr,mainrecno 
				FROM arch_miscfeepyts WHERE markdel=0)m On (f.recieptno=m.mainrecno and f.yr=m.yr) WHERE (f.markdel=0 AND c.admno LIKE '$find' and c.curr_year LIKE '$yr') Order By 
				f.recieptno Asc";
				else $fee="SELECT f.recieptno,f.pytdate,f.paytform,f.cmono,s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,f.bankcharges,f.arrears,
				f.prep,(f.amt-f.arrears-f.prep) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(m.recipetno),0,m.recipetno) as misrec FROM stud s Inner Join class c Using (admno) 
				Inner Join classnames cn USING (clsno) Inner Join arch_feerec f  On (c.admno=f.admno and c.curr_year=f.yr) Left Join (SELECT recipetno,yr,mainrecno FROM arch_miscfeepyts 
				WHERE markdel=0)m On (f.recieptno=m.mainrecno and f.yr=m.yr) WHERE (f.markdel=0 AND f.recieptno LIKE '$find' AND c.curr_year LIKE '$yr') Order By f.recieptno Asc";
			}else{
				$fee="SELECT f.recieptno,f.pytdate,f.paytform,f.cmono,s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,f.bankcharges,f.arrears,f.prep,
				(f.amt-f.arrears-f.prep) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(m.recipetno),0,m.recipetno) as misrec FROM stud s Inner Join class c Using (admno) Inner 
				Join classnames cn USING (clsno) Inner Join arch_feerec f  On (c.admno=f.admno and c.curr_year=f.yr) Left Join (SELECT recipetno,yr,mainrecno FROM arch_miscfeepyts WHERE 
				markdel=0 and (pytdate BETWEEN '$sdate' AND '$edate'))m On (f.recieptno=m.mainrecno and f.yr=m.yr) WHERE f.markdel=0 AND (f.pytdate BETWEEN '$sdate' AND '$edate') and 
				f.paytform LIKE '$mode' Order By f.recieptno Asc";
			}	
		}else{
			if (strcasecmp($find,"%")!=0){
				if (strcasecmp($findby,"admno")==0) $fee="SELECT f.recipetno,f.pytdate,f.pytfrm,f.cheno,s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) 
				As cls,f.bankcharges,f.arrears,0,(f.amt-f.arrears) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(f.mainrecno),0,f.mainrecno) as recno FROM stud s Inner Join class c 
				Using (admno) Inner Join classnames cn USING (clsno) Inner Join arch_miscfeepyts f  On (c.admno=f.payeesno and c.curr_year=f.yr) WHERE (f.markdel=0 AND c.admno LIKE 
				'$find' AND c.curr_year LIKE '$yr') Order By f.recipetno Asc";
				else $fee="SELECT f.recipetno,f.pytdate,f.pytfrm,f.cheno,s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,f.bankcharges,f.arrears,0,
				(f.amt-f.arrears) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(f.mainrecno),0,f.mainrecno) as recno FROM stud s Inner Join class c Using (admno) Inner Join classnames cn 
				USING (clsno) Inner Join arch_miscfeepyts f  On (c.admno=f.payeesno and c.curr_year=f.yr) WHERE (f.markdel=0 AND f.recieptno LIKE '$find' AND c.curr_year LIKE '$yr') Order 
				By f.recieptno Asc";
			}else{
				$fee="SELECT f.recipetno,f.pytdate,f.pytfrm,f.cheno,s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,f.bankcharges,f.arrears,0,
				(f.amt-f.arrears) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(f.mainrecno),0,f.mainrecno) as recno FROM stud s Inner Join class c Using (admno) Inner Join classnames cn 
				USING (clsno) Inner Join arch_miscfeepyts f  On (c.admno=f.payeesno and c.curr_year=f.yr) WHERE f.markdel=0 AND (f.pytdate BETWEEN '$sdate' AND '$edate') and f.pytfrm LIKE 
				'$mode' and c.curr_year LIKE '$yr' Order By f.recipetno Asc";
			}
		} $res=mysqli_query($conn,$fee);
		print "<table border=\"1\" cellspacing=0><tr><th colspan=\"4\">Fee Receipt Details</th><th colspan=\"3\">Student's Details</th><th colspan=\"4\">Amount Received</th><th 
		rowspan=\"2\">Total<br>Fee Paid</th><th rowspan=\"2\">View<br>Receipt</th></tr><tr bgcolor=\"#eeeeee\"><th>Receipt<br>No.</th><th>Received On</th><th>Mode</th><th>Mode No.</th>
		<th>Adm. No.</th><th>Pupils' Names</th><th>Class</th><th>Bank Charges</th><th>Arrears</th><th>Prepaid</th><th>Fees</th></tr>";
		$i=0;$ttl=array(0,0,0,0,0);
		if (mysqli_num_rows($res)>0):
			while (list($rn,$pd,$pf,$cn,$an,$sn,$cls,$bc,$ar,$pre,$fe,$tt,$mrn)=mysqli_fetch_row($res)):
				$mrn=($mrn>0?$mrn:0);
				if (($i%2)==1) print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">";	else print "<tr>";
				print "<td align=\"center\">$rn</td><td align=\"right\">".date("D d-M-Y",strtotime($pd))."</td><td>$pf</td><td>$cn</td><td>$an</td><td>$sn</td><td>$cls</td><td 
				align=\"right\">".number_format($bc,2)."</td><td align=\"right\">".number_format($ar,2)."</td><td align=\"right\">".number_format($pre,2)."</td><td align=\"right\">".
				number_format($fe,2)."</td><td align=\"right\">".number_format($tt,2)."</td><td align=\"center\"><a href=\"".($ac==1?"archfeereceipt.php?recno=$rn-$mrn-".($mrn==0?1:0):
				"archfeereceipt.php?recno=$mrn-$rn-".($mrn==0?2:0))."-$yr\">View</td></tr>";
				$ttl[0]+=$bc; $ttl[1]+=$ar; $ttl[2]+=$fe; $ttl[3]+=$pre; $ttl[4]+=$tt; $i++;
			endwhile;
		else:
			print "<tr>";
			if (strcasecmp($find,"%")==0) print "<td colspan=\"13\"><br>No fees receipts were made between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate)).
			"</td>";
			else print "<td colspan=\"13\"><br>".(strcasecmp($findby,"admno")==0?"The student whose admission number is $find did not pay fees":"Reciept No. $find does not exist in the 
			system")." in the year $yr.</td>";
			print "</tr>";
		endif;
		print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\"><b>".mysqli_num_rows($res)." Fees Payment Records</b></td><td align=
		\"right\" colspan=\"3\"><b>Subtotals (Kshs.)</b></td>";
		foreach ($ttl as $ttla) print "<td align=\"right\"><b>".number_format($ttla,2)."</b></td>";
		print "<td colspan=\"2\"></td></tr></table></div><br><center><button onclick=\"Clickheretoprint()\">Print</button></center>";
		mysqli_free_result($res);
	elseif (isset($_POST['MiscShow'])):
		if (strcasecmp($find,"%")!=0):
			if (strcasecmp($findby,"admno")==0) $fee="SELECT f.recipetno,f.pytdate,f.pytfrm,f.cheno,s.admno,concat(s.surname,' ',s.onames) As names,concat(c.class,'-',c.stream) As cls,
			f.bankcharges,f.arrears,f.uni,(f.amt-f.arrears-f.uni) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(f.mainrecno),0,f.mainrecno) as mainrec FROM stud s Inner Join class c Using 
			(admno,curr_year) Inner Join acc_miscfeepyts f  On (s.admno=f.payeesno) WHERE (f.markdel=0 AND s.admno LIKE '$find' and f.curr_year LIKE '$yr') Order By f.recipetno Asc";
			else $fee="SELECT f.recipetno,f.pytdate,f.pytfrm,f.cheno,s.admno,concat(s.surname,' ',s.onames) As names,concat(c.class,'-',c.stream) As cls,f.bankcharges,f.arrears,f.uni,(f.amt-
			f.arrears-f.uni) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(f.mainrecno),0,f.mainrecno) as mainrec FROM stud s Inner Join class c Using (admno,curr_year) Inner Join 
			acc_miscfeepyts f  On (s.admno=f.payeesno)) WHERE (f.markdel=0 AND f.recieptno LIKE '$find' and f.curr_year LIKE '$yr') Order By f.recipetno Asc";
		else:
			$sdate=preg_split("/\-/",$sdate);	$edate=preg_split("/\-/",$edate);
			$fee="SELECT f.recipetno, f.pytdate, f.pytfrm, f.cheno, s.admno, concat(s.surname,' ',s.onames) As names, concat(c.class,'-',c.stream) As cls, f.bankcharges,f.arrears,f.uni,(
			f.amt-f.arrears-f.uni) as Fees,(f.bankcharges+f.amt) As Ttl,if(isnull(f.mainrecno),0,f.mainrecno) as mainrec FROM stud s Inner Join class c Using (admno,curr_year) Inner Join 
			acc_miscfeepyts f  On (s.admno=f.payeesno) WHERE (f.markdel=0 AND (f.pytdate BETWEEN '$sdate[2]-$sdate[1]-$sdate[0]' AND '$edate[2]-$edate[1]-$edate[0]') And c.class LIKE '$cls' 
			AND c.stream LIKE '$str')Order By f.recipetno Asc";
		endif;
		$res=mysqli_query($conn,$fee);
		print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr><th colspan=\"4\">Fee Receipt Details</th><th colspan=\"3\">Student's Details</th><th colspan=\"4\">Amount 
		Received</th><th rowspan=\"2\">Total<br>Amt Paid</th><th rowspan=\"2\">Print<br>Fee Receipt</th><th rowspan=\"2\">Edit Fee<br>Reciept</th></tr><tr bgcolor=\"#eeeeee\"><th>Receipt 
		No.</th><th>Received On</th><th>Recieved In</th><th>Trans/Cheque No.</th><th>Adm. No.</th><th>Students Names</th><th>Class</th><th>Bank Charges</th><th>Arrears Cleared</th><th>
		Uniform</th><th>Fees</th></tr>";
		$i=0;$ttl=array(0,0,0,0,0);
		if (mysqli_num_rows($res)>0):
			while (list($rn,$pd,$pf,$cn,$an,$sn,$cls,$bc,$ar,$un,$fe,$tt,$mrn)=mysqli_fetch_row($res)):
				$nod=($today-strtotime($pd))/86400;
				if (($i%2)==1)
					print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">";
				else
					print "<tr>";
				print "<td align=\"center\">".(($nod<30 && $feed==1 && (strcasecmp($user,"administrator")==0 || strcasecmp($user,"Manager")==0))?"<a href=\"miscfeerecedit.php?recno=$rn\">
				$rn</a>":"$rn")."</td><td align=\"right\">".date("D d-M-Y",strtotime($pd))."</td><td>$pf</td><td>$cn</td><td>$an</td><td>$sn</td><td>$cls</td><td align=\"right\">".
				number_format($bc,2)."</td><td align=\"right\">".number_format($ar,2)."</td><td align=\"right\">".number_format($un,2)."</td><td align=\"right\">".number_format($fe,2).
				"</td><td align=\"right\">".number_format($tt,2)."</td><td align=\"center\"><a href=\"receipt.php?recno=$mrn-$rn-".($mrn==0?2:0)."-1\">Print</td><td align=\"center\">".
				($nod<2?"<a onclick=\"return canedit($feed)\" href=\"miscfeerecedit.php?recno=$rn\">Edit</a>":"Sealed!!")."</td></tr>";
				$ttl[0]+=$bc; $ttl[1]+=$ar; $ttl[2]+=$un; $ttl[3]+=$fe; $ttl[4]+=$tt; $i++;
			endwhile;
		else:
			print "<tr>";
			if (strcasecmp($admno,"%")==0) 
				print "<td colspan=\"14\"><br>No fees receipts were made between ".date("D d-M-Y",strtotime($sdate[2].'-'.$sdate[1].'-'.$sdate[0]))." and ".date("D d-M-Y",
				strtotime($edate[2].'-'.$edate[1].'-'.$edate[0]))."</td>";
			else
				print "<td colspan=\"14\"><br>The student whose admission number is $admno has not paid fees</td>";
			print "</tr>";
		endif;
		print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\"><b>".mysqli_num_rows($res)." Fees Payment Records</b></td><td align=\"right\" colspan=\"3\"><b>Subtotals (Kshs.)</b>
		</td>";
		foreach ($ttl as $ttla) print "<td align=\"right\"><b>".number_format($ttla,2)."</b></td>";
		print "<td colspan=\"2\"></td></tr></table></div><br><center><button onclick=\"Clickheretoprint()\">Print</button></center>";
	else:
		print "<font size=\"3\" color=\"#0000ee\"><p class=\"g\">This interface allows you to view the following Main Account Fees details
		<ol type=\"i\"><li>Fee Receipt Records<li>Fees Collection Analysis (Per payment form and Votehead)<li>Student's Fee Payment History
		</ol></p>";
		print "<p class=\"g\"><b><u>Fee Reciept Records</u></b></p><ol type=\"a\"><li> Select the range of date between which fee reciepts 
		were made<li>Select course, level and class<li>Do not enter receipt and admission number.<ul type=\"circle\"><li>Entering Admission 
		number will display only fee payment records of the respective student<li>Entering Reciept number, will display fee record of the 
		entered number</ul><li>Click <b>Receipts</b> button<li>You can click <u>Print</u> to print a duplicate receipt.<li>Click <u>Edit</u> to 
		make changes or delete the respective receipt. However, you MUST have priviledges of editing.</ol>";
		print "<p class=\"g\"><b><u>Fee Collection Analysis (Display Fee payment Analysis per votehead and form of payment)</u></b></p>
		<ol type=\"a\"><li>Select the range of date between which fee reciepts were made <li>It is irrelant to enter Admission or Reciept 
		number.	<li>Click <b>Analysis</b> button</ol>";
		print "<p class=\"g\"><b><u>Student's Fee Payment History</u></b></p><ol type=\"a\"><li> Enter student's Admission number<li>Click 
		<b>Receipts</b> button</ol>";
	endif;
	mysqli_close($conn);
?>
</body></html>