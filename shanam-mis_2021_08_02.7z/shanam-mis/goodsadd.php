<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['action'])?trim(strip_tags($_REQUEST['action'])):"0"; //itmcode to be edited
    class Accounts{
        private $acc, $descr;
        function __construct($a,$d){$this->acc=$a;	$this->descr=$d;}
        public function valAcNo(){return $this->acc;}	public function valAcName(){return $this->descr;}
    }
    if (isset($_POST['btnSave'])):
        $act=isset($_POST['txtOrigItemNo'])?sanitize($_POST['txtOrigItemNo']):'0-0';	$act=preg_split('/\-/',$act); //[0] is itmcode to be edited [1] No of Acs
        $itmno=isset($_POST['txtItemNo'])?sanitize($_POST['txtItemNo']):'0';            $acno=isset($_POST['txtInfo1'])?sanitize($_POST['txtInfo1']):'0';
        $categ=isset($_POST['cboCateg'])?strtoupper(sanitize($_POST['cboCateg'])):'CONSUMABLE';		$itmde=isset($_POST['cboDept'])?sanitize($_POST['cboDept']):'';
        $item=isset($_POST['txtItem'])?mysqli_real_escape_string($conn,strtoupper(strtoupper(sanitize($_POST['txtItem'])))):"";
        $units=isset($_POST['cboUnits'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['cboUnits']))):'PIECES';
        $max=isset($_POST['txtMax'])?sanitize($_POST['txtMax']):0;					$max=preg_replace("/[^0-9^\.]/","",$max);
        $min=isset($_POST['txtMin'])?sanitize($_POST['txtMin']):0;					$min=preg_replace("/[^0-9^\.]/","",$min);
        $up=isset($_POST['txtUP'])?sanitize($_POST['txtUP']):0; 				  	$up=preg_replace("/[^0-9^\.]/","",$up);
        $sqlvotes='';                                                                                   $itmde=$itmde==0?null:$itmde;
        for($i=0;$i<$act[1];$i++) {
          $votes=isset($_POST['cboVotes_'.$i])?sanitize($_POST['cboVotes_'.$i]):'0-0'; 			$votes=preg_split('/\-/',$votes); //[0] A/C No. [1] VOTEHEAD
          $ovotes=isset($_POST['txtVoteH_'.$i])?sanitize($_POST['txtVoteH_'.$i]):'0-0'; 		$ovotes=preg_split('/\-/',$ovotes); //Original [0] A/C No. [1] VOTEHEAD
          if($ovotes[1]>0 && $votes[1]==0) $sqlvotes.="DELETE FROM itemvote WHERE itmcode LIKE '$act[0]' and ac LIKE '$ovotes[0]' and voteno LIKE '$ovotes[1]';";
          if($ovotes[1]==0 && $votes[1]>0){
            $sqlvotes.="INSERT INTO itemvote(itmcode,ac,voteno) VALUES ($itmno,$votes[0],$votes[1]);";
          }elseif($ovotes[1]!=$votes[1]){
            $sqlvotes.="UPDATE itemvote SET itmcode=$itmno,ac=$votes[0],voteno=$votes[1] WHERE itmcode LIKE '$act[0]' and ac LIKE '$ovotes[0]' and voteno LIKE '$ovotes[1]';";
          }
        }if ((strlen($itmno)==0 || strlen($item)<5 || strlen($categ)<5 || $up<1 || $max<5 || $min<0)){
            print "<h4 style=\"color:#f00;text-align:center;letter-spacing:2px;word-spacing:4px;\">You must enter valid item code, name, category, user department, Unit price, Maximum stock
            level and minimum stock level before saving.<br>Click <a href=\"goods.php\"> HERE </a> to go back.</h4>"; exit(0);
        }else{
            mysqli_multi_query($conn,"UPDATE items SET itmcode='$itmno',itemname='$item',categ='$categ',deptno=".var_export($itmde,true).",units='$units',maxstock=$max,minstock=$min,unitprice='$up' WHERE
            itmcode LIKE '$act[0]'; $sqlvotes") or die(mysqli_error($conn). " Item Description not updated. Click <a href=\"goods.php?action=0-0\">HERE</a>to go try again.");
            $i=0; do{$i+=mysqli_affected_rows($conn);}while (mysqli_next_result($conn));   $i=($i>0?1:0);
            header("location:goods.php?action=1-$i"); exit(0);
        }
    elseif (isset($_POST['btnDelete'])):
        $itmno=trim(strip_tags($_POST['txtOrigItemNo'])); $act=preg_split('/\-/',$act); //[0] is itmcode to be edited [1] No of Acs
        mysqli_query($conn,"UPDATE Items SET markdel=1 WHERE itmcode LIKE '$act[0]'") or die(mysqli_error($conn). " Item not deleted. Click <a href=\"goods.php>here</a> to
        go try again.");
        $i=mysqli_affected_rows($conn);
        header("location:goods.php?action=2-$i");  exit(0);
    endif;
    $votes=$convotes=$fvotes=""; $noacs=0;
    $rs=mysqli_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE markdel=0 ORDER BY acno ASC;");
    while($data=mysqli_fetch_row($rs)){
        $accounts[]=new Accounts($data[0],$data[1]); 	$noacs++;
        $votes.=",if(i.ac like '$data[0]' , v.sno,0) as ac$data[0]";
        $convotes.=",sum(ac$data[0]) as g$data[0]"; $fvotes.=",it.g$data[0]";
    }
    $sql="SELECT i.itmcode,i.itemname,i.categ,if(isnull(i.deptno),0,d.deptno)as dn,i.units,i.maxstock,i.minstock,i.unitprice $fvotes FROM items i Left Join (SELECT itmcode $convotes
    FROM (SELECT i.itmcode $votes FROM itemvote i Inner Join acc_votes v On (i.voteno=v.sno))i Group By itmcode)it USING (itmcode) LEFT JOIN depts d ON (i.deptno=d.deptno) WHERE
    i.markdel=0 and i.itmcode LIKE '$act' ORDER BY i.itemname ASC;";
    headings('<link rel="stylesheet" href="tpl/css/inputsettings.css" type="text/css"/>',0,0,1);
?><div class="container divgen">
  <FORM action="goodsadd.php" name="Adding" Method="POST" onsubmit="return validateFormOnSubmit(this)"><Input name="txtOrigItemNo" id="txtOrigItemNo" type="hidden" value="<?php
    echo "$act-$noacs";?>">
  <div class="form-row"><div class="col-md-12 divsubheading">ITEM/ SERVICE DEFINITION INTERFACE</div>
  </div><div class="form-row">
      <div class="col-md-3"><label for="txtItemNo">Item Code</label><Input name="txtItemNo" id="txtItemNo" type="text" value="<?php echo $act;?>" maxlength="6" class="modalinput"
        onkeyup="checkInput(this)"></div>
      <div class="col-md-4"><label for="cboCateg">Category of the Item</label><SELECT name="cboCateg" id="cboCateg" size="1" class="modalinput" >
        <?php
            mysqli_multi_query($conn,"$sql SELECT categ FROM grps WHERE categ IS NOT NULL or categ Not LIKE '' ORDER BY categ ASC; SELECT deptno,deptname FROM depts WHERE markdel=0;
            SELECT sno,acc,descr FROM acc_votes WHERE markdel=0 and pyt_defined=1 and sno>5;");
            $i=0; $optVotes='';
            do{
              if($rs=mysqli_store_result($conn)){
                if($i==0){
                    $data=mysqli_fetch_row($rs);
                }elseif($i==1){
                    if (mysqli_num_rows($rs)>0) while (list($cat)=mysqli_fetch_row($rs)) print "<option ".(strcasecmp($cat,$data[2])==0?"selected":"").">$cat</option>";
                    print "</SELECT></div><div class=\"col-md-5\"><label for=\"cboDept\">User Department</label><SELECT name=\"cboDept\" size=\"1\" class=\"modalinput\"><option
                    value=\"0\" ".($data[3]==0?"selected":"").">GENERAL USE</option>";
                } elseif($i==2){
                    if (mysqli_num_rows($rs)>0) while (list($dno,$dep)=mysqli_fetch_row($rs)) print "<option value=\"$dno\" ".($dno==$data[3]?"selected":"").">$dep</option>";
                    print"</SELECT></div></div><div class=\"form-row\"><div class=\"col-md-12\"><label for=\"txtName\">Name of the Item</label><input type=\"text\" name=\"txtItem\"
                    id=\"txtItem\" maxlength=\"29\" class=\"modalinput\" value=\"$data[1]\"></div></div>";
                    print "<div class=\"form-row\"><div class=\"col-md-12 divsubheading\">STOCK LIMITS &AMP; PRICE OF THE ITEM/SERVICE</div></div><div class=\"form-row\"><div
                    class=\"col-md-3\"><label for=\"cboUnits\">Units of Measure</label><SELECT name=\"cboUnits\" id=\"cboUnits\" size=\"1\" class=\"modalinput\"><option
                    value=\"Pieces\" ".(strcasecmp($data[4],"pieces")==0?"Selected":"").">Pieces</option><option value=\"crates\" ".(strcasecmp($data[4],"crates")==0?"Selected":"").
                    ">Crates</option><option value=\"Dozen\" ".(strcasecmp($data[4],"dozen")==0?"Selected":"").">Dozen</option><option value=\"Grams\" ".(strcasecmp($data[4],
                    "Grams")==0?"Selected":"").">Grams</option><option value=\"Hours\" ".(strcasecmp($data[4],"hours")==0?"Selected":"").">Hours</option><option value=\"Days\" ".
                    (strcasecmp($data[4],"Days")==0?"Selected":"").">Days</option><option value=\"Months\" ".(strcasecmp($data[4],"months")==0?"Selected":"").">Months</option><option
                    value=\"Kg\" ".(strcasecmp($data[4],"kg")==0?"Selected":"").">Kg</option><option value=\"Litres\" ".(strcasecmp($data[4],"litres")==0?"Selected":"").">Litres
                    </option><option value=\"Metres\" ".(strcasecmp($data[4],"metres")==0?
                    "Selected":"").">Metres</option><option value=\"Packets\" ".(strcasecmp($data[4],"packets")==0?"Selected":"").">Packets</option><option value=\"Pairs\" ".
                    (strcasecmp($data[4],"pairs")==0?"Selected":"").">Pairs</option><option value=\"Persons\" ".(strcasecmp($data[4],"persons")==0?"Selected":"").">Persons</option>
                    <option value=\"Sets\" ".(strcasecmp($data[4],"Sets")==0?"Selected":"").">Sets</option><option value=\"Reams\" ".(strcasecmp($data[4],"reams")==0?"Selected":"").
                    ">Reams</option><option value=\"Tonnes\" ".(strcasecmp($data[4],"tonnes")==0?"Selected":"").">Tonnes</option><option value=\"Bag\"  ".
                    (strcasecmp($data[4],"Bag")==0?"Selected":"").">Bag</option><option value=\"Bales\" ".(strcasecmp($data[4],"Bales")==0?"Selected":"").">Bales</option></select>";
                    print '</div><div class="col-md-3"><label for="txtMax">Max. Stock Level</label><Input name="txtMax" id="txtMax" type="text" value="'.$data[5].'" maxlength="7"
                    class="modalinput numbersinput" onkeyup="checkInput(this)"></div><div class="col-md-3"><label for="txtMax">Min. Stock Level</label><Input name="txtMin"
                    id="txtMin" type="text" value="'.$data[6].'" maxlength="7" class="modalinput numbersinput" onkeyup="checkInput(this)"></div><div class="col-md-3"><label
                    for="txtMax">Unit Price</label><Input name="txtUP" id="txtUP" type="text" value="'.$data[7].'" maxlength="7" class="modalinput numbersinput"
                    onkeyup="checkInput(this)"></div></div>';
                    print "<div class=\"form-row\"><div class=\"col-md-12 divsubheading\">VOTEHEADS ON WHICH THE ITEM CAN BE COSTED</div></div>";
                }else{
                    print "<div class=\"form-row\">"; $index=0; $r=8;
                    foreach($accounts as $acc){
                        mysqli_data_seek($rs,0); print "<div class=\"col-md-4\" style=\"margin:10px 0;border-top:1px solid #f66;\"><label for=\"cboVotes_$index\">".$acc->valAcName()."
                        </label><SELECT name=\"cboVotes_$index\" id=\"cboVotes_$index\" size=\"1\" class=\"modalinput\"><option value=\"0-0\" ".(strlen($data[$r])==0?"selected":"").">None
                        </option>";
                        while($dt=mysqli_fetch_row($rs)){
                            if($dt[1]==$acc->valAcNo()) print "<option value=\"$dt[1]-$dt[0]\"  ".(strcasecmp(trim($data[$r]),$dt[0])==0?"selected":"").">$dt[2]</option>";
                        }print "</select><input type=\"hidden\" name=\"txtVoteH_$index\" value=\"".$acc->valAcNo()."-$data[$r]\"></div>"; $index++; $r++;
                    }
                }mysqli_free_result($rs);
              }$i++;
            }while(mysqli_next_result($conn));
        ?>
    </div><div class="form-row" style="margin:10px 0;border-top:1px solid #9f6;padding:5px;">
        <div class="col-md-5"><button type="submit" name="btnSave" id="btnSave" class="btn btn-primary btn-block btn-lg">Save Item/Service</button></div>
        <div class="col-md-1"></div>
        <div class="col-md-3"><button type="submit" name="btnDelete" id="btnDelete" class="btn btn-warning btn-block btn-lg">Delete Item</button></div>
        <div class="col-md-1"></div>
        <div class="col-md-2"><a href="goods.php"><button type="button" name="btnclose" id="btnclose" class="btn btn-info btn-block btn-lg">Close</button></a></div>
    </div></form>
  </div>
<script type="text/javascript" src="tpl/js/goodsadd.js"></script>
<?php mysqli_close($conn); footer();?>
<script type="text/javascript">
    $(document).ready(function(){//for sorting the units of sale
       var opt=$("#cboUnits option").sort(function(a,b){return a.value.toUpperCase().localeCompare(b.value.toUpperCase())});
       $("#cboUnits").append(opt);
    });
</script>
