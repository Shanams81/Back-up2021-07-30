<?php
	include_once('shanam.php');
	if (isset($_POST["CmdSaveRecord"])){
		$inadmno=trim($_POST['txtInit']);	$inadmno=preg_split('/\-/',$inadmno);
		$admno=isset($_POST['txtAdmNo'])?sanitize($_POST['txtAdmNo']):Null; 		$county=isset($_POST['cboCounty'])?sanitize($_POST['cboCounty']):'001';
		$admno=((strcasecmp($admno,"auto")==0)||(strlen($admno)==0))?Null:$admno;	$lvl=isset($_POST['cboLevel'])?strtoupper(sanitize($_POST['cboLevel'])):'';
		$birthno=isset($_POST['txtBirthNo'])?trim(strip_tags($_POST['txtBirthNo'])):'xxxxx'; $mp=isset($_POST['cboConst'])?sanitize($_POST['cboConst']):'001';
		$dob=$_POST['cboYr']."-".$_POST['cboMon']."-".$_POST['cboDays']; 		$acyr=isset($_POST['cboAcYr'])?trim(strip_tags($_POST['cboAcYr'])):date('Y');
		$surname=isset($_POST['txtSurname'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtSurname']))):''; $mca=isset($_POST['cboWard'])?sanitize($_POST['cboWard']):'0001';
		$onames=isset($_POST['txtONames'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtONames']))):'';
		$admda=isset($_POST['dtpAdmDate'])?sanitize($_POST['dtpAdmDate']):date('d-m-Y'); $admda=preg_split("/\-/",$admda);  $admdate=$admda[2].'-'.$admda[1].'-'.$admda[0];
		$form=isset($_POST['cboForm'])?strtoupper(sanitize($_POST['cboForm'])):''; 	$strm=isset($_POST['cboStream'])?strtoupper(sanitize($_POST['cboStream'])):'';
		$guard=isset($_POST['txtGuardian'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtGuardian']))):'';
		$relation=isset($_POST['cboRelation'])?strtoupper(sanitize($_POST['cboRelation'])):'FATHER';	$occup=isset($_POST['cboOccup'])?strtoupper(sanitize($_POST['cboOccup'])):'TEACHER';
		$address=isset($_POST['txtPAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPAddress']))):Null;
		$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):Null; $pres=isset($_POST['chkPresent'])?sanitize($_POST['chkPresent']):0;
		$locat=isset($_POST['txtLocation'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtLocation']))):'';
		$sublocat=isset($_POST['txtSubLocation'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtSubLocation']))):''; $regdon=date("Y-m-d H:n:s");
		$village=isset($_POST['txtVillage'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtVillage']))):'';	$un=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		$illness=isset($_POST['txtIllness'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtIllness']))):'None';$illness=strlen($illness)<5?'None':$illness;
		$allergy=isset($_POST['txtAllergy'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAllergy']))):'None';$allergy=strlen($allergy)<5?'None':$allergy;
		$nemis=isset($_POST['txtNEMISNo'])?strtoupper(sanitize($_POST['txtNEMISNo'])):Null;	 $nemis=strlen($nemis)==0?null:preg_replace('/[^a-zA-Z0-9]/','',$nemis);
		if(strlen($surname)<3 || strlen($onames)<5 || strlen($form)==0|| strlen($strm)==0 || strlen($lvl)==0 || strlen($county)==0 || strlen($mp)==0 || strlen($mca)==0 || strlen($guard)<8){
			print "SERVER ERROR <font color=\"#cc0000\">Ensure student's names, guardian's names, class/form, county, constituency, location, sub-location and village fields are validly
			entered before trying to saving</font>";
		}else{
			mysqli_multi_query($conn,"UPDATE stud SET admno='$admno',nemisno=".var_export($nemis,true).",surname='$surname',onames='$onames',address=".var_export($address,true).",telno=".var_export($telno,true).",
			guardian='$guard',relation='$relation',admdate='$admdate',dob='$dob',countyno='$county',constituencyno='$mp',wardno='$mca',curr_year='$acyr',location='$locat',sublocation='$sublocat',village='$village',
			illness='$illness',alergies='$allergy',occupation='$occup',birthcertno='$birthno',present='$pres' WHERE admno LIKE '$inadmno[0]'; UPDATE class SET curr_year='$acyr',clsno='$form',stream='$strm',lvlno='$lvl'
			WHERE (admno LIKE '$inadmno[0]' AND curr_year LIKE '$inadmno[1]');") or die(mysqli_error($conn)." Student details were not successfully saved. Click <a href=\"studadd.php\">HERE</a> to try again.");
			$i=0; do{$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=($i>0?1:0); header("location:student.php?action=1-$i");
		}exit(0);
	}else{
		$adm=isset($_REQUEST['admno'])?strip_tags($_REQUEST['admno']):"0-0"; $adm=preg_split('/\-/',$adm);
		mysqli_multi_query($conn,"SELECT s.admno,s.nemisno,s.surname,s.onames,s.address,s.telno,s.guardian,s.relation,s.occupation,s.admdate,s.dob,s.curr_year,s.countyno,s.constituencyno,s.wardno,s.location,s.sublocation,
		s.village,s.illness,s.alergies,s.birthcertno,sf.clsno,sf.stream,sf.lvlno,s.present FROM stud s Inner Join class sf Using (admno,curr_year) WHERE s.admno LIKE '$adm[0]'; SELECT studdel FROM gen_priv WHERE uname LIKE
		'".$_SESSION['username']."';SELECT code,name FROM county ORDER BY name ASC; SELECT code,name,codecounty FROM constituency ORDER BY codecounty,name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC;
		SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC;"); $i=$delpriv=0;	$optCounty=$optMP=$optMCA='';
		do{
			if($rs=mysqli_store_result($conn)){
				if ($i==0) $stud=mysqli_fetch_row($rs); elseif($i==1) list($delpriv)=mysqli_fetch_row($rs);
				elseif($i==2) while (list($s,$n)=mysqli_fetch_row($rs)) $optCounty.="<option ".($stud[12]==$s?"selected":"")." value=\"$s\">$n</option>";
				elseif($i==3){$mp='';$a=0;while(list($s,$n,$c)=mysqli_fetch_row($rs)){$mp.=($a==0?"":",")."new Consti(\"$s\",\"$n\",\"$c\")";
					if($stud[12]==$c) $optMP.="<option ".($stud[13]==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
				}else{$mca='';$a=0;while (list($s,$n,$c)=mysqli_fetch_row($rs)){$mca.=($a==0?"":",")."new MCA(\"$s\",\"$n\",\"$c\")";
					if($c==$stud[13]) $optMCA.="<option ".($stud[14]==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
		  	}mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn));
	}
	headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css"/><link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css"/>',0,0,2);
?>
<br><form method="post" action="studedit.php">
<div class="container" style="width:fit-content;background-color:#e6e6f6;"><div class="divheadings">STUDENT REGISTRATION	INTERFACE</div>
	<ul class="nav nav-tabs" id="myTabs">
	    <li class="nav-item active"><a class="nav-link active" data-toggle="tab" id="details-tab" href="#details">Student Details</a></li>
	    <li class="nav-item"><a class="nav-link" data-toggle="tab" id="other-tab" href="#other">Other Details</a></li>
	</ul>
	<div class="tab-content" id="myTabContent">
	    <div id="details" class="tab-pane fade show active" role="tabpanel" aria-labelledby="details-tab">
			<div class="form-row"><input type="hidden" name="txtInit" id="txtInit" maxlength="5" value="<?php echo $stud[0].'-'.$stud[11];?>">
				<div class="col-md-3"><label for="txtAdmNo">Admission No. </label><input type="text" name="txtAdmNo" id="txtAdmNo" maxlength="5" value="<?php echo $stud[0];?>"
					placeholder="Auto generated" class="modalinput"></div>
				<div class="col-md-2"><label for="txtNEMISNo">NEMIS No. </label><input type="text" name="txtNEMISNo" id="txtNEMISNo" maxlength="5" class="modalinput" value="<?php echo $stud[1];?>"
					placeholder="A0001"></div>
				<div class="col-md-3"><label for="txtBirthNo">Birth Certificate No.</label><Input type="text" name="txtBirthNo" id="txtBirthNo" maxlength="10" value="<?php echo $stud[20];?>"
					placeholder="0000000" class="modalinput"></div>
				<div class="col-md-4"><label for="cboYr">Date of Birth</label><div class="controls form-inline"><SELECT name="cboYr" size="1" id="cboYr" onchange="filldays('cboDays')"
					class="col-md-4 modalinput"><?php $date=preg_split('/\-/',$stud[10]); $date[1]=(int)$date[1]; $date[2]=(int)$date[2];	$a=(date('Y')-2); for($i=$a; $i>($a-30);$i--) echo "<option ".
					($date[0]==$i?"selected":"").">$i</option>"; ?></SELECT>-<SELECT name="cboMon" size="1" id="cboMon" class="col-md-4 modalinput" onchange="filldays('cboDays')"><OPTION value="01"
					<?php echo ($date[1]==1?"selected":"");?>>Jan</OPTION><OPTION value="02" <?php echo ($date[1]==2?"selected":"");?>>Feb</OPTION><OPTION value="03" <?php echo ($date[1]==3?
					"selected":"");?>>Mar</OPTION><OPTION value="04" <?php echo ($date[1]==4?"selected":"");?>>Apr</OPTION><OPTION value="05" <?php echo ($date[1]==5?"selected":"");?>>May</OPTION>
					<OPTION value="06" <?php echo ($date[1]==6?"selected":"");?>>Jun</OPTION><OPTION value="07" <?php echo ($date[1]==7?"selected":"");?>>Jul</OPTION><OPTION value="08" <?php
					echo ($date[1]==8?"selected":"");?>>Aug</OPTION><OPTION value="09" <?php echo ($date[1]==9?"selected":"");?>>Sep</OPTION><OPTION value="10" <?php echo ($date[1]==10?
					"selected":"");?>>Oct</OPTION><OPTION <?php echo ($date[1]==11?"selected":"");?> value="11">Nov</OPTION><OPTION value="12" <?php echo ($date[1]==12?"selected":"");?>>
					Dec</OPTION></SELECT>-<SELECT name="cboDays" size="1" id="cboDays" class="col-md-3 modalinput"><?php $a=date('t',strtotime($date[0].'-'.$date[1].'-01'));
					for($i=$a;$i>0;$i--) print "<option ".(($date[2]==$i)?"selected":"").">$i</option>";?></SELECT></div></div>
			</div><div class="form-row">
				<div class="col-md-3"><label for="txtSurname">Surname *</label><input type="text" name="txtSurname" id="txtSurname" maxlength="12" value="<?php echo $stud[2];?>"
				placeholder="Shanam" required class="modalinput"></div>
				<div class="col-md-7"><label for="txtONames">Other Names *</label><input type="text" name="txtONames" id="txtONames" value="<?php echo $stud[3];?>" maxlength="30"
					placeholder="Shanam" required  class="modalinput"></div>
				<div class="col-md-2"><label for="dtpAdmDate">Admitted On *</label><input type="text"	name="dtpAdmDate" class="tcal modalinput" <?php print "value=\"".date("d-m-Y",
				strtotime($stud[9]))."\"";?> readonly></div>
			</div><br><div class="form-row"><div class="col-md-12 divsubheading">DETAILS OF STUDENT GRADE/FORM AND STREAM</div></div>
			<div class="form-row">
				<div class="col-md-3"><label for="cboLevel">Level *</level><SELECT name="cboLevel" id="cboLevel" size="4" onchange="loadClasses(this)" required class="modalinput">
				<?php
					mysqli_multi_query($conn,"SELECT lvlno,lvlname FROM classlvl ORDER BY lvlno; SELECT clsno,clsname FROM classnames WHERE lvlno LIKE '$stud[23]' ORDER BY clsno; SELECT strm FROM grps WHERE strm is not null;")
					or die(mysqli_error($conn).' Error in database connection'); $i=0;
					do{
						if($rs=mysqli_store_result($conn)){
							if($i==0){if (mysqli_num_rows($rs)>0){while (list($lvl,$lvlname)=mysqli_fetch_row($rs)) echo "<option value=\"$lvl\" ".($stud[23]==$lvl?"selected":"").">$lvlname</option>";} echo '</SELECT></div>';
							}elseif($i==1){print '<div class="col-md-3"><label for="cboForm">Grade/ Form *</level><span id="clsNames"><SELECT name="cboForm" id="cboForm" size="4" required  class="modalinput">';
								if (mysqli_num_rows($rs)>0) while(list($cls,$clsname)=mysqli_fetch_row($rs)) echo "<option ".($stud[21]==$cls?"selected":"")." value=\"$cls\">$clsname</option>";		echo '</SELECT></span></div>';
							}else{echo '<div class="col-md-3"><label for="cboStream">Stream *</level><SELECT name="cboStream" id="cboStream" size="4" required  class="modalinput">';
								if (mysqli_num_rows($rs)>0) while(list($strm)=mysqli_fetch_row($rs)) echo "<option ".(strcasecmp($stud[22],$strm)==0?"selected":"").">$strm</option>";	echo "</SELECT></div>";
							}mysqli_free_result($rs);
						}$i++;
					}while(mysqli_next_result($conn));
					print '<div class="col-md-3"><label for="cboAcYr">Academic Year</label><SELECT name="cboAcYr" id="cboAcYr" size="4" required  class="modalinput">';	$i=date("Y");
					for ($a=$i;$a>($i-15);$a--) print "<option ".(($a==$stud[11])?"selected":"").">$a</option>";
				?></SELECT></div>
			</div><div class="form-row"><br><div class="col-md-12 divsubheading">DETAIL OF THE GUARDIAN/ PARENT</div>
			</div>
			<div class="form-row">
				<div class="col-md-9"><label for="txtGuardian">Name of Parent/Guardian *</label><input type="text" maxlength="30" name="txtGuardian" value="<?php echo $stud[6];?>"
				placeholder="Were xxxxxx" style="text-transform:uppercase;" id="txtGuardian" required  class="modalinput"></div>
				<div class="col-md-3"><label for="cboRelation">Relationship</label><td><SELECT name="cboRelation" id="cboRelation" size="1"  class="modalinput"><option <?php
				echo (strcasecmp($stud[7],
				"father")==0?"selected":"");?>>Father</option><option <?php echo (strcasecmp($stud[7],"mother")==0?"selected":"");?>>Mother</option><option <?php echo (strcasecmp($stud[7],
				"brother")==0?"selected":"");?>>Brother</option><option <?php echo (strcasecmp($stud[7],"sister")==0?"selected":"");?>>Sister</option><option <?php echo (strcasecmp($stud[7],
				"uncle")==0?"selected":"");?>>Uncle</option><option <?php echo (strcasecmp($stud[7],"aunt")==0?"selected":"");?>>Aunt</option><option <?php echo (strcasecmp($stud[7],
				"in-law")==0?"selected":"");?>>In-law</option><option <?php echo (strcasecmp($stud[7],"other")==0?"selected":"");?>>Other</option></SELECT></div>
			</div><div class="form-row">
				<div class="col-md-5"><label for="txtAddress">Postal Address</label><TEXTAREA rows="2" maxlength="35" name="txtPAddress" id="txtPAddress"  class="modalinput"><?php
				echo $stud[4];?></textarea></div>
				<div class="col-md-3"><label for="txtTelNo">Tel No.</label><input type="text" maxlength="13" name="txtTelNo" id="txtTelNo" value="<?php echo $stud[5];?>"
				placeholder="0700000000" class="modalinput"></div>
				<div class="col-md-3"><label for="cboOccup">Occupation *</label><td><SELECT name="cboOccup" id="cboOccup" size="1" class="modalinput"><option <?php echo (strcasecmp($stud[8],
				"accountant")==0?"selected":"");?>>Accountant</option><option <?php echo (strcasecmp($stud[8],"administrator")==0?"selected":"");?>>Administrator</option><option <?php
				echo (strcasecmp($stud[8],"banker")==0?"selected":"");?>>Banker</option><option <?php echo (strcasecmp($stud[8],"businessman")==0?"selected":"");?>>Businessman</option>
				<option <?php echo (strcasecmp($stud[8],"civil servant")==0?"selected":"");?>>Civil Servant</option><option <?php echo (strcasecmp($stud[8],"doctor")==0?"selected":"");?>>
				Doctor</option><option <?php echo (strcasecmp($stud[8],"driver")==0?"selected":"");?>>Driver</option><option <?php echo (strcasecmp($stud[8],"engineer")==0?"selected":"");?>>
				Engineer</option><option <?php echo (strcasecmp($stud[8],"farmer")==0?"selected":"");?>>Farmer</option><option <?php echo (strcasecmp($stud[8],"manager")==0?"selected":"");?>>
				Manager</option><option <?php echo (strcasecmp($stud[8],"nurse")==0?"selected":"");?>>Nurse</option><option <?php echo (strcasecmp($stud[8],"politician")==0?"selected":"");?>>
				Politician</option><option <?php echo (strcasecmp($stud[8],"secretary")==0?"selected":"");?>>Secretary</option><option <?php echo (strcasecmp($stud[8],"self employed")==0?
				"selected":"");?>>Self Employed</option><option <?php echo (strcasecmp($stud[8],"teacher")==0?"selected":"");?>>Teacher</option><option <?php echo (strcasecmp($stud[8],
				"technician")==0?"selected":"");?>>Technician</option></select></div>
				<div class="col-md-1"><br><label for="chkPresent"><input type="checkbox" name="chkPresent" id="chkPresent" value="1" <?php echo ($stud[24]==1?"checked":"");?>> Present?
				</label></div>
			</div>
		</div>
		<div id="other" class="tab-pane fade" role="tabpanel" aria-labelledby="other-tab">
			<div class="form-row">
		    	<div class="col-md-4"><label for="cboCounty">Home County *</label><SELECT name="cboCounty" id="cboCounty" size="1" required onChange="loadConstituency(this)" class="modalinput">
				<?php echo $optCounty; ?></SELECT></div>
				<div class="col-md-4"><label for="cboConst">Constituency *</label><SELECT name="cboConst" id="cboConst" size="1" onChange="loadWards(this)" required  class="modalinput"><?php
				echo $optMP; ?></SELECT></div>
				<div class="col-md-4"><label for="cboWard">County Ward *</label><SELECT name="cboWard" id="cboWard" size="1" required class="modalinput"><?php echo $optMCA; ?></SELECT></div>
		  </div><div class="form-row">
		    	<div class="col-md-4"><label for="txtLocation">Home Location</label><input name="txtLocation" id="txtLocation" maxlength="25" type="text" value="<?php echo $stud[15];?>"
					placeholder="Kholera"  class="modalinput"></div>
					<div class="col-md-4"><label for="txtSubLocation">Sub-Location</label><input type="text" name="txtSubLocation" id="txtSubLocation" maxlength="25" class="modalinput"
					value="<?php echo $stud[16];?>" placeholder="Bulimbo"></div>
					<div class="col-md-4"><label for="txtVillage">Village/ Town</td><td><Input type="text" name="txtVillage" class="modalinput" id="txtVillage" maxlength="25" value="<?php
					echo $stud[17];?>" placeholder="Lukusi"></div>
			</div><br><div class="form-row"><div class="col-md-12 divsubheading">HISTORICAL ILLNESS OR ALLERGIES OF THE STUDENT</div></div>
			<div class="form-row"><div class="col-md-12"><label for="txtIllness">Illnesses</label><textarea name="txtIllness" id="txtIllness" rows="2" maxlength="80"
				class="modalinput"><?php echo $stud[18];?></textarea></div>
			</div><div class="form-row"><div class="col-md-12"><label for="txtAllergy">Allergies</label><textarea name="txtAllergy" id="txtAllergy" rows="2" maxlength="80"
				class="modalinput"><?php echo $stud[19];?></textarea></div>
			</div>
		  </div>
		</div><hr>
	<div class="form-row">
		<div class="col-md-6"><button type="submit" name="CmdSaveRecord" id="cmdsave" class="btn btn-md btn-block btn-primary">Save Student Details</button></div>
		<div class="col-md-6" style="text-align:right;"><button class="btn btn-info btn-md" onclick="window.open('student.php','_self')" type="button" name="CmdClose">Cancel/Close
		</button></div>
	</div><hr><br>
</div></form><script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/iebc.js"></script><script type="text/javascript" src="tpl/js/studadd.js"></script>
<?php
	if(isset($mp) && strlen($mp)>0){
		echo '<script type="text/javascript">var mp=['.$mp.'];';
		if(strlen($mca)>0) echo 'var mca=['.$mca.'];';
		echo '</script>';
	}	mysqli_close($conn); footer();
?>
