<?php
    include_once("shanam.php");
    $rsDet=mysqli_query($conn,"SELECT gofeeview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");	$viu=0;
    if (mysqli_num_rows($rsDet)>0) list($viu)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
    if($viu==0) header("location:vague.php");
    headings('',0,0,0);
    print "<table border=0 align=\"center\" style=\"position:relative;top:100px;color:#fff;padding:10px;border-collapse:collpase;font-weight:bold;\"><tr><td style=\"text-align:center;
    font-style:bold;font-size:12pt;word-spacing:5px;letter-spacing:3px;\" colspan=2><hr>FREE PRIMARY EDUCATION (FSE) INTERFACE.<br> Log In Time: ".$_SESSION['logintime']."<hr></td></tr>";
    print "<tr><td align=\"center\"><a href=\"fsefeestruct.php\" target=\"det\" onclick=\"return canvi($viu);\"><img src=\"../gen_img/feestruct.jpg\" id=\"img2\" width=120 height=100
    onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>FSE - Fee Structure</td><td align=\"center\"><a href=\"fsefees.php\" target=\"det\" onclick=\"return canvi($viu);\">
    <img src=\"../gen_img/operations.jpg\" id=\"img2\" width=120 height=100 onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>FSE - Fees</td></tr>";
    print "<tr><td align=\"center\"><a href=\"fseben.php\" target=\"det\" onclick=\"return canvi($viu);\"><img src=\"../gen_img/stud.jpg\" id=\"img2\" width=120 height=100
    onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>FSE Beneficiaries</td><td align=\"center\"><a href=\"fseothergrants.php\" target=\"det\" 
    onclick=\"return canvi($viu);\"><img src=\"../gen_img/tuition.jpg\" id=\"img2\" width=120 height=100 onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Other Govt
    Grants</td></tr>";
    print "<tr><td colspan=\"2\" style=\"text-align:center;font-style:bold;font-size:12pt;word-spacing:5px;letter-spacing:3px;text-align:center;\"><hr>Shanam's Digital Solutions -
    Bridging Digital Divide<hr></td></tr></table><script type=\"text/javascript\" src=\"tpl/menu.js\"></script>";
    mysqli_close($conn); footer();
?>
