<?php
	session_start();
	if (!(isset($_SEESION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	$salno=isset($_REQUEST['salno'])?trim($_REQUEST['salno']):'0-0-0';	$salno=preg_split('/\-/',$salno);//[0] salary no, [1] for action, [2] for n of affected rows
	mysqli_multi_query($conn,"SELECT s.sal_month,s.sal_year,s.processedon FROM acc_salaries s WHERE salno LIKE '$salno[0]'; SELECT scnm,scadd,principal FROM ss;"); $i=0;
	do{
		if($rsSal=mysqli_store_result($conn)){
			if ($i==0) list($mon,$yr,$pron)=mysqli_fetch_row($rsSal);
			else $sch=mysqli_fetch_row($rsSal);
			mysqli_free_result($rsSal);
		} $i++;	
	}while(mysqli_next_result($conn));
	$ndays=(strtotime(date('Y-m-d'))-strtotime($pron))/86400;
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Salary Manager</title><link type="text/css" rel="stylesheet" href="tpl/accprint" media="print"/>
	<script type="text/javascript" src="tpl/printthis.js"></script>
	<style>table{border-collapse:collapse;}table,th,td{border:0.5px dotted blue;font-size:11px;paddig:1px;}table.h,td.h,th.h{border:0px;}body{font-size:11px;}</style>
</head>
<body background="../gen_img/bg3.gif">
<?php
	print "<a href=\"salaryview.php?salno=$salno[0]\"><img src=\"../gen_img/ani_back.gif\" hspace=\"1\" width=\"45\" height=\"20\" align=\"left\"></a>";
	$rsSalPay=mysqli_query($conn,"SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,sp.paypoint,sp.bsalary,sp.housingallow1,sp.medicalallow1,sp.travelallow1,
	sp.responsallow1,sp.empnssf,(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.responsallow1+sp.travelallow1+sp.empnssf) AS GSal,(sp.nssffee1+sp.empnssf+sp.nssfvol1) As nssf,
	sp.nhiffee1,sp.welfare1,sp.sacco1,sp.union1,(sp.paye1-sp.mpr1) as taxes1,sp.helb1,sp.advance,sp.otherlevies1,(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.welfare1
	+sp.otherlevies1+sp.union1+sp.empnssf+sp.nssfvol1+sp.sacco1) AS TtlDed,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1)-(sp.nssffee1+
	sp.nhiffee1+sp.advance+sp.nssfvol1+(sp.paye1-sp.mpr1)+sp.welfare1+sp.otherlevies1+sp.union1+sp.empnssf+sp.sacco1)) AS NetSal FROM Stf s INNER JOIN Acc_SalDef sd USING (idno) INNER JOIN 
	Acc_SalPyt sp USING (payrollno) Where (sp.salno LIKE '$salno[0]') ORDER BY s.surname,s.onames ASC");
	print "<table class=\"h\"><tr><th class=\"h\" rowspan=3 colspan=2><img src=\"img/logo1.jpg\" height=60 width=50></th><th class=\"h\" colspan=20 
	style=\"text-align:left;\">$sch[0]</th></tr><tr><th class=\"h\" colspan=20 style=\"text-align:left;\">$sch[1]</th></tr><tr><th class=\"h\" colspan=17 style=\"text-align:left;\">".
	strtoupper($mon)." $yr STAFF SALARY</th><th class=\"h\" colspan=3 style=\"text-align:right;\">Printed On ".date("D d M, Y")."</th></tr><tr style=\"letter-spacing:2px;word-spacing:4px;
	background-color:#eee;\"><th colspan=\"4\">STAFF MEMBERS' DETAILS</th><th rowspan=\"2\">BASIC<BR>SALARY</th><th colspan=\"5\">SALARY ALLOWANCES</th><th rowspan=\"2\">GROSS<br>SALARY</th>
	<th colspan=\"10\">DEDUCTIONS ON SALARY</th><th rowspan=\"2\">NET<br>SALARY</th></tr><tr><th>ID. No.</th><th>P/F No.</th><th>Names</th><th>Pay Point</th><th>Housing</th><th>Medical</th>
	<th>Overtime</th><th>Duty</th><th>Emp. NSSF</th><th>N.S.S.F</th><th>N.H.I.F</th><th>Welfare</th><th>SACCO</th><th>Union</th><th>PAYE</th><th>HELB</th><th>Advance</th><th>Other</th><th>
	TOTAL</th></tr>";
	$tbs=0; $tho=0; $tme=0; $ttr=0; $ten=0; $tgs=0; $tns=0; $tnh=0; $twe=0; $tsa=0; $tun=0; $tta=0; $tad=0; $tod=0; $ttd=0;	$tnet=0; $thel=0; $tres=0;	$i=0;
	if (mysqli_num_rows($rsSalPay)>0):
		while (list($id,$pr,$na,$pp,$bs,$ho,$me,$tr,$res,$en,$gs,$ns,$nh,$we,$sa,$un,$ta,$hel,$ad,$od,$td,$net)=mysqli_fetch_row($rsSalPay)):
			if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
			print "<td>$id</td><td>$pr</td><td>$na</td><td>$pp</td><td align=\"right\">".number_format($bs,2)."</td><td align=\"right\">".number_format($ho,2)."</td><td align=\"right\">".
			number_format($me,2)."</td><td align=\"right\">".number_format($tr,2)."</td><td align=\"right\">".number_format($res,2)."</td><td align=\"right\">".number_format($en,2)."</td>
			<td align=\"right\">".number_format($gs,2)."</td><td align=\"right\">".number_format($ns,2)."</td><td align=\"right\">".number_format($nh,2)."</td><td align=\"right\">".
			number_format($we,2)."</td><td align=\"right\">".number_format($sa,2)."</td><td align=\"right\">".number_format($un,2)."</td><td align=\"right\">".number_format($ta,2)."</td>
			<td align=\"right\">".number_format($hel,2)."</td><td align=\"right\">".number_format($ad,2)."</td><td align=\"right\">".number_format($od,2)."</td><td align=\"right\">".
			number_format($td,2)."</td><td align=\"right\">".number_format($net,2)."</td></tr>";
			$tbs+=$bs; $tho+=$ho; $tme+=$me; $ttr+=$tr; $ten+=$en; $tgs+=$gs; $tns+=$ns; $tnh+=$nh; $twe+=$we; $tsa+=$sa; $tun+=$un; $thel+=$hel; $tres+=$res; $tta+=$ta; $tad+=$ad; 
			$tod+=$od; $tnet+=$net; $ttd+=$td; $i++;
		endwhile;
	endif;
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"22\" align=\"left\" class=\"b\">".mysqli_num_rows($rsSalPay)." Staff Members</td></tr></table><br><br><table cellpadding=\"1\" 
	cellspacing=\"0\" border=\"1\"><tr><td colspan=\"3\"><b><u>SALARY ALLOWANCES</u></b></td><td style=\"background:#000;\" rowspan=10>--</td><td colspan=\"3\"><b><u>SALARY DEDUCTIONS</u>
	</b></td></tr>"; mysqli_free_result($rsSalPay);
	print "<tr><td>1.</td><td>Basic Salary</td><td align=\"right\">".number_format($tbs,2)."</td><td>1.</td><td>NSSF Deductions</td><td align=\"right\">".number_format($tns,2)."</td></tr>
	<tr><td>2.</td><td>Housing Allowance</td><td align=\"right\">".number_format($tho,2)."</td><td>2.</td><td>NHIF Deductions</td><td align=\"right\">".number_format($tnh,2)."</td></tr>
	<tr><td>3.</td><td>Medical Allowance</td><td align=\"right\">".number_format($tme,2)."</td><td>3.</td><td>Welfare Contributions</td><td align=\"right\">".number_format($twe,2)."</td>
	</tr><tr><td>4.</td><td>Overtime Allowance</td><td align=\"right\">".number_format($ttr,2)."</td><td>4.</td><td>S . A . C . C . O</td><td align=\"right\">".number_format($tsa,2)."</td>
	</tr><tr><td>5.</td><td>Responsibility/Duty Allowance</td><td align=\"right\">".number_format($tres,2)."</td><td>5.</td><td>Union Dues</td><td align=\"right\">".number_format($tun,2).
	"</td></tr><tr><td>6.</td><td>Employer NSSF Contribution</td><td align=\"right\">".number_format($ten,2)."</td><td>6.</td><td>Pay As you Earn (PAYE)</td><td align=\"right\">".
	number_format($tta,2)."</td></tr>";
	print "<tr><td rowspan=2 colspan=3></td><td>7.</td><td>HELB Loan Deductions</td><td align=\"right\">".number_format($thel,2)."</td></tr><tr><td>9.</td><td>
	Other Deductions</td><td align=\"right\">".number_format($tod,2)."</td></tr><tr><td colspan=\"2\"><b>Total Gross Salary</b></td><td align=\"right\"><b>".number_format($tgs,2)."</b>
	</td><td colspan=\"2\"><b>Total Deductions</b></td><td align=\"right\"><b>".number_format($ttd,2)."</b></td></tr><tr><td colspan=\"7\"><b>Total Net Salary ".number_format($tnet,2)."</b>
	</td></tr></table><br>Prepared By ________________________ Date___________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;<b>Bursar</b><br><br><br>Approved By ___________________________  Date_____________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;<b>$sch[2] - Principal</b>.";
	print "</div><div align=\"center\"><br><a href=\"javascript:Clickheretoprint()\"><img src=\"../gen_img/print.ico\" height=\"30\" width=\"30\">Print</a></div><br>";
	mysqli_close($conn);
?>
</body></html>