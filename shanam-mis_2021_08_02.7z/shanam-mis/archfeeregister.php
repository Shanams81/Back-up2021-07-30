<?php
	session_start();
	if (!(isset($_SEESION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else {
		include_once('../conn/pri_sch_connect.inc');
		$admno=isset($_REQUEST['admno'])?trim(strip_tags($_REQUEST['admno'])):"0-0";
		$admno=preg_split("/\-/",$admno); //0-admission, 1-academic year, [2] 1 main register and 2 misc register
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>Fees Register</title>
		<link href="tpl/acc.css" rel="stylesheet" type="text/css"/>
		<link href="tpl/accprint.css" rel="stylesheet" type="text/css" media="print" />
		<script type="text/javascript" src="tpl/printthis.js"></script>
    </head>
<body background="img/bg3.gif">
<?php
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,motto FROM ss"); 
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mot)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	if ($admno[2]==1){	
		print "<h3 style=\"color:#00f;text-align:center;\">$admno[1] Academic Year Student's Main Account Fees Register</h3><hr>";
		$rsStud=mysqli_query($conn,"SELECT s.names,s.cls,s.feegrp,s.trans,f.tui,f.board,f.act,f.pemol,f.ltt,f.rmi,f.ewc,f.admincosts,f.adm,f.lib,(f.med+s.spemed) as med,f.exam,(0) as 
		prep,(0) as ref,s.arrears,(0) as bc,f.olevies,(f.maint3+s.spemed+s.arrears+s.trans) as ttl FROM (SELECT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',
		c.stream) As cls,c.curr_year,c.feegrp,c.lvlno,(c.bbf+if(isnull(f.arr),0,f.arr)) as arrears,(c.specialmedical+if(isnull(f.smed),0,f.smed)) as spemed,(c.t1trans+c.t2trans+
		c.t3trans+if(isnull(f.trans),0,f.trans)) as trans FROM stud s Inner Join class c USING (admno) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT admno,yr,sum(f.arrears) 
		as arr,sum(f.spemed) as smed,sum(f.transport) as trans FROM arch_feerec f GROUP BY f.admno,yr,f.markdel HAVING f.markdel=0 and f.yr LIKE '$admno[1]'and f.admno LIKE '$admno[0]')f 
		On (c.admno=f.admno and c.curr_year=f.yr) WHERE (c.`admno` Like '$admno[0]' And c.curr_year LIKE '$admno[1]'))s Inner JOIN arch_feeoutline f USING (curr_year,lvlno,feegrp) ORDER 
		BY s.cls,s.names ASC");
		if (mysqli_num_rows($rsStud)>0):
			//Get School name, address, motto and mission
			$rsSch=mysqli_query($conn,"SELECT scnm,scadd,motto FROM ss"); 
			if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mot)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
			list($names,$cls,$fegr,$ftrans,$ftui,$fboa,$fact,$fpem,$fltt,$frmi,$fewc,$fadmc,$fadm,$flib,$fmed,$fexa,$fprep,$fref,$farr,$fbc,$fole,$fttl)=
			mysqli_fetch_row($rsStud);
			print "<div id=\"$admno[1]\"><table cellspacing=\"0\" border=\"0\"><tr><th rowspan=\"3\" valign=\"middle\" width=\"80\" align=\"center\"><img 
			src=\"img/logo.png\" width=\"60\" height=\"70\" vspace=\"1\" hspace=\"1\"></th><th style=\"font-size:12px;text-align:left;\">$scnm</th></tr><tr>
			<th style=\"font-size:12px;text-align:left;\">$scadd</th></tr><tr><th style=\"font-size:12px;text-align:left;\">$mot</th></tr><tr><th 
			colspan=\"2\" style=\"font-size:12px;text-align:left\"><hr><b>$admno[1] PUPIL'S FEES REGISTER &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;<span style=\"text-align:right;\">Printed On ".date("D d M,Y")."</span><hr></th></tr><tr><td colspan=\"2\"><br><p 
			style=\"letter-spacing:1px;font-size:13px;word-spacing:2px;\">Adm. No. $admno[0]-<b><u>$names</u></b> Class <b>$cls</b> Fee Group <b>$fegr</b>. <u><i>
			Fee Register As On <b>".date('D d M,Y',strtotime("$admno[1]-12-31"))."</b></i></u></p>";
			print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr bgcolor=\"#eeeeee\"><th>Receipt No.</th><th>Received On</th><th>Receipt Mode</th>
			<th>Cheque No.</th><th>Tuition</th><th>Boarding</th><th>Activity</th><th>Personal Emol</th><th>L . T &nbsp; T</th><th>R . M . I</th><th>E . W . C</th>
			<th>Admin Costs</th><th>Admission</th><th>Library</th><th>Medical</th><th>Exams</th><th>Transport</th><th>Prepayments</th><th>Refunds</th><th>Arrears
			</th><th>Bank 
			Charges</th><th>O. Levies</th><th>Total Amount</th><th>Balance</th></tr>";
			print "<tr><td colspan=\"4\" align=\"right\">Fees Expected As On 01, January ".$admno[1]."<td align=\"right\">".number_format($ftui,2)."</td><td 
			align=\"right\">".number_format($fboa,2)."</td><td align=\"right\">".number_format($fact,2)."</td><td align=\"right\">".number_format($fpem,2)."</td>
			<td align=\"right\">".number_format($fltt,2)."</td><td align=\"right\">".number_format($frmi,2)."</td><td align=\"right\">".number_format($fewc,2).
			"</td><td align=\"right\">".number_format($fadmc,2)."</td><td align=\"right\">".number_format($fadm,2)."</td><td align=\"right\">".number_format($flib,
			2)."</td><td align=\"right\">".number_format($fmed,
			2)."</td><td align=\"right\">".number_format($fexa,2)."</td><td align=\"right\">".number_format($ftrans,2)."</td><td align=\"right\">".
			number_format($fprep,2)."</td><td align=\"right\">".number_format($fref,2)."</td><td align=\"right\">".number_format($farr,2)."</td><td 
			align=\"right\">".number_format($fbc,2)."</td><td align=\"right\">".number_format($fole,2)."</td><td align=\"right\"><b>".number_format($fttl,2)."</b>
			</td><td align=\"right\"><b>".number_format($fttl,2)."</b></td></tr>";
			$rsFees=mysqli_query($conn,"SELECT recieptno,pytdate,paytform,cmono,tuition,boarding,activity,pemolu,ltt,rmi,ewc,admincosts,adm,lib,(medical+spemed) as med,exam,transport,
			prep,refunds,arrears,bankcharges,olevy,(amt+bankcharges) As Ttl,(amt-refunds-prep) as feeamt FROM Arch_feerec WHERE (`markdel`=0 AND admno LIKE '$admno[0]' and yr LIKE 
			'$admno[1]')");   
			$a=0;   $ttl=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0); 		$ai=mysqli_num_rows($rsFees);
			if ($ai>0):
				while (list($re,$pd,$pf,$cm,$tui,$boa,$act,$pem,$ltt,$rmi,$ewc,$con,$adm,$lib,$med,$exa,$tra,$prep,$ref,$arr,$bc,$ole,$tot,$fee)=
				mysqli_fetch_row($rsFees)):
					$fttl-=$fee;//running balance
					if (($a%2)==0) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>";
					print "<td>$re</td><td>".date("D d-M-Y",strtotime($pd))."<td>$pf</td><td>$cm</td><td align=\"right\">".number_format($tui,2)."</td><td 
					align=\"right\">".number_format($boa,2)."</td><td align=\"right\">".number_format($act,2)."</td><td align=\"right\">".number_format($pem,2).
					"</td><td align=\"right\">".number_format($ltt,2)."</td><td align=\"right\">".number_format($rmi,2)."</td><td align=\"right\">".
					number_format($ewc,2)."</td><td align=\"right\">".number_format($con,2)."</td><td align=\"right\">".number_format($adm,2)."</td><td 
					align=\"right\">".number_format($lib,2)."</td><td 
					align=\"right\">".number_format($med,2)."</td><td align=\"right\">".number_format($exa,2)."</td><td align=\"right\">".number_format($tra,2).
					"</td><td align=\"right\">".number_format($prep,2)."</td><td align=\"right\">".number_format($ref,2)."</td><td align=\"right\">".
					number_format($arr,2)."</td><td align=\"right\">".number_format($bc,2)."</td><td align=\"right\">".number_format($ole,2)."</td><td 
					align=\"right\">".number_format($tot,2)."</td><td align=\"right\"><b>".number_format($fttl,2)."</b></td></tr>";
					$ttl[0]+=$tui; $ttl[1]+=$boa; $ttl[2]+=$act; $ttl[3]+=$pem; $ttl[4]+=$ltt; $ttl[5]+=$rmi; $ttl[6]+=$ewc; $ttl[7]+=$con; $ttl[8]+=$adm;
					$ttl[9]+=$lib; $ttl[10]+=$med; $ttl[11]+=$exa; $ttl[12]+=$tra; $ttl[13]+=$prep; $ttl[14]+=$ref; $ttl[15]+=$arr;  $ttl[16]+=$bc; 	
					$ttl[17]+=$ole; $ttl[18]+=$tot; $a++;
				endwhile;
			else:
				print "<tr><td colspan=\"25\" align=\"center\" style=\"letter-spacing:2px;word-spacing:4px;\">No Fees Payment Was Made By this student</td>
				</tr>";
			endif;
			print "<tr bgcolor=\"#00fff1\"><td colspan=\"2\"><b>$ai Fees Installments</b></td><td colspan=\"2\" align=\"right\"><b>Subtotals (Kshs.)</b></td>";
			$tcount=0;
			foreach($ttl as $tt){
				print "<td align=\"right\"><b>".number_format($tt,2)."</b></td>";
				$tcount++;
			}	
			print "<td align=\"right\"><b>xxxxx</b></td></tr>"; mysqli_free_result($rsFees); 
			print "<tr bgcolor=\"#00eeee\"><td colspan=\"4\" align=\"right\"><b>Balance Per Votehead</b></td><td align=\"right\"><b>".number_format(($ftui-
			$ttl[0]),2)."</b></td><td align=\"right\"><b>".number_format(($fboa-$ttl[1]),2)."</b></td><td align=\"right\"><b>".number_format(($fact-$ttl[2]),2).
			"</b></td><td align=\"right\"><b>".number_format(($fpem-$ttl[3]),2)."</b></td><td align=\"right\"><b>".number_format(($fltt-$ttl[4]),2)."</b></td><td 
			align=\"right\"><b>".number_format(($frmi-$ttl[5]),2)."</b></td><td align=\"right\"><b>".number_format(($fewc-$ttl[6]),2)."</b></td><td 
			align=\"right\"><b>".number_format(($fadmc-$ttl[7]),2)."</b></td><td 
			align=\"right\"><b>".number_format(($fadm-$ttl[8]),2)."</b></td><td align=\"right\"><b>".number_format(($flib-$ttl[9]),2)."</b></td><td 
			align=\"right\"><b>".number_format(($fmed-$ttl[10]),2)."</b></td><td align=\"right\"><b>".number_format(($fexa-$ttl[11]),2)."</b></td><td 
			align=\"right\"><b>".number_format(($ftrans-$ttl[12]),2)."</b></td><td align=\"right\"><b>0.00</b></td><td align=\"right\">0.00</b></td><td 
			align=\"right\"><b>".number_format(($farr-$ttl[15]),2)."</b></td><td align=\"right\"><b>0.00</b></td><td align=\"right\"><b>".number_format(($fole-
			$ttl[17]),2)."</b></td><td align=\"right\"><b>".number_format($fttl,2)."</b></td><td align=\"right\"><b>xxxxx</b></td></tr></table></td></tr></table>
			</div>";
			print "<hr><br><center>Report Generated On ".date("D d-M-Y")."<br><br><br><a href=\"javascript:printSpecific($admno[0])\">Click To Print Record</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"archpupil.php\">Click Here to go back</a><br></center><hr>"; 
		else:	
			print "<p class=\"g\">No fees payment for the set criteria</p>";
		endif;
		mysqli_free_result($rsStud);
	}else{
		print "<h3 style=\"color:#00f;text-align:center;\">$admno[1] Academic Year Student's Misc Account Fees Register</h3><hr>";
		$rsStud=mysqli_query($conn,"SELECT s.names,s.cls,s.feegrp,f.misidcard,f.misqa,f.misremedial,f.misht,f.misgrad,f.mistrip,s.uniform,s.arrears,f.misole,(f.misct3+s.arrears+
		s.uniform) as bal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,c.curr_year,c.lvlno,c.feegrp,(c.miscbf+if(isnull(arr),0,arr)) 
		as arrears, (c.unifrm+if(isnull(unif),0,unif)) as uniform FROM stud s Inner Join class c USING (admno) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT payeesno,yr,
		sum(arrears) as arr,sum(uni) as unif FROM arch_miscfeepyts GROUP BY payeesno,yr,markdel HAVING (markdel=0 and payeesno LIKE '$admno[0]' and yr LIKE '$admno[1]'))m On 
		(c.admno=m.payeesno and c.curr_year=m.yr) WHERE (c.`admno` Like '$admno[0]' and c.curr_year LIKE '$admno[1]'))s Inner Join Arch_feeoutline f USING (curr_year,lvlno,feegrp)");
		if (mysqli_num_rows($rsStud)>0):
			list($names,$cls,$fegr,$fid,$fqa,$frem,$fht,$fgrad,$ftrip,$funi,$farr,$fole,$fttl)=mysqli_fetch_row($rsStud);
			print "<div id=\"$admno[0]\"><table cellspacing=\"0\" border=\"0\"><tr><th rowspan=\"3\" valign=\"middle\" width=\"80\" align=\"center\"><img 
			src=\"img/logo.png\" width=\"60\" height=\"70\" vspace=\"1\" hspace=\"1\"></th><th style=\"font-size:12px;text-align:left;\">$scnm</th></tr><tr><th 
			style=\"font-size:12px;text-align:left;\">$scadd</th></tr><tr><th style=\"font-size:12px;text-align:left;\">$mot</th></tr><tr><th colspan=\"2\" 
			style=\"font-size:12px;text-align:left\"><hr><b>$admno[1] PUPIL'S FEES REGISTER &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Printed On ".
			date("D d M,Y")."<hr></th></tr><tr><td colspan=\"2\"><br><p style=\"letter-spacing:1px;font-size:13px;word-spacing:2px;\">Adm. No. $admno[0]-<b><u>$names
			</u></b> Class <b>$cls</b> Fee Group <b>$fegr</b>. <u><i>Fee Register As On <b>".date('D d M,Y',strtotime("$admno[1]-12-31"))."</b></i></u></p>";
			print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr bgcolor=\"#eeeeee\"><th>Receipt No.</th><th>Received On</th><th>Form of Payment
			</th><th>Cheque No.</th><th>ID Card</th><th>Quality Assurance</th><th>Remedial Studies</th><th>Holiday Tuition</th><th>Graduation</th><th>Academic 
			Trip</th><th>Uniform</th><th>Arrears</th><th>Bank Charges</th><th>O. Levies</th><th>Total Amount</th><th>Balance</th></tr>";
			$rsFees=mysqli_query($conn,"SELECT recipetno,pytdate,pytfrm,cheno,idcard,qa,remedial,ht,grad,acatrip,uni,arrears,bankcharges,olevy,Amt FROM 
			Arch_MiscFeePyts WHERE (markdel=0 AND payeesno LIKE '$admno[0]' and yr LIKE '$admno[1]') ORDER BY recipetno Asc");
			print "<tr><td colspan=\"4\" align=\"right\">Fees Expected As On 01, January ".$admno[1]."<td align=\"right\">".number_format($fid,2)."</td><td 
			align=\"right\">".number_format($fqa,2)."</td><td align=\"right\">".number_format($frem,2)."</td><td align=\"right\">".number_format($fht,2)."</td>
			<td align=\"right\">".number_format($fgrad,2)."</td><td align=\"right\">".number_format($ftrip,2)."</td><td align=\"right\">".number_format($funi,2).
			"</td><td align=\"right\">".number_format($farr,2)."</td><td align=\"right\">0.00</td><td align=\"right\">".number_format($fole,2)."</td><td 
			align=\"right\"><b>".number_format($fttl,2)."</b></td><td align=\"right\"><b>".number_format($fttl,2)."</b></td></tr>";
			$ai=mysqli_num_rows($rsFees);	 $a=0; 	$ttl=array(0,0,0,0,0,0,0,0,0,0,0);
			if ($ai>0):
				while (list($re,$pd,$pf,$cm,$id,$qa,$rem,$ht,$grad,$trip,$uni,$arr,$bc,$ole,$tt)=mysqli_fetch_row($rsFees)):
					$fttl-=$tt;
					if (($a%2)==0) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>";
					print "<td>$re</td><td>".date("D d-M-Y",strtotime($pd))."<td>$pf</td><td>$cm</td><td align=\"right\">".number_format($id,2)."</td><td 
					align=\"right\">".number_format($qa,2)."</td><td align=\"right\">".number_format($rem,2)."</td><td align=\"right\">".number_format($ht,2).
					"</td><td align=\"right\">".number_format($grad,2)."</td><td align=\"right\">".number_format($trip,2)."</td><td align=\"right\">".
					number_format($uni,2)."</td><td align=\"right\">".number_format($arr,2)."</td><td align=\"right\">".number_format($bc,2)."</td><td 
					align=\"right\">".number_format($ole,2)."</td><td align=\"right\"><b>".number_format($tt,2)."</b></td><td align=\"right\"><b>".
					number_format($fttl,2)."</b></td></tr>";
					$ttl[0]+=$id; $ttl[1]+=$qa; $ttl[2]+=$rem; $ttl[3]+=$ht; $ttl[4]+=$grad; $ttl[5]+=$trip; $ttl[6]+=$uni; $ttl[7]+=$arr; $ttl[8]+=$bc; 
					$ttl[9]+=$ole;	$ttl[10]+=$tt; $a++;
				endwhile;
			else:
				print "<tr><td colspan=\"16\" align=\"left\" style=\"letter-spacing:2px;word-spacing:4px;\">No Fees Payment Was Made By this student</td></tr>";
			endif;
			print "<tr bgcolor=\"#E1E1E1\"><td colspan=\"2\"><b>$ai Fees Payment Installments</b></td><td colspan=\"2\" align=\"right\">
			<b>Subtotals (Kshs.)</b></td>";
			foreach($ttl as $tot) print "<td align=\"right\"><b>".number_format($tot,2)."</b></td>";
			print "<td>xxxxx</td></tr>"; mysqli_free_result($rsFees); 
			print "<tr bgcolor=\"#00eeee\"><td colspan=\"4\" align=\"right\"><b>Balance Per Votehead</b></td><td align=\"right\"><b>".number_format(($fid-$ttl[0]),2)."</b></td><td 
			align=\"right\"><b>".number_format(($fqa-$ttl[1]),2)."</b></td><td align=\"right\"><b>".number_format(($frem-$ttl[2]),2)."</b></td><td align=\"right\"><b>".
			number_format(($fht-$ttl[3]),2)."</b></td><td align=\"right\"><b>".number_format(($fgrad-$ttl[4]),2)."</b></td><td align=\"right\"><b>".number_format(($ftrip-$ttl[5]),2).
			"</b></td><td align=\"right\"><b>".number_format(($funi-$ttl[6]),2)."</b></td><td align=\"right\"><b>".number_format(($farr-$ttl[7]),2)."</b></td><td align=\"right\"><b>0.00
			</b></td><td align=\"right\"><b>".number_format(($fole-$ttl[9]),2)."</b></td><td align=\"right\"><b>".number_format($fttl,2)."</b></td><td align=\"right\"><b>xxxxx</b></td>
			</tr></table></td></tr></table></div>";
			print "<hr><br><center>Report Generated On ".date("D d-M-Y")."<br><br><br><a href=\"javascript:printSpecific($admno[0])\">Click To Print Record</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"archpupil.php\">Click Here to go back</a><br></center><hr>";
		else:	
			print "<p class=\"g\">No fees payment for the set criteria</p>";
		endif;
		mysqli_free_result($rsStud);
	}
mysqli_close($conn);
?>
</body>
</html>
