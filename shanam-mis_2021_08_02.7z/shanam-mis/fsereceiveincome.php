<?php
    session_start();
    if ((!isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
    include_once('tpl/printing.tpl');
    class Balance{
		private $vno,$vote,$bal;
		public function __construct($v,$vna,$t){$this->vno=$v;	$this->vote=$vna;	$this->bal=$t;} 
		public function valVSNo(){return $this->vno;} 	public function valBal(){return $this->bal;}	public function valVName(){return $this->vote;}		
	}class VoteAmt{
		private $vno,$amt;
		public function __construct($v,$a){$this->vno=$v; $this->amt=$a;} 	public function valVSNo(){return $this->vno;} 	public function valAmt(){return $this->amt;}
	}
	function findBal($vamt,$v){
		$len=count($vamt); $found=false; $amt=0; $a=0;
		while(!$found && $a<$len){
			if($vamt[$a]->valVSNo()==$v){$found=true; $amt=$vamt[$a]->valAmt();} $a++;
		}return $amt;
	}
    if(isset($_POST['btnSaveFee'])){
     	$nov=isset($_POST['txtNoV'])?sanitize($_POST['txtNoV']):0; 	$tkn=sanitize($_POST['txtToken']);  $tkn=preg_split('/\-/',$tkn);//[0]-Token,[1]-A/C,[2]-Rec SNo.,[3]-A/C Med,[4]-Uni A/C
        $admno=isset($_POST['txtAdmNo'])?sanitize($_POST['txtAdmNo']):0;    			$date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('Y-m-d');
        $paidby=isset($_POST['cboPaidBy'])?sanitize($_POST['cboPaidBy']):"Parent"; 		$bno=isset($_POST['txtBursNo'])?sanitize($_POST['txtBursNo']):null;      
		$bursbal=isset($_POST['txtBursBal'])?sanitize($_POST['txtBursBal']):0; 			$pytfrm=isset($_POST['cboPytFrm'])?strtoupper(sanitize($_POST['cboPytFrm'])):'DIRECT BANKING'; 
		$cheno=isset($_POST['txtCheNo'])?strtoupper(sanitize($_POST['txtCheNo'])):null; $bankno=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;
		$bal=isset($_POST['txtVoteBal'])?sanitize($_POST['txtVoteBal']):0;				$bal=preg_replace('/[^0-9\.]/','',$bal);	$date=preg_split('/\-/',$date); 
		$amt=isset($_POST['txtFee'])?sanitize($_POST['txtFee']):0; 	$origamt=isset($_POST['txtOrigFee'])?sanitize($_POST['txtOrigFee']):0;		$amt=preg_replace('/[^0-9\.]/','',$amt);	
		$origamt=preg_replace('/[^0-9\.]/','',$origamt);	$bursbal=preg_replace('/[^0-9\.]/','',$bursbal);	$bankno=($bankno>0?$bankno:null);	$bno=$bno>0?$bno:null;
		$bc=isset($_POST['txtBC'])?sanitize($_POST['txtBC']):0;	 $origbc=isset($_POST['txtOrigBC'])?sanitize($_POST['txtOrigBC']):0;	 	$bc=preg_replace('/[^0-9\.]/','',$bc);	
		$recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0;	$origbc=preg_replace('/[^0-9\.]/','',$origbc);	$cheno=strlen($cheno)>0?$cheno:null;	
		$kind=isset($_POST['txtKind'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtKind']))):null; 	$kind=strlen($kind)>0?$kind:null;
		$origbno=isset($_POST['txtOrigBursNo'])?sanitize($_POST['txtOrigBursNo']):null; $origbno=strlen($origbno)>0?$origbno:null;
		$idno=isset($_POST['txtIDNo'])?strtoupper(sanitize($_POST['txtIDNo'])):null; 	$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):'+2547';	
		$parent=isset($_POST['txtParent'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtParent']))):null;
		$addr=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):null;
		$origpf=isset($_POST['txtOrigPF'])?strtoupper(sanitize($_POST['txtOrigPF'])):'DIRECT BANKING';  $ttlamt=$amt+$bc;
		if ($amt<1 || $bal!=0 || ((strcasecmp($pytfrm,"Cash")!=0 && strcasecmp($pytfrm,"Kind")!=0) && strlen($cheno)==0) || (strcasecmp($pytfrm,"Kind")==0  && strlen($kind)<10 && 
		strlen($idno)<7 && strlen($parent)<8 && strlen($telno)<9) || (strcasecmp($pytfrm,"cheque")!=0 && $bc>0) || ($_SESSION['form_token']!=$tkn[0]) || ($bno>0 && $bno==$origbno && 
		(($bursbal+$origamt)<$amt))){
			print "Sorry, the fee receipt record had errors. The reciept was not sucessfully saved. Click <a href=\"studfee.php\">here</a> to try again";
			unset($_SESSION['form_token']); exit(0);
		}else{
		 	unset($_SESSION['form_token']);
		 	mysqli_query($conn,"UPDATE acc_incofee SET admno='$admno',pytdate='$date[2]-$date[1]-$date[0]',paidby='$paidby',pytfrm='$pytfrm',cheno=".var_export($cheno,true).",bursno=".
			var_export($bno,true).",bankno=".var_export($bankno,true).",kinddescr=".var_export($kind,true)." WHERE sno LIKE '$tkn[2]'") or die(mysqli_error($conn).". Click <a 
			href=\"feerec.php?cod=$admno-2020\">HERE</a> to try again.");  
			$sqlvote='';
			if($tkn[1]==1){//Main Account Locked voteheads
				$arr=isset($_POST['txtAmt_0'])?sanitize($_POST['txtAmt_0']):0;			$arr=preg_replace('/[^0-9\.]/','',$arr);
				$origarr=isset($_POST['txtCurr_0'])?sanitize($_POST['txtCurr_0']):0;	$origarr=preg_replace('/[^0-9\.]/','',$origarr);
				if ($arr!=$origarr){ $v=sanitize($_POST['txtVote_0']); $v=preg_split('/\-/',$v); 
					if($origprep==0) $sqlvote.="INSERT INTO acc_incovotes VALUES($recno,'$v[0]','$v[1]',$arr,0);"; 
					else $sqlvote.="UPDATE acc_incovotes SET amt='$prep' WHERE acc LIKE '$v[0]' and recno LIKE '$recno' and voteno LIKE '$v[1]';";
				}
				$ref=isset($_POST['txtAmt_1'])?sanitize($_POST['txtAmt_1']):0;			$ref=preg_replace('/[^0-9\.]/','',$ref);
				$origref=isset($_POST['txtCurr_1'])?sanitize($_POST['txtCurr_1']):0;	$origref=preg_replace('/[^0-9\.]/','',$origref);
				if ($ref!=$origref){ $v=sanitize($_POST['txtVote_1']); $v=preg_split('/\-/',$v); 
					if($origprep==0) $sqlvote.="INSERT INTO acc_incovotes VALUES($recno,'$v[0]','$v[1]',$ref,0);"; 
					else $sqlvote.="UPDATE acc_incovotes SET amt='$ref' WHERE acc LIKE '$v[0]' and recno LIKE '$recno' and voteno LIKE '$v[1]';";
				}
				$spemed=isset($_POST['txtAmt_2'])?sanitize($_POST['txtAmt_2']):0;	$spemed=preg_replace('/[^0-9\.]/','',$spemed);
				$origspemed=isset($_POST['txtCurr_2'])?sanitize($_POST['txtCurr_2']):0;	$origspemed=preg_replace('/[^0-9\.]/','',$origspemed);
				if ($spemed!=$origspemed){$v=sanitize($_POST['txtVote_2']); $v=preg_split('/\-/',$v); 
					if($origspemed==0) $sqlvote.="INSERT INTO acc_incovotes VALUES($recno,'$v[0]','$v[1]',$spemed,0);"; 
					else $sqlvote.="UPDATE acc_incovotes SET amt='$spemed' WHERE acc LIKE '$v[0]' and recno LIKE '$recno' and voteno LIKE '$v[1]';";
				}
				$prep=isset($_POST['txtAmt_3'])?sanitize($_POST['txtAmt_3']):0;		$prep=preg_replace('/[^0-9\.]/','',$prep); 
				$origprep=isset($_POST['txtCurr_3'])?sanitize($_POST['txtCurr_3']):0;		$origprep=preg_replace('/[^0-9\.]/','',$origprep);$start=4;
				if ($prep!=$origprep){ $v=sanitize($_POST['txtVote_3']); $v=preg_split('/\-/',$v); 
					if($origprep==0) $sqlvote.="INSERT INTO acc_incovotes VALUES($recno,'$v[0]','$v[1]',$prep,0);"; 
					else $sqlvote.="UPDATE acc_incovotes SET amt='$prep' WHERE acc LIKE '$v[0]' and recno LIKE '$recno' and voteno LIKE '$v[1]';";
				}
				if ($tkn[1]==$tkn[4]){//if uniform is main account
				 	$uni=isset($_POST['txtAmt_'.$start])?sanitize($_POST['txtAmt_'.$start]):0; $uni=preg_replace('/[^0-9\.]/','',$uni); 
					$origuni=isset($_POST['txtCurr_'.$start])?sanitize($_POST['txtCurr_'.$start]):0; $origuni=preg_replace('/[^0-9\.]/','',$origuni);$start++;
					if ($uni!=$origuni){ $v=sanitize($_POST['txtVote_'.$start]); $v=preg_split('/\-/',$v); 
						if($origuni==0) $sqlvote.="INSERT INTO acc_incovotes VALUES($recno,'$v[0]','$v[1]',$uni,0);"; 
						else $sqlvote.="UPDATE acc_incovotes SET amt='$uni' WHERE acc LIKE '$v[0]' and recno LIKE '$recno' and voteno LIKE '$v[1]';";
					}
				}else{$uni=0;	$origuni=0;}
				$sql="UPDATE acc_IncoRecNo0 SET bc=$bc,amt=$amt,arrears=$arr,spemed=$spemed,refunds=$ref,prep=$prep,unifrm=$uni WHERE recno LIKE '$recno' AND acc LIKE '$tkn[1]';";
			}else{
			 	$lkd=isset($_POST['txtLocked'])?sanitize($_POST['txtLocked']):'0-0'; $lkd=preg_split('/\-/',$lkd);//[0] Arrears [1] Xtrauniform
				$prep=0; $ref=0; $spemed=0; $arr=isset($_POST['txtAmt_'.$lkd[0]])?sanitize($_POST['txtAmt_'.$lkd[0]]):0;		$arr=preg_replace('/[^0-9\.]/','',$arr); 
				$origarr=isset($_POST['txtCurr_'.$lkd[0]])?sanitize($_POST['txtCurr_'.$lkd[0]]):0;		$origarr=preg_replace('/[^0-9\.]/','',$origarr); 	$start=0;
				if ($tkn[1]!=$tkn[4]){
					 $uni=isset($_POST['txtAmt_'.$lkd[1]])?sanitize($_POST['txtAmt_'.$lkd[1]]):0; $uni=preg_replace('/[^0-9\.]/','',$uni); 
					 $origuni=isset($_POST['txtCurr_'.$lkd[1]])?sanitize($_POST['txtCurr_'.$lkd[1]]):0; $origuni=preg_replace('/[^0-9\.]/','',$origuni); $start++;
					 if ($uni!=$origuni){ $v=sanitize($_POST['txtVote_'.$start]); $v=preg_split('/\-/',$v); 
						if($origuni==0) $sqlvote.="INSERT INTO acc_incovotes VALUES($recno,'$v[0]','$v[1]',$uni,0);"; 
						else $sqlvote.="UPDATE acc_incovotes SET amt='$uni' WHERE acc LIKE '$v[0]' and recno LIKE '$recno' and voteno LIKE '$v[1]';";
					}
				}else{$uni=0;	$origuni=0;}
				$sql="INSERT INTO acc_IncoRecNo1 bc=$bc,amt=$amt,arrears=$arr,spemed=$spemed,unifrm=$uni WHERE recno LIKE '$recno' AND acc LIKE '$tkn[1]';";
			}mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"feerec.php?cod=$admno-2020\">HERE</a> to try again.");
			$sql='';
			for($a=$start;$a<$nov;$a++){
				$vamt=isset($_POST['txtAmt_'.$a])?sanitize($_POST['txtAmt_'.$a]):0;		$vamt=preg_replace('/[^0-9\.]/','',$vamt);
				$orig=isset($_POST['txtCurr_'.$a])?sanitize($_POST['txtCurr_'.$a]):0; 	$orig=preg_replace('/[^0-9\.]/','',$orig);
				if($tkn[1]==1 || ($tkn[1]!=1 && ($a!=$lkd[0] || ($tkn[1]!=$tkn[4] && $a!=$lkd[1])))){
					if ($vamt!=$orig){ $v=sanitize($_POST['txtVote_'.$a]); $v=preg_split('/\-/',$v); 
						if($orig==0) $sqlvote.="INSERT INTO acc_incovotes VALUES($recno,'$v[0]','$v[1]',$vamt,0);"; 
						else $sqlvote.="UPDATE acc_incovotes SET amt='$vamt' WHERE acc LIKE '$v[0]' and recno LIKE '$recno' and voteno LIKE '$v[1]';";
					}
				}
			}if (strlen($sqlvote)>0){mysqli_multi_query($conn,$sqlvote) or die(mysqli_error($conn)."Click <a href=\"studfee.php\">HERE </a> to go back."); 
			while(mysqli_next_result($conn)){;}} $sqlvote='';
			if($prep!=$origprep){$sql='';//Prepayment
				if($prep>$origprep){
					$prep-=$origprep;
					mysqli_multi_query($conn,"SELECT c.voteno,if(isnull(f.ttl),0,f.ttl) as vamt,(c.t3-if(isnull(f.ttl),0,f.ttl)) as bal FROM clsfee c Inner Join acc_votes v On 
					(c.voteno=v.sno) Inner Join acc_voteacs a On (v.acc=a.acno) LEFT JOIN (SELECT i.admno,f.acc,v.voteno,sum(v.amt) as ttl FROM acc_incofee i Inner Join acc_incorecno0 f 
					USING (sno) Inner Join acc_incoprep v USING (recno) GROUP BY i.admno,f.acc,v.voteno,i.markdel HAVING markdel=0 and f.acc=1 and i.admno='$admno')f USING (admno,voteno) 
					WHERE c.admno='$admno' and v.acc=1; SELECT recno FROM acc_incoprep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno IN (SELECT sno FROM acc_votes WHERE descr 
					LIKE '%prepay%';");	 $i=0;
					do{
						if ($rs=mysqli_store_result($conn)){
							if($i==0){
								while(($d=mysqli_fetch_row($rs)) && ($prep>0)){
									if($d[2]>0){
									 	if ($d[2]>=$prep){ if($d[1]==0) $sql.="INSERT INTO acc_incoprep (recno,acc,voteno,amt) VALUES ($recno,'$tkn[1]',$d[0],$prep);"; 
											else $sql.="UPDATE acc_incoprep SET amt=amt+$prep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno LIKE '$d[0]';";	$prep=0;}
										else{if($d[1]==0) $sql.="INSERT INTO acc_incoprep (recno,acc,voteno,amt) VALUES ($recno,'$lmt[3]',$d[0],$d[2]);"; 
											else $sql.="UPDATE acc_incoprep SET amt=amt+$d[2] WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno LIKE '$d[0]';"; $prep-=$d[2];}
									}
								}
							}else{
								$no=mysqli_num_rows($rs);
								if($prep>0){ 
								 	if($no==0) $sql.="INSERT INTO acc_incoprep (recno,acc,voteno,amt) SELECT $recno,'$tkn[1]',sno,$prep FROM acc_votes WHERE descr LIKE '%prepay%';";
									else $sql.="UPDATE acc_incoprep amt=amt+$prep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno IN (SELECT sno FROM acc_votes WHERE descr 
									LIKE '%prepay%');";}
							}mysqli_free_result($rs); 	
						}$i++;
					}while(mysqli_next_result($conn));		
				}else{
					if($prep==0) $sql.="DELETE FROM acc_incoprep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]';";
					else{	$prep=$origprep-$prep;
						mysqli_multi_query($conn,"SELECT voteno,amt FROM acc_incoprep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno IN (SELECT sno FROM acc_votes WHERE descr 
						LIKE '%prepay%'); SELECT voteno,amt FROM acc_incoprep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno NOT IN (SELECT sno FROM acc_votes WHERE descr 
						LIKE '%prepay%');"); $i=0;
						do{
							if($rs=mysqli_store_result($rs)){
							 	if($i==0){
									if(mysqli_num_rows($rs)>0){$r=mysqli_fetch_row($rs); 
									if($r[1]>$prep){$sql.="UPDATE acc_incoprep SET amt=amt-$prep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno LIKE '$r[0]';"; $prep=0;}
									else{$sql.="DELETE FROM acc_incoprep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno LIKE '$r[0]';"; $prep-=$r[1];}}
								}else{	
								 	if($prep>0){while($r=mysqli_fetch_row($rs) && $prep>0){
										if($r[1]>$prep){$sql.="UPDATE acc_incoprep SET amt=amt-$prep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno LIKE '$r[0]';"; $prep=0;}
										else{$sql.="DELETE FROM acc_incoprep WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno LIKE '$r[0]';"; $prep-=$r[1];}
									}}
								}mysqli_free_result($rs); 	
							}$i++;	
						}while(mysqli_next_result($conn));	
					}	
				}
				if (strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"studfee.php\">HERE </a> to go back."); 
				while(mysqli_next_result($conn)){;}} 
			}if($ref!=$origref){//update refunds
				$sql="UPDATE class SET refunds=refunds+($ref-$origref) WHERE admno LIKE '$admno' and curr_year IN (SELECT finyr FROM ss);";
				if($ref==0)$sql.="DELETE FROM acc_incovotes WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno NOT IN (SELECT sno FROM acc_votes WHERE descr LIKE '%refund%');";
				else $sql.="UPDATE acc_incovotes SET amt=amt+($ref-$origref) WHERE recno LIKE '$recno' and acc LIKE '$tkn[1]' and voteno NOT IN (SELECT sno FROM acc_votes WHERE descr LIKE 
				'%refund%');";
				if (strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"studfee.php\">HERE </a> to go back."); 
				while(mysqli_next_result($conn)){;}} 				
			}if(strcasecmp($pytfrm,'KIND')==0 || strcasecmp($origpf,'KIND')==0){//Fee payment in kind
				if(strcasecmp($origpf,'KIND')!=0){//Originally not fee in kind
					mysqli_multi_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno'; SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '1'; SELECT voteno 
					FROM acc_votesassigned WHERE name LIKE '%kind%'; SELECT sno FROM acc_votes WHERE acc=1 and (descr LIKE '%lunch%' or descr LIKE '%board%'); SELECT amt FROM ".($tkn[1]==1?
					"acc_incorecno1":"acc_incorecno0")." WHERE recno LIKE '$recno';"); 
					$i=0; $payno=0; $vote=0; $addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';	
					do{
						if($rs=mysqli_store_result($conn)){
							if($i==0){$no=mysqli_num_rows($rs); if ($no>0) list($payno)=mysqli_fetch_row($rs);
							}elseif($i==1){$no=mysqli_num_rows($rs); if ($no>0) list($vono)=mysqli_fetch_row($rs);
							}elseif($i==2){$no=mysqli_num_rows($rs); if ($no>0) list($vote)=mysqli_fetch_row($rs);										
							}elseif($i==3){$no=mysqli_num_rows($rs); if ($vote==0 && $no>0) list($vote)=mysqli_fetch_row($rs);} //only when fee in Kind vote not defined
							else if(mysqli_num_rows($rs)>0) list($addamt)=mysqli_fetch_row($rs); else $addamt=0;
							mysqli_free_result($rs);
						}$i++;
					}while(mysqli_next_result($conn)); $vono++; $ttlamt+=$addamt;
					if($payno==0){//paye details are not in the system
						if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES (0,curdate(),'$parent','$idno',".var_export($addr,true).",
						'$telno','$addby')")){
							$rs=mysqli_query($conn,"SELECT last_insert_id()"); list($payno)=mysqli_fetch_row($rs);  mysqli_free_result($rs);
						}
					}
					mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,pytfrm,acc,caamt,rmks,expno,addedby,recsno) values ($vono,curdate(),'Cash',1,$ttlamt,'BEING PAYMENT 
					FOR $kind',$payno,'$addby',$tkn[2]); INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,1,$vote,$ttlamt);") or die(mysqli_error($conn));
				}elseif(strcasecmp($pytfrm,'KIND')!=0){//Originally fee in Kind but has changed
					mysqli_multi_query($conn,"UPDATE acc_pytvotes SET markdel=1 WHERE (vono,acc) IN (SELECT vono,acc FROM acc_exp WHERE recsno LIKE '$tkn[2]'); UPDATE acc_exp SET markdel=1,
					delreason='Fees Receipt No. $recno inkind changed to $pytfrm on ".date("D d F, Y")."',recsno=null WHERE recsno LIKE '$tkn[2]';"); while(mysqli_next_result($conn)){;}
				}else{
					mysqli_query($conn,"UPDATE acc_exppayee SET payee='$parent',idno='$idno',address=".var_export($addr,true).",telno='$telno' WHERE payno IN (SELECT expno FROM acc_exp 
					WHERE recsno LIKE '$tkn[2]')");	
				}
			}
		} header("Location:feecollection.php?action=1-1");	
    }if(isset($_POST['btnDel'])){
		$tkn=isset($_POST['txtTkn1'])?sanitize($_POST['txtTkn1']):'0-0-0-0-0-0';	$tkn=preg_split('/\-/',$tkn);//[0]Token [1]Rec No.[2]Acc [3]Serial No [4]Mode [5]AdmNo.
		$rmks=isset($_POST['txtReason'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtReason']))):null; $rmks=strlen($rmks)>0?$rmks:null;
		if($_SESSION['form_token']!=$tkn[0] || is_null($rmks) || strlen($rmks)<10){
			print "Sorry, cancellation of the fees record is not successful. Click <a href=\"feerecedit.php?rec=$tkn[2]-$tkn[3]-$tkn[5]\">HERE</a> to go back.";
			unset($_SESSION['form_token']); exit(0);
		}else{
			$sql="UPDATE acc_incofee SET markdel=1,delreason=".var_export($rmks,true)." WHERE sno LIKE '$tkn[3]'; UPDATE acc_IncoRecNo0 SET markdel=1 WHERE sno LIKE '$tkn[3]'; UPDATE 
			acc_IncoRecNo1 SET markdel=1 WHERE sno LIKE '$tkn[3]'; UPDATE acc_incovotes SET markdel=1 WHERE recno IN (SELECT recno FROM acc_incorecno0 WHERE sno LIKE '$tkn[3]' UNION SELECT 
			recno FROM acc_incorecno1 WHERE sno LIKE '$tkn[3]');";
			if(strcasecmp($tkn[4],'KIND')==0) $sql.="UPDATE acc_exp SET markdel=1,delreason=".var_export($rmks,true)." WHERE recsno LIKE '$tkn[3]'; UPDATE acc_pytvotes SET markdel=1 
			WHERE acc LIKE '$tkn[2]' and voteno LIKE '$tkn[4]' and vono IN (SELECT vono FROM acc_exp WHERE recsno LIKE '$tkn[3]');";
			mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Not successfully deleted. Click <a href=\"feecollection.php\">HERE</a> to go back.");
			$i=0; while(mysqli_next_result($conn)){$i+=mysqli_affected_rows($conn);} $i=($i>0?1:0);
			header("Location:feecollection.php?action=2-$i"); exit(0);
		}
	}else{
		$info=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):"0-0"; 	$info=preg_split('/\-/',$info); //[0] acc, [1] receipt serial no,[2] admission no.
		$sql="SELECT i.pytdate,i.paidby,i.pytfrm,i.cheno,i.bursno,i.bankno,i.kinddescr,f.arrears,f.spemed,f.unifrm,".($info[0]==1?"f.refunds,f.prep":"0 as ref,0 as prep")." FROM 
		acc_incofee i INNER JOIN ".($info[0]==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno) WHERE sno LIKE '$info[1]'; SELECT recno,bc,(amt-transfer) as amt FROM ".($info[0]==1?
		"acc_incorecno0":"acc_incorecno1")." WHERE sno LIKE '$info[1]'; SELECT voteno,amt FROM acc_incovotes WHERE acc like '$info[0]' and markdel=0 and recno IN (select recno FROM ".
		($info[0]==1?"acc_incorecno0":"acc_incorecno1")." WHERE sno LIKE '$info[1]'); SELECT a.descr FROM acc_voteacs a WHERE acno LIKE '$info[0]' and a.stud_assoc=1; SELECT v.sno,
		v.descr,if(isnull(c.t3),0,if((c.t3-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t3-if(isnull(sum(f.ttl)),0,sum(f.ttl))))) as bal FROM acc_votes v Inner Join acc_voteacs a On 
		(v.acc=a.acno) LEFT JOIN clsfee c On (c.voteno=v.sno) LEFT JOIN (SELECT i.admno,f.acc,v.voteno,sum(v.amt) as ttl FROM acc_incofee i Inner Join ".($info[0]==1?"acc_incorecno0":
		"acc_incorecno1")." f USING (sno) Inner Join acc_incovotes v USING (recno) GROUP BY i.admno,f.acc,v.voteno,i.markdel HAVING markdel=0 and f.acc LIKE '$info[0]')f USING 
		(admno,voteno) GROUP BY v.acc,a.stud_assoc,v.markdel,v.orderno,v.sno,v.descr,v.stud_fee,c.admno HAVING v.stud_fee=1 and v.acc LIKE '$info[0]' and a.stud_assoc=1 and v.markdel=0 
		and (c.admno is null or c.admno LIKE '$info[2]') ORDER BY v.sno ASC; SELECT s.stud_names,s.cls,ar.arbf,ar.med,ar.uni,ar.acspemed,ar.acunifrm,if(((s.t1f+ar.arbf+if(ar.acspemed=
		$info[0],ar.med,0)+if(ar.acunifrm=$info[0],ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+if(ar.acspemed=$info[0],ar.med,0)+if(ar.acunifrm=$info[0],ar.uni,0))-
		if(isnull(f.fee),0,f.fee))) as t1,if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,f.fee)-if((s.t1f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,
		f.fee))))) as t2,if((s.t3f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t3f-if(isnull(f.fee),0,f.fee)-if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee))))) as t3,
		(s.t3f+ar.arbf+if(ar.acspemed=$info[0],ar.med,0)+if(ar.acunifrm=$info[0],ar.uni,0)-if(isnull(f.fee),0,f.fee)) as ybal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) as 
		stud_names,concat(cn.clsname,'-',c.stream) As cls,s.curr_year,".($info[0]==1?"sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc=1,cf.T2,0)) as t2f,sum(if(v.acc=1,cf.T3,0)) as t3f":
		"sum(if(v.acc!=1,cf.T1,0)) as t1f,sum(if(v.acc!=1,cf.T2,0)) as t2f,sum(if(v.acc!=1,cf.T3,0)) as t3f")." FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN 
		classnames cn USING (clsno) INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY s.admno,
		s.surname,s.onames,s.curr_year,cn.clsname,c.stream,a.stud_assoc,s.present,s.markdel HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$info[2]')s INNER JOIN 
		(SELECT c.admno,sum(if($info[0]=1,c.bbf,c.miscbf)) as arbf,sum(c.spemed) as med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc 
		else 0 end) as acspemed,sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM `acc_votesassigned`)x GROUP BY admno, markdel HAVING markdel=0 and admno LIKE '$info[2]')ar 
		ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,".($info[0]==1?"if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm))":"if(isnull(sum(v.amt)),0,sum(v.amt-
		v.arrears-v.spemed-v.unifrm))")." as fee FROM acc_incofee f LEFT JOIN ".($info[0]==1?"acc_incorecno0":"acc_incorecno1")." v USING (sno) GROUP BY f.admno,f.MarkDel  HAVING 
		f.markdel=0 and f.admno LIKE '$info[2]')f ON (s.admno=f.admno); SELECT concat(sum(case when name='bbf' then acc else 0 end),'-',sum(case when name='bbf' then voteno else 0 end)) 
		as bbf,concat(sum(case when name='miscbf' then acc else 0 end),'-',sum(case when name='miscbf' then voteno else 0 end)) as miscbf,concat(sum(case when name='spemed' then acc else 0 
		end),'-',sum(case when name='spemed' then voteno else 0 end)) as spemed,concat(sum(case when name='unifrm' then acc else 0 end),'-',sum(case when name='unifrm' then voteno else 0 
		end)) as unifrm FROM acc_votesassigned;SELECT feedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';";  
		mysqli_multi_query($conn,$sql);	$form_token=uniqid();  	$_SESSION['form_token']=$form_token; 	$i=$del=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if ($i==0)list($ron,$pb,$pf,$cn,$bn,$bank,$kd,$arp,$medp,$refp,$prep,$unip)=mysqli_fetch_row($rs);
				elseif($i==1)list($recno,$bc,$amt)=mysqli_fetch_row($rs);
				elseif($i==2)while (list($v,$a)=mysqli_fetch_row($rs)) $voteamt[]=new VoteAmt($v,$a);
				elseif($i==3)list($acc)=mysqli_fetch_row($rs);
				elseif($i==4){$nov=mysqli_num_rows($rs); while($d=mysqli_fetch_row($rs)) $balances[]=new Balance($d[0],$d[1],$d[2]);}
				elseif($i==5)list($stnm,$stcls,$arr,$med,$uni,$acmed,$acuni,$t1,$t2,$t3,$ttl)=mysqli_fetch_row($rs);
				elseif($i==6) $spevote=mysqli_fetch_row($rs);//[0] bbf A/C & Vote [1] Misc Arr & Vote [2] Spemed AC & Vote [3] Unifrm A/C & Vote
				else list($del)=mysqli_fetch_row($rs);
				mysqli_free_result($rs);	
			}$i++;	
		}while(mysqli_next_result($conn)); $mon=date('m'); $bank=is_null($bank)?0:$bank; $bursbal=0; $payee='';	$idno='';	$address='';	$telno='';
		if(!is_null($bn)){$rs=mysqli_query($conn,"SELECT b.pytfrm,b.cheno,b.bankno,(b.amt-if(isnull(f.ttl),0,f.ttl)) as bal FROM acc_burs b LEFT JOIN (SELECT f.bursno,
		sum(if(isnull(f1.amt),0,(f1.amt+f1.bc))+if(isnull(f2.amt),0,(f2.amt+f2.bc))) as ttl FROM acc_incofee f Left Join acc_incorecno0 f1 USING (sno) left Join acc_incorecno1 f2 USING 
		(sno) GROUP BY f.bursno,f.markdel having f.markdel=0 and f.bursno LIKE '$bn')f USING (bursno) GROUP BY b.pytfrm,b.cheno,b.bankno,b.bursno,b.markdel HAVING b.bursno LIKE '$bn' and 
		b.markdel=0"); list($bursbal)=mysqli_fetch_row($rs); mysqli_free_result($rs);}
		if(strcasecmp($pf,'kind')==0){$rs=mysqli_query($conn,"SELECT p.payee,p.idno,p.address,p.telno FROM acc_exppayee p WHERE p.payno IN (SELECT expno FROM acc_exp WHERE recsno LIKE 
		'$info[1]')"); list($payee,$idno,$address,$telno)=mysqli_fetch_row($rs); mysqli_free_result($rs);}
	}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="tpl/css/inputfrms.css"/>
    <link href="../date/tcal.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/>
	<script type="text/javascript" src="../date/tcal.js"></script>
    <style>body{font-size:10px;background: url(../gen_img/ara.jpg) no-repeat;background-size: cover;}input,select{border:0.5px dotted #0d0;border-radius:6px;color:#00d;height:13pt;
	padding:1px;} #spKind{display:none;}
	textarea{border:0.5px dotted #0d0;border-radius:7px;color:#00d;padding:1px;}table{padding:3px;border-collapse:collapse;}table.vote,th.vote,td.vote{border:0px;
	border-bottom:0.5px dotted blue;}td{border:0px;}</style>
</head>
<body onload="showKind(<?php echo "'$pf'";?>)">
<form method="post" action="fsereceiveincome.php" name="frmFeeRecs" onsubmit="return SaveFeeRecord(this);"><input type="hidden" name="txtNoV" id="txtNoV" size=2 value="<?php print $nov;?>">
<input type="hidden" name="txtToken" id="txtToken" value="<?php print "$form_token-$info[0]-$info[1]-$acmed-$acuni";?>">
<h2 style="font-weight:bold;font-size:13pt;letter-spacing:2px;word-spacing:3px;color:#fff;background:#000;"><?php print "EDITING $acc FEE RECEIPT<br><hr style=\"background:#fff;
border:#fff;\">ADM. NO. ".$info[2]." <u>".$stnm."</u> IN CLASS ".$stcls;?></h2>
<table style="float:left;padding:3px;"><tr><td colspan="2">
	<span id="feeDetails" style="float:left;background:#fff;border-radius:20px;border:0px;">
        <table align="center" style="background:linear-gradient(to right,#eee,#ccebff);"><tr><td align="right" colspan=4 bgcolor="#eeeeee" style="padding:5px;"><b>TODAY: <?php 
		print strtoupper(date("D d F, Y")); ?></b></td></tr>
		<tr><td style="padding:5px;"><b>Receipt No.</b><br><input type="text" name="txtRecNo" size="12" maxlength="5" value="<?php echo $recno;?>" readonly></td><td style="padding:5px;">
		<b>Admission No.</b><br><Input name="txtAdmNo" id="txtAdmNo" size=7 type="text" readonly value="<?php print $info[2];?>"></td><td colspan=2 style="padding:5px;"><b>Fees Received On
		</b><br><input type="text" size="15" name="dtpDate" readonly value="<?php print date("d-m-Y",strtotime($ron)); ?>" id="dtpDate" class="tcal"></td></tr>
		<tr><td colspan=4><hr></td></tr><tr><td style="padding:5px;"><b>Fee Paid By</b><br><SELECT name="cboPaidBy" id="cboPaidBy" size="1"><Option <?php print strcasecmp($pb,'parent')==0?
		"selected":"";?> value="Parent">Parent</option><Option <?php print strcasecmp($pb,'bursary')==0?"selected":""; ?>>Bursary</option><Option <?php print strcasecmp($pb,'guardian')==0?
		"selected":"";?> value="Guardian">Guardian</option><Option <?php print strcasecmp($pb,'well wisher')==0?"selected":""; ?>>Well Wisher</option></SELECT></td><td style="padding:5px;">
		<b>Bursary No.</b><br><input type="text" name="txtBursNo" id="txtBursNo" value="<?php print $bn;?>" onchange="loadBursaryBal(this)" size=7 maxlength=4 onkeyup="checkInput(1,this)">
		<input type="hidden" name="txtOrigBursNo" id="txtOrigBursNo" value="<?php print $bn;?>"></td><td style="background:#inherit;padding:5px;" colspan=2><b>Bursary Balance to be 
		Distributed</b><br><input type="text" name="txtBursBal" id="txtBursBal" size=8 readonly value="<?php echo number_format($bursbal,2);?>" style="text-align:right;background:inherit;">
		</td></tr>
		<tr><td colspan="4"><hr></td></tr><tr><td style="padding:5px;"><b>Mode of Payment</b><br><SELECT name="cboPytFrm" id="cboPytFrm" size=1 onchange="checkPyt(this)"><option <?php 
		print strcasecmp($pf,'cash')==0?"selected":"";?> value="CASH">Cash</option><option <?php print strcasecmp($pf,'cheque')==0?"selected":"";?> value="CHEQUE">Cheque</option><option 
		value="DIRECT BANKING" <?php print strcasecmp($pf,'direct banking')==0?"selected":"";?>>Direct Banking</option><option <?php print strcasecmp($pf,'kind')==0?"selected":"";?> 
		value="KIND">Kind</option><option <?php print strcasecmp($pb,'mfees')==0?"selected":"";?> value="MFEES">M-Fees</option><option <?php print strcasecmp($pb,'money order')==0?
		"selected":"";?> value="MONEY ORDER">Money Order</option></SELECT><input type="hidden" name="txtOrigPF" id="txtOrigPF" size=5 value="<?php echo $pf;?>"></td><td 
		style="padding:5px;"><b>Trans/ Cheque No.</b><br><input name="txtCheNo" id="txtCheNo" size=15 maxlength=15 onkeyup="validateTransNo(this)" onchange="verifyDuplicateTransNo(this)" 
		<?php echo "value=\"$cn\" ".(strcasecmp($pf,'cash')!=0?"":"locked");?>></td><td colspan=2><b>Banker</b>(For Cheque/Direct Banking/Money Order)<br><SELECT name="cboBank" 
		id="cboBank" size=1 readonly><option value="0" <?php echo ($bank==0?"selected":"");?>>None</option><?php $rs=mysqli_query($conn,"SELECT sno,descr FROM acc_banks WHERE markdel=0 
		ORDER BY descr Asc"); while ($d=mysqli_fetch_row($rs)) print "<option ".($bank==$d[0]?"selected":"")." value=\"$d[0]\">$d[1]</option>"; mysqli_free_result($rs);?></SELECT></td></tr>
		<tr><td colspan=4 style="padding:5px;"><span id="spKind" style="background:inherit;"><table><tr style="padding:5px;"><td colspan=2 style="background-color:#444;color:#fff;
		font-weight:bold;letter-spacing:3px;word-spacing:4px;padding:5px;">DESCRIPTION OF FEES RECEIVED IN KIND</td></tr><tr><td style="padding:5px;"><b>ID No.</b><br><input type="text" 
		name="txtIDNo" id="txtIDNo" size="12" maxlength="10" value="<?php echo $idno;?>" placeholder="ID No." onkeyup="checkInput(1,this)" onchange="showKindDet(this)"></td><td 
		style="padding:5px;"><b>Parent/Guardian Names</b><br><input type="text" name="txtParent" id="txtParent" size="65" maxlength="40" value="<?php echo $payee;?>" readonly 
		placeholder="Names of Guardian/ Parent"></td></tr>
		<tr><td style="padding:5px;"><b>Tel No.</b><br><input type="text" name="txtTelNo" id="txtTelNo" size="13" maxlength=13 value="<?php echo $telno;?>" readonly placeholder="+2547">
		</td><td style="padding:5px;"><b>Postal Address</b><br><input type="text" name="txtAddress" id="txtAddress" size=65 maxlength=75 value="<?php echo $address;?>" readonly 
		placeholder="P.O Box"></td></tr>
		<tr><td colspan=2 style="padding:5px;"><b>Narration of Fee Paid in Kind</b><br><textarea name="txtKind" id="txtKind" type="text" placeholder="2 90KG BAGS OF MAIZE @4,000" cols=65 
		rows=2 maxlength=150 readonly style="text-transform:uppercase;"><?php echo $kd;?></textarea></span></td></tr></table></span></td></tr><tr><td colspan=4><hr></td></tr>
		<tr><td style="padding:5px;"><b>Amount of Fee Paid</b><br><input type="text" name="txtFee" id="txtFee" size=14	maxlength=11 style="text-align:right;" value="<?php echo 
		number_format($amt,2);?>" onkeyup="ttlFee()" onchange="calcTtl()"><input type="hidden" name="txtOrigFee" id="txtOrigFee" size=14 maxlength=11 value="<?php echo $amt;?>"></td><td 
		valign="top" style="padding:5px;"><b>Bank Charges</b><br><INPUT type="text" name="txtBC" id="txtBC" size=10 maxlength=11 style="text-align:right;" value="<?php echo 
		number_format($bc,2);?>" onkeyup="ttlFee()" <?php echo strcasecmp($pf,'cheque')==0?"":"readonly";?>><input type="hidden" name="txtOrigBC" id="txtOrigBC" size=14 maxlength=11 
		value="<?php echo $bc;?>"></td><td bgcolor="#eeeeee" style="padding:5px;"><b>Total Amount (Kshs.)</b><br><input type="text" name="txtTtlFee" id="txtTtlFee" size=13 
		value="<?php print number_format(($amt+$bc),2);?>" disabled style="text-align:right;font-weight:bold;"></td></tr></table>
	</span></td></tr><tr><td colspan=2 valign="top" style="font-weight:bold;padding:5px;"><TEXTAREA name="txtWords" id="txtWords" cols=60 rows=2 style="border:0px;font-weight:bold;
	background:inherit;color:#fdf;" readonly><?php echo NumToWord($amt+$bc);?></textarea></td></tr><tr style="letter-spacing:1px;word-spacing:2px;background-color:#555;color:#fff;"><td 
	align="center" class="vote" colspan=2 style="padding:5px;">Fee Amount to be Distributed:<input type="text" name="txtVoteBal" id="txtVoteBal" size=13 value="0.00" 
	style="text-align:right;font-weight:bold;background:inherit;color:#fff;" readonly></tr></table>
	<span id="balShow" style="background:#eee;"><table><tr><th class="vote">VOTEHEAD</th><th class="vote">BALANCE</th><th class="vote">CURRENT</th><th class="vote">EDITABLE</th></tr>
	<?php 
		$locked=''; $lc=$a=0;
		foreach($balances as $bal){
		 	$b=findBal($voteamt,$bal->valVSNo()); 
			if($info[0]==1){
				$arrpos=(stripos($bal->valVName(),'arrear')!==false?1:0); 	$medpos=(stripos($bal->valVName(),'surcharg')!==false?1:0);
				$burspos=(stripos($bal->valVName(),'bursary')!==false?1:0);	$xtraunipos=(stripos($bal->valVName(),'extra uni')!==false?1:0);
				if (($arrpos==1 || $medpos==1 || $burspos==1 || $xtraunipos==1)) $ro="readonly style=\"color:#00f;background:#eee;";
				else $ro="style=\"color:#000;"; $ro.="text-align:right;\"";
				if(stripos($bal->valVName(),'prepa')!==false || stripos($bal->valVName(),'refund')!==false){$locked.=($lc==0?"":"-")."$a"; $lc++;}
			}elseif($info[0]!=1){
				$arrpos=(stripos($bal->valVName(),'arrear')!==false?1:0); $xtraunipos=(stripos($bal->valVName(),'extra uni')!==false?1:0);
				if(($arrpos==1 || $xtraunipos==1)){
					$ro="readonly style=\"color:#00f;background:#eee;";	$locked.=($lc==0?"":"-")."$a";
				}else $ro="style=\"color:#000;"; $ro.="text-align:right;\"";	
			}else $ro="style=\"color:#000;text-align:right;\"";
			print "<tr><td class=\"vote\">".$bal->valVName()."</td><td class=\"vote\"><input type=\"hidden\" name=\"txtVote_$a\" id=\"txtVote_$a\" value=\"$info[0]-".$bal->valVSNo().
			"\" size=3><input type=\"text\" name=\"txtBal_$a\" id=\"txtBal_$a\" readonly style=\"text-align:right;background:#eee;\" value=\"".number_format($bal->valBal(),2)."\" 
			size=10></td><td class=\"vote\"><input type=\"text\" name=\"txtCurr_$a\" id=\"txtCurr_$a\" style=\"text-align:right;background:#eee;\" value=\"".number_format($b,2)."\" 
			size=10 readonly></td><td class=\"vote\"><input type=\"text\" name=\"txtAmt_$a\" id=\"txtAmt_$a\" $ro value=\"".number_format($b,2)."\" size=10 onchange=\"calcVotes($a)\">
			</td></tr>";	$a++;
		}print "</table><input name=\"txtLocked\" id=\"txtLocked\" type=\"hidden\" value=\"$locked\">";
	?></span>
<br><br><hr><center><button type="submit" name="btnSaveFee" id="CmdSave" style="height:34px;padding:4px;border-radius:10pt;min-width:200px;font-size:11pt;
font-weight:bold"><b>Save Fee Record</b></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button type="button" name="btnDelete" id="btnDelete" style="height:34px;padding:4px;border-radius:10pt;min-width:200px;font-size:11pt;font-weight:bold" onclick="showDel(<?php 
echo $del;?>)"><b>Delete Fee Record</b></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;<a href="feecollection.php"><button type="button" name="btnClose" style="height:34px;padding:4px;border-radius:10pt;min-width:150px;">Close/ Cancel</button></a></center>
</form>
<div id="feeDel" class="modal">
	<div class="imgcontainer"><span onclick="document.getElementById('feeDel').style.display='none'" class="close" title="Close" style="color:#fff;">&times;</span></div><br/>
	<div class="container" style="font-size:10pt;color:#fff;"><br><br><form name="frmDel" method="post" action="feerecedit.php"	onsubmit="return confirmDel(<?php echo $del;?>)">
	<table align="center" class="h" style="font-size:12pt;"><tr><td style="background-color:#444;color:#fff;font-weight:bold;letter-spacing:2px;word-spacing:4px;text-align:center;">DELETE 
	<?php echo "$pf RECEIPT NO. $recno FROM $stnm <br> IN CLASS $stcls";?><hr></td></tr><INPUT name="txtTkn1" id="txtTkn1" type="hidden" value="<?php echo 
	"$form_token-$recno-$info[0]-$info[1]-$pf-$info[2]";?>" id="txtTkn">
	<tr><td class="h">Reason for Cancellation of Income *<br><textarea name="txtReason" id="txtReason" required cols=80 rows=5 maxlength=150 placeholder="ERRONEOUSLY CAPTURED" 
	style="text-transform:uppercase;"></textarea><hr><br>.</td></tr></table>
	<button name="btnDel" type="submit" class="modBtn">Cancel Income Record</button>
	</div><br>
	<div class="container" style="text-align:right;"><button type="button" onclick="document.getElementById('feeDel').style.display='none'" class="cancelbtn">Close</button></div>
	</form>
</div>
<script type="text/javascript" src="tpl/js/feeRecEdit.js"></script>
</body>
</html> 