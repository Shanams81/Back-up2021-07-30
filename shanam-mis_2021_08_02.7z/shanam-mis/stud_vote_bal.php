<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != '')))  header ("Location:../index.php"); else  include_once('../conn/pri_sch_connect.inc');
	$un=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';	include_once('tpl/printing.tpl');
	$admno=$_REQUEST['adm']; $admno=preg_split("/\-/",$admno);//$admno[0] admission no.,$admno[1]-1 fee_bal_status.php
?>
<html>
<head>
	<link rel="shortcut icon" href="img/phone.ico"/>
	<link href="tpl/accprint.css" rel="stylesheet" type="text/css" media="print"/>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<script type="text/javascript" src="tpl/printthis.js"></script>
</head>
<body >
<?php
	$rsDet=mysqli_query($conn,"SELECT scnm,scadd FROM ss");
	if (mysqli_num_rows($rsDet)>0) list($scnm,$scadd)=mysqli_fetch_row($rsDet);
	mysqli_free_result($rsDet);
	//main bal
 	$rsBal=mysqli_query($conn,"SELECT s.admno,s.names,s.cls,s.specialmedical,s.bbf,s.t1trans,if((f.t1board-s.boap)<1,0,(f.t1board-s.boap)) as t1boabal,if((f.t1act-
	s.actp)<1,0,(f.t1act-s.actp)) as t1actbal,if((f.t1pemol-s.pemp)<1,0,(f.t1pemol-s.pemp)) as t1pembal,if((f.t1ltt-s.lttp)<1,0,(f.t1ltt-s.lttp)) as t1lttbal,if((f.t1rmi-s.rmip)<1,0,
	(f.t1rmi-s.rmip)) as t1rmibal,if((f.t1ewc-s.ewcp)<1,0,(f.t1ewc-s.ewcp)) as t1ewcbal,if((f.t1adm-s.adminp)<1,0,(f.t1adm-s.adminp)) as t1admbal,if((f.t1lib-s.libp)<1,0,(f.t1lib-
	s.libp)) as t1libbal, if((f.t1med-s.medp)<1,0,(f.t1med-s.medp)) as t1medbal, if((f.t1tui-s.tuip)<1,0,(f.t1tui-s.tuip)) as t1tuibal, if((f.t1exam-s.exap)<1,0,(f.t1exam-s.exap)) as 
	t1exabal,if((f.t1olevies-s.olep)<1,0,(f.t1olevies-s.olep)) as t1olebal,if((f.maint1-s.amtp)<1,(s.specialmedical+s.bbf+s.t1trans),(f.maint1-s.amtp+s.specialmedical+s.bbf+s.t1trans)) 
	as t1bal,s.t2trans,if((f.t2board-s.boap-if((f.t1board-s.boap)<1,0,(f.t1board-s.boap)))<1,0,(f.t2board-s.boap-if((f.t1board-s.boap)<1,0,(f.t1board-s.boap)))) as t2boabal,
	if((f.t2act-s.actp-if((f.t1act-s.actp)<1,0,(f.t1act-s.actp)))<1,0,(f.t2act-s.actp-if((f.t1act-s.actp)<1,0,(f.t1act-s.actp)))) as t2actbal, if((f.t2pemol-s.pemp-if((f.t1pemol-
	s.pemp)<1,0,(f.t1pemol-s.pemp)))<1,0,(f.t2pemol-s.pemp-if((f.t1pemol-s.pemp)<1,0,(f.t1pemol-s.pemp)))) as t2pembal, if((f.t2ltt-s.lttp-if((f.t1ltt-s.lttp)<1,0,(f.t1ltt-s.lttp)))<1,
	0,(f.t2ltt-s.lttp-if((f.t1ltt-s.lttp)<1,0,(f.t1ltt-s.lttp)))) as t2lttbal, if((f.t2rmi-s.rmip-if((f.t1rmi-s.rmip)<1,0,(f.t1rmi-s.rmip)))<1,0,(f.t2rmi-s.rmip-if((f.t1rmi-s.rmip)<1,0,
	(f.t1rmi-s.rmip)))) as t2rmibal,if((f.t2ewc-s.ewcp-if((f.t1ewc-s.ewcp)<1,0,(f.t1ewc-s.ewcp)))<1,0,(f.t2ewc-s.ewcp-if((f.t1ewc-s.ewcp)<1,0,(f.t1ewc-s.ewcp)))) as t2ewcbal, 
	if((f.t2adm-s.adminp-if((f.t1adm-s.adminp)<1,0,(f.t1adm-s.adminp)))<1,0,(f.t2adm-s.adminp-if((f.t1adm-s.adminp)<1,0,(f.t1adm-s.adminp)))) as t2admbal,if((f.t2lib-s.libp-if((f.t1lib-
	s.libp)<1,0,(f.t1lib-s.libp)))<1,0,(f.t2lib-s.libp-if((f.t1lib-s.libp)<1,0,(f.t1lib-s.libp)))) as t2libbal, if((f.t2med-s.medp-if((f.t1med-s.medp)<1,0,(f.t1med-s.medp)))<1,0,
	(f.t2med-s.medp-if((f.t1med-s.medp)<1,0,(f.t1med-s.medp)))) as t2medbal, if((f.t2tui-s.tuip-if((f.t1tui-s.tuip)<1,0,(f.t1tui-s.tuip)))<1,0,(f.t2tui-s.tuip-if((f.t1tui-s.tuip)<1,0,
	(f.t1tui-s.tuip)))) as t2tuibal, if((f.t2exam-s.exap-if((f.t1exam-s.exap)<1,0,(f.t1exam-s.exap)))<1,0,(f.t2exam-s.exap-if((f.t1exam-s.exap)<1,0,(f.t1exam-s.exap)))) as t2exabal, 
	if((f.t2olevies-s.olep-if((f.t1olevies-s.olep)<1,0,(f.t1olevies-s.olep)))<1,0,(f.t2olevies-s.olep-if((f.t1olevies-s.olep)<1,0,(f.t1olevies-s.olep)))) as t2olebal, if((f.maint2-
	s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))<1,s.t2trans,(f.maint2+s.t2trans-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))) as t2bal,	
	s.t3trans,if((f.board-s.boap-if((f.t2board-s.boap)<1,0,(f.t2board-s.boap)))<1,0,(f.board-s.boap-if((f.t2board-s.boap)<1,0,(f.t2board-s.boap)))) as t3boabal, if((f.act-s.actp
	-if((f.t2act-s.actp)<1,0,(f.t2act-s.actp)))<1,0,(f.act-s.actp-if((f.t2act-s.actp)<1,0,(f.t2act-s.actp)))) as t3actbal, if((f.pemol-s.pemp-if((f.t2pemol-s.pemp)<1,0,(f.t2pemol-
	s.pemp)))<1,0,(f.pemol-s.pemp-if((f.t2pemol-s.pemp)<1,0,(f.t2pemol-s.pemp)))) as t3pembal, if((f.ltt-s.lttp-if((f.t2ltt-s.lttp)<1,0,(f.t2ltt-s.lttp)))<1,0,(f.ltt-s.lttp-
	if((f.t2ltt-s.lttp)<1,0,(f.t2ltt-s.lttp)))) as t3lttbal, if((f.rmi-s.rmip-if((f.t2rmi-s.rmip)<1,0,(f.t2rmi-s.rmip)))<1,0,(f.rmi-s.rmip-if((f.t2rmi-s.rmip)<1,0,(f.t2rmi-
	s.rmip)))) as t3rmibal, if((f.ewc-s.ewcp-if((f.t2ewc-s.ewcp)<1,0,(f.t2ewc-s.ewcp)))<1,0,(f.ewc-s.ewcp-if((f.t2ewc-s.ewcp)<1,0,(f.t2ewc-s.ewcp)))) as t3ewcbal, if((f.adm-
	s.adminp-if((f.t2adm-s.adminp)<1,0,(f.t2adm-s.adminp)))<1,0,(f.adm-s.adminp-if((f.t2adm-s.adminp)<1,0,(f.t2adm-s.adminp)))) as t3admbal, if((f.lib-s.libp-if((f.t2lib-s.libp)<1,
	0,(f.t2lib-s.libp)))<1,0,(f.lib-s.libp-if((f.t2lib-s.libp)<1,0,(f.t2lib-s.libp)))) as t3libbal, if((f.med-s.medp-if((f.t2med-s.medp)<1,0,(f.t2med-s.medp)))<1,0,(f.med-s.medp-
	if((f.t2med-s.medp)<1,0,(f.t2med-s.medp)))) as t3medbal, if((f.tui-s.tuip-if((f.t2tui-s.tuip)<1,0,(f.t2tui-s.tuip)))<1,0,(f.tui-s.tuip-if((f.t2tui-s.tuip)<1,0,(f.t2tui-
	s.tuip)))) as t3tuibal, if((f.exam-s.exap-if((f.t2exam-s.exap)<1,0,(f.t2exam-s.exap)))<1,0,(f.exam-s.exap-if((f.t2exam-s.exap)<1,0,(f.t2exam-s.exap)))) as t3exabal,if((f.olevies-
	s.olep-if((f.t2olevies-s.olep)<1,0,(f.t2olevies-s.olep)))<1,0,(f.olevies-s.olep-if((f.t2olevies-s.olep)<1,0,(f.t2olevies-s.olep)))) as t3olebal,if((f.maint3-s.amtp-if((f.maint2-
	s.amtp)<1,0,(f.maint2-s.amtp)))<1,s.t3trans,(f.maint3+s.t3trans-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))) as t3bal,
	(s.t1trans+s.t2trans+s.t3trans) as trans,(f.board-s.boap) as boabal, (f.act-s.actp) as actbal, (f.pemol-s.pemp) as pembal, (f.ltt-s.lttp) as lttbal, (f.rmi-s.rmip) as rmibal, 
	(f.ewc-s.ewcp) as ewcbal, (f.adm-s.adminp) as admbal, (f.lib-s.libp) as libbal, (f.med-s.medp) as medbal, (f.tui-s.tuip) as tuibal,(f.exam-s.exap) as exabal, (f.olevies-s.olep) as 
	olebal, (f.maint3+s.specialmedical+s.bbf+s.t1trans+s.t2trans+s.t3trans-s.amtp) as bal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',
	c.stream) As cls,c.curr_year,c.feegrp,c.lvlno,c.bbf,c.specialmedical,c.t1trans,c.t2trans,c.t3trans,if(isnull(f.tui),0,f.tui) as tuip,if(isnull(f.boa),0,f.boa) as boap,if(isnull(f.act)
	,0,f.act) as actp,if(isnull(f.lt),0,f.lt) as lttp,if(isnull(f.rm),0,f.rm) as rmip,if(isnull(f.ew),0,f.ew) as ewcp,if(isnull(f.exa),0,f.exa) as exap,if(isnull(f.admin),0,f.admin) as 
	adminp,if(isnull(f.libra),0,f.libra) as libp,if(isnull(f.med),0,f.med) as medp,if(isnull(f.pem),0,f.pem) as pemp,if(isnull(f.ole),0,f.ole) as olep,if(isnull(f.amtpaid),0,f.amtpaid) 
	as amtp FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT admno,curr_year,sum(f.tuition) As tui,sum(f.boarding) As boa,
	sum(f.activity) As act,sum(f.ltt) As lt,
	sum(f.rmi) As rm,sum(f.ewc) as ew,sum(f.exam) As exa,sum(f.adm) As admin,sum(f.lib) as libra,sum(f.medical) as med,sum(f.pemolu) as pem,sum(f.olevy) as ole,sum(amt-arrears-refunds-
	spemed-transport-prep) As amtpaid FROM acc_feerec f GROUP BY f.admno,f.curr_year,f.markdel Having (f.admno LIKE '$admno[0]' and curr_year LIKE '$admno[2]' and f.markdel LIKE '0'))f On 
	(s.admno=f.admno and s.curr_year=f.curr_year) WHERE (s.`admno` Like '$admno[0]'  and s.curr_year LIKE '$admno[2]'))s Inner JOIN acc_feeoutline f USING (curr_year,lvlno,feegrp)");
 	list($admn,$names,$cls,$spmed,$bbf,$trans1,$boa1,$act1,$pem1,$ltt1,$rmi1,$ewc1,$adm1,$lib1,$med1,$tui1,$exa1,$ole1,$bal1,$trans2,$boa2,$act2,$pem2,$ltt2,$rmi2,$ewc2,$adm2,$lib2,
	 $med2,$tui2,$exa2,$ole2,$bal2,$trans3,$boa3,$act3,$pem3,$ltt3,$rmi3,$ewc3,$adm3,$lib3,$med3,$tui3,$exa3,$ole3,$bal3,$trans,$boa,$act,$pem,$ltt,$rmi,$ewc,$adm,$lib,$med,$tui,$exa,
	 $ole,$bal)=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);
	//misc fee
	$rsBal=mysqli_query($conn,"SELECT s.miscbf,s.unifrm,if((f.t1misidcard-idp)<1,0,(f.t1misidcard-idp)) as t1id,if((f.t1misqa-qap)<1,0,(f.t1misqa-qap)) as t1qa,if((f.t1misremedial
	-remp)<1,0,(f.t1misremedial-remp)) as t1rem,if((f.t1misht-htp)<1,0,(f.t1misht-htp)) as t1ht,if((f.t1misgrad-gradp)<1,0,(f.t1misgrad-gradp)) as t1grad,if((f.t1mistrip-tripp)<1,0,
	(f.t1mistrip-tripp)) as t1trip,if((f.t1misole-olep)<1,0,(f.t1misole-olep)) as t1ole,if((f.misct1-amtp)<1,(s.miscbf+s.unifrm),(f.misct1-amtp+s.miscbf+s.unifrm)) as t1bal,
	if((f.t2misidcard-idp-if((f.t1misidcard-idp)<1,0,(f.t1misidcard-idp)))<1,0,(f.t2misidcard-idp-if((f.t1misidcard-idp)<1,0,(f.t1misidcard-idp)))) as t2id,if((f.t2misqa-qap-
	if((f.t1misqa-qap)<1,0,(f.t1misqa-qap)))<1,0,(f.t2misqa-qap-if((f.t1misqa-qap)<1,0,(f.t1misqa-qap)))) as t2qa,if((f.t2misremedial-remp-if((f.t1misremedial-remp)<1,0,
	(f.t1misremedial-remp)))<1,0,(f.t2misremedial-remp-if((f.t1misremedial-remp)<1,0,(f.t1misremedial-remp)))) as t2rem,if((f.t2misht-htp-if((f.t1misht-htp)<1,0,(f.t1misht-htp)))<1,0,
	(f.t2misht-htp-if((f.t1misht-htp)<1,0,(f.t1misht-htp)))) as t2ht,if((f.t2misgrad-gradp-if((f.t1misgrad-gradp)<1,0,(f.t1misgrad-gradp)))<1,0,(f.t2misgrad-gradp-if((f.t1misgrad-
	gradp)<1,0,(f.t1misgrad-gradp)))) as t2grad,if((f.t2mistrip-tripp-if((f.t1mistrip-tripp)<1,0,(f.t1mistrip-tripp)))<1,0,(f.t2mistrip-tripp-if((f.t1mistrip-tripp)<1,0,(f.t1mistrip-
	tripp)))) as t2trip,if((f.t2misole-olep-if((f.t1misole-olep)<1,0,(f.t1misole-olep)))<1,0,(f.t2misole-olep-if((f.t1misole-olep)<1,0,(f.t1misole-olep)))) as t2ole,if((f.misct2-amtp-
	if((f.misct1-amtp)<1,0,(f.misct1-amtp)))<1,0,(f.misct2-amtp-if((f.misct1-amtp)<1,0,(f.misct1-amtp)))) as t2bal,if((f.misidcard-idp-if((f.t2misidcard-idp)<1,0,(f.t2misidcard-idp)))
	<1,0,(f.misidcard-idp-if((f.t2misidcard-idp)<1,0,(f.t2misidcard-idp)))) as t3id,if((f.misqa-qap-if((f.t2misqa-qap)<1,0,(f.t2misqa-qap)))<1,0,(f.misqa-qap-if((f.t2misqa-qap)<1,0,
	(f.t2misqa-qap)))) as t3qa,if((f.misremedial-remp-if((f.t2misremedial-remp)<1,0,(f.t2misremedial-remp)))<1,0,(f.misremedial-remp-if((f.t2misremedial-remp)<1,0,(f.t2misremedial-
	remp)))) as t3rem,if((f.misht-htp-if((f.t2misht-htp)<1,0,(f.t2misht-htp)))<1,0,(f.misht-htp-if((f.t2misht-htp)<1,0,(f.t2misht-htp)))) as t3ht,if((f.misgrad-gradp-if((f.t2misgrad-
	gradp)<1,0,(f.t2misgrad-gradp)))<1,0,(f.misgrad-gradp-if((f.t2misgrad-gradp)<1,0,(f.t2misgrad-gradp)))) as t3grad, if((f.mistrip-tripp-if((f.t2mistrip-tripp)<1,0,(f.t2mistrip-
	tripp)))<1,0,(f.mistrip-tripp-if((f.t2mistrip-tripp)<1,0,(f.t2mistrip-tripp)))) as t3trip,if((f.misole-olep-if((f.t2misole-olep)<1,0,(f.t2misole-olep)))<1,0,(f.misole-olep-
	if((f.t2misole-olep)<1,0,(f.t2misole-olep)))) as t3ole,if((f.misct3-amtp-if((f.misct2-amtp)<1,0,(f.misct2-amtp)))<1,0,(f.misct3-amtp-if((f.misct2-amtp)<1,0,(f.misct2-amtp)))) as 
	t3bal,(f.misidcard-idp) as idbal,(f.misqa-qap) as qabal,(f.misremedial-remp) as rembal,(f.misht-htp) as htbal,(f.misgrad-gradp) as gradbal, (f.mistrip-tripp) as tripbal,(f.misole-
	olep) as olebal,(f.misct3+s.miscbf+s.unifrm-amtp) as bal FROM (SELECT c.curr_year,c.lvlno,c.feegrp,c.miscbf,c.unifrm,if(isnull(sqa),0,sqa) as qap, if(isnull(id),0,id) as idp, 
	if(isnull(rem),0,rem) as remp, if(isnull(sht),0,sht) as htp,if(isnull(sgrad),0,sgrad) as gradp,if(isnull(trip),0,trip) as tripp,if(isnull(ole),0,ole) as olep, if(isnull(amtpaid),0,
	amtpaid) as amtp  FROM class c LEFT JOIN (SELECT payeesno,curr_year,sum(qa) as sqa,sum(idcard) as id,sum(remedial) as rem,sum(ht) as sht,sum(grad) as sgrad,sum(acatrip) as trip,
	sum(olevy) as ole,sum(amt-arrears-uni) as amtpaid FROM acc_miscfeepyts GROUP BY payeesno,curr_year,markdel HAVING (markdel=0 and payeesno LIKE '$admno[0]' and curr_year LIKE 
	'$admno[2]'))m On (c.admno=m.payeesno and c.curr_year=m.curr_year) WHERE (c.admno LIKE '$admno[0]' and c.curr_year LIKE '$admno[2]'))s Inner Join Acc_feeoutline f USING (curr_year,lvlno,
	feegrp)");	
	list($miscbf,$unif,$id1,$qa1,$rem1,$ht1,$grad1,$trip1,$mole1,$mbal1,$id2,$qa2,$rem2,$ht2,$grad2,$trip2,$mole2,$mbal2,$id3,$qa3,$rem3,$ht3,$grad3,$trip3,$mole3,$mbal3,$id,$qa,$rem,$ht,
	$grad,$trip,$mole,$mbal)=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);
	//Display data
	print "<div id=\"print_content\"><table cellpadding=\"1\" cellspacing=\"0\" align=\"center\" style=\"border:1px dotted green;border-collapse:collapse;color:#000000;font-size:12px;\">
	<tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" width=\"100%\"><tr><td rowspan=\"3\"><img src=\"img/logo.png\" width=\"50\" height=\"50\" vspace=\"1\" hspace=\"1\">
	</td><td style=\"font-weight:bold;font-size:14px;letter-spacing:2px;word-spacing:3px;\">$scnm</td></tr><tr><td style=\"font-weight:bold;font-size:14px;\">$scadd</td></tr><tr>
	<td style=\"font-weight:bold;font-size:12px;letter-spacing:1px;word-spacing:2px;\">STUDENT'S FEE BALANCE ANALYSIS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Printed On&nbsp;".
	date("D d-M-Y")."</td></tr><tr><td colspan=\"2\"><hr></td></tr>";
	print "<tr><td>Admission No.</td><td>$admn <u><b>$names</b></u> in class $cls</td></tr><tr><td colspan=\"3\"><Img src=\"img/washout.png\" width=\"450\" height=\"300\" 
	style=\"position:fixed;opacity:0.1;pointer-events:none;\">";
	//votehead allocation
	print "<br><table border=\"1\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" style=\"font-size:11px;\"><tr style=\"letter-spacing:2px;word-spacing:3px;\"><th colspan=\"5\">
	MAIN ACCOUNT FEE BALANCE</th><th rowspan=\"17\" bgcolor=\"#555555\">-</th><th colspan=\"5\">MISCELLANEOUS ACCOUNT FEE BALANCE</th></tr><tr><th align=\"right\">Special Medical 
	Charges</th><th>".number_format($spmed,2)."</th><th colspan=\"2\" align=\"right\">Fee Arrears B/F</th><th>".number_format($bbf,2)."</th><th align=\"right\">School Uniform</th><th>".
	number_format($unif,2)."</th><th colspan=\"2\" align=\"right\">Fee Arrears B/F</th><th>".number_format($miscbf,2)."</th></tr>";
	print "<tr><th>Votehead</th><th>Term I</th><th>Term II</th><th>Term III</th><th>Total</th><th>Votehead</th><th>Term I</th><th>Term II</th><th>Term III</th><th>Total</th></tr>";
	print "<tr><td>Tuition</td><td align=\"right\">".number_format($tui1,2)."</td><td align=\"right\">".number_format($tui2,2)."</td><td align=\"right\">".number_format($tui3,2)."</td>
	<td align=\"right\">".number_format($tui,2)."</td><td>ID Card</td><td align=\"right\">".number_format($id1,2)."</td><td align=\"right\">".number_format($id2,2)."</td><td 
	align=\"right\">".number_format($id3,2)."</td><td align=\"right\">".number_format($id,2)."</td></tr>";
	print "<tr><td>Boarding &amp; Meals</td><td align=\"right\">".number_format($boa1,2)."</td><td align=\"right\">".number_format($boa2,2)."</td><td align=\"right\">".
	number_format($boa3,2)."</td><td align=\"right\">".number_format($boa,2)."</td><td>Quality Assuarance</td><td align=\"right\">".number_format($qa1,2)."</td><td align=\"right\">".
	number_format($qa2,2)."</td><td align=\"right\">".number_format($qa3,2)."</td><td align=\"right\">".number_format($qa,2)."</td></tr>";
	print "<tr><td>Activity</td><td align=\"right\">".number_format($act1,2)."</td><td align=\"right\">".number_format($act2,2)."</td><td align=\"right\">".number_format($act3,2)."</td>
	<td align=\"right\">".number_format($act,2)."</td><td>Remedial Studies</td><td align=\"right\">".number_format($rem1,2)."</td><td align=\"right\">".number_format($rem2,2)."</td><td 
	align=\"right\">".number_format($rem3,2)."</td><td align=\"right\">".number_format($rem,2)."</td></tr>";
	print "<tr><td>L . T &amp; T</td><td align=\"right\">".number_format($ltt1,2)."</td><td align=\"right\">".number_format($ltt2,2)."</td><td align=\"right\">".number_format($ltt3,2).
	"</td><td align=\"right\">".number_format($ltt,2)."</td><td>Holiday Tuition</td><td align=\"right\">".number_format($ht1,2)."</td><td align=\"right\">".number_format($ht2,2)."</td>
	<td align=\"right\">".number_format($ht3,2)."</td><td align=\"right\">".number_format($ht,2)."</td></tr>";
	print "<tr><td>R . M . I</td><td align=\"right\">".number_format($rmi1,2)."</td><td align=\"right\">".number_format($rmi2,2)."</td><td align=\"right\">".number_format($rmi3,2)."</td>
	<td align=\"right\">".number_format($rmi,2)."</td><td>Graduation Fee</td><td align=\"right\">".number_format($grad1,2)."</td><td align=\"right\">".number_format($grad2,2)."</td><td 
	align=\"right\">".number_format($grad3,2)."</td><td align=\"right\">".number_format($grad,2)."</td></tr>";
	print "<tr><td>E . W . C</td><td align=\"right\">".number_format($ewc1,2)."</td><td align=\"right\">".number_format($ewc2,2)."</td><td align=\"right\">".number_format($ewc3,2)."</td>
	<td align=\"right\">".number_format($ewc,2)."</td><td>Academic Trip</td><td align=\"right\">".number_format($trip1,2)."</td><td align=\"right\">".number_format($trip2,2)."</td><td 
	align=\"right\">".number_format($trip3,2)."</td><td align=\"right\">".number_format($trip,2)."</td></tr>";
	print "<tr><td>Examination</td><td align=\"right\">".number_format($exa1,2)."</td><td align=\"right\">".number_format($exa2,2)."</td><td align=\"right\">".number_format($exa3,2).
	"</td><td align=\"right\">".number_format($exa,2)."</td><td>Other Levies</td><td align=\"right\">".number_format($mole1,2)."</td><td align=\"right\">".number_format($mole2,2)."</td>
	<td align=\"right\">".number_format($mole3,2)."</td><td align=\"right\">".number_format($mole,2)."</td></tr>";
	print "<tr><td>Administrative Costs</td><td align=\"right\">".number_format($adm1,2)."</td><td align=\"right\">".number_format($adm2,2)."</td><td align=\"right\">".
	number_format($adm3,2)."</td><td align=\"right\">".number_format($adm,2)."</td><td rowspan=\"6\"></td><td rowspan=\"6\"></td><td rowspan=\"6\"></td><td rowspan=\"6\"></td><td 
	rowspan=\"6\"></td></tr>";
	print "<tr><td>Library Fee</td><td align=\"right\">".number_format($lib1,2)."</td><td align=\"right\">".number_format($lib2,2)."</td><td align=\"right\">".number_format($lib3,2).
	"</td><td align=\"right\">".number_format($lib,2)."</td></tr>";
	print "<tr><td>Medical</td><td align=\"right\">".number_format($med1,2)."</td><td align=\"right\">".number_format($med2,2)."</td><td align=\"right\">".number_format($med3,2)."</td>
	<td align=\"right\">".number_format($med,2)."</td></tr>";
	print "<tr><td>Personal Emolument</td><td align=\"right\">".number_format($pem1,2)."</td><td align=\"right\">".number_format($pem2,2)."</td><td align=\"right\">".number_format($pem3,
	2)."</td><td align=\"right\">".number_format($pem,2)."</td></tr>";
	print "<tr><td>Transport</td><td align=\"right\">".number_format($trans1,2)."</td><td align=\"right\">".number_format($trans2,2)."</td><td align=\"right\">".number_format($trans3,
	2)."</td><td align=\"right\">".number_format($trans,2)."</td></tr>";
	print "<tr><td>Other Levies</td><td align=\"right\">".number_format($ole1,2)."</td><td align=\"right\">".number_format($ole2,2)."</td><td align=\"right\">".number_format($ole3,2).
	"</td><td align=\"right\">".number_format($ole,2)."</td></tr>";
	print "<tr><td><b>Total Main Bal</b></td><td align=\"right\">".number_format($bal1,2)."</td><td align=\"right\">".number_format($bal2,2)."</td><td align=\"right\">".
	number_format($bal3,2)."</td><td align=\"right\">".number_format($bal,2)."</td><td><b>Total Misc Bal.</b></td><td align=\"right\">".number_format($mbal1,2)."</td><td 
	align=\"right\">".number_format($mbal2,2)."</td><td align=\"right\">".number_format($mbal3,2)."</td><td align=\"right\">".number_format($mbal,2)."</td></tr></table>";
	$ttlamt=$bal+$mbal;	
	print "<tr><td colspan=\"2\"><hr></td></tr><tr><td colspan=\"2\"><b>Grand Total Balance </b>".number_format($ttlamt,2)." <u>(".NumToWord(preg_replace("/\,/","",number_format($ttlamt,
	2))).")</u></td></tr><tr><td colspan=\"2\"><br><br>Served By <u><b>$un</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign________________</td>
	</tr><tr><td colspan=\"2\"><hr></td></tr><tr><td colspan=\"2\" style=\"color:#aaaaaa;font-size:7px;\"><center>Fees once paid is neither refunded nor transferable. Designed By: 
	Shanams Digital Solutions +254736732168</center></td></tr></table></td></tr></table></div><br><br><div><center><button type=\"button\" onclick=\"Clickheretoprint()\">Print</button>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"".($admno[1]==0?"studfee.php":"fee_bal_status.php")."\"><button type=\"button\">Close</button></a></div></center>";
	mysqli_close($conn);
?>
</body>
</html>