<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	if (isset($_POST['cmdSave'])){
		$info=isset($_POST['txtData'])?strip_tags($_POST['txtData']):"0-0-0"; 
		$info=preg_split('/\-/',$info); //0 - admission number, 1 no of forms entered and [2] 0 for continuing and 1 for alumni
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(strip_tags($_POST['txtRmks']))):"ON HUMANITARIAN GROUNDS";
		//Main Account amount changes
		$arr=isset($_POST["txtArr"])?strip_tags($_POST["txtArr"]):0;					$arr=preg_replace("/[^0-9^\.]/","",$arr);
		$waiveOrig=isset($_POST["txtWArr"])?strip_tags($_POST["txtWArr"]):0;			$waiveOrig=preg_replace("/[^0-9^\.]/","",$waiveOrig);
		$waiveEdit=isset($_POST["txtWArrEdit"])?strip_tags($_POST["txtWArrEdit"]):0;	$waiveEdit=preg_replace("/[^0-9^\.]/","",$waiveEdit); $diff=$waiveEdit-$waiveOrig;
		//Misc A/C amount Changes
		$marr=isset($_POST["txtMArr"])?strip_tags($_POST["txtMArr"]):0;					$marr=preg_replace("/[^0-9^\.]/","",$arr);
		$mwaiveOrig=isset($_POST["txtWMArr"])?strip_tags($_POST["txtWMArr"]):0;			$mwaiveOrig=preg_replace("/[^0-9^\.]/","",$mwaiveOrig);
		$mwaiveEdit=isset($_POST["txtWMArrEdit"])?strip_tags($_POST["txtWMArrEdit"]):0;	$mwaiveEdit=preg_replace("/[^0-9^\.]/","",$mwaiveEdit);	$mdiff=$mwaiveEdit-$mwaiveOrig;
		$ttl=$waiveEdit+$mwaiveEdit;	$sql="";
		if (strlen($rmks)>10){
			$sql.="UPDATE arrears_waive SET arr_waived='$waiveEdit',misc_waived='$mwaiveEdit',amt_waived='$ttl',rmks='$rmks' WHERE admno LIKE '$info[0]' and curr_year LIKE '$info[1]';";
			if ($info[2]==0) $sql.="UPDATE form SET bbf=bbf-$diff,miscbf=miscbf-$mdiff,alumniarrears=alumniarrears-$diff-$mdiff WHERE admno LIKE '$info[0]' and curr_year LIKE '$info[1]';";
			else $sql.="UPDATE form SET alumniarrears=alumniarrears-$diff-$mdiff WHERE admno LIKE '$info[0]' and curr_year LIKE '$info[1]';";
			mysqli_multi_query($conn,$sql); $i=mysqli_affected_rows($conn);
		} else $i=0;	header("location:waive_arrears.php?action=1-$i");
	}elseif(isset($_POST['cmdDel'])){
	 	$info=isset($_POST['txtData'])?strip_tags($_POST['txtData']):"0-0-0"; 
		$info=preg_split('/\-/',$info); //0 - admission number, 1 no of forms entered and [2] 0 for continuing and 1 for alumni
		$rmks=isset($_POST['txtCancelRmks'])?mysqli_real_escape_string($conn,strtoupper(strip_tags($_POST['txtCancelRmks']))):"";
		$waiveOrig=isset($_POST["txtWArr"])?strip_tags($_POST["txtWArr"]):0;			$waiveOrig=preg_replace("/[^0-9^\.]/","",$waiveOrig);
		$mwaiveOrig=isset($_POST["txtWMArr"])?strip_tags($_POST["txtWMArr"]):0;			$mwaiveOrig=preg_replace("/[^0-9^\.]/","",$mwaiveOrig);
		if (strlen($rmks)>10){
			$sql.="UPDATE arrears_waive SET delreason='$rmks',markdel=1 WHERE admno LIKE '$info[0]' and curr_year LIKE '$info[1]';";
			if ($info[2]==0) $sql.="UPDATE form SET bbf=bbf+$waiveOrig, miscbf=miscbf+$mwaiveOrig, alumniarrears=alumniarrears+$waiveOrig+$mwaiveOrig WHERE admno LIKE '$info[0]' and 
			curr_year LIKE '$info[1]';";
			else $sql.="UPDATE form SET alumniarrears=alumniarrears+$waiveOrig+$mwaiveOrig WHERE admno LIKE '$info[0]' and curr_year LIKE '$info[1]';";
			mysqli_multi_query($conn,$sql); $i=mysqli_affected_rows($conn);
		}else $i=0; header("location:waive_arrears.php?action=2-$i");
	}else{
		$info=isset($_REQUEST['admno'])?strip_tags($_REQUEST['admno']):"0-2016-0"; 
		$info=preg_split('/\-/',$info); //0 - admission number, 1 year and [2] 0 for continuing students and 1 for alumni
		if ($info[2]==0) $sql="SELECT w.waivedon,concat(a.surname,' ',a.onames) as stud_names,concat(sf.form,'-', sf.stream) as frm,w.curr_year,w.arr_waived,w.misc_waived,w.amt_waived,
		w.rmks,sf.miscbf,sf.bbf FROM stud a Inner Join form sf USING (admno) INNER JOIN arrears_waive w On (sf.admno=w.admno and sf.curr_year=w.curr_year) WHERE sf.admno LIKE '$info[0]' 
		AND sf.curr_year LIKE '$info[1]'";
		else $sql="SELECT w.waivedon,concat(a.surname,' ',a.onames) as stud_names,concat(sf.form,'-', sf.stream) as frm,w.curr_year,w.arr_waived,w.misc_waived,
		w.amt_waived,w.rmks,0,sf.alumniarrears FROM stud a Inner Join form sf USING (admno) INNER JOIN arrears_waive w On (sf.admno=w.admno and sf.curr_year=w.curr_year) WHERE sf.admno 
		LIKE '$info[0]' AND sf.curr_year LIKE '$info[1]'";
		$rsStud=mysqli_query($conn,$sql);	$stud=mysqli_fetch_row($rsStud); mysqli_free_result($rsStud);
	}
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<link href="../date/tcal.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<script type="text/javascript" src="../date/tcal.js"></script>
	<script type="text/javascript" src="tpl/waivecont.js"></script>
</head>
<body background="../gen_img/bg3.gif">
	<form method="post" action="waive_arrears_edit.php" onsubmit="return onSubmitVerify(this);" name="frmWaive">
	<BR><BR><table cellpadding="4" cellspacing="3" border="0" align="center"><tr><td colspan="4" style="background-color:#000;font-weight:bold;font-size:12pt;letter-spacing:4px;
	word-spacing:6px;text-align:center;color:#0e0;">EDITING OF THE FEE ARREARS WAIVED</td></tr>
	<?php	
		print "<tr><td align=\"right\">Adm. No.</td><td style=\"font-weight:bold;letter-spacing:2px;word-spacing:3px;\">$info[0] <u>$stud[1]</u></td><td align=\"right\">Form</td><td>
		$stud[2]</td></tr><tr><td align=\"right\">Waived on</td><td>".date('D d M, Y',strtotime($stud[0]))."</td><td align=\"right\">Arrears for FY</td><td>$stud[3]</td></tr><tr><td 
		colspan=\"4\"><hr></td></tr>";
		print "<tr><td align=\"right\" valign=\"top\">Waive Narration</td><td colspan=\"3\"><textarea cols=\"70\" rows=\"3\" name=\"txtRmks\" id=\"txtRmks\" maxlength=\"200\" 
		style=\"letter-spacing:2px;word-spacing:3px;text-transform:uppercase;color:#00f;\" required>$stud[7]</textarea></td></tr>";
		print "<tr><td colspan=\"4\"><input name=\"txtData\" type=\"hidden\" value=\"$info[0]-$info[1]-$info[2]\">";
		print "<table cellpadding=\"2\" width=\"100%\" border=\"1\" style=\"border-collapse:collapse;font-size:10pt;\"><tr style=\"background-color:#666;color:#fff;font-weight:bold;
		letter-spacing:4px;word-spacing:8px;\"><th colspan=\"7\">DETAILS OF AMOUNT OF ARREARS WAIVED</th></tr><tr style=\"background-color:#999;color:#fff;font-weight:bold;
		letter-spacing:1px;word-spacing:2px;\"><th rowspan=\"2\"></th><th colspan=\"3\">Miscelleneous A/C</th><th colspan=\"3\">Main Account</th></tr><tr style=\"background-color:#999;
		color:#fff;font-weight:bold;letter-spacing:1px;word-spacing:2px;\"><th>Arrears</th><th>Waived</th><th>Edit Amt</th><th>Arrears</th><th>Waived</th><th>Edit Amt</th></tr>";		
		print "<tr><td>FY$info[1]</td><td><input type=\"text\" name=\"txtMArr\" id=\"txtMArr\" size=\"8\" value=\"".number_format(($stud[5]+$stud[8]),2)."\" readonly 
		style=\"text-align:right;background-color:#ddd;border:0px;\"></td><td><input type=\"text\" name=\"txtWMArr\" id=\"txtWMArr\" size=\"8\" value=\"".number_format($stud[5],2)."\" 
		style=\"text-align:right;background-color:#ddd;border:0px;\"></td><td><input type=\"text\" name=\"txtWMArrEdit\" id=\"txtWMArrEdit\" size=\"8\" value=\"".number_format($stud[5],2).
		"\" ".(($stud[5]+$stud[8])>0?"":"readonly")." style=\"text-align:right;color:#00f;\" required onkeyup=\"checkInput(this)\"></td>";
		print "<td><input type=\"text\" name=\"txtArr\" id=\"txtArr\" size=\"8\" value=\"".number_format(($stud[4]+$stud[9]),2)."\" readonly style=\"text-align:right;background-color:#ddd;
		border:0px;\"></td><td><input type=\"text\" name=\"txtWArr\" id=\"txtWArr\" size=\"8\" value=\"".number_format($stud[4],2)."\" style=\"text-align:right;background-color:#ddd;
		border:0px;\"></td><td><input type=\"text\" name=\"txtWArrEdit\" id=\"txtWArrEdit\" size=\"8\" value=\"".number_format($stud[4],2)."\" ".(($stud[4]+$stud[9])>0?"":"readonly")." 
		style=\"text-align:right;color:#00f;\" required onkeyup=\"checkInput(this)\"></td></tr>";
		print "</table></td></tr><tr><td colspan=\"4\"><hr></td></tr>";
		print "<tr><td colspan=\"2\" align=\"center\"><button name=\"cmdSave\" type=\"submit\">Save Waive Record</Button></td><td align=\"right\" colspan=\"2\"><a 
		href=\"waive_arrears.php?action=0-0\"><button name=\"cmdClose\" type=\"button\">Cancel/ Close</Button></a></td></tr><tr><td colspan=\"4\"><hr></td></tr>";
		print "<tr style=\"background-color:#ddd;color:#f00;font-weight:bold;letter-spacing:6px;word-spacing:9px;text-align:center;text-decoration:underline;font-size:11pt;\"><td 
		colspan=\"4\">CANCELLATION OF THE WAIVE</td></tr><tr><td align=\"right\" valign=\"top\">Cancel Narration</td><td colspan=\"3\"><textarea cols=\"70\" rows=\"3\" 
		name=\"txtCancelRmks\" id=\"txtCancelRmks\" maxlength=\"200\" style=\"letter-spacing:2px;word-spacing:3px;text-transform:uppercase;color:#00f;\" 
		placeholder=\"Reason for cancelling the arrears waive\"></textarea></td></tr>";
		print "<tr><td colspan=\"4\"><hr></td></tr><tr><td colspan=\"2\" align=\"center\"><button type=\"submit\" name=\"cmdDel\">Cancel the Waive</button></td><td colspan=\"2\" 
		align=\"right\"><a href=\"waive_arrears.php?action=0-0\"><button name=\"cmdClose\" type=\"button\">Cancel/ Close</Button></a></td></tr>";
		print"</table>";
		mysqli_close($conn);
	?>
	</form>
</body></html>