<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else{
		include_once('../conn/pri_sch_connect.inc');
		$dat=isset($_REQUEST['adm'])?$_REQUEST['adm']:"0-0-0"; 	$dat=preg_split('/\-/',$dat);
		$rsCo=mysqli_query($conn,"SELECT lvlname,t1tui,t1board,t1act,t1ltt,t1rmi,t1ewc,t1exam,t1adm,t1lib,t1med,t1pemol,t1olevies,maint1,(t2tui-t1tui) as tui2,(t2board-
		t1board) as boa2,(t2act-t1act) as act2, (t2ltt-t1ltt) as ltt2,(t2rmi-t1rmi) as rmi2,(t2ewc-t1ewc) as ewc2,(t2exam-t1exam)as exa2,(t2adm-t1adm) as adm2,
		(t2lib-t1lib) as lib2,(t2med-t1med) as med2,(t2pemol-t1pemol) as pem2,(t2olevies-t1olevies) as ole2,(maint2-maint1) as ttl2,(tui-t2tui) as tui3,(board-
		t2board) as boa3,(act-t2act) as act3, (ltt-t2ltt) as ltt3,(rmi-t2rmi) as rmi3,(ewc-t2ewc) as ewc3,(exam-t2exam)as exa3,(adm-t2adm) as adm3,(lib-t2lib) as 
		lib3,(med-t2med) as med3,(pemol-t2pemol) as pem3,(olevies-t2olevies) as ole3,(maint3-maint2) as ttl3, tui,board,act,ltt,rmi,ewc,exam,adm,lib,med,pemol,
		olevies,maint3 FROM acc_feeoutline f inner join classlvl c Using (lvlno) WHERE curr_year IN (SELECT finyr FROM ss) and feegrp LIKE '$dat[1]' and f.lvlno LIKE '$dat[2]'");
		//fetch fee data from database
		if (mysqli_num_rows($rsCo)>0) list($lvl, $t1tui,$t1boa,$t1act,$t1ltt,$t1rmi,$t1ewc,$t1exa,$t1adm,$t1lib,$t1med,$t1pem,$t1ole,$t1,$t2tui,$t2boa,$t2act,$t2ltt,
		$t2rmi,$t2ewc,$t2exa,$t2adm,$t2lib,$t2med,$t2pem,$t2ole,$t2,$t3tui,$t3boa,$t3act,$t3ltt,$t3rmi,$t3ewc,$t3exa,$t3adm,$t3lib,$t3med,$t3pem,$t3ole,$t3,$tui,
		$boa,$act,$ltt,$rmi,$ewc,$exa,$adm,$lib,$med,$pem,$ole,$yt)=mysqli_fetch_row($rsCo); 	mysqli_free_result($rsCo);
	}
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Fee Structure</title>
</head>
<body background="img/bg3.gif">
	<?php
		$h= "Fees Structure Definition";
		print "<center><h2>".strtoupper($h)."</h2></center><hr>";
		print "<table cellspacing=\"0\" cellpadding=\"4\" border=\"1\" bordercolor=\"#cccccc\" align=\"center\"><tr><td colspan=\"5\" ALIGN=\"CENTER\"><b>
		MAIN ACCOUNT FEE STRUCTURE</b></td></tr><tr><td colspan=\"5\" align=\"left\">-<br>$dat[0] $lvl Fee Structure Of $dat[1] Pupils<br>-</td></tr>";
		print "<tr bgcolor=\"#eeeeee\"><td><b>Votehead</b></td><td align=\"center\"><b>Term I</b></td><td align=\"center\"><b>Term II</b></td><td 
		align=\"center\"><b>Term III</b></td><td align=\"center\"><b>Total</b></td></tr>";
		print "<tr><td>Tuition</td><td align=\"right\">".number_format($t1tui,2)."</td><td align=\"right\">".number_format($t2tui,2)."</td><td 
		align=\"right\">".number_format($t3tui,2)."</td><td align=\"right\">".number_format($tui,2)."</td><tr>";
		print "<tr><td>Boarding &amp; Meals</td><td align=\"right\">".number_format($t1boa,2)."</td><td align=\"right\">".number_format($t2boa,2)."</td><td 
		align=\"right\">".number_format($t3boa,2)."</td><td align=\"right\">".number_format($boa,2)."</td></tr>";
		print "<tr><td>Activity</td><td align=\"right\">".number_format($t1act,2)."</td><td align=\"right\">".number_format($t2act,2)."</td><td 
		align=\"right\">".number_format($t3act,2)."</td><td align=\"right\">".number_format($act,2)."</td><tr>";
		print "<tr><td>L . T &amp; T</td><td align=\"right\">".number_format($t1ltt,2)."</td><td align=\"right\">".number_format($t2ltt,2)."</td><td 
		align=\"right\">".number_format($t3ltt,2)."</td><td align=\"right\">".number_format($ltt,2)."</td><tr>";
		print "<tr><td>R . M . I</td><td align=\"right\">".number_format($t1rmi,2)."</td><td align=\"right\">".number_format($t2rmi,2)."</td><td 
		align=\"right\">".number_format($t3rmi,2)."</td><td align=\"right\">".number_format($rmi,2)."</td><tr>";
		//row six
		print "<tr><td>E . W . C</td><td align=\"right\">".number_format($t1ewc,2)."</td><td align=\"right\">".number_format($t2ewc,2)."</td><td 
		align=\"right\">".number_format($t3ewc,2)."</td><td align=\"right\">".number_format($ewc,2)."</td><tr>";
		print "<tr><td>Examination/ CATs</td><td align=\"right\">".number_format($t1exa,2)."</td><td align=\"right\">".number_format($t2exa,2)."</td><td 
		align=\"right\">".number_format($t3exa,2)."</td><td align=\"right\">".number_format($exa,2)."</td></tr>";
		print "<tr><td>Administrative Costs</td><td align=\"right\">".number_format($t1adm,2)."</td><td align=\"right\">".number_format($t2adm,2)."</td><td 
		align=\"right\">".number_format($t3adm,2)."</td><td align=\"right\">".number_format($adm,2)."</td></tr>";
		print "<tr><td>Library</td><td align=\"right\">".number_format($t1lib,2)."</td><td align=\"right\">".number_format($t2lib,2)."</td><td 
		align=\"right\">".number_format($t3lib,2)."</td><td align=\"right\">".number_format($lib,2)."</td></tr>";
		print "<tr><td>Medical</td><td align=\"right\">".number_format($t1med,2)."</td><td align=\"right\">".number_format($t2med,2)."</td><td 
		align=\"right\">".number_format($t3med,2)."</td><td align=\"right\">".number_format($med,2)."</td></tr>";
		//row 11
		print "<tr><td>Personal Emolument</td><td align=\"right\">".number_format($t1pem,2)."</td><td align=\"right\">".number_format($t2pem,2)."</td><td 
		align=\"right\">".number_format($t3pem,2)."</td><td align=\"right\">".number_format($pem,2)."</td></tr>";
		print "<tr><td>Other Levies</td><td align=\"right\">".number_format($t1ole,2)."</td><td align=\"right\">".number_format($t2ole,2)."</td><td 
		align=\"right\">".number_format($t3ole,2)."</td><td align=\"right\">".number_format($ole,2)."</td></tr>";
		print "<tr><td>Total Fees</td><td align=\"right\">".number_format($t1,2)."</td><td align=\"right\">".number_format($t2,2)."</td><td align=\"right\">
		".number_format($t3,2)."</td><td align=\"right\">".number_format($yt,2)."</td></tr>";
		mysqli_close($conn);
	?></table><center><br><a href="feestruct.php"><b>BACK</b></a></center>
</body>
</html>