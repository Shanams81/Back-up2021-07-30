<?php
    include_once('shanam.php');
    $action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
    mysqli_multi_query($conn,"SELECT finyr FROM ss; SELECT g.aluadd, g.aluedit, a.feeadd,a.feeedit, g.aluview FROM gen_priv g Inner Join acc_priv a USING (uname) WHERE g.uname LIKE '".$_SESSION['username']."';
    SELECT clsno FROM classnames ORDER BY clsno DESC LIMIT 0,1;") or die(mysqli_error($conn)); $i=$canadd=$canedit=$fee=$feeedit=$canviu=$clsno=0;  $form="";
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){list($yr)=mysqli_fetch_row($rs); $yr=isset($yr)?$yr:date('Y');}elseif($i==1) list($canadd,$canedit,$fee,$feeedit,$canviu)=mysqli_fetch_row($rs);
        else list($clsno)=mysqli_fetch_row($rs);  mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
    //feedbacks
    if ($canviu==0) header("Location:vague.php"); $year=isset($_POST['cboYear'])?sanitize($_POST['cboYear']):"%"; $fr=isset($_POST['cboForm'])?sanitize($_POST['cboForm']):'%';
    $st=isset($_REQUEST['cboStream'])?sanitize($_REQUEST['cboStream']): "%";
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css"/>', $action[0], $action[1], 2);
?><div class="head"><form method="post" action="alumni.php"><a href="pupil_manager.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;
<?php
    print "Show <SELECT name=\"cboYear\" id=\"cboYear\" size=\"1\"><option value=\"%\">All</option>";
    mysqli_multi_query($conn,"SELECT DISTINCT curr_year FROM stud WHERE curr_year<$yr ORDER BY curr_year DESC; SELECT c.clsno,concat(l.lvlname,' - ',c.clsname) as cls FROM classnames c Inner Join classlvl l USING (lvlno)
    ORDER BY clsno ASC; SELECT strm FROM grps WHERE strm is not null;") or die(mysqli_error($conn).". Click <a href=\"alumni.php\">HERE</a> to try again."); $i=0;
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){if (mysqli_num_rows($rs)>0) while (list($y)=mysqli_fetch_row($rs)) print "<option value=\"$y\" ".($y==$year?"SELECTED":"").">$y</option>";
          print "</select> Form <select name=\"cboForm\" id=\"cboForm\" size=\"1\" id=\"form\"><option selected value=\"%\">All</option>";
        }elseif($i==1){if (mysqli_num_rows($rs)>0){while (list($cls,$clsn)=mysqli_fetch_row($rs)){print "<option value=\"$cls\">$clsn</option>"; if($cls==$fr) $form=$clsn;}}
          print "</SELECT>-<select name=\"cboStream\" id=\"cboStream\" size=\"1\" id=\"stream\"><option selected value=\"%\">All</option>";
        }else{if (mysqli_num_rows($rs)>0) while (list($strm)=mysqli_fetch_row($rs)) print "<option value=\"$strm\" ".(strcasecmp($strm,$st)==0?"Selected":"").">$strm</option>";} mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
    print "</select>Alumni &nbsp;&nbsp;&nbsp;&nbsp;<button type=\"submit\" name=\"Stud\">Show Alumni</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type=\"submit\" name=\"cmdArrears\">View Recovered
    Arrears</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button name=\"cmdRef\" type=\"submit\">Refunded Refunds</button></form></div>";
    if (isset($_POST['Stud']) || isset($_POST['cmdArrears'])|| isset($_POST['cmdRef'])){
        if (strcmp($fr,"%")==0 && strcmp($st,"%")==0) $h="";  elseif (strcmp($fr,"%")!=0 && strcmp($st,"%")==0)$h="Form $form "; elseif (strcmp($fr,"%")==0 && strcmp($st,"%")!=0)$h="Stream $st "; else $h="Form $fr - $st ";
        $h=((strcasecmp($year,"%")==0)?"All":$year)." ".$h.isset($_POST['Stud'])?" Alumni Arrears' Details Report":(isset($_POST['cmdArrears'])?" Alumni Fee Arrears Recoveries":" Alumni Refund Payments");
    }else $h="LIST OF Alumni in the system";
    print "<h3 style=\"text-align:center;letter-spacing:3px;words-spacing:4px;\">".strtoupper($h)."</h3><div class=\"container\" style=\"width:fit-content;background-color:#ecf4f3;padding:5px;
    border-radius:10px;margin:5px auto;\">";
    if (isset($_POST["cmdArrears"])){
        print "<div class=\"form-row\"><div class=\"col-md-12\" style=\"height:fit-content;border-radius:15px 15px 0 0;border:1px dotted #00A;padding:5px;\"><form action=\"\" method=\"get\"
        name=\"frmFindArr\">Find Arrears By <input type=\"radio\" name=\"optArrFind\" id=\"radArrAdmNo\" value=\"0\" onclick=\"clrArrText()\">Adm. No. <input type=\"radio\" name=\"optArrFind\"
        id=\"radArrRecNo\" checked value=\"1\" onclick=\"clrArrText()\" checked>Receipt No. <input type=\"radio\" name=\"optArrFind\" id=\"radArrNames\" value=\"2\" onclick=\"clrArrText()\">Alumni
        Name <input type=\"text\" size=\"25\" name=\"txtArrFind\" id=\"txtArrFind\" onkeyup=\"myArrFunction()\"  value=\"\" placeholder=\"Type here what to find\"></form></div></div>";
        $sql="SELECT f.recno,i.pytdate,i.pytfrm,i.cheno,i.admno,concat(s.surname,' ',s.onames) as nams,concat(cn.clsname,' ',sf.stream,' (',sf.curr_year,')') as  frm,f.arrears,i.sno FROM stud s "
        . "Inner Join class sf USING (admno,curr_year) Inner Join classnames cn USING (clsno) Inner Join acc_incofee i USING (admno) INNER JOIN acc_incorecno0 f USING (sno) WHERE f.arrears>0 and "
        . "s.curr_year LIKE '$year' and sf.clsno LIKE '$fr' and sf.stream LIKE '$st' and s.type=1 ORDER BY f.recno ASC";
        $rs=mysqli_query($conn,$sql) or die(mysqli_error($conn)); $nor=mysqli_num_rows($rs);
        print "<div class=\"form-row\"><div class=\"col-md-12\" style=\"max-height:580px;overflow-y:scroll;\"><table class=\"table table-striped table-sm table-hover table-bordered\" id=\"arrTable\">
        <thead class=\"thead-dark\"><tr><th>Receipt No.</th><th>Received On</th><th>Adm. No.</th><th>Received From</th><th>Form/Grade</th><th>Mode</th><th>Mode No.</th><th>Amount</th><th>Admin Action
        </th></tr></thead><tbody>"; $ttl=0;
        if ($nor>0){ $i=0;
            while (list($rec,$pd,$pf,$cn,$an,$sn,$fo,$ar,$serialno)=mysqli_fetch_row($rs)){
                $days=(strtotime(date('Y-m-d'))-strtotime($pd))/86400;
                print "<tr><td>$rec</td><td align=\"right\">".date("D d M, Y",strtotime($pd))."</td><td>$an</td><td>$sn</td><td>$fo</td><td>$pf</td><td>$cn</td><td align=\"right\">
                ".number_format($ar,2)."</td><td align=\"center\">".(($days<2 && $feeedit==1)?"<a style=\"background:inherit;\" onclick=\"return canedit($feeedit)\"
                href=\"alumniarrclearance.php?admno=1-$an-$serialno-1\"><img src=\"../gen_img/edit.ico\" width=18 height=16 title=\"Edit\"></a>":"")."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a "
                . "style=\"background:inherit;\" href=\"rpts/receiptcopy.php?recno=$serialno-1-1-0\"><img src=\"../gen_img/print.ico\" width=18 height=16 title=\"Print\"></a></td></tr>";
                $i++; $ttl+=$ar;
            }
        }else print "<tr><td colspan=\"9\">There are arrears recoveries to be displayed</td></tr>";
        print "</tbody><tfoot><tr><td colspan=\"4\" id=\"spArrTotal\" style=\"font-weight:bold;\">$nor Alumni Fee Arrears Recovery Record(s)</td><td align=\"right\" colspan=\"3\"><b>Total
        Recoveries</b></td><td align=\"right\"><b>".number_format($ttl,2)."</b></td><td></td></tr></tfoot></table></div></div></div>";
    }elseif (isset($_POST["cmdRef"])){
        print "<span style=\"height:fit-content;width:100%;border-radius:15px 15px 0px 0px;border:1px dotted #00A;display:block;font-size:10pt;padding:5px;\"><form action=\"\" method=\"get\"
        name=\"frmFindRef\">Find Refunds By <input type=\"radio\" name=\"optRefFind\" id=\"radRefAdmNo\" value=\"0\" onclick=\"clrRefText()\">Adm. No. <input type=\"radio\" name=\"optRefFind\"
        id=\"radRefIDNo\" value=\"1\" onclick=\"clrRefText()\">ID. No. <input type=\"radio\" name=\"optRefFind id=\"radRefVNo\" checked value=\"2\" onclick=\"clrRefText()\" checked>Voucher No.
        <input type=\"radio\" name=\"optRefFind\" id=\"radRefNames\" value=\"3\" onclick=\"clrRefText()\">Alumni Name <input type=\"text\" size=\"25\" name=\"txtRefFind\" id=\"txtRefFind\"
        onkeyup=\"myRefFunction(this)\" value=\"\" placeholder=\"Type here what to find\"></form></span>";
        $sql="SELECT e.vono,a.admno,p.idno,p.payee,p.telno,e.pytdate,e.pytfrm, e.cheno,(e.caamt+e.chamt) as ref,e.expno FROM acc_arrrefclr a Inner JOIN acc_exp e ON (a.recno=e.vono and
        a.ac=e.acc) Inner Join acc_exppayee p On (e.expno=p.payno) WHERE a.transtype=1 and a.MarkDel=0 and e.markdel=0 ORDER BY e.vono ASC";
        $rs=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rs);
        print "<table class=\"table table-striped table-sm table-hover table-bordered\" id=\"refTable\"><thead class=\"thead-dark\"><tr><th>Voucher No.</th><th>Refunded On</th><th>ID No.</th><th>Adm. No.</th>
        <th>Names of Alumni</th><th>Tel No.</th><th>Mode</th><th>Mode No.</th><th>Amount</th><th>Admin Action</th></tr></thead><tbody>"; $ttl=0;
        if ($nor>0){
            while (list($vno,$admno,$idno,$payee,$telno,$refon,$mode,$modeno,$amt,$expno)=mysqli_fetch_row($rs)){
                $days=(strtotime(date('Y-m-d'))-strtotime($refon))/86400;
                print"<tr><td>$vno</td><td align=\"right\">".date("D d M, Y",strtotime($refon))."</td><td>$idno</td><td>$admno</td><td>$payee</td><td>$telno</td><td>$mode</td><td>$modeno</td><td
                align=\"right\">".number_format($amt,2)."</td><td align=\"center\">".(($days<2 && $feeedit==1)?"<a style=\"background:inherit;\" onclick=\"return canedit($feeedit)\"
                href=\"refunded.php?ref=1-$admno-$vno\"><img src=\"../gen_img/edit.ico\" width=18 height=16 title=\"Edit\"></a>":"")."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a "
                . "style=\"background:inherit;\" href=\"rpts/pv.php?action=$vno-5-$expno-1\"><img src=\"../gen_img/print.ico\" width=18 height=16 title=\"Print\"></a></td></tr>";
                $ttl+=$amt;
            }
        }else print "<tr><td colspan=\"10\">There are refunds in the selected criteria</td></tr>";
        print "</tbody><tfoot class=\"thead-light\"><tr><td colspan=\"4\" id=\"spRefTotal\" style=\"font-weight:bold;\">$nor Fee Refund Record(s)</td><td align=\"right\" colspan=\"4\"><b>Total Refunds</b></td><td "
        . "align=\"right\"><b>".number_format($ttl,2)."</b></td><td></td></tr></tfoot></table></div>";
    }else{
        $sql="SELECT s.admno,s.nemisno,concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname,'-',f.stream,'-',f.curr_year) As frm,s.telno,s.admdate,t.arr,t.ref,f.clsno FROM stud s Inner Join class f USING
        (admno,curr_year) Inner Join classnames c USING (clsno) Inner Join (SELECT admno,sum(alumniarrears) as arr,sum(alumniref) as ref From class group by admno)t using (admno) WHERE s.type=1 and s.curr_year LIKE
        '$year' and s.type=1 and f.clsno LIKE '$fr' and f.stream LIKE '$st' Order By s.admno Asc";
        $rsStud=mysqli_query($conn, $sql) or die(mysqli_error($conn). ". Click <a href=\"alumni.php\">HERE</a> to try again.");
        print "<span style=\"height:fit-content;width:100%;border-radius:15px 15px 0px 0px;border:1px dotted #00A;display:block;font-size:10pt;padding:5px;\"><form action=\"\" method=\"get\"
        name=\"frmFind\">Find Alumni By <input type=\"radio\" name=\"optFind\" id=\"radAdmNo\" checked value=\"0\" onclick=\"clrText()\">Adm. No. <input type=\"radio\" name=\"optFind\"
        id=\"radNEMISNo\" checked value=\"1\" onclick=\"clrText()\">NEMIS No. <input type=\"radio\" name=\"optFind\" id=\"radNames\" value=\"2\" onclick=\"clrText()\">Name <input type=\"text\"
        size=\"25\" name=\"txtFind\" id=\"txtFind\" onkeyup=\"myFunction()\"  value=\"\" placeholder=\"Type here what to find\"> <a href=\"alumniadd.php?admno=0-0\" style=\"float:right;\">
        <button type=\"button\" name=\"cmdAdd\" ".(($canadd==0)?"Disabled":"")." style=\"background-color:#0c0;\">Register Alumni</button></a></button></form></span>";
        print "<div style=\"max-height:600px;overflow-y:scroll;width:fit-content;\"><table class=\"table table-striped table-sm table-hover table-bordered\" id=\"myTable\"><thead class=\"thead-dark\"><tr><th
        colspan=\"6\">STUDENTS' DETAILS</th><th colspan=\"2\">ARREARS &amp; REFUNDS B/F</th><th rowspan=\"2\" colspan=\"2\">Admin Action</th></tr><tr><th>Adm. No.</th><th>NEMIS No.</th><th>Names</th><th>Form</th><th>
        Tel. No.</th><th>Admitted On</th><th>Arrears</th><th>Refunds</th></tr></thead><tbody>";
        $arr=$ref=$type=$amt=0; //type=0 -Arrears and 1 Refunds, amt is amount of either arrears or refunds
        if (mysqli_num_rows($rsStud)>0){
          while ($rsS=mysqli_fetch_array($rsStud,MYSQLI_ASSOC)):
            print "<tr>";  $amt=$a=0;
            foreach($rsS as $sr){
              if($a<8){ if ($a<5){if ($a==0) $admno=$sr;   print "<td>".$sr."</td>";}elseif ($a==5){ print "<td>".date("D, d-F-Y",strtotime($sr))."</td>";
                }else{ if ($a==6){if($sr>0){$arr+=$sr; $amt=$sr; $type=0;}} else {if($sr>0){$ref+=$sr; $amt=$sr; $type=1;}} print "<td align=\"right\">".number_format($sr,2)."</td>";}
              }$a++;
            }print "<td align=\"center\">".(($amt>0)?"<a onclick=\"return canadd($fee)\"  href=\"".($type==0?"alumniarrclearance.php?admno=0-$admno-0-0\" title=\"Receive Arrears\">&#128188;&#128188;</a>":
            "refunded.php?ref=0-$admno-0\" title=\"Clear Refund\">&#128184;&#128184;</a>"):"")."</td><td align=\"center\"><a onclick=\"return canedit($canedit)\" href=\"alumniadd.php?admno=1-$admno\" title=\"Edit\">
            &#128395;&#128697;</a></td></tr>";
          endwhile;
        } print "</tbody><tfoot class=\"thead-light\"><tr><td colspan=\"4\" align=\"left\" class=\"b\">".mysqli_num_rows($rsStud)." Alumni Record(s)</td><td colspan=\"2\" align=\"right\" class=\"b\">Arrears Subtotals "
        . "(Kshs.)</td><td align=\"right\" class=\"b\">".number_format($arr,2)."</td><td align=\"right\"><b>".number_format($ref,2)."</b></td><td></td></tr></tfoot></table></div>";
        mysqli_free_result($rsStud);
    }print "</div><script type=\"text/javascript\" src=\"tpl/js/stud-find.js\"></script><script type=\"text/javascript\" src=\"tpl/js/alumni.js\"></script>";
    mysqli_close($conn); footer();
?>
