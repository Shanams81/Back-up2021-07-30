<?php
	declare(strict_types=1); 	include_once('shanam.php');
	if (isset($_POST['newwithdraw'])){header ("Location:banking.php?tno=0-0-0"); exit(0);
	}else{
		$action=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):"0-0"; $action=preg_split('/\-/',$action);
		$sdate=isset($_POST['dtpStart'])?sanitize($_POST['dtpStart']):date("d-m-Y",strtotime("-30days"));		$edate=isset($_POST['dtpEnd']) ? $_POST['dtpEnd']:date("d-m-Y");
		$sdate=preg_split("/\-/",$sdate); $sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];				$edate=preg_split("/\-/",$edate); $edate=$edate[2].'-'.$edate[1].'-'.$edate[0];
		$ac=isset($_POST['cboAc'])?sanitize($_POST['cboAc']):"%";						$type=isset($_POST['cboType'])?sanitize($_POST['cboType']):"%";
		mysqli_multi_query($conn,"SELECT withdrawals,bankedit,bankdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT acno,abbr FROM acc_voteacs WHERE markdel=0 ORDER BY
		acno ASC;"); $withd=$edit=$del=$i=0;	 $optac='';$acname='All A/cs';
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){ if(mysqli_num_rows($rs)>0) list($withd,$edit,$del)=mysqli_fetch_row($rs);
				}else{while($d=mysqli_fetch_row($rs)){$optac.="<option value=\"$d[0]\" ".($d[0]==$ac?"selected":"").">$d[1]</option>"; if($d[0]==$ac) $acname=$d[1];}
				}mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn)); if($withd==0){header("location:vague.php"); exit(0);}
		$h=($type=="%"?"All Transactions":($type==1?"Cash Debits":"Cash Credits"))." Made Between ".date("D d F Y",strtotime($sdate))." and ".date("D d F Y",strtotime($edate)). " on $acname";
		mysqli_multi_query($conn,"SELECT c.cfno,c.cfdate,v.abbr,concat(if(c.cftype=0,'CREDIT FROM ','CASH PAYMENT TO '),if(c.transtype=0,'FEES',if(c.transtype=1,'BANK WITHDRAWAL',
		if(c.transtype=2,'PAYEES',if(c.transtype=3,'IMPREST',if(c.transtype=4,'SALARY',if(c.transtype=5,'SALARY ADVANCE','BURSARY'))))))) as ti,c.rmks,c.amt FROM acc_cashflow c INNER JOIN
		acc_voteacs v ON (c.acc=v.acno) WHERE c.markdel=0 and	c.cftype LIKE '$type' and (c.cfdate between	'".date('Y-m-d',strtotime($sdate))."' and '".date('Y-m-d',strtotime($edate))."')
		and c.acc like '$ac' ORDER BY cfno ASC; SELECT v.descr,(a.cashbalbf+if(isnull(b.amt),0,b.amt)) as amt FROM acc_votebalbf a Inner Join acc_voteacs v ON (a.acc=v.acno) Left Join
		(SELECT acc,(sum(if(cftype=0,amt,0))-sum(if(cftype=1,amt,0))) as amt FROM `acc_cashflow` GROUP BY acc,markdel HAVING markdel=0)b USING (acc) GROUP BY a.acc,a.cashbalbf ORDER BY
		a.acc ASC;");
	}headings('<link rel="stylesheet" href="/date/tcal.css"><link rel="stylesheet" href="tpl/css/headers.css"><link rel="stylesheet" href="tpl/css/cashflow.css">',$action[0],$action[1],2);
?>
<div class="head"><form action="cashflow.php" method="POST"><a href="withdrawborrow.php"><img src="/gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>
	&nbsp;View <SELECT size="1" name="cboType"><option value="%" <?php echo ($type=="%"?"selected":"");?>>All Transactions</option><option value="1" <?php echo ($type=="1"?"selected":"");?>>
	Cash Debits</option><option value="0" <?php echo ($type=="0"?"selected":"");?>>Cash Credits</option></SELECT> <label for"dtpStart">Made Between </label><input name="dtpStart" class="tcal"
	type="text" value="<?php echo date('d-m-Y', strtotime($sdate));?>" readonly size="9">&nbsp;<label for="dtpEnd">&nbsp;And &nbsp;</label><input name="dtpEnd" class="tcal" type="text"
	value="<?php echo date('d-m-Y', strtotime($edate));?>" readonly size="9"> <label for="ac"> On </label> <SELECT name="cboAc" size="1" id="cboAc"><option value="%" <?php
	echo ($ac=="%"?"selected":"");?>>All A/Cs</option><?php echo $optac;?></select>&nbsp;&nbsp;&nbsp; <button name="Show">Show Transactions</button></form>
</div><div class="container" id="print_content" style="width:fit-content;margin:0 auto;background-color:#e6e6e6;border-radius:10px 10px 0 0;">
	<div class="form-row"><div class="col-md-12"><h5><?php echo strtoupper($h);?></h5></DIV></DIV>
	<div class="form-row"><div class="col-md-12" style="max-height:400px;overflow-y:scroll"><table class="table table-bordered table-sm	table-striped table-hover"><thead class="thead-dark"><tr><th>#</th>
		<th>Date</th><th>Account</th><th>Type of Transaction</th><th>Narrative</th><th>Amount</th></tr></thead><tbody>
		<?php $nor=$i=$ttl=$cttl=$bttl=0;  $optcash=$optbank='';
		do{
			if($rs=mysqli_store_result($conn)){
				if ($i==0){$nor=mysqli_num_rows($rs); if ($nor==0)print "<tr><td colspan=\"6\">No Cash at Hand Transaction records are available</td></tr>";
					else{ $c=1;	while (list($cfno,$cfda,$cfac,$type,$crmks,$cfam)=mysqli_fetch_row($rs)){print "<tr><td>$c</td><td align=\"right\">".date("D d M, Y",strtotime($cfda))."</td><td>
						$cfac</td><td>$type</td><td>$crmks</td><td	align=\"right\">".number_format(floatval($cfam),2)."</td></tr>";	$ttl+=$cfam; $c++;}
					}
				}else{$c=1; while($d=mysqli_fetch_row($rs)){$optcash.="<div class=\"form-row rline\"><div class=\"col-md-1\">$c</div><div class=\"col-md-7\">$d[0]</div><div class=\"col-md-4
					aright\">".number_format(floatval($d[1]),2)."</div></DIV>"; $cttl+=floatval($d[1]); $c++;}
				}mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn));
		print "</tbody><tfoot class=\"thead-light\"><tr><th colspan=\"3\" id=\"tdNOC\">$nor Cash at Hand Transaction Record(s)</th><th style=\"text-align:right\" colspan=\"2\">Total Cash
		Amount Transacted</th><th colspan=\"2\"	id=\"tdCTtl\" style=\"text-align:right\">".number_format($ttl,2)."</th></tr>";
		?></tfoot></table></div>
	</div><div class="form-row"><div class="col-md-12 title">CASH AT HAND BALANCE AS ON <?php echo strtoupper(date("D d M, Y")." AT ".date("H:i:s")); ?></DIV></DIV>
	<div class="form-row"><div class="col-md-6 maindiv"><!-- Cash at Hand Balance -->
		<div class="form-row"><div class="col-md-12 stitle">CASH AT HAND</div></div>
		<div class="form-row rline"><div class="col-md-1 rhead">#</div><div class="col-md-7 rhead">VOTEHEAD ACCOUNT</div><div class="col-md-4 aright rhead">BALANCE</div></DIV>
		<?php echo $optcash;?><div class="form-row"><div class="col-md-8 aright stitle">TOTAL CASH AT HAND</div><div class="col-md-4 aright stitle"><?php	echo number_format($cttl,2);?>
		</div></div>
	</div><div class="col-md-6 maindiv"></div></div>
	<div class="form-row"><div class="col-md-12" style="text-align:right"><br><img src="/gen_img/print.ico" height="25" width="25" onclick="Clickheretoprint()">Print</div></div>
</div><script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/printthis.js"></script>
<?php mysqli_close($conn); footer();?>
