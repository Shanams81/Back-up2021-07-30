<?php
	session_start();
	if (!(isset($_SEESION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else {
		include_once('../conn/mysqli_connect.inc.tpl');
		$action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
		$rsStf=mysqli_query($conn,"SELECT saladvwaive FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'"); $waiv=0;
		if(mysqli_num_rows($rsStf)==1) list($waiv)=mysqli_fetch_row($rsStf);	mysqli_free_result($rsStf);
		if($waiv==0) header("location:vague.php");
		$idno=isset($_REQUEST['txtIDNo']) ? strip_tags($_REQUEST['txtIDNo']):"%"; $idno=strlen($idno)==0?"%":$idno;
	}
?>
<html>
<head>
	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Salary Manager</title>
	<script type="text/javascript" src="tpl/actionmessage.js"></script>
</head>
<body background="../gen_img/bg3.gif" <?php print "onload=\"actiondone($action[0],$action[1])\"";?>>
	<center><form method="post" action="waive_Advance.php">
		<a href="waivers.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp; Find Member of Staff of ID No.</label>&nbsp;<input type="text" 
		maxlength="10" size="11" name="txtIDNo" id="idno" value="%"> &nbsp;&nbsp;<button type="submit" name="cmdShow">Salary Advance Defaulter</button> &nbsp;&nbsp;<button type="submit" 
		name="cmdShowWaive">Waived Salary Advances</button>
	</form></center>
	<hr><h3>
	<?php
		if (isset($_POST['cmdShow'])) $h="Salary Advance Defaulters"; elseif (isset($_POST['cmdShowWaive'])) $h="Waived Salary Advances"; else $h= "Salary Advance Waivers - User Manuals";
		print "<h2 style=\"word-spacing:3px;letter-spacing:2px;text-align:center;\">".strtoupper($h)."</h2>";
	?></h3>
	<hr>
</body>
</html>
<?php
if (isset($_POST['cmdShow'])):
	$rsAdvDef=mysqli_query($conn,"SELECT a.`advno`,s.`idno`,concat(s.surname,' ',s.onames) as `st_names`,s.designation,a.`adv_date`,concat(a.duration,' Month(s)') as dur,a.`amt`,
	a.`amtperduration`,IF(Sum(c.`amt_clr`) Is Null,0,Sum(c.`amt_clr`)) AS SumofAmtCleared,(a.`amt`-IF(Sum(c.`amt_clr`) Is Null,0,Sum(c.`amt_clr`))) AS Balance,a.rmks FROM stf s 
	INNER JOIN (`Acc_Adv` a LEFT JOIN `Acc_AdvClr` c ON a.`advno` = c.`advano`) ON s.`idno` = a.`idno` GROUP BY s.`idno`,s.surname,s.onames,a.`adv_date`,a.`advno`,a.`amtperduration`,
	a.`amt`,a.rmks,a.duration HAVING (((a.`amt`-IF(Sum(c.`amt_clr`) Is Null,0,Sum(c.`amt_clr`)))>0) and (s.`idno` LIKE '$idno')) Order By a.advno Asc");
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\" align=\"center\"><tr align=\"middle\"><th rowspan=\"2\">Advance<br>No.</th><th colspan=\"3\">Staff Member's Details</th>
	<th colspan=\"2\">Advance Details</th><th colspan=\"4\">Salary Advance Amount</th><th rowspan=\"2\" bgcolor=\"#eeeeee\">Reason for the Salary Advance</th><th rowspan=\"2\">Admin<br>
	Action</th></tr><tr bgcolor=\"#eeeeee\"><th>ID. No.</th><th>Names</th><th>Designation</th><th>Issued On</th><th>Recovered In<th>Amount</th><th>Deduction/Month</th><th>Cleared</th><th>
	Balance</th></tr>";
	$ttl=array(0,0,0,0); $i=0;
	if (mysqli_num_rows($rsAdvDef)>0):
		while ($res=mysqli_fetch_array($rsAdvDef,MYSQLI_NUM)):
			if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
			$ai=0;
			foreach($res as $rse){
				if (($ai<4) || ($ai==10) || ($ai==5)):
					if ($ai==0) $adno=$rse;
					print "<td>".$rse."</td>";
				elseif ($ai==4):
					$rse=date("D, d-F-Y",strtotime($rse));
					print "<td>".$rse."</td>";
				else:
					$rse=(float)$rse;
					$ttl[($ai-6)]+=$rse;
					print "<td align=\"right\">".number_format($rse,2)."</td>";
				endif;	
				$ai++;
			}
			print "<td align=\"center\"><a href=\"Waive_Adv.php?id=0-$adno-%\">Waive</a></td></tr>"; $i++;
		endwhile;
	endif;
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\" class=\"b\">".mysqli_num_rows($rsAdvDef)." Salary Advance Defaulters</td><td align=\"right\" class=\"b\" colspan=\"2\">
	Advance's Subtotals (Kshs.)</td>";
	foreach($ttl as $t) print "<td align=\"right\" class=\"b\">".number_format($t,2)."</td>";
	print "<td align=\"middle\" colspan=\"2\"></td></tr></table><br><center>Report Generated on ".date("l F d, Y")."</center>";
	mysqli_free_result($rsAdvDef);
elseif (isset($_POST['cmdShowWaive'])):
	$rsWaiv=mysqli_query($conn,"SELECT a.advno,s.idno,concat(s.surname,' ',s.onames) as st_names,a.adv_date,concat(a.duration,' Month(s)') as dur,a.amt,w.waiveno,w.waivedon,w.amt_waived,
	w.rmks FROM stf s INNER JOIN Acc_Adv a USING (idno) Inner Join acc_advwaive w On (a.advno=w.advno) WHERE w.markdel=0 and s.idno LIKE '$idno' ORDER BY a.advno ASC");
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\" align=\"center\"><tr align=\"middle\" style=\"word-spacing:4px;letter-spacing:2px;\"><th colspan=\"6\">SALARY ADVANCE 
	DETAILS</th><th colspan=\"3\">ADVANCE WAIVE DETAILS</th><th rowspan=\"2\">Admin<br>Action</th></tr><tr bgcolor=\"#eeeeee\"><th>Adv. No.</th><th>ID. No.</th><th>Names</th><th>Issued On
	</th><th>Recovered In<th>Amount</th><th>Waived On</th><th>Waive Remarks</th><th>Amount</th></tr>";
	$i=0; $tadamt=0; $twamt=0; $nr=mysqli_num_rows($rsWaiv);
	if ($nr>0){
		while (list($advno,$id,$nam,$addate,$dur,$adamt,$wano,$waon,$wamt,$rmk)=mysqli_fetch_row($rsWaiv)){
			if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
			print "<td>$advno</td><td>$id</td><td>$nam</td><td align=\"right\">".date("D d M, Y",strtotime($addate))."</td><td>$dur</td><td align=\"right\">".number_format($adamt,2).
			"</td><td align=\"right\">".date("D d M, Y",strtotime($waon))."</td><td>$rmk</td><td align=\"right\">".number_format($wamt,2)."</td><td align=\"center\"><a 
			href=\"Waive_Adv.php?id=1-$advno-$wano\">Edit</a></td></tr>";
			$i++; $tadamt+=$adamt;	$twamt+=$wamt;
		}
	}else print "<tr><td colspan=\"10\">.<br>There are no salary advance waivers/ pardons registered in the system<br>.</td></tr>";
	print "<tr><td colspan=\"3\">$nr Salary Advance Waiver(s)</td><td colspan=\"2\" align=\"right\">Total Amount</td><td align=\"right\">".number_format($tadamt,2)."</td><td colspan=2><td 
	align=\"right\">".number_format($twamt,2)."</td><td></td></tr></table><br><center>Report Generated on ".date("l F d, Y")."</center>";
	mysqli_free_result($rsWaiv);
else:
	print "<b><u>Viewing Issued Salary Advances</u></b><ol type=\"a\"><li>Select the <b>Month</b> whose advances is to be viewed,<li>Or select <b>All</b> to view 
	all year's salary advances. Leave, or<li>Enter ID. No. to view respective individual member's salary advances.<li>Click <b>Salary Advance</b> button.</ol>";
endif;
mysqli_close($conn);
?>