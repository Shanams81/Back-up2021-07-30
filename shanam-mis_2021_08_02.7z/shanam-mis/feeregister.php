<?php
	include_once('shanam.php');		include_once('tpl/funcs.tpl');
	$cls=isset($_POST['cboCls'])?sanitize($_POST['cboCls']):1;	$strm=isset($_POST['cboStream'])?sanitize($_POST['cboStream']):"%";
	$admno=isset($_POST['txtAdm'])?sanitize($_POST['txtAdm']):"%"; 	$admno=strlen($admno)==0?"%":$admno;	$acc=isset($_POST['cboAcc'])?trim(strip_tags($_POST['cboAcc'])):1;
	if(isset($_POST['btnRegPDF'])){header("location:pdf/feeregpdf.php?rec=$cls-$strm-$admno-$acc"); exit(0);}
	if(isset($_POST['btnRegXLS'])){header("location:xls/xlsfeereg.php?rec=$cls-$strm-$admno-$acc"); exit(0);}
	mysqli_multi_query($conn,"SELECT finyr,scnm,scadd FROM ss; SELECT clsno,clsname FROM classnames; SELECT strm FROM grps WHERE strm is not null or strm not like ''; SELECT acno,abbr
	FROM acc_voteacs WHERE stud_assoc=1 and markdel=0");
	$i=0; $optcls=$optstrm=$optacc=$accname="";
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){if(mysqli_num_rows($rs)==1) list($yr,$scnm,$scadd)=mysqli_fetch_row($rs); else $yr=date('Y');}
			elseif($i==1)	while (list($clsno,$clsname)=mysqli_fetch_row($rs)) $optcls.="<option value=\"$clsno\" ".($cls==$clsno?"selected":"").">$clsname</option>";
			elseif($i==2) while (list($st)=mysqli_fetch_row($rs)) $optstrm.="<option value=\"$st\" ".(strcasecmp($strm,$st)==0?"selected":"").">$st</option>";
			else while($d=mysqli_fetch_row($rs)){$optacc.="<option value=\"$d[0]\" ".($d[0]==$acc?"selected":"").">$d[1]</option>";if($d[0]==$acc) $accname=$d[1];}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link href="tpl/css/headers.css" rel="stylesheet" /><link href="tpl/accprint.css" rel="stylesheet" media="print" /><link rel="stylesheet" href="tpl/css/modalfrm.css"/>
	<link href="tpl/css/spinner.css" rel="stylesheet" /><style>table.h,td.h,th.h{border:0}table.s,td.s,th.s{border:1px solid #00f;font-size:0.8rem;}td.r,th.r{text-align:right !important;}
	td.b{font-weight:bold}</style>',0,0,2);
?><div class="head"><form method="post" action="feeregister.php" onsubmit="document.querySelector('#busyWait').style.display='block'">View <SELECT name="cboAcc" id="cboAcc" size="1">
<?php echo $optacc;?></SELECT> Fee Registers of Form/Grade &nbsp;<select name="cboCls" size="1" id="Class"><?php echo $optcls;?></select>-<select name="cboStream" size="1" id="stream">
<?php echo $optstrm;?></select>&nbsp;&nbsp;<label for="ta"> or for Admission No.</label><input name="txtAdm" type="text" maxlength="7" size="7" value="%">&nbsp;&nbsp;&nbsp; <button
type="submit" accesskey="F" name="btnReg">Show Fee Register</button>&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="P" name="btnRegPDF">PDF Fee Register</button>&nbsp;&nbsp;&nbsp;
<button type="submit" accesskey="X" name="btnRegXLS">Spreadsheet Fee Register</button></form></div>
<?php
if (isset($_POST["btnReg"])){
	$sql="SELECT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,";
	if ($acc==1) $sql.="(c.bbf+if(isnull(f.arr),0,f.arr)) as arr,if(x.acspemed=1,(c.spemed+if(isnull(f.smed),0,f.smed)),0) as spemed,if(x.acunifrm=1,(c.unifrm+if(isnull(f.suni),0,f.suni)),
		0)	as uni FROM stud s Inner Join class c USING (admno,curr_year) Inner	Join classnames cn USING (clsno) Inner Join ss ON (s.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,
		sum(f.arrears) as arr,sum(f.spemed) as smed,sum(f.unifrm) as suni FROM acc_incofee i Inner Join acc_incorecno0 f ";
	else $sql.="(c.miscbf+if(isnull(f.arr),0,f.arr)) as arr,if(x.acspemed!=1,(c.spemed+if(isnull(f.smed),0,f.smed)),0) as spemed,if(x.acunifrm!=1,(c.unifrm+if(isnull(f.suni),0,f.suni)),0)
		as uni FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) Inner Join ss ON (s.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,sum(f.arrears)
		as arr,sum(f.spemed) as smed, sum(f.unifrm)	as suni FROM acc_incofee i Inner Join acc_incorecno1 f ";
	if(strcasecmp($admno,"%")==0)$sql.="USING (sno) GROUP BY i.admno,f.markdel Having f.markdel LIKE '0')f USING (admno),(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,
	sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM acc_votesassigned)x WHERE c.clsno LIKE '$cls' and c.stream LIKE '$strm' and s.present=1";
	else $sql.="USING (sno) GROUP BY i.admno,f.markdel Having i.admno LIKE '$admno' and f.markdel LIKE '0')f USING (admno),(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,
	sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM acc_votesassigned)x WHERE s.admno LIKE '$admno' and s.present=1";
	$rsStud=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"home.php\">HERE</a> to go back.");
	if (mysqli_num_rows($rsStud)>0){
		while (list($admno,$names,$cls,$arr,$spemed,$uni)=mysqli_fetch_row($rsStud)){
			$rs=mysqli_query($conn,"SELECT v.sno,v.abbr FROM clsfee f Inner Join acc_votes v ON (f.voteno=v.sno) Inner Join ss s ON (f.curr_year=s.finyr) WHERE f.admno='$admno' and v.acc='$acc'
			ORDER BY v.sno ASC;"); $f=$paid=$cols=''; $novotes=0;
			while ($row=mysqli_fetch_row($rs)){
				$f.= ",SUM(IF(voteno='$row[0]', f.t3, 0)) as `$row[1]` "; $paid.= ",SUM(IF(v.voteno='$row[0]', v.amt, 0)) as `{$row[1]}` "; $cols.='<th class="s">'.$row[1].'</th>';
				$ttl[]=0; $bal[]=0; $novotes++;
			}mysqli_free_result($rs); $rs=mysqli_query($conn,"SELECT admno $f FROM clsfee f Inner Join ss s ON (f.curr_year=s.finyr) GROUP BY admno,curr_year HAVING f.admno LIKE '$admno'");
			$fee=mysqli_fetch_row($rs); mysqli_free_result($rs);
			print "<div style=\"background-color:#ddd;width:fit-content;margin:5px auto;border-radius:10px\"><div id=\"$admno\"><table class=\"table table-sm h\"><tr><th rowspan=\"3\"
			valign=\"middle\" width=\"80\" class=\"h\"  style=\"border-bottom:2px solid #000\"><img	src=\"/gen_img/logo.jpg\" width=\"60\" height=\"70\" vspace=\"1\" hspace=\"1\"></th><th
			style=\"font-size:12pt;text-align:left;\" class=\"h\" colspan=2>$scnm</th></tr><tr><th style=\"font-size:12pt;text-align:left;\" class=\"h\" colspan=2>$scadd</th></tr><tr><th
			class=\"h\" style=\"font-size:12px;border-bottom:2px solid #000;text-align:left;\">$accname FEES REGISTER</th><th class=\"h\" style=\"font-size:10px;border-bottom:2px solid #000;
			text-align:right;\" width=\"180\">Printed On ".date("D d M,Y")."</th></tr><tr><td colspan=\"3\"><br><p style=\"letter-spacing:1px;font-size:12pt;word-spacing:2px;font-weight:bold;\">
			Adm. No. $admno - <u>$names</u>	in Form/Grade $cls. <u><i>Fee Register As On ".date('D d M,Y')."</i></u></p>";
			print "<table class=\"table table-sm s\"><thead><tr><th class=\"s\">RECEIPT</th><th class=\"s\">DATE</th><th class=\"s\">MODE</th><th class=\"s\">MODE NO.</th><th
			class=\"s\">ARREARS</th>".($spemed>0?"<th class=\"s\">S/ MED</th>":"").($uni>0?"<th class=\"s\">X/ UNIF</th>":"").$cols.($acc==1?"<th class=\"s\">PREPAID</th>
			<th class=\"s\">REFUNDS</th>":"")."<th class=\"s\">BC</th><th class=\"s\">TOTAL</th><th class=\"s\">Balance</th></tr>";
			print "<tr><td colspan=\"4\" class=\"s r b\">Fees Expected As On 01, January $yr</td><td class=\"s r b\">".number_format($arr,2)."</td>".($spemed>0?("<td class=\"s r b\">".
			number_format($spemed,2)."</td>"):"").($uni>0?("<td class=\"s r b\">".number_format($uni,2)."</td>"):""); $i=0; $ttlfee=$arr+$spemed+$uni;
			foreach($fee as $amt){if($i>0){print "<td class=\"s r b\">".number_format($amt,2)."</td>"; $bal[$i-1]=$amt; $ttlfee+=$amt;}$i++;}
			if($acc==1) print "<td class=\"r s b\">0.00</td><td class=\"r s b\">0.00</td>";
			print "<td class=\"r s b\">0.00</td><td class=\"s r b\">".number_format($ttlfee,2)."</td><td class=\"s r b\">".number_format($ttlfee,2)."</td></tr>";
			$sql="SELECT f.recno,i.pytdate,i.pytfrm,i.cheno,f.arrears,f.spemed,f.unifrm $paid,";
			if($acc==1) $sql.="f.prep,f.refunds,f.bc,(f.amt-f.transfer) as ttl FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY
			f.recno,i.pytdate,i.pytfrm,i.cheno,f.arrears,f.spemed,f.unifrm,f.amt,f.transfer,f.prep,f.refunds,i.markdel,i.admno ";
			else $sql="f.bc,(f.amt-f.transfer) as ttl FROM acc_incofee i Inner Join acc_incorecno1 f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY f.recno,i.pytdate,i.pytfrm,
			i.cheno,f.arrears,f.spemed,f.unifrm,f.amt,f.transfer,i.markdel,i.admno ";
			$sql.="HAVING i.markdel=0 and i.admno LIKE '$admno' ORDER BY f.recno ASC";
			$rs=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"home.php\">HERE</a> to go back.");$tarr=$tprep=$tref=$tuni=$tsmed=$tpaid=$tbc=0; $nof=mysqli_num_rows($rs);
			if($nof>0){while($da=mysqli_fetch_row($rs)){$i=$a=$b=0; print "<tr>";
				foreach($da as $rec){
					if($i<5){if($i==1){print "<td class=\"r s\">".date('d-M-Y',strtotime($rec))."</td>";}elseif($i==4){print "<td class=\"s r\">".number_format($rec,2)."</td>";$arr-=$rec; $tarr+=$rec;}
						else print "<td class=\"s\">$rec</td>";
					}elseif($i<7){if($i==5 && $spemed>0){print "<td class=\"s r\">".number_format($rec,2)."</td>";$spemed-=$rec; $tsmed+=$rec;}
						elseif($i==6 && $uni>0){print "<td class=\"s r\">".number_format($rec,2)."</td>";$uni-=$rec; $tuni+=$rec;}
					}else{if($i<($novotes+7)){ print "<td class=\"s r\">".number_format($rec,2)."</td>";$bal[$i-7]-=$rec;$ttl[$i-7]+=$rec;
						}else{if($acc==1 && $i<($novotes+2)){print "<td class=\"s r\">".number_format($rec,2)."</td>"; if($a==0) $prep+=$rec; else $ref+=$rec; $a++;}
						else{print "<td class=\"s r b\">".number_format($rec,2)."</td>"; if($b==0)$tbc+=$rec; else $ttlfee-=$rec; $tpaid+=$rec; $b++;}}
					}	$i++;
				}print "<td class=\"s r b\">".number_format($ttlfee,2)."</td></tr>";}
			}else	print "<tr><td class=\"s b\" colspan=\"".($acc==1?($novotes+8):($novotes+6))."\">This student has not paid fee this year</td></tr>";
			print "<tr><td class=\"s b\" colspan=3>$nof Fee Payment Installment(s)</td><td class=\"b r s\">Total Paid</td><td class=\"s r b\">".number_format($tarr,2)."</td>";
			if($tsmed>0 || $spemed>0) print "<td class=\"s r b\">".number_format($tsmed,2)."</td>"; if($tuni>0 || $uni>0) print "<td class=\"s r b\">".number_format($tuni,2)."</td>";
			foreach($ttl as $tt) print "<td class=\"s r b\">".number_format($tt,2)."</td>";
			if($acc==1) print "<td class=\"s r b\">".number_format($tprep,2)."</td><td class=\"s r b\">".number_format($tref,2)."</td>";
			print "<td class=\"s r b\">".number_format($tbc,2)."</td><td class=\"s r b\">".number_format($tpaid,2)."</td><td class=\"s r b\">".number_format($ttlfee,2)."</td></tr><tr><td
			class=\"s r b\" colspan=4>Fee Balance</td><td	class=\"s r b\">".number_format($arr,2)."</td>";
			if($tsmed>0 || $spemed>0) print "<td class=\"s r b\">".number_format($spemed,2)."</td>"; if($tuni>0 || $uni>0) print "<td class=\"s r b\">".number_format($uni,2)."</td>";
			foreach($bal as $tt) print "<td class=\"s r b\">".number_format($tt,2)."</td>";
			print "<td class=\"s\" colspan=\"".($acc==1?5:3)."\"></td></tr></table></td></tr></table></div>";
			print "<div style=\"text-align:right\"><span style=\"float:left;font-weight:bold;\"><u>KEY:</u>BC- BANK CHARGES, S/MED - SURCHARGED MEDICAL, X/UNIF - EXTRA UNIFORM</span>
			<a href=\"javascript:printSpecific($admno)\"><img src=\"/gen_img/print.ico\" height=\"30\" width=\"30\"></a></div></div>"; mysqli_free_result($rs); unset($ttl);unset($bal);
		}
	}else print "<H1>NO STUDENT RECORD FOUND</H1>"; mysqli_free_result($rsStud);
}else{
	$h= "<font color=\"#0000ff\">".date("D d-M-Y")." - Fees Register Manual (Please Read)";
	print "<h3>".strtoupper($h)."</h3></center></font>";
	print "<p class=\"g\">With this interface, you can view both main fee register and miscellaneous fee registers. Fees register shows
	student's fee payment installments as distributed to respective voteheads. To view this report: <ol style=\"a\"><li>Select the form
	and stream whose students' register is to be viewed and <li>Click either <b>Main Fee Register</b> or <b>Misc Fee Register</b> button
	to view Main Account Fees Register or Miscellaneous Account Fees Register respectively.</ol></p>";
	print "<p class=\"g\">To view a student's fee register, enter student's admission number and click on respective type of register to
	be viewed.</p>";
}print "<div id=\"busyWait\" class=\"modal\" onclick=\"document.querySelector('#busyWait').style.display='none'\"><div class=\"loader\"></div></div><script type=\"text/javascript\"
src=\"tpl/js/printthis.js\"></script>";
mysqli_close($conn);footer();
?>
