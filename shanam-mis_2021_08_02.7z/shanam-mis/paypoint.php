<?php
	include_once('/conn/pri_sch_connect.inc');
	include_once('/mpdf/mpdf.php');
	$dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0-0-0";
	$dat=preg_split("/\-/",$dat);	//0 - Month, 1 - Year, 2 - Bank	and 3 - Cheque number
	$h=strtoupper($dat[0].'-'.$dat[1].' Salary');
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,mission,motto FROM ss");
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mis,$mot)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	//start pdf file
	$mpdf=new mPDF('c','A4','','',10,10,12,12,10,10);
	$mpdf->useOnlyCoreFonts = true;    // false is default
	$mpdf->SetWatermarkText("$dat[0]-$dat[1] Salaries");
	$mpdf->showWatermarkText = true;
	$mpdf->watermark_font = 'DejaVuSansCondensed';
	$mpdf->watermarkTextAlpha = 0.1;
	$mpdf->SetDisplayMode('fullpage');
	$mpdf->setFooter('Page {PAGENO} of {nbpg} Pages');
	$html='<html><head><title>'.$dat[0].' - '.$dat[1].' Payroll</title><style>
			table.hide {border:0px;collapse;font-size:12px;font-weight:bold;letter-spacing:2px;word-spacing:3px;}
			td.hide,th.hide{border:0px;}
			table.gen,td,th {border:1px solid blue;border-collapse:collapse;font-weight:normal;font-size:12px;}
			p{font-size:12px;line-spacing:6pt;}
			</style></head><body>';
	$dat[2]=trim($dat[2]);
	$html.='<table cellspacing="0" width="100%" class="hide"><tr><td rowspan="3" valign="middle" width="90" align="center" class="hide"><img
	src="img/logo.png" width="70" height="80" vspace="1" hspace="1"></td><td class="hide">'.$scnm.'</td></tr><tr><td class="hide">'.$scadd.'
	</td></tr><tr><td class="hide">'.$mot.'</td></tr><tr><td colspan="2" class="hide"><hr><b style="font-size:12px;">'.$h.'</b>&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Printed On:'.date("D d-M-Y").'<hr></td></tr></table>';
	$html.='<p>THE MANAGER,<br>'.$dat[2].' BANK.<br><br>Dear Sir/ Madam,<br>I kindly request you to credit the accounts listed below with the
	respective amounts shown. Attached find cheque 	number '.$dat[3].' showing the total amount of salary for the employees listed.</p>';
	$sql="SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.designation,sd.bankbranch,sd.accountno,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1)-
	(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1)) AS NetSal FROM Stf s INNER JOIN Acc_SalDef sd Using (idno) INNER JOIN
	Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And (sp.sal_year LIKE '$dat[1]') and (sd.bankname LIKE '$dat[2]%') and sp.markdel=0) ORDER BY
	s.surname,s.onames ASC";
	$rsSal=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsSal);
	$html.='<table cellpadding="1" cellspacing="0" class="gen" align="center"><tr bgcolor="#eeeeee"><th>S/N</th><th><b>ID. No.</b></th><th><b>Payroll No.</b></th><th><b>Names</b></th>
	<th><b>Designation</b></th><th><b>Bank Branch</b></th><th><b>Account No.</b></th><th><b>Net Salary</b></th></tr>';
	$tnet=0; $i=0;
	if ($nor>0):
		while (list($id,$pr,$na,$de,$bb,$acno,$net)=mysqli_fetch_row($rsSal)):
			if (($i%2)==0) $html.='<tr>'; else $html.='<tr bgcolor="#eeeeee">';
			$html.='<td>'.($i+1).'</td><td>'.$id.'</td><td>'.$pr.'</td><td>'.$na.'</td><td>'.$de.'</td><td>'.$bb.'</td><td align="right">'.$acno.'</td><td align="right">'.
			number_format($net,2).'</td></tr>';
			$tnet+=$net; 	$i++;
		endwhile;
	else:
		$html.='<tr><td colspan="8">No Salary for '.$dat[0].'-'.$dat[1].'</td></tr>';
	endif;
	$html.='<tr bgcolor="#eeaaaa"><td colspan="4" align="left" class="b"><b>'.$nor.' Staff Members\' Salary</b></td><td colspan="3" align="right"><b>Salary Subtotals</b></td><td
	align="right"><b>'.number_format($tnet,2).'</b></td></tr></table>';
	mysqli_free_result($rsSal);		$rsSal=mysqli_query($conn,"SELECT principal FROM ss"); 	list($princ)=mysqli_fetch_row($rsSal);
	mysqli_free_result($rsSal);
	$html.='<br>Thank you.<br>Yours Faithfully, <br><br><br>_________________________<br>'.$princ.'<br>The Director/Principal';
	$html.='</body></html>';
	$mpdf->WriteHTML($html);
	$mpdf->Output();
	mysqli_close($conn);
?>
