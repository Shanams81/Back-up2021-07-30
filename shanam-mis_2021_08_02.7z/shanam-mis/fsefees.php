<?php
    include_once('shanam.php');
    if(isset($_POST['btnSave'])){
        $tkn=isset($_POST['txtTkn'])?sanitize($_POST['txtTkn']):0;			$recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0;
        $date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('d-m-Y');	$date=preg_split('/\-/',$date);	$date=$date[2].'-'.$date[1].'-'.$date[0];
        $ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;				$tranche=isset($_POST['txtTranchNo'])?sanitize($_POST['txtTranchNo']):0;
        $ben=isset($_POST['txtNOB'])?sanitize($_POST['txtNOB']):0;			$mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'EFT';
        $cheno=isset($_POST['txtCheNo'])?sanitize($_POST['txtCheNo']):null;	$amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0; $cheno=strlen($cheno)>0?$cheno:null;
        $bal=isset($_POST['txtBal'])?sanitize($_POST['txtBal']):0;			$nov=isset($_POST['txtNOV'])?sanitize($_POST['txtNOV']):0;
        $bank=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;		$amt=preg_replace('/[^0-9\.]/','',$amt);	$bal=preg_replace('/[^0-9\.]/','',$bal);
        if($_SESSION['tkn']!=$tkn || $ac==0 || $tranche==0 || $ben==0 || (strcasecmp($mode,'cheque')==0 && strlen($cheno)==0) || $bal!=0 || $amt<1 || $bank==0){
                echo 'FSE Receipt Record has errors. Can not be saved as entered. Click <a href="fsefees.php">HERE</a> to go back.'; unset($_SESSION['tkn']); exit(0);
        }else{
            $sql="INSERT INTO acc_fseincome(recno,noofstud,recon,batchno,acc,acsno,amt,mode,modeno,rmks,addedby) VALUES (0,$ben,'$date','$tranche',$ac,$bank,".($amt*$ben).",'$mode',".
            var_export($cheno,true).",'FSE Fees','".$_SESSION['username']." (".$_SESSION['priviledge'].")')";
            if(mysqli_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fsefees.php">HERE</a> to go back')){
                $recno=mysqli_insert_id($conn); $sql='INSERT INTO acc_fsevotes (recno,acc,voteno,amt) VALUES '; $a=0;
                if($recno>0){
                    for($i=0;$i<$nov;$i++){
                        $v=isset($_POST['txtVote_'.$i])?sanitize($_POST['txtVote_'.$i]):'0-0';	$v=preg_split('/\-/',$v); //[0] Vote No. [1] Acc
                        $bal=isset($_POST['txtBal_'.$i])?sanitize($_POST['txtBal_'.$i]):0;		$bal=preg_replace('/[^0-9\.]/','',$bal);
                        $vamt=isset($_POST['txtVAmt_'.$i])?sanitize($_POST['txtVAmt_'.$i]):0;	$vamt=preg_replace('/[^0-9\.]/','',$vamt);
                        if ($vamt>0){$sql.=($a==0?"":",")."($recno,$v[1],$v[0],".($vamt*$ben).")"; $a++;}
                    }
                }if($a==0) $sql=''; else $sql.=';';
                $sql.="INSERT INTO acc_fseben(recno,acc,admno,amt) SELECT $recno,$ac,admno,$amt FROM stud WHERE markdel=0 and present=1 ORDER BY admno ASC LIMIT 0,$ben; INSERT INTO
                acc_banking(sno,transdate,bank_type,acsno,amt,rmks,transtype,transno,addedby) VALUES(0,'$date',0,$bank,($amt*$ben),'FSE Income',0,$recno,
                '".$_SESSION['username']." (".$_SESSION['priviledge']."');";
                mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fsefees.php">HERE</a> to go back'); $i=0;
                do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $act[1]=($i>0?1:0); $act[0]=1;
            }else{$act[0]=0;$act[1]=0;}
        }
    }else{ $act=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0';	$act=explode('-',$act); }
    mysqli_multi_query($conn,"SELECT gofeeview,gofeeedit,gofeeadd FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT count(admno) from stud GROUP BY markdel,present HAVING
    markdel=0 and present=1; SELECT max(batchno) as bn FROM acc_fseincome GROUP BY acc,markdel,commt HAVING markdel=0 and
    commt=0 and acc IN (SELECT * FROM (SELECT acno FROM acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 ORDER BY acno ASC LIMIT 0,1)e);") or die(mysqli_error($conn).". Click <a "
    . "href=\"fsegrants.php\">HERE</a> to go back.");
    $nostud=$i=$viu=$edit=$add=$tranchno=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){if(mysqli_num_rows($rs)>0) list($viu,$edit,$add)=mysqli_fetch_row($rs);
            }elseif($i==1){if(mysqli_num_rows($rs)>0) list($nostud)=mysqli_fetch_row($rs);
            }else{if(mysqli_num_rows($rs)>0) list($tranchno)=mysqli_fetch_row($rs);}
            mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));	$tranchno++;	$_SESSION['tkn']=$tkn=uniqid();
    if($viu==0) header("location:vague.php");
    $sdate=isset($_POST['dtpStart'])?sanitize($_POST['dtpStart']):(date("Y")."-01-01"); $sdate=preg_split('/\-/',$sdate); 	$sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];
    $edate=isset($_POST['dtpEnd'])?sanitize($_POST['dtpEnd']):date("Y-m-d");			$edate=preg_split('/\-/',$edate); 	$edate=$edate[2].'-'.$edate[1].'-'.$edate[0];
    headings('<link rel="stylesheet" type="text/css" href="tpl/css/headers.css"/><link href="tpl/css/modalfrm.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="/date/tcal.css"/><link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css"/>',$act[0],$act[1],2);
?><div class="head"><form method="post" action="fsefees.php"><a href="fsegrants.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;
FSE Fees Received Between&nbsp; <input name="dtpStart" class="tcal" type="text" value="<?php echo $sdate;?>" readonly size="9">&nbsp; &nbsp; And &nbsp;<input name="dtpEnd" class="tcal"
type="text" value="<?php echo $edate;?>" readonly size="9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s"
name="Show">View FSE Receipts</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" accesskey="r" name="Show" <?php echo ($add==0?"disabled":"");?> onclick="receiveFSE()">Receive
FSE Income</button></a></form></div>
<?php
    $h="FSE Fees Received Between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate));
    print "<h3 style=\"font-size:12pt;color:#fff;font-weight:bold;letter-spacing:3px;word-spacing:4px;text-decoration:underline overline #fff double;margin-top:5px;text-align:center;\">".
    strtoupper($h)."</h3>";
    $sdate=preg_split("/\-/",$sdate); $sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];
    $edate=preg_split("/\-/",$edate); $edate=$edate[2].'-'.$edate[1].'-'.$edate[0]; $optAC="<option value=\"0\" selected>Choose Votehead A/C</option>";
    $sql="SELECT recno,batchno,recon,acc,mode,noofstud,(amt/noofstud) as per,amt FROM acc_fseincome WHERE markdel=0 AND (recon Between '$sdate' And '$edate') and commt=0";
    $rs=mysqli_query($conn,"SELECT acno,descr from acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 and markdel=0 ORDER BY acno ASC;"); $noa=mysqli_num_rows($rs); $sql1=''; $i=0;
    while(list($acno,$name)=mysqli_fetch_row($rs)){
        $sql1.="sum(if(i.acc=$acno,i.acc,0)) as acc$acno,sum(if(i.acc=$acno,i.recno,0)) as rec$acno, sum(if(i.acc=$acno, i.per,0)) as per$acno, sum(if(i.acc=$acno,i.amt,0)) as ttl$acno,";
        $acname[]=$name;	$optAC.="<option value=\"$acno\">$name</option>"; $i++;
    }$sql="SELECT i.batchno,i.recon,i.mode, $sql1 sum(i.per) as pamt,sum(i.amt) as ttl FROM ($sql)i GROUP BY i.batchno,i.mode ORDER BY i.batchno ASC";
    $fee=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    print "<div class=\"container\" style=\"background-color:#f6f6f6;font-size:0.65rem;width:fit-content;border-radius:20px 20px 0 0;\">";
    print "<table class=\"table table-striped table-hover table-sm table-bordered\"><thead class=\"thead-dark\"><tr><th rowspan=2>#</th><th rowspan=2>RECEIVED ON</th><th rowspan=2>MODE
    </th>"; $lbl='<tr>'; $i=0;
    foreach($acname as $a){
        print "<th colspan=3 style=\"letter-spacing:4px;word-spacing:6px;".($i%2==0?"background-color:#777;color:#fff;":"")."\">$a</th>";
        $lbl.='<th '.($i%2==0?'style="background-color:#777;color:#fff;"':'').'">REC</th><th '.($i%2==0?'style="background-color:#777;color:#fff;"':'').'">AMT PER<br>STUDENT</th><th '.
        ($i%2==0?'style="background-color:#777;color:#fff;"':'').'>A/C<BR>LUMPSUM</th>';
        $ttl[]=0; $i++; $ttl[]=0;
    }print "<th colspan=\"2\" style=\"background-color:#1aa6b7;color:#fff;\">TRANCHE TOTAL AMT</th><th rowspan=\"2\">FSE<br>RECEIPT</th></tr>$lbl<th  style=\"background-color:#1aa6b7;
    color:#fff;\">PER<br>STUDENT</th><th  style=\"background-color:#1aa6b7;color:#fff;\">GRAND<br>TOTAL</th></tr></thead><tbody>"; $gttl=[0,0];	$nor=mysqli_num_rows($fee);  $id=uniqid();
    if ($nor>0){
        while ($data=mysqli_fetch_row($fee)):
            print "<tr><td>".$data[0]."</td><td>".date('D d M, Y', strtotime($data[1]))."</td><td>".$data[2]."</td>"; $days=(strtotime(date('Y-m-d'))-strtotime($data[1]))/86400;
            $index=0;   $rec='';   $i=3;
            foreach($acname as $a){ $rec=$data[$i+1].'-'.$data[$i];    $i++;
                print "<td align=\"center\">".($days<4?"<a onclick=\"return canEdit($edit)\" href=\"fsefeerecedit.php?rec=$rec-".$id."\"> &nbsp; $data[$i] &nbsp; </a>":
                "$data[$i]")."</td><td align=\"right\">".number_format($data[$i+1],2)."</td><td align=\"right\">".number_format($data[$i+2],2)."</td>";
                $ttl[$index]+=$data[$i+1];	$ttl[$index+1]+=$data[$i+2];   $i+=3;  $index+=2;
            }print "<td align=\"right\"  style=\"background-color:#1aa6b7;color:#fff;\">".number_format($data[$i],2)."</td><td align=\"right\"  style=\"background-color:#1aa6b7;color:#fff;\">".
            number_format($data[$i+1],2)."</td><td align=\"center\"><a style=\"background:inherit;\"  href=\"pdf/fsereceipt.php?rec=$data[0]\" target=\"_BLANK\"><img
            src=\"../gen_img/print.ico\" width=18 height=16 title=\"Print\"></a></td></tr>";
            $gttl[0]+=$data[$i];  	$gttl[1]+=$data[$i+1];
        endwhile;
    }else{
        print "<tr><td colspan=\"20\"><br>There are no FSE fee receipts</td></tr>";
    } print "</tbody><tfoot><tr><th colspan=\"3\" style=\"text-align:left;\">$nor FSE Tranch(es)</th>";   $i=$count=0;
    foreach($acname as $a){
        print "<th align=\"right\" ".($i%2==0?'style="background-color:#777;color:#fff;"':'').">".($i==0?"TOTAL":"")."</th><th align=\"right\" "
        .($i%2==0?'style="background-color:#777;color:#fff;"':'').">".number_format($ttl[$count],2)."</th><th align=\"right\" ".($i%2==0?'style="background-color:#777;color:#fff;"':'').">"
        .number_format($ttl[$count+1],2)."</th>"; $count+=2; $i++;
    }
    print "<th align=\"right\">".number_format($gttl[0],2)."</th><th align=\"right\">".number_format($gttl[1],2)."</th><td></td></tr></tfoot></table><br><b><u>KEY:</u></b> # - TRANCHE NO.
    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;REC - RECEIPT NO.</div>";
    mysqli_free_result($fee);
?></div>
<div id="FSEIncome" class="modal">
    <div class="imgcontainer"><span onclick="document.getElementById('FSEIncome').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
	   <div class="container" style="background-color:#bbe1fa;border-radius:10px 0;padding:6px;"><form name="frmNewIncome" method="post" action="fsefees.php"
       onsubmit="return validateData(this)"><INPUT name="txtTkn" type="hidden" size=4 value="<?php echo $tkn;?>" id="txtTkn">
      <div class="form-row">
          <div class="col-md-12 divheadings">FREE SECONDARY EDUCATION (FSE) RECEIPT MANAGER</div>
      </div><div class="form-row">
          <div class="col-md-6 divlrborder">
              <div class="form-row">
                  <div class="col-md-12 divsubheading">FSE RECEIPT DETAILS</div>
              </div><div class="form-row">
                  <div class="col-md-6"><label for="txtRecNo">Receipt No. *</label><input type="text" name="txtRecNo" id="txtRecNo" readonly value="" placeholder="Auto"
                    class="modalinput"></div>
                  <div class="col-md-6"><label for="dtpDate">Received On *</label><input type="text" name="dtpDate" id="dtpDate" readonly value="<?php echo date('d-m-Y',
                  strtotime($edate));?>" class="tcal modalinput"></div>
              </div><div class="form-row">
                  <div class="col-md-6"><label for="cboAC">Votehead Account Credited *</label><SELECT name="cboAC" id="cboAC" onchange="loadTranchAC(this)" size=1 class="modalinput">
                    <?php echo $optAC;?></SELECT></div>
                  <div class="col-md-6"><label for="txtTranchNo">Tranche No. *</label><input type="text" name="txtTranchNo" id="txtTranchNo" value="<?php echo $tranchno;?>" readonly
                    class="modalinput"></div>
              </div><div class="form-row">
                  <div class="col-md-6"><label for="txtNOB">No. of Beneficiaries *</label><input type="text" name="txtNOB" id="txtNOB" value="<?php echo number_format($nostud,0);?>"
                  onkeyup="checkData(0,this)" onblur="confirmNo(this)" class="modalinput"></div>
                  <div class="col-md-6"><label for="txtTtlStud">No. of Students *</label><input type="text" name="txtTtlStud" id="txtTtlStud" readonly style="background-color:#bbb;"
                    value="<?php echo number_format($nostud,0);?>" class="modalinput numbersinput"></div>
              </div><div class="form-row">
                  <div class="col-md-6"><label for="cboMode">Mode of Receipt *</label><SELECT name="cboMode" id="cboMode" size=1 onchange="enableTransNo(this)" class="modalinput" size=1>
                    <option value="EFT" selected>E . F . T</option><option value="Cheque">Cheque</option></SELECT></div>
                  <div class="col-md-6"><label for="txtCheNo">Trans/ Cheque No. </label><input type="text" name="txtCheNo" id="txtCheNo" value="" maxlength=15 class="modalinput"></div>
              </div><div class="form-row">
                  <div class="col-md-6"><label for="cboBank">Bank A/C Credited *</label><span id="spBankAC"><SELECT name="cboBank" id="cboBank" size=1 class="modalinput"><option value="0">
                    Choose Bank A/C</option></SELECT></span></div>
                  <div class="col-md-6"><label for="txtAmt">Amount Per Student *</label><input type="text" name="txtAmt" id="txtAmt" value="0.00" maxlength=10 class="modalinput numbersinput"
                    onkeyup="checkData(1,this)" onblur="distributeVotes(this)" size="15"></div>
              </div>
		</div><div class="col-md-6 divlrborder" id="spVotes">
      <div class="form-row"><div class="col-md-12 divsubheading">VOTEHEAD DISTRIBUTION DETAILS</div></div>
      <div class="form-row"><div class="col-md-6 divsubheading">VOTEHEAD</div><div class="col-md-3 divsubheading">BALANCE</div><div class="col-md-3 divsubheading">AMOUNT</div></div>
    <?php
  		$rs=mysqli_query($conn,"SELECT f.voteno,v.acc,v.descr,(f.t3-if(isnull(i.vamt),0,(i.vamt))) as bal FROM acc_votes v INNER JOIN acc_feestruct f ON (v.sno=f.voteno) LEFT JOIN
  		(SELECT v.voteno,sum(v.amt/i.noofstud) as vamt FROM acc_fseincome i INNER JOIN acc_fsevotes v USING (recno,acc) GROUP BY v.acc,v.voteno,v.markdel HAVING v.markdel=0)i using
  		(voteno) WHERE v.acc IN (SELECT * FROM (SELECT acno FROM acc_voteacs WHERE stud_assoc=0 ORDER BY acno ASC LIMIT 0,1)f)"); $nov=mysqli_num_rows($rs); $c=0; $ttl=0;
  		print "<input name=\"txtNOV\" id=\"txtNOV\" type=\"hidden\" value=\"$nov\">";
  		while ($dat=mysqli_fetch_row($rs)){
          echo "<div class=\"form-row\"><div class=\"col-md-6\">$dat[2]<input type=\"hidden\" name=\"txtVote_$c\" id=\"txtVote_$c\" value=\"$dat[0]-$dat[1]\"></div><div class=\"col-md-3\">
          <input type=\"text\" name=\"txtBal_$c\" id=\"txtBal_$c\" value=\"".number_format($dat[3],2)."\" readonly class=\"modalinput numbersinput modalinputdisabled\"></div><div
          class=\"col-md-3\"><input type=\"text\" name=\"txtVAmt_$c\" id=\"txtVAmt_$c\" value=\"0.00\" onkeyup=\"checkData(1,this)\" onchange=\"confirmBal($c)\" class=\"modalinput
          numbersinput\"></div></div>";	$ttl+=$dat[3]; $c++;
  		} echo "<hr><div class=\"form-row\"><div class=\"col-md-6\">TOTAL AMOUNT</div><div class=\"col-md-3\"><input type=\"text\" name=\"txtTtlBal\" id=\"txtTtlBal\" value=\"".
      number_format($ttl,2)."\" readonly class=\"modalinput numbersinput modalinputdisabled\"></div><div class=\"col-md-3\"><input type=\"text\" name=\"txtTtlVAmt\" id=\"txtTtlVAmt\"
      readonly value=\"0.00\" class=\"modalinput numbersinput modalinputdisabled\"></div></div>";	mysqli_free_result($rs);
    ?></div>
  </div><hr><div class="form-row">
      <div class="col-md-12" style="font-size:11pt;font-weight:bold;letter-spacing:5px;word-spacing:6px;padding:5px 1px;text-align:right;">BALANCE TO BE DISTRIBUTED <input type="text"
        name="txtBal" id="txtBal" readonly value="0.00" size=10 class="numbersinput modalinputdisabled"></div>
  </div><hr><div class="form-row">
      <div class="col-md-6"><button type="submit" class="btn btn-block btn-primary btn-md" name="btnSave">Save Changes</button></div>
      <div class="col-md-6" style="text-align:right;"><button type="button" onclick="document.getElementById('FSEIncome').style.display='none'" class="btn btn-info btn-md">Close
      </button></div>
    </div>
    <div class="form-row">
        <div class="col-md-12" id="spDelete"></div>
    </div>
	</div></form>
</div><script type="text/javascript" src="tpl/js/fsefees.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<?php mysqli_close($conn); footer(); ?>
