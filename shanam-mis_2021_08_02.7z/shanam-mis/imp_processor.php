<?php
	session_start();
	include_once("../conn/pri_sch_connect.inc");
	$imp=isset($_REQUEST['impno'])?$_REQUEST['impno']:"0-0"; $imp=preg_split("/\-/",$imp);
	$rsSP=mysqli_query($conn,"SELECT impissue,impdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$impissue=0;	$impdel=0;	list($impissue,$impdel)=mysqli_fetch_row($rsSP);	mysqli_free_result($rsSP);
	if (($imp[1]==0) && ($impissue==1)){//Issuing of imprest
		mysqli_query($conn,"UPDATE acc_imp SET status=1 WHERE impno LIKE '$imp[0]'") or die(mysqli_error($conn)." Click <a href=imprests.php>
		Here</a> to try again!!.");
		$i=mysqli_affected_rows($conn);
		if ($i==1) header("location:pdf/imp_printout.php?impno=$imp[0]"); else header("location:imprests.php");
		exit(0);
	}elseif (($imp[1]==1) && ($impdel==1)){//delete the imprest
		$rs=mysqli_query($conn,"SELECT reqno FROM acc_imp WHERE impno LIKE '$imp[0]'");
		if (mysqli_num_rows($rs)>0) list($reqno)=mysqli_fetch_row($rs);	 mysqli_free_result($rs);
		mysqli_query($conn,"UPDATE acc_imp SET markdel=1,delreason=concat('Imprest cancelled on ',curdate()) WHERE impno LIKE '$imp[0]'") or die(mysqli_error()." Imprest not deleted. CLick <a 
		href=\"imprests.php\">HERE</a> to try again");
		$i=mysqli_affected_rows($conn);
		if ($i==1) mysqli_query($conn,"UPDATE acc_req SET markdel=0,served=0,approved=0 WHERE reqno LIKE '$reqno'") or
		die(mysqli_error()." Imprest not deleted. Click <a href=\"imprests.php\">HERE</a> to try again");
	}
	mysqli_close($conn);
	header("location:imprests.php");
?>
