<?php
	include_once('shanam.php');
	$rsDet=mysqli_query($conn,"SELECT sysdata FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'");	$sys=0;
	if (mysqli_num_rows($rsDet)>0) list($sys)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	$nhifno=isset($_REQUEST['nhif'])?$_REQUEST['nhif']:0;		$act=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; 		$act=preg_split('/\-/',$act);
	headings('<link rel="stylesheet" href="tpl/css/inputsettings.css"/>',$act[0],$act[1],1);
?>
<div class="container divgen"><form method="post" action="nhifbracketsave.php"><div class="form-row"><div class="col-md-12" style="color:#0F3;text-align:center;font-size:12pt;
background-color:#444;font-style:bold;word-spacing:5px;letter-spacing:3px;border-radius:10px 10px 0 0;" colspan="4">N.H.I.F DEDUCTIONS' BRACKETS INTERFACE</div></div>
<div class="form-row"><div class="col-md-4 divsubheading">Salary From</div><div class="col-md-4 divsubheading">Salary To</div><div class="col-md-3 divsubheading"><b>
	NHIF Amount</div><div class="col-md-1 divsubheading">Action</div></div>
<?php
 	$rs=mysqli_query($conn,"SELECT nhifno,lowerbound,upperbound,amount FROM acc_nhifcalc ORDER BY nhifno ASC"); $i=0;
 	while (list($nhif,$lb,$ub,$amt)=mysqli_fetch_row($rs)){
 	 	print "<div class=\"form-row\">";
		if ($nhifno==$nhif) print "<div class=\"col-md-4\"><input name=\"txtNo\" value=\"$i\" type=\"hidden\"><input name=\"txtNHIF_$i\" type=\"hidden\" value=\"$nhif\">
		<input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtLB_$i\" value=\"".number_format($lb,2)."\" style=\"color:#00c;\"></div><div
		class=\"col-md-4\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtUB_$i\" value=\"".number_format($ub,2)."\" style=\"color:#00c;\">
		</div><div class=\"col-md-3\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"10\" name=\"txtAmt_$i\" value=\"".number_format($amt,2)."\"
		style=\"color:#00c;\"></div><div class=\"col-md-1\"><button type=\"submit\" name=\"cmdSave\" style=\"background-color:inherit;\"><img src=\"../gen_img/save.ico\" height=\"20\"
		width=\"20\" title=\"Save\"></button></div>";
		else print "<div class=\"col-md-4\"><input name=\"txtNHIF_$i\" type=\"hidden\" value=\"$nhif\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\"
		name=\"txtLB_$i\"	id=\"txtLB_$i\" readonly value=\"".number_format($lb,2)."\" style=\"background-color:#eee;\"></div><div class=\"col-md-4\"><input type=\"text\"
		class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtUB_$i\" id=\"txtUB_$i\" readonly value=\"".number_format($ub,2)."\" style=\"background-color:#eee;\"></div>
		<div class=\"col-md-3\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtAmt_$i\" id=\"txtAmt_$i\" readonly value=\"".number_format($amt,2)."\"
		style=\"background-color:#eee;\"></div><div class=\"col-md-1\">".($nhifno==0?"<img src=\"../gen_img/edit.ico\" height=\"20\" width=\"20\" title=\"edit\"
		onclick=\"window.open('nhifbrackets.php?nhif=$nhif','_self')\">":"")."</div>";
		print "</div>";
		$i++;
	}
?><hr>
<div class="form-row"><div class="col-md-12" style="text-align:right;"><button type="button" onclick="window.open('settings_manager.php','_self')" name="btnClose" class="btn
btn-info disabled">Close</button></div></div>
</DIV>
<?php mysqli_close($conn);	footer();
