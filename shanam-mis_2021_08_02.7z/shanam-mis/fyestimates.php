<?php
    include_once('shanam.php');
    mysqli_multi_query($conn,"SELECT finyr FROM ss; SELECT budgedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';"); $finyr=date('Y'); $edi=$i=0;
    do{if($rs=mysqli_store_result($conn)){if ($i==0) list($finyr)=mysqli_fetch_row($rs); else list($edi)=mysqli_fetch_row($rs); mysqli_free_result($rs);  }$i++; }while(mysqli_next_result($conn)); $act[0]=$act[1]=0;
    if (isset($_POST['btnSave'])){
        $lmt=isset($_POST['txtAcc'])?sanitize($_POST['txtAcc']):0; 	$sql="";
        for($i=0;$i<$lmt;$i++){ $nvotes=isset($_POST["txtNoVot_$i"])?sanitize($_POST["txtNoVot_$i"]):0;
            for ($a=0;$a<$nvotes;$a++){
              $voteno=isset($_POST["txtVote_$i"."_$a"])?sanitize($_POST["txtVote_$i"."_$a"]):0;  $prevamt=isset($_POST["txtPrev_$i"."_$a"])?sanitize($_POST["txtPrev_$i"."_$a"]):0;
              $curramt=isset($_POST["txtCurr_$i"."_$a"])?sanitize($_POST["txtCurr_$i"."_$a"]):0; $curramt=preg_replace("/[^0-9^\.]/","",$curramt);$prevamt=preg_replace("/[^0-9^\.]/","",$prevamt);
              $sql.='UPDATE acc_fyestimates SET prevest='.$prevamt.', curest='.$curramt.' WHERE finyr LIKE \''.$finyr.'\' and voteno LIKE \''.$voteno.'\';';
            }
        }if (strlen($sql)>0){$i=0; mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)); while (mysqli_next_result($conn)){$i+=mysqli_affected_rows($conn);}  $act[0]=1; $act[1]=$i;}
    }elseif(isset($_POST['btnRefresh'])){
      mysqli_multi_query($conn,"DELETE FROM acc_fyestimates WHERE voteno not in (select sno FROM acc_votes WHERE sno>5 and markdel=0 and abbr Not LIKE 'arrears'); INSERT IGNORE INTO acc_fyestimates SELECT v.sno,ss.finyr,
      0 as pe,0 as ce FROM acc_votes v,ss WHERE sno>5 and markdel=0 and abbr Not LIKE 'arrears'"); $act[0]=1;do{$act[1]=mysqli_affected_rows($conn);}while(mysqli_next_result($conn));
    }
    class fyest{  private $sno,$acc,$vote,$prevest,$curest; function __construct($s,$ac,$v,$p,$c){$this->sno=$s;$this->vote=$v;$this->prevest=$p;$this->curest=$c;$this->acc=$ac;}public function myAcc(){return $this->acc;}
        public function mySNo(){return $this->sno;}public function myVote(){return $this->vote;}public function myPrev(){return $this->prevest;}public function myCur(){return $this->curest;}
    }class Accounts{ private $acc,$descr;function __construct($a,$d){$this->acc=$a;	$this->descr=$d;} public function valAcNo(){return $this->acc;}	public function valAcName(){return $this->descr;} }
    mysqli_multi_query($conn,"INSERT IGNORE INTO acc_fyestimates (voteno,finyr) SELECT sno,$finyr FROM acc_votes WHERE markdel=0 and pyt_defined=1 and sno>5; SELECT acno,
    descr FROM acc_voteacs WHERE markdel=0 ORDER BY acno ASC; SELECT f.voteno,v.acc,v.descr,f.prevest,f.curest,v.acc FROM acc_fyestimates f Inner Join
    acc_votes v On (f.voteno=v.sno) WHERE f.finyr LIKE '$finyr'	ORDER BY v.acc,v.sno ASC;");	$i=$noacs=0;	$lstVotes=[];
    do{
      if($i==0){}else {
        if($rs=mysqli_store_result($conn)){
          if($i==1){while($data=mysqli_fetch_row($rs)){$accounts[]=new Accounts($data[0],$data[1]); 	$noacs++;}
          }else{$nvotes=0; while (list($vno,$acc,$vot,$prev,$cur,$acc)=mysqli_fetch_row($rs)){ $lstVotes[]=new fyest($vno,$acc,$vot,$prev,$cur); $nvotes++; }
          }mysqli_free_result($rs);
        }
      }$i++;
    }while(mysqli_next_result($conn));  headings('<style>td,th{font-size:0.7rem;}input{font-size:0.7rem;}a{color:#ff7;}</style>',$act[0],$act[1],1);
?>
<div class="container-fluid" style="border:1px dashed #fff;border-radius:10px;padding:10px;"><h2 style="font-size:12pt;color:#fff;background-color:#000;letter-spacing:6px;word-spacing:8px;border-radius:10px 10px 0 0;">FY
<?php
  echo $finyr.' ESTIMATES</h2><ul class="nav nav-tabs" id="myTabs">';	$i=0; $tabs=1;
  foreach ($accounts as $acc) {
    if($i%3==0){echo '<li class="nav-item'.($tabs==1?' active':'').'"><a class="nav-link'.($tabs==1?' active':'').'" data-toggle="tab" id="page'.$tabs.'-tab" href="#page'.$tabs.'">PAGE '.$tabs.'</a></li>';$tabs++;}$i++;
  }
?></ul><form method="post" action="fyestimates.php" onsubmit="return validateInput(this,<?php echo "$noacs";?>)"><div class="tab-content" id="myTabContent"> <div id="page1" role="tabpanel" class="tab-pane fade show active"
  aria-labelledby="page1-tab"><input type="hidden" name="txtAcc" id="txtAcc" value="<?php echo $noacs;?>"><div class="row"><div class="col-md-12"><table class="table table-bordered table-responsive table-sm"><thead
  class="thead-dark"><tr>
<?php $i=$tabs=1; $headings=''; $tabno=2;
  foreach ($accounts as $acc){$curr[]=0; $prev[]=0; if($i<4) echo "<th>".$acc->valAcName()." ESTIMATES</th>"; else $headings.="<th>".$acc->valAcName()." ESTIMATES</th>"; $i++;}
  echo "</tr></thead><tbody><tr>";  $i=0;
  foreach($accounts as $acc){$acno=$acc->valAcNo();
    echo "<td valign=\"top\"><table class=\"table table-borderless table-striped table-sm table-hover\" style=\"background-color:#e6e6e6;\"><thead class=\"thead-light\"><tr><th>VOTEHEAD</th><th
    style=\"text-align:center\">".($finyr-1)." ACTUAL</th><th>$finyr ESTIMATE</th></tr></thead><tbody>"; $a=0;
    foreach($lstVotes as $val){
      if($acno==$val->myAcc()){echo "<tr><td><input type=\"hidden\" name=\"txtVote_$i"."_$a\" value=\"".$val->mySNo()."\">".$val->myVote()."</td><td><input type=\"text\" name=\"txtPrev_$i"."_$a\"
          id=\"txtPrev_$i"."_$a\" value=\"".number_format($val->myPrev(),2)."\" style=\"text-align:right;\" ".($edi==0?"readonly":"")." onkeyup=\"checkInput(this)\" onblur=\"mainTtl($i,0)\"></td><td><input
          type=\"text\" name=\"txtCurr_$i"."_$a\" id=\"txtCurr_$i"."_$a\" value=\"".number_format($val->myCur(),2)."\" style=\"text-align:right;\" ".($edi==0?"readonly":"")." onkeyup=\"checkInput(this)\"
          onblur=\"mainTtl($i,1)\"></td></tr>";  $prev[$i]+=$val->myPrev(); 		$curr[$i]+=$val->myCur(); 		$a++;
      }
    }echo "</body><tfoot class=\"thead-dark\"><tr><th>TOTAL ESTIMATE</th><th><input type=\"text\" readonly id=\"txtPrevTtl_$i\" value=\"".number_format($prev[$i],2)."\" style=\"text-align:right;font-weight:bold;\">
    </th><th><input type=\"text\" readonly id=\"txtCurrTtl_$i\" value=\"".number_format($curr[$i],2)."\" style=\"text-align:right;font-weight:bold;\"></th></tr></thead><input type=\"hidden\" name=\"txtNoVot_$i\"
    id=\"txtNoVot_$i\" value=\"$a\"></table></td>";
    if($i==$tabno){  $tabs++;	$tabno+=3; //tabno - allow only 3 accounts each page
      echo "</tbody></tr></table></div></div></div><div id=\"page$tabs\" class=\"tab-pane fade show\" role=\"tabpanel\" aria-labelledby=\"page$tabs-tab\"><div class=\"row\"><div class=\"col-md-12\"><table class=\"table
      table-bordered table-responsive table-sm\"><thead class=\"thead-dark\"><tr>$headings</tr></thead><tbody><tr>";
    }$i++;
  }
?></tr></table></div></div></div>
<div class="row"><div class="col-md-5"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSave" <?php echo ($edi==0?"disabled":"");?>>Save Financial Year Estimates</button></div><div class="col-md-4"
style="text-align:right"><button type="submit" class="btn btn-primary btn-md" name="btnRefresh" <?php echo ($edi==0?"disabled":"");?>>Refresh Voteheads</button></div><div class="col-md-3" style="text-align:right"><button
type="button" class="btn btn-info btn-md" name="btnClose" onclick="window.open('goodsbudg.php','_self')">Cancel/ Close</button></a></div></form><script type="text/javascript" src="tpl/js/fyestimates.js"></script>
<?php mysqli_close($conn); footer(); ?>
