<?php
	declare(strict_types=1);
	include_once('shanam.php');
	mysqli_multi_query($conn,"SELECT finyr FROM ss; SELECT credview,credadd,crededit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';");
	$viu=$add=$edi=$i=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if ($i==0){list($yr)=mysqli_fetch_row($rs);
			}else{list($viu,$add,$edi)=mysqli_fetch_row($rs);
			}mysqli_free_result($rs);
		}$i++;
	}while (mysqli_next_result($conn));
	if (isset($_POST['cmdSave'])){
		$regdate=isset($_POST['txtDate'])?$_POST['txtDate']:date("d-m-Y");			$rdate=preg_split("/\-/",$regdate); $date="$rdate[2]-$rdate[1]-$rdate[0]";
		$supid=isset($_POST['txtSupCode'])?sanitize($_POST['txtSupCode']):"";		$cuyr=isset($_POST['txtYr'])?sanitize($_POST['txtYr']):date('Y');
		$name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName']))):"";		$supid=strlen($supid)==0?null:$supid;
		$telno=isset($_POST['txtTelNo'])?$_POST['txtTelNo']:"";				$telno=strlen($telno)==0?null:$telno;		$un=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		$paddress=isset($_POST['txtAddress'])?strtoupper(sanitize($_POST['txtAddress'])):""; 	$paddress=strlen($paddress)==0?null:$paddress;
		$idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):""; 					$idno=strlen($idno)==0?null:$idno;
		$email=isset($_POST['txtEMail'])?sanitize($_POST['txtEMail']):""; 			$email=filter_var($email,FILTER_VALIDATE_EMAIL)?$email:null;
		if (strlen($name)>7 && strlen($telno)>9 && $cuyr<=$yr){
		 	$sql="INSERT INTO acc_creditors (cred_no,supid,yr,idno,name,telno,paddress,email,regdate,addedby) VALUES (0,".var_export($supid,true).",'$cuyr',
			".var_export($idno,true).",'$name',".var_export($telno,true).",".var_export($paddress,true).",".var_export($email,true).",'$date','$un')";
			mysqli_query($conn,$sql) or die(mysqli_error($conn)." Creditor's record not successfully saved. Click <a href=\"creditors.php\">here</a> to try again.");
			$i=mysqli_affected_rows($conn);	$credno=mysqli_insert_id($conn);
			header("location:creditorsummary.php?recno=$credno-1-$i"); //Open interface for adding credit details
		} else{echo "Creditor record has error(s). Click <a href=\"creditors.php\">HERE</a> to try again";} exit(0);
	}if($viu==0) header("location:vague.php");
	$type=isset($_POST['cboType'])?sanitize($_POST['cboType']):'%';			$ac=isset($_POST['cboAc'])?sanitize($_POST['cboAc']):1;
	$nam=isset($_POST['txtName'])?sanitize($_POST['txtName']):'%';			$nam=strlen($nam)>0?$nam:'%';
	$clr=isset($_POST['cboCleared'])?sanitize($_POST['cboCleared']):0;	$act=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0';	$act=preg_split('/\-/',$act);
	headings('<link href="tpl/css/headers.css" rel="stylesheet" /><link href="tpl/css/modalfrm.css" rel="stylesheet" /><link href="tpl/css/inputsettings.css" rel="stylesheet" />',
	$act[0],$act[1],2);
	$rs=mysqli_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE markdel=0 ORDER BY acno ASC");	$optacc=$accname='';
	if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)){$optacc.="<option value=\"$d[0]\" ".($ac==$d[0]?"selected":"").">$d[1]</option>";if($ac==$d[0]) $accname=$d[1];}
?><div class="head"><Form name="frmCreditors" method="post" action="creditors.php" onsubmit="return validateCreditor(this)">View<SELECT name="cboType" size="1"><option value="%"
	selected>All Creditors</option><option value="0">Sundry Creditors</option><option value="1"><?php echo $yr;?> Creditors</option></SELECT> With <SELECT name="cboCleared" size="1"><option
	value="0" Selected>All</option><option value="1">Balance</option><option value="2">No Balance</option></SELECT> in <SELECT name="cboAc" size="1"><?php echo $optacc;?></SELECT> Account(s)
	&nbsp;&nbsp;&nbsp;<button name="cmdShow" type="submit" class="btn btn-warning btn-md">Show Creditors</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button name="cmdAdd" <?php echo ($add==1?"":
	"disabled");?> class="btn btn-warning btn-md" onclick="document.getElementById('creditorAdd').style.display='block'" type="button">Add New Creditor</button></form>
</div>
<div class="container" style="width:fit-content;margin:0 auto;background-color:#e6e6e6;border-radius:10px 10px 0 0;">
	<div class="form-row"><div class="col-md-12" style="border:0.5px dotted green;border-radius:10px;padding:6px;"><form name="frmFind" action="#" method="post">Find Creditors By
		&nbsp;<input type="radio" name="radFind" id="radCName" value="name" onclick="clrText()" checked>Creditor's Name&nbsp; <input type="radio" name="radFind" id="radTelNo" value="telno"
		onclick="clrText()">Tel No. &nbsp; <input type="radio" name="radFind" id="radVote"	value="votehead" onclick="clrText()">Votehead Costed &nbsp;&nbsp; <input type="text" maxlength="15"
		size="25" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Type what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;"></form></div>
	</div><div class="form-row"><div class="col-md-12">
<?php
	if($type==='0') $sql="d.yr<$yr";	elseif($type==='1') $sql="d.yr=$yr"; 	else $sql="d.yr LIKE '%'";
	$sql="SELECT * FROM (SELECT c.cred_no,c.name,c.telno,c.regdate,a.acno,concat(v.abbr,' (',a.abbr,')') as vote,d.yr,count(d.cred_No) as NC,sum(d.estimatedamt) as estamt,sum(d.estimatedamt
	-d.amt) as paid,sum(d.amt) as balance FROM  acc_creditors c INNER Join acc_creditorsdet d USING (cred_no) Inner Join acc_voteacs a ON (d.acc=a.acNo) Inner Join acc_votes v On
	(d.voteno=v.sno) GROUP BY	c.cred_no,c.name,c.telno,c.regdate,d.yr,d.voteno,d.markdel,d.acc,a.abbr HAVING d.markdel=0 and $sql and d.acc LIKE '$ac')c ";
	$sql.=" WHERE balance".($clr==0?" LIKE '%'":($clr==1?">0":"=0"))." ORDER BY yr,c.name ASC";
	$rs=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"creditors.php\">HERE</a> to go back.");	$no=mysqli_num_rows($rs); 		$ttl=0;
	$h=($type=='%' && $ac=='%')?'list of all creditors':(($type!='%' && $ac=='%')?'All '.($type=='1'?$yr.' Creditors':'Sundry Creditors'):(($type=='%' && $ac!='%')?
	'All Creditors ':($type=='1'?$yr.' Creditors':'Sundry Creditors')));
	$h.=($clr!=0?(' with '.($clr==1?'':'No').' Commitment Balance'):'').' In '.$accname; 	print "<h5 align=\"center\"><u>".strtoupper($h)."</u></h5></div></div>";
?><div class="form-row"><div class="col-md-12" style="max-height:700px;overflow-y:scroll;font-size:0.9rem;"><table class="table table-striped table-bordered table-hover table-sm">
<thead class="thead-dark"><tr style="letter-spacing:1px;word-spacing:3px;"><th>REGISTERED<br>ON</th><th>NAME</th><th>TEL. NO.</th><th>VOTEHEAD</th>
<th>YEAR</th><th>NO. OF<BR>COMM'T</th><th>ESTIMATED<br>COST</th><th>PAID OUT</th><th>BALANCE</th><th colspan="2">ADMIN ACTIONS</th></tr></thead>
<?php	$gest=$gpaid=$gbal=0;
	if($no>0){
		while (list($cn,$names,$telno,$date,$acc,$vote,$dyr,$noc,$est,$paid,$bal)=mysqli_fetch_row($rs)){
		 	print "<tr><td align=\"right\">".date("D d M, y",strtotime($date))."</td><td>$names</td><td>$telno</td><td>$vote</td><td align=\"center\">$dyr</td><td align=\"center\">$noc</td>
			<td align=\"right\">".number_format(floatval($est),2)."</td><td align=\"right\">".number_format(floatval($paid),2)."</td><td align=\"right\">".number_format(floatval($bal),2).
			"</td><td align=\"center\" nowrap><a href=\"creditorsummary.php?recno=$cn-0-0\">View Details</a></td><td align=\"center\" nowrap>".(floatval($bal)>0?"<a
			href=\"creditorpv.php?recno=$cn-$acc\" title=\"Creditor's New Commitment Payment\">Pay Creditor</a>":"")."</td></tr>";
			$gest+=floatval($est); $gpaid+=floatval($paid);	$gbal+=floatval($bal); $i++;
		}
	}else print "<tr><td colspan=\"10\">There are No creditors register on specified criteria</td></tr>";
	print "<tr><td colspan=\"3\"><b>$no CREDITOR(S)</b></td><td align=\"right\" colspan=\"3\"><b>SUBTOTALS (KSHS.)</b></td><td align=\"right\"><b>".number_format($gest,
	2)."</b></td><td align=\"right\"><b>".number_format($gpaid,2)."</b></td><td align=\"right\"><b>".number_format($gbal,2)."</b></td><td colspan=\"3\"></td></tr></table><br>";
	//if ($no>0) print "<br><br><center>View <a href=\"creditorprintable.php?dat=$type-$yr-$nam-$clr-$ac\"><b>Printable Version</b></a> of the report.</center>";
?></div></div></div>
<div id="creditorAdd" class="modal">
	<form method="post" action="creditors.php" onsubmit="return validateFormOnSubmit(this)">
	<div class="imgcontainer"><span onclick="document.getElementById('creditorAdd').style.display='none'" class="close" title="Close">&times;</span></div><br/>
	<div class="container divmodalmain divlrborder">
		<div class="form-row"><div class="col-md-12 divheadings">REGISTRATION OF NEW CREDITOR</div></div>
		<div class="form-row">
			<div class="col-md-4"><label for="txtCredNo">Creditor's Code</label><Input Name="txtCredNo" id="txtCredNo" Type="Text" readonly value="Auto" maxlength="4" class="modalinput"></div>
			<div class="col-md-4"><label for="txtIDNo">Creditor's ID No.</label><input name="txtIDNo" id="txtIDNo" type="text" value="" maxlength="10" placeholder="987654321"
				onkeyup="checkInput(this)" class="modalinput"></div>
			<div class="col-md-4"><label for="txtDate">Registered On</label><input name="txtDate" id="txtDate" readonly class="tcal modalinput" value="<?php echo date("d-m-Y");?>"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtName">Name of Supplier</label><input name="txtName" id="txtName" type="text" class="modalinput" maxlength="30" value=""
				placeholder="Shanam's Digital Solutions"></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="txtAddress">Postal Address</label><input name="txtAddress" id="txtAddress" type="text" class="modalinput" maxlength="35"
				value="P.O Box "></div>
				<div class="col-md-6"><label for="txtEMail">E-Mail Address</label><input name="txtEMail" id="txtEMail" type="text" class="modalinput" maxlength="35"
					value="" style="text-transform:lowercase;" placeholder="someone@website.com"></div>
		</div><div class="form-row">
			<div class="col-md-4"><label for="txtTelNo">Telephone No.</label><input name="txtTelNo" id="txtTelNo" type="text" class="modalinput" maxlength="13" value=""
				placeholder="254720123456"></div>
			 <div class="col-md-4"><label for="txtTelNo">Supplier Code </label><input name="txtSupCode" id="txtSupCode" type="text" class="modalinput" maxlength="4" readonly
				 value="" ></div>
			 <div class="col-md-4"><label for="txtTelNo">Year of Registration</label><Input Name="txtYr" id="txtYr" Type="Text" value="<?php echo $yr;?>" class="modalinput"
				 maxlength="4" onkeyup="checkInput(this)"></div>
		</div><br><hr><br>
		<div class="form-row">
			<div class="col-md-4"><button type="submit" accesskey="s" name="cmdSave" class="btn btn-primary btn-md btn-block">Save Details and Continue</button></div>
			<div class="col-md-4"></div>
			<div class="col-md-4" style="text-align:right"><button type="button" name="cmdClose" onclick="document.getElementById('creditorAdd').style.display='none'"
			class="btn btn-info btn-md">Cancel/ Close</button></div>
		</div>
</div></div>
<script type="text/javascript">
	function canedit(pr) {
		if (pr == 0) {
				alert("Sorry, you do not have the priviledges to edit the record"); return false;
			} else {return true;}
	}
</script>
<?php mysqli_close($conn); footer();?>
