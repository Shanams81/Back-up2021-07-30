<!DOCTYPE html>
<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) {
		header ("Location:../index.php");
	} else {
	 	include_once('../conn/Pri_sch_connect.inc');
		$cls = isset($_POST['CboCls'])?trim(strip_tags($_POST['CboCls'])):"%";
		$str = isset($_POST['CboStream'])?trim(strip_tags($_POST['CboStream'])):"%";
		$rs=mysqli_query($conn,"SELECT finyr FROM ss"); if(mysqli_num_rows($rs)==1) list($yr)=mysqli_fetch_row($rs); else $yr=date('Y'); mysqli_free_result($rs);
	}
?>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css"/><link href="tpl/headers.css" rel="stylesheet" type="text/css"/>
		<title>School Fees Defaulters</title>
		<script type="text/javascript" src="tpl/priv.js"></script>
    </head>
<body background="img/bg3.gif"><font size="2"><div class="head"><form method="post" action="fee_bal_status.php">Fee Balance Status of Pupils in Class &nbsp;<select name="CboCls" size="1" 
id="Class"><option selected value="%">All</option>
<?php 
	$rs=@mysqli_query($conn,"SELECT clsno,clsname FROM classnames"); 
	if (mysqli_num_rows($rs)>0) while (list($clsno,$clsname)=mysqli_fetch_row($rs)) print "<option value=\"$clsno\">$clsname</option>";	mysqli_free_result($rs);
	print "</select>-<select name=\"CboStream\" size=\"1\" id=\"stream\"><option selected value=\"%\">All</option>";
	$rs=@mysqli_query($conn,"SELECT strm FROM grps WHERE strm is not null or strm not like ''"); 
	if (mysqli_num_rows($rs)>0) while (list($strm)=mysqli_fetch_row($rs)) print "<option>$strm</option>"; mysqli_free_result($rs);
?></select>&nbsp;&nbsp;<button type="submit" accesskey="s" name="CmdBalState">View Fee Bal Status</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" 
name="CmdMainbal">Main A/C Bal Per Votehead</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name="CmdMiscbal">Misc A/C Bal Per Votehead</button>	
</form></div>
<?php
	if (isset($_POST["CmdBalState"]) || isset($_POST["CmdMainbal"]) || isset($_POST["CmdMiscbal"])){
		if ((strcasecmp($cls,"%")==0) && (strcasecmp($str,"%")==0)) $h="All pupils' "; 
		elseif ((strcasecmp($cls,"%")==0) && (strcasecmp($str,"%")!=0)) $h="All $str stream pupils' ";  
		elseif ((strcasecmp($cls,"%")!=0) && (strcasecmp($str,"%")==0)) $h="All class $cls pupils' "; 
		else $h="Class $cls - $str pupils' ";
		$h.=" fees balance status as on ".date("D, d-F-Y");
	}elseif (isset($_POST["CmdMainbal"])) $h.=" main a/c balance per votehead as on ".date("D, d-F-Y");
	elseif (isset($_POST["CmdMiscbal"])) $h.=" misc a/c balance per votehead as on ".date("D, d-F-Y");
	else $h= "Fee Defaulters' Manual";
	print "<div id=\"print_content\"><h3>".strtoupper($h)."</h3>";
	if (isset($_POST["CmdBalState"])):
		$rsBal=mysqli_query($conn,"SELECT s.admno,s.names,s.cls,s.ttl,s.mttl,if((f.maint1-s.amtp)<1,(s.specialmedical+s.bbf+s.t1trans),(f.maint1-s.amtp+s.specialmedical+s.bbf+s.t1trans)) 
		as t1bal,if((f.maint2-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))<1,s.t2trans,(f.maint2+s.t2trans-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))) as t2bal,
		if((f.maint3-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))<1,s.t3trans,(f.maint3+s.t3trans-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))) as t3bal,(f.maint3+
		s.specialmedical+s.bbf+s.t1trans+s.t2trans+s.t3trans-s.amtp) as bal,if((f.misct1-s.misamtp)<1,(s.miscbf+s.unifrm),(f.misct1-s.misamtp+s.miscbf+s.unifrm)) as t1misbal,if((f.misct2-
		s.misamtp-if((f.misct1-s.misamtp)<1,0,(f.misct1-s.misamtp)))<1,0,(f.misct2-s.misamtp-if((f.misct1-s.misamtp)<1,0,(f.misct1-s.misamtp)))) as t2misbal,if((f.misct3-s.misamtp-
		if((f.misct2-s.misamtp)<1,0,(f.misct2-s.misamtp)))<1,0,(f.misct3-s.misamtp-if((f.misct2-s.misamtp)<1,0,(f.misct2-s.misamtp)))) as t3misbal,(f.misct3+s.miscbf+s.unifrm-s.misamtp) 
		as misbal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) As names,c.clsno,concat(cn.clsname,'-',c.stream) As cls,c.curr_year,c.feegrp,c.lvlno,c.bbf,c.specialmedical,c.t1trans,
		c.t2trans,c.t3trans,c.miscbf,c.unifrm,if(isnull(f.amtpaid),0,f.amtpaid) as amtp,(if(isnull(f.amtprep),0,f.amtprep)+if(isnull(f.ttlpaid),0,f.ttlpaid)) as ttl,if(isnull(m.ttlamt),0,
		m.ttlamt) as mttl,if(isnull(m.amtpaid),0,m.amtpaid) as misamtp FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT 
		admno,curr_year,sum(amt-arrears-refunds-spemed-transport-prep) As amtpaid,sum(prep) As amtprep,sum(amt+bankcharges) As ttlpaid FROM acc_feerec f GROUP BY f.admno,curr_year,
		f.markdel Having (f.markdel=0 and f.curr_year LIKE '$yr'))f On (s.admno=f.admno and s.curr_year=f.curr_year) LEFT JOIN (SELECT payeesno,curr_year,sum(amt-arrears-uni) as amtpaid,
		sum(amt+bankcharges) as ttlamt FROM acc_miscfeepyts GROUP BY payeesno,curr_year,markdel HAVING (markdel=0 and curr_year LIKE '$yr'))m On (s.admno=m.payeesno and 
		s.curr_year=m.curr_year) WHERE (c.`clsno` Like '$cls' and c.`stream` Like '$str' and c.curr_year LIKE '$yr'))s INNER JOIN acc_feeoutline f USING (curr_year,lvlno,feegrp) Order By 
		cls,names Asc");
		print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr bgcolor=\"#eeeeee\"><th colspan=\"4\" align=\"center\">Pupils' Details</th><th colspan=\"3\" align=\"center\">
		Total Fees Paid</th><th colspan=\"3\" align=\"center\">Term One Balance</th><th colspan=\"3\" align=\"center\">Term Two Balance</th><th colspan=\"3\" align=\"center\">Term Three 
		Balance</th><th colspan=\"3\" align=\"center\">Years Total Balance</th></tr><tr><th>S/N</th><th>Adm. No.</th><th align=\"center\">Names</th><th align=\"center\">Class</th><th 
		align=\"Center\">Main</th><th align=\"center\">Misc.</th><th align=\"center\">Total</th><th align=\"Center\">Main</th><th align=\"center\">Misc.</th><th align=\"center\">Total</th>
		<th align=\"Center\">Main</th><th align=\"center\">Misc.</th><th align=\"center\">Total</th><th align=\"Center\">Main</th><th align=\"center\">Misc.</th><th align=\"center\">Total
		</th><th align=\"Center\">Main</th><th align=\"center\">Misc.</th><th align=\"center\">Total</th></tr>";
		$a=mysqli_num_rows($rsBal); $amt=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		if ($a>0):
			$i=0;
			while (list($adn,$nam,$cla,$fee,$mfee,$t1,$t2,$t3,$ttl,$mt1,$mt2,$mt3,$mttl)=mysqli_fetch_row($rsBal)):
				if (($i%2)==0) print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">"; else print "<tr>";
				print "<td align=\"right\">".($i+1).".</td><td align=\"center\">$adn</td><td>$nam</td><td>$cla</td><td align=\"right\">".number_format($fee,2)."</td><td align=\"right\">".
				number_format($mfee,2)."</td><td align=\"right\"><b>".number_format(($fee+$mfee),2)."</b></td><td align=\"right\">".number_format($t1,2)."</td><td align=\"right\">".
				number_format($mt1,2)."</td><td align=\"right\"><b>".number_format(($mt1+$t1),2)."</td><td align=\"right\">".number_format($t2,2)."</td><td align=\"right\">".
				number_format($mt2,2)."</td><td align=\"right\"><b>".number_format(($mt2+$t2),2)."</b></td><td align=\"right\">".number_format($t3,2)."</td><td align=\"right\">".
				number_format($mt3,2)."</td><td align=\"right\"><b>".number_format(($mt3+$t3),2)."</b></td><td align=\"right\">".number_format($ttl,2)."</td><td align=\"right\">".
				number_format($mttl,2)."</td><td align=\"right\"><b>".number_format(($ttl+$mttl),2)."</b></td></tr>";
				$i++; $amt[0]+=$fee; $amt[1]+=$mfee; $amt[2]+=($fee+$mfee); $amt[3]+=$t1; $amt[4]+=$mt1;  $amt[5]+=($t1+$mt1); $amt[6]+=$t2; $amt[7]+=$mt2;  $amt[8]+=($t2+$mt2); 
				$amt[9]+=$t3; $amt[10]+=$mt3;  $amt[11]+=($t3+$mt3); $amt[12]+=$ttl; $amt[13]+=$mttl;  $amt[14]+=($ttl+$mttl);
			endwhile;
		else:
			print "<tr><td colspan=\"19\"><br>No fees defualters have been found</td></tr>";
		endif;
		print "<tr><td colspan=\"3\">$a Pupils' Records</td><td align=\"right\">Subtotals</td>";
		foreach($amt as $am) print "<td align=\"right\"><b>".number_format($am,2)."</b></td>";
		print "</tr></table></div><br><center><button onclick=\"Clickheretoprint()\">Print</button></center>";
		mysqli_free_result($rsBal);
	elseif (isset($_POST["CmdMainbal"])):
		$rsBal=mysqli_query($conn,"SELECT s.admno,s.names,s.cls,s.specialmedical,s.bbf,s.trans,(f.tui-s.tuip) as tuibal,(f.board-s.boap) as boabal,(f.act-s.actp) as actbal,(f.pemol-s.pemp) 
		as pembal,(f.ltt-s.lttp) as lttbal,(f.rmi-s.rmip) as rmibal,(f.ewc-s.ewcp) as ewcbal,(f.adm-s.adminp) as admbal,(f.lib-s.libp) as libbal,(f.med-s.medp) as medbal,(f.exam-
		s.exap) as exabal,(f.olevies-s.olep) as olebal,(f.maint3+s.specialmedical+s.bbf+s.trans-s.amtp) as bal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) As names,
		concat(cn.clsname,'-',c.stream) As cls,c.clsno,c.curr_year,c.feegrp,c.lvlno,c.bbf,c.specialmedical,(c.t1trans+c.t2trans+c.t3trans) as trans,if(isnull(f.tui),0,f.tui) as tuip,
		if(isnull(f.boa),0,f.boa) as boap,if(isnull(f.act),0,f.act) as actp,if(isnull(f.lt),0,f.lt) as lttp,if(isnull(f.rm),0,f.rm) as rmip,if(isnull(f.ew),0,f.ew) as ewcp,
		if(isnull(f.exa),0,f.exa) as exap,if(isnull(f.admin),0,f.admin) as adminp,if(isnull(f.libra),0,f.libra) as libp,if(isnull(f.med),0,f.med) as medp,if(isnull(f.pem),0,f.pem) as 
		pemp,if(isnull(f.ole),0,f.ole) as olep,if(isnull(f.amtpaid),0,f.amtpaid) as amtp FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) LEFT 
		JOIN (SELECT admno,curr_year,sum(f.tuition) As tui,sum(f.boarding) As boa,sum(f.activity) As act,sum(f.ltt) As lt,sum(f.rmi) As rm,sum(f.ewc) as ew,sum(f.exam) As exa,sum(f.adm) 
		As admin,sum(f.lib) as libra,sum(f.medical) as med,sum(f.pemolu) as pem,sum(f.olevy) as ole,sum(amt-arrears-refunds-spemed-transport-prep) As amtpaid FROM acc_feerec f GROUP BY 
		f.admno,curr_year,f.markdel Having f.markdel=0 and f.curr_year LIKE '$yr')f On (s.admno=f.admno and s.curr_year=f.curr_year) WHERE (c.`clsno` Like '$cls' and c.`stream` Like 
		'$str' and s.markdel=0 and s.present=1 and s.curr_year LIKE '$yr'))s Inner JOIN acc_feeoutline f USING (curr_year,lvlno,feegrp) ORDER BY s.cls,s.names ASC");
		print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr bgcolor=\"#eeeeee\"><th colspan=\"4\" align=\"center\">Pupils' Details</th><th colspan=\"3\" align=\"center\">
		Special Charges &amp; Arrears</th><th colspan=\"12\" align=\"center\">Main Account Total Balance Per Votehead</th><th rowspan=\"2\" align=\"center\" valign=\"middle\">Total Fee
		<br>Balance</th><th rowspan=\"2\" align=\"center\" valign=\"middle\">View Details</th></tr><tr><th>S/N</th><th>Adm. No.</th><th>Names</th><th>Class</th><th>Medical</th><th>Arrears 
		B/F</th><th>Transport</th><th>Tuition</th><th>Boarding</th><th>Activity</th><th>P/Emol</th><th>L . T &amp; T</th><th>R . M . I</th><th>E . W . C</th><th>Admin Costs</th><th>Library
		</th><th>Medical</th><th>Exam</th><th>Other Levies</th></tr>";
		$a=mysqli_num_rows($rsBal); $amt=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		if ($a>0){
		 	$rowno=0;
			while($det=mysqli_fetch_row($rsBal)){
				if ($rowno%2==0) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>"; $i=0;
				print "<td>".($rowno+1)."</td>";
				foreach($det as $d){
					if ($i>2){
						if ($i<18) print "<td align=\"right\">".number_format($d,2)."</td>"; else print "<td align=\"right\"><b>".number_format($d,2)."</b></td>";
						$amt[($i-3)]+=$d;
					}else{if ($i==0){ $admno=$d; print "<td align=\"center\">$d</td>";} else print "<td>$d</td>";} 
					$i++;
				}
				print "<td align=\"center\"><a href=\"stud_vote_bal.php?adm=$admno-1-$yr\">View</td></td>";	
				$rowno++;
			}	
		}else{
			print "<tr><td colspan=\"20\">No pupils exist in the system</td></tr>";
		}
		print "<tr><td colspan=\"3\"><b>$a Pupils' Main Balance Record(s)</b></td><td align=\"right\"><b>Subtotals</b></td>";
		foreach($amt as $am) print "<td align=\"right\"><b>".number_format($am,2)."</b></td>"; 
		print "<td></td></tr></table></div><br><center><button onclick=\"Clickheretoprint()\">Print</button></center>";
	elseif (isset($_POST["CmdMiscbal"])):
		$rsBal=mysqli_query($conn,"SELECT s.admno,s.names,s.cls,s.unifrm,s.miscbf,(f.misidcard-idp) as idbal,(f.misqa-qap) as qabal,(f.misremedial-remp) as rembal,(f.misht-htp) as htbal,
		(f.misgrad-gradp) as gradbal,(f.mistrip-tripp) as tripbal,(f.misole-olep) as olebal,(f.misct3+s.miscbf+s.unifrm-amtp) as bal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) As 
		names,concat(cn.clsname,'-',c.stream) As cls,c.clsno,c.curr_year,c.lvlno,c.feegrp,c.miscbf,c.unifrm,if(isnull(sqa),0,sqa) as qap, if(isnull(id),0,id) as idp,if(isnull(rem),0,rem) 
		as remp, if(isnull(sht),0,sht) as htp,if(isnull(sgrad),0,sgrad) as gradp,if(isnull(trip),0,trip) as tripp,if(isnull(ole),0,ole) as olep, if(isnull(amtpaid),0,amtpaid) as amtp FROM 
		stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT payeesno,curr_year,sum(qa) as sqa,sum(idcard) as id,sum(remedial) as rem,
		sum(ht) as sht,sum(grad) as sgrad,sum(acatrip) as trip,sum(olevy) as ole,sum(amt-arrears-uni) as amtpaid FROM acc_miscfeepyts GROUP BY payeesno,curr_year,markdel HAVING (markdel=0 
		and curr_year LIKE '$yr'))m On (c.admno=m.payeesno and c.curr_year=m.curr_year) WHERE (c.`clsno` Like '$cls' and c.`stream` Like '$str' and s.markdel=0 and s.present=1 and 
		s.curr_year LIKE '$yr'))s Inner Join Acc_feeoutline f USING (curr_year,lvlno,feegrp) ORDER BY s.cls,s.names ASC");
		print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr bgcolor=\"#eeeeee\"><th colspan=\"4\" align=\"center\">Pupils' Details</th><th colspan=\"2\" align=\"center\">
		Uniform Charges &amp; Arrears</th><th colspan=\"7\" align=\"center\">Misc. Account Total Balance Per Votehead</th><th rowspan=\"2\" align=\"center\" valign=\"middle\">Total Fee
		<br>Balance</th><th rowspan=\"2\" align=\"center\" valign=\"middle\">View Details</th></tr><tr><th>S/N</th><th>Adm. No.</th><th>Names</th><th>Class</th><th>Uniform</th><th>Arrears 
		B/F</th><th>ID Card</th><th>Quality Assurance</th><th>Remedial Studied</th><th>Holiday Tuition</th><th>Graduation</th><th>Academic Trip</th><th>Other Levies</th></tr>";
		$a=mysqli_num_rows($rsBal); $amt=array(0,0,0,0,0,0,0,0,0,0);
		if ($a>0){
		 	$rowno=0;
			while($det=mysqli_fetch_row($rsBal)){
				if ($rowno%2==0) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>"; $i=0;
				print "<td>".($rowno+1)."</td>";
				foreach($det as $d){
					if ($i>2){
						if ($i<12) print "<td align=\"right\">".number_format($d,2)."</td>"; else print "<td align=\"right\"><b>".number_format($d,2)."</b></td>";
						$amt[($i-3)]+=$d;
					}else{if ($i==0){ $admno=$d; print "<td align=\"center\">$d</td>";} else print "<td>$d</td>";} 
					$i++;
				}
				print "<td align=\"center\"><a href=\"stud_vote_bal.php?adm=$admno-1-$yr\">View</td></td>";	
				$rowno++;
			}	
		}else{
			print "<tr><td colspan=\"20\">No pupils exist in the system</td></tr>";
		}
		print "<tr><td colspan=\"3\"><b>$a Pupils' Misc. Balance Record(s)</b></td><td align=\"right\"><b>Subtotals</b></td>";
		foreach($amt as $am) print "<td align=\"right\"><b>".number_format($am,2)."</b></td>"; 
		print "<td></td></tr></table></div><br><center><button onclick=\"Clickheretoprint()\">Print</button></center>";
	else:
		print "<font size=\"3\" color=\"#0000ee\"><p class=\"g\">This interface allows you to view the following Main Account Fees details<ol type=\"i\"><li>Fee Balance status<li>Main A/C 
		Fee Balance per Votehead<li>Misc A/C Fee Balance per Votehead</ol></p>";
		print "<p class=\"g\"><b><u>Fee Balance status</u></b></p><ol type=\"a\"><li>Select the class whose balances are to be viewed<li>Select pupils' stream and <li>Click <b>View Fee Bal 
		Status</b> button</ol>";
		print "<p class=\"g\"><b><u>Main A/C Fee Balance per Votehead</u></b></p><ol type=\"a\"><li>Select the class whose balance per votehead are to be viewed<li>Select pupils' stream and 
		<li>Click <b>Main A/C Bal Per Votehead</b> button</ol>";
		print "<p class=\"g\"><b><u>Misc A/C Fee Balance per Votehead</u></b></p><ol type=\"a\"><li>Select the class whose balance per votehead are to be viewed<li>Select pupils' stream and 
		<li>Click <b>Misc A/C Bal Per Votehead</b> button</ol>";
	endif;
	mysqli_close($conn);
?>
</body>
</html>