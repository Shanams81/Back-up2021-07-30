<?php
	include_once('shanam.php');
	$id=isset($_REQUEST['id'])?$_REQUEST['id']:"0-0-0"; $id=preg_split('/\-/',$id); //id[0] purchno, id[1] unifrmno, id[2] cost
	$yr=date('Y');
	if (isset($_POST['CmdSave'])):
		$ad=strip_tags($_POST['TxtInfo']);	$ad=preg_split('/\-/',$ad);		$yr=date('Y');
		$unifrm=trim(strip_tags($_POST['CboUnifrm']));	$qty=isset($_POST['TxtQty'])?trim(strip_tags($_POST['TxtQty'])):0;	$qty=preg_replace("/[^0-9^\.]/","",$qty);
		$curamt=$ad[1]*$qty;
		if (strlen($unifrm)>0 && $qty>0){
		 	mysqli_query($conn,"UPDATE unipurchdetails SET qty='$qty' WHERE purchno Like '$ad[2]' and unifrmno LIKE '$ad[3]'") or die(mysqli_error($conn)
			 . " uniform details not added. Click <a href=\"unifrmpurch.php?admno=$ad[0]-1\">here</a> to go back.");
			$nos=mysqli_affected_rows($conn);
			if ($nos>0 && $curamt!=$ad[4]){//if uniform details were updated and there were changes then update uniform amt
				$change=$curamt-$ad[4];
				@mysqli_query($conn,"UPDATE class SET unifrm=unifrm+'$change' WHERE admno LIKE '$ad[0]' and curr_year LIKE '$yr'");
			}
			header("location:studarrears.php?action=$ad[0]-$yr-1");
		}else{
		  	print "<font size=\"+2\" color=\"#ff0000\">Ensure uniform description and unit price are validly entered before saving</font>";
		}
		$act[0]=1;
	endif;
	$rsPD=mysqli_query($conn,"SELECT up.purchno,up.admno,concat(s.surname,' ',s.onames)stud_names,concat(c.class,'-',c.stream) as cls,up.purchasedon,u.uname,
	u.unitsale,upd.qty,u.amt FROM stud s Inner Join class c USING (admno,curr_year) Inner Join unifrmpurchase up On (s.admno=up.admno) Inner Join unipurchdetails
	upd On (up.purchno=upd.purchno) INNER JOIN uniforms u On (upd.unifrmno=u.unifrmno) WHERE (upd.purchno Like '$id[0]' and upd.unifrmno LIKE '$id[1]' and
	upd.curr_year IN (SELECT finyr FROM ss))");
	list($purchno,$adno,$name,$cls,$date,$uniname,$units,$qty,$amt)=mysqli_fetch_row($rsPD); 		mysqli_free_result($rsPD);
	headings('',$act[0],$act[1],2);
	print "<form Action=\"unifrmpurchedit.php\" name=\"Adding\" Method=\"POST\" onsubmit=\"return validateFormOnSubmit(this)\"><input name=\"TxtInfo\"
	type=\"hidden\" value=\"$adno-$amt-$id[0]-$id[1]-$id[2]\"><table cellspacing=\"0\" cellpadding=\"4\" border=\"1\" align=\"center\" style=\"top:150px;\">
	<tr bgcolor=\"#eeeeee\"><th colspan=\"8\" style=\"letter-spacing:3px;word-spacing:5px;text-weight:bold;\">UNIFORM PURCHASED BY $adno <u>$name	</u> <br>
	CLASS $cls</th></tr><tr><th colspan=\"8\"><table border=0 cellpadding=6 cellspacing=0 align=\"center\"><tr><td colspan=\"3\"><b>Pucharse No. $purchno
	Purchased On ".date('D d M, Y',strtotime($date))."</b></td></tr><tr><td align=\"right\">Uniform Description</td><td><SELECT name=\"CboUnifrm\" size=\"1\"
	READONLY><option selected>$uniname</option></SELECT> Sold In $units";
	print "</td><td valign=\"middle\" rowspan=\"2\"><button name=\"CmdSave\">Save Uniform Purchase<br>Details</button></td></tr>";
	print "<tr><td valign=\"middle\" align=\"right\">Quantity Purchased</td><td><input type=\"text\" name=\"TxtQty\" id=\"TxtQty\" maxlength=\"2\" size=\"10\"
	value=\"0\" style=\"text-align:right;\" onkeyup=\"checkInput(this)\"> Cost per Unit Kshs. ".number_format($amt,2)."</tr></table></td></tr></table></form>";	
?>
<script type="text/javascript" src="tpl/unifrmpurch.js"></script>
<script type="text/javascript" src="tpl/actionmessage.js"></script>
<?php 	mysqli_close($conn); footer();?>
