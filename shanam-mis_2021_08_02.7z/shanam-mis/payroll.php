<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0';	$act=preg_split("/\-/",$act);
    class Payroll{
        private $salno,$mon,$yr,$acno,$bank,$voteno,$vote,$pron,$batchno,$nos,$state,$gsal,$ded,$nsal,$check,$approve,$vac;
        public function __construct($sano,$mo,$y,$acn,$ban,$vn,$vo,$on,$bn,$n,$st,$gsa,$de,$nsa,$ch,$ap,$va){$this->salno=$sano;	$this->mon=$mo;		$this->yr=$y;
        $this->acno=$acn;	$this->bank=$ban;	$this->voteno=$vn;	$this->vote=$vo;	$this->pron=date('d-m-Y',strtotime($on));	$this->batchno=$bn;		$this->nos=$n;
        $this->state=$st;	$this->gsal=$gsa;	$this->ded=$de;		$this->nsal=$nsa;	$this->check=$ch;	$this->approve=$ap;		$this->vac=$va;}
        public function valSalNo(){return $this->salno;}	public function valMon(){return $this->mon;}		public function valYr(){return $this->yr;}
        public function valACNo(){return $this->acno;}		public function valBank(){return $this->bank;}		public function valVoteNo(){return $this->voteno;}
        public function valVote(){return $this->vote;}		public function valDate(){return $this->pron;}		public function valBatch(){return $this->batchno;}
        public function valNOS(){return $this->nos;}		public function valState(){return $this->state;}	public function valGSal(){return $this->gsal;}
        public function valDed(){return $this->ded;}		public function valNSal(){return $this->nsal;}		public function valCheck(){return $this->check;}
        public function valVAc(){return $this->vac;}		public function valApprove(){return $this->approve;}	public function __destruct(){;}
    }mysqli_multi_query($conn, "SELECT salview,saladd,saledit,saldel,salcheck,salapprove FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT finyr FROM ss;");
    $salviu=0;	$salad=0; 	$saled=0; $saldel=0; $salchk=0; $salapprove=0;	$finyr=date('Y'); $i=0;
    do{
        if ($rs=mysqli_store_result($conn)){
            if ($i==0) list($salviu,$salad,$saled,$saldel,$salchk,$salapprove)=mysqli_fetch_row($rs);
            else list($finyr)=mysqli_fetch_row($rs);
        }$i++; mysqli_free_result($rs);
    }while (mysqli_next_result($conn));
    if($salviu==0) header("Location:vague.php");
    if (isset($_POST['btnSaveEdit0'])){
        $sno=isset($_POST['txtSNo1'])?sanitize($_POST['txtSNo1']):'0-0'; 	 		$sno=preg_split('/\-/',$sno);//[0] 0-new 1-editing, and [1] payroll serial no
        $pfno=isset($_POST['txtPFNo1'])?sanitize($_POST['txtPFNo1']):'0';  			$pon=isset($_POST['txtDate1'])?sanitize($_POST['txtDate1']):date('d-m-Y');  $pon=preg_split('/\-/',$pon);
        $mon=isset($_POST['cboMonth1'])?strtoupper(sanitize($_POST['cboMonth1'])):date('F'); $yr=isset($_POST['cboYear1'])?sanitize($_POST['cboYear1']):date('Y');
        $bno=isset($_POST['txtBatch1'])?sanitize($_POST['txtBatch1']):1;	 		$ac=isset($_POST['cboAC1'])?sanitize($_POST['cboAC1']):1;
        $voteac=isset($_POST['cboVoteAC1'])?sanitize($_POST['cboVoteAC1']):1;		$vote=isset($_POST['cboVotes1'])?sanitize($_POST['cboVotes1']):1;
        if ($pfno>0 && $ac>0 && $vote>0 && $yr>2019 && strlen($mon)>2 && $bno>0){//Sufficient data to be saved
            if ($sno[0]==0) $sql="INSERT INTO acc_salaries (salno,processedon,acc,sal_month,sal_year,acsno,voteno,addedby,batchno) VALUES ($pfno,'$pon[2]-$pon[1]-$pon[0]','$voteac','$mon',
            $yr,$ac,$vote,'".$_SESSION['username'].' ('.$_SESSION['priviledge'].')'."',$bno)";
            else $sql="UPDATE acc_salaries SET salno='$pfno',processedon='$pon[2]-$pon[1]-$pon[0]',acc='$voteac',sal_month='$mon',sal_year='$yr',acsno='$ac',voteno='$vote',batchno='$bno'
            WHERE salno LIKE '$sno[1]'";
            mysqli_query($conn,$sql); $act[1]=mysqli_affected_rows($conn);
        }else{$act[1]=0;  echo "There were errors on the payroll";} $act[0]=1;
    }
    mysqli_multi_query($conn,"SELECT s.salno,s.sal_month,s.sal_year,s.acsno,concat(b.abbr,' (',a.accno,')') as bank,s.voteno,concat(ac.abbr,' (',v.descr,')') as vote,s.processedon,
    s.batchno,count(sp.payrollno) as nos,if(count(sp.payrollno)=0,'Add Earners',if(s.checkstatus=0,'Pending Confirmation',if(s.approvestatus=0,'Pending Approval','Approved'))) as status,
    if(isnull(sum(sp.bsalary)),0,sum(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1)) as gsal,if(isnull(sum(sp.nssffee1)),0,sum(sp.nssffee1+
    sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.welfare1+sp.otherlevies1+sp.union1+sp.empnssf+sp.nssfvol1+sp.sacco1)) as ded, if(isnull(sum(sp.bsalary)),0,sum((sp.bsalary+sp.housingallow1
    +sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1)-(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.welfare1+sp.otherlevies1+sp.union1+sp.empnssf+sp.nssfvol1+
    sp.sacco1))) as nsal,s.checkstatus,s.approvestatus,s.acc FROM acc_salaries s Inner Join acc_accounts a On (s.acsno=a.sno) Inner Join acc_banks b On (a.bankno=b.sNo) Inner Join
    acc_voteacs ac On (a.accacc=ac.acno) Inner Join acc_votes v On (s.voteno=v.sno) LEFT Join acc_salpyt sp on (s.salno=sp.salno) GROUP BY s.salno,s.voteno,v.descr,s.acsno,a.accacc,ac.abbr,
    s.markdel,s.sal_month,s.sal_year,s.processedon,s.batchno,s.checkstatus,s.approvestatus,s.addedby HAVING s.markdel=0 ORDER BY s.salno DESC; SELECT saladd,saledit,saldel FROM acc_priv WHERE
    uname LIKE '".$_SESSION['username']."';SELECT salno,concat(sal_month,' - ',sal_year) as mon,approvestatus FROM acc_salaries ORDER BY salno DESC LIMIT 0,1; SELECT schtype FROm ss;");
    $schtype=$i=0;
    do{
        if ($rs=mysqli_store_result($conn)){
            if($i==0){$nop=mysqli_num_rows($rs);  if ($nop>0) while ($d=mysqli_fetch_row($rs)) $payroll[]=new Payroll($d[0],$d[1],$d[2],$d[3],$d[4],$d[5],$d[6],$d[7],$d[8],$d[9],$d[10],$d[11],
            $d[12],$d[13],$d[14],$d[15],$d[16]);
            }elseif ($i==1) list($saladd,$saledit,$saldel)=mysqli_fetch_row($rs);
            elseif($i==2) $sper=mysqli_fetch_row($rs);
            else list($schtype)=mysqli_fetch_row($rs);
        }$i++; 	mysqli_free_result($rs);
    }while(mysqli_next_result($conn));
    headings('<link href="tpl/css/inputsettings.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="../date/tcal.css" />',$act[0],$act[1],2);
?>
<div class="container" style="background-color:#e6e6e6;border-radius:10px 10px 0 0;padding:6px;">
    <div class="form-row"><div class="col-md-12" style="border:0.5px dotted #007;border-radius:10px;background:white;"><form method="post" action="#"><a href="stf_manager.php"><Img
      src="img\ani_back.gif" Align="left" Height="20" width="60" hspace="5"></a>Find Payroll By &nbsp;&nbsp;&nbsp;<input type="radio" name="radFind" id="radMon" value="sal_month"
      onclick="clrText(0)" checked>Month&nbsp;<input type="radio" name="radFind" id="radYr" value="sal_year" onclick="clrText(0)">Year &nbsp;&nbsp;&nbsp;<input type="text" maxlength="13"
      size="20" name="txtFind" id="txtFind" value="" onkeyup="myFunction(0)" placeholder="Search for a Payroll" title="Type what to find">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button
      name="btnNew" id="btnNew" type="button" onclick="addNew(0,0)" class="btn btn-primary btn-md">Create a New Payroll</button></form></div>
    </div><div class="form-row">
      <div class="col-md-12" style="max-height:250px;margin:4px auto;overflow-y:scroll;font-size:0.7rem;">
        <table id="myTable" class="table table-stripped table-sm table-hover table-bordered"><thead class="thead-dark"><tr style="letter-spacing:2px;word-spacing:4px;"><th
        colspan="6">PAYROLL DETAILS</th><th colspan="3">TOTAL SALARY</th><th rowspan="2">PAYROLL<br>STATUS</th><th colspan="3">ADMIN ACTIONS</th></tr><tr><th>Month</th><th>Year
        </th><th>Processed</th><th>Votehead Debited</th><th>A/C Debited</th><th>Earners</th><th>Gross</th><th>Deduction</th><th>Net</th><th>Payroll</th><th>Approve</th><th>Salary
        </th></tr></thead><tbody>
        <?php
            $i=$tgs=$tded=$tns=0; $ndays=7;
            if (isset($payroll)){
              foreach($payroll as $pf){
                $tgs+=$pf->valGSal();	$tded+=$pf->valDed();	$tns+=$pf->valNSal(); $ndays=(strtotime(date('Y-m-d'))-strtotime($pf->valDate()))/86400;
                print "<tr><td>".$pf->valMon()."</td><td>".$pf->valYr()."</td><td>".date("d M, Y",strtotime($pf->valDate()))."</td><td>".$pf->valVote().
                "</td><td>".$pf->valBank()."</td><td>".$pf->valNOS()."</td><td align=\"right\">".number_format($pf->valGSal(),2)."</td><td align=\"right\">".number_format($pf->valDed(),2).
                "</td><td align=\"right\">".number_format($pf->valNSal(),2)."</td><td>".$pf->valState()."</td><td align=\"center\">".($pf->valNSal()>0?($pf->valCheck()==0?"<a
                href=\"payrollapproval.php?rec=0-".$pf->valSalNo()."\" onclick=\"return payrollVerify(0,$salchk)\">Confirm":($pf->valApprove()==0?"<a href=\"payrollapproval.php?rec=1-".
                $pf->valSalNo()."-".$pf->valVAc()."\"  onclick=\"return payrollVerify(1,$salapprove)\">Approve":"")):"<a href=\"#\" onclick=\"addNew(1,".$pf->valSalNo().")\">Edit")."</a>
                </td><td align=\"center\">".(($ndays<14 && $pf->valApprove()==1)?"<a href=\"payrollapproval.php?rec=2-".$pf->valSalNo()."\" onclick=\"return payrollVerify(2,$salapprove)\">
                Unapprove</a>":"")."</td><td align=\"center\"><a onclick=\"viewPayroll(".$pf->valNSal().",$salviu,".$pf->valSalNo().")\" href=\"#\">View</a></td></tr>";
              }
            }else print "<tr><td colspan=\"13\">No Payroll has been processed using the system</td></tr>";
            print "</tbody><tfoot class=\"thead-light\"><tr><td colspan=\"3\"><b>$nop Staff Salary Payroll(s)</b></td></td><td colspan=\"3\" align=\"right\"><b>Totals (Kshs.)</b></td><td
            align=\"right\"><b>".number_format($tgs,2)."</b></td><td align=\"right\"><b>".number_format($tded,2)."</b></td><td align=\"right\"><b>".number_format($tns,2)."</b></td><td
            colspan=\"4\"></td></tr></tfoot>";
        ?></table></div>
    </div><div class="form-row"><div class="col-md-12" id="divPayroll" style="border:1px dotted #00a;border-radius:8px;padding:3px;">
      <div class="form-row">
        <div class="col-md-12" style="background:#fff;border-radius:10px 10px 0 0;padding:3px;font-size:1rem;margin:2px"><form method="post" action="payroll.php" name="frmPayrollList">
        Find Staff By &nbsp;&nbsp;&nbsp;<input type="radio" name="radFind1" id="radPFNo1" value="payrollno" onclick="clrText(1)">PF No.&nbsp;<input type="radio" name="radFind1"
        id="radIDNo1" value="idno" onclick="clrText(1)">ID No.&nbsp;<input type="radio" name="radFind1" id="radNames1" value="names" onclick="clrText(1)" checked>Names &nbsp; &nbsp;
        <input type="text" maxlength="13" size="20" name="txtFind1" id="txtFind1" value="" onkeyup="myFunction(1)" placeholder="Search for Staff" title="Type what to find"></form></div>
      </div><div class="form-row">
        <div class="col-md-9" style="font-size:10pt;font-weight:bold;letter-spacing:6px;word-spacing:10px;margin:left;"><?php echo strtoupper($sper[1]);?> SALARY PAYROLL</div>
        <div class="col-md-3" style="text-align:right;">Date: <?php echo date("D d M, Y");?></div>
      </div><div class="form-row"><div class="col-md-12" style="overflow-y:scroll;max-height:450px;">
    <?php
        $rsP=mysqli_query($conn,"SELECT sp.payrollno,s.idno,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.bsalary,sp.housingallow1,sp.medicalallow1,sp.travelallow1,
        responsallow1,sp.empnssf,(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1) AS GSal,(sp.nssffee1+sp.empnssf+sp.nssfvol1) as nssf,sp.nhiffee1,
        (sp.paye1-sp.mpr1) as tax,sp.union1,sp.sacco1,sp.welfare1,sp.advance,sp.otherlevies1,sp.helb1,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1)-
        (sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1+sp.helb1)) AS NetSal FROM stf s INNER JOIN acc_saldef USING (idno)
        Inner Join acc_salpyt sp USING (payrollno) Where sp.salno In (SELECT * FROM (SELECT salno FROM acc_salaries WHERE markdel=0 ORDER BY salno DESC LIMIT 0,1)x) and sp.markdel=0 ORDER BY
        s.surname,s.onames ASC");
        $gsal=$ded=$net=0; $nop=mysqli_num_rows($rsP);
        if ($nop>0){
            echo '<table id="myTable1" class="table table-stripped table-sm table-hover table-bordered" style="font-size:0.6rem;"><thead class="thead-dark"><tr><th colspan="4">DETAILS OF
            MEMBER OF STAFF</th><th rowspan=2>BASIC<br>SALARY</th><th colspan=5>SALARY ALLOWANCES</th><th rowspan=2>GROSS<BR>SALARY</th><th colspan=9>DEDUCTIONS/ RECOVERIES FROM SALARY</th><th rowspan=2>NET<BR>
            SALARY</th><th rowspan=2>ADMIN<BR>ACTION</th><tr><th>PFNO</th><th>ID NO</th><th>NAMES</th><th>DESIGNATION</th><th>HOUSE</th><th>MEDIC</th><th>COMMUTER</th><th>DUTY</th><th>
            NSSF</th><th>NSSF</th><th>NHIF</th><th>PAYE</th><th>'.($schtype==0?'ELIMU</th><th>KDS':'UNION</th><th>SACCO').'</th><th>WELFARE</th><th>ADVANCE</th><th>HELB</th><th>'.
            ($schtype==0?'RENT':'OTHER DED').'</th></tr></thead><tbody>'; $ttl=array(0,0,0);
            while (list($pfno,$idno,$name,$des,$bsal,$house,$med,$com,$resp,$enssf,$gsal,$nssf,$nhif,$paye,$union,$sacco,$welf,$adv,$ole,$helb,$nsal)=mysqli_fetch_row($rsP)){
                echo '<tr><td>'.$pfno.'</td><td>'.$idno.'</td><td>'.$name.'</td><td>'.$des.'</td><td align="right"><b>'.number_format($bsal,2).'</b></td><td align="right">'.
                number_format($house,2).'</td><td align="right">'.number_format($med,2).'</td><td align="right">'.number_format($com,2).'</td><td align="right">'.number_format($resp,2).'</td>
                <td align="right">'.number_format($enssf,2).'</td><td align="right"><b>'.number_format($gsal,2).'</b></td><td align="right">'.number_format($nssf,2).'</td><td align="right">'.
                number_format($nhif,2).'</td><td align="right">'.number_format($paye,2).'</td><td align="right">'.number_format($union,2).'</td><td align="right">'.number_format($sacco,2).
                '</td><td align="right">'.number_format($welf,2).'</td><td align="right">'.number_format($adv,2).'</td><td align="right">'.number_format($helb,2).'</td><td align="right">'.
                number_format($ole,2).'</td><td align="right"><b>'.number_format($nsal,2).'</b></td><td align="center">'.(($saledit==1 && $sper[2]==0)?'<a onclick="return canEdit('.$saledit.')" '
                . 'href="processStaffSalaries.php?salno=1-'.$sper[0].'-'.$pfno.'">Edit</a>':'').'</td></tr>';
                $ttl[0]+=$bsal;  	$ttl[1]+=$gsal; 	$ttl[2]+=$nsal;
            } mysqli_free_result($rsP);
            echo '</tbody><tfoot><tr><th colspan="2" id="parTotals" style="font-weight:bold;">'.$nop.' Staff Salaries.</th><th style="text-align:right;font-weight:bold;" colspan="2">Total '
            . 'Basic Salary</th><th style="text-align:right;font-weight:bold;" id="ttlBS">'.number_format($ttl[0],2).'<th style="text-align:right;font-weight:bold;" colspan="5">Total Gross '
            . 'Salary</th><th id="ttlGS" style="text-align:right;font-weight:bold;">'.number_format($ttl[1],2).'</th><th style="text-align:right;font-weight:bold;" colspan="9">Total Net Salary'
            . '</th><th id="ttlNS" style="text-align:right;font-weight:bold;">'.number_format($ttl[2],2).'.</th></tr></tfoot></table>';
        }else{
            echo '<center><a onclick="return canProcess('.$saladd.')" href="processStaffSalaries.php?salno=0-'.$sper[0].'-0"><button name="btnProcessAll" id="btnNew" type="button" class="p">
            Process Staff Members\' Salary</button></a></center>';
        }
        ?></div>
    </div></div></div>
</div>
<div id="payrollEdit" class="container modal">
    <FORM action="payroll.php" name="FrmAdding" Method="POST" onsubmit="return validateFormOnSubmit1(this)">
    <div class="imgcontainer"><span onclick="document.getElementById('payrollEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
    <div class="divmain divlrborder">
        <div class="form-row"><div class="col-md-12 divsubheading">PAYROLL CREATION MANAGER<input name="txtSNo1" id="txtSNo1" type="hidden" value=""></div>
        </div>
        <?php
            mysqli_multi_query($conn,"SELECT max(salno) FROM acc_salaries;SELECT acno,descr FROM acc_voteacs WHERE sal_assoc=1 ORDER BY acno; SELECT a.sno,concat(b.descr,' A/C NO. ',
            a.accno) as ac FROM acc_accounts a Inner Join acc_banks b On (a.bankno=b.sno) Inner Join acc_voteacs ac On (a.accacc=ac.acno) WHERE a.markdel=0 and ac.sal_assoc=1 and a.accacc
            IN (SELECT * FROM (SELECT accacc FROM acc_accounts a Inner Join acc_voteacs ac On (a.accacc=ac.acno) WHERE a.markdel=0 and ac.sal_assoc=1 order by sno asc limit 0,1)x) ORDER BY
            a.sno ASC; SELECT sno,descr FROM acc_votes WHERE acc in (SELECT * FROM (SELECT accacc FROM acc_accounts a Inner Join acc_voteacs ac On (a.accacc=ac.acno) WHERE a.markdel=0 and
            ac.sal_assoc=1 order by sno asc limit 0,1)x);");				$salno=$i=0;	$optVotes=$optBankAc=$optVoteAc="";
            do{
                if($rs=mysqli_store_result($conn)){
                    if ($i==0){if(mysqli_num_rows($rs)>0) list($salno)=mysqli_fetch_row($rs); }
                    elseif($i==1) while($dat=mysqli_fetch_row($rs)) $optVoteAc.="<option value=\"$dat[0]\">$dat[1]</option>";
                    elseif($i==2) while($dat=mysqli_fetch_row($rs)) $optBankAc.="<option value=\"$dat[0]\">$dat[1]</option>";
                    else while($dat=mysqli_fetch_row($rs)) $optVotes.="<option value=\"$dat[0]\" ".(stripos($dat[1],"emolum")==false?"":"selected").">$dat[1]</option>";
                }$i++; mysqli_free_result($rs);
            }while(mysqli_next_result($conn));  $salno++;
        ?>
        <div class="form-row"><div class="col-md-4"><label for="txtPFNo1">Payroll No. *</label><Input name="txtPFNo1" id="txtPFNo1" type="text" <?php print "value=\"$salno\"";?>
            required maxlength="4" readonly class="form-control"></div>
            <div class="col-md-4"><label for="cboVoteAC1">Votehead Account *</label><SELECT name="cboVoteAC1" id="cboVoteAC1" size="1" onchange="loadBankAC(this)" class="form-control">
            <?php echo $optVoteAc;?></SELECT></div>
            <div class="col-md-4"><label for="txtDate1">Date Processed *</label><Input name="txtDate1" id="txtDate1" type="text" <?php print "value=\"".date("d-m-Y")."\"";?>
            maxlength="10" class="tcal form-control" readonly></div>
        </div><div class="row"><div class="col-md-4"><label for="cboMonth1">Salary Month *</label><SELECT size="1" name="cboMonth1" id="cboMonth1" required class="form-control"><option value="january">January
            </option><option value="february">February</option><option value="march">March</option><option value="april">April</option><option value="may">May</option><option value="june">June
            </option><option value="july">July</option><option value="august">August</option><option value="september">September</option><option value="october">October</option><option
            value="november">November</option><option value="december">December</option></SELECT></div>
            <div class="col-md-4"><label for="cboYear1">Salary Year *</label><SELECT name="cboYear1" id="cboYear1" size="1" class="form-control"><?php print "<option value=\"".($finyr-1)."\">".($finyr-1)."</option>"
            . "<option value=\"$finyr\">$finyr</option><option value=\"".($finyr+1)."\">".($finyr+1)."</option>";?></SELECT></div>
            <div class="col-md-4"><label for="txtBatch1">Batch No. *</label><INPUT type="text" name="txtBatch1" id="txtBatch1" value="1" required class="form-control"></div>
        </div><div class="row">
            <div class="col-md-4"><label for="txtBatch1">Votehead Debited </label><span id="spVotes1"><SELECT size="1" name="cboVotes1" id="cboVotes1" class="form-control"><?php print $optVotes;?>
            </SELECT></span></div>
            <div class="col-md-8"><label for="cboAC1">Bank A/C Debited </label><span id="spBanks1"><SELECT name="cboAC1" id="cboAC1" size="1" class="form-control"><?php echo $optBankAc;?></SELECT></span></div>
        </div><br><div class="row"><div class="col-md-12">Payroll Status <Input name="chkConfirm1" id="chkConfirm1" type="checkbox" value="1" disabled>Confirmed &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;<Input name="chkApproved1" id="chkApproved1" type="checkbox" value="1" disabled>Approved</div>
        </div><hr><div class="row">
          <div class="col-md-6"><button type="submit" class="btn btn-primary btn-block btn-md" name="btnSaveEdit0">Save Payroll Details</button></div>
          <div class="col-md-3" id="btnDelete" style="text-align:right;"></div>
          <div class="col-md-3" style="text-align:right;"><button type="button" onclick="document.getElementById('payrollEdit').style.display='none'" class="btn btn-info btn-md">Cancel/
            Close</button></div>
        </div>
    </form>
</div></div>
<script type="text/javascript" src="tpl/priv.js"></script><script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/payroll-find.js"></script>
<script type="text/javascript">
  var payroll=[];
  <?php
    $p="";
    if(isset($payroll)){ $i=0;
      foreach ($payroll as $pf){$p.=($i==0?"":",")."new Payroll(".$pf->valSalNo().",\"".strtolower($pf->valMon())."\",".$pf->valYr().",\"".$pf->valDate()."\",".$pf->valBatch().",".
      $pf->valACNo().",".$pf->valVoteNo().",".$pf->valCheck().",".$pf->valApprove().",".$pf->valVAc().")";	$i++;}
    }if(strlen($p)>0) print "payroll.push($p);";
    print "</script>"; mysqli_close($conn); footer();
  ?>
