<?php
    include_once('shanam.php');
    include_once('tpl/funcs.tpl');
    $admno=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0-1";
    $admno=preg_split("/\-/",$admno); //$admno[1] for financial year. $admno[0] is admission number of student.
    if (isset($_POST['CmdSave'])){
        $action=strip_tags($_POST['TxtAction']); $action=preg_split("/\-/",$action);
        $med=isset($_POST['txtMed'])?strip_tags($_POST['txtMed']):0;	$fgrp=isset($_POST['cboGroup'])?strip_tags($_POST['cboGroup']):'General';
        $med=preg_replace('/[^0-9^\.]/','',$med);
        if (($med>=0) && strlen($fgrp)>2) {
            mysqli_query($conn,"UPDATE form SET specialmedical='$med', stud_group='$fgrp' WHERE admno LIKE '$action[0]' And curr_year='$action[1]'") or 
            die(mysqli_error($conn)." Record not saved. Click <a href=\"studarrears.php?action=$action[0]-$action[1]-$action[2]\">Here</a> to try again!!!!");
            $i=mysqli_affected_rows($conn);
        }else $i=0;
        header("location:arrearsbf.php?action=1-$i");
    }else{
        $rsSt=mysqli_query($conn,"SELECT concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname,'-',sf.stream) as frm,c.clsno,sf.spemed,sf.curr_year FROM stud s Inner Join class sf 
        Using (admno,curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) WHERE s.admno LIKE '$admno[0]'"); 
        list($studnames,$frm,$form,$med,$cuyr)=mysqli_fetch_row($rsSt); mysqli_free_result($rsSt);	
        $rs=mysqli_query($conn,"SELECT arrrefedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'"); $edi=0;
        if (mysqli_num_rows($rs)>0) list($edi)=mysqli_fetch_row($rs); mysqli_free_result($rs);	
    }headings('<script type="text/javascript" src="tpl/studarrears.js"></script>',0,0,1);
?>
<form method="post" action="studarrears.php" onsubmit="return ValidateInput(this);" style="color:#fff;">
<?php
    print "<input type=\"hidden\" value=\"$admno[0]-$admno[1]\" name=\"TxtAction\">";// Admission number, financial year and onclose where to go
    print "<br><br><br><table cellpadding=\"6\" cellspacing=\"2\" border=\"1\" align=\"center\" style=\"font-size:11pt;left:150px;top:150px;align:center;border-color:#fff;
    border-collapse:collapse;\"><tr><th colspan=\"5\"  style=\"color:#fff;background-color:#111;Letter-spacing:2px;word-spacing:4px;font-size:13pt;\">".
    strtoupper("Admission No. $admno[0] <u>($studnames)</u> <br> Form $frm ")."<hr></th></tr><tr><td colspan=\"5\">";
    print "<table border=0 cellspacing=\"1\" cellpadding=\"2\" width=\"100%\" align=\"center\"><tr><td align=\"right\" colspan=3>FY$cuyr Sur Medical Charges</td><td><Input 
    type=\"text\" name=\"txtMed\" value=\"".number_format($med,2)."\" size=\"10\" maxlength=\"10\" onkeyup=\"checkInput(this)\" onblur=\"addCommas(this)\" style=\"text-align:right;\">
    </td></tr></table><hr></td></tr>";
    print "<tr style=\"font-weight:bold;text-align:center;\"><td rowspan=\"2\">DESCRIPTION OF ARREARS</td><td colspan=\"3\">FEES ARREARS B/F</td><td 
    rowspan=\"2\">ADMIN<BR>ACTION</td></tr><tr><td>Main A/C</td><td>Misc A/C</td><td>Refundable</td></tr>";
    /*if ($admno[2]!=1) $sql="SELECT c.curr_year,upper(concat('Form ',n.clsname,' - ',c.stream,' ',c.curr_year)) as dsc,c.bbf,c.miscbf,c.alumniref,c.clsno FROM class c Inner Join 
    classnames n USING (clsno) WHERE admno LIKE '$admno[0]' and markdel=0 ORDER BY curr_year DESC LIMIT 0,4";
    else */$sql="SELECT c.curr_year,upper(concat('Form ',n.clsname,' - ',c.stream,' ',c.curr_year)) as dsc,c.bbf,c.miscbf,c.alumniref,c.clsno FROM class c Inner Join classnames n USING 
    (clsno) WHERE admno LIKE '$admno[0]' and markdel=0 ORDER BY curr_year DESC LIMIT 0,4";
    $rsArr=mysqli_query($conn,$sql);	$noa=mysqli_num_rows($rsArr);
    if ($noa==0){ //Arrears and form not defined
        $namecls=$form;
        print "<tr><td></td><td></td><td></td><td align=\"center\"><a onclick=\"return canedit($edi);\" href=\"studarrearseditor.php?rec=$admno[0]-1-$admno[1]-$namecls\">Define</a>
        </td></tr>";
    }else{
        $i=1; $ncls=4;
        while (list($yr,$dsc,$main,$misc,$ref,$cls)=mysqli_fetch_row($rsArr)){
            print "<tr><td>$dsc</td><td align=\"right\">".number_format($main,2)."</td><td align=\"right\">".number_format($misc,2)."</td><td align=\"right\">".
            number_format($ref,2)."</td><td align=\"center\">";
            if(($yr!=$cuyr)) print "<a onclick=\"return canedit($edi);\" href=\"studarrearseditor.php?rec=$admno[0]-2-$yr-$cls\"><img width=\"25\" height=\"25\" src=\"../gen_img/edit.ico\" "
            . "title=\"Edit Arrears\"></a>";
            print "</td></tr>"; $myyr=$yr;	$mycls=$cls;	$i++;
        } $i--;
        if ($i<$ncls){
            $myyr--; $mycls--;
            print "<tr><td colspan=4></td><td align=\"center\"><a onclick=\"return canedit($edi);\" href=\"studarrearseditor.php?rec=$admno[0]-1-$myyr-$mycls\" style=\"color:#fff;\">Define
            </a></td></tr>";
        } 	
    }mysqli_free_result($rsArr);
    print "<tr bgcolor=\"#eeeeee\"><td align=\"center\" colspan=\"5\"><button type=\"submit\" accesskey=\"s\" name=\"CmdSave\"><u>S</u>ave $cuyr Fee Group &amp; Medical Charges</button>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"arrearsbf.php\"><button type=\"button\" name=\"CmdClose\">Cancel/ Close</button></a></td></tr></table></form>";
    mysqli_close($conn); footer();
?>