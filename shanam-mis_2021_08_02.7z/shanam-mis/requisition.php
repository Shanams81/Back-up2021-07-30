<?php
	include_once('shanam.php');
	$sdate= isset($_POST['dtpStart']) ? $_POST['dtpStart'] : date('d-m-Y',strtotime(date('Y').'-01-01'));
	$edate= isset($_POST['dtpEnd']) ? $_POST['dtpEnd'] : date("d-m-Y"); $state=isset($_POST['cboState'])?strip_tags($_POST['cboState']):0;
	$action=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):'0-0';	$action=preg_split("/\-/",$action);
	$rsPriv=mysqli_query($conn,"SELECT reqadd,reqedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$appr=$req=0; if (mysqli_num_rows($rsPriv)>0) list($appr,$req)=mysqli_fetch_row($rsPriv); mysqli_free_result($rsPriv);
	headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css"/><link rel="stylesheet" type="text/css" href="/date/tcal.css"/>',$action[0],$action[1],2);
?>
 <div class="head"><form method="post" action="requisition.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" onclick="window.open('imprest_manager.php','_self')"
		align="left">&nbsp;&nbsp;&nbsp;<label for="cboState">View </label><SELECT name="cboState" id="cboState" size="1"><Option value=0 ".($state==0?"selected":"").">Unapproved
		</option><Option value=1 <?php echo ($state==1?"selected":"");?>>Approved</option><Option value=2 <?php echo ($state==2?"selected":"");?>>Rejected</option></Select>&nbsp;
		Requisitions raised between &nbsp;<input name="dtpStart" class="tcal" type="text" value="<?php echo $sdate;?>" readonly size="10">&nbsp; and &nbsp;<input name="dtpEnd" class="tcal"
		type="text" value="<?php echo $edate;?>" readonly size="10">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name="Show">View Requisitions</button>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button onclick="window.open('reqadd.php','_self')" <?php echo ($req==0?"disabled":"");?> type="button" accesskey="s" name="Show">New
		Requisition</button></form>
</div>
<?php
	$sql="SELECT r.reqno,r.deptno,r.acc,s.idno,concat(s.surname,' ',s.onames) as st_names,r.reqdate,d.deptname,r.reqtype,r.rmks, if(isnull(i.amt),0,i.amt) as Amt, if(isnull(p.status),
	0,p.status) as impstate FROM acc_req r Inner Join stf s Using (idno) Inner Join depts d ON (r.deptno=d.deptno) LEFT JOIN (SELECT reqno,sum(approvedup*approvedqty) as amt
	FROM acc_reqitems GROUP BY reqno,markdel HAVING markdel=0)i ON (r.reqno=i.reqno) LEFT JOIN acc_imp p ON (r.reqno=p.reqno) WHERE ";
	if (isset($_POST['Show'])){
	 	$h=($state==0)?"Unapproved":($state==1?"Approved":"Rejected ");
		$h.=" Requistions' Made between ".date('D d F, Y',strtotime($sdate))." and ".date('D d F, Y',strtotime($edate))." Report";
		$sdate=preg_split("/\-/",$sdate);	$edate=preg_split("/\-/",$edate);
		if($state!=0) $sql.="(r.approved LIKE '$state' and (r.approvedate BETWEEN '$sdate[2]-$sdate[1]-$sdate[0]' and '$edate[2]-$edate[1]-$edate[0]') and r.served=0 and r.markdel=0) ";
		else $sql.="(r.approved LIKE '$state' and (r.reqdate BETWEEN '$sdate[2]-$sdate[1]-$sdate[0]' and '$edate[2]-$edate[1]-$edate[0]') and r.served=0 and r.markdel=0)";
	} else {
		$h="ALL UNAPPROVED REQUISITIONS IN THE SYSTEM"; $sql.="r.approved=0 and r.served=0 and r.markdel=0";
	}$sql.=" ORDER BY r.reqno ASC";
	print "<h4>$h</h4><hr>";
	print "<div class=\"container\" style=\"background-color:#e6e6e6;width:fit-content;max-height:700px;overflow-y:scroll;\"><table id=\"myTable\" class=\"table table-sm table-hover
	table-bordered table-striped\"><thead class=\"thead-dark\"><tr><th>#</th><th>DATE</th><th>DEPARTMENT</th><th>REQUISITIONED BY</th><th>TYPE</th><th>NARRATION OF THE REQUISITION
	</th><th>AMOUNT</th><th colspan=\"3\">ADMIN ACTIONS</th></tr></thead>";
	$rsReq=mysqli_query($conn,$sql); 	$i=mysqli_num_rows($rsReq); $ttl=0;
	if ($i>0){ $r=1;
		while (list($reqno,$deptno,$acc,$idno,$nam,$date,$dept,$type,$rmks,$amt,$impstatus)=mysqli_fetch_row($rsReq)){
			print "<tr><td align=\"center\">$r</td><td align=\"right\">".date('D d M, Y',strtotime($date))."</td><td>$dept</td><td>$nam</td><td >$type</td><td>$rmks</td><td align=\"right\">"
			.number_format($amt,2)."</td>";
			if ($state==0) print "<td align=\"center\" ><a onclick=\"return canApprove($appr)\" href=\"reqadd.php?reqno=$reqno-$deptno-$acc-$idno-1\">Edit</a></td><td align=\"center\">
			<a onclick=\"return canApprove($appr)\" href=\"reqapproval.php?reqno=$reqno-1\">Approve</a></td><td align=\"center\"><a href=\"reqreject.php?reqno=$reqno\">Reject</a></td>";
			elseif($state==1) print "<td></td><td align=\"center\">".($impstatus==0?"<a onclick=\"return canApprove($appr)\" href=\"reqapproval.php?reqno=$reqno-2\">Unapprove</a>":"").
			"</td><td></td>";
			else print "<td></td><td></td><td align=\"center\">".($impstatus==0?"<a onclick=\"return canApprove($appr)\" href=\"reqapproval.php?reqno=$reqno-3\">Restore</a>":"")."</td>";
			print"</tr>";
			$r++; 		$ttl+=$amt;
		}
	}else print "<tr><td colspan=\"10\">Sorry, No requisitions exists for the selected criteria</td></tr>"; mysqli_free_result($rsReq);
	print "<tr><td colspan=\"4\"><b>$i Requisition Detail(s)</b></td><td colspan=\"2\" align=\"right\"><b>REQUISITON SUBTOTAL (KSHS.)</td><td align=\"right\">".number_format($ttl,2).
	"</b></td><td colspan=\"3\"></td></tr></table></div>";
?>
<script type="text/javascript" src="tpl/js/requisition.js"></script>
<script type="text/javascript" src="../date/tcal.js"></script>
<?php mysqli_close($conn); footer();?>
