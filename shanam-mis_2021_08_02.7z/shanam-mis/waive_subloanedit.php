<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	if (isset($_POST['cmdSave'])){
		$info=isset($_POST['txtDat'])?strip_tags($_POST['txtDat']):"0-0-0"; 
		$info=preg_split('/\-/',$info); //[0] 0 for new waive and 1 for edit waive, [1] - Advance number, [2] - Waive Number
		$origAmt=isset($_POST['txtB4Amt'])?strip_tags($_POST['txtB4Amt']):'0'; 	$advno=isset($_POST['txtAdvNo'])?strip_tags($_POST['txtAdvNo']):'0';
		$date=isset($_POST['txtDate'])?$_POST['txtDate']:date('d-m-Y');		$date=preg_split('/\-/',$date);
		$amt=isset($_POST['txtWaived'])?strip_tags($_POST['txtWaived']):0;	$amt=preg_replace("/[^0-9^\.]/","",$amt);
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(strip_tags($_POST['txtRmks']))):"ON HUMANITARIAN GROUNDS"; 
		if ($info[0]==0) $sql="INSERT INTO Acc_SubloanWaive(waiveno,loanno,waivedon,amt_waived,rmks) VALUES (0,'$info[1]','$date[2]-$date[1]-$date[0]','$amt',".var_export($rmks,true).")";
		else $sql="UPDATE acc_subloanwaive SET waivedon='$date[2]-$date[1]-$date[0]',amt_waived='$amt',rmks=".var_export($rmks,true)." WHERE waiveno LIKE '$info[2]'";
		mysqli_query($conn,$sql) or die(mysqli_error($conn)." Record not saved. Click <a href=\"waive_subloan.php\">here</a> to try again."); $i=mysqli_affected_rows($conn); 
		if($i>0 && $info[0]==0){// new waive
			mysqli_query($conn,"INSERT INTO Acc_SubloanClr (clrno,loanno,clr_date,amt_clr,clr_form,rmks) VALUES (0,'$info[1]','$date[2]-$date[1]-$date[0]','$amt','Cash','SUBLOAN WAS WAIVED')") or 
			die(mysqli_error($conn)." Record not saved. Click <a href=\"waive_subloan.php\">here</a> to try again.");
		}else if ($i>0 && $info[0]==1){//editing waive
			$amt-=$origAmt; 
			mysqli_query($conn,"UPDATE acc_subloanclr SET amt_clr=amt_clr+$amt WHERE loanno LIKE '$info[1]'")  or die(mysqli_error($conn)." Record not saved. Click <a href=\"waive_sublon.php\">
			here</a> to try again.");
		} header("location:waive_suloan.php?action=1-$i");
	}else if (isset($_POST['cmdDel'])){
	 	$info=isset($_POST['txtDat'])?strip_tags($_POST['txtDat']):"0-0-0"; $info=preg_split('/\-/',$info); //[0] 0 for new waive and 1 for edit waive, [1] - Advance number, [2] - Waive Number
		mysqli_query($conn,"UPDATE acc_subloanwaive SET markdel=1 WHERE waiveno LIKE '$info[2]'"); $i=mysqli_affected_rows($conn);
		if ($i>0) mysqli_query($conn,"DELETE FROM acc_subloanclr WHERE loanno LIKE '$info[1]'");
		header("location:waive_subloan.php?action=2-$i");
	}else{
		$info=isset($_REQUEST['id'])?strip_tags($_REQUEST['id']):"0-0-0"; 
		$info=preg_split('/\-/',$info); //[0] 0 for new waive and 1 for edit waive, [1] - Advance number, [2] - Waive Number
		$rsStud=mysqli_query($conn,"SELECT a.loanno,s.idno,concat(s.surname,' ',s.onames) as st_names,s.tscno,a.adv_date,concat(a.mons,' Month(s)') as dur,a.amt,a.amtpermon,
		IF(isnull(Sum(c.amt_clr)),0,Sum(c.amt_clr)) AS AmtClrd,(a.amt-IF(isnull(Sum(c.amt_clr)),0,Sum(c.amt_clr))) AS Bal FROM stf s INNER JOIN (Acc_sunloan a LEFT JOIN Acc_subloanClr c USING 
		(loanno)) ON s.idno= a.idno GROUP BY s.idno,s.surname,s.onames,a.adv_date,a.loanno,a.amtpermon,a.amt,a.rmks,a.mons HAVING a.loanno LIKE '$info[1]'");
		list($advno,$idno,$name,$tsc,$advdate,$dur,$amt,$amtpd,$clrd,$bal)=mysqli_fetch_row($rsStud); mysqli_free_result($rsStud);
		$won=date('Y-m-d');	$wrmks="On humanitarian grounds"; $warr=0;
		if ($info[0]==1){
			$rs=mysqli_query($conn,"SELECT waivedon,amt_waived,rmks FROM acc_subloanwaive WHERE waiveno LIKE '$info[2]'");
			list($won,$warr,$wrmks)=mysqli_fetch_row($rs); mysqli_free_result($rs);
		}
	}
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<link href="../date/tcal.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<script type="text/javascript" src="../date/tcal.js"></script>
	<script type="text/javascript" src="tpl/waiveadv.js"></script>
</head>
<body background="../gen_img/bg3.gif">
	<form method="post" action="waive_adv.php" onsubmit="return onSubmitVerify(this);" name="frmCont">
	<?php
		print "<table cellpadding=\"4\" cellspacing=\"3\" border=\"0\" style=\"position:absolute;top:100px;left:300px;\"><tr><td colspan=\"6\" style=\"background-color:#000;
		font-weight:bold;font-size:12pt;letter-spacing:4px;word-spacing:7px;text-align:center;color:#0e0;\">WAIVING SALARY ADVANCE BALANCE</td></tr>";
		print "<input type=\"hidden\" name=\"txtDat\" value=\"$info[0]-$info[1]-$info[2]\"><input type=\"hidden\" name=\"txtB4Amt\" id=\"txtB4Amt\" value=\"$warr\">";
		print "<tr><td align=\"right\">ID. No.</td><td colspan=\"5\"style=\"font-weight:bold;letter-spacing:1px;word-spacing:3px;\">$idno <u>$name</u> TSC No. <u>$tsc</u></td></tr>
		<tr><td align=\"right\">Advance No.</td><td>$info[1]</td><td align=\"right\">Issued On</td><td>".date("D d M, Y",strtotime($advdate))."</td><td align=\"right\">To be Recovered In
		</td><td>$dur</td></tr>";
		print "<tr><td align=\"right\">Advance Issued</td><td><input type=\"text\" name=\"txtAdvAmt\" id=\"txtAdvAmt\" size=\"6\" value=\"".number_format($amt,2)."\" disabled 
		style=\"text-align:right;font-weight:bold;\"></td><td align=\"right\">Advance Cleared</td><td><input type=\"text\" name=\"txtAdvClr\" id=\"txtAdvClr\" size=\"6\" value=\"".
		number_format($clrd,2)."\" disabled style=\"text-align:right;font-weight:bold;\"></td><td align=\"right\">Advance Balance</td><td><input type=\"text\" name=\"txtBal\" 
		id=\"txtBal\" size=\"6\" value=\"".number_format($bal,2)."\" disabled style=\"text-align:right;font-weight:bold;\"></td></tr><tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td align=\"right\">Waived On</td><td><input name=\"txtDate\" type=\"text\" class=\"tcal\" size=\"7\" readonly value=\"".date('d-m-Y',strtotime($won)).
		"\"></td><td align=\"right\">Amount Waived</td><td><input type=\"text\" name=\"txtWaived\" size=\"6\" style=\"text-align:right;\" value=\"".number_format($warr,2)."\" 
		id=\"txtWaived\" onkeyup=\"checkInput(this)\" onblur=\"calcTtl()\"></td><td align=\"right\">Balance After Waive</td><td><input type=\"text\" name=\"txtWaiveBal\" size=\"6\" 
		style=\"text-align:right;font-weight:bold;\" value=\"".number_format($bal,2)."\" id=\"txtWaiveBal\" disabled></td></tr>";
		print "<tr><td align=\"right\" valign=\"top\">Reason of Waive</td><td colspan=\"5\"><textarea cols=\"75\" rows=\"3\" name=\"txtRmks\" maxlength=\"200\" 
		style=\"letter-spacing:2px;word-spacing:3px;text-transform:uppercase;\">$wrmks</textarea></td></tr><tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td colspan=\"2\" align=\"center\"><button name=\"cmdSave\" type=\"submit\">Save Waive Record</Button></td><td align=\"center\" colspan=\"2\"><button name=\"cmdDel\" 
		type=\"submit\" ".($info[0]==0?"disabled":"").">Delete Waive</Button></td><td align=\"center\" colspan=\"2\"><a href=\"waive_advance.php?action=0-0\"><button name=\"cmdClose\" 
		type=\"button\">Cancel/ Close</Button></a></td></tr></table>";
		mysqli_close($conn);
	?>
	</form>
</body></html>