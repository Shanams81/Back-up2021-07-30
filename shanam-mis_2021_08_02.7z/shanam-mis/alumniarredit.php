<?php
	include_once('shanam.php');
	$admno=isset($_REQUEST['rec']) ? $_REQUEST['rec']:"0-0";		$admno=preg_split("/\-/",$admno); //[0] adm no, [1]=year
	if (isset($_POST['cmdSave'])){
		$adm=isset($_POST['txtAdmNo'])?sanitize($_POST['txtAdmNo']):0; 									$max=isset($_POST['txtMax'])?sanitize($_POST['txtMax']):0; 			$sql='';
		$rmks=isset($_POST['txtRmks'])?strtoupper(sanitize($_POST['txtRmks'])):0;				$doneon=date('Y-m-d');	$by=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		for ($i=0;$i<$max;$i++){
			$yr=isset($_POST['txtRec_'.$i])?sanitize($_POST['txtRec_'.$i]):(date('Y')-1); $parr=isset($_POST['txtPArr_'.$i])?sanitize($_POST['txtPArr_'.$i]):0;
			$arr=isset($_POST['txtArr_'.$i])?sanitize($_POST['txtArr_'.$i]):0;						$pref=isset($_POST['txtPRef_'.$i])?sanitize($_POST['txtPRef_'.$i]):0;
			$ref=isset($_POST['txtRef_'.$i])?sanitize($_POST['txtRef_'.$i]):0;						$pref=preg_replace('/[^0-9^\.]/',"",$pref);	$ref=preg_replace('/[^0-9^\.]/',"",$ref);
			$parr=preg_replace('/[^0-9^\.]/',"",$parr);			$arr=preg_replace('/[^0-9^\.]/',"",$arr);
			if($arr>0 && $ref>0){}//do nothing since an alumni can not have refunds and arrears in the same year
			else{
				if($parr!=$arr) $sql.="UPDATE class SET alumniarrears=$arr WHERE admno='$adm' and curr_year='$yr'; INSERT INTO acc_arrrefchanges(sno,admno,arr_yr,doneon,prevamt,newamt,ac,type,
				rmks,addedby) VALUES (0,$adm,$yr,'$doneon',$parr,$arr,1,0,'$rmks','$by'); ";
				elseif($pref!=$ref) $sql.="UPDATE class SET alumniref=$ref WHERE admno='$adm' and curr_year='$yr'; INSERT INTO acc_arrrefchanges(sno,admno,arr_yr,doneon,prevamt,newamt,ac,type,
				rmks,addedby) VALUES (0,$adm,$yr,'$doneon',$pref,$ref,1,1,'$rmks','$by');";
			}
		} if (strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"alumniadd.php?admno=1-$adm\">HERE</a> to try again");	while(mysqli_next_result($conn)){}}
		header("location:AlumniAdd.php?admno=1-$adm"); exit(0);
	} headings('',0,0,1);
?><br><div class="container" style="border:1px dashed #ff3;border-radius:10px;background-color:#eee;padding:10px;max-width:700px;margin:auto;"><form method="post" action="alumniarredit.php"
onsubmit="return validateInput(this)">
<?php
	print "<input type=\"hidden\" name=\"txtAdmNo\" value=\"$admno[0]\">";
 	mysqli_multi_query($conn,"SELECT concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname,' ',sf.stream,' ',sf.curr_year) as strm FROM stud s LEFT JOIN class sf USING
	(admno,curr_year) Inner Join classnames c USING (clsno) WHERE s.admno LIKE '$admno[0]' and s.curr_year LIKE '$admno[1]'; SELECT f.curr_year,concat(c.clsname,' ',f.stream,' ',f.curr_year)
	as strm, f.alumniarrears, f.alumniref FROM class f Inner Join classnames c USING (clsno) WHERE f.admno LIKE '$admno[0]' ORDER BY curr_year ASC;") or die(mysqli_error($conn).". Click <a
	href=\"alumniadd.php?admno=1-$admno[0]\">HERE</a> to try again."); $index=0; $data='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($index==0) list($studnames,$frm)=mysqli_fetch_row($rs);
			else{ $a=0;
					while($alu=mysqli_fetch_row($rs)){
						$data.='<div class="form-row"><div class="col-md-4" style="text-align:right;font-weight:bold;"><input type="hidden" name="txtRec_'.$a.'" value="'.$alu[0].'">'.$alu[1].'</div><div
						class="col-md-2"><input type="text" name="txtPRef_'.$a.'" id="txtPRef_'.$a.'" maxlength="10" readonly style="text-align:right;background:#ddd;font-weight:bold;" value="'.
						number_format($alu[3],2).'"></div><div	class="col-md-2"><input type="text" name="txtRef_'.$a.'" id="txtRef_'.$a.'" maxlength="10" style="text-align:right;font-weight:bold;
						color:#00f;" value="'.number_format($alu[3],2).'" onkeyup="checkNumber(this)"></div><div class="col-md-2"><input type="text" name="txtPArr_'.$a.'" id="txtPArr_'.$a.'" maxlength="10"
						readonly style="text-align:right;background:#ddd;font-weight:bold;" value="'.number_format($alu[2],2).'"></div><div class="col-md-2"><input type="text" name="txtArr_'.$a.'"
						id="txtArr_'.$a.'" maxlength="10" style="text-align:right;color:#00f;font-weight:bold;" value="'.number_format($alu[2],2).'" onkeyup="checkNumber(this)"></div></div>';
						$a++;
					}
			}mysqli_free_result($rs);
		}$index++;
	}while(mysqli_next_result($conn));
?>
<div class="form-row">
	<div class="col-md-12" style="background:#555;color:#fff;text-align:center;"><h5>EDITING OF FEE ARREARS/ REFUNDS B/F FOR	ADM. NO. <?php	echo "$admno[0] <b><u>".strtoupper($studnames).
	"</u></b> ALUMNI OF ".strtoupper($frm);?> </h5></div>
</div><br>
<div class="form-row">
	<div class="col-md-4"></div><div class="col-md-4" style="border-radius:10px 10px 0px 0px;background:#999;color:#fff;font-weight:bold;text-align:center;"><u>CURRENT REFUNDS B/F</u></div><div
	class="col-md-4" style="border-radius:10px 10px 0px 0px;background:#444;color:#fff;font-weight:bold;text-align:center;"><u>CURRENT FEE ARREARS B/F</u></div>
</div><div class="form-row">
	<div class="col-md-4"></div><div class="col-md-2" style="border-radius:0px 0px 10px 10px;background:#999;color:#fff;text-align:center;">PREVIOUS</div><div class="col-md-2"
	style="text-align:center;background:#999;color:#fff;border-radius:0px 0px 10px 10px;">CURRENT</div><div class="col-md-2" style="border-radius:0px 0px 10px 10px;background:#444;color:#fff;
	text-align:center;">PREVIOUS</div><div class="col-md-2" style="color:#fff;text-align:center;border-radius:0px 0px 10px 10px;background:#444;">CURRENT</div>
</div><?php echo "$data <input type=\"hidden\" name=\"txtMax\" id=\"txtMax\" value=\"$a\">";?>
<BR><div class="form-row">
	<div class="col-md-12"><lable for="txtRmks">Narration/ Reason for this Change *</label><Textarea name="txtRmks" id="txtRmks" rows="3" maxlength="150" style="text-transform:uppercase;"
	placeholder="Reason why arrears/ refunds are being changed" required onkeyup="enableSave()"></textarea></div>
</div><br><div class="form-row">
	<div class="col-md-6"><button type="submit" accesskey="s" name="cmdSave" id="cmdSave" style="height:40px;" disabled><u>S</u>ave Arrears/ Refunds Changes</button></div>
	<div class="col-md-6" style="text-align:right;"><a href="alumniadd.php?admno=<?php echo "1-$admno[0]";?>"><button type="button" name="cmdClose" style="height:40px;">Cancel/ Close
	</button></div>
</div></form></div><script type="text/javascript" src="tpl/js/alumni_arr_ref_amt.js"></script>
<?php mysqli_close($conn); footer(); ?>
