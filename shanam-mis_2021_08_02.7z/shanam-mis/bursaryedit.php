<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:\index.php"); else include_once('../conn/pri_sch_connect.inc');
	if(isset($_POST['btnSave'])){
		$ron=isset($_POST['txtReceivedOn'])?sanitize($_POST['txtReceivedOn']):date('d-m-Y'); $ron=preg_split('/\-/',$ron); $ron=$ron[2].'-'.$ron[1].'-'.$ron[0];
		$name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName']))):'';
		$po=isset($_POST['txtPO'])?sanitize($_POST['txtPO']):0;		$code=isset($_POST['txtPOCode'])?sanitize($_POST['txtPOCode']):null;
		$town=isset($_POST['txtTown'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtTown']))):null;
		$mode=isset($_POST['cboMode'])?strtoupper(sanitize($_POST['cboMode'])):'CHEQUE'; 	$modeno=isset($_POST['txtModeNo'])?sanitize($_POST['txtModeNo']):null;
		$bank=isset($_POST['cboBank'])?strtoupper(sanitize($_POST['cboBank'])):0;			$bank=($bank==0?null:$bank);
		$branch=isset($_POST['txtBranch'])?strtoupper(sanitize($_POST['txtBranch'])):null; $ack=isset($_POST['txtAck'])?strtoupper(sanitize($_POST['txtAck'])):'THE CHAIRPERSON';
		$amt=isset($_POST['txtAmt'])?strtoupper(sanitize($_POST['txtAmt'])):0;				$amt=preg_replace('/[^0-9\.]/','',$amt);
		$bno=isset($_POST['txtBursNo'])?strtoupper(sanitize($_POST['txtBursNo'])):0;		$burs=isset($_POST['txtBurs'])?strtoupper(sanitize($_POST['txtBurs'])):'0-0-0';
		$burs=preg_split('/\-/',$burs); //[0] Bursary Reciept(0-no,1-yes),[1] Mode (0-Cheque,1-Cash) and [2] Bursary votehead
		if($bno>0 && strlen($name)>8 && $po>0 && strlen($town)>3 && strlen($modeno)>2 && $amt>0 && strlen($ack)>3){
			$sql="UPDATE acc_burs SET SourceName=".var_export($name,true).",PytFrm='$mode',CheNo='$modeno',PytDate='$ron',Addressee='$ack',bankno=".var_export($bank,true).",branch=".
			var_export($branch,true).",po='$po',pocode=".var_export($code,true).",city='$town' WHERE bursno LIKE '$bno'";
			if(mysqli_query($conn,$sql) or die(mysqli_error($conn))) $action[1]=mysqli_affected_rows($conn);
			else $action[1]=0;
		}else $action[1]=0; $action[0]=1;  header("location:bursary.php?action=$action[0]-$action[1]");
	}elseif(isset($_POST['btnDelBursary'])){
		$bno=isset($_POST['txtBursNo'])?strtoupper(sanitize($_POST['txtBursNo'])):0;		$rmks=isset($_POST['txtDelReason'])?strtoupper(sanitize($_POST['txtDelReason'])):'';
		if(strlen($rmks)>10) if (mysqli_query($conn,"UPDATE acc_burs SET delreason=".var_export($rmks,true).",markdel=1 WHERE bursno LIKE '$bno'")){ $action[1]=mysqli_affected_rows($conn);
			//sql for cancelling related pv
			$sql="UPDATE acc_exppayee SET markdel=1 WHERE idno LIKE 'burs-$bno';UPDATE acc_exp e Inner Join acc_exppayee p on (e.expno=p.payno) SET e.markdel=1,e.delreason='Bursary cancelled because of ".var_export($rmks,true)."'
			WHERE p.idno LIKE 'burs-$bno' and e.commt=0; UPDATE acc_pytvotes v Inner Join acc_exp e USING (vono,acc) Inner Join acc_exppayee p on (e.expno=p.payno) SET v.markdel=1 WHERE e.commt=0 and p.idno LIKE 'burs-$bno';";
			//cancelling related receipt  and beneficiaries
			$sql.="UPDATE acc_incofee SET markdel=1, delreason='Bursary cancelled because of ".var_export($rmks,true)."' WHERE admno LIKE 'burs-$bno'; UPDATE acc_incorecno0 i Inner Join acc_incofee f USING (sno) SET
			i.markdel=1 WHERE f.admno LIKE 'burs-$bno'; UPDATE acc_incorecno1 i Inner Join acc_incofee f USING (sno) SET i.markdel=1 WHERE f.admno LIKE 'burs-$bno'; UPDATE acc_incovotes v SET markdel=1 WHERE (recno,acc) In
			(SELECT recno,acc FROM acc_incorecno0 i Inner Join acc_incofee f USING (sno) WHERE f.admno LIKE 'burs-$bno' UNION SELECT recno,acc FROM acc_incorecno1 i Inner Join acc_incofee f USING (sno) WHERE f.admno LIKE
			'burs-$bno');";
			$sql.="UPDATE acc_incofee SET markdel=1, delreason='Bursary cancelled because of ".var_export($rmks,true)."' WHERE bursno LIKE '$bno'; UPDATE acc_incorecno0 i Inner Join acc_incofee f USING (sno) SET
			i.markdel=1 WHERE f.bursno LIKE '$bno'; UPDATE acc_incorecno1 i Inner Join acc_incofee f USING (sno) SET i.markdel=1 WHERE f.bursno	LIKE '$bno'; UPDATE acc_incovotes SET markdel=1 WHERE (recno,acc) In (SELECT
			recno,acc FROM acc_incorecno0  i Inner Join acc_incofee f USING (sno) WHERE f.bursno LIKE '$bno' UNION SELECT recno,acc FROM acc_incorecno1 i Inner Join acc_incofee f USING (sno) WHERE f.bursno LIKE '$bno');";
			mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)." Click <a href=\"bursary.php\">HERE</a> to try again.");
			while(mysqli_next_result($conn)){;}
		}else $action[1]=0; $action[0]=2;  header("location:bursary.php?action=$action[0]-$action[1]");
	}
	$bn=isset($_REQUEST['bno'])?$_REQUEST['bno']:'0';
	mysqli_multi_query($conn,"SELECT bursdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT SourceName,PytFrm,CheNo,PytDate,Amt,Addressee,bankno,branch,po,pocode,
	city FROM acc_burs WHERE bursno LIKE '$bn';");	$del=0; 	$i=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0) list($del)=mysqli_fetch_row($rs);
			else list($bname,$pytfrm,$cheno,$pdate,$amt,$addr,$bank,$branch,$po,$code,$town)=mysqli_fetch_row($rs);
			mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
?>
<!DOCTYPE html>
<html>
	<head>
    	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" type="text/css" href="../date/tcal.css" />
		<script type="text/javascript" src="../date/tcal.js"></script><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>Bursaries</title>
    </head>
<body background="../gen_img/bg3.gif">
<span id="showBursary" style="border:1px groove #eee;border-radius:20px;background-color:#ffe;height:auto;overflow:auto;display:block;float:left;padding:10px;max-width:50%;"><form
method="post" action="bursaryedit.php" name="frmBursary" onsubmit="return validateData(this);">
<table class="h" style="padding:4px;font-weight:bold;left:200px;position:absolute;top:100px;" align="center"><tr class="nohover"><th colspan=4 style="padding:4px;border:0px;background:#333;
color:#fff;letter-spacing:3px;word-spacing:4px;font-weight:bold;font-size:11pt;">BURSARY EDITOR MANAGER</th></tr>
<tr class="nohover"><td class="h" style="padding:2px;" colspan=2>Bursary No.<br><input type="text" name="txtBursNo" id="txtBursNo" type="text" size=10 value="<?php echo $bn;?>"
readonly></td><td class="h" style="padding:2px;">Received On<br><input type="text" name="txtReceivedOn" id="txtReceivedOn" size=10 class="tcal" readonly value="<?php echo date('d-m-Y',
strtotime($pdate));?>"></td><td class="h" rowspan="5" valign="middle" style="padding:2px;"><button type="submit" name="btnSave" id="btnSave" style="min-width:100px;min-height:40px;">
Save Bursary<br>Changes</button><a href="bursary.php"></td></tr>
<tr class="nohover"><td class="h" style="padding:2px;" colspan=3>Bursary Name *<br><input type="text" type="text" name="txtName" id="txtName" size=80 maxlength=40 placeholder="NG CDF"
value="<?php echo $bname; ?>" style="text-transform:uppercase;letter-spacing:3px;word-spacing:4px;" required onkeyup="checkName(this)"></td></tr>
<tr class="nohover"><td class="h" style="padding:2px;">P.O Box *<br><input type="text" name="txtPO" id="txtPO" size=18 maxlength=5 value="<?php echo $po;?>" placeholder="440"
onkeyup="checkInput(this,1)" required></td><td class="h" style="padding:2px;">Postal Code<br><input type="text" name="txtPOCode" id="txtPOCode" size=12 maxlength=6 value="<?php echo $code;
?>" placeholder="50406" onkeyup="checkInput(this,1)"></td><td class="h" style="padding:2px;">Town/City *<br><input type="text" name="txtTown" id="txtTown" size=25 maxlength=25 value="<?php
echo $town; ?>" placeholder="Mumias" required></td></tr>
<tr class="nohover"><td class="h" style="padding:2px;">Received In *<br><Select name="cboMode" id="cboMode" size=1><option <?php echo (strcasecmp($po,'cheque')==0?"selected":"");?>>Cheque
</option><option <?php echo (strcasecmp($po,'direct banking')==0?"selected":"");?>>Direct Banking</option><option <?php echo (strcasecmp($po,'m-fees')==0?"selected":"");?>>M-Fees</option>
</SELECT></td><td class="h" style="padding:2px;">Trans/ Cheque No. *<br><input type="text" type="text" name="txtModeNo" id="txtModeNo" size=15 maxlength=15 required value="<?php
echo $cheno;?>" placeholder="0001245" style="text-transform:uppercase;"></td><td class="h" style="padding:2px;"> Acknowledgement Addressee *<br><input type="text" name="txtAck" id="txtAck"
size=25 maxlength=20 value="<?php echo $addr; ?>" required placeholder="The Chairperson"></td></tr>
<tr class="nohover"><td class="h" style="padding:2px;">Banker (If received in Cheque)<br><SELECT name="cboBank" id="cboBank" size=1><option value="0" selected>None</Option>
<?php $rs=mysqli_query($conn,"SELECT sno,`descr` FROM acc_banks WHERE markdel=0 ORDER BY `descr`");
while($d=mysqli_fetch_row($rs)) print "<option value=\"$d[0]\" ".($d[0]==$bank?"selected":"").">$d[1]</option>"; mysqli_free_result($rs);?></select></td><td class="h" style="padding:2px;">
Bank Branch<br><input type="text" name="txtBranch" id="txtBranch" size=15 maxlength=25 value="<?php echo $branch;?>" placeholder="Mumias"></td><td class="h" style="padding:2px;">Amount
Received *<br><input type="text" name="txtAmt" id="txtAmt" size=15 maxlength=10 value="<?php echo number_format($amt,2);?>" placeholder="0.00" readonly style="text-align:right;"
onkeyup="checkInput(this,0)" onblur="enableSave(this,<?php echo $add;?>)" required></td></tr><tr><td colspan=4><br>.<br><hr><br><br><P style="font-size:12pt;letter-spacing:3px;
word-spacing:4px;background:#000;color:#fff;">REASON FOR CANCELLATION OF BURSARY</p>
<textarea name="txtDelReason" id="txtDelReason" rows=2 cols=90 maxlength=140 placeholder="A BOUNCED CHEQUE" style="text-transform:uppercase;" onkeyup="enableDelete(this,<?php echo $del;
?>)"></TEXTAREA><br><br><button type="submit" style="left:10px;" class="cancelbtn" name="btnDelBursary" id="btnDelBursary" disabled>Delete this Bursary</button><br><br><hr><a
href="bursary.php"><button name="btnClose" type="button" style="min-width:100px;min-height:40px;float:right;">Close</button></a></td></tr></table></form>
<script type="text/javascript" src="tpl/js/bursary.js"></script>
</body></html>
