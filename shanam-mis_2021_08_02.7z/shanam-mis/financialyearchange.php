<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else {
		include_once('../conn/pri_sch_connect.inc');
		$rsYr=mysqli_query($conn,"SELECT finyr FROM ss"); list($finyr)=mysqli_fetch_row($rsYr); $cuyr=isset($finyr)?$finyr:date("Y");
		mysqli_free_result($rsYr);
	}
	 $yr=$cuyr+1;
	if (isset($_POST['CmdFeeBal'])){
		mysqli_query($conn,"Update class f Inner Join (SELECT s.admno, s.curr_year, (if(((s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-
		if(isnull(f.fee),0,f.fee))<=0,0,((s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee)))+if(((s.mt3f+ar.marbf+if(ar.acspemed!=1,
		ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,
		f.mfee)))) as bal FROM (SELECT c.admno,c.lvlno,c.curr_year,sum(if(v.acc=1,cf.T3,0)) as t3f,sum(if(v.acc!=1,cf.T3,0)) as mt3f FROM class c INNER JOIN clsfee cf USING (admno,curr_year)
		INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY c.admno,c.lvlno,
		c.curr_Year,a.stud_assoc HAVING a.stud_assoc=1 and c.curr_year=$cuyr)s INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.miscbf) as marbf,sum(c.spemed)
		as med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0
		end) as acunifrm FROM acc_votesassigned)x GROUP BY admno, markdel HAVING markdel=0)ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds))
		as ttl,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm)) as fee, if(isnull(sum(m.amt)),0,sum(m.amt)) as mttl,if(isnull(sum(m.amt)),0,sum(m.amt-
		m.arrears-m.spemed-m.unifrm)) as mfee FROM acc_incofee f LEFT JOIN acc_incorecno0 v USING (sno) Left Join acc_incorecno1 m USING (sno) GROUP BY f.admno,f.markdel HAVING
		f.markdel=0)f ON (s.admno=f.admno))t USING (admno,curr_year) SET f.bbf=t.bal, f.miscbf=0,f.alumniarrears=t.bal") or die(mysqli_error($conn)." Loading class eight balances failed.
		Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
		print "<b>Congratulations, ".mysqli_affected_rows($conn)." arrears have been updated</b><br>";
		mysqli_query($conn,"INSERT IGNORE INTO class SELECT s.admno,$yr,s.clsno,s.stream,s.lvlno,0,0,0,0,0,0,0,0 FROM (SELECT s.admno,sf.clsno, sf.stream,sf.curr_year,sf.lvlno
		FROM stud s Inner Join class sf USING (admno,curr_year) WHERE s.type=0 and s.markdel=0 and s.present=1 And sf.curr_year LIKE '$cuyr')s") or die(mysqli_error($conn).
		" No update took place. Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
		$i=mysqli_affected_rows($conn);
		if ($i>0) mysqli_multi_query($conn,"UPDATE stud SET curr_year=$yr WHERE (type=0 and markdel=0 and present=1 And curr_year LIKE '$cuyr' And admno IN (SELECT admno FROM class WHERE
		curr_year LIKE '$yr')); UPDATE stud SET type=1,present=0 WHERE curr_year='$cuyr';") or
		die(mysqli_error($conn)." No student academic year update took place. Click <a href=\"financialyearchange.php\">Here</a> to try again");
		print "<b>Congratulations, $i form one-three of $cuyr have been promoted to the next class.</b><br>";
		while(mysqli_next_result($conn)){;}//flush multi_queries
		mysqli_multi_query($conn,"Insert Ignore Into arch_clsfee SELECT admno,curr_year,voteno,t3,markdel FROM clsfee; Insert Ignore Into arch_feestruct SELECT yr,lvlno,voteno,t3 FROM
		acc_feestruct;UPDATE acc_feestruct SET yr=$yr; INSERT INTO arch_votes SELECT sno,$cuyr,abbr,descr,expabbr,expdescr,acc ,fs_defined,pyt_defined,`protected`,`orderno`,stud_fee,
		other_inco,markdel FROM acc_votes;") or die(mysqli_error($conn)." No update took place. Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
		while(mysqli_next_result($conn)){;}//flush multi_queries
		mysqli_multi_query($conn,"INSERT IGNORE INTO arch_incofee SELECT sno,$cuyr,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,addedby,markdel,kinddescr,delreason,commt,verno,verdate,
		verstate,verbanked FROM acc_incofee; INSERT IGNORE INTO arch_incorecno0 SELECT recno,$cuyr,recon,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm,transfer,markdel FROM	acc_incorecno0;
		INSERT IGNORE INTO acc_incoprep SELECT recno,acc,voteno,amt,markdel FROM acc_incoprep;DELETE FROM acc_incofee;") or die(mysqli_error($conn)." No update took place. Click <a href=\"javascript:history.go(0)\">
		Here</a> to try again");
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 2</p>";
		$step=2;
	}elseif (isset($_POST['CmdArchFeeStruct'])){
		mysqli_query($conn,"Insert Ignore Into Arch_feeoutline SELECT Curr_year,feegrp,lvl,Tui,Board,Act,ltt,rmi,ewc,exam,admincosts,adm,lib,Med,Pemol,olevies,MainT3,
		MisIdCard, MisQA,MisRemedial,MisHT,MisGrad,MisTrip,MisOle,MiscT3 FROM acc_feeoutline") or die(mysqli_error($conn)." No update took place. Click <a
		href=\"javascript:history.go(0)\">Here</a> to try again");
		$i=mysqli_affected_rows($conn);
		print "<b>Congratulations, $i fee structure declaration of $cuyr have been succesfully archived.</b><br>";
		mysqli_query($conn,"UPDATE acc_feeoutline SET curr_year=curr_year+1") or die(mysqli_error($conn)." No update took place. Click <a
		href=\"javascript:history.go(0)\">Here</a> to try again");
		$i=mysqli_affected_rows($conn);
		print "<b>Congratulations, $i fee structure declaration of $yr have been succesfully declared.</b><br>";
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 3</p>";
		$step=3;
	}elseif (isset($_POST['CmdArchReciepts'])){
		mysqli_multi_query($conn,"INSERT INTO arch_votes SELECT sno,$cuyr,fieldname,abbr,descr FROM acc_votes; INSERT IGNORE INTO Arch_alterincome SELECT code,
		$cuyr as yr,alt_names,telno,idno,paddress,email,serv_date,ac,rmks,product,voteno,addedby,markdel FROM acc_alterincome; DELETE FROM acc_alterincome;") or
		die(mysqli_error($conn)." Alternative Main A/C Reciepts not archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
		$i=mysqli_affected_rows($conn);
		while(mysqli_next_result($conn)){;}//flush multi_queries
		print "<b>Congratulations, $i alternative receipts of the financial year $yr have been succesfully archived.</b><br>";
		mysqli_query($conn,"INSERT IGNORE INTO Arch_feerec SELECT recieptno,$cuyr As yr,admno,pytdate,paidby,paytform,cmono,amt,pytno,bankcharges,tuition,boarding,
		activity,ltt,rmi,ewc,exam,admincosts,adm,lib,medical,pemolu,arrears,spemed,transport,refunds,olevy,prep,bank,addedby,markdel,kinddescr FROM acc_feerec") or
		die(mysqli_error($conn)." Main A/C Reciepts not archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try
		again");
		$i=mysqli_affected_rows($conn);
		print "<b>Congratulations, $i main account fee receipts of the financial year $cuyr have been succesfully archived.</b><br>";
		mysqli_query($conn,"INSERT IGNORE INTO Arch_miscfeepyts SELECT recipetno,$cuyr As yr,payeesno,pytdate,paidby,pytfrm,cheno,bursaryno,amt,bankcharges,qa,
		idcard,remedial,olevy,arrears,ht,uni,grad,acatrip,bank,kinddescr,addedby,markdel,mainrecno FROM acc_miscfeepyts") or die(mysqli_error($conn).
		" Miscellaneous A/C reciepts not archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
		$i=mysqli_affected_rows($conn);
		print "<b>Congratulations, $i miscellaneous account fee receipts of the financial year $cuyr have been succesfully archived.</b><br>";
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 4</p>";
		$step=4;
	}elseif (isset($_POST['CmdTransPrep'])){
	 	$rsRec=mysqli_query($conn,"SELECT max(recieptno) as mre FROM acc_feerec"); if(mysqli_num_rows($rsRec)==1) list($recno)=mysqli_fetch_row($rsRec);
		else $recno=1; mysqli_free_result($rsRec);
		$rsRec=mysqli_query($conn,"SELECT max(recipetno) as mre FROM acc_miscfeepyts"); if(mysqli_num_rows($rsRec)==1) list($mrecno)=mysqli_fetch_row($rsRec);
		else $mrecno=1; mysqli_free_result($rsRec);
		mysqli_multi_query($conn,"DELETE FROM acc_feerec; DELETE FROM acc_miscfeepyts;DELETE FROM acc_prep;INSERT IGNORE INTO acc_feerec (recieptno,admno,pytdate)
		values ('$recno','aaaa','$cuyr-12-31');INSERT IGNORE INTO acc_miscfeepyts (recieptno,payeesno,pytdate) values ('$mrecno','aaaa','$cuyr-12-31')") or
		die(mysqli_error($conn)." fee reciept records not deleted. Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
	 	while(mysqli_next_result($conn)){;}//flush multi_queries
		mysqli_query($conn,"INSERT INTO Acc_feerec (admno,pytdate,paidby,paytform,pytno,cmono,amt,tuition,bank,addedby,kinddescr) SELECT admno,'$yr-01-01' As pyt,
		paidby,paytform,pytno,cmono,prep,prep,bank,'As Prepayment' As addedby,kinddescr FROM arch_feerec WHERE markdel=0 And prep>0 and yr=$cuyr") or
		die(mysqli_error($conn)." Prepayments were not fowarded. Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
		$i=mysqli_affected_rows($conn);
	 	print "<b>Congratulations, $i prepayments of the financial year $cuyr have been succesfully moved to next financial year.</b><br>";
	 	print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 5</p>";
		$step=5;
	}elseif (isset($_POST['CmdComputeComts'])){
	 	mysqli_query($conn,"INSERT IGNORE INTO arch_stf SELECT idno,$cuyr as yr FROM stf WHERE type=0") or die(mysqli_error($conn)." staff details not
		archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try again"); $a=mysqli_affected_rows($conn);
		mysqli_query($conn,"UPDATE stf SET type=1,st_status=0,markdel=0 WHERE markdel=1 OR type=1");
		print "<b>Congratulations, $a staff in the financial year $cuyr have been succesfully archived.</b><br>";
		mysqli_multi_query($conn,"INSERT INTO arch_uniforms SELECT unifrmno,$cuyr as yr,uname,unitsale,amt,addedby,markdel FROM uniforms; INSERT INTO
		arch_unifrmpurchase SELECT purchno, $cuyr as yr,admno,purchasedon,addedby, markdel FROM unifrmpurchase; INSERT INTO arch_unipurchdetails SELECT purchno,
		$cuyr as yr,unifrmno,purchdate,qty,markdel FROM unipurchdetails; DELETE FROM unifrmpurchase;") or die(mysqli_error($conn)." There was an error in
		archiving uniform details");
		while(mysqli_next_result($conn)){;}//flush multi_queries
		mysqli_query($conn,"INSERT IGNORE INTO arch_sup SELECT supid,$cuyr as yr,name,regdate,telno,paddress,email,location,idno,active,addedby,markdel
		FROM Acc_sup") or die(mysqli_error($conn)." Suppliers' details not archived");
		$i=mysqli_affected_rows($conn);
		if ($i>0) mysqli_query($conn,"INSERT IGNORE INTO arch_supitems SELECT itmcode,$cuyr as yr,supno,markdel FROM Acc_supitems") or die(mysqli_error($conn).
		" Suppliers' details not archived");
		$i=mysqli_affected_rows($conn);
		print "<b>Congratulations, $i suppliers' details of the financial year $cuyr have been succesfully archived.</b><br>";
		//Requisition and LPO Archiving
		mysqli_query($conn,"INSERT IGNORE INTO arch_req SELECT reqno,$cuyr as yr,reqdate,idno,deptno,rmks,reqtype,forwarddate,forwardby,forwardrmks,forwarded,
		approvedate,approvedby,approvedrmks,approved,served,markdel FROM Acc_req") or die(mysqli_error($conn)." Requisition details not archived. Click
		<a href=\"javascript:history.go(0)\">Here</a> to try  again");
		if (mysqli_affected_rows($conn)>0){
		 	mysqli_multi_query($conn,"INSERT IGNORE INTO arch_reqitems SELECT itmno,$cuyr as yr,reqno,unitprice,qty,approvedup,
			approvedqty,markdel FROM Acc_reqitems; INSERT INTO arch_reqrej SELECT rejno,$cuyr as yr,reqno,req_date,rmks,addedby,markdel FROM acc_reqrej;") or
			die(mysqli_error($conn)." Requisition items' details not archived");
			while(mysqli_next_result($conn)){;}//flush multi_queries
		}
		mysqli_query($conn,"INSERT IGNORE INTO arch_imp SELECT impno,$cuyr as yr,cudate,idno,amt,rmks,approvedby,status,vno,reqno,markdel FROM Acc_imp")
		or die(mysqli_error($conn)." Imprest details not archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try again.");
		$a=mysqli_affected_rows($conn);
		print "<b>Congratulations, $a Imprests of the financial year $cuyr have been succesfully archived.</b><br>";
		mysqli_query($conn,"INSERT IGNORE INTO arch_lpo SELECT lpono,$cuyr as yr,supid,acno,raisedon,descr,voteno,addedby,status,markdel,reqno,approvedon,
		approvedby FROM Acc_lpo") or die(mysqli_error($conn)." LPO details not archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try again");
		$i=mysqli_affected_rows($conn);
		if ($i>0){//if there are LPOs then we have deliveries and invoices to backup
			mysqli_query($conn,"INSERT IGNORE INTO arch_lpoitems SELECT lpono,$cuyr as yr,itmcode,up,qty,approvedup,approvedqty,markdel FROM Acc_lpoitems") or
			die(mysqli_error($conn)." LPO items' details not archived");
			mysqli_query($conn,"INSERT IGNORE INTO arch_del SELECT serialno,$cuyr as yr,delnoteno,lpono,del_date,descr,cleared,addedby,markdel FROM Acc_del") or
			die(mysqli_error($conn)." suppplier deliveries not archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try  again");
			$a=mysqli_affected_rows($conn);
			if ($a>0) mysqli_query($conn,"INSERT IGNORE INTO arch_delitems SELECT itmcode,$cuyr as yr,serialno,qty,markdel FROM Acc_delitems") or
			die(mysqli_error($conn)." Delivery items' details not archived");
			mysqli_query($conn,"INSERT IGNORE INTO arch_invoice SELECT serialno,$cuyr as yr,inv_no,supid,lpono,inv_date,cleared,addedby,markdel FROM
			Acc_Invoice") or die(mysqli_error($conn)." Invoices not archived. Click <a href=\"javascript:history.go(0)\">Here</a> to try  again");
			$a=mysqli_affected_rows($conn);
			if ($a>0) mysqli_query($conn,"INSERT IGNORE INTO arch_invitems SELECT itmcode,$cuyr as yr,serialno,qty,up,markdel FROM Acc_invitems") or
			die(mysqli_error($conn)." Delivery items' details not archived");
			//update sundry creditors in the system
			mysqli_multi_query($conn,"INSERT IGNORE INTO acc_creditors SELECT supid,lpono,$cuyr as yr,bal FROM (SELECT i.supid,i.lpono,(sum(p.qty*p.up)-
			if(isnull(e.ttl),0,e.ttl)) as bal FROM acc_invoice i Inner Join acc_invitems p USING (serialno) LEFT JOIN (SELECT lpono,sum(caamt+chamt) as ttl
			FROM acc_exp GROUP BY lpono,markdel HAVING lpono is not null and markdel=0)e On (i.lpono=e.lpono) GROUP BY i.supid, i.lpono,i.markdel HAVING
			i.markdel=0)b Where bal>0; INSERT IGNORE INTO arch_creditors SELECT supid,lpono,$cuyr as yr,bal FROM (SELECT i.supid,i.lpono,(sum(p.qty*p.up)-
			if(isnull(e.ttl),0,e.ttl)) as bal FROM acc_invoice i Inner Join acc_invitems p USING (serialno) LEFT JOIN (SELECT lpono,sum(caamt+chamt) as ttl
			FROM acc_exp GROUP BY lpono,markdel HAVING lpono is not null and markdel=0)e On (i.lpono=e.lpono) GROUP BY i.supid, i.lpono,i.markdel HAVING
			i.markdel=0)b Where bal>0") or die(mysqli_error($conn)." Sundry creditors' details not archived");
			while(mysqli_next_result($conn)){;}//flush multi_queries
		}
		print "<b>Congratulations, $i supplier deliveries of the financial year $cuyr have been succesfully archived.</b><br>";
		mysqli_query($conn,"INSERT IGNORE INTO arch_exp SELECT voucherno,$cuyr as yr,pytdate,payee,idno,address,telno,acc,payform,chequeno,caamt,chamt,rmks,
		addedby,markdel,lpono,commt FROM Acc_exp;") or die(mysqli_error($conn)." suppplier deliveries not archived");
		if ($i>0) mysqli_multi_query($conn,"INSERT IGNORE INTO arch_misexp SELECT voucherno,$cuyr as yr,Datepyt,Acc,QA,ID,remedial,Arrears,HT,Uniform,Olevy,
		MarkDel FROM Acc_misexp; INSERT IGNORE INTO arch_mainexp SELECT voucherno,$cuyr as yr,Datepyt,Acc,tui,boa,act,ltt,rmi,ewc,exa,admincosts,adm,lib,med,pem,
		arr,trans,ocosts,MarkDel FROM Acc_mainexp;") or die(mysqli_error($conn)." Expenditure voteheads not archived. Click <a href=\"javascript:history.go(0)\">
		Here</a> to try again");
		while(mysqli_next_result($conn)){;}//flush multi_queries
		mysqli_multi_query($conn,"DELETE FROM acc_sup WHERE supid NOT IN (SELECT suppid FROM Acc_creditors WHERE amt>0);DELETE FROM acc_lpo; DELETE FROM Acc_imp
		WHERE state=1 or markdel=1; Delete FROM acc_req; DELETE FROM acc_exp;");
		while(mysqli_next_result($conn)){;}//flush multi_queries
		print "<b>Congratulations, $i expenditure/ payments of the financial year $cuyr have been succesfully archived.</b><br>";
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 6</p>";
		$step=6;
	}elseif (isset($_POST['CmdPocketMoney'])){
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 7</p>";
		$step=7;
	}elseif (isset($_POST['CmdInterborrow'])){

		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 8</p>";
		$step=8;
	}elseif(isset($_POST['CmdArchStf'])){
		print "<p font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 9</p>";
		$step=9;
	}elseif(isset($_POST['CmdArchSal'])){
		mysqli_query($conn,"INSERT IGNORE INTO arch_saldef SELECT payrollno,$cuyr as yr,idno,salsource,bankname,accountno,bsal,nssffee,nssfvol,nhiffee,
		saccofee,welfare,otherlevies,houseallow,medicalallow,travellallow,empnssf,paye,mpr,unionfee,helb,bankbranch,addedby,markdel,nssfno,nhifno,unionno,
		saccono,welfareno FROM Acc_saldef") or die(mysqli_error($conn)." Salary definition details were not archived. Click <a href=\"javascript:history.go(0)\">
		Here</a> to try again");	$i=mysqli_affected_rows($conn);
		print "<b>Congratulations, $i salary definition of the financial year $cuyr have been succesfully archived.</b><br>";
		$rsAdv=mysqli_query($conn,"SELECT a.advno,a.payrollno,a.adv_date,(a.amt-if(isnull(c.ded),0,c.ded)) as advamt,a.authorisedby,a.rmks,a.duration,
		a.amtperduration,a.addedby,a.markdel,a.issued FROM acc_adv a LEFT JOIN (SELECT advano,sum(amt_clr) as ded FROM acc_advclr GROUP BY advano,markdel Having
		markdel=0)c On (a.advno=c.advano) WHERE (a.amt-if(isnull(c.ded),0,c.ded))>0");
		mysqli_query($conn,"INSERT IGNORE INTO arch_advreq SELECT reqno,$cuyr as yr,payrollno,reqdate,rmks,amt,ded_period,amtperded,adv_status,addedby,markdel
		FROM Acc_advreq") or die(mysqli_error($conn)." Salary advance details were not archived. Click <a
		href=\"javascript:history.go(0)\">Here</a> to try again");		$a=mysqli_affected_rows($conn);
		if ($a>0){
			mysqli_multi_query($conn,"INSERT IGNORE INTO arch_adv SELECT advno,$cuyr as yr,payrollno,advreqno,adv_date,amt,authorisedby,rmks,duration,
			amtperduration,addedby,markdel,issued FROM Acc_adv; INSERT INTO arch_advrej SELECT rejno,$cuyr as yr,advreqno,rej_date,rmks,addedby,markdel FROM
			acc_advrej; INSERT IGNORE INTO arch_advclr SELECT clrno,advano,sal_month,sal_year,clr_date,amt_clr,clr_form,rmks,markdel FROM Acc_advclr;DELETE FROM
			acc_advreq;DELETE FROM acc_adv;") or die(mysqli_error($conn)." Salary advance clearance details were not archived. Click <a
			href=\"javascript:history.go(0)\">Here</a> to try again");
			while(mysqli_next_result($conn)){;}//flush multi_queries
			print "<b>Congratulations, $a salary advances of the financial year $cuyr have been succesfully archived.</b><br>"; $sql="";
			if (mysqli_num_rows($rsAdv)>0) while (list($adno,$pno,$add,$am,$ab,$rk,$du,$ap,$adb,$mk,$ast)=mysqli_fetch_row($rsAdv)) $sql.="INSERT INTO Acc_Adv
			VALUES ('$adno','$pno',null,'$add','$am','$ab','$rk','$du','$ap','$adb','$mk','$ast');";
			mysqli_multi_query($conn,$sql);	mysqli_free_result($rsAdv);
			while(mysqli_next_result($conn)){;}//flush multi_queries
		}
		mysqli_query($conn,"DELETE FROM acc_saldef WHERE markdel=1");
		print "<b>Congratulations, $a salary payments of the financial year $cuyr have been succesfully archived.</b><br>";
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 10</p>";
		$step=10;
	}elseif(isset($_POST['CmdArchBudg'])){
		mysqli_query($conn,"INSERT IGNORE INTO arch_budget SELECT sno,$cuyr as yr,voteno,ac,budg_date,markdel,addedby FROM Acc_budget") or
		die(mysqli_error($conn)." Budget details were not archived");
		$a=mysqli_affected_rows($conn); if ($a>0) mysqli_multi_query($conn,"INSERT IGNORE INTO arch_budgitms SELECT budgno,sno,$cuyr as yr,itmcode,prevqty,prevup,
		qty,up FROM acc_budgitms; UPDATE acc_budget SET budg_date=curdate(); UPDATE acc_budgitms SET prevqty=qty,prevup=up;");
		print "<b>Congratulations, $a budget of the financial year $cuyr have been succesfully archived.</b><br>";
		mysqli_multi_query($conn,"INSERT IGNORE INTO arch_logt SELECT logno,$cuyr as yr,username,login_date,logout_date FROM logt; INSERT IGNORE INTO
		arch_useractions SELECT taskno,$cuyr as yr,actiondate,logno,recordno,reason,recdate,pytfrm,chequeno,origamt,curramt,useraction,markdel FROM useractions;
		DELETE FROM logt;") or die(mysqli_error($conn)." User login were not archived");
		$a=mysqli_affected_rows($conn);
		while(mysqli_next_result($conn)){;}//flush multi_queries
		print "<b>Congratulations, $a useractions of the financial year $cuyr have been succesfully archived.</b><br>";
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">Next is Step 11</p>";
		$step=11;
	}elseif(isset($_POST['CmdArchBurs'])){
	 	$rsBurs=mysqli_query($conn,"SELECT b.paymentno,f.ttl FROM acc_burs b INNER JOIN (SELECT pytno,sum(amt) as ttl From Acc_feerec Group by pytno having
		pytno is not null)f On (b.paymentno=f.pytno)");
		mysqli_query($conn,"INSERT IGNORE INTO arch_burs SELECT paymentno,$cuyr as yr,sourcename,paytfrm,chequeno,pytdate,amount,bankcharge,addedby,addressee,
		bank,branch,po,pocode,city,markdel,status FROM Acc_burs") or die(mysqli_error($conn)." Bursary details were not archived. Click <a
		href=\"javascript:history.go(0)\">Here</a> to try again");
		$a=mysqli_affected_rows($conn); if ($a>0) mysqli_query($conn,"DELETE FROM acc_burs WHERE paymentno NOT IN (SELECT DISTINCT pytno FROM acc_feerec)");
		$sql="";	print "<b>Congratulations, $a bursaries of the financial year $cuyr have been succesfully archived.</b><br>";
		if (mysqli_num_rows($rsBurs)>0){
			while (list($pn,$am)=mysqli_fetch_row($rsBurs)) $sql.="UPDATE acc_burs SET amount='$am' WHERE paymentno LIKE '$pn'; ";
			mysqli_multi_query($conn,$sql);
			while(mysqli_next_result($conn)){;}//flush multi_queries
		} 	mysqli_free_result($rsBurs);
		mysqli_query($conn,"UPDATE ss SET finyr='$yr',sysdate='$yr-12-31'")or die(mysqli_error($conn)." Financial year has not been update. Click <a
		href=\"javascript:history.go(0)\">Here</a> to try again");
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;\">Congratulations, you have succcessfully moved to ".($cuyr+1)." financial year.
		Click <a href=\"start.php\">HERE</a> to proceed using the system</p>";
		$step=12;
	}else{
		print "<p style=\"font-size:12px;font-color:#00ff44;text-align:center;text-weight:bold;\">This is Step 1</p>";
		$step=1;
	}

?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Financial Year Change</title>
	<script type="text/javascript">
		function disable_cmd(){
			var step=<?php print $step;?>;
			if (step<13){
				for (var i=1;i<13;i++){
					if (i==step){
					 	document.getElementById("Cmd"+i).disabled=false;
					}else{
					 	 document.getElementById("Cmd"+i).disabled=true;
					}
				}
			}else{
				alert ("Congratulations you have successfully moved to next final year "+<?php print ($cuyr+1); ?>);
			}
		}
	</script>
</head>
<body background="img/bg3.gif" onload="disable_cmd()">
	<form method="post" action="FinancialYearChange.php">
	<table border="1" cellspacing="0" cellpadding="2" align="center"><tr><td align="center" style="letter-spacing:2px;word-spacing:3px;text-size:12px;"><b>
	STUDENT AND INCOME RECEIPT DETAILS </b></td></tr><tr><td align="center">
		<table border="0" cellspacing="0" cellpadding="2" width="100%" style="text-size:12px;"><tr><td align="center">Step 1</td><td align="center">Step 2</td>
		</tr><tr><td><button name="CmdFeeBal" type="submit" id="Cmd1" style="text-size:12px;">Update Fees Balance</button></td><td><button
		name="CmdArchFeeStruct" type="submit" id="Cmd2" style="text-size:12px;">Archive Fee Structures</button></td></tr>
		<tr><td align="center">Step 3</td><td align="center">Step 4</td></tr><tr><td><button name="CmdArchReciepts" type="submit" id="Cmd3"
		style="text-size:12px;">Archive Fee Receipts</button></td><td><button name="CmdTransPrep" type="submit" id="Cmd4" style="text-size:11px;">Transfer
		Prepayments</button></td></tr></table>
	</td></tr><tr><td align="center" style="letter-spacing:2px;word-spacing:3px;"><b>IMPRESTS AND PAYMENTS/ EXPENDITURES</b></td></tr><tr><td align="center">
		<table border="0" cellspacing="0" cellpadding="2" width="100%"  style="text-size:12px;"><tr><td align="center">Step 5</td><td align="center">Step 6</td>
		</tr><tr><td><button name="CmdComputeComts" type="submit" id="Cmd5" style="text-size:11px;">Compute Commitment<br>Payment Balances</button></td><td>
		<button name="CmdPocketMoney" type="submit" id="Cmd6" style="text-size:11px;">Archive Pocket Money</button></td></tr>
		<tr><td align="center" colspan="2">Step 7</td></tr><tr><td colspan="2"><button name="CmdInterborrow" type="submit" id="Cmd7" style="text-size:11px;">
		Archive Interborrowings</button></td></td></tr></table>
	</td></tr><tr><td align="center" style="letter-spacing:2px;word-spacing:3px;"><b>BURSARIES, SALARIES, AND BUDGETS</b></td></tr><tr><td align="center">
		<table border="0" cellspacing="0" cellpadding="2" width="100%" style="text-size:12px;"><tr><td align="center">Step 8</td><td align="center">Step 9</td>
		</tr><tr><td><button name="CmdArchStf" type="submit" id="Cmd8" style="text-size:11px;">Archive Staff Details</button></td><td><button name="CmdArchSal"
		type="submit" id="Cmd9" style="text-size:11px;">Archive Salary Details</button></td></tr>
		<tr><td align="center">Step 10</td><td align="center">Step 11</td></tr><tr><td><button name="CmdArchBudg" type="submit" id="Cmd10"
		style="text-size:11px;">Archive Budget Details</button></td><td><button name="CmdArchBurs" type="submit" id="Cmd11" style="text-size:11px;">Archive
		Bursary Details</button></td></tr></table></td></tr>
	</form>
</body>
</html>
