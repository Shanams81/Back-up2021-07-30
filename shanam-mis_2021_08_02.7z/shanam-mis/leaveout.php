<?php
	include_once('shanam.php');
	function balSQL($lno,$lvl,$cls,$bal,$date,$yr,$m){
		$sql="SELECT $lno,s.admno,(if(isnull(f.ttl),0,f.ttl)+if(isnull(f.mttl),0,f.mttl)) as paid,";
		if ($m==1) $sql.="(if(((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-
		if(isnull(f.fee),0,f.fee)))+if(((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,
		ar.uni,0))-if(isnull(f.mfee),0,f.mfee)))) as bal FROM (SELECT c.admno,c.lvlno,sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc!=1,cf.T1,0)) as mt1f ";
		elseif($m==2) $sql.="(if(((s.t2f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t2f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-
		if(isnull(f.fee),0,f.fee)))+if(((s.mt2f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt2f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-
		if(isnull(f.mfee),0,f.mfee)))) as bal FROM (SELECT c.admno,c.lvlno,sum(if(v.acc=1,cf.T2,0)) as t2f,sum(if(v.acc!=1,cf.T2,0)) as mt2f ";
		else $sql.="(if(((s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,
		f.fee)))+if(((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),
		0,f.mfee)))) as bal FROM (SELECT c.admno,c.lvlno,sum(if(v.acc=1,cf.T3,0)) as t3f,sum(if(v.acc!=1,cf.T3,0)) as mt3f";
		$sql.=" FROM class c INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY c.admno,c.lvlno,c.curr_Year,a.stud_assoc,c.clsno HAVING
		a.stud_assoc=1 and c.curr_year=$yr and c.lvlno LIKE '$lvl' and c.clsno LIKE '$cls')s INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.miscbf) as marbf,sum(c.spemed)	as med,sum(c.unifrm) as uni,x.acspemed,
		x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0	end) as acunifrm FROM acc_votesassigned)x GROUP BY admno, markdel HAVING
		markdel=0)ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds)) as ttl,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm)) as fee,
		if(isnull(sum(m.amt)),0,sum(m.amt)) as mttl,if(isnull(sum(m.amt)),0,sum(m.amt-m.arrears-m.spemed-m.unifrm)) as mfee FROM acc_incofee f LEFT JOIN acc_incorecno0 v USING (sno) Left Join acc_incorecno1 m USING (sno)
		GROUP BY f.admno,f.markdel HAVING	f.markdel=0)f ON (s.admno=f.admno) WHERE ";
		if ($m==1) $sql.="(if(((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),
		0,f.fee)))+if(((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),
		0,f.mfee))))>$bal";
		elseif($m==2) $sql.="(if(((s.t2f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t2f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),
		0,f.fee)))+if(((s.mt2f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt2f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),
		0,f.mfee))))>$bal";
		else $sql.="(if(((s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,
		f.fee)))+if(((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),
		0,f.mfee))))>$bal"; return $sql;
	} $sdate=isset($_POST['dtpDate1'])?sanitize($_POST['dtpDate1']):'01-01-'.date("Y");	$edate=isset($_POST['dtpDate2'])?sanitize($_POST['dtpDate2']):date("d-m-Y");
	$lvl=isset($_POST['cboLvl'])?sanitize($_POST['cboLvl']):"%"; $sno=[0,0];
	mysqli_multi_query($conn,"SELECT leaveoutadd,leaveoutcancel FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT finyr FROM ss; SELECT lvlno,lvlname FROM classlvl order by lvlno asc; SELECT tno FROM
	terms inner Join ss USING (finyr) WHERE curdate() between starts and ends; SELECT c.clsno,concat(l.lvlabbr,' - ',c.clsname) as cls,lvlno FROM classnames c Inner JOin classlvl l USING (lvlno)"); $add=$del=$i=$trm=0;
	$optlvl=$optcls=$lstcls='';
	do{if($rs=mysqli_store_result($conn)){
			if($i==0){list($add,$del)=mysqli_fetch_row($rs);}elseif($i==1){list($yr)=mysqli_fetch_row($rs);}
			elseif($i==2){while(list($n,$nm)=mysqli_fetch_row($rs)){$optlvl.="<option value=\"$n\">$nm</option>"; if(strcasecmp($lvl,"%")!=0 && $lvl==$n) $optName=$nm;}}
			elseif($i==3){list($trm)=mysqli_fetch_row($rs);}else{$c=0;while($d=mysqli_fetch_row($rs)){$optcls.="<option value=\"$d[0]\">$d[1]</option>"; $lstcls.=($c==0?"":",")."new LstClass($d[0],'$d[1]',$d[2])"; $c++;}}
			mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	if(isset($_POST['btnSave'])){
		$pon=isset($_POST['txtProcessedOn'])?sanitize($_POST['txtProcessedOn']):date('d-m-Y'); 	$pon=explode('-',$pon); $pon="$pon[2]-$pon[1]-$pon[0]";
		$lon=isset($_POST['txtLeaveOn'])?sanitize($_POST['txtLeaveOn']):date('d-m-Y'); 					$lon=explode('-',$lon);	$lon="$lon[2]-$lon[1]-$lon[0]";
		$ron=isset($_POST['txtReturnOn'])?sanitize($_POST['txtReturnOn']):date('d-m-Y'); 				$ron=explode('-',$ron);	$ron="$ron[2]-$ron[1]-$ron[0]";
		$lvl=isset($_POST['cboLvl'])?sanitize($_POST['cboLvl']):'%';$lvl=($lvl=='%'?null:$lvl); $bal=isset($_POST['txtBal'])?sanitize($_POST['txtBal']):0;
		$tkn=isset($_POST['txtTkn'])?sanitize($_POST['txtTkn']):0; $bal=preg_replace('/[^0-9\.]/','',$bal); $cls=isset($_POST['cboCls'])?sanitize($_POST['cboCls']):'%';$cls=($cls=='%'?null:$cls);
		if ($bal>0 && (strtotime($ron)>strtotime($lon)) && $_SESSION['leaveoutSess']==$tkn){
			mysqli_query($conn,"INSERT INTO acc_leaveout(sno,preparedon,leavedate,returndate,lvlno,clsno,minbal,addedby) VALUES(0,'$pon','$lon','$ron',".var_export($lvl,true).",".var_export($cls,true).",$bal,
			'".$_SESSION['username']." (".$_SESSION['priviledge'].")');") or die(mysqli_error($conn).". Leaveout session not successfully saved. Click <a href=\"leaveout.php\">HERE</a>
			to go back."); $sno[1]=mysqli_affected_rows($conn);	$lvl=is_null($lvl)?"%":$lvl;$cls=is_null($cls)?"%":$cls; unset($_SESSION['leaveoutSess']);
			if($sno[1]>0){ $rs=mysqli_query($conn,"SELECT last_insert_id()"); list($lno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
				$sql=balSQL($lno,$lvl,$cls,$bal,$pon,$yr,$trm); mysqli_query($conn,"INSERT IGNORE INTO acc_leaveoutstud(sno,admno,paid,bal) $sql;");
			}
		}else $sno[1]=0; $sno[0]=1;
	}elseif(isset($_POST['btnSessionSaveEdit'])){
		$pon=isset($_POST['txtProcessedOn1'])?sanitize($_POST['txtProcessedOn1']):date('d-m-Y');$pon=explode('-',$pon); $pon="$pon[2]-$pon[1]-$pon[0]";
		$lon=isset($_POST['txtLeaveOn1'])?sanitize($_POST['txtLeaveOn1']):date('d-m-Y'); 				$lon=explode('-',$lon);	$lon="$lon[2]-$lon[1]-$lon[0]";
		$ron=isset($_POST['txtReturnOn1'])?sanitize($_POST['txtReturnOn1']):date('d-m-Y'); 			$ron=explode('-',$ron);	$ron="$ron[2]-$ron[1]-$ron[0]";
		$lvl=isset($_POST['cboLvl1'])?sanitize($_POST['cboLvl1']):'%';	$bal=isset($_POST['txtBal1'])?sanitize($_POST['txtBal1']):0;	$lvl=($lvl=='%'?null:$lvl);
		$orig=isset($_POST['txtOBal1'])?sanitize($_POST['txtOBal1']):0;	$bal=preg_replace('/[^0-9\.]/','',$bal);	$orig=preg_replace('/[^0-9\.]/','',$orig);
		$lno=isset($_POST['txtSNo1'])?sanitize($_POST['txtSNo1']):0; $tkn=isset($_POST['txtTkn1'])?sanitize($_POST['txtTkn1']):0; $cls=isset($_POST['cboCls1'])?sanitize($_POST['cboCls1']):'%';$cls=($cls=='%'?null:$cls);
		if ($bal>0 && (strtotime($ron)>strtotime($lon)) && $lno>0  && $_SESSION['leaveoutSess']==$tkn){
			if (mysqli_query($conn,"UPDATE acc_leaveout SET preparedon='$pon',leavedate='$lon',returndate='$ron',lvlno=".var_export($lvl,true).",clsno=".var_export($cls,true).",minbal=$bal WHERE sno LIKE '$lno'")){
				$sno[1]=mysqli_affected_rows($conn); unset($_SESSION['leaveoutSess']);
				if($bal>$orig){mysqli_query($conn,"DELETE FROM acc_leaveoutstud WHERE sno LIKE '$lno' and bal<$bal"); //Remove student with less balance after review
				}elseif($bal<$orig){$sql=balSQL($lno,$lvl,$cls,$bal,$pon,$yr,$trm); mysqli_query($conn,"INSERT IGNORE INTO acc_leaveoutstud(sno,admno,paid,bal) $sql;") or die(mysqli_error($conn));}//add more students with balances
			}
		}else $sno[1]=0; $sno[0]=1;
	}elseif(isset($_POST['btnDelLeave'])){//delete entire session
		$lno=isset($_POST['txtSNo1'])?sanitize($_POST['txtSNo1']):0; $rmks=isset($_POST['txtDelReason'])?strtoupper(sanitize($_POST['txtDelReason'])):'';	$tkn=isset($_POST['txtTkn1'])?sanitize($_POST['txtTkn1']):0;
		if(strlen($rmks)>9  && $_SESSION['leaveoutSess']==$tkn){
			mysqli_multi_query($conn,"UPDATE acc_leaveout SET markdel=1,delreason='$rmks' WHERE sno LIKE '$lno';DELETE FROM acc_leaveoutstud WHERE sno LIKE '$lno'");
			$sno[1]=mysqli_affected_rows($conn);  unset($_SESSION['leaveoutSess']);
		} $sno[0]=2;
	}elseif (isset($_POST['btnDel'])){//Deleting student leaveout
		$sno=isset($_POST['txtDet'])?sanitize($_POST['txtDet']):"0-0"; $sno=explode('-',$sno); //[0] sno and [1] admno
		$reason=isset($_POST['txtReason'])?strtoupper(sanitize($_POST['txtReason'])):""; $tkn=isset($_POST['txtTkn2'])?sanitize($_POST['txtTkn2']):0;
		if (strlen($reason)>10 && $_SESSION['leaveoutSess']==$tkn){
			mysqli_query($conn,"UPDATE acc_leaveoutstud SET status=1,delreason='$reason' WHERE sno LIKE '$sno[0]' and admno LIKE '$sno[1]'"); $sno[1]=mysqli_affected_rows($conn); unset($_SESSION['leaveoutSess']);
		}else $sno[0]=0; 	$sno[1]=2;
	}elseif(isset($_REQUEST['leaveoutRestore'])){
		$sno=isset($_REQUEST['leaveoutRestore'])?strip_tags($_REQUEST['leaveoutRestore']):'0-0'; $sno=explode('-',$sno); //[0] sno ans [1] admno
		mysqli_query($conn,"UPDATE acc_leaveoutstud SET status=0,delreason=null WHERE sno LIKE '$sno[0]' and admno LIKE '$sno[1]'") or die(mysqli_error($conn)); $sno[1]=mysqli_affected_rows($conn); $sno[0]=1;
	} else{$sno=isset($_REQUEST['sno'])?sanitize($_REQUEST['sno']):'0-0'; $sno=explode('-',$sno);} $_SESSION['leaveoutSess']=$tkn=uniqid();
	headings('<link href="tpl/css/inputsettings.css" rel="stylesheet"/><link href="tpl/css/headers.css" rel="stylesheet"/><link rel="stylesheet" href="tpl/css/modalfrm.css"/>
	<link href="/date/tcal.css" rel="stylesheet"/>',$sno[0],$sno[1],2);
?><div class="head"><form method="post" action="leaveout.php" name="frmFind"><a href="pupil_manager.php"><img src="/gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left">
	</a>&nbsp;Fee Leaveout Sessions Between <input name="dtpDate1" id="dtpDate1" class="tcal" type="text" value="<?php echo $sdate;?>" readonly size=8> And <input name="dtpDate2"
	id="dtpDate1" class="tcal" type="text" value="<?php echo $edate;?>" readonly size="8">  In  <select name="cboLvl" size=1 id="cboLvl"><option value="%" selected>All</Option>
	<?php echo $optlvl; ?></select>&nbsp;&nbsp;<button type="submit" accesskey="s" name="Show">View Leaveout Sessions</button></form>
</div>
<div class="container" style="border:1px groove #00e;border-radius:20px;background-color:#e6e6e6;width:100%;"><div class="form-row">
	<div class="col-md-6" id="showLeaveouts"><form method="post" action="leaveout.php" name="frmLeaveout" onsubmit="return validateData(this);">
	<div class="form-row"><div class="col-md-12 divheadings">NEW LEAVEOUT SESSION DETAILS</div></div>
	<div class="form-row" style="border:1px solid #666;"><div class="col-md-9"><input type="hidden" name="txtTkn" value="<?php echo $tkn;?>">
			<div class="form-row"><div class="col-md-6"><label for="txtSNo">Leaveout Session</label><input type="text" name="txtSNo" class="modalinput" id="txtSNo" type="text" size=10 readonly
				value="Auto"></div><div class="col-md-6"><label for="txtProcessedOn">Processed On</label><input type="text" name="txtProcessedOn" id="txtProcessedOn" size=10 class="modalinput tcal" readonly
				value="<?php echo $edate;?>"></div>
			</div><div class="form-row"><div class="col-md-6"><label for="txtLeaveOn">Student(s) Leave On</label><input type="text" type="text" name="txtLeaveOn" id="txtLeaveOn" size=10
				class="tcal modalinput" readonly value="<?php echo date('d-m-Y',strtotime('+1 days'));?>"></div><div class="col-md-6"><label for="txtReturnOn">Return Date</label><input
				name="txtReturnOn" id="txtReturnOn" size=10 class="tcal modalinput" readonly value="<?php echo date('d-m-Y',strtotime('+3 days'));?>"></div>
			</div><div class="form-row"><div class="col-md-4"><label for="cboLvl">Leaveouts For</label><select name="cboLvl" size=1 id="cboLvl" class="modalinput" onchange="showClass(0,this)"><option value="%" selected>
				All Students</Option><?php echo $optlvl;?></SELECT></div><div class="col-md-4"><label for="cboLvl">Form/Grade</label><select name="cboCls" size=1 id="cboCls" class="modalinput"><option value="%" selected>
				All</Option><?php echo $optcls;?></SELECT></div><div class="col-md-4"><label for="cboLvl">Min. Balance</label><input type="text" name="txtBal" id="txtBal" value="1.00" onkeyup="checkInput(this)"
				onblur="enableSave(this,<?php echo $add;?>)" class="modalinput numbersinput"></div>
			</div>
		</div><div class="col-md-3"><br><br><button type="submit" name="btnSave" id="btnSave" class="btn btn-primary btn-md btn-block" disabled>Save Leaveout</br>Details</button></div>
	</form></div><div class="form-row"><div class="col-md-12" id="dispLeaveouts" style="max-height:400px;overflow-y:scroll;">
		<table class="table table-sm table-hover table-responsive table-striped table-bordered"><thead class="thead-dark"><tr><th colspan=6>LEAVEOUT SESSION DETAILS</th><th colspan=2>
			ACTIONS</th><tr><th>S/No.</th><th>Prepared On</th><th>Students Left On</th><th>Returned On</th><th>Leaveout For</th><th>Min Bal</th><th>Students</th><th>Edit</tr></thead><tbody>
			<?php
				$sql="SELECT l.sno,date_format(l.preparedon,'%d-%m-%Y') as pon,date_format(l.leavedate,'%d-%m-%Y') as ld,date_format(l.returndate,'%d-%m-%Y') as rd,c.lvlno,concat(if(isnull(c.lvlno),'All ',c.lvlabbr),
				if(isnull(l.clsno),'',concat(' - Form/Grade ',cl.clsabbr))) as nm,l.minbal,datediff(l.leavedate,curdate()) as df FROM	acc_leaveout l Left Join classlvl c USING (lvlno) left Join classnames cl ON (l.clsno=cl.clsno)
				WHERE l.markdel=0 AND (l.preparedon	BETWEEN '".date('Y-m-d',strtotime($sdate))."' AND '".date('Y-m-d',strtotime($edate))."') ".(strcasecmp($lvl,'%')!=0?"and l.lvlno LIKE '$lvl'":"")." Order By sno Desc";
				$rs=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"pupil_manager.php\">HERE</a> to go back.");
				if (isset($_POST["Show"])){
					$h="Leaveout Sessions Between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate));
					if (strcasecmp($lvl,"%")==0) $h.=" for all students"; else $h.=" for $optName students";
				}else $h="Leaveout Sessions Between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate))." for all students."; $i=1;$leavesessions=''; $datediff=$ls=0;
				if (mysqli_num_rows($rs)>0){while (list($sno,$po,$ld,$rd,$lvlno,$lvl,$mb,$df)=mysqli_fetch_row($rs)){
						if ($df>=0){$leavesessions.=($ls==0?"":",")."new leaveSession($sno,'$po','$ld','$rd','".(is_null($lvlno)?"%":$lvlno)."',$mb)"; $ls++;}
						print "<tr>"; if($i==1) {$datediff=$df; $serialno=$sno;}
						print "<td>$i.</td><td align=\"right\">".date("D d M, Y",strtotime($po))."</td><td align=\"right\">".date("D d M, Y",strtotime($ld))."</td><td align=\"right\">".
						date("D d M, Y",strtotime($rd))."</td><td>$lvl</td><td align=\"right\">".number_format($mb,2)."</td><td style=\"text-align:center;\"><a onclick=\"showLeaveouts($sno,$df,0)\"
						href=\"#\">View</a></td><td style=\"text-align:center;\">".(($add==1 && $df>=0)?"<a onclick=\"getLeaveSession($sno)\" href=\"#\">Edit</a>":" - ")."</td></tr>";
						$i++;
					}
				}else print "<tr><td colspan=\"8\"><br>No fee leaveout session were prepared between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate))."</td></tr>";
				print "</table>"; mysqli_free_result($rs);
			?>
		</div></div>
</div><div class="col-md-6" id="showDefaulters">
	<div class="form-row"><div class="col-md-12" style="font-weight:bold;background-color:#d9ecf2;"><form name="frmFind" method="post">Find By <input type="radio"
		checked name="radFind" id="radAdm" onclick="clrText()">Adm. No. <input type="radio" name="radFind" id="radName" onclick="clrText()">Names <input type="text" name="txtFind"
		id="txtFind" size=10 value="" placeholder="Type what to find here" onkeyup="findStudents(this)"><input type="hidden" name="txtFindSNo" id="txtFindSNo" value="">&nbsp; OR &nbsp;
		<button id="btnViewDeleted" name="btnViewDeleted" type="button" onclick="showCancelledLeaveouts()" disabled class="btn btn-md btn-info">Cancelled Leaveouts</button>
	</form></div>
	</div><hr><div class="form-row"><div class="col-md-12" id="spListStuds" style="border:0px;background:#ffe;max-height:550px;overflow-y:scroll;">
		<h5 style="font-weight:bold;color:#00f;font-size:11pt;font-weight:bold;">LIST OF FEE DEFAULTERS SENT HOME</h5><table class="table table-hover table-sm table-striped
		table-bordered" id="tabDefaulter"><thead class="thead-dark"><tr><th>S/No</th><th>Adm. No.</th><th>Students Names</th><th>Class</th><th>FeePaid</th><th>Fee Bal</th><th>Status</th>
		<th>Action</th></tr></thead><tbody>
		<?php $rs=mysqli_query($conn,"SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,l.paid,l.bal,if(isnull(l.delreason),'".($datediff<0?
		"Went Home":"Go Home")."',l.delreason) as rmks FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN acc_leaveoutstud l
		USING (admno) WHERE l.status=0 and l.sno IN (SELECT * FROM (SELECT sno FROM acc_leaveout WHERE markdel=0 Order By sno DESC limit 0,1)x) ORDER BY cn.clsname,c.Stream,s.admno ASC");
		$i=1; $paid=$bal=0; $nos=mysqli_num_rows($rs);
		if($nos>0){while($data=mysqli_fetch_row($rs)){ $counter=0; print "<tr><td>$i.</td>";
			foreach($data as $d){if($counter<3 || $counter>4) print "<td>$d</td>"; elseif($counter==3){$paid+=$d; print "<td style=\"text-align:right;\">".number_format($d,2)."</td>";}
				else{$bal+=$d; print "<td style=\"text-align:right;\">".number_format($d,2)."</td>";} $counter++;
			}$i++; print "<td></td></tr>";
		}print"</tbody>";} print "<tfoot><tr class=\"nohover\"><th colspan=3><span id=\"spNoStud\">$nos Student(s)' Leaveout Sheets</span></th><th style=\"text-align:right;\">Total Amount
		</th><th style=\"text-align:right;\"><span id=\"spPaid\">".number_format($paid,2)."</span></th><th style=\"text-align:right;\"><span id=\"spBal\">".number_format($bal,2)."</span>
		</th><th colspan=2></th></tr></tfoot></table></div>";
	?></div><div class="form-row"><div class="col-md-12" style="text-align:center;display:none;" id="spPrint"><img src="/gen_img/print.ico" height=20 width=30 onclick="printSpecific()"
		title="Print Report" alt="Print List">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="/gen_img/print.ico" height=20 width=30 alt="Leavouts" title="Print Leaveout Sheets"
		onclick="printLeaveouts()"></div></div>
	</div>
</div><hr><div class="form-row"><div class="col-md-12" style="text-align:right"><button type="button" class="btn btn-md btn-info" onclick="window.open('pupil_manager.php','_self')">
	C l o s e</button></div>
</div></div>
<div id="leaveoutSessionEdit" class="modal">
	<form class="modal-content animate" action="leaveout.php" method="POST" name="frmLeaveoutEdit" onsubmit="return validateLeaveSessionEdit(this);">
	<div class="imgcontainer"><span onclick="document.getElementById('leaveoutSessionEdit').style.display='none'" class="close" title="Close">&times;</span></div><br/>
	<div class="container"  style="background-color:#dddddd"><input type="hidden" name="txtTkn1" value="<?php echo $tkn;?>">
		<div class="form-row"><div class="col-md-12 divheadings">EDIT LEAVEOUT SESSION</div></div>
		<div class="form-row"><div class="col-md-6"><label for="txtSNo1">Leaveout Session</label><input type="text"	name="txtSNo1" id="txtSNo1" type="text" class="modalinput" readonly
			value="Auto"></div><div class="col-md-6"><label for="txtProcessedOn1">Processed On</label><input type="text" name="txtProcessedOn1" id="txtProcessedOn1" class="tcal modalinput"
			readonly value="<?php echo $edate;?>"></div>
		</div><div class="form-row"><div class="col-md-6"><label for="txtLeaveOn1">Student(s) Leave On</label><input type="text" type="text" name="txtLeaveOn1" id="txtLeaveOn1" class="tcal
			modalinput" readonly value="<?php	echo date('d-m-Y',strtotime('+1 days'));?>"></div><div class="col-md-6"><label for="txtReturnOn1">Return Date</label><input name="txtReturnOn1"
			id="txtReturnOn1" class="tcal modalinput" readonly value="<?php echo date('d-m-Y',strtotime('+3 days'));?>"></div>
		</div><div class="form-row"><div class="col-md-4"><label for="cboLvl1">Leaveouts For</label><select name="cboLvl1" size=1 id="cboLvl1" class="modalinput" onchange="showClass(1,this)"><option value="%" selected>
			All Students</Option><?php echo $optlvl;?></SELECT></div><div class="col-md-4"><label for="cboLvl">Form/Grade</label><select name="cboCls1" size=1 id="cboCls1" class="modalinput"><option value="%" selected>
			All</Option></SELECT></div><div class="col-md-4"><label for="txtBal1">Minimum Balance</label><input type="text" name="txtBal1" id="txtBal1" class="modalinput numbersinput" value="0.00"
			onkeyup="checkInput(this)"><input type="hidden" name="txtOBal1" id="txtOBal1" size=5 value=""></div>
		</div><hr><div class="form-row" id="divSessDelBtn">
			<div class="col-md-5"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSessionSaveEdit">Save Leaveout Session</button></div><div class="col-md-4"
			style="text-align:center"><button type="button" class="btn btn-default btn-md" onclick="showSessDelRmks()">Delete Session</button></div><div class="col-md-3"
			style="text-align:right"><button type="button" class="btn btn-info btn-md" onclick="document.getElementById('leaveoutSessionEdit').style.display='none'">Close/ Cancel</button></div>
		</div><div class="form-row" id="divLeaveSessDel" style="visibility:hidden"><div class="col-md-12">
			<div class="form-row"><div class="col-md-12"><label for="txtDelReason">Narration/Reason for cancellation of Leaveout Session</label><textarea name="txtDelReason" id="txtDelReason"
				rows=3 maxlength=140 placeholder="SOME STUDENTS' FEE RECORDS WERE MISSING" class="modalinput" onkeyup="enableDelete(0,this,<?php echo $del;?>)"></TEXTAREA></div>
			</div><div class="form-row"><div class="col-md-5"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnDelLeave"	id="btnDelLeave" disabled>Delete Leaveout
				Session</button></div><div class="col-md-4" style="color:#f00;">Deleting Leaveout session is irreversible!!!</div><div class="col-md-3" style="text-align:right"><button
				type="button" onclick="closeSesDel()" style="float:right;" class="btn btn-info btn-md">Cancel</button></div>
  		</div>
		</div></div>
	</div></form>
</div><div id="leaveoutDelete" class="modal">
	<form class="modal-content animate" action="leaveout.php" method="POST" name="frmLeaveoutDelete">
	<div class="imgcontainer"><span onclick="document.getElementById('leaveoutDelete').style.display='none'" class="close" title="Close">&times;</span></div><br/>
	<div class="container"  style="background-color:#dddddd"><input type="hidden" name="txtTkn2" value="<?php echo $tkn;?>"><input name="txtDet" id="txtDet" type="hidden" value="">
		<div class="form-row"><div class="col-md-12 divheadings">LEAVEOUT CANCELLATION INTERFACE</div></div>
		<div class="form-row"><div class="col-md-12" id="divNames"><table class="table table-sm table-hover table-bordered"><thead class="thead-dark"><tr><th>ADM. NO.</th><th>NAMES OF STUDENT
		</th><th>FORM</th><th>FEE PAID</th><th>FEE BAL</th></tr></thead><tr id="trInfo"></tr></table></div></div>
		<div class="form-row"><div class="col-md-12"><label for="txtReason">Reason for Leaveout Cancellation</label><textarea rows="3"	class="modalinput" maxlength="150" name="txtReason"
		placeholder="There is commitment to pay fees at the end of the month" onkeyup="enableDelete(1,this,<?php echo $del;?>)"></textarea></div></div>
		<hr><div class="form-row"><div class="col-md-6"><Button name="btnDel" id="btnDel" type="submit" class="btn btn-primary btn-md btn-block" disabled>Delete Leaveout</button></div><div
		class="col-md-6" style="text-align:right"><Button name="cmdClose" type="button" onclick="document.getElementById('leaveoutDelete').style.display='none'">Cancel Action</button>
		</div></div><hr>
	</div>
</div>
<script type="text/javascript" src="tpl/js/leaveout.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/actionmessage.js"></script><script type="text/javascript">
<?php	if(strlen($leavesessions)>0) print "leavesessions.push($leavesessions);"; if(strlen($lstcls)>0) print "lstclass.push($lstcls);"; print "</script>"; mysqli_close($conn); footer();?>
