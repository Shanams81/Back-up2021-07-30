<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	if (isset($_POST['cmdSave'])){
		$info=isset($_POST['txtDat'])?strip_tags($_POST['txtDat']):"0-0-0"; 
		$info=preg_split('/\-/',$info); //0 - admission number, 1 no of forms entered and [2] 0 for continuing and 1 for alumni
		$date=isset($_POST['txtDate'])?$_POST['txtDate']:date('d-m-Y');		$date=preg_split('/\-/',$date);	$sql="";
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(strip_tags($_POST['txtRmks']))):"ON HUMANITARIAN GROUNDS";
		for ($i=0;$i<$info[1];$i++){
			$yr=isset($_POST["txtYr_$i"])?$_POST["txtYr_$i"]:date('Y');
			$main=isset($_POST["txtWArr_$i"])?strip_tags($_POST["txtWArr_$i"]):0;		$main=preg_replace("/[^0-9^\.]/","",$main);
			$misc=isset($_POST["txtWMArr_$i"])?strip_tags($_POST["txtWMArr_$i"]):0;	$misc=preg_replace("/[^0-9^\.]/","",$misc); 	$ttl=$main+$misc;
			if ($ttl>0){
				$sql.="INSERT INTO arrears_waive (admno,curr_year,arr_waived,misc_waived,amt_waived,waivedon,rmks,wtype) VALUES ('$info[0]','$yr','$main','$misc','$ttl',
				'$date[2]-$date[1]-$date[0]','$rmks',$info[2]);";
				if ($info[2]==0) $sql.="UPDATE form SET bbf=bbf-$main,miscbf=miscbf-$misc,alumniarrears=alumniarrears-$ttl WHERE admno LIKE '$info[0]' and curr_year LIKE 
				'$yr';";
				else $sql.="UPDATE form SET alumniarrears=alumniarrears-$ttl WHERE admno LIKE '$info[0]' and curr_year LIKE '$yr';";		
			}
		}
		if (strlen($sql)>0) {
			mysqli_multi_query($conn,$sql); $i=mysqli_affected_rows($conn);
		} else $i=0;	header("location:waive_arrears.php?action=1-$i");
	}else{
		$info=isset($_REQUEST['admno'])?strip_tags($_REQUEST['admno']):"0-2016-0"; 
		$info=preg_split('/\-/',$info); //0 - admission number, 1 year and [2] 1 for new waive and 2 for edit waive
		$rsStud=mysqli_query($conn,"SELECT s.admno,concat(s.surname,' ',s.onames) as nam,concat(f.form,'-',f.stream) as frm,s.type FROM stud s Inner Join form f USING 
		(admno,curr_year) WHERE s.admno LIKE '$info[0]' AND s.curr_year LIKE '$info[1]'");
		$stud=mysqli_fetch_row($rsStud); mysqli_free_result($rsStud);
		$won=date('d-m-Y');	$wrmks="On humanitarian grounds";
	}
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<link href="../date/tcal.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<script type="text/javascript" src="../date/tcal.js"></script>
	<script type="text/javascript" src="tpl/waivecont.js"></script>
</head>
<body background="../gen_img/bg3.gif">
	<form method="post" action="waive_curr_arrears.php" onsubmit="return onSubmitVerify(this);" name="frmCont">
	<BR><BR><table cellpadding="4" cellspacing="3" border="0" align="center"><tr><td colspan="4" style="background-color:#000;font-weight:bold;font-size:12pt;
	letter-spacing:8px;word-spacing:10px;text-align:center;color:#0e0;">WAIVING OF FEE ARREARS</td></tr>
	<?php	
		print "<tr><td align=\"right\">Adm. No.</td><td style=\"font-weight:bold;letter-spacing:2px;word-spacing:3px;\">$stud[0] <u>$stud[1]</u></td><td align=\"right\">
		Form</td><td>$stud[2]</td></tr><td align=\"right\">Date</td><td colspan=\"3\"><input name=\"txtDate\" type=\"text\" class=\"tcal\" size=\"10\" readonly 
		value=\"".date('d-m-Y',strtotime($won))."\"></td></tr><tr><td colspan=\"4\"><hr></td></tr>";
		print "<tr><td></td><td colspan=\"4\">";
		print "<table border=\"1\" cellpadding=\"2\" style=\"border-collapse:collapse;font-size:10pt;\"><tr style=\"background-color:#bbb;color:#fff;font-weight:bold;
		letter-spacing:2px;word-spacing:4px;\"><th rowspan=\"2\">FORM</th><th colspan=\"2\">MISC ACCOUNT</th><th colspan=\"2\">MAIN ACCOUNT</th></tr><tr 
		style=\"background-color:#999;color:#fff;font-weight:bold;letter-spacing:1px;word-spacing:2px;\"><th>Arrears</th><th>Waive</th><th>Arrears</th><th>Waive</th></tr>";
		if ($stud[3]==0) $sql="SELECT concat(sf.curr_year,' ', sf.form,'-', sf.stream) as frm,sf.bbf,sf.miscbf,sf.curr_year FROM form sf WHERE sf.admno LIKE '$info[0]' 
		and sf.markdel=0 order by sf.curr_year asc";
		else $sql="SELECT concat(sf.curr_year,' ', sf.form,'-', sf.stream) as frm,sf.alumniarrears,0,sf.curr_year FROM form sf WHERE sf.admno LIKE '$info[0]' and 
		sf.markdel=0 order by sf.curr_year asc";
		$rs=mysqli_query($conn,$sql); $narr=mysqli_num_rows($rs);
		print "<input type=\"hidden\" name=\"txtDat\" value=\"$info[0]-$narr-$stud[3]\">"; $ttl=0;	$mttl=0;
		if ($narr>0){
		 	$i=0;
			while (list($frm,$bbf,$misbf,$cyr)=mysqli_fetch_row($rs)){
				print "<tr><td>$frm<input type=\"hidden\" name=\"txtYr_$i\" value=\"$cyr\"></td>";
				print "<td><input type=\"text\" name=\"txtMArr_$i\" id=\"txtMArr_$i\" size=\"8\" value=\"".number_format($misbf,2)."\" readonly style=\"text-align:right;
				background-color:#ddd;border:0px;\"></td><td><input type=\"text\" name=\"txtWMArr_$i\" id=\"txtWMArr_$i\" size=\"8\" value=\"0.00\" ".($misbf>0?"":
				"readonly")." style=\"text-align:right;\" required onkeyup=\"checkInput(this,4,$narr)\"></td>";
				print "<td><input type=\"text\" name=\"txtArr_$i\" id=\"txtArr_$i\" size=\"8\" value=\"".number_format($bbf,2)."\" readonly style=\"text-align:right;
				background-color:#ddd;border:0px;\"></td><td><input type=\"text\" name=\"txtWArr_$i\" id=\"txtWArr_$i\" size=\"8\" value=\"0.00\" ".($bbf>0?"":"readonly").
				" style=\"text-align:right;\" required onkeyup=\"checkInput(this,1,$narr)\"></td></tr>";
				$i++; $ttl+=$bbf; 	$mttl+=$misbf;
			}
		}else{
			print "<tr><td colspan=\"5\">There are arrears records available</td></tr>";
		} mysqli_free_result($rs);
		print "<tr style=\"text-align:right;background-color:#666;color:#fff;font-weight:bold;\"><td>TOTAL</td><td><input size=8 name=\"txtTtlMArr\" id=\"txtTtlMArr\" 
		type=\"text\" style=\"text-align:right;background-color:#eee;border:0px;\" value=\"".number_format($mttl,2)."\"></td><td><input size=8 
		name=\"txtMTtl\" id=\"txtMTtl\" type=\"text\" style=\"text-align:right;background-color:#eee;\" value=\"0.00\"></td><td><input size=8 name=\"txtTtlArr\" 
		id=\"txtTtlArr\" type=\"text\" style=\"text-align:right;background-color:#eee;border:0px;\" value=\"".number_format($ttl,2)."\"></td><td><input 
		size=8 name=\"txtTtl\" id=\"txtTtl\" type=\"text\" style=\"text-align:right;background-color:#eee;\" value=\"0.00\"></td></tr></table>";
		print "<tr><td align=\"right\" valign=\"top\">Waive Narration</td><td colspan=\"3\"><textarea cols=\"70\" rows=\"3\" name=\"txtRmks\" maxlength=\"200\" 
		style=\"letter-spacing:2px;word-spacing:3px;text-transform:uppercase;\" required>$wrmks</textarea></td></tr><tr><td colspan=\"4\"><hr></td></tr>";
		print "<tr><td colspan=\"3\" align=\"center\"><button name=\"cmdSave\" type=\"submit\">Save Waive Record</Button></td><td align=\"right\"><a 
		href=\"waive_arrears.php?action=0-0\"><button name=\"cmdClose\" type=\"button\">Cancel/ Close</Button></a></td></tr></table>";
		mysqli_close($conn);
	?>
	</form>
</body></html>