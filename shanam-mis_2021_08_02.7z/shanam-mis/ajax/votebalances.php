<?php
  include_once('../../conn/pri_sch_connect.inc');
  $data=sanitize($_REQUEST['q']); $data=preg_split('/\-/',$data);
  if($data[0]==0){ //FIND A/C DETAILS
    $optvotes='<option value="0" selected>Choose Votehead</option>';
    $optbank='<SELECT name="cboBankAC" id="cboBankAC" size="1" class="modalinput" disabled><option value="0" selected>Choose Bank A/C</option>';  $lst='';
    mysqli_multi_query($conn,"SELECT max(vono) as vno FROM acc_exp GROUP BY acc HAVING acc LIKE '$data[1]'; SELECT a.sno,concat(b.descr,' - A/C NO. ',a.accno) as ac FROM acc_accounts a Inner
    Join acc_banks b ON (a.bankno=b.sno) WHERE a.accacc LIKE '$data[1]'; ");   $vono=$i=0;//$bank=$cash='';
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){ if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $vono=$d[0];
        }else{ if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $optbank.="<option value=\"$d[0]\">$d[1]</option>"; $optbank.='</SELECT>';
        }mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn)); $vono++; echo "$vono~$optbank";
  }else{//FIND PAYEE DETAILS
    $rs=mysqli_query($conn,"SELECT payno,payee,telno,address,email FROM acc_exppayee WHERE idno LIKE '$data[1]'");
    if(mysqli_num_rows($rs)){$d=mysqli_fetch_row($rs); echo "$d[0]~$d[1]~$d[2]~$d[3]~$d[4]";
    }else echo 0; mysqli_free_result($rs);
  } mysqli_close($conn);
?>
