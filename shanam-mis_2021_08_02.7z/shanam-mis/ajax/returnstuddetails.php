<?php
    include_once('../../conn/pri_sch_connect.inc');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=explode('-',$data);	//[0] 0 - Student Details,1 Receipt Details,2 Fee Bal, [1] -admno or receipt no , [2] account if receipt details required
    if ($data[0]==0){$sql="SELECT concat('NAME: ',s.surname,' ',s.onames, '<br>FORM/ GRADE: ',cn.clsname,' - ',c.stream) As cls FROM stud s Inner Join class c USING (admno,curr_year) Inner JOin classnames cn On
      (c.clsno=cn.clsno) WHERE s.admno LIKE '$data[1]'";
    }elseif($data[0]==1){ $sql="SELECT f.admno,f.pytdate,f.pytfrm,f.cheno,(i.amt-i.transfer-i.arrears-i.spemed-i.unifrm".($data[2]==1?"-i.prep-i.refunds":"").") as fee,i.arrears,i.spemed,i.unifrm,".($data[2]==1?
    "i.prep,i.refunds":"0 as prep,0 as refunds").",(i.amt-i.transfer) as ttl,if(isnull(f.bursno),0,f.bursno) as bno FROM acc_incofee f Inner Join ".($data[2]==1?"acc_incorecno0":"acc_incorecno1")." i USING (sno) WHERE
    i.recno LIKE '$data[1]' and i.acc LIKE '$data[2]'";
  }else{ if($data[2]==1) $sql="SELECT (s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0)-if(isnull(f.fee),0,f.fee)) as ybal FROM (SELECT cf.admno,sum(if(v.acc=1,cf.T3,0)) as t3f FROM clsfee cf INNER
    JOIN acc_votes v On (cf.voteno=v.sno) GROUP BY cf.admno,v.acc HAVING cf.admno LIKE '$data[1]' and v.acc LIKE '$data[2]')s INNER JOIN (SELECT	c.admno,sum(c.bbf) as arbf,sum(c.spemed) as med,sum(c.unifrm) as uni,
    x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM	acc_votesassigned)x GROUP BY admno,markdel
    HAVING admno LIKE '$data[1]' and markdel=0)ar USING (admno) LEFT JOIN (SELECT f.admno,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm-v.transfer) as fee	FROM acc_incofee f INNER JOIN acc_incorecno0 v
    USING (sno) GROUP BY f.admno,f.markdel HAVING f.markdel=0 AND f.admno LIKE '$data[1]')f USING (admno)";
    else $sql="SELECT (s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0)-if(isnull(f.mfee),0,f.mfee)) as mybal FROM (SELECT cf.admno,sum(if(v.acc!=1,cf.T3,0)) as mt3f FROM  clsfee cf INNER JOIN
    acc_votes v On (cf.voteno=v.sno) GROUP BY cf.admno,v.acc HAVING cf.admno LIKE '$data[1]' and v.acc LIKE '$data[2]')s INNER JOIN (SELECT	c.admno,sum(c.miscbf) as marbf,sum(c.spemed) as med,sum(c.unifrm) as uni,
    x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM	acc_votesassigned)x GROUP BY admno,markdel
    HAVING admno LIKE '$data[1]' and markdel=0)ar USING (admno) LEFT JOIN (SELECT f.admno,sum(m.amt-m.arrears-m.spemed-m.unifrm-m.transfer) as mfee	FROM acc_incofee f INNER JOIN acc_incorecno1 m USING (sno)
    GROUP BY f.admno,f.markdel HAVING f.markdel=0 AND f.admno LIKE '$data[1]')f USING (admno)";
  }$rs=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"transferfees.php\">HERE</a> to go back.");
  if($data[0]==0){if(mysqli_num_rows($rs)>0) list($details)=mysqli_fetch_row($rs); else $details="No Student has Adm. No. ".$data[1]; echo $details;
  }else{
    if($data[0]!=2){ if(mysqli_num_rows($rs)>0){ $data=mysqli_fetch_row($rs); $details="$data[0]~$data[1]~$data[2]~$data[3]~$data[4]~$data[5]~$data[6]~$data[7]~$data[8]~$data[9]~$data[10]~$data[11]"; }
      else $details="0~0~0~0~0~0~0~0~0~0~0~0"; echo $details;
    }else{$bal=0; if(mysqli_num_rows($rs)>0) list($bal)=mysqli_fetch_row($rs); echo $bal;}
  } mysqli_free_result($rs);mysqli_close($conn);
?>
