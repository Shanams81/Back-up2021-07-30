<?php
    session_start();   include_once('../../conn/pri_sch_connect.inc');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0]-net salary,[1]- salary no and [2] random
    mysqli_multi_query($conn,"SELECT saladd,saledit,saldel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT salno,concat(sal_month,' - ',sal_year) as mon,approvestatus,
    datediff(curdate(),processedon) as n FROM acc_salaries WHERE salno LIKE '$data[1]'; SELECT schtype FROm ss;"); $saladd=$saledit=$saldel=$schtype=$i=0; $optStf='';
    do{
        if ($rs=mysqli_store_result($conn)){if($i==0) list($saladd,$saledit,$saldel)=mysqli_fetch_row($rs);elseif($i==1) $sper=mysqli_fetch_row($rs);else list($schtype)=mysqli_fetch_row($rs);
        }$i++; mysqli_free_result($rs);
    }while (mysqli_next_result($conn)); $i=0;
?>
<div class="form-row">
    <div class="col-md-6" style="background:#fff;border:0.5px dotted green;border-radius:10px 10px 0 0;padding:5px;font-size:0.8rem;"><form method="post" action="payroll.php"
    name="frmPayrollList">&nbsp; Find Payroll Member By &nbsp;&nbsp;<input type="radio" name="radFind1" id="radPFNo1" value="payrollno" onclick="clrText(1)">PF No.&nbsp;<input
    type="radio" name="radFind1" id="radIDNo1" value="idno" onclick="clrText(1)">ID No.&nbsp;<input type="radio" name="radFind1" id="radNames1" value="names" onclick="clrText(1)"
    checked>Names &nbsp; <input type="text" maxlength="13" size="20" name="txtFind1" id="txtFind1" value="" onkeyup="myFunction(1)" placeholder="Search for a Payroll"
    title="Type what to find"></div>
    <div class="col-md-6" style="background:#fff;border:0.5px dotted green;border-radius:10px 10px 0 0;padding:5px;font-size:0.8rem;"><?php echo (($sper[2]==0 && $saladd==1)?
    '<button onclick="window.open(\'processstaffsalaries.php?salno=2-'.$sper[0].'-1\')" type="button" name="btnAddNewEarner" class="btn btn-primary btn-md">Add New Earner</button>':
    '');?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo (($sper[3]<30 && $sper[2]==1 && $saladd==1)?'<button type="button" name="btnViewSalRpt"
    class="btn btn-info btn-md" onclick="window.open(\'salchequeno.php?salno='.$sper[0].'\',\'_self\')">Payroll Cheque Numbers</button>':''); ?>&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;<?php echo (($sper[2]==1 && $saladd==1)?'<button type="button" name="btnViewSalRpt" class="btn btn-info btn-md"
    onclick="window.open(\'salaryview.php?salno='.$sper[0].'\',\'_self\')">Payroll Reports</button>':''); ?></form></div>
  </div> <div class="form-row">
    <div class="col-md-9" style="font-size:12pt;font-weight:bold;letter-spacing:6px;word-spacing:10px;"><?php echo strtoupper($sper[1]);?> SALARY PAYROLL</div>
    <div class="col-md-3" style="text-align:right;">Date: <?php echo date("D d M, Y");?></div>
  </div><div class="form-row"><div class="col-md-12" style="overflow-y:scroll;max-height:400px;">
  <?php
      $rsP=mysqli_query($conn,"SELECT sp.payrollno,s.idno,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.bsalary,sp.housingallow1,sp.medicalallow1,sp.travelallow1,
      responsallow1,sp.empnssf,(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1) AS GSal,(sp.nssffee1+sp.empnssf+sp.nssfvol1) as nssf,sp.nhiffee1,
      (sp.paye1-sp.mpr1) as tax,sp.union1,sp.sacco1,sp.welfare1,sp.advance,sp.otherlevies1,sp.helb1,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1)-
      (sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1)) AS NetSal FROM stf s INNER JOIN acc_saldef USING (idno) Inner
      Join acc_salpyt sp USING (payrollno) Where sp.salno LIKE '$sper[0]' and sp.markdel=0 ORDER BY s.surname,s.onames ASC");
      $gsal=$ded=$net=0; $nop=mysqli_num_rows($rsP);
      if ($nop>0){
          $ttl=array(0,0,0);
          echo '<table id="myTable1"  class="table table-stripped table-sm table-hover table-bordered" style="font-size:0.6rem;"><thead class="thead-dark"><tr><th colspan="4">DETAILS OF
          MEMBER OF STAFF</th><th rowspan=2>BASIC<br>SALARY</th><th colspan=5>SALARY ALLOWANCES</th><th rowspan=2>GROSS<BR>SALARY</th><th colspan=9>DEDUCTIONS/ RECOVERIES FROM SALARY</th>
          <th rowspan=2>NET<BR>SALARY</th><th rowspan=2>ADMIN<BR>ACTION</th><tr><th>PFNO</th><th>ID NO</th><th>NAMES</th><th>DESIGNATION</th><th>HOUSE</th><th>MEDIC</th><th>COMMUTER</th>
          <th>DUTY</th><th>NSSF</th><th>NSSF</th><th>NHIF</th><th>PAYE</th><th>'.($schtype==0?'ELIMU</th><th>KDS':'UNION</th><th>SACCO').'</th><th>WELFARE</th><th>ADVANCE</th><th>HELB
          </th><th>'.($schtype==0?'RENT':'OTHER DED').'</th></tr></thead><tbody>';
          while (list($pfno,$idno,$name,$des,$bsal,$house,$med,$com,$resp,$enssf,$gsal,$nssf,$nhif,$paye,$union,$sacco,$welf,$adv,$ole,$helb,$nsal)=mysqli_fetch_row($rsP)){
              echo '<tr><td>'.$pfno.'</td><td>'.$idno.'</td><td>'.$name.'</td><td>'.$des.'</td><td align="right"><b>'.number_format($bsal,2).'</b></td><td align="right">'.
              number_format($house,2).'</td><td align="right">'.number_format($med,2).'</td><td align="right">'.number_format($com,2).'</td><td align="right">'.number_format($resp,2).'</td>
              <td align="right">'.number_format($enssf,2).'</td><td align="right"><b>'.number_format($gsal,2).'</b></td><td align="right">'.number_format($nssf,2).'</td><td align="right">'.
              number_format($nhif,2).'</td><td align="right">'.number_format($paye,2).'</td><td align="right">'.number_format($union,2).'</td><td align="right">'.number_format($sacco,2).
              '</td><td align="right">'.number_format($welf,2).'</td><td align="right">'.number_format($adv,2).'</td><td align="right">'.number_format($helb,2).'</td><td align="right">'.
              number_format($ole,2).'</td><td align="right"><b>'.number_format($nsal,2).'</b></td><td align="center">'.(($saledit==1 && $sper[2]==0)?'<a onclick="return canEdit('.$saledit.')" '
              . 'href="processStaffSalaries.php?salno=1-'.$sper[0].'-'.$pfno.'">Edit</a>':'').'</td></tr>';
              $ttl[0]+=$bsal;  	$ttl[1]+=$gsal; 	$ttl[2]+=$nsal;
          } mysqli_free_result($rsP);
          echo '</tbody><tfoot><tr><th colspan="2" id="parTotals" style="font-weight:bold;">'.$nop.' Staff Salaries.</th><th style="text-align:right;font-weight:bold;" colspan="2">Total '
          . 'Basic Salary</th><th style="text-align:right;font-weight:bold;" id="ttlBS">'.number_format($ttl[0],2).'<th style="text-align:right;font-weight:bold;" colspan="5">Total Gross Salary'
          . '</th><th id="ttlGS" style="text-align:right;font-weight:bold;">'.number_format($ttl[1],2).'</th><th style="text-align:right;font-weight:bold;" colspan="9">Total Net Salary</th><th '
          . 'style="text-align:right;font-weight:bold;" id="ttlNS">'.number_format($ttl[2],2).'.</th></tr></tfoot></table>';
      }else{
          echo '<center><a onclick="return canProcess('.$saladd.')" href="processstaffsalaries.php?salno=0-'.$sper[0].'-0"><button name="btnProcessAll" id="btnNew" type="button"
          class="btn btn-primary btn-lg">Process Staff Members\' Salary</button></a></center>';
      }
  ?></div>
</div>
<?php
	mysqli_close($conn);
?>
