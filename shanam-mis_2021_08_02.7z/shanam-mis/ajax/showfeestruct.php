<?php
    session_start();
    include_once('../../conn/pri_sch_connect.inc');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0] 0 viewing 1 editing,[1]- year, [2] lvlno,[3] - Account
    $h=($data[0]==0?"":"EDITING ")." FY".$data[1]." - ";
    if (mysqli_multi_query($conn,"SELECT ucase(abbr) as nam FROM acc_voteacs WHERE acno LIKE '$data[3]'; SELECT UCASE(lvlname) FROM classlvl WHERE lvlno LIKE '$data[2]';")){ $i=0;
      do{
        if ($rs1=mysqli_store_result($conn)){
          if($i==0){if(mysqli_num_rows($rs1)>0) list($acname)=mysqli_fetch_row($rs1);}else{if(mysqli_num_rows($rs1)>0)list($lvlname)=mysqli_fetch_row($rs1);} mysqli_free_result($rs1);
        }$i++;
      }while (mysqli_next_result($conn));
    }$h.=$acname.' '.$lvlname.' FEE STRUCTURE';
    echo '<div class="container" style="max-width:800px;width:fit-content;padding:5px;background-color:#709fb0;"><h5 style="font-weight:strong;letter-spacing:1px;word-spacing:2px;background-color:#000;color:#fff;
    text-align:center;">'.$h.'.</h5><form method="post" action="feestruct.php" name="frmFeeStruct" onsubmit="return validateData(this)">';
    if ($data[0]==0) echo '<table class="table-striped table-hover" style="padding:5px;"><tr><th>VOTEHEAD</th><th align="right">TERM I</th><th align="right">TERM II</th><th align="right">
    TERM III</th><th align="right">TOTAL</th></tr>';
    else echo '<div class="form-row" style="border-bottom:1px dotted #f99;"><div class="col-md-4 divsubheading">VOTEHEAD</div><div class="col-md-2 divsubheading">TERM I</div><div
    class="col-md-2 divsubheading">TERM II</div><div class="col-md-2 divsubheading">TERM III</div><div class="col-md-2 divsubheading">TOTAL</div></div>';
    $rs=mysqli_query($conn,"SELECT f.voteno,v.descr,f.t1,(f.t2-f.t1) as term2,(f.t3-f.t2) as term3,t3 FROM acc_feestruct f inner join acc_votes v on (f.voteno=v.sno) WHERE (f.yr LIKE
    '$data[1]' and f.lvlno LIKE '$data[2]' and v.acc LIKE '$data[3]') Order By f.voteno Asc");	$nofs=mysqli_num_rows($rs);		$i=0; $ttlAmt=array(0,0,0,0);
    while (list($voteno,$vote,$t1,$t2,$t3,$ttl)=mysqli_fetch_row($rs)):
      if ($data[0]==0){ //Viewing data
          echo '<tr><td>'.$vote.'</td><td style="text-align:right;">'.number_format($t1,2).'</td><td style="text-align:right;">'.number_format($t2,2).'</td><td style="text-align:right;">'.
          number_format($t3,2).'</td><td style="text-align:right;font-weight:bold;">'.number_format($ttl,2).'</td></tr>';
      }else{ //Editing
          echo '<div class="form-row" style="border-bottom:1px dotted #f99;"><div class="col-md-4"><input type="hidden" name="txtVote_'.$i.'" id="txtVote_'.$i.'" value="'.$voteno.'">'.
          $vote.'</div><div class="col-md-2"><input type="text" name="txtT1_'.$i.'" id="txtT1_'.$i.'" value="'.number_format($t1,2).'" required onkeyup="checkData(this)"
          onblur="getTotal('.$i.','.$nofs.')" class="modalinput numbersinput"><input type="hidden" name="txtOT1_'.$i.'" id="txtOT1_'.$i.'" value="'.number_format($t1,2).'"></div><div
          class="col-md-2"><input type="text" name="txtT2_'.$i.'" id="txtT2_'.$i.'" value="'.number_format($t2,2).'" onblur="getTotal('.$i.','.$nofs.')" required onkeyup="checkData(this)"
          class="modalinput numbersinput"><input type="hidden" name="txtOT2_'.$i.'" id="txtOT2_'.$i.'" value="'.number_format($t2,2).'"></div><div class="col-md-2"><input type="text"
          name="txtT3_'.$i.'" id="txtT3_'.$i.'" value="'.number_format($t3,2).'" required onkeyup="checkData(this)" onblur="getTotal('.$i.','.$nofs.')" class="modalinput numbersinput">
          <input type="hidden" name="txtOT3_'.$i.'" id="txtOT3_'.$i.'" value="'.number_format($t3,2).'"></div><div class="col-md-2"><input type="text" name="txtTtl_'.$i.'"
          id="txtTtl_'.$i.'" value="'.number_format($ttl,2).'" required readonly class="modalinput numbersinput modalinputdisabled"<input type="hidden" name="txtOTtl_'.$i.'"
          id="txtOTtl_'.$i.'" value="'.number_format($ttl,2).'"></div></div>';
      } $ttlAmt[0]+=$t1; $ttlAmt[1]+=$t2; $ttlAmt[2]+=$t3; $ttlAmt[3]+=$ttl; $i++;
    endwhile;
    if ($data[0]==0) echo '<tr><td style="text-align:right;font-weight:bold;">Term\'s Totals</td>';
    else echo '<div class="row" style="border-bottom:1px dotted #f99;"><div class="col-md-4" style="text-align:right;font-weight:bold;">Term\'s Totals</div>'; $i=0;
    foreach ($ttlAmt as $amt){
        if ($data[0]==0) echo '<td style="text-align:right;background:#ddd;font-weight:bold;">'.number_format($amt,2).'</td>';
        else echo '<div class="col-md-2"><input type="text" name="txtTermTtl_'.$i.'" id="txtTermTtl_'.$i.'" value="'.number_format($amt,2).'" required  class="modalinput numbersinput
        modalinputdisabled" readonly></div>'; $i++;
    }
    echo ($data[0]==1?'</div>':'</tr>');
    if ($data[0]==1) echo '<br><div class="form-row"><div class="col-md-5" style="text-align:center"><input type="hidden" name="txtData" id="txtData" value="'.$data[1].'-'.$data[2].'-'.$data[3].'-'.$nofs.'"><button
    type="submit" name="btnSaveFS" class="btn btn-warning btn-block btn-md">Save Fee Structure</button></div><div class="col-md-5" style="text-align:center"><button type="submit" name="btnRefreshStudFee"
    id="btnRefreshStudFee"  class="btn btn-info btn-md">Effect to All '.$lvlname.' Students</button></div><div class="col-md-2" style="text-align:right"><button type="button" name="btnCloseFS"  class="btn btn-warning
    btn-md" onclick="closeFS()">Cancel/ Close</button></div></div>';
    else echo '</tr><tr><td colspan="5" style="text-align:right;"><a href="#" onclick="printSpecific(\'divFeeStruct\')"><img src="../../gen_img/print.ico" width="20" height="20">
    Print</a></td></tr></table>';
    echo "</form></div>";
    mysqli_free_result($rs); mysqli_close($conn);
?>
