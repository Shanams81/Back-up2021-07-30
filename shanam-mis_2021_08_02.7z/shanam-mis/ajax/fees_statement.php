<?php
    include_once('../../conn/pri_sch_connect.inc'); session_start(); $admno=$_REQUEST['adm']; $yr=date('Y'); $un=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
    $admno=preg_split("/\-/",$admno);	//$recno[0] pupil admission no.,$recno[1]-0 studfee.php and $recno[2] financial year.
    class Accounts{ private $sno,$abbr,$descr;public function __construct($s,$a,$d){$this->sno=$s; $this->abbr=$a; $this->descr=$d;}		public function valSNo(){return $this->sno;}
        public function valAbbr(){return $this->abbr;}		public function valDescr(){return $this->descr;}
    }echo'<!DOCTYPE html><html lang="en" dir="ltr"><head><style>.mini{border:0;border-bottom:1px dotted #00a;}.show{border:1px solid #000;}.h{border:0}.bgc{background:#aaa;color:#00f;
    font-weight:bold;letter-spacing:1px;word-spacing:2px;}.numf{text-align:right !important;}</style></head><body>';
    mysqli_multi_query($conn,"SELECT scnm,scadd,finyr FROM ss; SELECT acno,abbr,descr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0; SELECT sum(case when name='bbf' then acc else
    0 end) as acbbf,sum(case when name='miscbf' then acc else 0 end) as acmiscbf,sum(case when name='spemed' then acc else 0 end) as acspemed,sum(case when name='unifrm' then acc else
    0 end) as acunifrm FROM `acc_votesassigned`; SELECT abbr FROM terms Inner Join ss USING (finyr) ORDER BY tno ASC;"); $i=0; $sql=''; $noac=0;
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){list($scnm,$scadd,$finyr)=mysqli_fetch_row($rs);} elseif($i==1){while (list($d,$a,$n)=mysqli_fetch_row($rs)){$noac++; $accounts[]=new Accounts($d,$a,$n);}
        }elseif($i==2){$acno=mysqli_fetch_row($rs);} else {while(list($trm)=mysqli_fetch_row($rs)) $term[]=$trm;} mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
    //Balance details
    $sql="SELECT s.admno,s.stud_names,s.cls,(ar.arbf+if(isnull(f.arrp),0,f.arrp)) as bbf,(ar.marbf+if(isnull(f.marrp),0,f.marrp)) as misbf,if(ar.acspemed=1,(ar.med+if(isnull(f.medp),0,
    f.medp)),0) as med,if(ar.acspemed!=1,(ar.med+if(isnull(f.mmedp),0,f.mmedp)),0) as mmed,if(ar.acunifrm=1,(ar.uni+if(isnull(f.unip),0,f.unip)),0) as uni,if(ar.acunifrm!=1,(ar.uni+
    if(isnull(f.munip),0,f.munip)),0) as muni,s.t3f,s.mt3f, if(((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+
    if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))) as t1bal, if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee)-if((s.t1f-
    if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,f.fee))))) as t2bal,if((s.t3f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t3f-if(isnull(f.fee),0,f.fee)-if((s.t2f-if(isnull(f.fee),0,
    f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee))))) as t3bal,(s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0)-if(isnull(f.fee),0,f.fee)) as ybal,if(((s.mt1f+ar.marbf
    +if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee)
    ,0,f.mfee))) as mt1bal,if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-if(isnull(f.mfee),0,f.mfee)-if((s.mt1f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt1f-if(isnull(f.mfee),0,
    f.mfee))))) as mt2bal,if((s.mt3f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt3f-if(isnull(f.mfee),0,f.mfee)-if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-if(isnull(f.mfee),0,
    f.mfee))))) as mt3bal,((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee)) as mybal FROM (SELECT s.admno,concat(s.surname,' ',
    s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,s.curr_year,sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc!=1,cf.T1,0)) as mt1f,sum(if(v.acc=1,cf.T2,0)) as t2f,
    sum(if(v.acc!=1,cf.T2,0)) as mt2f,sum(if(v.acc=1,cf.T3,0)) as t3f,sum(if(v.acc!=1,cf.T3,0)) as mt3f FROM  stud s INNER JOIN class c USING (admno, curr_year) INNER JOIN classnames cn
    USING (clsno) INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY s.admno,s.surname,s.onames,
    s.Curr_Year,cn.clsname,c.stream,a.stud_assoc,s.present,s.markdel HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$admno[0]')s INNER JOIN (SELECT c.admno,
    sum(c.bbf) as arbf,sum(c.miscbf) as marbf,sum(c.spemed) as med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as
    acspemed, sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM `acc_votesassigned`)x GROUP BY admno, markdel HAVING markdel=0 and admno LIKE '$admno[0]')ar ON
    (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.arrears)),0,sum(v.arrears))as arrp,if(isnull(sum(v.spemed)),0,sum(v.spemed))as medp,if(isnull(sum(v.unifrm)),0,
    sum(v.unifrm))as unip,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm)) as fee,if(isnull(sum(m.arrears)),0,sum(m.arrears)) as marrp,
    if(isnull(sum(m.spemed)),0,sum(m.spemed))as mmedp,if(isnull(sum(m.unifrm)),0,sum(m.unifrm))as munip,if(isnull(sum(m.amt)),0,sum(m.amt-m.arrears-m.spemed-m.unifrm)) as mfee FROM
    acc_incofee f left Join acc_incorecno0 v USING (sno) Left Join acc_incorecno1 m USING (sno) GROUP BY f.admno,f.markdel HAVING f.markdel=0 and f.admno LIKE '$admno[0]')f on
    (s.admno=f.admno)";
    $rsBal=mysqli_query($conn, $sql); $data=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);  //Display data
    echo "<div id=\"print_content\"><table class=\"h\"><tr class=\"nohover\"><td rowspan=\"3\"class=\"h\" style=\"border-bottom:1px solid #00f;\"><img src=\"/gen_img/logo.jpg\"
    width=\"50\" height=\"50\" vspace=\"1\" hspace=\"1\"></td><td class=\"h\" style=\"font-weight:bold;font-size:14px;letter-spacing:2px;word-spacing:3px;\" colspan=\"2\">$scnm</td>
    </tr><tr class=\"nohover\"><td class=\"h\" style=\"font-weight:bold;font-size:12px;\" colspan=\"2\">$scadd</td></tr><tr class=\"nohover\"><td style=\"font-weight:bold;font-size:12px;
    letter-spacing:1px;word-spacing:2px;border-bottom:1px solid #00f;\" class=\"h\">FY$finyr FEES STATEMENT</td><td style=\"border-bottom:1px solid #00f;text-align:right;\" class=\"h\">
    Printed On&nbsp;".date("D d-M-Y")."</td></tr>";
    print "<tr class=\"nohover\"><td colspan=\"3\" style=\"font-size:12pt;letter-spacing:1px;word-spacing:2px;\" class=\"h\">Statement For <u><b>$data[1]</b></u> Admission No. <u>$data[0]
    </u> in class <u>$data[2]</u>.</td></tr><tr class=\"nohover\"><td colspan=\"3\" align=\"center\" class=\"h\"><Img src=\"/gen_img/washout.jpg\" width=450 height=300
    style=\"position:fixed;opacity:0.1;pointer-events:none;\">";
    print "<table class=\"h\" align=\"center\"><tr><td valign=\"top\" class=\"h\">";  $count=1;
    foreach ($accounts as $acc){
        print "<table class=\"mini\" cellspacing=0><tr class=\"nohover\"><th colspan=\"".($count==1?8:6)."\" class=\"mini bgc\">".$acc->valDescr()." FEES</th></tr>";
        $arr=$med=$uni=$fee=$ttlamt=0;
        if($acc->valSNo()==1){$arr=$data[3];$fee=$data[9]; $med=$data[5];$uni=$data[7];}else{$arr=$data[4];$fee=$data[10]; $med=$data[6];$uni=$data[8];}$ttlamt=$arr+$med+$uni+$fee;
        print "<tr><td colspan=\"".($count==1?6:4)."\" class=\"mini\">Fees Arrears B/F  on 1st Jan, $yr</td><td colspan=\"2\" class=\"mini numf\">".number_format($arr,2)."</td></tr>
        <tr><td colspan=\"".($count==1?6:4)."\" class=\"mini\">FY$yr Fees</td><td class=\"mini numf\" colspan=\"2\">".number_format($fee,2)."</td></tr><tr><td class=\"mini\"
        colspan=\"".($count==1?6:4)."\">Surcharged Medical</td><td class=\"mini numf\" colspan=\"2\">".number_format($med,2)."</td></tr><tr><td class=\"mini\" colspan=\"".($count==1?6:4).
        "\">Uniform</td><td class=\"mini numf\" colspan=\"2\">".number_format($uni,2)."</td></tr><tr><th colspan=\"".($count==1?6:4)."\" class=\"mini\">Total Expected Year's Fee KShs.
        </th><th class=\"mini numf\" colspan=\"2\">".number_format($ttlamt,2)."</th></tr>";
        print"<tr><th class=\"show bgc\">RECEIPT</th><th class=\"show bgc\">RECEIVED ON</th><th class=\"show bgc\">MODE</th><th class=\"show bgc\">ARREARS</th>".($count==1?"<th
        class=\"show bgc\">PREPAID</th><th class=\"show bgc\">REFUNDS</th>":"")."<th class=\"show bgc\">FEE</th><th class=\"show bgc\">TOTAL</th></tr>";
        if($acc->valSNo()==1) $sql="SELECT f.recno,i.pytdate,i.pytfrm,f.arrears,f.prep,f.refunds,(f.amt-f.arrears-f.refunds-f.prep) as fee, f.amt,f.sno FROM acc_incofee i Inner Join
        acc_incorecno0 f USING (sno) WHERE i.admno LIKE '$admno[0]' and i.markdel=0 ORDER BY f.recno ASC";
        else $sql="SELECT f.recno,i.pytdate,i.pytfrm,f.arrears,0 as pre, 0 as refunds,(f.amt-f.arrears) as fee, f.amt,f.sno FROM acc_incofee i Inner Join acc_incorecno1 f USING (sno)
        WHERE i.admno  LIKE '$admno[0]' and i.markdel=0 ORDER BY f.recno ASC";
        $rsFee=mysqli_query($conn,$sql); $nofeerec=mysqli_num_rows($rsFee); $ttl=array(0,0,0,0,0);
        if(mysqli_num_rows($rsFee)>0){
          while($d=mysqli_fetch_row($rsFee)){
              print "<tr><td class=\"show\">$d[0]</td><td  class=\"show numf\">".date('D d M, y',strtotime($d[1]))."</td><td class=\"show\">$d[2]</td><td  class=\"show numf\">".
              number_format($d[3],2)."</td>".($count==1?"<td class=\"show numf\">".number_format($d[4],2)."</td><td class=\"show numf\">".number_format($d[5],2)."</td>":"")."<td
              class=\"show nuf\">".number_format($d[6],2)."</td><td class=\"show numf\">".number_format($d[7],2)."</td></tr>";	for ($ai=0;$ai<5;$ai++) $ttl[$ai]+=$d[$ai+3];
          }
        }else{
          print "<tr><td colspan=\"".($count==1?8:6)."\" class=\"show\">There are no receipts on this account</td></tr>";
        }print "<tr style=\"font-weight:bold;\"><td colspan=2 class=\"show\">$nofeerec Fee Payments</td><td  class=\"show numf\">Totals</td>";   $ai=0;
        foreach ($ttl as $t){
          if(($ai===1 || $ai===2) && $count===1) print "<td  class=\"show numf\">".number_format($t,2)."</td>";
          elseif($ai!==1 && $ai!==2) print "<td  class=\"show numf\">".number_format($t,2)."</td>"; $ai++;
        }print "</tr></table></td>";
        if ($count<$noac) print "<td rowspan=2 class=\"h\">--</td><td class=\"h\" valign=\"top\">"; $count++;
    }
    print "</tr><tr>"; $ai=0;
    foreach($accounts as $acc) {
      $t1bal=0; $t2bal=0; $t3bal=0; $ybal=0; if($acc->valSNo()==1){$t1bal=$data[11];$t2bal=$data[12];$t3bal=$data[13];$ybal=$data[14];} else{$t1bal=$data[15];$t2bal=$data[16];
      $t3bal=$data[17];$ybal=$data[18];}
      print "<td class=\"h\"><br><table class=\"show\" cellspacing=0><tr><th class=\"show bgc\">$term[0] Bal</th><th class=\"show bgc\">$term[1] Bal</th><th class=\"show bgc\">$term[2]
      Bal</th><th class=\"show bgc\">Total Year's Bal</th></tr><tr><th class=\"show numf\">".number_format($t1bal,2)."</th><th class=\"show numf\">".number_format($t2bal,2)."</th><th
      class=\"show numf\">".number_format($t3bal,2)."</th><th class=\"show numf\">".number_format($ybal,2)."</th></tr></table></td>";
      $ai++;
    }
    print "</tr></table></td></tr>";
    if($noac>1) print "<tr><td colspan=\"3\" class=\"h bgc\" style=\"border:1px solid #00f;\"><b>Total Balances -></b> $term[0] Kshs. <b>".number_format(($data[11]+$data[15]),2).
    "</b> $term[1] Kshs. <b>".number_format(($data[12]+$data[16]),2)."</b> $term[2] Kshs. <b>".number_format(($data[13]+$data[17]),2)."</b>. Total Bal KShs. <b>".
    number_format(($data[14]+$data[18]),2).":</b></td></tr>";
    print "<tr><td colspan=\"3\" class=\"h\"><br><br>Served By <u><b>$un</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign ________________</td>
    </tr><tr><td colspan=\"3\" style=\"color:#999;font-size:8px;border-top:2px solid #777;text-align:center;\" class=\"h\">The statement is invalid without official stamp. Designed By:
    Shanams Digital Solutions +254736732168</center></td></tr></table></div>";
    print "<div id=\"btns\" style=\"text-align:center\"><button type=\"button\" class=\"btn btn-primary btn-md\" onclick=\"Clickheretoprint()\">Print</button>&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;<a href=\"".($admno[1]==0?"studfee.php":"inquirebal.php")."\"><button class=\"btn btn-info btn-md\" type=\"button\">Close</button></a></center></div>";
    mysqli_close($conn);
?>
</body></html>
