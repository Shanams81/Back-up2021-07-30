<?php
    include_once('../../conn/pri_sch_connect.inc');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0] 0 Bursary, 1 Fee Receipt Transaction Number, [1]bursary number/ transaction number
    if ($data[0]==0 || $data[0]==1){
        if($data[0]==0) $sql="SELECT b.pytfrm,b.cheno,b.bankno,(b.amt-if(isnull(f.ttl),0,f.ttl)) as bal FROM acc_burs b LEFT JOIN (SELECT f.bursno,sum(if(isnull(f1.amt),0,(f1.amt+f1.bc))+
        if(isnull(f2.amt),0,(f2.amt+f2.bc))) as ttl FROM acc_incofee f Left Join acc_incorecno0 f1 USING (sno) left Join acc_incorecno1 f2 USING (sno) GROUP BY f.bursno,f.markdel having 
        f.markdel=0 and f.bursno LIKE '$data[1]')f USING (bursno) GROUP BY b.pytfrm,b.cheno,b.bankno,b.bursno,b.markdel HAVING b.bursno LIKE '$data[1]' and b.markdel=0";
        else $sql="SELECT count(sno) FROM acc_incofee GROUP BY cheno,markdel HAVING markdel=0 and cheno LIKE '$data[1]'";
        $rs=mysqli_query($conn,$sql); $nofs=mysqli_num_rows($rs);
        if($nofs>0){$d=mysqli_fetch_row($rs); if ($data[0]==0) echo strtoupper($d[0]).'-'.$d[1].'-'.$d[2].'-'.$d[3]; else echo $d[0];} 
        else{if ($data[0]==0) echo '0-0-0-0'; else echo 0;};
    }else{
        $sql="SELECT concat(surname,' ',onames) as nams,telno,address FROM stf WHERE idno LIKE '$data[1]'; SELECT payee,telno,address FROM acc_exppayee WHERE idno LIKE '$data[1]'; SELECT 
        alt_names,telno,paddress FROM acc_alterincome WHERE idno LIKE '$data[1]';"; mysqli_multi_query($conn,$sql); $i=0; $got=false;
        do{
            if(!$got && $rs=mysqli_store_result($conn)){
                if($i==0){if(mysqli_num_rows($rs)>0){$got=true;	$d=mysqli_fetch_row($rs); echo strtoupper($d[0]).'-'.$d[1].'-'.$d[2];}}
                elseif($i==1){if(mysqli_num_rows($rs)>0){$got=true;	$d=mysqli_fetch_row($rs); echo strtoupper($d[0]).'-'.$d[1].'-'.$d[2];}}
                else{if(mysqli_num_rows($rs)>0){$got=true;	$d=mysqli_fetch_row($rs); echo strtoupper($d[0]).'-'.$d[1].'-'.$d[2];}}
            }$i++;	
        }while(mysqli_next_result($conn));	
        if($got==false) echo '0-0-0';
    } mysqli_close($conn);
?>