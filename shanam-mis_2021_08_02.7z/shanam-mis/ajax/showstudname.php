<?php
    include_once('../../conn/pri_sch_connect.inc');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0] 0 find stud,1 uniform purchase lists, [1] adm. no./purchase no [2] 0-uniform 1 surmedical
    $rs=mysqli_query($conn,"SELECT scnm,concat(scadd,' TEL NO. ',telno) as addr FROM ss;"); list($scnm,$scadd)=mysqli_fetch_row($rs); mysqli_free_result($rs);
    if($data[0]==0){//Find students
        $opt="";
        mysqli_multi_query($conn,"SELECT a.abbr FROM acc_votes v Inner Join acc_voteacs a On (v.acc=a.acno) WHERE v.abbr LIKE 'uniform%'; SELECT concat(s.surname,' ',s.onames) as
        nam,concat(cn.clsname,'-',c.stream) As cls FROM stud s Inner Join class c USING (admno,curr_year) Inner JOin classnames cn On (c.clsno=cn.clsno) WHERE s.admno LIKE '$data[1]' and
        s.markdel=0 and s.present=1"); $nofs=$i=0;
        do{
            if($rs=mysqli_store_result($conn)){
                if($i==0){
                    list($accname)=mysqli_fetch_row($rs);
                }else{
                    $nofs=mysqli_num_rows($rs);
                    if($nofs>0){$d=mysqli_fetch_row($rs); $txt=($data[2]==0?($accname.' UNIFORM ORDERS BY'):'MEDICAL BILL FOR').' ADM. NO.'.$data[1].' <u>'.$d[0].' </u> FORM/GRADE '.$d[1];}
                    else $txt='NO STUDENT FOUND WITH ADMISSION NUMBER '.$data[1];
                }mysqli_free_result($rs);
            }$i++;
        }while(mysqli_next_result($conn));
        $txt.='<input name="txtAdmNo" id="txtAdmNo" type="hidden" value="'.($nofs>0?$data[1]:'').'">';
        echo $txt;
    }else{ //find Uniform purchases
        mysqli_multi_query($conn,"SELECT concat(s.surname,' ',s.onames) as nam,concat(cn.clsname,'-',c.stream) As cls,up.purchasedon FROM stud s Inner Join class c USING (admno,curr_year)
        Inner Join classnames cn On (c.clsno=cn.clsno) Inner Join unifrmpurchase up On (s.admno=up.admno) WHERE up.purchno LIKE '$data[1]'; SELECT u.uname,u.unitsale,p.qty,u.amt,(p.qty*
        u.amt) as price FROM uniforms u Inner Join unipurchdetails p USING (unifrmno) WHERE p.purchno LIKE '$data[1]' ORDER BY p.unifrmno ASC;"); $i=0;
        do{
            if ($rs=mysqli_store_result($conn)){
                if($i==0){
                    $stud=mysqli_fetch_row($rs);
                    echo '<table border="0"><tr><th rowspan="3" style="border=0;border-bottom:1px solid #00f;"><img width="60" height="60" src="/gen_img/logo.jpg"
                    vspace="1" hspace="1" data-holder-rendered="true"/></th><th colspan="2" style="border=0;">'.$scnm.'</th></tr><tr><th colspan="2" style="border=0;">'.strtoupper($scadd).
                    '</th></tr><tr><th style="border=0;border-bottom:1px solid #00f;">LIST OF UNIFORM PURCHASED</th><th style=\"text-align:right;border=0;border-bottom:1px solid #00f;
                    font-size:8px;\">Printed On '.date('D d M, Y').'</th></tr>';
                    echo '<tr><td colspan="3" style="border=0;"><p>UNIFORM PURCHASED BY '.strtoupper($stud[0].'<br> CLASS '.$stud[1].' on '.date('D, d M, Y',strtotime($stud[2]))).'</p><table
                    align="center"><tr><th>UNIFORM NAME</th><th>UNIT OF ISSUE</th><th>QUANTITY</th><th>UNIT PRICE</th><th>AMOUNT</th></tr>';
                }else{
                    $ttl=0;
                    while($uni=mysqli_fetch_row($rs)){ echo '<tr><td>'.$uni[0].'</td><td>'.$uni[1].'</td><td style="text-align:right">'.number_format($uni[2],2).'</td><td
                      style="text-align:right">'.number_format($uni[3],2).'</td><td style="text-align:right;font-weight:bold;"><b>'.number_format($uni[4],2).'</b></td></tr>';  $ttl+=$uni[4];
                    }echo '<tr><td style="text-align:right;" colspan="4"><b>TOTAL UNIFORM PURCHASED</b></td><td style="text-align:right;font-weight:bold;"><b>'.number_format($ttl,2).'</b></td>
                    </tr></table>';
                    echo '<br><br><b>Signature _____________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    Bursar/ Acc. Clerk</b></td></tr></table>';
                }
            }$i++;
        }while(mysqli_next_result($conn));
    } mysqli_close($conn);
?>
