<?php
    session_start();
    include_once('../../conn/pri_sch_connect.inc');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0] 0 viewing 1 editing,[1]- Account
    $rs=mysqli_query($conn,"SELECT ucase(abbr) as nam FROM acc_voteacs WHERE acno LIKE '$data[1]'");
    if(mysqli_num_rows($rs)>0) list($acname)=mysqli_fetch_row($rs); mysqli_free_result($rs);
    $h=$acname.' FEE STRUCTURE';
    echo '<h5 style="font-weight:strong;letter-spacing:1px;word-spacing:2px;background-color:#000;color:#fff;text-align:center;">'.$h.'.</h5>'.($data[0]!=0?'<form method="post"
    action="FSEfeestruct.php" name="frmFSEFeeStruct" onsubmit="return validateData(this)">':'');
    echo '<table class="table-striped" style="border:0;"><tr><th>VOTEHEAD</th><th>TERM I</th><th>TERM II</th><th>TERM III</th><th>TOTAL</TH></TR>';
    $rs=mysqli_query($conn,"SELECT f.yr,f.voteno,v.descr,f.t1,(f.t2-f.t1) as term2,(f.t3-f.t2) as term3,t3 FROM acc_feestruct f inner join acc_votes v on (f.voteno=v.sno) WHERE
    v.acc LIKE '$data[1]' and f.yr IN (SELECT finyr FROM ss) Order By f.voteno Asc");	$nofs=mysqli_num_rows($rs);		$i=0; $ttlAmt=array(0,0,0,0);
    while (list($yr,$voteno,$vote,$t1,$t2,$t3,$ttl)=mysqli_fetch_row($rs)){
        if ($data[0]==0){//viewing data
            echo '<tr><td>'.$vote.'</td><td style="text-align:right;">'.number_format($t1,2).'</td><td style="text-align:right;">'.number_format($t2,2).'</td>
            <td style="text-align:right;">'.number_format($t3,2).'</td><td style="text-align:right;font-weight:bold;">'.number_format($ttl,2).'</td></tr>';
        }else{//Editing
            $cuyr=$yr;
            echo '<tr><td><input type="hidden" name="txtV_'.$i.'" id="txtV_'.$i.'" value="'.$voteno.'">'.$vote.'</td><td><input type="text" name="txtT1_'.$i.'" class="modalinput"
            id="txtT1_'.$i.'" value="'.number_format($t1,2).'" required onkeyup="checkData(this)" onblur="getTotal('.$i.','.$nofs.')" style="text-align:right;"></td><td>
            <input type="text" name="txtT2_'.$i.'" id="txtT2_'.$i.'" value="'.number_format($t2,2).'" onblur="getTotal('.$i.','.$nofs.')" required onkeyup="checkData(this)"
            style="text-align:right;" class="modalinput"></td><td><input type="text" name="txtT3_'.$i.'" id="txtT3_'.$i.'" value="'.number_format($t3,2).'" required onkeyup="checkData(this)"
            onblur="getTotal('.$i.','.$nofs.')" style="text-align:right;"  class="modalinput"></td><td><input type="text" name="txtTtl_'.$i.'" id="txtTtl_'.$i.'" value="'.number_format($ttl,
            2).'" required style="text-align:right;background:#ddd;font-weight:bold;" readonly  class="modalinput"></td></tr>';
        } $ttlAmt[0]+=$t1; $ttlAmt[1]+=$t2; $ttlAmt[2]+=$t3; $ttlAmt[3]+=$ttl; $i++;
    }    echo '<tr><td align="right"><b>Term\'s Totals</b></td>'; $i=0;
    foreach ($ttlAmt as $amt){
        echo '<td align="right"><input type="text" name="txtTermTtl_'.$i.'" id="txtTermTtl_'.$i.'" value="'.number_format($amt,2).'" required style="text-align:right;
        background:#ddd;font-weight:bold;" readonly  class="modalinput"></td>'; $i++;
    }
    echo '</tr></table>';
    if ($data[0]==1) echo '<hr><center><input type="hidden" name="txtData" id="txtData" value="'.$cuyr.'-'.$data[1].'-'.$nofs.'"><button type="submit" class="btn btn-md btn-primary"
    name="btnSaveFS">Save Fee Structure</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="fsegrants.php"><button type="button" class="btn btn-info
    btn-md" name="btnCloseFS">Cancel/ Close</button></a> </center></form>';
    else echo '<a href="#" onclick="printSpecific(\'divFeeStruct\')"><img src="../../gen_img/print.ico" width="20" height="20">Print</a>';
    mysqli_free_result($rs);     mysqli_close($conn);
?>
