<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data); //[0]-dept, [1]-Requisition No.
	echo '<label for="cboItem">Item Requested</label><SELECT name="cboItem" id="cboItem" size="4" class="modalinput" onchange="showNewItem(this)" onchange="viewNew(this)">';
	$rs=mysqli_query($conn,"SELECT i.itmcode,concat(i.itemname,' - ',i.units,' @ Kshs.',i.unitprice) as nam FROM items i WHERE (i.deptno is null OR i.deptno LIKE '$data[1]')
	and i.markdel=0 and i.itmcode NOT IN (SELECT itmcode FROM acc_reqitems WHERE reqno LIKE '$data[2]') Order By itemname ASC") or die(mysqli_error($conn).' Error in database connection');
	$i=0;
	if (mysqli_num_rows($rs)>0) while (list($no,$name)=mysqli_fetch_row($rs)){echo '<option value="'.$no.'" '.($i==0?"selected":"").'>'.$name.'</option>'; $i++;}
	echo '<option value="0" '.($i>0?'':'selected').'>New Item</option>';
	mysqli_free_result($rs);
	print '</SELECT>'; mysqli_close($conn);
?>
