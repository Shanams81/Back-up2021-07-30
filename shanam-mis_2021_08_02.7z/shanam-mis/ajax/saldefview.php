<?php
    include_once('../../conn/pri_sch_connect.inc');
    $pf=isset($_REQUEST['pfno'])?sanitize($_REQUEST['pfno']):'0-0';   $pf=preg_split('/\-/',$pf);
    mysqli_multi_query($conn,"SELECT s.idno,concat(s.surname,' ',s.onames,' (',designation,')') as nam,s.jg,concat(d.bankname,' BANK - ',d.bankbranch,'<br>A/C NO. ',d.accountno) as pp,
    d.nssfno,d.nhifno,d.bsal,d.houseallow,d.medicalallow,d.empnssf,d.travellallow,d.responsallow,d.nssffee,d.nhiffee,d.paye,d.mpr,d.unionfee,d.saccofee,d.welfare,d.otherlevies FROM stf s
    Inner Join acc_saldef d USING (idno) WHERE d.payrollno LIKE '$pf[0]' and d.markdel=0; SELECT schtype FROM ss;");
    $i=$scht=0;
    do{
      if($rs=mysqli_store_result($conn)){
          if($i==0) list($idno,$name,$jg,$pp,$nssfno,$nhifno,$bsal,$house,$med,$empnssf,$comm,$response,$nssf,$nhif,$paye,$mpr,$union,$sac,$wel,$ole)=mysqli_fetch_row($rs);
          else list($scht)=mysqli_fetch_row($rs);
          mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
?>
<br><div class="container" style="margin:auto;background-color:#eee;max-width:500px;"><div class="row"><div class="col-md-12 mb-3" style="background:#000;color:#fff;">SALARY FOR ID NO. <?php
echo " $idno <u>".strtoupper($name)."<br>JOB GROUP $jg";?></u></div></div>
<div class="row"><div class="col-md-3 mb-3">Payroll No. <?php echo $pf[0];?></div><div class="col-md-8 mb-3"><b>Paypoint </b><?php echo $pp;?></div></div>
<div class="row"><div class="col-md-4 mb-3">N.S.S.F No. <?php echo $nssfno;?></div><div class="col-md-8 mb-3">N.H.I.F No. <?php echo $nhifno;?></div></div>
<div class="row"><div class="col-md-12 mb-3">
<table class="table-striped table-condensed" style="border:0px;"><thead><tr><th colspan="2" style="letter-spacing:3px;word-spacing:4px;">SALARY ALLOWANCES</th>
<th colspan="2" style="letter-spacing:3px;word-spacing:4px;">SALARY DEDUCTIONS</th></tr></thead><tbody>
<tr><td>Basic Salary</td><td align="right"><?php echo number_format($bsal,2);?></td><td>NSSF Fee</td><td align="right"><?php echo number_format($nssf,2);?></td></tr>
<tr><td>Housing</td><td align="right"><?php echo number_format($house,2);?></td><td>NHIF Fee</td><td align="right"><?php echo number_format($nhif,2);?></td></tr>
<tr><td>Medical</td><td align="right"><?php echo number_format($med,2);?></td><td><?php echo ($scht==0?"Elimu":"Union Fee");?></td><td align="right"><?php echo number_format($union,2);?></td></tr>
<tr><td>Commuter</td><td align="right"><?php echo number_format($comm,2);?></td><td>PAYE Auto</td><td align="right"><?php echo number_format(($paye-$mpr),2);?></td></tr>
<tr><td>Responsibility/Duty</td><td align="right"><?php echo number_format($response,2);?></td><td><?php echo ($scht==0?"K . D . S":"SACCO");?></td><td align="right">
<?php echo number_format($sac,2);?></td></tr>
<tr><td>Employer NSSF</td><td align="right"><?php echo number_format($empnssf,2);?></td><td>Welfare</td><td align="right"><?php echo number_format($wel,2);?></td></tr>
<tr><td colspan="2"></td><td><?php echo ($scht==0?"Rent":"Other Deductions");?></td><td align="right"><?php echo number_format($ole,2);?></td></tr>
<tr><td><b>GROSS SALARY</b></td><td align="right"><b><?php echo number_format(($bsal+$med+$house+$comm+$empnssf),2);?></b></td><td><b>TOTAL DEDUCTIONS</b></td><td align="right">
<b><?php echo number_format(($ole+($paye-$mpr)+$union+$nssf+$empnssf+$nhif+$sac+$wel),2);?></b></td></tr>
<tr><td colspan="3" align="right"><b>GROSS SALARY</b></td><td align="right"><b>
  <?php echo number_format((($bsal+$med+$house+$comm+$empnssf)-($ole+($paye-$mpr)+$union+$nssf+$empnssf+$nhif+$sac+$wel)),2);?>
</b></td></tr></tbody></table></DIV></div>
<?php mysqli_close($conn);  ?>
