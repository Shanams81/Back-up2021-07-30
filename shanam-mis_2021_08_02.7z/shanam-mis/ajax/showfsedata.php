<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['rno']))); $data=preg_split('/\-/',$data);	//[0] 0 Tranche No., 1 Banks , 2-Votehead balances, 3- [1]- Account
	if ($data[0]==0){
    mysqli_multi_query($conn,"SELECT max(batchno) as bn FROM acc_fseincome GROUP BY acc,markdel,commt HAVING markdel=0 and commt=0 and acc LIKE '$data[1]'; SELECT a.sno,concat(b.abbr,
    ' - A/C ',a.accno) as acc FROM acc_accounts a Inner Join acc_banks b ON (a.bankno=b.sno) WHERE accacc LIKE '$data[1]'; SELECT f.voteno,v.acc,v.descr,(f.t3-if(isnull(i.vamt),0,
    (i.vamt))) as bal FROM acc_votes v INNER JOIN acc_feestruct f ON (v.sno=f.voteno) LEFT JOIN (SELECT v.voteno,sum(v.amt/i.noofstud) as vamt FROM acc_fseincome i INNER JOIN
		acc_fsevotes v USING (recno,acc) GROUP BY v.acc,v.voteno,v.markdel,i.commt HAVING v.markdel=0 and i.commt=0 and v.acc LIKE '$data[1]')i using (voteno) WHERE v.acc LIKE '$data[1]'
		and	v.fs_defined=1;");    $i=0; $tn=$bank='';
    $votes='<div class="form-row"><div class="col-md-6 divsubheading">VOTEHEAD</div><div class="col-md-3 divsubheading">BALANCE</div><div class="col-md-3 divsubheading">AMOUNT</div>
		</div>';
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){ if(mysqli_num_rows($rs)>0)list($d)=mysqli_fetch_row($rs); else $d=0; $d++; $tn=$d;
        }elseif($i==1){
          $bank.="<SELECT name=\"cboBank\" id=\"cboBank\" size=1 class=\"modalinput\"><option value=\"0\" selected>Choose Bank A/C</option>";
          if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $bank.="<option value=\"$d[0]\">$d[1]</option>";
          $bank.="</SELECT>";
        }else{
          $nov=mysqli_num_rows($rs); $c=$ttl=0; $votes.="<input name=\"txtNOV\" id=\"txtNOV\" type=\"hidden\" value=\"$nov\">";
          while ($dat=mysqli_fetch_row($rs)){
            $votes.="<div class=\"form-row\"><div class=\"col-md-6\">$dat[2]<input type=\"hidden\" name=\"txtVote_$c\" id=\"txtVote_$c\" value=\"$dat[0]-$dat[1]\"></div><div
						class=\"col-md-3\"><input type=\"text\" name=\"txtBal_$c\" id=\"txtBal_$c\" value=\"".number_format($dat[3],2)."\" readonly class=\"modalinput numbersinput
						modalinputdisabled\"></div><div class=\"col-md-3\"><input type=\"text\" name=\"txtVAmt_$c\" id=\"txtVAmt_$c\" value=\"0.00\" onkeyup=\"checkData(1,this)\"
						onchange=\"confirmBal($c)\" class=\"modalinput numbersinput\"></div></div>";	$ttl+=$dat[3]; $c++;
          } $votes.="<hr><div class=\"form-row\"><div class=\"col-md-6\">TOTAL AMOUNT</div><div class=\"col-md-3\"><input type=\"text\" name=\"txtTtlBal\" id=\"txtTtlBal\"
					value=\"".number_format($ttl,2)."\" readonly class=\"modalinput numbersinput modalinputdisabled\"></div><div class=\"col-md-3\"><input type=\"text\" name=\"txtTtlVAmt\"
					id=\"txtTtlVAmt\"  readonly value=\"0.00\" class=\"modalinput numbersinput modalinputdisabled\"></div></div>";
        } mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
    echo "$tn~$bank~$votes";
	}else{
    mysqli_multi_query($conn,"SELECT v.sno,v.descr FROM acc_votes v WHERE v.acc LIKE '$data[1]' and other_inco=1; SELECT a.sno,concat(b.abbr,' - A/C ',a.accno) as acc FROM
		acc_accounts a Inner Join acc_banks b ON (a.bankno=b.sno) WHERE accacc LIKE '$data[1]';"); $i=0; $votes=$bank='';
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){
					$votes.='<SELECT name="cboVotes" id="cboVotes" size=1  class="modalinput"><option value=\"0\" selected>Choose Votehead</option>';
          if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $votes.="<option value=\"$d[0]\">$d[1]</option>";
          $votes.='</SELECT>';
				}else {
					$bank.="<SELECT name=\"cboBank\" id=\"cboBank\" size=1  class=\"modalinput\"><option value=\"0\" selected>Choose Bank A/C</option>";
					if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $bank.="<option value=\"$d[0]\">$d[1]</option>";
					$bank.="</SELECT>";
				}mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn));
    echo "$votes~$bank";
	}mysqli_close($conn);
?>
