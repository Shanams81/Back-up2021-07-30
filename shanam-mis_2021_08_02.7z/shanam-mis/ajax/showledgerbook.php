<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data); //[0]-Acc No, [1]-Votehead No.
	mysqli_multi_query($conn,"SELECT finyr,scnm,concat(scadd,' Tel. No. ',telno) as ad FROM ss; SELECT v.lfn,v.descr,a.descr as acc FROM acc_votes v Inner JOIN acc_voteacs a ON (v.acc=a.acno) WHERE v.markdel=0 and v.acc LIKE
	'$data[0]' and v.sno LIKE '$data[1]';SELECT m.mon,if(isnull(i.inco),0,i.inco) as inc,if(isnull(e.exp),0,e.exp) as ex FROM (WITH RECURSIVE seq AS (SELECT 1 AS mon UNION ALL SELECT mon + 1 FROM seq WHERE
	mon<month(curdate())) SELECT * FROM seq)m LEFT JOIN	(SELECT month(i.recon) As mon,sum(v.amt)As inco FROM ".($data[0]==1?"acc_incorecno0":($data[0]==2?"acc_incorecno1":"acc_fseincome"))." i Inner Join ".($data[0]<3?
	"acc_incovotes":"acc_fsevotes")." v USING (recno,acc) inner Join ss on (year(i.recon)=ss.finyr) GROUP BY month(i.recon),i.markdel,v.voteno,year(i.recon) Having i.markdel=0 and v.voteno LIKE '$data[1]')i USING (mon)
	LEFT JOIN (SELECT month(pytdate) as mon,sum(amt) as exp FROM acc_pytvotes v Inner Join ss ON (year(v.pytdate)=ss.finyr) GROUP BY year(v.pytdate),month(pytdate),voteno,markdel HAVING voteno LIKE '$data[1]' and markdel=0)e
	using (mon);");	$valid=$dr=$cr=$i=$ends=0; $scnm=$scad=$lfn=$votenm=$acnm=$tbl='';
	do{if($rs=mysqli_store_result($conn)){ if($i==0) list($finyr,$scnm,$scad)=mysqli_fetch_row($rs);	elseif($i==1) list($lfn,$votenm,$acnm)=mysqli_fetch_row($rs);
		else{while($d=mysqli_fetch_row($rs)){ $date=date('F', mktime(0, 0, 0, $d[0], 10))." - ".date('t',strtotime($finyr.'-'.$d[0].'-01')); $tbl.="<tr><td>".$date."</td><td>Cash Book (CB)</td><td align=\"right\">".
			number_format($d[1],2)."</td><td>$date</td><td>Cash Book (CB)</td><td align=\"right\">".number_format($d[2],2)."</td></tr>"; $dr+=$d[1]; $cr+=$d[2]; $ends++;}} mysqli_free_result($rs);}$i++;
	}while(mysqli_next_result($conn));
	print "<div class=\"form-row\"><div class=\"col-md-1\"><img src=\"/gen_img/logo.jpg\" width=\"50\" height=\"60\"></div><div class=\"col-md-11\"><div class=\"form-row\"><div class=\"col-md-12\">$scnm</div></div><div
	class=\"form-row\"><div	class=\"col-md-12\">$scad</div></div><div class=\"form-row\"><div class=\"col-md-9\">FY$finyr $acnm - LEDGER BOOK</div><div class=\"col-md-3\" style=\"text-align:right\">Date: ".date("D d M, Y").
	"</div></div></div></div><div class=\"form-row\"><div class=\"col-md-12\">";
	print "<table class=\"table table-hover table-sm table-stripped table-bordered\"><thead><tr><th class=\"hborder\" style=\"font-weight:bold\" colspan=\"6\">LEDGER FOLIO NO. $lfn&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;VOTEHEAD:<u>$votenm</u></th></tr><tr><th align=\"right\" colspan=\"3\">D E B I T</th><th colspan=\"3\" align=\"right\">C R E D I T</th></tr><tr><th>DATE</th><th>DETAILS</th><th>AMOUNT</th><th>DATE</th><th>
	DETAILS</th><th>AMOUNT</th></tr>$tbl"; $ends++; while($ends<13){
		$date=date('F', mktime(0, 0, 0, $ends, 10))." - ".date('t',strtotime($finyr.'-'.$ends.'-01')); print "<tr><td>".$date."</td><td></td><td></td><td></td><td></td><td align=\"right\"></td></tr>";
		$ends++;
	}	print "<tr><td colspan=\"2\" align=\"right\"><b>Total Income</b></td><td align=\"right\"><b>".number_format($dr,2)."</b></td><td colspan=\"2\" align=\"right\"><b>Total Credit</b></td><td align=\"right\"><b>".
	number_format($cr,2)."</b></td></tr></table></td></tr></table></div></div>";
	print "<div class=\"form-row\"><div class=\"col-md-12\" style=\"text-align:right\"><img src=\"/gen_img/print.ico\" width=\"50\" height=\"40\" onclick=\"Clickheretoprint()\" title=\"Print Ledgerbook Report\"></div></div>";;
	mysqli_close($conn);
?>
