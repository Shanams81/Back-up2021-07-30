<?php
	session_start(); include_once('../../conn/pri_sch_connect.inc');
	$data=sanitize($_REQUEST['q']); $data=preg_split('/\-/',$data);
	//[0] 0 new 1 edit,[1] reg no. [2] name [3] addr [4] EMail [5] tel
	$data[2]=mysqli_real_escape_string($conn,$data[2]);		$data[3]=mysqli_real_escape_string($conn,$data[3]); $de=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
	if (strlen($data[2])>10 && strlen($data[3])>10 && strlen($data[4])>8){
		if ($data[0]==0) $sql="INSERT INTO acc_creditors (cred_no,yr,name,paddress,email,telno,regdate,categ,addedby) VALUES (0,year(curdate()),".var_export($data[2],true).",".
		var_export($data[3],true).",".var_export($data[4],true).",".var_export($data[5],true).",curdate(),1,'$de')";
		else $sql="UPDATE acc_creditors SET name=".var_export($data[2],true).",paddress=".var_export($data[3],true).",email='$data[4]',telno='$data[5]' WHERE cred_no=$data[1] and categ=1;";
		mysqli_query($conn,$sql) or die(mysqli_error($conn)." Hospital details were not saved. Click <a href=\"spemedical.php\">here</a> to go back.");
		echo "<p style=\"font-size:1rem;color:#f00\">".mysqli_affected_rows($conn)." Hospital facility details Successfully Saved!!!.</p>";
	}else echo "<p style=\"font-size:1rem;color:#f00\">Ensure Hospital facility details are validly entered before saving</p>";
	echo "<table class=\"table-striped table-hover\"><thead><tr><th>#</th><th>Name of Facility</th><th>Address</th><th>E - Mail</th><th>Telno</th><th>Registered On</th><th>Action</th></tr>
	</thead><tbody>"; $count=$edi=$i=0;
	mysqli_multi_query($conn,"SELECT feeedit FROM acc_Priv Where Uname LIKE '".$_SESSION['username']."'; SELECT cred_no,name,paddress,email,telno,regdate FROM acc_creditors WHERE markdel=0
	and categ=1");
	do{
		if($rs=mysqli_store_result($conn)){
			if($count==0){ list($edi)=mysqli_fetch_row($rs);
			}else{
				$i=mysqli_num_rows($rs); $a=1;
				if ($i>0) while (list($credno,$name,$addr,$email,$tel,$date)=mysqli_fetch_row($rs)){
					print "<tr><td>$a</td><td>$name</td><td>$addr</td><td>$email</td><td>$tel</td><td>".date('D d M, Y',strtotime($date))."</td><td align=\"center\">".($edi==1?"<a href=\"#\"
					onclick=\"editHospital($credno)\">Edit</a>":"-")."</td></tr>"; $a++;
				}
			}mysqli_free_result($rs);
		}$count++;
	}while(mysqli_next_result($conn));
	print "</tbody><tfoot><tr class=\"nohover\"><td colspan=\"7\" style=\"letter-spacing:6px;word-spacing:9px;font-weight:bold;\">$i Hospital Facilities</td></tr></tfoot></table>";
	mysqli_close($conn);
?>
