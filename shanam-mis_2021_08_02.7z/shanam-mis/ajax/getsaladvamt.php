<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0]-Pyroll no and [1] random
	//work on salary advances
	$rs=mysqli_query($conn,"SELECT a.advno,a.payrollno,if((a.amt-IF(isnull(c.clr),0,c.clr))>a.amtperduration,a.amtperduration,(a.amt-IF(isnull(c.clr),0,c.clr))) AS Bal FROM 
	Acc_Adv a LEFT JOIN (SELECT advano,sum(amt_clr) as clr FROM Acc_AdvClr GROUP BY advano,markdel HAVING markdel=0)c ON a.advno=c.advano WHERE a.markdel=0 and (a.amt-
	IF(isnull(c.clr),0,c.clr))>0 and a.payrollno LIKE '$data[0]' ORDER BY a.payrollno ASC"); 
	$noa=mysqli_num_rows($rs); $sql=''; $amt=0;
	if ($noa>0){ 
	 	$i=0; $sql="INSERT INTO acc_advclr(clrno,advano,clr_date,amt_clr,rmks,salno) VALUES "; 
		while ($adv=mysqli_fetch_row($rs)){
			$sql.=($i>0?",":"")."(0,$adv[0],curdate(),$adv[2],'Recovered from salary',$data[1])";
			$amt+=$adv[2]; $i++;
		}
		echo "$amt~$sql";
	}else{echo '0~0';}
?>