<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0]-acc no.
	$opt="";
	$rs=mysqli_query($conn,"SELECT sno,descr FROM acc_votes WHERE acc LIKE '$data[0]' and markdel=0 ORDER BY sno ASC");
	while($d=mysqli_fetch_row($rs)) $opt.="<option value=\"$d[0]\">$d[1]</option>"; mysqli_free_result($rs);
	echo 'Votehead Where Income is Received *<br><SELECT name="cboVote" id="cboVote" size="1" class="t"><option value=""></option>'.$opt.'</SELECT><br><br>Cumulative Votehead 
	For Above Votehead <br><SELECT name="cboCVote" id="cboCVote" size="1" class="t"><option value=""></option>'.$opt.'</SELECT></td></tr>';
	mysqli_close($conn);
?>