<?php
	session_start();
	include_once('../../conn/pri_sch_connect.inc');
	$data=sanitize($_REQUEST['sno']); $data=preg_split('/\./',$data);	//[0] 0 Defaulters, [1] leaveout serial no [2] no. of days after processing
	$sql="SELECT leaveoutcancel FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT l.returndate,if(isnull(c.lvlno),'All ',concat('Class ',c.lvlname)) as nm,l.minbal FROM
	acc_leaveout l Left Join classlvl c USING (lvlno) WHERE l.sno LIKE '$data[1]';  SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,
	l.paid,l.bal,if(isnull(l.delreason),'".($data[2]<0?"Went Home":"To Go Home")."',l.delreason) as rmks FROM  stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn
	USING (clsno) INNER JOIN acc_leaveoutstud l USING (admno) WHERE l.status=";
	if($data[0]==0) $sql.="0 "; else $sql.="1 "; $sql.=" and l.sno LIKE '$data[1]' ORDER BY cn.clsname,c.Stream,s.admno ASC";
	mysqli_multi_query($conn,$sql); $index=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if ($index==0) list($del)=mysqli_fetch_row($rs);
			elseif($index==1){
				list($date,$cls,$bal)=mysqli_fetch_row($rs);
				$h=$data[0]==0?"sent":"exempted from going";
				echo '<h6>'.strtoupper($cls.' students '.$h.' home on '.date('D d F,Y',strtotime($date))).' WITH FEE BALANCE OF AT LEAST KSHS. '.number_format($bal).'.</h6><table class="table
				table-hover table-bordered table-sm" id="tabDefaulter"><thead class="thead-dark"><tr><th>S/No</th><th>Adm. No.</th><th>Students Names</th><th>Class</th><th>Fee Paid</th><th>Fee
				Bal</th><th>Status</th><th>Action</th></tr></thead><tbody>';
			}else{
				$i=1; $paid=0; $bal=0; $nos=mysqli_num_rows($rs);
				if($nos>0){while($dat=mysqli_fetch_row($rs)){ $counter=0; print "<tr><td>$i.</td>";
					foreach($dat as $d){
					 	if($counter==0) $admno=$d;
						if($counter<3 || $counter>4) echo "<td>$d</td>";
						elseif($counter==3){$paid+=$d; echo "<td style=\"text-align:right;\">".number_format($d,2)."</td>";}
						else{$bal+=$d; echo "<td style=\"text-align:right;\">".number_format($d,2)."</td>";} $counter++;
					}echo "<td style=\"text-align:center;\">".($data[2]<0?"-":(($data[0]==0 && $del==1)?"<img src=\"/gen_img/del.ico\" height=\"20\" width=\"20\" alt=\"Delete\" title=\"Delete\"
					onclick=\"leaveOutStudDel($i,$data[1],$admno)\">":($del==1?"<a href=\"leaveout.php?leaveoutRestore=$data[1]-$admno\">Restore</a>":"")))."</td></tr>"; $i++;
				}echo "</tbody>";} echo "<tfoot class=\"thead-light\"><tr><th colspan=3><span id=\"spNoStud\">$nos Student(s)' Leaveout Sheets</span></th><th style=\"text-align:right;\">
				Total</th><th style=\"text-align:right;\"><span id=\"spPaid\">".number_format($paid,2)."</span></th><th style=\"text-align:right;\"><span id=\"spBal\">".
				number_format($bal,2)."</span></th><th colspan=2></th></tr></tfoot></table>";
			}mysqli_free_result($rs);
		}$index++;
	}while(mysqli_next_result($conn)); 	mysqli_close($conn);
?>
