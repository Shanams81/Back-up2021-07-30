<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=sanitize($_REQUEST['bno']); $data=preg_split('/\-/',$data);
	$sql="SELECT scnm,concat(scadd,', Tel No. ',telno) as addr FROM ss; SELECT sourcename,pytfrm,cheno,Amt FROM acc_burs WHERE bursno LIKE '$data[0]'; SELECT f.recno,f.pytdate,s.admno,
	concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,f.ttl FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno)
	INNER JOIN (SELECT f.recno,i.pytdate,i.bursno,i.admno,((f.amt-f.refunds-f.transfer)+If(isnull(m.amt),0, m.amt)) AS TTL FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) LEFT
	JOIN (SELECT sno,(amt-transfer) as amt FROM acc_incorecno1 m WHERE markdel=0)m ON (i.sno=m.sno) WHERE i.markdel=0 AND i.bursno LIKE '$data[0]')f ON s.admno=f.admno ORDER BY f.recno,
	s.surname,s.onames ASC;"; mysqli_multi_query($conn,$sql); $index=0;
	echo '<table id="tabStudents" border="1" class="table table-striped table-sm table-hover table-bordered"><caption style="letter-spacing:2px;word-spacing:3px;color:#00a;caption-side:top;
	font-weight:bold;font-size:10pt;text-align:justify;">';
	do{
    if($rs=mysqli_store_result($conn)){
			if($index==0){
				list($scnm,$addr)=mysqli_fetch_row($rs);
				echo '<img src="/gen_img/logo.jpg" align=left width="60" height="60">'.$scnm.'<br>'.$addr.'<br>';
			}elseif($index==1){
        list($name,$pytfrm,$cheno,$amt)=mysqli_fetch_row($rs);
        $h="beneficiaries of $name bursary received as $pytfrm $cheno";
        echo strtoupper($h).'</CAPTION><thead class="thead-dark"><tr class="nohover"><th>Receipt No.</th><th>Date</th><th>Adm. No.</th><th>Student Names</th><th>Form</th><th>Amount</th></tr>
        </thead><tbody>';
      }else{
        $i=1; $ttl=0; $nos=mysqli_num_rows($rs);
        if($nos>0){while (list($brn,$dt,$ad,$bsn,$bfr,$btt)=mysqli_fetch_row($rs)){
            echo "<tr><td>$brn</td><td align=\"right\">".date("D d M, Y",strtotime($dt))."</td><td>$ad</td><td>$bsn</td><td>$bfr</td><td align=\"right\">".number_format($btt,
            2)."</td></tr>";		$ttl+=$btt;
        }}else echo "<td colspan=6 style=\"font-size:12pt;font-weight:bold;letter-spacing:4px;word-spacing:6px;color:#f00;\">This bursary has not been distributed to beneficiaries
        </td></tr>";
        echo "</tbody><tfoot><tr><td colspan=3><span id=\"spNoStud\">$nos Bursary Beneficiaries</span></td><td align=\"right\" colspan=2><b>Subtotals</td><td align=\"right\"><span
        id=\"spTtl\">".number_format($ttl,2)."</span></td></tr></tfoot></table>";
      }mysqli_free_result($rs);
    }$index++;
	}while(mysqli_next_result($conn));
 	mysqli_close($conn);
?>
