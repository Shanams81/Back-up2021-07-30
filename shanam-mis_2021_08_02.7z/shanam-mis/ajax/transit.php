<?php
  $insert=$conn=mysqli_connect('127.0.0.1','Acc','acc2014','shanam_mis'); if (mysqli_connect_error()) die('MYSQL Error: Error, Database cannot be opened'); mysqli_autocommit($conn,TRUE); mysqli_autocommit($insert,TRUE);
  $action=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):'0-0'; $action=explode('-',$action);
  class VoteHeads{
    private $sno,$abbr,$acc;  public function __construct($s,$a,$c){$this->sno=$s; $this->abbr=$a; $this->acc=$c;}   public function valSNo(){return $this->sno;} public function valAbbr(){return $this->abbr;}
    public function valAcc(){return $this->acc;}    public function getVotehead($ab,$ac){if(strcasecmp($this->abbr,$ab)==0 && $this->acc=$ac) return $this->sno; else return 0;}
  } $votes=[]; class FeeStruct{
    private $admno=null,$curr_year=null,$amt=null;  public function __construct($a,$y,$am){$this->admno=$a; $this->curr_year=$y; $this->amt=$am;}
    public function valAdmNo(){return $this->admno;}public function valYear(){return $this->curr_year;} public function valAmt(){return $this->amt;}
  } function getVoteHead($vo,$ke,$ac){ $vote=$i=0; $found=false; $l=count($vo); while($i<$l && !$found){$vote=($vo[$i]->getVotehead($ke,$ac)); if($vote>0) $found=true; $i++;} return $vote; }
  function annualArchive($opt,$yr,$fromconn,$toconn){
    mysqli_multi_query($toconn,"INSERT IGNORE INTO arch_votes(sno,yr,lfn,abbr,descr,expabbr,expdescr,acc,fs_defined,pyt_defined,protected,orderno,stud_fee,other_inco,markdel) VALUES (1,$yr,null,'ARREARS','ARREARS B/F',
    'SUNDRY','SUNDRY CREDITORS',1,0,0,1,1,1,0,0),(2,$yr,NULL,'REFUNDS','REFUNDS','REFUNDS','REFUNDS',1,0,0,1,1,1,0,0),(3,$yr,NULL,'SPEMED','SURCHARGED MEDICAL','SPEMED','SURCHARGED MEDICAL',1,0,0,1,1,1,0,0),(4,$yr,
    NULL,'PREPAID','PREPAYMENTS','PREPAID','PREPAYMENTS',1,0,0,1,1,1,0,0),(5,$yr,NULL,'BURSARY','BURSARY','BURSARY','BURSARY',1,0,0,1,1,1,0,0); INSERT INTO arch_votes(sno,yr,lfn,fieldname,descr,expabbr,expdescr,acc,
    fs_defined,pyt_defined,protected,orderno,stud_fee,other_inco,markdel) SELECT @sn:=@sn+1 as sno,yr,null as lfn,abbr,descr,abbr as expabbr,descr as expdescr,if(acc=1,1,if(acc=4,2,if(acc=2,3,4))) as ac,if((sno<12 ||
    (sno>16 && sno<55)),1,0) as fs_defined,if(sno<55,1,0) as pyt_defined,if(sno>55,1,0) as protected,(@sn+20) as orderno,if((sno<12 || (sno>16 && sno<29) || (sno>47 && sno<55)),1,0) as stud_fee, if(sno<55,1,0) as
    other_inco, 0 as markdel FROM acc.arch_votes,(SELECT @sn:=5)x WHERE not isnull(abbr) and yr=$yr; SELECT sno,yr,lower(abbr) as ab,acc FROM arch_votes WHERE markdel=0 AND yr=$yr; SELECT c.admno,c.curr_year,f.tuition
    as tution,f.boardingn as boarding,f.pemolum as pemolu,f.activity,f.ltt,f.rmi,f.ewc,f.contig as cont,f.eif,f.medical as med,f.caution as caut,f.insure,f.vote1,f.vote2,f.vote3,f.vote4,f.vote5,f.vote6,f.vote7,f.vote8,
    f.vote9,f.vote10,f.vote11,f.vote12 FROM acc.form c Inner Join acc.arch_feeoutline f USING (form,fee_group,curr_year) WHERE c.markdel=0 and c.curr_year=$yr; SELECT c.admno,c.curr_year,f.mvote1 as vote1,f.mvote2 as
    vote2,f.mvote3 as vote3,f.mvote5 as vote5,f.mvote6 as vote6,f.mvote7 as vote7,f.mvote8 as vote8,f.mvote9 as vote9 FROM acc.form c Inner Join acc.arch_feeoutline f USING (form,fee_group,curr_year) WHERE c.markdel=0
    and c.curr_year=$yr; SELECT if(abbr like '%uniform%' and acc=1, concat('f.',fieldname),0) as main,if((abbr like '%unif%' and acc=4),concat('m.',fieldname),0) as misc FROM arch_votes WHERE abbr LIKE '%unif%' and
    yr=$yr;") or die(mysqli_error($toconn).". ARCHIVE STEP 3. (a) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");  $i=$nv=$mainuni=$miscuni=0; $votes=[];
    do{
      if($rs=mysqli_store_result($toconn)){
        if($i<2) echo "ARCHIVE STEP 3. (b) ".mysqli_affected_rows($conn)." records uploaded.<br>";
        elseif($i==2) while($d=mysqli_fetch_row($rs)){$votes[]=new VoteHeads($d[0],$d[1],$d[2]); $nv++;}
        elseif($i==3 || $i==4){$acc=($i==15?1:2); while($d=mysqli_fetch_assoc($rs)){$c=0; $check=4; $sql=''; $admno=$d[0]; $cyr=$d[1]; foreach($d as $key=>$value){if($c>1 && $c==$check && $value>0){
          $vno=getVoteHead($votes,$key,$acc); $s=$c-2; $e=$c-1; $sql.="INSERT INTO clsfee(admno,curr_year,voteno,t1,t2,t3) VALUES ($admno,$cyr,$vno,$d[$s],$d[$e],$value);"; $check+=3;} $c++;}
          if(strlen($sql)>0) mysqli_multi_query($fromconn,$sql) or die(mysqli_error($fromconn).". STEP 2 (b) Click <a href=\"financialyearchange.php\">HERE</a> to go back."); while(mysqli_next_result($fromconn)){}}
        }else{if(mysqli_num_rows($rs)>0)list($mainuni, $miscuni)=mysqli_fetch_row($rs);}  mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));    //STEP FOUR
    $rs=mysqli_query($fromconn,"SELECT 0 as opt,f.recieptno,f.admno,f.pytdate,f.paidby,f.paytform,f.cmono,f.pytno,if(isnull(f.bank),null,1) as bn,f.addedby,f.kinddescr,f.delreason,f.commt,0 as interb_no,f.verno,
    f.verdate,f.verstate,f.verbanked,f.bankcharges,f.amt,f.arrears,f.spemed,f.refunds,if(isnull(p.amt),0,p.amt) as prep,$mainuni as unifrm,f.transfer,f.markdel,if(isnull(m.recipetno),0,m.recipetno) as mrec,
    if(isnull(m.bankcharges),0,m.bankcharges) as mbc,if(isnull(m.amt),0,m.amt) as mamt,if(isnull(m.arrears),0,m.arrears) as marrears,0 as mspemed,if(isnull($miscuni),0,$miscuni) as munifrm,0 as transfer,
    if(isnull(m.markdel),0,m.markdel) as mmarkdel FROM acc.arch_feerec f Left Join acc.arch_prep p USING (recieptno,yr) Left Join acc.arch_miscfeepyts m USING (recieptno,yr) WHERE f.yr=$yr UNION SELECT 1 as opt,
    recipetno as recieptno,payeesno as admno,pytdate,'Parent' as paidby,pytfrm as paytform,cheno as cmono,bursaryno as pytno,if(isnull(bank),null,1) as bn,addedby,kinddescr,delreason,commt,0 as interb_no,verno,verdate,
    verstate,verbanked,0 as bankcharges,0 as amt,0 as arrears,0 as spemed,0 as refunds,0 as prep,0 as unifrm,0 as transfer,0 as markdel,recipetno as mrec,bankcharges as mbc,amt as mamt, arrears as marrears,0 as mspemed,
    $miscuni as munifrm,0 as transfer,markdel as mmarkdel FROM acc.arch_miscfeepyts m WHERE isnull(recieptno) and yr=$yr"); $row=1;
    while($data=mysqli_fetch_row($rs)){
      if(mysqli_query($toconn,"INSERT INTO arch_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,addedby,kinddescr,delreason,commt,interb_no,verno,verdate,verstate,verbanked,markdel) VALUES($row,'$data[2]',
      '$data[3]','$data[4]','$data[5]',".var_export($data[6],true).",".var_export($data[7],true).",".var_export($data[8],true).",'$data[9]',".var_export($data[10],true).",".var_export($data[11],true).",'$data[12]',".
      var_export($data[13],true).",".var_export($data[14],true).",".var_export($data[15],true).",".var_export($data[16],true).",".var_export($data[17],true).",$data[26])")  or die(mysqli_error($toconn).
      ". STEP 4 (a) Click <a href=\"financialyearchange.php\">HERE</a> to go back.")){
        if($data[0]==0){$sql.="INSERT INTO arch_incorecno0(recno,yr,recon,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm,transfer,markdel) VALUES ($data[1],$yr,'$data[3]',$row,1,$data[18],$data[19],$data[20],$data[21],
          $data[22],$data[23],$data[24],$data[25],$data[26]);";
          if($data[27]>0) $sql.="INSERT INTO arch_incorecno0(recno,yr,recon,sno,acc,bc,amt,arrears,spemed,unifrm,transfer,markdel) VALUES ($data[27],$yr,'$data[3]',$row,2,$data[28],$data[29],$data[30],$data[31],$data[32],
            $data[33],$data[34]);";
        }else $sql.="INSERT INTO arch_incorecno0(recno,yr,recon,sno,acc,bc,amt,arrears,spemed,unifrm,transfer,markdel) VALUES ($data[27],$yr,'$data[3]',$row,2,$data[28],$data[29],$data[30],$data[31],$data[32],$data[33],
          $data[34]);";
        mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 4.(b) Click <a href=\"financialyearchange.php\">HERE</a> to go back."); while(mysqli_next_result($toconn)){} $row++;
      }
    }//School Fund Fees For current students
    $rs=mysqli_query($fromconn,"SELECT recieptno,pytdate,markdel,tution,boarding,activity,pemolu,ltt,rmi,ewc,cont,eif,caut,insure,medical,hire,(rent+rentfurn+rentwater+rentelect) as rent,sfinco,disporse,propreplace,spemed,
    arrears,refunds,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,vote10,vote11,vote12,bursary,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM acc.arch_feerec WHERE yr=$yr"); $nrecs=mysqli_num_rows($rs);
    if($nrecs>0){
      while($data=mysqli_fetch_assoc($rs)){$recno=$data[0]; $date=$data[1]; $mk=$data[2]; $i=0; $sql=''; foreach($data as $key=>$value){if($i>2 && $value>0){$vno=getVoteHead($votes,$key,1);
        $sql.="INSERT INTO arch_incovotes(recno,yr,acc,pytdate,voteno,amt,markdel) VALUES ($recno,$yr,1,'$date',$vno,$value,$mk);";} $i++;}
        if(strlen($sql)>0){mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 4. (c) Click <a href=\"financialyearchange.php\">HERE</a> to go back."); while(mysqli_next_result($toconn)){}}
      }
    }mysqli_free_result($rs); //Prepayments
    $rs=mysqli_query($fromconn,"SELECT recieptno,markdel,tution,boarding,activity,pemolu,ltt,rmi,ewc,cont,eif,insure,medical,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,vote10,vote11,vote12 FROM acc.arch_prep
      WHERE yr=$yr;");
    $nrecs=mysqli_num_rows($rs);
    if($nrecs>0){
      while($data=mysqli_fetch_assoc($rs)){$recno=$data[0]; $mk=$data[1]; $i=0; $sql=''; foreach($data as $key=>$value){ if($i>1 && $value>0){ $vno=getVoteHead($votes,$key,1);
        $sql.="INSERT INTO acc_incoprep(recno,acc,voteno,amt,markdel) VALUES($recno,1,$vno,$value,$mk);"; } $i++;}
        if(strlen($sql)>0){mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 3. (d) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");while(mysqli_next_result($toconn)){}}
      }
    }mysqli_free_result($rs); //Misc Fund Fees
    $rs=mysqli_query($conn,"SELECT recipetno,pytdate,markdel,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9 FROM acc.arch_miscfeepyts WHERE yr=$yr"); $nrecs=mysqli_num_rows($rs);
    if($nrecs>0){
      while($data=mysqli_fetch_assoc($rs)){$sql=''; $recno=$data[0]; $date=$data[1]; $mk=$data[2]; $i=0; foreach($data as $key=>$value){if($i>2 && $value>0){$vno=getVoteHead($votes,$key,2);
        $sql.="INSERT INTO arch_incovotes(recno,yr,acc,pytdate,voteno,amt,markdel) VALUES($recno,$yr,1,'$date',$vno,$value,$mk);";} $i++;}
        if(strlen($sql)>0){mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 3. (e) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");while(mysqli_next_result($toconn)){}}
      }
    }mysqli_free_result($rs); //FSE Fees
    mysqli_query($fromconn,"SELECT tvote1 as vote1,tvote2 as vote2,tvote3 as vote3,tvote4 as vote4,tvote5 as vote5,tvote6 as vote6,tvote7 as vote7,tvote8 as vote8,tvote9 as vote9 FROM acc.arch_oafeestruct f WHERE yr=$yr;
    SELECT ovote1 as vote1,ovote2 as vote2,ovote3 as vote3,ovote4 as vote4,ovote5 as vote5,ovote6 as vote6,ovote7 as vote7,ovote8 as vote8,ovote9 as vote9 FROM acc.arch_oafeestruct f WHERE yr=$yr;SELECT tuition as tution,
    boardingn as boarding,pemolum as pemolu,activity,ltt,rmi,ewc,contig as cont,eif,medical as med,caution as caut,insure,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,vote10,vote11,vote12 FROM
    acc.arch_feeoutline WHERE form LIKE 'two' and fee_group LIKE 'General' and curr_year=$yr; SELECT mvote1 as vote1,t1mvote1,t2mvote1,mvote2 as vote2,t1mvote2,t2mvote2,mvote3 as vote3,t1mvote3,t2mvote3,mvote5 as vote5,
    t1mvote5,t2mvote5,mvote6 as vote6,t1mvote6,t2mvote6,mvote7 as vote7,t1mvote7,t2mvote7,mvote8 as vote8,t1mvote8,t2mvote8,mvote9 as vote9,t1mvote9,t2mvote9 FROM acc.arch_feeoutline WHERE form LIKE 'two' and fee_group
    LIKE 'General' and curr_year=$yr; INSERT IGNORE INTO arch_fseincome(recno,yr,noofstud,recon,batchno,acc,acsno,amt,arrears,commt,interb_no,mode,modeno,rmks,bankno,delreason,verno,verdate,verstate,verbanked,addedby,
    markdel) SELECT recieptno,yr,noofstud,dateofpayt,batchno,if(ac='2',3,4) as acc,acsno,ttlamt,0 as arrears,commt,inter_no,mode,modeno,rmks,1 as bankno,delreason,verno,verdate,verstate,verbanked,addedby,markdel FROM
    acc.arch_oacrec WHERE yr=$yr; INSERT IGNORE INTO acc_creditordetpaid(detno,yr,vono,acc,amt) SELECT d.detno,d.yr,cast(e.voucherno as integer) as vno,e.accountno,(d.estimatedamt-d.amt) as paid FROM
    acc.arch_creditorsdet d Inner Join acc.arch_exp e ON (d.cred_no=e.expno and d.yr=e.yr and e.commt=1) WHERE (d.estimatedamt-d.amt)>0 order by d.cred_no asc;"); $sql=''; $i=0; $finyr=date('Y');
    do{
      if($rs=mysqli_store_result($fromconn)){
        if($i==0){while($d=mysqli_fetch_assoc($rs)){foreach($d as $key=>$value){if($value>0){$vno=getVoteHead($votes,$key,3); $sql.="INSERT INTO arch_feestruct(yr,lvlno,voteno,t3) VALUES ($yr,1,$vno,$value);";}}}
        }elseif($i==1){while($d=mysqli_fetch_assoc($rs)){foreach($d as $key=>$value){if($value>0){$vno=getVoteHead($votes,$key,4); $sql.="INSERT INTO arch_feestruct(yr,lvlno,voteno,t3) VALUES ($yr,1,$vno,$value);";}}}
        }elseif($i==2){while($d=mysqli_fetch_assoc($rs)){foreach($d as $key=>$value){if($value>0){$vno=getVoteHead($votes,$key,1); $sql.="INSERT INTO arch_feestruct(yr,lvlno,voteno,t3) VALUES ($yr,1,$vno,$value);";}}}
        }elseif($i==3){while($d=mysqli_fetch_assoc($rs)){foreach($d as $key=>$value){if($value>0){$vno=getVoteHead($votes,$key,2); $sql.="INSERT INTO arch_feestruct(yr,lvlno,voteno,t3) VALUES ($yr,1,$vno,$value);";}}}
        }else{echo "<br>".mysqli_num_rows($rs)." Records transferred.";} mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($fromconn));
    if(strlen($sql)>0){mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 3. (f) Click <a href=\"financialyearchange.php\">HERE</a> to go back."); while(mysqli_next_result($toconn)){}}
    //FSE acc voteheads
    $rs=mysqli_query($fromconn,"SELECT recno,if(ac=2,3,4) as acc,recievedon,markdel,arrears,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM acc.arch_fsevote
    WHERE yr=$yr;"); $nrecs=mysqli_num_rows($rs);
    if($nrecs>0){while($data=mysqli_fetch_assoc($rs)){$sql='';$recno=$data[0]; $acc=$data[1]; $date=$data[2]; $mk=$data[3]; $i=0; foreach($data as $key=>$value){if($i>2 && $value>0){$vno=getVoteHead($votes,$key,1);
      $sql.="INSERT INTO arch_fsevotes(recno,yr,acc,pytdate,voteno,amt,markdel) VALUES ($recno,$yr,$acc,'$date',$vno,$value,$mk);";} $i++;}
      if(strlen($sql)>0){mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 3. (g) Click <a href=\"financialyearchange.php\">HERE</a> to go back."); while(mysqli_next_result($toconn)){}}
    }} mysqli_free_result($rs);
    //STEP 4 - **********************payments
    mysqli_query($fromconn,"SELECT cast(voucherno as int) as vono,acc,pytdate,markdel,tution,boarding,activity,pemolu,ltt,rmi,ewc,cont,eif,caut,insure,medical,hire,rent,sfinco,disporse,propreplace,arrears,vote1,vote2,
    vote3,vote4,vote5,vote6,vote7,vote8,vote9,vote10,vote11,vote12,bursary,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM acc.arch_pytvote WHERE yr=$yr; INSERT IGNORE INTO acc_creditordetpaid(detno,yr,vono,
    acc,amt) SELECT d.detno,d.yr,cast(e.voucherno as integer) as vno,e.accountno,(d.estimatedamt-d.amt) as paid FROM acc.arch_creditorsdet d Inner Join acc.arch_exp e ON (d.cred_no=e.expno and d.yr=e.yr and e.commt=1)
    WHERE (d.estimatedamt-d.amt)>0 order by d.cred_no asc;"); $nrecs=mysqli_num_rows($rs); $reciepts=[]; $i=0;
    if($nrecs>0){
      while($data=mysqli_fetch_assoc($rs)){$sql=''; $vno=$data[0]; $acc=$data[1]; $date=$data[2]; $mk=$data[3]; $i=0; foreach($data as $key=>$value){if($i>3 && $value>0){ $vno=getVoteHead($votes,$key,$acc);
        $sql.="INSERT INTO arch_pytvotes(vono,yr,acc,pytdate,voteno,amt,markdel) VALUES($recno,$yr,$acc,'$date',$vno,$value,$mk);";} $i++;}
        if(strlen($sql)>0){mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 4. (a) Click <a href=\"financialyearchange.php\">HERE</a> to go back."); while(mysqli_next_result($toconn)){}}
      }
    }mysqli_free_result($rs);
    $rs=mysqli_query($fromconn,"SELECT cast(voucherno as int) as vono,if(acc=2,3,4) as ac,pytdate,markdel,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM
    acc.arch_fsepytvote WHERE yr=$yr;"); $nrecs=mysqli_num_rows($rs); $reciepts=[];
    if($nrecs>0){
      while($data=mysqli_fetch_assoc($rs)){$sql=''; $vono=$data[0]; $acc=$data[1]; $date=$data[2]; $mk=$data[3]; $i=0; foreach($data as $key=>$value){if($i>3){$vno=getVoteHead($votes,$key,$acc);
        $sql.="INSERT INTO arch_pytvotes(vono,yr,acc,pytdate,voteno,amt,markdel) VALUES($vono,$yr,$acc,'$date',$vno,$value,$mk);";}$i++;}
        if(strlen($sql)>0){mysqli_multi_query($toconn,$sql) or die(mysqli_error($toconn).". STEP 4. (b) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");while(mysqli_next_result($toconn)){}}
      }
    }mysqli_free_result($rs);
  }
  if($action[0]==0){
    mysqli_multi_query($conn,"INSERT IGNORE INTO ss(sysdate,scnm,scadd,principal,nssfno,nhifno,locked,emppin,minbal,finyr,motto,mission,vision,receipt,noimps,mpr,nssfrate,bursreceipt,scabb,typerecno,bursType,paybillNo,
    paybillac) SELECT sysdate,scnm,scadd,principal,nssfno,nhifno,locked,emppin,minbal,finyr,motto,mission,vision,receipt,noimps,mpr,nssfrate,bursreceipt,scabb,typerecno,burstype,paybillNo,paybillac FROM acc.ss; INSERT
    IGNORE INTO login SELECT * FROM acc.login; INSERT IGNORE INTO gen_priv(uname,studview,studedit,studdel,studadd,aluview,aluedit,aludel,aluadd,stfview,stfedit,stfdel,stfadd,userview,useredit,userdel,useradd,backup,
    confdel,feetrans,recpwd,reqraise,reqfoward,reqedit,reqapp,reqappamt,deptview,deptadd,deptedit,deptdel,sysdata,grpview,grpedit,grpdel,grpadd,archview,privview,privedit,privdel,setupview,setupedit,setupdel,setupadd,
    analysis,leaveoutadd,leaveoutview,leaveoutcancel,pledgeview,pledgeedit,pledgedel,pledgeadd,loanwaive,arr_waive,saladvwaive) SELECT uname,studview,studedit,studdel,studadd,aluview,aluedit,aludel,aluadd,stfview,stfedit
    ,stfdel,stfadd,userview,useredit,userdel,useradd,backup,confdel,feetrans,recpwd,reqraise,reqfoward,reqedit,reqapp,reqappamt,deptview,deptadd,deptedit,deptdel,sysdata,grpview,grpedit,grpdel,grpadd,archview,privview,
    privedit,privdel,0,0,0,0,0,0,0,leaveoutcancel,pledgeview,pledgeedit,pledgedel,pledgeadd,loanwaive,arr_waive,saladvwaive FROM acc.gen_priv; INSERT IGNORE INTO acc_priv(uname,advview,advedit,advdel,advadd,salview,
    saledit,saldel,saladd,feeview,feeedit,feedel,feeadd,gofeeview,gofeeedit,gofeedel,gofeeadd,struview,struedit,strudel,struadd,uniadd,pytview,pytedit,pytdel,pytadd,impview,impedit,impdel,impissue,impclr,bursview,bursedit,
    bursdel,bursadd,budgview,budgedit,budgdel,budgadd,print,rpt,tools,archiveview,withdrawals,advreqapproval,reqapproval,reqview,reqedit,reqadd,reqdel,reqreject,itemview,itemedit,itemdel,itemadd,accview,accedit,accdel,
    accadd,salcheck,salapprove,voteview,voteedit,votedel,voteadd,arrrefedit,borroview,borroedit,borrodel,borroadd,transconf,credview,crededit,creddel,credadd,bankedit,bankdel) SELECT uname,advview,advedit,advdel,advadd,
    salview,saledit,saldel,saladd,feeview,feeedit,feedel,feeadd,gofeeview,gofeeedit,gofeedel,gofeeadd,struview,struedit,strudel,struadd,0,pytview,pytedit,pytdel,pytadd,impview,impedit,impdel,0,impclr,bursview,bursedit,
    bursdel,bursadd,budgview,budgedit,budgdel,budgadd,print,rpt,tools,archiveview,withdrawals,0,0,0,0,0,0,0,0,0,0,0,accview,accedit,accdel,accadd,salcheck,salapprove,0,0,0,0,arrrefedit,borroview,borroedit,borrodel,
    borroadd,transconf,credview,crededit,creddel,credadd,bankedit,bankdel FROM acc.acc_priv;INSERT IGNORE INTO wise SELECT * FROM acc.wise; INSERT IGNORE INTO grps(grp_no,staff,strm,pp,bb,corevalue,categ,stud_grp) SELECT
    grp_no,staff,strm,pp,bb,corevalue,categ,null FROM acc.grps WHERE not isnull(staff) or not isnull(strm) or not isnull(pp) or not isnull(bb) or not isnull(corevalue); INSERT IGNORE INTO classlvl(lvlno,lvlabbr,lvlname,
    clsno) VALUES(1,'SEC','SECONDARY',4);INSERT INTO acc_voteacs(acno,abbr,descr,stud_assoc,sal_assoc,imp_assoc,pyt_assoc,govt_assoc,fee_assoc,wd) VALUES(1,'SCH FUND A/C','SCHOOL FUND AND OTHER MONIES ACCOUNT',1,1,1,1,0,
    1,1),(2,'MISC A/C','MISCELLANEOUS FUND ACCOUNT',1,0,0,1,0,1,1),(3,'OPERATIONS A/C','OPERATIONS ACCOUNT',0,1,1,1,1,1,1),(4,'TUITION A/C','TUITION ACCOUNT',0,1,1,1,1,1,0),(5,'INFRASTRUCTURE','INFRASTRUCTURE ACCOUNT',
    0,0,0,1,1,0,0); INSERT INTO terms(tno,finyr,abbr,descr,starts,ends) VALUES (1,2021,'Term I','Term I 2021','2021-01-01','2021-06-30'),(2,2021,'Term II','Term II 2021','2021-07-01','2021-09-30'),(3,2021,'Term III',
    'Term III 2021','2021-10-01','2021-12-31');") or die(mysqli_error($conn).". 1. Click <a href=\"financialyearchange.php\">HERE</a> to go back."); $i=1;
    do{$comm=''; switch($i){case 1:$comm='System Data';break;case 2:$comm='System User';break;case 3:$comm='General Priviledge';break;case 4:$comm='Accounts Priviledges';break;case 5:$comm='Daily Quotes';break;
      case 6:$comm='Groupings';break;case 8:$comm='Class Level';break;case 9:$comm='Votehead A/Cs';break;case 10:$comm='Terms';break;} echo "STEP 1. $comm ".mysqli_affected_rows($conn)." records uploaded.<br>"; $i++;
    }while(mysqli_next_result($conn)); echo "<hr style=\"border:1px dotted #fff;\">";
    mysqli_multi_query($conn,"INSERT IGNORE INTO classnames(clsno,clsabbr,clsname,lvlno) VALUES (1,'I','ONE',1),(2,'II','TWO',1),(3,'III','THREE',1),(4,'IV','FOUR',1); INSERT IGNORE INTO stud(admno,nemisno,
    surname,onames,address,telno,guardian,relation,admdate,dob,present,photo,addedby,curr_year,markdel,type,regdon,countyno,constituencyno,wardno,location,sublocation,village,illness,alergies,occupation,birthcertno,pwd,
    pwdrmks,cleared) SELECT admno,null,surname,onames,address,telno,guardian,relation,admdate,dob,present,photo,addedby,curr_year,markdel,type,regdon,'001','001','0001',location,sublocation,village,illness,alergies,
    'Self-Employed',birthcertno,0,null,cleared FROM acc.stud; INSERT IGNORE INTO class(admno,curr_year,clsno,stream,lvlno,bbf,miscbf,spemed,unifrm,refunds,alumniarrears,alumniref,markdel) SELECT admno,curr_year,
    if(form like 'one',1,if(form Like 'two',2,if(form like 'Three',3,4))) as clsno,stream,1 as lvlno,bbf,miscbf,SpecialMedical,unifrm,0 as refunds,alumniarrears,alumniref,markdel FROM acc.form; UPDATE stud,ss set
    countyno=ss.county,constituencyno=ss.constituency,wardno=ss.ward; INSERT IGNORE INTO stf(idno,surname,onames,address,telno,employer,designation,gender,staffgrp,dob,pin,photo,addedby,pw,email,regdon,countyno,
    constituencyno,wardno,sublocation,village,pwd,pwdrmks,st_type,illness,alergies,present,markdel) SELECT idno,surname,onames,address,telno,employer,designation,gender,staffgrp,dob,pin,photo,addedby,'0000' as pw,email,
    regdon,'001' as countyno,'001' as constituencyno,'0001' as wardno,'xxxxx' as sublocation,'xxxxx' as village,0,null,st_type,null,null,if(markdel=0,0,1) as present,markdel FROM acc.stf; UPDATE stf,ss set
    countyno=ss.county,constituencyno=ss.constituency,wardno=ss.ward; INSERT IGNORE INTO acc_accounts(sno,accname,acctype,accacc,accno,accdate,bankno,branch,fa,markdel) SELECT sno,accname,acctype,accacc,
    accno,accdate,1,branch,fa,markdel FROM acc.acc_accounts; INSERT IGNORE INTO acc_burs(bursno,sourcename,pytfrm,cheno,pytdate,amt,bankcharge,addedby,addressee,bankno,branch,po,pocode,city,markdel,delreason,status)
    SELECT paymentno,sourcename,paytfrm,chequeno,pytdate,Amount,bankcharge,addedby,addressee,1 as bankno,branch,po,pocode,city,markdel,delreason,status FROM acc.acc_burs;") or die(mysqli_error($conn).". 1. Click <a
    href=\"financialyearchange.php\">HERE</a> to go back."); $i=9;
    do{$comm=''; switch($i){case 9:$comm='Classes';break;case 10:$comm='Student';break;case 11:$comm='Student forms';break;case 12:$comm='Student Home';break; case 13:$comm='Staff';break;case 14:$comm='Staff Home';break;
      case 15:$comm='Bank A/C';break;case 16:$comm='Bursaries';break;} echo "STEP 1 (a). $comm ".mysqli_affected_rows($conn)." records uploaded.<br>"; $i++;
    }while(mysqli_next_result($conn));
    mysqli_multi_query($conn,"INSERT IGNORE INTO acc_votebalbf SELECT if(a.accacc=2,3,if(a.accacc=3,4,if(a.accacc=4,2,1))) as ac,ss.finyr,a.cashbalbf FROM acc.acc_accounts a,ss WHERE a.markdel=0;INSERT IGNORE INTO
    acc_votebalbf SELECT a.acno,ss.finyr,0 as bal FROM acc_voteacs a,ss; INSERT IGNORE INTO acc_acbalbf SELECT a.sno,ss.finyr,a.bankbalbf FROM acc.acc_accounts a,ss WHERE a.markdel=0; INSERT IGNORE INTO acc_acbalbf
    SELECT a.sno,ss.finyr,0 as bal FROM acc_accounts a, ss;INSERT IGNORE INTO acc_saldef(payrollno,idno,acc,bankname,accountno,bsal,nssffee,nssfvol,nhiffee,saccofee,welfare,otherlevies,houseallow,medicalallow,travellallow,
    responsallow,empnssf,paye,mpr,unionfee,helb,bankbranch,addedby,markdel,nssfno,nhifno,unionno,saccono,welfareno) SELECT payrollno,idno,if(salsource LIKE 'main account',1,if(salsource like 'operations account',4,null))
    as acc,bankname,accountno,bsal,nssffee,nssfvol,nhiffee,saccofee,welfare,otherlevies,houseallow,medicalallow,travellallow,responsallow,empnssf,paye,mpr,unionfee,helb,bankbranch,addedby,markdel,nssfno,nhifno,unionno,
    saccono,welfareno FROM acc.acc_saldef; INSERT IGNORE INTO acc_adv(advno,payrollno,adv_date,amt,authorisedby,rmks,duration,amtperduration,pytfrm,cheno,acsno,acc,vono,advreqno,addedby,markdel,issued) SELECT a.advno,
    d.payrollno,a.adv_date,a.amt,a.authorisedby,e.rmks,a.duration,a.amtperduration,e.payform,e.chequeno,e.acsno,a.acc,e.cbvno,null as advreqno,a.addedby,a.markdel,1 as issued FROM acc.acc_adv a Inner Join acc.acc_saldef d
    USING (idno) Inner join acc.acc_exppayee p USING (idno) Inner JOin acc.acc_exp e ON (p.payno=e.expno and e.commt=0); INSERT IGNORE INTO acc_payecalc SELECT * FROM acc.acc_payecalc; INSERT IGNORE INTO acc_nhifcalc
    SELECT * FROM acc.acc_nhifcalc; INSERT IGNORE INTO acc_advclr(clrno,advano,clr_date,amt_clr,rmks,salno,markdel) SELECT clrno,advano,clr_date,amt_clr,rmks,null as salno,markdel FROM acc.acc_advclr; INSERT IGNORE INTO
    acc_votes(sno,lfn,abbr,descr,expabbr,expdescr,acc,fs_defined,pyt_defined,protected,orderno,stud_fee,other_inco,markdel) VALUES(1,null,'ARREARS','ARREARS B/F','SUNDRY','SUNDRY CREDITORS',1,0,0,1,1,1,0,0),(2,NULL,
    'REFUNDS','REFUNDS','REFUNDS','REFUNDS',1,0,0,1,2,1,0,0),(3,NULL,'SPEMED','SURCHARGED MEDICAL','SPEMED','SURCHARGED MEDICAL',1,0,0,1,3,1,0,0),(4,NULL,'PREPAID','PREPAYMENTS','PREPAID','PREPAYMENTS',1,0,0,1,4,1,0,0),
    (5,NULL,'BURSARY','BURSARY','BURSARY','BURSARY',1,0,0,1,5,1,0,0);INSERT IGNORE INTO acc_votes(sno,lfn,abbr,descr,expabbr,expdescr,acc,fs_defined,pyt_defined,protected,orderno,stud_fee,other_inco,markdel) SELECT
    @sn:=@sn+1 as sno,null as lfn,fieldname,descr,abbr as expabbr,descr as expdescr,if(acc=1,1,if(acc=4,2,if(acc=2,3,4))) as ac,if((sno<12 || (sno>16 && sno<55)),1,0) as fs_defined,if(sno<55,1,0) as pyt_defined,if(sno>55,
    1,0) as protected,(@sn+5) as orderno,if((sno<12 || (sno>16 && sno<29) || (sno>47 && sno<55)),1,0) as stud_fee,if(sno<55,1,0) as other_inco, 0 as markdel FROM acc.acc_votes,(SELECT @sn:=5)x WHERE not isnull(abbr);
    INSERT IGNORE INTO acc_votesassigned(sno,name,acc,voteno,hvoteno,protected,markdel) VALUES(1,'BBF',1,1,null,1,0),(2,'SPEMED',1,3,null,1,0),(3,'MISCBF',2,34,null,1,0),(4,'UNIFRM',2,35,null,1,0);INSERT IGNORE INTO
    acc_salaries(salno,sal_month,sal_year,acc,acsno,voteno,processedon,addedby,markdel,batchno,checkstatus,approvestatus) SELECT s.salno,s.sal_month,s.sal_year,s.acc,s.acsno,v.sno as voteno,s.processedon,s.addedby,
    s.markdel,s.batchno,s.checkstatus,s.approvestatus FROM acc.acc_salaries s Inner Join acc.acc_votes v ON (s.acc=v.acc and v.abbr='p/emol'); INSERT IGNORE INTO acc_salpyt(payrollno,salno,bsalary,housingallow1,
    medicalallow1,travelallow1,responsallow1,nssffee1,nssfvol1,nhiffee1,welfare1,sacco1,otherlevies1,advance,empnssf,paye1,mpr1,union1,helb1,paypoint,markdel) SELECT d.payrollno,s.salno,s.bsalary,
    s.housingallow1,s.medicalallow1,s.travelallow1,s.responsallow1,s.nssffee1,s.nssfvol1,s.nhiffee1,s.welfare1,s.sacco1,s.otherlevies1,s.advance,s.empnssf,s.paye1,s.mpr1,s.union1,s.helb1,s.paypoint,s.markdel FROM
    acc.acc_salpyt s Inner Join acc.acc_saldef d USING (idno); INSERT IGNORE INTO acc_alterincome(code,alt_names,telno,idno,paddress,acc,product,voteno,rmks,hiredate,addedby,markdel) SELECT code,alt_names,telno,idno,
    paddress,ac,product,voteno,rmks,serv_date,addedby,markdel FROM  acc.acc_alterincome;") or die(mysqli_error($conn).". STEP 2. (a) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");  $i=0;
    do{
      $comm=''; switch ($i){case 0:$comm='Cash at Hand';break; case 1:$comm='Cash at Hand Nill';break; case 2:$comm='Cash at Bank';break; case 3:$comm='Cash at Bank Nil';break; case 4:$comm='Salary Definition';
      break;case 5:$comm='Salary Advance';break;case 6:$comm='PAYE rates';break;case 7:$comm='NHIF Rates';break;case 8:$comm='Advance Clearance';break;case 9:$comm='Mandatory Votes';break;case 10:$comm='General Votes';
      break;case 11:$comm='Special Votes';break; case 12:$comm='Payrolls';break; case 13:$comm='Salaries';break; case 14:$comm='Other Incomes';break;}
      echo "STEP 1 (b). $comm ".mysqli_affected_rows($conn)." records uploaded.<br>";
      $i++;
    }while(mysqli_next_result($conn));
  }elseif($action[0]==1){echo "<hr style=\"border:1px dotted #fff;\">";//STEP Two
    mysqli_multi_query($conn,"SELECT sno,lower(abbr) as ab,acc FROM acc_votes WHERE markdel=0; SELECT c.admno,c.curr_year,f.t1tui,f.t2tui,f.tuition as tution,f.t1board,f.t2board,f.boardingn as boarding,f.t1pemol,
    f.t2pemol,f.pemolum as pemolu,f.t1act,f.t2act,f.activity,f.t1ltt,f.t2ltt,f.ltt,f.t1rmi,f.t2rmi,f.rmi,f.t1ewc,f.t2ewc,f.ewc,f.t1cont,f.t2cont,f.contig as cont,f.t1eif,f.t2eif,f.eif,f.t1med,f.t2med,f.medical as med,
    f.t1caut,f.t2caut,f.caution as caut,f.t1insure,f.t2insure,f.insure,f.t1vote1,f.t2vote1,f.vote1,f.t1vote2,f.t2vote2,f.vote2,f.t1vote3,f.t2vote3,f.vote3,f.t1vote4,f.t2vote4,f.vote4,f.t1vote5,f.t2vote5,f.vote5,
    f.t1vote6,f.t2vote6,f.vote6,f.t1vote7,f.t2vote7,f.vote7,f.t1vote8,f.t2vote8,f.vote8,f.t1vote9,f.t2vote9,f.vote9,f.t1vote10,f.t2vote10,f.vote10,f.t1vote11,f.t2vote11,f.vote11,f.t1vote12,f.t2vote12,f.vote12 FROM
    acc.form c Inner Join acc.acc_feeoutline f USING (form,fee_group) Inner Join acc.ss s On (s.finyr=c.curr_year) WHERE c.markdel=0; SELECT c.admno,c.curr_year,f.t1mvote1,f.t2mvote2,f.mvote1 as vote1,f.t1mvote2,
    f.t2mvote2,f.mvote2 as vote2,f.t1mvote3,f.t2mvote3,f.mvote3 as vote3,f.t1mvote5,f.t2mvote5,f.mvote5 as vote5,f.t1mvote6,f.t2mvote6,f.mvote6 as vote6,f.t1mvote7,f.t2mvote7,f.mvote7 as vote7,f.t1mvote8,f.t2mvote8,
    f.mvote8 as vote8,f.t1mvote9,f.t2mvote9,f.mvote9 as vote9 FROM acc.form c Inner Join acc.acc_feeoutline f USING (form,fee_group) Inner Join acc.ss s On (s.finyr=c.curr_year) WHERE c.markdel=0; ") or
    die(mysqli_error($conn).". STEP 2. (a) Click <a href=\"financialyearchange.php\">HERE</a> to go back."); $exsql=[]; $i=$nv=0; $sql="INSERT IGNORE INTO clsfee(admno,curr_year,voteno,t1,t2,t3) VALUES"; $comm=0;
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){$votes=[]; while($d=mysqli_fetch_row($rs)) $votes[]=new VoteHeads($d[0],$d[1],$d[2]); echo "STEP 2. (a) ".mysqli_num_rows($rs)." Voteheads loaded.<br>";
        }else{$nv=0;
          while($d=mysqli_fetch_assoc($rs)){$c=$count=0; $admno=$d['admno']; $acc=($i==1?1:2); $cyr=$d['curr_year'];
            foreach($d as $key=>$value){if($c>1){if($count==0){$t1=$value;$count++;}elseif($count==1){$t2=$value; $count++;}elseif($count==2){$vno=getVoteHead($votes,$key,$acc);
              $sql.=($comm==0?"":",")."($admno,$cyr,$vno,$t1,$t2,$value)";  $count=0; $comm++; $nv++;
              if($nv%300==0){$exsql[]=$sql; $sql="INSERT IGNORE INTO clsfee(admno,curr_year,voteno,t1,t2,t3) VALUES"; $comm=0;}}} $c++;
            }
          }
        }mysqli_free_result($rs);
      } $i++;
    }while(mysqli_next_result($conn)); if($nv%300!=0) $exsql[]=$sql;
    if($nv>0){foreach($exsql as $sql){mysqli_query($conn,$sql) or die(mysqli_error($conn).". Error in updating fee structures."); echo mysqli_affected_rows($conn)." Fee structures updated.<br>";}}
  }elseif($action[0]==2){echo "<hr style=\"border:1px dotted #fff;\">";//STEP Three
    mysqli_multi_query($conn,"SELECT sno,lower(abbr) as ab,acc FROM acc_votes; SELECT if(acc=1,concat('f.',abbr),0) as main,if(acc=2,concat('m.',abbr),0) as misc FROM `acc_votes` WHERE expabbr LIKE '%unif%'; SELECT
    count(recieptno) FROM acc.acc_feerec GROUP BY markdel HAVING markdel=0; SELECT count(recieptno) FROM acc.acc_prep GROUP BY markdel HAVING markdel=0; SELECT count(recipetno) FROM acc.acc_miscfeepyts GROUP BY markdel
    HAVING markdel=0;") or die(mysqli_error($conn).". Error in data retrieval"); $mainuni=$miscuni=$nummain=$nummisc=$numprep=$i=0;
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){$votes=[]; while($d=mysqli_fetch_row($rs)) $votes[]=new VoteHeads($d[0],$d[1],$d[2]); echo "STEP 3. (a) ".mysqli_affected_rows($conn)." Voteheads loaded.<br>";
        }elseif($i==1){if(mysqli_num_rows($rs)>0)list($mainuni, $miscuni)=mysqli_fetch_row($rs);}elseif($i==2){if(mysqli_num_rows($rs)>0)list($nummain)=mysqli_fetch_row($rs);
        }elseif($i==3){if(mysqli_num_rows($rs)>0)list($numprep)=mysqli_fetch_row($rs);}else{if(mysqli_num_rows($rs)>0)list($nummisc)=mysqli_fetch_row($rs);}  mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));
    $rs=mysqli_query($conn,"SELECT 0 as opt,f.recieptno,f.admno,f.pytdate,f.paidby,f.paytform,f.cmono,f.pytno,if(isnull(f.bank),null,1) as bn,f.addedby,f.kinddescr,f.delreason,f.commt,0 as interb_no,f.verno,f.verdate,
    f.verstate,f.verbanked,f.bankcharges,f.amt,f.arrears,f.spemed,f.refunds,if(isnull(p.amt),0,p.amt) as prep,$mainuni as unifrm,f.transfer,f.markdel,if(isnull(m.recipetno),0,m.recipetno) as mrec,
    if(isnull(m.bankcharges),0,m.bankcharges) as mbc,if(isnull(m.amt),0,m.amt) as mamt,if(isnull(m.arrears),0,m.arrears) as marrears,0 as mspemed,if(isnull($miscuni),0,$miscuni) as munifrm,0 as transfer,
    if(isnull(m.markdel),0,m.markdel) as mmarkdel FROM acc.acc_feerec f Left Join acc.acc_prep p USING (recieptno) Left Join acc.acc_miscfeepyts m USING (recieptno) UNION SELECT 1 as opt,recipetno as recieptno,
    payeesno as admno,pytdate,'Parent' as paidby,pytfrm as paytform,cheno as cmono,bursaryno as pytno,if(isnull(bank),null,1) as bn,addedby,kinddescr,delreason,commt,0 as interb_no,verno,verdate,verstate,verbanked,0 as
    bankcharges,0 as amt,0 as arrears,0 as spemed,0 as refunds,0 as prep,0 as unifrm,0 as transfer,0 as markdel,recipetno as mrec,bankcharges as mbc,amt as mamt,arrears as marrears,0 as mspemed,$miscuni as munifrm,0 as
    transfer,markdel as mmarkdel FROM acc.acc_miscfeepyts m WHERE isnull(recieptno);");
    $sql="INSERT IGNORE INTO acc_incorecno0(recno,recon,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm,transfer,markdel) VALUES ";  $count=$count1=0; $sqlinco=$sqlinco1=[];
    $sql1="INSERT IGNORE INTO acc_incorecno1(recno,recon,sno,acc,bc,amt,arrears,spemed,unifrm,transfer,markdel) VALUES ";
    while($data=mysqli_fetch_row($rs)){
      if(mysqli_query($insert,"INSERT IGNORE INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,addedby,kinddescr,delreason,commt,inter_no,verno,verdate,verstate,verbanked,markdel) VALUES(0,'$data[2]',
      '$data[3]','$data[4]','$data[5]',".var_export($data[6],true).",".var_export($data[7],true).",".var_export($data[8],true).",'$data[9]',".var_export($data[10],true).",".var_export($data[11],true).",'$data[12]',".
      var_export($data[13],true).",".var_export($data[14],true).",".var_export($data[15],true).",".var_export($data[16],true).",".var_export($data[17],true).",$data[26])")  or die(mysqli_error($insert).
      ". STEP 3 (a) Click <a href=\"transit.php\">HERE</a> to go back.")){$sno=mysqli_insert_id($insert);
        if($data[0]==0){$sql.=($count==0?"":",")."($data[1],'$data[3]',$sno,1,$data[18],$data[19],$data[20],$data[21],$data[22],$data[23],$data[24],$data[25],$data[26])"; $count++;
          if($data[27]>0){$sql1.=($count1==0?"":",")."($data[27],'$data[3]',$sno,2,$data[28],$data[29],$data[30],$data[31],$data[32],$data[33],$data[34])"; $count1++;
            if($count1%200==0){$sqlinco1[]=$sql1; $sql1="INSERT IGNORE INTO acc_incorecno1(recno,recon,sno,acc,bc,amt,arrears,spemed,unifrm,transfer,markdel) VALUES "; $count1=0;}
          }if($count%200==0){$sqlinco[]=$sql; $sql="INSERT IGNORE INTO acc_incorecno0(recno,recon,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm,transfer,markdel) VALUES "; $count=0;}
        }else{$sql1.=($count1==0?"":",")."($data[27],'$data[3]',$sno,2,$data[28],$data[29],$data[30],$data[31],$data[32],$data[33],$data[34])"; $count1++;
          if($count1%200==0){$sqlinco1[]=$sql1; $sql1="INSERT IGNORE INTO acc_incorecno1(recno,recon,sno,acc,bc,amt,arrears,spemed,unifrm,transfer,markdel) VALUES "; $count1=0;}
        }
      }
    } if($count>0) $sqlinco[]=$sql; if($count1>0) $sqlinco1[]=$sql1;
    foreach($sqlinco as $sql){
      mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 3.(b) Click <a href=\"transit.php\">HERE</a> to go back."); echo mysqli_affected_rows($insert)." School fund Fees Records inserted<br>";
    }foreach($sqlinco1 as $sql){
      mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 3.(c) Click <a href=\"transit.php\">HERE</a> to go back."); echo mysqli_affected_rows($insert)." Misc Fund Fees Records inserted<br>";
    }$nloops=($nummain==0?0:($nummain<=200?1:ceil($nummain%200))); $upper=200; $lower=0;
    for($i=0;$i<$nloops;$i++){
      $rs=mysqli_query($conn,"SELECT recieptno,pytdate,markdel,tution,boarding,activity,pemolu,ltt,rmi,ewc,cont,eif,caut,insure,medical,hire,(rent+rentfurn+rentwater+rentelect) as rent,sfinco,disporse,propreplace,
      spemed,arrears,refunds,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,vote10,vote11,vote12,bursary,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM acc.acc_feerec WHERE markdel=0 ORDER BY
      recieptno ASC limit $lower,$upper;"); $nrecs=mysqli_num_rows($rs); $sql="INSERT IGNORE INTO acc_incovotes(recno,acc,pytdate,voteno,amt,markdel) VALUES "; $count=0;
      while($data=mysqli_fetch_assoc($rs)){$recno=$data['recieptno']; $date=$data['pytdate']; $mk=$data['markdel']; $index=0;
        foreach($data as $key=>$value){if($index>2 && $value>0){$vno=getVoteHead($votes,$key,1); $sql.=($count==0?"":",")."($recno,1,'$date',$vno,$value,$mk)"; $count++;} $index++;}
      }mysqli_free_result($rs);
      if($count>0) mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 3. (c) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");
      echo "Transerferred Batch No. ".($i+1)." of $nrecs  School fund fees records.$nloops<br>"; $lower=$upper; $upper+=200;
    }//Prepayments
    $nloops=($numprep==0?0:($numprep<=200?1:ceil($numprep%200))); $upper=200; $lower=0;
    for($i=0;$i<$nloops;$i++){
      $rs=mysqli_query($conn,"SELECT recieptno,markdel,tution,boarding,activity,pemolu,ltt,rmi,ewc,cont,eif,insure,medical,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,vote10,vote11,vote12 FROM acc.acc_prep
      WHERE markdel=0 ORDER BY recieptno ASC limit $lower,$upper;"); $count=0;  $nrecs=mysqli_num_rows($rs); $sql="INSERT IGNORE INTO acc_incoprep(recno,acc,voteno,amt,markdel) VALUES ";
      while($data=mysqli_fetch_assoc($rs)){$recno=$data['recieptno']; $mk=$data['markdel']; $index=0;
        foreach($data as $key=>$value){if($index>1 && $value>0){$vno=getVoteHead($votes,$key,1); $sql.=($count==0?"":",")."($recno,1,$vno,$value,$mk)"; $count++;} $index++;}
      }mysqli_free_result($rs);
      if($count>0) mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 3. (d) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");
      echo "Transerferred Batch No. ".($i+1)." of $nrecs School fund Prepayment records.$nloops<br>"; $lower=$upper; $upper+=200;
    } //Misc Fund Fees
    $nloops=($nummisc==0?0:($nummisc<=100?1:ceil($nummisc%100))); $upper=200; $lower=0;
    for($i=0;$i<$nloops;$i++){
      $rs=mysqli_query($conn,"SELECT recipetno,pytdate,markdel,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9 FROM acc.acc_miscfeepyts WHERE markdel=0 ORDER BY recipetno ASC limit $lower,$upper;"); $count=0;
      $nrecs=mysqli_num_rows($rs); $sql="INSERT IGNORE INTO acc_incovotes(recno,acc,pytdate,voteno,amt,markdel) VALUES ";
      while($data=mysqli_fetch_assoc($rs)){$recno=$data['recipetno']; $date=$data['pytdate']; $mk=$data['markdel']; $index=0;
        foreach($data as $key=>$value){if($index>2 && $value>0){$vno=getVoteHead($votes,$key,2); $sql.=($count==0?"":",")."($recno,1,'$date',$vno,$value,$mk)"; $count++;} $index++;}
      }mysqli_free_result($rs);
      if($count>0) mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 3. (e) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");
      echo "Transerferred Batch No. ".($i+1)." of $nrecs Misc A/C fees records.$nloops<br>";
    } //FSE Fees
  }elseif($action[0]==3){echo "<hr style=\"border:1px dotted #fff;\">";
    $rs=mysqli_query($conn,"SELECT sno,lower(abbr) as ab,acc FROM acc_votes WHERE markdel=0; "); $votes=[]; while($d=mysqli_fetch_row($rs)){$votes[]=new VoteHeads($d[0],$d[1],$d[2]);} mysqli_free_result($rs);
    mysqli_multi_query($conn,"SELECT finyr FROM ss;SELECT tvote1 as vote1,tvote2 as vote2,tvote3 as vote3,tvote4 as vote4,tvote5 as vote5,tvote6 as vote6,tvote7 as vote7,tvote8 as vote8,tvote9 as vote9 FROM
    acc.acc_oafeestruct f Inner Join ss s on (f.curr_year=s.finyr);SELECT ovote1 as vote1,ovote2 as vote2,ovote3 as vote3,ovote4as vote4,ovote5 as vote5,ovote6 as vote6,ovote7 as vote7,ovote8 as vote8,ovote9 as vote9
    FROM acc.acc_oafeestruct f Inner Join ss s on (f.curr_year=s.finyr);SELECT tuition as tution,t1tui,t2tui,boardingn as boarding,t1board,t2board,pemolum as pemolu,t1pemol,t2pemol,activity,t1act,t2act,ltt,t1ltt,t2ltt,
    rmi,t1rmi,t2rmi,ewc,t1ewc,t2ewc,contig as cont,t1cont,t2cont,eif,t1eif,t2eif,medical as med,t1med,t2med,caution as caut,t1caut,t2caut,insure,t1insure,t2insure,vote1,t1vote1,t2vote1,vote2,t1vote2,t2vote2,vote3,t1vote3,
    t2vote3,vote4,t1vote4,t2vote4,vote5,t1vote5,t2vote5,vote6,t1vote6,t2vote6,vote7,t1vote7,t2vote7,vote8,t1vote8,t2vote8,vote9,t1vote9,t2vote9,vote10,t1vote10,t2vote10,vote11,t1vote11,t2vote11,vote12,t1vote12,t2vote12
    FROM acc.acc_feeoutline WHERE form LIKE 'two' and fee_group LIKE 'General'; SELECT mvote1 as vote1,t1mvote1,t2mvote1,mvote2 as vote2,t1mvote2,t2mvote2,mvote3 as vote3,t1mvote3,t2mvote3,mvote5 as vote5,t1mvote5,
    t2mvote5,mvote6 as vote6,t1mvote6,t2mvote6,mvote7 as vote7,t1mvote7,t2mvote7,mvote8 as vote8,t1mvote8,t2mvote8,mvote9 as vote9,t1mvote9,t2mvote9 FROM acc.acc_feeoutline WHERE form LIKE 'two' and fee_group LIKE
    'General'; INSERT IGNORE INTO acc_fseincome(recno,noofstud,recon,batchno,acc,acsno,amt,arrears,commt,interb_no,mode,modeno,rmks,bankno,delreason,verno,verdate,verstate,verbanked,addedby,markdel) SELECT recieptno,
    noofstud,dateofpayt,batchno,if(ac='2',3,4) as acc,acsno,ttlamt,0 as arrears,commt,inter_no,mode,modeno,rmks,1 as bankno,delreason,verno,verdate,verstate,verbanked,addedby,markdel FROM acc.acc_oacrec;");
    $sql="INSERT IGNORE INTO acc_feestruct(yr,lvlno,voteno,t1,t2,t3) VALUES"; $count=$i=0; $finyr=date('Y');
    do{
     if($i<5){
        if($rs=mysqli_store_result($conn)){
          if($i==0){if(mysqli_num_rows($rs)>0)list($finyr)=mysqli_fetch_row($rs);
          }elseif($i==1){while($d=mysqli_fetch_assoc($rs)){foreach($d as $key=>$value){if($value>0){$vno=getVoteHead($votes,$key,3); $sql.=($count==0?"":",")."($finyr,1,$vno,$value,$value,$value)"; $count++;}}}
          }elseif($i==2){while($d=mysqli_fetch_assoc($rs)){foreach($d as $key=>$value){if($value>0){$vno=getVoteHead($votes,$key,4); $sql.=($count==0?"":",")."($finyr,1,$vno,$value,$value,$value)"; $count++;}}}
          }else{$acc=($i==3?1:2); while($d=mysqli_fetch_assoc($rs)){$c=$vno=$t3=$t2=$t1=0; foreach($d as $key=>$value){if($c===0){if($value>0){$t3=$value; $vno=getVoteHead($votes,$key,$acc);} $c++;}
            elseif($c==1){$t1=$value; $c++;}elseif($c==2){$t2=$value; $c=0; if($t3>0){$sql.=($count==0?"":",")."($finyr,1,$vno,$t1,$t2,$t3)"; $count++;}}}}
        }
      }else{echo "<br>".mysqli_affected_rows($conn)." FSE Records transferred.";} mysqli_free_result($rs);} $i++;
    }while(mysqli_next_result($conn));
    if($count>0){mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 3.(f) Click <a href=\"transit.php\">HERE</a> to go back."); echo mysqli_affected_rows($insert)." fee structures.<br>";}
    //FSE acc voteheads
    $rs=mysqli_query($conn,"SELECT recno,if(ac=2,3,4) as acc,receivedon,markdel,arrears,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM acc.acc_fsevote");
    $count=0; $sql="INSERT IGNORE INTO acc_fsevotes(recno,acc,pytdate,voteno,amt,markdel) VALUES ";
    while($data=mysqli_fetch_assoc($rs)){ $recno=$data['recno']; $acc=$data['acc']; $date=$data['receivedon']; $mk=$data['markdel']; $i=0;
      foreach($data as $key=>$value){if($i>2 && $value>0){$vno=getVoteHead($votes,$key,$acc); $sql.=($count==0?"":",")." ($recno,$acc,'$date',$vno,$value,$mk)"; $count++;} $i++;}
    }mysqli_free_result($rs); if($count>0){mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 3. (g) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");
    echo mysqli_affected_rows($insert)." FSE Fee Receipts transferred.<br>";}
  }elseif($action[0]==4){
    //STEP 4 - **********************payments
    mysqli_multi_query($insert,"SELECT sno,lower(abbr) as ab,acc FROM acc_votes WHERE markdel=0 and acc in (1,3,4); INSERT IGNORE INTO acc_exppayee(payno,regdate,payee,idno,address,telno,email,addedby,markdel)
    SELECT payno,regdate,payee,idno,address,telno,null as email,addedby,markdel FROM acc.acc_exppayee; INSERT IGNORE INTO acc_exp(vono,acsno,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,commt,addedby,markdel,recsno,
    salno,delreason,recno) SELECT cast(voucherno as int) as vono,acsno,pytdate,accountno,payform,chequeno,caamt,chamt,rmks,expno,commt,addedby,markdel,recieptno,salno,delreason,verno FROM acc.acc_exp;INSERT IGNORE INTO
    acc_creditors(cred_no,supid,yr,idno,name,telno,paddress,email,regdate,addedby,markdel,delreason,categ) SELECT cred_no,supid,yr,idno,name,telno,paddress,null as email,regdate,addedby,markdel,delreason,0 as cated FROM
    acc.acc_creditors; INSERT IGNORE INTO acc_creditorsdet(detno,cred_no,inv_no,inv_date,lpono,acc,yr,voteno,amt,estimatedamt,rmks,delreason,admno,addedby,markdel) SELECT detno,cred_no,'0001' as inv_no,regdate as
    inv_date,lpono,acno as acc,yr,voteno,amt,estimatedamt,rmks,delreason,null as admno,addedby,markdel FROM acc.acc_creditorsdet;INSERT IGNORE INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,markdel,
    delreason,addedby) SELECT cfno,ac,cftype,cfdate,rmks,amt,transtype,transno,markdel,delreason,addedby FROM acc.acc_cashflow;INSERT IGNORE INTO acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno
    ,markdel,addedby) SELECT transano,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,markdel,addedby FROM acc.acc_banking;INSERT IGNORE INTO acc_fyestimates SELECT * FROM acc.acc_fyestimates; INSERT IGNORE INTO
    acc_fseben SELECT * FROM acc.acc_govtfundben;INSERT IGNORE INTO acc_arrrefchanges(sno,admno,arr_yr,doneon,prevamt,newamt,ac,type,rmks,addedby) SELECT sno,admno,arr_yr,doneon,if(oldarr>0,oldarr,oldref) as prevamt,
    newarr,ac,type,rmks,addedby FROM acc.acc_arrrefchanges;INSERT IGNORE INTO acc_arrrefclr(clrno,recno,arr_year,ac,clron,admno,amt,transtype,markdel,changermks) SELECT clrno,recieptno,arr_year,ac,clron,admno,amt,
    transtype,markdel,changermks FROM acc.acc_arrrefclr;INSERT IGNORE INTO acc_creditordetpaid(detno,vono,acc,amt) SELECT d.detno,cast(e.voucherno as integer) as vno,e.accountno,(d.estimatedamt-d.amt) as paid FROM
    acc.acc_creditorsdet d Inner Join acc.acc_exp e ON (d.cred_no=e.expno and e.commt=1) WHERE (d.estimatedamt-d.amt)>0 order by  d.cred_no asc;"); $i=0;
    do{
      if($i==0 && $rs=mysqli_store_result($insert)){$votes=[]; while($d=mysqli_fetch_row($rs)) $votes[]=new VoteHeads($d[0],$d[1],$d[2]); mysqli_free_result($rs);
      }else{$comm=''; switch ($i){case 1:$comm="Payee";break;case 2:$comm="Payments";break;case 3:$comm="Creditors";break;case 4:$comm="Commitments";break;case 5:$comm="Cash at Hand";break;
        case 6:$comm="Cash at Bank";break; case 7:$comm="FY Estimates";break; case 8:$comm="FSE Beneficiary";break;case 9:$comm="Arrears Changes";break;case 10:$comm="Arrears Recovery";break;
        case 11:$comm="Commitment Payments";break;} echo "STEP 4. ".mysqli_affected_rows($insert)." $comm records uploaded.<br>";
      } $i++;
    }while(mysqli_next_result($insert));
    $rs=mysqli_query($conn,"SELECT cast(voucherno as int) as vono,acc,pytdate,markdel,tution,boarding,activity,pemolu,ltt,rmi,ewc,cont,eif,caut,insure,medical,hire,rent,sfinco,disporse,propreplace,arrears,vote1,vote2,
    vote3,vote4,vote5,vote6,vote7,vote8,vote9,vote10,vote11,vote12,bursary,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM acc.acc_pytvote;");
    $count=0; $sql="INSERT IGNORE INTO acc_pytvotes(vono,acc,pytdate,voteno,amt,markdel) VALUES ";
    while($data=mysqli_fetch_assoc($rs)){ $vno=$data['vono']; $acc=$data['acc']; $date=$data['pytdate']; $mk=$data['markdel']; $i=0;
      foreach($data as $key=>$value){if($i>3 && $value>0){ $vno=getVoteHead($votes,$key,$acc); $sql.=($count==0?"":",")."($vno,$acc,'$date',$vno,$value,$mk)"; $count++;}$i++;}
    }mysqli_free_result($rs);
    if($count>0){mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 4. (a) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");echo mysqli_affected_rows($insert)." Payments transferred.<br>";}
    $rs=mysqli_query($conn,"SELECT cast(voucherno as int) as vono,acc,pytdate,markdel,vote1,vote2,vote3,vote4,vote5,vote6,vote7,vote8,vote9,nssf,unions,nhif,sacco,welfare,odedn,paye,saladv,helb FROM
    acc.acc_fsepytvote;"); $count=0; $sql="INSERT IGNORE INTO acc_pytvotes(vono,acc,pytdate,voteno,amt,markdel) VALUES ";
    while($data=mysqli_fetch_assoc($rs)){$vono=$data['vono']; $acc=$data['acc']; $date=$data['pytdate']; $mk=$data['markdel']; $i=0;
      foreach($data as $key=>$value){if($i>3){$vno=getVoteHead($votes,$key,$acc); $sql.=($count==0?"":",")."($vono,$acc,'$date',$vno,$value,$mk)"; $count++;}$i++;}
    }mysqli_free_result($rs);
    if($count>0){mysqli_query($insert,$sql) or die(mysqli_error($insert).". STEP 4. (b) Click <a href=\"financialyearchange.php\">HERE</a> to go back.");echo mysqli_affected_rows($insert)." Votehead transferred.<br>";}
    //Budgeting & Other assorted
    mysqli_multi_query($insert,"INSERT IGNORE INTO depts(deptno,deptname,abbr,hodno,deptcat,markdel) SELECT deptno,deptname,abbr,hodno,deptcat,markdel FROM acc.depts; INSERT IGNORE INTO items(itmcode,itemname,categ,deptno,
    units,maxstock,minstock,currstock,unitprice,addedby,addedon,markdel) SELECT itmcode,itemname,categ,deptno,units,maxstock,minstock,currstock,unitprice,addedby,addedon,markdel FROM acc.items; INSERT IGNORE INTO itemvote(
    itmcode,ac,voteno) SELECT itmcode,ac,voteno FROM acc.itemvote; INSERT IGNORE INTO acc_budget(budgno,voteno,ac,budg_date,markdel,addedby) SELECT budgno,voteno,ac,budg_date,markdel,addedby FROM acc.acc_budget; INSERT
    IGNORE INTO acc_budgetdraft(budgno,voteno,ac,budg_date,markdel,addedby) SELECT budgno,voteno,ac,budg_date,markdel,addedby FROM acc.acc_budgetdraft; INSERT IGNORE INTO acc_budgitems(sno,budgno,itmcode,prevqty,prevup,
    qty,up,markdel) SELECT sno,budgno,itmcode,prevqty,prevup,qty,up,0 as markdel FROM acc.acc_budgitems; INSERT IGNORE INTO acc_budgitemsdraft(sno,budgno,itmcode,prevqty,prevup,qty,up,markdel) SELECT sno,budgno,itmcode,
    prevqty,prevup,qty,up,0 as markdel FROM acc.acc_budgitemsdraft; INSERT IGNORE INTO acc_feetransfer(transno,transdate,recieptno,fromadmno,receiveradmno,amt,rmks,ac,transtype,markdel) SELECT transno,transdate,recieptno,
    fromadmno,receiveradmno,amt,rmks,ac,transtype,markdel FROM acc.acc_feetransfer; INSERT IGNORE INTO acc_imp(impno,acc,cudate,idno,amt,rmks,approvedby,status,vno,reqno,delreason,markdel,addedby) SELECT impno,acc,cudate,
    idno,amt,rmks,approvedby,state,vno,reqno,delreason,markdel,addedby FROM acc.acc_imp; INSERT IGNORE INTO acc_leaveout(sno,preparedon,leavedate,returndate,lvlno,clsno,minbal,addedby,markdel,delreason) SELECT sno,
    preparedon,leavedate,returndate,1 as lvlno,if(form LIKE 'one',1,if(form LIKE 'two',2,if(form LIKE 'three',3,4))) as clsno,minbal,addedby,markdel,delreason FROM acc.acc_leaveout;INSERT IGNORE INTO acc_leaveoutstud(sno,
    admno,paid,bal,status,delreason) SELECT sno,admno,paid,bal,status,delreason FROM acc.acc_leaveoutstud; INSERT IGNORE acc_salppcheques(salno,paypoint,nos,dateon,chequeno,amt) SELECT salno,paypoint,nos,dateon,chequeno,
    amt FROM acc.acc_salppcheques; INSERT IGNORE acc_tenants(tno,idno,entrydate,houseno,housetype,exitdate,regdon,addedby,markdel) SELECT tno,idno,entrydate,houseno,housetype,exitdate,capturedon as regdon,addedby,markdel
    FROM acc.acc_tenants; INSERT IGNORE INTO acc_tenantrent(tno,yr,rent,rentfurn,rentwater,rentelect,markdel) SELECT tno,yr,rent,rentfurn,rentwater,rentelect,markdel FROM acc.acc_tenants;"); $i=0;
    do{$comm=''; switch ($i) {case 0:$comm="Department";break; case 1:$comm="Items";break; case 2:$comm="Budgets";break;case 3:$comm="Budget Items";break; case 4:$comm="Draft Budgets";break;
      case 5:$comm="Draft Budget Items";break; case 6:$comm="Fee transfers";break; case 7:$comm="Imprest";break; case 8:$comm="Leaveout Session";break; case 9:$comm="Leaveout Sheets";break;
      case 10:$comm="Salary Cheques";break;case 11:$comm="Tenants";break; case 12:$comm="Rent";break;}echo "STEP 4. ".mysqli_affected_rows($insert)." $comm records uploaded.<br>";
    }while(mysqli_next_result($insert));
  }elseif($action[0]==5){//ARCHIVED FEES & SALARIES STEP1
    mysqli_multi_query($conn,"INSERT IGNORE INTO arch_stf (idno,yr) SELECT idno,yr FROM acc.arch_stf; INSERT IGNORE INTO arch_burs(bursno,yr,sourcename,pytfrm,cheno,pytdate,amt,bankcharge,addedby,addressee,bankno,
    branch,po,pocode,city,markdel,delreason,status) SELECT paymentno,yr,sourcename,paytfrm,chequeno,pytdate,Amount,bankcharge,addedby,addressee,1 as bankno,branch,po,pocode,city,markdel,delreason,status FROM
    acc.arch_burs; INSERT IGNORE INTO arch_saldef(payrollno,yr,idno,acc,bankname,accountno,bsal,nssffee,nssfvol,nhiffee,saccofee,welfare,otherlevies,houseallow,medicalallow,travellallow,responsallow,empnssf,paye,mpr,
    unionfee,helb,bankbranch,addedby,markdel,nssfno,nhifno,unionno,saccono,welfareno) SELECT payrollno,yr,idno,if(salsource LIKE 'main account',1,if(salsource like 'operations account',4,null)) as acc,bankname,accountno,
    bsal,nssffee,nssfvol,nhiffee,saccofee,welfare,otherlevies,houseallow,medicalallow,travellallow,responsallow,empnssf,paye,mpr,unionfee,helb,bankbranch,addedby,markdel,nssfno,nhifno,unionno,saccono,welfareno FROM
    acc.arch_saldef; INSERT IGNORE INTO arch_adv(advno,yr,payrollno,adv_date,amt,authorisedby,rmks,duration,amtperduration,pytfrm,cheno,acsno,acc,vono,advreqno,addedby,markdel,issued) SELECT a.advno,a.yr,d.payrollno,
    a.adv_date,a.amt,a.authorisedby,e.rmks,a.duration,a.amtperduration,e.payform,e.chequeno,e.acsno,a.acc,e.cbvno,null as advreqno,a.addedby,a.markdel,1 as issued FROM acc.arch_adv a Inner Join acc.arch_saldef d USING
    (idno) Inner join acc.arch_exppayee p USING (idno) Inner JOin acc.acc_exp e ON (p.payno=e.expno and e.commt=0); INSERT IGNORE INTO arch_advclr(clrno,yr,advano,clr_date,amt_clr,rmks,salno,markdel) SELECT clrno,yr,
    advano,clr_date,amt_clr,rmks,null as salno,markdel FROM acc.arch_advclr; INSERT IGNORE INTO arch_salaries(salno,sal_month,sal_year,acc,acsno,voteno,processedon,addedby,markdel,batchno,checkstatus,approvestatus,verno)
    SELECT s.salno,s.sal_month,s.sal_year,s.acc,s.acsno,v.sno as voteno,s.processedon,s.addedby,s.markdel,s.batchno,s.checkstatus,s.approvestatus,s.verno FROM acc.arch_salaries s Inner Join acc.arch_votes v ON
    (s.acc=v.acc and v.abbr='p/emol');INSERT IGNORE INTO arch_salpyt(payrollno,salno,bsalary,housingallow1,medicalallow1,travelallow1,responsallow1,nssffee1,nssfvol1,nhiffee1,welfare1,sacco1,otherlevies1,advance,empnssf,
    paye1,mpr1,union1,helb1,paypoint,markdel) SELECT d.payrollno,s.salno,s.bsalary,s.housingallow1,s.medicalallow1,s.travelallow1,s.responsallow1,s.nssffee1,s.nssfvol1,s.nhiffee1,s.welfare1,s.sacco1,s.otherlevies1,
    s.advance,s.empnssf,s.paye1,s.mpr1,s.union1,s.helb1,s.paypoint,s.markdel FROM arch_salpyt s Inner Join arch_saldef d USING (idno); INSERT IGNORE INTO arch_alterincome(code,yr,alt_names,telno,idno,paddress,acc,
    product,voteno,rmks,hiredate,addedby,markdel) SELECT code,yr,alt_names,telno,idno,paddress,ac,product,voteno,rmks,serv_date,addedby,markdel FROM  acc.arch_alterincome;") or die(mysqli_error($conn).". ARCHIVE 1.
    Click <a href=\"financialyearchange.php\">HERE</a> to go back.");
    do{echo "ARCHIVE STEP 1. ".mysqli_affected_rows($conn)." records uploaded.<br>";}while(mysqli_next_result($conn));
    //STEP TWO  **********************payments
    mysqli_multi_query($insert,"INSERT IGNORE INTO arch_exppayee(payno,yr,regdate,payee,idno,address,telno,email,addedby,markdel) SELECT payno,yr,regdate,payee,idno,address,telno,null as email,addedby,markdel FROM
    acc.arch_exppayee;INSERT IGNORE INTO arch_exp(vono,yr,acsno,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,commt,addedby,markdel,recsno,salno,delreason,recno) SELECT cast(voucherno as int) as vono,yr,acsno,pytdate,
    accountno,payform,chequeno,caamt,chamt,rmks,expno,commt,addedby,markdel,recieptno,salno,delreason,verno FROM arch.acc_exp;INSERT IGNORE INTO arch_creditors(cred_no,yr,supid,cred_yr,idno,name,telno,paddress,email,regdate,
    addedby,markdel,delreason,categ) SELECT cred_no,yr,supid,yr as cred_yr,idno,name,telno,paddress,null as email,regdate,addedby,markdel,delreason,0 as cated FROM acc.arch_creditors; INSERT IGNORE INTO arch_creditorsdet
    (detno,yr,cred_no,inv_no,inv_date,lpono,acc,cred_yr,voteno,amt,estimatedamt,rmks,delreason,admno,addedby,markdel) SELECT detno,yr,cred_no,'0001' as inv_no,regdate as inv_date,lpono,acno as acc,cred_yr,voteno,amt,
    estimatedamt,rmks,delreason,null as admno,addedby,markdel FROM acc.arch_creditorsdet; INSERT IGNORE INTO arch_cashflow(cfno,yr,acc,cftype,cfdate,rmks,amt,transtype,transno,markdel,delreason,addedby) SELECT cfno,yr,ac,
    cftype,cfdate,rmks,amt,transtype,transno,markdel,delreason,addedby FROM acc.arch_cashflow; INSERT IGNORE INTO arch_banking(sno,yr,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,markdel,addedby) SELECT
    transano,yr,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,markdel,addedby FROM acc.arch_banking;INSERT IGNORE INTO arch_fyestimates SELECT * FROM acc.arch_fyestimates; INSERT INTO arch_fseben SELECT * FROM
    acc.arch_govtfundben; INSERT IGNORE INTO arch_arrrefchanges(sno,admno,arr_yr,doneon,prevamt,newamt,ac,type,rmks,addedby) SELECT sno,admno,arr_yr,doneon,if(oldarr>0,oldarr,oldref) as prevamt,newarr,ac,type,rmks,addedby
    FROM acc.arch_arrrefchanges;INSERT IGNORE INTO arch_arrrefclr(clrno,yr,recno,arr_year,ac,clron,admno,amt,transtype,markdel,changermks) SELECT clrno,yr,recieptno,arr_year,ac,clron,admno,amt,transtype,markdel,changermks
    FROM acc.arch_arrrefclr; SELECT DISTINCT yr FROM arch_votes ORDER BY yr ASC;");  $i=0;
    do{if($i<10){$comm=''; switch ($i){case 0:$comm='Payee Details';break;case 1:$comm='Payment Details';break;case 2:$comm='Creditors Details';break;case 3:$comm='Commitment Details';break;
      case 4:$comm='Cash at Hand Transactions';break; case 5:$comm='Cash at Bank Transactions';break;case 6:$comm='FY Estimate Details';break;case 7:$comm='FSE Beneficiary Details';break;
      case 8:$comm='Arrears Changes Details';break; case 9:$comm='Arrears Recovery Details';break;} echo "ARCHIVE STEP 2. ".mysqli_affected_rows($insert)." $comm records uploaded.<br>";
      }else{if($rs=mysqli_store_result($conn)) while($d=mysqli_fetch_row($rs)) $arch_yr[]=$d[0]; mysqli_free_result($rs);} $i++;
    }while(mysqli_next_result($insert));
    mysqli_multi_query($conn,"INSERT IGNORE INTO acc_feetransfer(transno,transdate,recieptno,fromadmno,receiveradmno,amt,rmks,ac,transtype,markdel) SELECT transno,transdate,recieptno,fromadmno,receiveradmno,amt,
    rmks,ac,transtype,markdel FROM acc.arch_feetransfer; INSERT IGNORE INTO arch_imp(impno,yr,acc,cudate,idno,amt,rmks,approvedby,status,vno,reqno,delreason,markdel,addedby) SELECT impno,yr,acc,cudate,idno,amt,rmks,
    approvedby,state,vno,reqno,delreason,markdel,addedby FROM acc.arch_imp; INSERT IGNORE INTO arch_leaveout(sno,yr,preparedon,leavedate,returndate,lvlno,clsno,minbal,addedby,markdel,delreason) SELECT sno,yr,preparedon,
    leavedate,returndate,lvlno,clsno,minbal,addedby,markdel,delreason FROM acc.arch_leaveout; INSERT IGNORE INTO arch_leaveoutstud(sno,yr,admno,paid,bal,status,delreason) SELECT sno,yr,admno,paid,bal,status,delreason
    FROM acc.arch_leaveoutstud; INSERT IGNORE INTO arch_salppcheques(salno,yr,paypoint,nos,dateon,chequeno,amt) SELECT salno,yr,paypoint,nos,dateon,chequeno,amt FROM acc.arch_salppcheques;");
    do{echo "STEP 4. ".mysqli_affected_rows($conn)." records uploaded.";}while(mysqli_next_result($conn));
  }else{
    annualArchive($action[0],$action[1],$conn,$insert);
  }
?>
