<?php
	session_start();
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	$edi=0;
	$rs=mysqli_query($conn,"SELECT setupedit FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'"); if(mysqli_num_rows($rs)>0) list($edi)=mysqli_fetch_row($rs);
	mysqli_free_result($rs);
	if ($data[0]==0){ //class level settings
  	if (strlen($data[1])>2){
				$sql="INSERT INTO classlvl(lvlno,lvlname) VALUES(0,'$data[1]')";
				mysqli_query($conn,$sql) or die(mysqli_error($conn)." Class level details not saved.");
    } else print "<p style=\"color:#e00;font-weight:bold;\">Data provided has omission/ errors. Record not saved</p>";
    $sql="SELECT lvlno,lvlname FROM classlvl order by lvlno asc";	$rs=mysqli_query($conn,$sql);
		echo '<table class="table table-hover table-striped"><thead class="thead-dark"><tr><th class="show" colspan="6" style="font-size:12pt;font-weight:bold;letter-spacing:4px;
		word-spacing:6px;">LIST OF CLASS LEVELS</th></tr><tr><th class="show">S/No.</th><th class="show">Name</th><th class="show">Action</th></tr></thead><tbody>'; 	$i=1;
		while ($data=mysqli_fetch_row($rs)){
      echo '<tr><td class="show">'.$i.'</td><td class="show">'.$data[1].'</td><td class="show">'.($edi==1?'<span onclick="showModal(1,'.$data[0].')" Title="Edit" class="spedit">
			&#x270d;</span>':'').'</td>'; $i++;
		}
	}elseif($data[0]==1||$data[0]==3){//class details body
    if (strlen($data[1])>0 && strlen($data[3])>2 && $data[2]>0){
        $sql="INSERT INTO classnames(clsno,clsname,lvlno) VALUES('$data[1]','$data[3]','$data[2]');";
        mysqli_query($conn,$sql) or die(mysqli_error($conn)." Class Details Not Saved.");
		} else print "<p style=\"color:#e00;font-weight:bold;\">Class data provided has omission/ errors. Record not saved</p>";
    $sql="SELECT c.clsno,c.clsname,l.lvlname FROM classnames c Inner Join classlvl l USING (lvlno) ORDER BY c.clsno asc";
    $rs=mysqli_query($conn,$sql);
    echo '<table class="table table-hover table-striped"><thead class="thead-dark"><tr><th class="show" colspan="8" style="font-size:12pt;font-weight:bold;letter-spacing:4px;
		word-spacing:6px;">LIST OF CLASSES</th></tr><tr><th class="show">S/No.</th><th class="show">Name</th><th class="show">Level</th><th class="show">Action</th></tr></thead><tbody>';
		$i=1;
    while ($data=mysqli_fetch_row($rs)){
        echo '<tr><td class="show">'.$i.'</td><td class="show">'.$data[1].'</td><td class="show">'.$data[2].'</td><td class="show">'.($edi==0?'':'<span
				onclick="showModal(2,'.$data[0].')" Title="Edit" class="spedit">&#x270d;</span>').'</td>';
        $i++;
    }
	}
	echo '</tbody></table>'; mysqli_close($conn);
?>
