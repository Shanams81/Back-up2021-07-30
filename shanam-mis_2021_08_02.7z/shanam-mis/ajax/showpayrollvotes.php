<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0] 0 - Bank A/C 1 - Voteheads [0]-A/C No,[1]- feegroup and [2] lvl
	if ($data[0]==0) $sql="SELECT a.sno,concat(b.descr,' A/C NO. ',a.accno) as ac FROM acc_accounts a Inner Join acc_banks b On (a.bankno=b.sno) Inner Join acc_voteacs ac On 
	(a.accacc=ac.acno) WHERE ac.sal_assoc=1 and a.accacc LIKE '$data[1]' and a.markdel=0 ORDER BY a.sno ASC;";
	else $sql="SELECT sno,descr FROM acc_votes WHERE acc LIKE '$data[1]'";
	$rs=mysqli_query($conn,$sql);
	if ($data[0]==0) echo '<SELECT size="1" name="cboAC1" id="cboAC1"  class="form-control">'; else echo '<SELECT size="1" name="cboVotes1" id="cboVotes1"  class="form-control">';
	if (mysqli_num_rows($rs)>0) while ($dat=mysqli_fetch_row($rs)) echo '<option value="'.$dat[0].'" '.($data[0]==1?(stripos($dat[1],'emolum')==false?'':'selected'):"").'>'.$dat[1].'</option>';
	echo '</SELECT>';
	mysqli_close($conn);
?>