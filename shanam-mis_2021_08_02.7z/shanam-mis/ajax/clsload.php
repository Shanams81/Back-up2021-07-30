<?php
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);
	echo '<SELECT name="cboForm" id="cboForm" size="4" class="modalinput">';
	$rsStr=mysqli_query($conn,"SELECT clsno,clsname FROM classnames WHERE lvlno LIKE '".$data[1]."' ORDER BY clsno") or die(mysqli_error($conn).' Error in database connection');
	if (mysqli_num_rows($rsStr)>0) while (list($cls,$clsname)=mysqli_fetch_row($rsStr)) echo '<option value="'.$cls.'">'.$clsname.'</option>';
	mysqli_free_result($rsStr);
	print '</SELECT>'; mysqli_close($conn);
?>
