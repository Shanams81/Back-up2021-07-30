<?php
	session_start();
	include_once('../../conn/pri_sch_connect.inc');
	$data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\-/',$data);	//[0]-IDNO,[1]- feegroup and [2] lvl
	$h=$data[0];	$i=0;	$stviu=0; $sted=0; $lvlname="";
	$rs=mysqli_query($conn,"SELECT ((s.bsal+s.travellallow+s.medicalallow+s.houseallow+s.empnssf)-(s.nssffee+(s.paye-s.mpr)+s.empnssf+s.otherlevies+s.nhiffee+s.unionfee+s.saccofee+s.welfare)-
        if(isnull(a.bal),0,a.bal)) as ns FROM acc_saldef s LEFT JOIN (SELECT a.payrollno,sum(bal) as bal FROM (SELECT a.payrollno,a.advno,(a.amt-if(isnull(c.ttl),0,c.ttl)) as bal FROM acc_adv a LEFT 
        JOIN (SELECT advano,sum(amt_clr) as ttl FROM acc_advclr GROUP BY advano,markdel HAVING markdel=0)c On (a.advno=c.advano) WHERE a.markdel=0 and a.issued=1)a Inner Join acc_saldef s USING (payrollno) GROUP BY 
	a.payrollno,s.idno HAVING a.payrollno LIKE '$data[0]')a USING (payrollno) WHERE s.payrollno LIKE '$data[0]'");	$net=0; 
	list($net)=mysqli_fetch_row($rs);
	echo number_format($net,2);
	mysqli_close($conn);
?>