<?php
	include_once('shanam.php');
	$rsDet=mysqli_query($conn,"SELECT sysdata FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'");	$sys=0;
	if (mysqli_num_rows($rsDet)>0) list($sys)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	$payeno=isset($_REQUEST['paye'])?$_REQUEST['paye']:0;		$act=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; 		$act=preg_split('/\-/',$act);
	headings('<link rel="stylesheet" href="tpl/css/inputsettings.css"/>',$act[0],$act[1],1);
?>
<div class="container divgen"><form method="post" action="taxbracketsave.php">
	<div class="form-row">
		<div class="col-md-12" style="color:#0F3;text-align:center;background-color:#444;font-style:bold;font-size:1.2rem;word-spacing:5px;letter-spacing:3px;padding:8px;
		border-radius:10px 10px 0 0;">PAYE TAX BRACKETS	MANAGEMENT INTERFACE</div>
	</div><div class="form-row">
		<div class="col-md-4 divsubheading">Salary From</div><div class="col-md-4 divsubheading">Salary To</div><div class="col-md-2 divsubheading">Rate (%)</div><div
		class="col-md-1 divsubheading">Action</div>
	</div>
	<?php
 	$rs=mysqli_query($conn,"SELECT payeno,lowerbound,upperbound,rate FROM acc_payecalc ORDER BY payeno ASC"); $i=0;
 	while (list($paye,$lb,$ub,$rate)=mysqli_fetch_row($rs)){
 	 	print "<div class=\"form-row\">";
		if ($payeno==$paye) print "<div class=\"col-md-4\"><input name=\"txtNo\" value=\"$i\" type=\"hidden\"><input name=\"txtPAYE_$i\" type=\"hidden\" value=\"$paye\"><input
		type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtLB_$i\" value=\"".number_format($lb,2)."\" style=\"color:#00c;\"></div><div
		class=\"col-md-4\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtUB_$i\" value=\"".number_format($ub,2)."\" style=\"color:#00c;\">
		</div><div class=\"col-md-2\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"4\" name=\"txtRate_$i\" value=\"".number_format($rate,1)."\"
		style=\"color:#00c;\"></div><div class=\"col-md-1\"><button type=\"submit\" name=\"cmdSave\" style=\"background-color:inherit;\"><img src=\"../gen_img/save.ico\" height=\"20\"
		width=\"20\" title=\"Save\"></button></div>";
		else print "<div class=\"col-md-4\"><input name=\"txtPAYE_$i\" type=\"hidden\" value=\"$i-$paye\"><input type=\"text\" class=\"modalinput numbersinput\"
		maxlength=\"13\" name=\"txtLB_$i\" id=\"txtLB_$i\" readonly value=\"".number_format($lb,2)."\"></div><div class=\"col-md-4\"><input type=\"text\" class=\"modalinput
		numbersinput\" maxlength=\"13\" name=\"txtUB_$i\" id=\"txtUB_$i\" readonly value=\"".number_format($ub,2)."\"></div><div class=\"col-md-2\"><input
		type=\"text\" class=\"modalinput numbersinput\" maxlength=\"4\" name=\"txtRate_$i\" id=\"txtRate_$i\" readonly value=\"".number_format($rate,1)."\">
		</div><div class=\"col-md-1\" style=\"text-align:center;\">".($payeno==0?"<img onclick=\"window.open('taxbrackets.php?paye=$paye','_self')\" src=\"../gen_img/edit.ico\"
		height=\"20\"	width=\"20\" title=\"Edit\"></a>":"")."</div>";
		print "</div>";
		$i++;
	}
?><br><hr><br>
<div class="form-row"><div class="col-md-12" style="text-align:right;"><button type="button" name="btnClose" onclick="window.open('settings_manager.php','_self')" class="btn
	btn-info btn-md">Close</button></div>
</div></div>
<?php mysqli_close($conn);	footer();?>
