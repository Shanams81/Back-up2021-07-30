<html><head><title>Blank</title></head>
<body background="img/bg3.gif">
<h1>You have no priviledges on this operation. You are not allowed to view the content of this web page.</h1>
</body>
</html>