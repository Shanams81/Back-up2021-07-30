<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['CmdSave'])){
		$recno=isset($_POST['TxtRecNo'])?trim(strip_tags($_POST['TxtRecNo'])):0; 		$recno=(strcasecmp($recno,"auto")==0 || strlen($recno)==0)?Null:$recno;
		$admno=isset($_POST['TxtAdmNo'])?trim(strip_tags($_POST['TxtAdmNo'])):'';		$date=date('Y-m-d'); $paidby=isset($_POST['CboPaidBy'])?trim(strip_tags($_POST['CboPaidBy'])):'Guardian';	
		$bursno=isset($_POST['TxtBursNo'])?trim(strip_tags($_POST['TxtBursNo'])):Null;		$bursno=strlen($bursno)==0?Null:$bursno;		
		$pytfrm=isset($_POST['CboPytFrm'])?trim(strip_tags($_POST['CboPytFrm'])):'Cash'; 	
		$cheno=isset($_POST['TxtCheNo'])?trim(strip_tags($_POST['TxtCheNo'])):Null; 	$cheno=strlen($cheno)==0?Null:strtoupper($cheno);
		$bank=strcasecmp($pytfrm,"cash")==0?None:trim($_POST['CboBank']);				$bank=strcasecmp($bank,"none")==0?Null:$bank; 
		$kind=isset($_POST['TxtKind'])?trim(strip_tags($_POST['TxtKind'])):Null; 		$kind=strlen($kind)==0?Null:strtoupper($kind);
		$bc=isset($_POST['TxtBC'])?trim(strip_tags($_POST['TxtBC'])):0;					
		$mainamt=isset($_POST['TxtMainFee'])?trim(strip_tags($_POST['TxtMainFee'])):0; 	
		$miscamt=isset($_POST['TxtMiscFee'])?trim(strip_tags($_POST['TxtMiscFee'])):0; 	
		$admno=preg_split('/\-/',$admno); //admno[0] admission no., admno[1] financial year	
		$tui=isset($_POST['TxtTui'])?trim(strip_tags($_POST['TxtTui'])):0; 				$misid=isset($_POST['TxtMisID'])?trim(strip_tags($_POST['TxtMisID'])):0;
		$boa=isset($_POST['TxtBoard'])?trim(strip_tags($_POST['TxtBoard'])):0; 			$misqa=isset($_POST['TxtMisQA'])?trim(strip_tags($_POST['TxtMisQA'])):0;
		$act=isset($_POST['TxtAct'])?trim(strip_tags($_POST['TxtAct'])):0; 				$misrem=isset($_POST['TxtMisRem'])?trim(strip_tags($_POST['TxtMisRem'])):0;
		$ltt=isset($_POST['TxtLTT'])?trim(strip_tags($_POST['TxtLTT'])):0;				$misht=isset($_POST['TxtMisHT'])?trim(strip_tags($_POST['TxtMisHT'])):0;
		$rmi=isset($_POST['TxtRMI'])?trim(strip_tags($_POST['TxtRMI'])):0; 				$misgra=isset($_POST['TxtMisGrad'])?trim(strip_tags($_POST['TxtMisGrad'])):0;
		$ewc=isset($_POST['TxtEWC'])?trim(strip_tags($_POST['TxtEWC'])):0; 				$mistrip=isset($_POST['TxtMisTrip'])?trim(strip_tags($_POST['TxtMisTrip'])):0;
		$exa=isset($_POST['TxtExam'])?trim(strip_tags($_POST['TxtExam'])):0;			$misuni=isset($_POST['TxtMisUni'])?trim(strip_tags($_POST['TxtMisUni'])):0;
		$admin=isset($_POST['TxtAdmin'])?trim(strip_tags($_POST['TxtAdmin'])):0; 		$misarr=isset($_POST['TxtMisArr'])?trim(strip_tags($_POST['TxtMisArr'])):0;
		$lib=isset($_POST['TxtLib'])?trim(strip_tags($_POST['TxtLib'])):0; 				$misole=isset($_POST['TxtMisOle'])?trim(strip_tags($_POST['TxtMisOle'])):0;
		$med=isset($_POST['TxtMed'])?trim(strip_tags($_POST['TxtMed'])):0;				$spemed=isset($_POST['TxtSpeMed'])?trim(strip_tags($_POST['TxtSpeMed'])):0;
		$trans=isset($_POST['TxtTrans'])?trim(strip_tags($_POST['TxtTrans'])):0;		$pem=isset($_POST['TxtPEM'])?trim(strip_tags($_POST['TxtPEM'])):0;
		$arr=isset($_POST['TxtArr'])?trim(strip_tags($_POST['TxtArr'])):0;				$ref=isset($_POST['TxtRef'])?trim(strip_tags($_POST['TxtRef'])):0;
		$prep=isset($_POST['TxtPrep'])?trim(strip_tags($_POST['TxtPrep'])):0;			$ole=isset($_POST['TxtOle'])?trim(strip_tags($_POST['TxtOle'])):0;
		$un=$_SESSION[username]." (".$_SESSION['priviledge'].")";
		$bc=preg_replace("/[^0-9^\.]/","",$bc);			$mainamt=preg_replace("/[^0-9^\.]/","",$mainamt);  			$miscamt=preg_replace("/[^0-9^\.]/","",$miscamt); 
		//main account voteheads
		$tui=preg_replace("/[^0-9^\.]/","",$tui); 	$boa=preg_replace("/[^0-9^\.]/","",$boa);	$act=preg_replace("/[^0-9^\.]/","",$act);	$ltt=preg_replace('/[^0-9^\.]/','',$ltt); 	
		$rmi=preg_replace('/[^0-9^\.]/','',$rmi); 	$ewc=preg_replace('/[^0-9^\.]/','',$ewc);	$exa=preg_replace("/[^0-9^\.]/","",$exa);	$admin=preg_replace("/[^0-9^\.]/","",$admin);
		$lib=preg_replace('/[^0-9^\.]/','',$lib); 	$med=preg_replace('/[^0-9^\.]/','',$med); 	$spemed=preg_replace('/[^0-9^\.]/','',$spemed); $trans=preg_replace("/[^0-9^\.]/","",$trans);
		$pem=preg_replace('/[^0-9^\.]/','',$pem); 	$arr=preg_replace('/[^0-9^\.]/','',$arr); 	$ref=preg_replace('/[^0-9^\.]/','',$ref); 		$prep=preg_replace("/[^0-9^\.]/","",$prep);
		$ole=preg_replace('/[^0-9^\.]/','',$ole); 	$mainttl=$tui+$boa+$act+$ltt+$rmi+$ewc+$exa+$admin+$lib+$med+$spemed+$trans+$pem+$arr+$ref+$prep+$ole;
		//misc account voteheads
		$misid=preg_replace('/[^0-9^\.]/','',$misid);  		$misqa=preg_replace('/[^0-9^\.]/','',$misqa); 		$misrem=preg_replace('/[^0-9^\.]/','',$misrem);
		$misht=preg_replace('/[^0-9^\.]/','',$misht); 		$misgra=preg_replace('/[^0-9^\.]/','',$misgra); 	$mistrip=preg_replace('/[^0-9^\.]/','',$mistrip);
		$misuni=preg_replace('/[^0-9^\.]/','',$misuni); 	$misarr=preg_replace('/[^0-9^\.]/','',$misarr);		$misole=preg_replace('/[^0-9^\.]/','',$misole); 
		$miscttl=$misid+$misqa+$misrem+$misht+$misgra+$mistrip+$misuni+$misarr+$misole; 
		//SQL statement to save record
		if ((($mainamt!=$mainttl) && ($miscamt!=$miscttl)) || ((strcasecmp($pytfrm,"Cheque")==0 || strcasecmp($pytfrm,"Direct Banking")==0 || strcasecmp($pytfrm,"Money Order")==0 || 
		strcasecmp($pytfrm,"M-Fees")==0) && strlen($cheno)==0) || (strcasecmp($pytfrm,"Kind")==0  && strlen($kind)==0) && ($_SESSION['form_token']!=$_POST['form_token'])){
			print "Sorry, the fee receipt record had errors. The reciept was not sucessfully saved. Click <a href=\"studfee.php\">here</a> to try again";
			unset($_SESSION['form_token']);
			exit();
		}
		$mainrecno=0; 	$miscrecno=0; $i=0;
		if($mainamt>0){
			$sql="INSERT INTO Acc_feerec VALUES (".var_export($recno,true).",'$admno[0]','$date','$admno[1]','$paidby','$pytfrm',".var_export($cheno,true).",'$mainamt',".var_export($bursno,
			true).",'$bc','$tui','$boa','$act','$ltt','$rmi','$ewc','$exa','$admin','0','$lib','$med','$pem','$arr','$spemed','$trans','$ref','$ole','$prep',
			".var_export($bank,true).",'$un','0',".var_export($kind,true).")";
			mysqli_query($conn,$sql) or die(mysqli_error($conn).". Main Account Fees record not saved. Click <a href=\"studfee.php\">here</a> to try again."); 
			$i=mysqli_affected_rows($conn);	$rsRec=mysqli_query($conn,"SELECT LAST_INSERT_ID()"); 	list($mainrecno)=mysqli_fetch_row($rsRec);	mysqli_free_result($rsRec);
			if (($i==1) && ($trans>0 || $spemed>0 || $arr>0)){
				$rs=mysqli_query($conn, "SELECT t1trans,t2trans,t3trans FROM stud Inner Join class USING (admno,curr_year) WHERE stud.admno LIKE '$admno[0]'");
				$tra1=0;	$tra2=0;	$tra3=0;	$tra=mysqli_fetch_array($rs); mysqli_free_result($rs);
				if ($trans>0){
					if($tra[0]>0){
					 	if ($trans>=$tra[0]){$tra1=$tra[0];$trans-=$tra[0];} else {$tra1=$trans; $trans=0;}
					}
					if($tra[1]>0 && $trans>0){
					 	if ($trans>=$tra[1]){$tra2=$tra[1];$trans-=$tra[1];} else {$tra2=$trans; $trans=0;}
					}
					if($tra[2]>0 && $trans>0){
						if ($trans>=$tra[2]){$tra3=$tra[2];$trans-=$tra[2];} else {$tra3=$trans; $trans=0;}	
					} 	
				}
				mysqli_query($conn,"UPDATE class SET bbf=(bbf-$arr),specialmedical=(specialmedical-$spemed),t1trans=(t1trans-$tra1),t2trans=(t2trans-$tra2),
				t3trans=(t3trans-$tra3) WHERE (admno LIKE '$admno[0]' AND curr_year LIKE '$admno[1]')") or die(mysqli_error($conn). " Main Account Fee Balance 
				Not Updated");		
			}
		}
		if($miscamt>0){
		 	$bc=$mainamt>0?0:$bc;//avoid double entry of bank charges
			$sql="INSERT INTO Acc_miscfeepyts VALUES (null,'$admno[0]','$date','$admno[1]','$paidby','$pytfrm',".var_export($cheno,true).",".var_export($bursno,true).",'$miscamt','$bc',
			'$misqa','$misid','$misrem','$misole','$misarr','$misht','$misuni','$misgra','$mistrip',".var_export($bank,true).",".var_export($kind,true).",'$un',0,".
			var_export(($mainrecno==0?null:$mainrecno),true).")";
			mysqli_query($conn,$sql) or die(mysqli_error($conn).". Misc. Account Fees record not saved. Click <a href=\"studfee.php\">here</a> to try again."); 
			$i=mysqli_affected_rows($conn);	$rsRec=mysqli_query($conn,"SELECT LAST_INSERT_ID()"); 	list($miscrecno)=mysqli_fetch_row($rsRec);	
			mysqli_free_result($rsRec);
			if ($i==1 && ($misuni>0 || $misarr>0)){
				mysqli_query($conn,"UPDATE class SET unifrm=(unifrm-$misuni), miscbf=(miscbf-$misarr) WHERE (admno Like '$admno[0]' and curr_year Like 
				'$admno[1]')") or die(mysqli_error($conn)." Miscellaneous Account Fee Balance Not Updated.");
			}
		}
		//which account is to be printed
		unset($_SESSION['form_token']);
		if ($mainrecno>0 && $miscrecno>0) $ac=0; elseif ($mainrecno>0 && $miscrecno==0) $ac=1; else $ac=2;
		if ($i==1)	header ("Location:receipt.php?recno=$mainrecno-$miscrecno-$ac-0"); else header("location:studfee.php");
	}else{
     	$info=isset($_REQUEST['cod']) ? strip_tags($_REQUEST['cod']): "0-0"; 	$info=preg_split('/\-/',$info);
     	$form_token=uniqid();
	 	$_SESSION['form_token']=$form_token;
		$rsStud=mysqli_query($conn,"SELECT s.admno,s.names,s.clsname,s.cls,s.specialmedical,s.bbf,s.t1trans,if((f.t1board-s.boap)<1,0,(f.t1board-s.boap)) as t1boabal,if((f.t1act-s.actp)<1,0,
		(f.t1act-s.actp)) as t1actbal,if((f.t1pemol-s.pemp)<1,0,(f.t1pemol-s.pemp)) as t1pembal,if((f.t1ltt-s.lttp)<1,0,(f.t1ltt-s.lttp)) as t1lttbal,if((f.t1rmi-s.rmip)<1,0,(f.t1rmi-
		s.rmip)) as t1rmibal,if((f.t1ewc-s.ewcp)<1,0,(f.t1ewc-s.ewcp)) as t1ewcbal,if((f.t1adm-s.adminp)<1,0,(f.t1adm-s.adminp)) as t1admbal,if((f.t1lib-s.libp)<1,0,(f.t1lib-s.libp)) as 
		t1libbal,if((f.t1med-s.medp)<1,0,(f.t1med-s.medp)) as t1medbal,if((f.t1tui-s.tuip)<1,0,(f.t1tui-s.tuip)) as t1tuibal, if((f.t1exam-s.exap)<1,0,(f.t1exam-s.exap)) as t1exabal,
		if((f.t1olevies-s.olep)<1,0,(f.t1olevies-s.olep)) as t1olebal,if((f.maint1-s.amtp)<1,(s.specialmedical+s.bbf+s.t1trans),(f.maint1-s.amtp+s.specialmedical+s.bbf+s.t1trans)) as 
		t1bal,s.t2trans,if((f.t2board-s.boap-if((f.t1board-s.boap)<1,0,(f.t1board-s.boap)))<1,0,(f.t2board-s.boap-if((f.t1board-s.boap)<1,0,(f.t1board-s.boap)))) as t2boabal,if((f.t2act-
		s.actp-if((f.t1act-s.actp)<1,0,(f.t1act-s.actp)))<1,0,(f.t2act-s.actp-if((f.t1act-s.actp)<1,0,(f.t1act-s.actp)))) as t2actbal,if((f.t2pemol-s.pemp-if((f.t1pemol-s.pemp)<1,0,
		(f.t1pemol-s.pemp)))<1,0,(f.t2pemol-s.pemp-if((f.t1pemol-s.pemp)<1,0,(f.t1pemol-s.pemp)))) as t2pembal,if((f.t2ltt-s.lttp-if((f.t1ltt-s.lttp)<1,0,(f.t1ltt-s.lttp)))<1,0,(f.t2ltt-
		s.lttp-if((f.t1ltt-s.lttp)<1,0,(f.t1ltt-s.lttp)))) as t2lttbal,if((f.t2rmi-s.rmip-if((f.t1rmi-s.rmip)<1,0,(f.t1rmi-s.rmip)))<1,0,(f.t2rmi-s.rmip-if((f.t1rmi-s.rmip)<1,0,(f.t1rmi-
		s.rmip)))) as t2rmibal,if((f.t2ewc-s.ewcp-if((f.t1ewc-s.ewcp)<1,0,(f.t1ewc-s.ewcp)))<1,0,(f.t2ewc-s.ewcp-if((f.t1ewc-s.ewcp)<1,0,(f.t1ewc-s.ewcp)))) as t2ewcbal,if((f.t2adm-
		s.adminp-if((f.t1adm-s.adminp)<1,0,(f.t1adm-s.adminp)))<1,0,(f.t2adm-s.adminp-if((f.t1adm-s.adminp)<1,0,(f.t1adm-s.adminp)))) as t2admbal,if((f.t2lib-s.libp-if((f.t1lib-s.libp)<1,
		0,(f.t1lib-s.libp)))<1,0,(f.t2lib-s.libp-if((f.t1lib-s.libp)<1,0,(f.t1lib-s.libp)))) as t2libbal, if((f.t2med-s.medp-if((f.t1med-s.medp)<1,0,(f.t1med-s.medp)))<1,0,(f.t2med-
		s.medp-if((f.t1med-s.medp)<1,0,(f.t1med-s.medp)))) as t2medbal, if((f.t2tui-s.tuip-if((f.t1tui-s.tuip)<1,0,(f.t1tui-s.tuip)))<1,0,(f.t2tui-s.tuip-if((f.t1tui-s.tuip)<1,0,(f.t1tui-
		s.tuip)))) as t2tuibal,if((f.t2exam-s.exap-if((f.t1exam-s.exap)<1,0,(f.t1exam-s.exap)))<1,0,(f.t2exam-s.exap-if((f.t1exam-s.exap)<1,0,(f.t1exam-s.exap)))) as t2exabal,
		if((f.t2olevies-s.olep-if((f.t1olevies-s.olep)<1,0,(f.t1olevies-s.olep)))<1,0,(f.t2olevies-s.olep-if((f.t1olevies-s.olep)<1,0,(f.t1olevies-s.olep)))) as t2olebal,if((f.maint2-
		s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))<1,s.t2trans,(f.maint2+s.t2trans-s.amtp-if((f.maint1-s.amtp)<1,0,(f.maint1-s.amtp)))) as t2bal,s.t3trans,if((f.board-s.boap-
		if((f.t2board-s.boap)<1,0,(f.t2board-s.boap)))<1,0,(f.board-s.boap-if((f.t2board-s.boap)<1,0,(f.t2board-s.boap)))) as t3boabal, if((f.act-s.actp-if((f.t2act-s.actp)<1,0,(f.t2act-
		s.actp)))<1,0,(f.act-s.actp-if((f.t2act-s.actp)<1,0,(f.t2act-s.actp)))) as t3actbal,if((f.pemol-s.pemp-if((f.t2pemol-s.pemp)<1,0,(f.t2pemol-s.pemp)))<1,0,(f.pemol-s.pemp-
		if((f.t2pemol-s.pemp)<1,0,(f.t2pemol-s.pemp)))) as t3pembal, if((f.ltt-s.lttp-if((f.t2ltt-s.lttp)<1,0,(f.t2ltt-s.lttp)))<1,0,(f.ltt-s.lttp-if((f.t2ltt-s.lttp)<1,0,(f.t2ltt-
		s.lttp)))) as t3lttbal, if((f.rmi-s.rmip-if((f.t2rmi-s.rmip)<1,0,(f.t2rmi-s.rmip)))<1,0,(f.rmi-s.rmip-if((f.t2rmi-s.rmip)<1,0,(f.t2rmi-s.rmip)))) as t3rmibal, if((f.ewc-s.ewcp-
		if((f.t2ewc-s.ewcp)<1,0,(f.t2ewc-s.ewcp)))<1,0,(f.ewc-s.ewcp-if((f.t2ewc-s.ewcp)<1,0,(f.t2ewc-s.ewcp)))) as t3ewcbal, if((f.adm-s.adminp-if((f.t2adm-s.adminp)<1,0,(f.t2adm-
		s.adminp)))<1,0,(f.adm-s.adminp-if((f.t2adm-s.adminp)<1,0,(f.t2adm-s.adminp)))) as t3admbal, if((f.lib-s.libp-if((f.t2lib-s.libp)<1,0,(f.t2lib-s.libp)))<1,0,(f.lib-s.libp-
		if((f.t2lib-s.libp)<1,0,(f.t2lib-s.libp)))) as t3libbal, if((f.med-s.medp-if((f.t2med-s.medp)<1,0,(f.t2med-s.medp)))<1,0,(f.med-s.medp-if((f.t2med-s.medp)<1,0,(f.t2med-s.medp)))) 
		as t3medbal, if((f.tui-s.tuip-if((f.t2tui-s.tuip)<1,0,(f.t2tui-s.tuip)))<1,0,(f.tui-s.tuip-if((f.t2tui-s.tuip)<1,0,(f.t2tui-s.tuip)))) as t3tuibal, if((f.exam-s.exap-if((f.t2exam-
		s.exap)<1,0,(f.t2exam-s.exap)))<1,0,(f.exam-s.exap-if((f.t2exam-s.exap)<1,0,(f.t2exam-s.exap)))) as t3exabal,if((f.olevies-s.olep-if((f.t2olevies-s.olep)<1,0,(f.t2olevies-s.olep)))
		<1,0,(f.olevies-s.olep-if((f.t2olevies-s.olep)<1,0,(f.t2olevies-s.olep)))) as t3olebal,if((f.maint3-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))<1,s.t3trans,(f.maint3+
		s.t3trans-s.amtp-if((f.maint2-s.amtp)<1,0,(f.maint2-s.amtp)))) as t3bal,(s.t1trans+s.t2trans+s.t3trans) as trans,(f.board-s.boap) as boabal, (f.act-s.actp) as actbal,(f.pemol-
		s.pemp) as pembal, (f.ltt-s.lttp) as lttbal, (f.rmi-s.rmip) as rmibal,(f.ewc-s.ewcp) as ewcbal, (f.adm-s.adminp) as admbal,(f.lib-s.libp) as libbal, (f.med-s.medp) as medbal,(f.tui
		-s.tuip) as tuibal,(f.exam-s.exap) as exabal, (f.olevies-s.olep) as olebal,(f.maint3+s.specialmedical+s.bbf+s.t1trans+s.t2trans+s.t3trans-s.amtp) as bal FROM (SELECT s.admno,
		concat(s.surname,' ',s.onames) As names,cn.clsname,concat(cn.clsname,'-',c.stream) As cls,c.curr_year,c.feegrp,c.lvlno,c.bbf,c.specialmedical,c.t1trans,c.t2trans,c.t3trans,
		if(isnull(f.tui),0,f.tui) as tuip,if(isnull(f.boa),0,f.boa) as boap,if(isnull(f.act),0,f.act) as actp,if(isnull(f.lt),0,f.lt) as lttp,if(isnull(f.rm),0,f.rm) as rmip,
		if(isnull(f.ew),0,f.ew) as ewcp,if(isnull(f.exa),0,f.exa) as exap,if(isnull(f.admin),0,f.admin) as adminp,if(isnull(f.libra),0,f.libra) as libp,if(isnull(f.med),0,f.med) as medp,
		if(isnull(f.pem),0,f.pem) as pemp,if(isnull(f.ole),0,f.ole) as olep,if(isnull(f.amtpaid),0,f.amtpaid) as amtp FROM stud s Inner Join class c USING (admno,curr_year) Inner Join 
		classnames cn USING (clsno) LEFT JOIN (SELECT f.admno,sum(f.tuition) As tui,sum(f.boarding) As boa,sum(f.activity) As act,sum(f.ltt) As lt,sum(f.rmi) As rm,sum(f.ewc) as ew,
		sum(f.exam) As exa,sum(f.admincosts) As admin,sum(f.lib) as libra,sum(f.medical) as med,sum(f.pemolu) as pem,sum(f.olevy) as ole,sum(amt-arrears-refunds-spemed-transport-prep) As 
		amtpaid FROM acc_feerec f GROUP BY f.admno,f.markdel Having (f.admno LIKE '$info[0]' and f.markdel=0))f On (s.admno=f.admno) WHERE (s.`admno` Like '$info[0]' and 
		s.curr_year=$info[1]))s Inner JOIN acc_feeoutline f USING (curr_year,lvlno,feegrp)");
		$rsMisc=mysqli_query($conn,"SELECT s.miscbf,s.unifrm,if((f.t1misidcard-idp)<1,0,(f.t1misidcard-idp)) as t1id,if((f.t1misqa-qap)<1,0,(f.t1misqa-qap)) as t1qa,if((f.t1misremedial
		-remp)<1,0,(f.t1misremedial-remp)) as t1rem,if((f.t1misht-htp)<1,0,(f.t1misht-htp)) as t1ht,if((f.t1misgrad-gradp)<1,0,(f.t1misgrad-gradp)) as t1grad,if((f.t1mistrip-tripp)<1,0,
		(f.t1mistrip-tripp)) as t1trip,if((f.t1misole-olep)<1,0,(f.t1misole-olep)) as t1ole,if((f.misct1-amtp)<1,(s.miscbf+s.unifrm),(f.misct1-amtp+s.miscbf+s.unifrm)) as t1bal,
		if((f.t2misidcard-idp-if((f.t1misidcard-idp)<1,0,(f.t1misidcard-idp)))<1,0,(f.t2misidcard-idp-if((f.t1misidcard-idp)<1,0,(f.t1misidcard-idp)))) as t2id,if((f.t2misqa-qap-
		if((f.t1misqa-qap)<1,0,(f.t1misqa-qap)))<1,0,(f.t2misqa-qap-if((f.t1misqa-qap)<1,0,(f.t1misqa-qap)))) as t2qa,if((f.t2misremedial-remp-if((f.t1misremedial-remp)<1,0,
		(f.t1misremedial-remp)))<1,0,(f.t2misremedial-remp-if((f.t1misremedial-remp)<1,0,(f.t1misremedial-remp)))) as t2rem,if((f.t2misht-htp-if((f.t1misht-htp)<1,0,(f.t1misht-htp)))<1,0,
		(f.t1misht-htp-if((f.t1misht-htp)<1,0,(f.t1misht-htp)))) as t2ht,if((f.t2misgrad-gradp-if((f.t1misgrad-gradp)<1,0,(f.t1misgrad-gradp)))<1,0,(f.t2misgrad-gradp-if((f.t1misgrad-
		gradp)<1,0,(f.t1misgrad-gradp)))) as t2grad,if((f.t2mistrip-tripp-if((f.t1mistrip-tripp)<1,0,(f.t1mistrip-tripp)))<1,0,(f.t2mistrip-tripp-if((f.t1mistrip-tripp)<1,0,(f.t1mistrip-
		tripp)))) as t2trip,if((f.t2misole-olep-if((f.t1misole-olep)<1,0,(f.t1misole-olep)))<1,0,(f.t2misole-olep-if((f.t1misole-olep)<1,0,(f.t1misole-olep)))) as t2ole,if((f.misct2-amtp-
		if((f.misct1-amtp)<1,0,(f.misct1-amtp)))<1,0,(f.misct2-amtp-if((f.misct1-amtp)<1,0,(f.misct1-amtp)))) as t2bal,if((f.misidcard-idp-if((f.t2misidcard-idp)<1,0,(f.t2misidcard-idp)))
		<1,0,(f.misidcard-idp-if((f.t2misidcard-idp)<1,0,(f.t2misidcard-idp)))) as t3id,if((f.misqa-qap-if((f.t2misqa-qap)<1,0,(f.t2misqa-qap)))<1,0,(f.misqa-qap-if((f.t2misqa-qap)<1,0,
		(f.t2misqa-qap)))) as t3qa,if((f.misremedial-remp-if((f.t2misremedial-remp)<1,0,(f.t2misremedial-remp)))<1,0,(f.misremedial-remp-if((f.t2misremedial-remp)<1,0,(f.t2misremedial-
		remp)))) as t3rem,if((f.misht-htp-if((f.t2misht-htp)<1,0,(f.t2misht-htp)))<1,0,(f.misht-htp-if((f.t2misht-htp)<1,0,(f.t2misht-htp)))) as t3ht,if((f.misgrad-gradp-if((f.t2misgrad-
		gradp)<1,0,(f.t2misgrad-gradp)))<1,0,(f.misgrad-gradp-if((f.t2misgrad-gradp)<1,0,(f.t2misgrad-gradp)))) as t3grad, if((f.mistrip-tripp-if((f.t2mistrip-tripp)<1,0,(f.t2mistrip-
		tripp)))<1,0,(f.mistrip-tripp-if((f.t2mistrip-tripp)<1,0,(f.t2mistrip-tripp)))) as t3trip,if((f.misole-olep-if((f.t2misole-olep)<1,0,(f.t2misole-olep)))<1,0,(f.misole-olep-
		if((f.t2misole-olep)<1,0,(f.t2misole-olep)))) as t3ole,if((f.misct3-amtp-if((f.misct2-amtp)<1,0,(f.misct2-amtp)))<1,0,(f.misct3-amtp-if((f.misct2-amtp)<1,0,(f.misct2-amtp)))) as 
		t3bal,(f.misidcard-idp) as idbal,(f.misqa-qap) as qabal,(f.misremedial-remp) as rembal,(f.misht-htp) as htbal,(f.misgrad-gradp) as gradbal, (f.mistrip-tripp) as tripbal,(f.misole-
		olep) as olebal,(f.misct3+s.miscbf+s.unifrm-amtp) as bal FROM (SELECT c.curr_year,c.lvlno,c.feegrp,c.miscbf,c.unifrm,if(isnull(sqa),0,sqa) as qap, if(isnull(id),0,id) as idp, 
		if(isnull(rem),0,rem) as remp, if(isnull(sht),0,sht) as htp,if(isnull(sgrad),0,sgrad) as gradp,if(isnull(trip),0,trip) as tripp,if(isnull(ole),0,ole) as olep, if(isnull(amtpaid),0,
		amtpaid) as amtp  FROM class c LEFT JOIN (SELECT payeesno,sum(qa) as sqa,sum(idcard) as id,sum(remedial) as rem,sum(ht) as sht,sum(grad) as sgrad,sum(acatrip) as trip,
		sum(olevy) as ole,sum(amt-arrears-uni) as amtpaid FROM acc_miscfeepyts GROUP BY payeesno,markdel HAVING (markdel=0 and payeesno LIKE '$info[0]'))m On 
		(c.admno=m.payeesno) WHERE (c.admno LIKE '$info[0]' and c.curr_year=$info[1]))s Inner Join Acc_feeoutline f USING (curr_year,lvlno,feegrp)");
		if (mysqli_num_rows($rsStud)==1) $data=mysqli_fetch_array($rsStud,MYSQLI_NUM); mysqli_free_result($rsStud);
		if (mysqli_num_rows($rsMisc)==1) $misc=mysqli_fetch_array($rsMisc,MYSQLI_NUM); mysqli_free_result($rsMisc);
		$mon=date('m');
		$balmisc=($mon<5)?$misc[9]:($mon<9?($misc[9]+$misc[17]):$misc[33]); //current miscellenous balance
		$curdate=date('d-m-Y');
	}
	
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<link rel="shortcut icon" href="img/phone.ico"/>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="tpl/feereceipt.js"></script>
	<script type="text/javascript">
		var s_cls= <?php print "\"".strtoupper($data[2])."\""; ?>;
		var voteBal=new Array(<?php $i=0; 
			foreach($data as $amt){
			 	if(($i>5) && ($i<48)) if($i<47) print "$amt,"; else print $amt; 
				$i++;
			}?>);
		var miscBal=new Array(<?php $i=0; 
			foreach($misc as $amt){
			 	if(($i>1) && ($i<26)) if($i<25) print "$amt,"; else print $amt; 
				$i++;
			}?>);
	</script><style>body{font-size:10px;}input,select{border:0.5px dotted #0d0;border-radius:7px;color:#00d;height:14pt;padding:2px;}button{height:24pt;padding:4px;border-radius:10pt;}
	table.vote,th.vote,td.vote{border-left:0px;border-top:0px;border-right:0px;border-bottom:0.5px dotted blue;}td{border:0px;}</style>
</head>
<body background="img/bg3.gif" onload="document.feerecs.TxtMiscFee.focus();">
	 <?php 
	 	print "<form method=\"post\" action=\"feereceipt.php\" name=\"feerecs\" onsubmit=\"if (submitting){feerecs.CmdSave.disabled=true; return false;} if (SaveFeeRecord(this)){
		feerecs.CmdSave.value='Please Wait'; return true;}else{return false;}\"><input type=\"hidden\" name=\"form_token\" value=\"$form_token\"><table cellpadding=\"1\" cellspacing=\"0\" 
		align=\"center\" style=\"border:1px dotted green;border-collapse:collapse;\"><tr><td>";	
		print "<table class=\"h\" align=\"center\"><tr><td style=\"font-weight:bold;font-size:12px;letter-spacing:3px;word-spacing:4px;
		color:#fff;background-color:#000;\" colspan=\"6\">OFFICIAL RECEIPT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".date("D d-M-Y")."</td></tr>";
		print "<tr><td align=\"right\"><b>Receipt No.</b></td><td><input type=\"text\" name=\"TxtRecNo\" size=\"12\" maxlength=\"5\" value=\"Auto\" readonly></td><td align=\"right\">
		Admission No.</td><td><Input name=\"TxtAdmNo\" id=\"TxtAdmNo\" size=\"7\" type=\"text\" readonly value=\"$data[0]-$info[1]\"></td><td align=\"right\">Fees Received On</td><td><input 
		type=\"text\" size=\"15\" name=\"DTPDate\" value=\"$curdate\" readonly></td></tr>";
		print "<tr><td align=\"right\">Received From</td><td colspan=\"5\" align=\"left\" style=\"font-weight:normal;font-size:12px; letter-spacing:4px;word-spacing:6px;\" 
		bgcolor=\"#eeeeee\">$data[1] - Class $data[3]</td></tr><tr><td align=\"right\">Fee Paid By</td><td><SELECT name=\"CboPaidBy\" size=\"1\"><Option selected>Parent</option><Option>
		Bursary</option><Option>Guardian</option><Option>Well Wisher</option></SELECT></td><td align=\"right\">Bursary No.</td><td><input type=\"text\" name=\"TxtBursNo\" value=\"\" 
		size=\"7\" maxlength=\"4\"></td><td colspan=\"2\">Bursary Balance to be Distributed <input type=\"text\" name=\"TxtBursBal\" size=\"8\" disabled value=\"0.00\" 
		style=\"text-align:right;\"></td></tr>";
		print "<tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td align=\"right\">Fees Received In</td><td><SELECT name=\"CboPytFrm\" id=\"CboPytFrm\" size=\"1\" onchange=\"checkPyt(this)\"><option selected>Cash</option><option>
		Cheque</option><option>Direct Banking</option><option>Kind</option><option>M-Fees</option><option>Money Order</option></SELECT></td><td align=\"right\">Trans/ Cheque No.</td><td>
		<input name=\"TxtCheNo\" id=\"TxtCheNo\" size=\"20\" maxlength=\"29\" readonly></td><td align=\"right\">Cheque's Banker</td><td><SELECT name=\"CboBank\" id=\"CboBank\" size=\"1\" 
		disabled><option selected>None</option><option>KCB</option><option>Barclays</option><option>CFC Stanbic</option><option>Cooperative</option><option>Equity</option><option>Family
		</option><option>Gulf Bank</option><option>National</option><option>NIC</option><option>Posta</option><option>Standard Chartered</option><option>DTB</option><option>Bank of Africa
		</option></SELECT></td></tr>";
		print "<tr><td align=\"right\">Description of Fee in Kind</td><td colspan=\"3\" align=\"left\"><input name=\"TxtKind\" id=\"TxtKind\" type=\"text\" size=\"57\" maxlength=\"50\" 
		readonly></td><td align=\"right\">Bank Charges</td><td><INPUT type=\"text\" name=\"TxtBC\" id=\"TxtBC\" size=\"14\" maxlength=\"11\" style=\"text-align:right;\" value=\"0.00\" 
		onkeyup=\"checkInput(this)\" onChange=\"ttlFees()\" readonly></td></tr><tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td align=\"right\">Main Account Fees</td><td><input type=\"text\" name=\"TxtMainFee\" id=\"TxtMainFee\" size=\"14\" maxlength=\"11\" style=\"text-align:right;\" 
		value=\"0.00\" onkeyup=\"checkInput(this)\" onblur=\"checkMainBal(s_cls,voteBal)\" onchange=\"ttlFees()\"></td><td align=\"right\">Misc A/C Fee</td><td><input type=\"text\" 
		name=\"TxtMiscFee\" id=\"TxtMiscFee\" size=\"13\" maxlength=\"10\" value=\"".number_format($balmisc,2)."\" style=\"text-align:right;\" onKeyUp=\"checkInput(this)\" 
		onchange=\"ttlFees()\" onblur=\"checkMiscBal(s_cls,miscBal)\"></td><td bgcolor=\"#eeeeee\" align=\"right\" colspan=\"2\"><b>Total Amount Received</b> <input type=\"text\" 
		name=\"TxtTtlFee\" id=\"TxtTtlFee\" size=\"13\" value=\"".number_format($balmisc,2)."\" disabled style=\"text-align:right;\"></td></tr><tr><td colspan=\"6\"><hr>";
		print "<table class=\"vote\" style=\"border-collapse:collapse;padding:1px;\" width=\"100%\"><tr style=\"letter-spacing:2px;word-spacing:3px;background-color:#555;color:#fff;\"><th 
		colspan=\"4\" class=\"vote\">
		MAIN ACCOUNT FEES</th><th class=\"vote\" rowspan=\"21\" bgcolor=\"#555555\">--</th><th class=\"vote\" colspan=\"3\">MISCELLANEOUS ACCOUNT FEES</th></tr><tr><th class=\"vote\" >
		</th><th class=\"vote\">Votehead</th><th class=\"vote\">Balance (Kshs.)</th><th class=\"vote\">Amount Paid (Kshs.)</th><th class=\"vote\">Votehead</th><th class=\"vote\">Balance 
		(Kshs.)</th><th class=\"vote\">Amount Paid (Kshs.)</th></tr>";
		print "<tr><td class=\"vote\">1.</td><td class=\"vote\">Tuition</td><td align=\"center\" class=\"vote\"><INPUT name=\"TxtBalTui\" type=\"text\" size=\"13\" disabled 
		style=\"text-align:right;border:0px;\" value=\"".number_format($data[58],2)."\" id=\"TxtBal10\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtTui\" type=\"text\" 
		size=\"13\" style=\"text-align:right;\" value=\"0.00\" id=\"TxtVal10\" onChange=\"ComputeVote()\" onkeyup=\"checkInput(this)\"></td><td class=\"vote\">ID Card</td><td class=\"vote\" 
		align=\"center\"><input name=\"TxtBalID\" type=\"text\" size=\"13\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($misc[26],2)."\" id=\"TxtMisBal0\"></td>
		<td align=\"center\" class=\"vote\"><input name=\"TxtMisID\" type=\"text\" size=\"13\" style=\"text-align:right;\" value=\"0.00\" id=\"TxtMisVal0\" onChange=\"misComputeVote()\" 
		onkeyup=\"checkInput(this)\"></td></tr>";
		print "<tr><td class=\"vote\">2.</td><td class=\"vote\">Boarding &amp; Meals</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalBoard\" type=\"text\" size=\"13\" 
		id=\"TxtBal1\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[49],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtBoard\" 
		type=\"text\" size=\"13\" id=\"TxtVal1\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Quality 
		Assurance</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalQA\" type=\"text\" size=\"13\" id=\"TxtMisBal1\" style=\"text-align:right;border:0px;\" disabled value=\"".
		number_format($misc[27],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtMisQA\" type=\"text\" size=\"13\" id=\"TxtMisVal1\" style=\"text-align:right;\" 
		value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">3.</td><td class=\"vote\">Activity</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalAct\" type=\"text\" size=\"13\" id=\"TxtBal2\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[50],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtAct\" type=\"text\" size=\"13\" 
		id=\"TxtVal2\" onkeyup=\"checkInput(this)\" style=\"text-align:right;\" value=\"0.00\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Remedial Studies</td><td 
		align=\"center\" class=\"vote\"><input name=\"TxtBalRem\" type=\"text\" size=\"13\" id=\"TxtMisBal2\" style=\"text-align:right;border:0px;\" disabled value=\"".
		number_format($misc[28],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtMisRem\" type=\"text\" size=\"13\" id=\"TxtMisVal2\" onkeyup=\"checkInput(this)\" 
		style=\"text-align:right;\" value=\"0.00\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">4.</td><td class=\"vote\">L . T &amp; T</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalLTT\" type=\"text\" size=\"13\" id=\"TxtBal4\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[52],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtLTT\" type=\"text\" size=\"13\" 
		id=\"TxtVal4\" onkeyup=\"checkInput(this)\" style=\"text-align:right;\" value=\"0.00\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Holiday Tuition</td><td align=\"center\" 
		class=\"vote\"><input name=\"TxtBalHT\" type=\"text\" size=\"13\" id=\"TxtMisBal3\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($misc[29],2)."\"></td>
		<td align=\"center\" class=\"vote\"><input name=\"TxtMisHT\" type=\"text\" size=\"13\" id=\"TxtMisVal3\" onkeyup=\"checkInput(this)\" style=\"text-align:right;\" value=\"0.00\" 
		onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">5.</td><td class=\"vote\">R . M . I</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalRMI\" type=\"text\" size=\"13\" id=\"TxtBal5\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[53],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtRMI\" type=\"text\" size=\"13\" 
		id=\"TxtVal5\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Graduation Fee</td><td align=\"center\" 
		class=\"vote\"><input name=\"TxtBalGrad\" type=\"text\" size=\"13\" id=\"TxtMisBal4\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($misc[30],2)."\">
		</td><td align=\"center\" class=\"vote\"><input name=\"TxtMisGrad\" type=\"text\" size=\"13\" id=\"TxtMisVal4\" style=\"text-align:right;\" value=\"0.00\" 
		onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">6.</td><td class=\"vote\">E . W . C</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalEWC\" type=\"text\" size=\"13\" id=\"TxtBal6\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[54],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtEWC\" type=\"text\" size=\"13\" 
		id=\"TxtVal6\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Academic Trip</td><td align=\"center\" 
		class=\"vote\"><input name=\"TxtBalTrip\" type=\"text\" size=\"13\" id=\"TxtMisBal5\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($misc[31],2)."\"></td>
		<td align=\"center\" class=\"vote\"><input name=\"TxtMisTrip\" type=\"text\" size=\"13\" id=\"TxtMisVal5\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" 
		onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">7.</td><td class=\"vote\">Examination</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalExam\" type=\"text\" size=\"13\" id=\"TxtBal11\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[59],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtExam\" type=\"text\" size=\"13\" 
		id=\"TxtVal11\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Uniform</td><td align=\"center\" 
		class=\"vote\"><input name=\"TxtBalUni\" type=\"text\" size=\"13\" id=\"TxtMisBal7\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($misc[1],2)."\"></td>
		<td align=\"center\" class=\"vote\"><input name=\"TxtMisUni\" type=\"text\" size=\"13\" id=\"TxtMisVal7\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" 
		onChange=\"misComputeVote()\" readonly></td></tr>";
		print "<tr><td class=\"vote\">8.</td><td class=\"vote\">Administrative Costs</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalAdmin\" type=\"text\" size=\"13\" 
		id=\"TxtBal7\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[55],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtAdmin\" 
		type=\"text\" size=\"13\" id=\"TxtVal7\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Misc. Arrears
		</td><td align=\"center\" class=\"vote\"><input name=\"TxtMisBalArr\" type=\"text\" size=\"13\" id=\"TxtMisBal8\" style=\"text-align:right;border:0px;\" disabled value=\"".
		number_format($misc[0],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtMisArr\" type=\"text\" size=\"13\" id=\"TxtMisVal8\" style=\"text-align:right;\" 
		value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\" readonly></td></tr>";
		print "<tr><td class=\"vote\">9.</td><td class=\"vote\">Library Fee</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalLib\" type=\"text\" size=\"13\" id=\"TxtBal8\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[56],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtLib\" type=\"text\" size=\"13\" 
		id=\"TxtVal8\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td><td class=\"vote\">Other Levies</td><td align=\"center\" 
		class=\"vote\"><input name=\"TxtMisBalOle\" type=\"text\" size=\"13\" id=\"TxtMisBal6\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($misc[32],2)."\">
		</td><td align=\"center\" class=\"vote\"><input name=\"TxtMisOle\" type=\"text\" size=\"13\" id=\"TxtMisVal6\" style=\"text-align:right;\" value=\"0.00\" 
		onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">10.</td><td class=\"vote\">Medical</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalMed\" type=\"text\" size=\"13\" id=\"TxtBal9\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[57],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtMed\" type=\"text\" size=\"13\" 
		id=\"TxtVal9\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td><td rowspan=\"8\" class=\"vote\"></td><td rowspan=\"8\" 
		class=\"vote\"></td><td rowspan=\"8\"></td></tr>";
		print "<tr><td class=\"vote\">11.</td><td class=\"vote\">Special Medical Fee</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalSpeMed\" type=\"text\" size=\"13\" 
		id=\"TxtBal14\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[4],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtSpeMed\" 
		type=\"text\" size=\"13\" id=\"TxtVal14\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\" readonly></td></tr>";
		print "<tr><td class=\"vote\">12.</td><td class=\"vote\">Transport</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalTrans\" type=\"text\" size=\"13\" id=\"TxtBal0\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[48],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtTrans\" type=\"text\" size=\"13\" 
		id=\"TxtVal0\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">13.</td><td class=\"vote\">Personal Emolument</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalPEM\" type=\"text\" size=\"13\" 
		id=\"TxtBal3\" style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[51],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtPEM\" 
		type=\"text\" size=\"13\" id=\"TxtVal3\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">14.</td><td class=\"vote\">Fee Arrears</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalArr\" type=\"text\" size=\"13\" id=\"TxtBal13\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[5],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtArr\" type=\"text\" size=\"13\" 
		id=\"TxtVal13\" style=\"text-align:right;\" value=\"0.00\" readonly></td></tr>";
		print "<tr><td class=\"vote\">15.</td><td class=\"vote\">Refunds</td><td class=\"vote\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtRef\" type=\"text\" size=\"13\" 
		id=\"TxtVal15\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\" ".(strcasecmp($data[2],"eight")==0?"readnonly":"")."></td></tr>";
		print "<tr><td class=\"vote\">16.</td><td class=\"vote\">Prepayments</td><td class=\"vote\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtPrep\" type=\"text\" 
		size=\"13\" id=\"TxtVal16\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td></tr>";
		print "<tr><td class=\"vote\">17.</td><td class=\"vote\">Other Levies</td><td align=\"center\" class=\"vote\"><input name=\"TxtBalOle\" type=\"text\" size=\"13\" id=\"TxtBal12\" 
		style=\"text-align:right;border:0px;\" disabled value=\"".number_format($data[60],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtOle\" type=\"text\" size=\"13\" 
		id=\"TxtVal12\" style=\"text-align:right;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"ComputeVote()\"></td></tr>";
		print "<tr><td colspan=\"2\" class=\"vote\"><b>Total Amount (Kshs.)</b></td><td align=\"center\" class=\"vote\"><input name=\"TxtBal\" type=\"text\" size=\"13\" id=\"TxtBal\" 
		style=\"text-align:right;border:0px;font-weight:bold;\" disabled value=\"".number_format($data[61],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtTtl\" 
		type=\"text\" size=\"13\" id=\"TxtTtl\" style=\"text-align:right;border:0px;font-weight:bold;\" value=\"0.00\" readonly></td><td class=\"vote\"><b>Total Amount</b></td><td 
		align=\"center\" class=\"vote\"><input name=\"TxtMisBal\" type=\"text\" size=\"13\" id=\"TxtMisBal\" style=\"text-align:right;border:0px;font-weight:bold;\" disabled value=\"".
		number_format($misc[33],2)."\"></td><td align=\"center\" class=\"vote\"><input name=\"TxtMisTtl\" type=\"text\" size=\"13\" id=\"TxtMisTtl\" style=\"text-align:right;border:0px;
		font-weight:bold;\" value=\"0.00\" readonly></td></tr>";
		print "<tr style=\"letter-spacing:2px;word-spacing:3px;background-color:#555;color:#fff;\"><td colspan=\"4\" align=\"center\" class=\"vote\">Balance To Be Distributed: <input 
		type=\"text\" name=\"TxtVoteBal\" id=\"TxtVoteBal\" size=\"13\" value=\"0.00\" style=\"text-align:right;font-weight:bold;background-color:#555;color:#fff;\" readonly></td><td 
		colspan=\"3\" align=\"center\" class=\"vote\">Balance To Be Distributed: <input type=\"text\" name=\"TxtMisVoteBal\" id=\"TxtMisVoteBal\" size=\"13\" value=\"0.00\" 
		style=\"text-align:right;font-weight:bold;background-color:#555;color:#fff;\" readonly></td></tr></table></td></tr></table>";
		print "</td></tr>";
		print"<tr><td align=\"right\" valign=\"top\" style=\"color:#AA0000;font-weight:bold;\">Fees Paid in Words <TEXTAREA name=\"TxtWords\" id=\"TxtWords\" 
		cols=\"75\" rows=\"2\" style=\"border:0px;font-weight:bold;color:#AA0000;\" readonly value=\"0.00\">Zero Shillings and Zero Cents</textarea></td></tr>";
		print "<tr><td><center><hr><button type=\"submit\" name=\"CmdSave\" id=\"CmdSave\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Save Fee Record&nbsp;&nbsp;&nbsp;&nbsp;</button>&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"studfee.php\" target=\"det\"><button type=\"button\" name=\"close\">&nbsp;&nbsp;&nbsp;&nbsp;Cancel/ Close&nbsp;&nbsp;&nbsp;&nbsp;</button></a>
		</center></td></tr></table>";
	?>
	</form>
</body>
</html>
<?php
	mysqli_close($conn);
?>