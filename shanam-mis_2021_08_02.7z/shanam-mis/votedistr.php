<?php
	include_once('shanam.php');	$action=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; $action=explode('-',$action);
	$acno=isset($_REQUEST['cboAC'])?$_REQUEST['cboAC']:1;	  $task=isset($_REQUEST['task'])?$_REQUEST['task']:"1000-0";	$task=explode('-',$task);$acname='';
	mysqli_multi_query($conn,"SELECT finyr FROM ss; SELECT feetrans FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT acno,descr FROM acc_voteacs WHERE stud_assoc=1;"); $optac=""; $i=0;
	do{if($rs=mysqli_store_result($conn)){if($i==0) list($cuyr)=mysqli_fetch_row($rs); elseif($i==1) list($feetr)=mysqli_fetch_row($rs); else{while($d=mysqli_fetch_row($rs)){ $optac.="<option value=\"$d[0]\" ".
		($d[0]==$acno?"SELECTED":"").">$d[1]</option>"; if($d[0]==$acno) $acname=strtoupper($d[1]);}} mysqli_free_result($rs);} $i++;
	}while(mysqli_next_result($conn)); if ($feetr==0) header("Location:vague.php");
	headings('<link href="tpl/css/headers.css" rel="stylesheet"/><link href="tpl/css/inputsettings.css" rel="stylesheet" />',$action[0],$action[1],2);
?><div class="head"><form method="post" action="votedistr.php"><a href="pupil_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;View <SELECT name="cboAC" id="cboAC"
	size="1"><?php echo $optac;?></SELECT> Students with  <button type="submit" accesskey="m" name="btnOvervotehead">Fee <b>V</b>otehead Anomalies</button> &nbsp;&nbsp; or &nbsp;&nbsp; <button type="submit" name="btnShow">
	Show All Students</button></form>
</div><div class="container divmain">
<?php
if(isset($_POST['btnOvervotehead'])){
    $sql="SELECT DISTINCT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',cl.stream) As cls FROM stud s Inner Join class cl USING (admno,curr_year) Inner	Join classnames cn USING (clsno) Inner Join
    clsfee c USING (admno,curr_year) Inner Join ss ON (s.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,f.acc,v.voteno,sum(v.amt) as ttl FROM acc_incofee i Inner Join ".($acno==1?"acc_incorecno0":"acc_incorecno1")." f USING
    (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY i.admno,f.acc,v.voteno,i.markdel HAVING markdel=0 and f.acc LIKE '$acno')f USING (admno,voteno) GROUP BY s.admno,s.curr_year,s.surname,s.onames,cn.clsname,
    cl.stream,c.voteno,c.t1,c.t2,c.t3 HAVING if((c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl))))<0 or (if((c.t2-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0, 0,(c.t2-
    if(isnull(sum(f.ttl)),0,sum(f.ttl))))-if((c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t1-if(isnull(sum(f.ttl)),0,sum(f.ttl)))))<0 or (if((c.t3-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t3-if(isnull(sum(f.ttl))
    ,0,sum(f.ttl))))-if((c.t2-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t2-if(isnull(sum(f.ttl)),0,sum(f.ttl)))))<0";
    $rsStud=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"home.php\">HERE</a> to go back.");
    echo "<h5 style=\"letter-spacing:1px;font-size:12pt;word-spacing:2px;\">LIST OF STUDENTS WITH $acname VOTEHEAD DISTRIBUTION ANOMALIES</h5>";
    echo '<div class=\"form-row\"><div class=\"col-md-12\" style="background:inherit;border:0.5px dotted green;border-radius:10px;padding:6px;"><form name="frmFindOver" action="#">Find Student By &nbsp;<input type="radio"
    name="radFind1" id="radAdmNo1" value="admno" onclick="clrText()">Adm. No.&nbsp;<input type="radio" name="radFind1" id="radNEMISNo1" value="nemisno" onclick="clrText()">NEMIS No.&nbsp; <input type="radio" name="radFind"
    id="radName1" value="st_names" checked onclick="clrText()">Names &nbsp;&nbsp; <input type="text" maxlength="17" placeholder="Type/ Enter what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;"
    name="txtFind1" id="txtFind1" value="" onkeyup="myFunction()" size="30"></form></div></div>';
    echo '<div class="form-row"><div class="col-md-12" style="max-height:700px;overflow-y:scroll;"><table class="table table-sm table-bordered table-hover"><thead class="thead-dark"><tr><th>#</th><th>ADM. NO.</th><th>NAMES
    </th><th>FORM/GARDE</th><th>FEE PAID</th></tr></THEAD><tbody>'; $i=1;
    if(mysqli_num_rows($rsStud)){
        while (list($admno,$names,$cls)=mysqli_fetch_row($rsStud)){
            echo "<tr><td>$i.</td><td>$admno</td><td>$names</td><td>$cls</td><td style=\"text-align:center\"><a href=\"votedistr.php?task=0-$acno-$admno</td></tr>"; $i++;
        }
    }else echo "<tr><td colspan=\"5\">NO STUDENTS WITH FEE DISTRIBUTION ANOMALIES</td></tr>"; echo "</tbody></table></div></div>";
}elseif ($task[0]==0){
	$rsStud=mysqli_query($conn,"SELECT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',cl.stream) As cls FROM stud s Inner Join class cl USING (admno,curr_year) Inner	Join classnames cn USING (clsno)
	WHERE s.admno LIKE '$task[2]'") or die(mysqli_error($conn).". 1. Click <a href=\"home.php\">HERE</a> to go back.");
	if (mysqli_num_rows($rsStud)>0){	list($admno,$names,$cls)=mysqli_fetch_row($rsStud);
		$rs=mysqli_query($conn,"SELECT v.sno,v.abbr FROM clsfee f Inner Join acc_votes v ON (f.voteno=v.sno) Inner Join ss s ON (f.curr_year=s.finyr) WHERE f.admno='$task[2]' and v.acc='$task[1]' ORDER BY v.sno ASC;");
		$f=$paid=$cols=''; $novotes=0;
		while ($row=mysqli_fetch_row($rs)){
			$f.=",SUM(IF(voteno='$row[0]',f.t3,0)) as `$row[1]`"; $paid.=",SUM(IF(v.voteno='$row[0]',v.amt,0)) as `$row[1]`"; $cols.='<th class="s">'.$row[1].'</th>'; $novotes++;
		}mysqli_free_result($rs); $sql="SELECT admno $f FROM clsfee f Inner Join ss s ON (f.curr_year=s.finyr) Inner Join acc_votes v ON (f.voteno=v.sno) GROUP BY f.admno,f.curr_year,v.acc HAVING f.admno LIKE
		'$task[2]' and v.acc LIKE	'$task[1]'"; $start=($task[1]==1?7:5); $novotes+=($task[1]==1?3:1);
		$rs=mysqli_query($conn,$sql) or die(mysqli_error($conn).". 2. Click <a href=\"home.php\">HERE</a> to go back."); $fee=mysqli_fetch_row($rs); mysqli_free_result($rs);
		print "<h4 style=\"letter-spacing:1px;font-size:12pt;word-spacing:2px;font-weight:bold;\">Adm. No. $admno - <u>$names</u>	in Form/Grade $cls</h4><table class=\"table table-sm table-bordered table-hover\"><thead
		class=\"thead-dark\"><tr><th colspan=\"3\">DETAILS OF FEE PAYMENT</th><th rowspan=\"2\">AMOUNT<br>RECIEVED</th><th colspan=\"$novotes\">DISTRIBUTION OF FEE RECEIPT TO RESPECTIVE VOTEHEADS</th><th></th></tr><tr><th>
		RECEIPT</th><th>DATE</th><th>MODE</th><th>ARREARS</th>".($task[1]==1?"<th>REFUNDS</th><th>PREPAID</th>":"")."$cols<th>ACTION</th></tr><tr style=\"text-align:rigth\"><th colspan=\"4\" class=\"r\">EXPECTED FEES PER
		VOTEHEAD</th><th>-</th>".($task[1]==1?"<th>-</th><th>-</th>":""); if($task[1]==1) $ttl=$bal=[0,0,0,0]; else $ttl=$bal=[0,0]; $i=0;
		foreach($fee as $amt){if($i>0){print "<th class=\"r b\">".number_format($amt,2)."</th>"; $bal[]=$amt; $ttl[]=0;}$i++;} print "<th></th></tr></thead><tbody>";
		$sql="SELECT f.recno,i.pytdate,i.pytfrm,f.amt,f.arrears".($task[1]==1?",f.refunds,f.prep":"")." $paid FROM acc_incofee i Inner Join ".($task[1]==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join
		acc_incovotes v	USING (recno,acc) GROUP BY f.recno,i.pytdate,i.pytfrm,i.markdel,i.admno,v.acc HAVING v.acc LIKE '$task[1]' and i.markdel=0 and i.admno LIKE '$admno' ORDER BY f.recno ASC";
		$rs=mysqli_query($conn,$sql) or die(mysqli_error($conn)." .3. Click <a href=\"home.php\">HERE</a> to go back."); $nof=mysqli_num_rows($rs);
		if($nof>0){$lp=$start-($task[1]==1?4:2); while($da=mysqli_fetch_row($rs)){$i=$a=$b=0; print "<tr>";
			foreach($da as $rec){
				if($i<$start){if($i==1){print "<td class=\"r\">".date('d-M-Y',strtotime($rec))."</td>";}elseif($i<3){print "<td>$rec</td>"; if($i==0)$recno=$rec;}else{print "<td class=\"s r\">".number_format($rec,2)."</td>";
				$ttl[$i-3]+=$rec;} }else{print "<td class=\"s r\">".number_format($rec,2)."</td>";	$bal[$i-$lp]-=$rec;	$ttl[$i-$lp]+=$rec;}	$i++;
			}print "<td class=\"c\"><a href=\"votedistredit.php?rec=$task[1]-$recno-$task[2]-3\">Redistribute</a></td></tr>";}
		}else print "<tr><td colspan=15>THE STUDENT HAS NOT PAID ANY FEES</td></tr>";
		print "<tfoot class=\"thead-light\"><tr><th colspan=\"3\" class=\"r\">FEES PAID PER VOTEHEAD</th>"; foreach($ttl as $amt) print "<th class=\"r b\">".number_format($amt,2)."</th>";
		print "<th></th></tr><tr style=\"text-align:rigth\"><th colspan=\"$start\" class=\"r\">BALANCE PER VOTEHEAD</th>"; $i=0; $lp=($task[1]==1?3:1);
		foreach($bal as $amt){if($i>$lp) print "<th class=\"r b\">".number_format($amt,2)."</th>"; $i++;}print "<th></th></tr></tfoot></table>";
	}
}else{
	print "<center><h3>List Of Students Meeting the Search Criteria</h3></center>";
	$sql="SELECT s.admno,s.nemisno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,l.lvlname FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING
	(clsno) Inner Join classlvl l ON (c.lvlno=l.lvlno) WHERE (s.markdel=0 and s.type=0 AND s.present=1 And s.curr_year LIKE '$cuyr') Order By s.surname,s.onames Asc"; $rs=mysqli_query($conn,$sql);
	if (mysqli_num_rows($rs)>0){
		echo '<div style="background:inherit;border:0.5px dotted green;border-radius:10px;padding:6px;"><form name="frmFind" action="#">Find Student By &nbsp;<input type="radio" name="radFind" id="radAdmNo"
    value="admno" onclick="clrText()">Adm. No.&nbsp;<input type="radio" name="radFind" id="radNEMISNo" value="nemisno" onclick="clrText()">NEMIS No.&nbsp; <input type="radio" name="radFind" id="radName" value="st_names"
    checked onclick="clrText()">Names &nbsp;&nbsp; <input type="text" maxlength="17" size="30" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Type/ Enter what to Find" style="border:0px;
    border-bottom:1px solid blue;color:#00d;"></form></div>';
		echo "<div class=\"form-row\"><div class=\"col-md-12\" style=\"max-height:700px;overflow-y:scroll;\"><table class=\"table table-bordered table-sm table-hover table-striped\"id=\"tblStud\"><tr style=\"font-weight:bold;
		text-align:center;letter-spacing:3px;word-spacing:5px;\"><th colspan=\"6\">DETAIL OF STUDENTS</th><th rowspan=\"2\">FEE <BR>RECORDS</th></tr><tr><th>#</th><th>ADM. NO.</th><th>NEMIS NO.</th><th>NAMES</th><th>
		FORM/GRADE</th><th>CATEGORY</th></tr>"; $i=1;
		while (list($ad,$nn,$sn,$fr,$stgr)=mysqli_fetch_row($rs)){echo "<tr><td align=\"center\">$i</td><td>$ad<td>$nn</td><td>$sn</td><td>$fr</td><td>$stgr</td><td align=\"center\"><a href=\"votedistr.php?task=0-$acno-$ad\">
			Show</a></td></tr>"; $i++;} echo "</table>";
	}else{if (strcasecmp($search,"admno")==0) echo "Sorry, No student has the admission number $adm"; else echo "Sorry, there is no student with the name $adm";} echo "</div></div>";	mysqli_free_result($rs);
} echo "</div>";
mysqli_close($conn); footer();
?><script type="text/javascript" src="tpl/js/votedistr.js"></script>
