<?php
    include_once('shanam.php');
    if (isset($_POST['CmdAdd'])) header("Location:stfadd.php");
    $sg=isset($_POST['CboSg'])?sanitize($_POST['CboSg']):"%"; 	$et=isset($_POST['CboEmpType'])?sanitize($_POST['CboEmpType']):"1";
    $act=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0';			$act=preg_split('/\-/',$act);
    $rsStf=mysqli_query($conn, "SELECT stfview,stfadd,stfedit FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'");
    $stfviu=0;	$stfad=0; 	$stfed=0;
    if(mysqli_num_rows($rsStf)==1) list($stfviu,$stfad,$stfed)=mysqli_fetch_row($rsStf);	mysqli_free_result($rsStf);
    if($stfviu==0) header("Location:vague.php");
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css" />',$act[0],$act[1],2);
?><div class="head">
<form method="post" action="stf.php" name="frmShow"><a href="stf_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;View <select
name="CboEmpType" size="1" id="et"><option selected value="1">Current</option><option value="0">Old</Option></select> Members of Staff Belonging to <select name="CboSg" size="1"
id ="sg"><option selected value="%">All</option>
<?php
	$rs=mysqli_query($conn,"SELECT staff FROM grps WHERE staff is not null") or die(mysqli_error($conn)." Can't load staff groups.");
	if (mysqli_num_rows($rs)>0) while (list($strm)=mysqli_fetch_row($rs)) print "<option>".$strm."</option>"; mysqli_free_result($rs);
?>
</select> Categories &nbsp;&nbsp;&nbsp;<button type="submit" name="Staff">Show Staff Details</button>&nbsp;&nbsp;or &nbsp;&nbsp;<button type="submit" name="CmdAdd">Register Staff
Member</button></form></div>
<?php
	$h=trim($et)=="1"?"Current ":"old ";	$h=$h." ".(trim($sg)=="%" ? "" : trim($sg));
	$h= trim($h)." Members of Staff' Details Report";
	print "<h3 style=\"font-size:12pt;color:#fff;text-decoration:underline overline double #fff;letter-spacing:3px;word-spacing:4px;text-align:center;\">".strtoupper($h)."</h3>";
	if ($et==1) $sql="SELECT s.idno,concat(s.surname,' ',s.onames) as st_names,s.gender,s.pin,s.telno,concat(c.name,' COUNTY, ',co.name,' CONSTITUENCY, ',w.name,' WARD') as home,
	s.empdate,s.designation FROM stf s INNER Join county c on (s.countyno=c.code) Inner Join constituency co On (s.constituencyno=co.code) Inner Join ward w on (s.wardno=w.code) WHERE
	(s.Markdel=0 and s.present=1 and s.staffgrp like '$sg') Order By s.surname,s.onames Asc";
	else $sql="SELECT s.idno,concat(s.surname,' ',s.onames) as st_names,s.gender,s.pin,s.telno,concat(c.name,' COUNTY, ',co.name,' CONSTITUENCY, ',w.name,' WARD') as home,s.empdate,
	s.designation FROM stf s INNER Join county c on (s.countyno=c.code) Inner Join constituency co On (s.constituencyno=co.code) Inner Join ward w on (s.wardno=w.code) WHERE (s.Markdel=1 or
	s.present=0) and s.staffgrp like '$sg' Order By s.surname,s.onames Asc";
	$rs=mysqli_query($conn,$sql);
	print "<div class=\"container\" style=\"border:1px groove #fff;border-radius:15px;padding:0 10px;margin:auto;width:1000px;background-color:#e6e6e6;font-size:0.8rem;\">
  <div class=\"row\"><div class=\"col-md-12\" style=\"border:0.5px dotted green;border-radius:10px;padding:6px;\"><form name=\"frmFind\" action=\"stf.php\"method=\"post\">Find Staff By&nbsp;
  <input type=\"radio\" name=\"radFind\" id=\"radIDNo\" value=\"idno\" onclick=\"clrText()\">ID No.&nbsp; <input type=\"radio\" name=\"radFind\" id=\"radName\" value=\"st_names\" checked
  onclick=\"clrText()\">Names &nbsp; <input type=\"radio\" name=\"radFind\" id=\"radGender\" value=\"gender\" onclick=\"clrText()\">Gender &nbsp; <input type=\"radio\" name=\"radFind\"
  id=\"radDesign\" value=\"designation\" onclick=\"clrText()\">Designation &nbsp; <input type=\"text\" maxlength=\"17\" size=\"30\" name=\"txtFind\" id=\"txtFind\" value=\"\"
  onkeyup=\"myFunction()\" placeholder=\"Type/ Enter what to Find\" style=\"border:0px;border-bottom:1px solid blue;color:#00d;\"></form></div></div>";
	print "<div class=\"row\"><div class=\"col-md-12\" style=\"border:1px Solid #fff;border-radius:10px;padding:6px;display:block;max-height:600px;overflow-y:scroll;padding:5px;
  max-width:1050px;\"><table class=\"table table-striped table-hover table-sm table-bordered\" id=\"myTable\"><thead class=\"thead-dark\"<tr><th>ID. No.</th><th>Names</th><th>Gender</th>
  <th>KRA PIN No.</th><th>Tel. No.</th><th>Home Details</th><th>Employed On</th><th>Designation</th><th>Action</th></tr></thead></tbody>";		$i=0;
	if (mysqli_num_rows($rs)>0):
		while ($rsS=mysqli_fetch_array($rs,MYSQLI_ASSOC)):
			print "<tr>";		$a=0;
			foreach($rsS as $sr){
			 	if ($a==0) $idno=$sr; if ($a==6) $sr=date("D, d-M-Y",strtotime($sr));
				if ($a<8) print "<td>".$sr."</td>"; else $def=$sr;
				$a++;
			}	print "<td align=\"center\" valign=\"middle\"><a href=\"stfedit.php?idno=$idno\">Edit</a></td></tr>";
			$i++;
		endwhile;
	else:
		print "<tr bgcolor=\"#eaa\"><td colspan=\"9\" align=\"left\" class=\"b\">No Staff Details' Records Exist</td></tr>";
	endif;
	print "</tbody></table></div></div><div class=\"row\"><div class=\"col-md-6\" style=\"font-weight:bold;\" id=\"spTotal\">".mysqli_num_rows($rs)." Staff Details' Record(s)'</div><div
  class=\"col-md-6\" style=\"text-align:right\"><a href=\"stf_manager.php\"><button type=\"button\" name=\"btnclose\" class=\"btn btn-info btn-md\">Close</button></a></div></div></div>";
	mysqli_free_result($rs);
?>
<script type="text/javascript" src="tpl/js/stf-find.js"></script>
<?php mysqli_close($conn); footer();?>
