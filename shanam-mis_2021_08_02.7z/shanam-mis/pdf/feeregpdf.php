<?php
	include_once('../../conn/pri_sch_connect.inc'); 	include_once('tcpdf_include.php'); $rec=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):'0-0-0'; $rec=explode('-',$rec);
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);	$pdf->SetCreator(PDF_CREATOR); 		$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('Fee Notices');			$pdf->SetSubject('Fee Notices');	$pdf->SetKeywords('Shanam, Digital, SOlutions, Fee Notices');
	$pdf->setFooterData(array(0,64,0), array(0,64,128)); 	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER); $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM); $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {require_once(dirname(__FILE__).'/lang/eng.php');	$pdf->setLanguageArray($l);	}
	// set default font subsetting mode
	$pdf->setFontSubsetting(true); $pdf->AddPage("L");
	mysqli_multi_query($conn,"SELECT finyr,scnm,scadd,motto FROM ss;SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0 and acno LIKE '$rec[3]'");
	$i=0; $accname="";
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){if(mysqli_num_rows($rs)==1) list($yr,$scnm,$scadd,$mot)=mysqli_fetch_row($rs); else $yr=date('Y');}
			else list($acc,$accname)=mysqli_fetch_row($rs);mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	//Query balances
	$sql="SELECT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,";
	if ($acc==1) $sql.="(c.bbf+if(isnull(f.arr),0,f.arr)) as arr,if(x.acspemed=1,(c.spemed+if(isnull(f.smed),0,f.smed)),0) as spemed,if(x.acunifrm=1,(c.unifrm+if(isnull(f.suni),0,f.suni)),
		0)	as uni FROM stud s Inner Join class c USING (admno,curr_year) Inner	Join classnames cn USING (clsno) Inner Join ss ON (s.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,
		sum(f.arrears) as arr,sum(f.spemed) as smed,sum(f.unifrm) as suni FROM acc_incofee i Inner Join acc_incorecno0 f ";
	else $sql.="(c.miscbf+if(isnull(f.arr),0,f.arr)) as arr,if(x.acspemed!=1,(c.spemed+if(isnull(f.smed),0,f.smed)),0) as spemed,if(x.acunifrm!=1,(c.unifrm+if(isnull(f.suni),0,f.suni)),0)
		as uni FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) Inner Join ss ON (s.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,sum(f.arrears)
		as arr,sum(f.spemed) as smed, sum(f.unifrm)	as suni FROM acc_incofee i Inner Join acc_incorecno1 f ";
	if(strcasecmp($rec[2],"%")==0)$sql.="USING (sno) GROUP BY i.admno,f.markdel Having f.markdel LIKE '0')f USING (admno),(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,
	sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM acc_votesassigned)x WHERE c.clsno LIKE '$rec[0]' and c.stream LIKE '$rec[1]' and s.present=1";
	else $sql.="USING (sno) GROUP BY i.admno,f.markdel Having i.admno LIKE '$rec[2]' and f.markdel LIKE '0')f USING (admno),(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,
	sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM acc_votesassigned)x WHERE s.admno LIKE '$rec[2]' and s.present=1";
	$rsStud=mysqli_query($conn,$sql);
	$html='<style>table.h{border:0.1px dotted #fff;page-break-inside:avoid;font-size:10pt;table-layout:fixed}td.h{border:0.1px dotted #fff;}th.h{border:0.1px dotted #fff;font-size:11pt;
	font-weight:bold;}table.s{border:1px solid #00f;word-wrap:break-word;font-size:7pt}td.s{border:1px solid #00f;}th.s{border:1px solid #00f;font-weight:bold;}
	td.r,th.r{text-align:right}td.b{font-weight:bold;}</style>';
	if (mysqli_num_rows($rsStud)>0){
		while (list($admno,$names,$cls,$arr,$spemed,$uni)=mysqli_fetch_row($rsStud)){
			$rs=mysqli_query($conn,"SELECT v.sno,v.abbr FROM clsfee f Inner Join acc_votes v ON (f.voteno=v.sno) Inner Join ss s ON (f.curr_year=s.finyr) WHERE f.admno='$admno' and v.acc='$acc'
			ORDER BY v.sno ASC;"); $f=$paid=$cols=''; $novotes=$i=0;
			while ($row=mysqli_fetch_row($rs)){
				$f.= ",SUM(IF(voteno='$row[0]', f.t3, 0)) as `$row[1]` "; $paid.= ",SUM(IF(v.voteno='$row[0]', v.amt, 0)) as `{$row[1]}` ";
				$cols.='<th class="s" width="'.($i==0?55:45).'">'.$row[1].'</th>';
				$ttl[]=0; $bal[]=0; $novotes++; $i++;
			}mysqli_free_result($rs); $rs=mysqli_query($conn,"SELECT admno $f FROM clsfee f Inner Join ss s ON (f.curr_year=s.finyr) GROUP BY admno,curr_year HAVING f.admno LIKE '$admno'");
			$fee=mysqli_fetch_row($rs); mysqli_free_result($rs);
			$html.="<table width=\"980\" class=\"h\"><tr><th rowspan=\"3\"	valign=\"middle\" width=\"80\" class=\"h\"  style=\"border-bottom:2px solid #000\"><img	src=\"/gen_img/logo.jpg\"
			width=\"50\" height=\"55\" vspace=\"1\" hspace=\"1\"></th><th	style=\"font-size:12pt;text-align:left;\" class=\"h\" colspan=2 width=\"910\">$scnm</th></tr><tr><th width=\"910\"
			style=\"font-size:12pt;text-align:left;\" class=\"h\" colspan=2>$scadd</th></tr><tr><th	class=\"h\"  width=\"730\" style=\"font-size:12px;border-bottom:2px solid #000;
			text-align:left;\">$accname FEES REGISTER</th><th class=\"h\" style=\"font-size:10px;border-bottom:2px solid #000;text-align:right;\" width=\"180\">Printed On ".date("D d M,Y").
			"</th></tr><tr><td colspan=\"3\" width=\"980\"><p style=\"letter-spacing:1px;font-size:12pt;word-spacing:2px;font-weight:bold;\">Adm. No. $admno - <u>$names</u>	in Form/Grade
			$cls. <u><i>Fee Register As On ".date('D d M,Y')."</i></u></p>";
			$html.="<table class=\"s\"><thead><tr><th class=\"s\"  width=\"50\">RECEIPT</th><th class=\"s\" width=\"53\">DATE</th><th class=\"s\" width=\"55\">MODE</th><th class=\"s\"
			width=\"57\">MODE NO.</th><th width=\"55\" class=\"s\">ARREARS</th>".($spemed>0?"<th width=\"50\" class=\"s\">S/ MED</th>":"").($uni>0?"<th class=\"s\" width=\"50\">
			X UNIFORM</th>":"").$cols.($acc==1?"<th class=\"s\" width=\"50\">PREPAID</th><th class=\"s\" width=\"50\">REFUNDS</th>":"")."<th class=\"s\" width=\"33\">BC</th><th class=\"s\"
			width=\"55\">TOTAL</th><th class=\"s\" width=\"55\">Balance</th></tr></thead>";
			$html.="<tr><td colspan=\"4\" class=\"s r b\">Fees Expected As On 01, January $yr</td><td class=\"s r b\">".number_format($arr,2)."</td>".($spemed>0?("<td class=\"s r b\">".
			number_format($spemed,2)."</td>"):"").($uni>0?("<td class=\"s r b\">".number_format($uni,2)."</td>"):""); $i=0; $ttlfee=$arr+$spemed+$uni;
			foreach($fee as $amt){if($i>0){$html.="<td class=\"s r b\">".number_format($amt,2)."</td>"; $bal[$i-1]=$amt; $ttlfee+=$amt;}$i++;}
			if($acc==1) $html.="<td class=\"r s b\">0.00</td><td class=\"r s b\">0.00</td>";
			$html.="<td class=\"r s b\">0.00</td><td class=\"s r b\">".number_format($ttlfee,2)."</td><td class=\"s r b\">".number_format($ttlfee,2)."</td></tr>";
			$sql="SELECT f.recno,i.pytdate,i.pytfrm,i.cheno,f.arrears,f.spemed,f.unifrm $paid,";
			if($acc==1) $sql.="f.prep,f.refunds,f.bc,(f.amt-f.transfer) as ttl FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY
			f.recno,i.pytdate,i.pytfrm,i.cheno,f.arrears,f.spemed,f.unifrm,f.amt,f.transfer,f.prep,f.refunds,i.markdel,i.admno ";
			else $sql="f.bc,(f.amt-f.transfer) as ttl FROM acc_incofee i Inner Join acc_incorecno1 f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY f.recno,i.pytdate,i.pytfrm,
			i.cheno,f.arrears,f.spemed,f.unifrm,f.amt,f.transfer,i.markdel,i.admno ";
			$sql.="HAVING i.markdel=0 and i.admno LIKE '$admno' ORDER BY f.recno ASC";
			$rs=mysqli_query($conn,$sql);$tarr=$tprep=$tref=$tuni=$tsmed=$tpaid=$tbc=0; $nof=mysqli_num_rows($rs);
			if($nof>0){while($da=mysqli_fetch_row($rs)){$i=$a=$b=0; $html.="<tr>";
				foreach($da as $rec){
					if($i<5){if($i==1){$html.="<td class=\"r s\">".date('d-m-Y',strtotime($rec))."</td>";}
					elseif($i==4){$html.="<td class=\"s r\">".number_format($rec,2)."</td>";$arr-=$rec; $tarr+=$rec;}		else $html.="<td class=\"s\">$rec</td>";
					}elseif($i<7){if($i==5 && $spemed>0){$html.="<td class=\"s r\">".number_format($rec,2)."</td>";$spemed-=$rec; $tsmed+=$rec;}
						elseif($i==6 && $uni>0){$html.="<td class=\"s r\">".number_format($rec,2)."</td>";$uni-=$rec; $tuni+=$rec;}
					}else{if($i<($novotes+7)){ $html.="<td class=\"s r\">".number_format($rec,2)."</td>";$bal[$i-7]-=$rec;$ttl[$i-7]+=$rec;
						}else{if($acc==1 && $i<($novotes+2)){$html.="<td class=\"s r\">".number_format($rec,2)."</td>"; if($a==0) $prep+=$rec; else $ref+=$rec; $a++;}
						else{$html.="<td class=\"s r b\">".number_format($rec,2)."</td>"; if($b==0)$tbc+=$rec; else $ttlfee-=$rec; $tpaid+=$rec; $b++;}}
					}	$i++;
				}$html.="<td class=\"s r b\">".number_format($ttlfee,2)."</td></tr>";}
			}else	$html.="<tr><td class=\"s b\" colspan=\"".($acc==1?($novotes+8):($novotes+6))."\">This student has not paid fee this year</td></tr>";
			$html.="<tr><td class=\"s b\" colspan=\"3\">$nof Fee Payment Installment(s)</td><td class=\"b r s\">Total Paid</td><td class=\"s r b\">".number_format($tarr,2)."</td>";
			if($tsmed>0 || $spemed>0) $html.="<td class=\"s r b\">".number_format($tsmed,2)."</td>"; if($tuni>0 || $uni>0) print "<td class=\"s r b\">".number_format($tuni,2)."</td>";
			foreach($ttl as $tt) $html.="<td class=\"s r b\">".number_format($tt,2)."</td>";
			if($acc==1) $html.="<td class=\"s r b\">".number_format($tprep,2)."</td><td class=\"s r b\">".number_format($tref,2)."</td>";
			$html.="<td class=\"s r b\">".number_format($tbc,2)."</td><td class=\"s r b\">".number_format($tpaid,2)."</td><td class=\"s r b\">".number_format($ttlfee,2)."</td></tr><tr><td
			class=\"s r b\" colspan=\"4\">Fee Balance</td><td	class=\"s r b\">".number_format($arr,2)."</td>";
			if($tsmed>0 || $spemed>0) $html.="<td class=\"s r b\">".number_format($spemed,2)."</td>"; if($tuni>0 || $uni>0) print "<td class=\"s r b\">".number_format($uni,2)."</td>";
			foreach($bal as $tt) $html.="<td class=\"s r b\">".number_format($tt,2)."</td>";
			$html.="<td class=\"s\" colspan=\"".($acc==1?5:3)."\"></td></tr></table></td></tr></table>"; mysqli_free_result($rs); unset($ttl);unset($bal);
			$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
		}
	} mysqli_free_result($rsStud);  //Display data
	$pdf->Output("feeregister.pdf","I");
	mysqli_close($conn);
?>
