<?php
    include_once('../../conn/pri_sch_connect.inc');include_once('tcpdf_include.php');include_once('../tpl/printing.tpl');
    $dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"10-0-0"; 	$dat=preg_split("/\-/",$dat);	//[0] 0 -payroll 1- payslip, [1] salno and [2] staff group
    if($dat[0]==1) $pdf = new TCPDF("L", PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    else $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $pdf->SetCreator(PDF_CREATOR); $pdf->SetAuthor('Shanam\'s Digital Solutions');  $pdf->SetTitle('Salary Report'); $pdf->SetSubject('Payroll');
    $pdf->SetKeywords('Shanam, Digital, SOlutions, Payroll, Payslip');
    $pdf->setFooterData(array(0,64,0), array(0,64,128)); $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));//setting footer
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);// set default monospaced font
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT); $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);  $pdf->SetFooterMargin(PDF_MARGIN_FOOTER); // set margins
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);// set auto page breaks
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);// set image scale factor
    if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {require_once(dirname(__FILE__).'/lang/eng.php'); $pdf->setLanguageArray($l);}// set some language-dependent strings (optional)
    $pdf->setFontSubsetting(true);// set default font subsetting mode
    $pdf->AddPage();// Add a page
    //Get School name, address, motto and mission
    mysqli_multi_query($conn,"SELECT scnm,scadd,principal,schtype FROM ss; SELECT sal_month,sal_year FROM acc_salaries WHERE salno LIKE '$dat[1]'"); $i=0;
    do{
            if($rs=mysqli_store_result($conn)){
                    if($i==0) $sch=mysqli_fetch_row($rs);
                    else list($mon,$yr)=mysqli_fetch_row($rs);
                    mysqli_free_result($rs);
            }$i++;
    }while(mysqli_next_result($conn));
    $css='<style> table,td,th{border:0.5px dotted blue;border-collapse:collapse;font-weight:normal;font-size:9px;}table.h{border:0.1px solid #fff;font-size:10px;}
    th.h{border:0px solid #fff;text-align:left;font-weight:bold;font-size:10px;}td.h,th.h{border:0px solid #fff;text-align:left;font-size:10px;}
    tr:nth-child(even){background-color:#eee;} td.pay{border:0.1px solid #fff;font-size:10px;border-bottom:0.5px dotted #555;text-align:left;}</style>';
    if($dat[0]==1){
        $rsSalPay=mysqli_query($conn,"SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,sp.bsalary,sp.housingallow1,sp.medicalallow1,sp.travelallow1,
        sp.responsallow1,sp.empnssf,(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.responsallow1+sp.travelallow1+sp.empnssf) AS GSal,(sp.nssffee1+sp.empnssf+sp.nssfvol1) As nssf,
        sp.nhiffee1,sp.welfare1,sp.sacco1,sp.union1,(sp.paye1-sp.mpr1) as taxes1,sp.helb1,sp.advance,sp.otherlevies1,(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.welfare1+
        sp.otherlevies1+sp.union1+sp.empnssf+sp.nssfvol1+sp.sacco1) AS TtlDed,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf+sp.responsallow1)-(sp.nssffee1+
        sp.nhiffee1+sp.advance+sp.nssfvol1+(sp.paye1-sp.mpr1)+sp.welfare1+sp.otherlevies1+sp.union1+sp.empnssf+sp.sacco1)) AS NetSal FROM stf s INNER JOIN acc_saldef sd USING (idno)
        INNER JOIN acc_salpyt sp USING (payrollno) Where (sp.markdel=0 and sp.salno LIKE '$dat[1]' AND s.staffgrp LIKE '$dat[2]') ORDER BY sd.payrollno ASC");
        $grp=strcasecmp($dat[2],'%')==0?'All staff':$dat[2];
        $html=$css.'<table class="h"><tr><th class="h" rowspan="3" colspan="2" width="50"><img src="/gen_img/logo.jpg" height="40" width="45"></th><th class="h" colspan="21">'.$sch[0].'</th>
        </tr><tr><th class="h" colspan="20">'.$sch[1].'</th></tr><tr><th class="h" colspan="17">.<BR>'.strtoupper($mon.' '.$yr.' '.$grp).' PAYROLL</th><th class="h" colspan="4"
        style="text-align:right;">.<BR>Printed On '.date('D d M, Y').'</th></tr>';
        $html.='<thead><tr><th width="50">ID. NO.</th><th width="25">P/F NO.</th><th width="100">NAMES</th><th width="55">BASIC<br>SALARY</th><th width="43">
        HOUSE</th><th width="48">MEDICAL</th><th width="45">COMMUTER</th><th width="47">DUTY</th><th width="40">EMP NSSF</th><th width="50">GROSS<br>SALARY</th><th width="50">
        N.S.S.F</th><th width="40">N.H.I.F</th><th width="45">WELFARE</th><th width="40">'.($sch[3]==0?'K.D.S</th><th width="40">ELIMU':'SACCO</th><th width="40">UNION').'</th><th
        width="40">PAYE</th><th width="40">HELB</th><th width="53">ADVANCE</th><th width="40">'.($sch[3]==0?'RENT':'OTHER').'</th><th width="50">TOTAL</th><th width="50">NET<br>SALARY</th>
        </tr></thead>';
        $tbs=0; $tho=0; $tme=0; $ttr=0; $ten=0; $tgs=0; $tns=0; $tnh=0; $twe=0; $tsa=0; $tun=0; $tta=0; $tad=0; $tod=0; $ttd=0;	$tnet=0; $thel=0; $tres=0;	$i=0;
        if (mysqli_num_rows($rsSalPay)>0):
            while (list($id,$pr,$na,$bs,$ho,$me,$tr,$res,$en,$gs,$ns,$nh,$we,$sa,$un,$ta,$hel,$ad,$od,$td,$net)=mysqli_fetch_row($rsSalPay)):
                $html.='<tr><td width="50">'.$id.'</td><td width="25">'.$pr.'</td><td width="100">'.$na.'</td><td width="55" align="right">'.number_format($bs,2).'</td><td align="right" width="43">'.
                number_format($ho,2).'</td><td align="right" width="48">'.number_format($me,2).'</td><td align="right" width="45">'.number_format($tr,2).'</td><td align="right" width="47">'.
                number_format($res,2).'</td><td align="right" width="40">'.number_format($en,2).'</td><td align="right" width="50">'.number_format($gs,2).'</td><td align="right" width="50">'.
                number_format($ns,2).'</td><td align="right" width="40">'.number_format($nh,2).'</td><td width="45" align="right">'.number_format($we,2).'</td><td align="right" width="40">'.
                number_format($sa,2).'</td><td align="right" width="40">'.number_format($un,2).'</td><td align="right" width="40">'.number_format($ta,2).'</td><td align="right" width="40">'.
                number_format($hel,2).'</td><td align="right" width="53">'.number_format($ad,2).'</td><td align="right" width="40">'.number_format($od,2).'</td><td align="right" width="50">'.
                number_format($td,2).'</td><td align="right" width="50">'.number_format($net,2).'</td></tr>';
                $tbs+=$bs; $tho+=$ho; $tme+=$me; $ttr+=$tr; $ten+=$en; $tgs+=$gs; $tns+=$ns; $tnh+=$nh; $twe+=$we; $tsa+=$sa; $tun+=$un; $thel+=$hel; $tres+=$res; $tta+=$ta; $tad+=$ad;
                $tod+=$od; $tnet+=$net; $ttd+=$td; $i++;
            endwhile;
        endif;
        $html.='<tr bgcolor="#eeaaaa"><td colspan="21" align="left">'.mysqli_num_rows($rsSalPay).' Staff Members</td></tr></table>.<br><table style="page-break-inside:avoid;font-size:11pt;
        border:0.1px solid #fff;"><tr style="font-weight:bold;letter-spacing:3px;word-spacing:4px;text-align:center;"><td
        colspan="3" width="255"><b><u>SALARY ALLOWANCES</u></b></td><td rowspan="10" width="30">--</td><td colspan="3" width="255"><b><u>SALARY DEDUCTIONS</u></b></td><td rowspan="10"
        width="450" style="border:0.1px solid #fff;text-align:center;">.<br><br><br>Prepared By ________________ Date__________<br><b>BURSAR</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;<br><br><br>Approved By _________________ Date_________<br><b>'.$sch[2].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>Principal</b>&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;</td></tr>';
        mysqli_free_result($rsSalPay);
        $html.="<tr><td width=\"25\">1.</td><td width=\"150\">Basic Salary</td><td align=\"right\" width=\"80\">".number_format($tbs,2)."</td><td width=\"25\">1.</td><td width=\"150\">
        NSSF Deductions</td><td align=\"right\" width=\"80\">".number_format($tns,2)."</td>
        </tr><tr><td>2.</td><td>Housing Allowance</td><td align=\"right\">".number_format($tho,2)."</td><td>2.</td><td>NHIF Deductions</td><td align=\"right\">".number_format($tnh,2).
        "</td></tr><tr><td>3.</td><td>Medical Allowance</td><td align=\"right\">".number_format($tme,2)."</td><td>3.</td><td>Welfare Contributions</td><td align=\"right\">".
        number_format($twe,2)."</td></tr><tr><td>4.</td><td>Overtime Allowance</td><td align=\"right\">".number_format($ttr,2)."</td><td>4.</td><td>".($sch[3]==0?"K . D . S":
        "S . A . C . C . O")."</td><td align=\"right\">".number_format($tsa,2)."</td></tr><tr><td>5.</td><td>Responsibility/Duty Allowance</td><td align=\"right\">".number_format($tres,2).
        "</td><td>5.</td><td>".($sch[3]==0?"Elimu SACCO":"Union Dues")."</td><td align=\"right\">".number_format($tun,2)."</td></tr><tr><td>6.</td><td>Employer NSSF Contribution</td><td
        align=\"right\">".number_format($ten,2)."</td><td>6.</td><td>Pay As you Earn (PAYE)</td><td align=\"right\">".number_format($tta,2)."</td></tr>";
        $html.="<tr><td rowspan=\"2\" colspan=\"3\"></td><td>7.</td><td>HELB Loan Deductions</td><td align=\"right\">".number_format($thel,2)."</td></tr><tr><td>9.</td><td>".($sch[3]==0?
        "RENT":"Other Deductions")."</td><td align=\"right\">".number_format($tod,2)."</td></tr><tr><td colspan=\"2\"><b>Total Gross Salary</b></td><td align=\"right\"><b>".
        number_format($tgs,2)."</b></td><td colspan=\"2\"><b>Total Deductions</b></td><td align=\"right\"><b>".number_format($ttd,2)."</b></td></tr><tr><td colspan=\"7\"><b>Total Net
        Salary ".number_format($tnet,2)."</b></td></tr></table>";
        //$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
    }else{
        $sql="SELECT s.idno,sd.payrollno,s.pin,s.jg,date_add(s.dob,Interval 60 year) as dor,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.paypoint,sp.bsalary,sp.housingallow1,
        sp.medicalallow1,sp.travelallow1,sp.empnssf,(sp.bsalary+sp.empnssf+sp.housingallow1+sp.medicalallow1+sp.travelallow1) AS GSal,(sp.nssffee1+sp.empnssf) as nssf,sp.nhiffee1,sp.union1,
        sp.mpr1,(sp.paye1-sp.mpr1) as taxes1,sp.advance,sp.sacco1,sp.welfare1,sp.otherlevies1,(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+
        sp.sacco1+sp.welfare1) AS TtlDed,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.empnssf+sp.travelallow1)-(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+
        sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1)) AS NetSal FROM stf s INNER JOIN acc_saldef sd USING (idno) INNER JOIN acc_salpyt sp ON sd.payrollno=sp.payrollno WHERE (sp.salno
        LIKE '$dat[1]' and s.staffgrp LIKE '$dat[2]' and sp.markdel=0) ORDER BY s.surname,s.onames ASC";
        $rsSal=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsSal);
        if ($nor>0):
            $i=1; $html='';
            $html=$css.'<table class="h" width="700">';
            while (list($id,$pr,$pin,$jg,$dor,$na,$de,$pp,$bs,$ho,$me,$tr,$empnssf,$gs,$ns,$nh,$un,$mpr,$ta,$ad,$sac,$ris,$od,$td,$net)=mysqli_fetch_row($rsSal)):
                if ($i%2==1) $html.=($i==1?'':'</tr><tr><td colspan="2" valign="middle" height="20"><hr style="border:1px dashed blue;background-color:#fff;"></td></tr>').'<tr>';
                $html.='<td style="padding:10px;" width="350">';
                $html.='<table class="h" style="page-break-inside:avoid;"><tr><th class="h" rowspan="3" width="50"><img src="/gen_img/logo.jpg" height="40" width="45"></th><th class="h"
                colspan="2" width=250>'.$sch[0].'</th></tr><tr><th class="h" colspan="2">'.$sch[1].'</th></tr><tr><th class="h" width="140" style="font-size:11px;">'.strtoupper($mon.' '.
                $yr).' PAYROLL</th><th class="h" style="text-align:right;font-size:8px;" width="110">Printed On '.date('d M, Y').'</th></tr><tr><td colspan="3" class="h"><hr>';
                $html.='PF No. '.$pr.' &nbsp;&nbsp;<u>'.$na.'</u> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ID No. '.$id.'<br> Job Group '.$jg.'&nbsp;&nbsp;&nbsp;&nbsp;Designation '.
                $de.' &nbsp;&nbsp;&nbsp; PIN No. '.$pin.'<br>Retires On '.$dor.'<p style="text-align:center;font-weight:bold;">'.$pp.'<hr></p></td></tr><tr><td colspan="3" align="center" class="h">';
                $html.='<table align="center" class="h"><tr><td class="pay" width="200" align="left"><b>Basic Salary</b></td><td class="pay" align="right" width="100"><b>'.
                number_format($bs,2).'</b></td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Housing Allowance</td><td class="pay" align="right">'.number_format($ho,2).'</td></tr>
                <tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Medical Allowance</td><td class="pay" align="right">'.number_format($me,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;Commuter Allowance</td><td class="pay" align="right">'.number_format($tr,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Employer
                NSSF Contribution</td><td class="pay" align="right">'.number_format($empnssf,2).'</td></tr><tr><td class="pay"><b>Gross Salary</b></td><td class="pay" align="right">'
                . '<b>'.number_format($gs,2).'</b></td></tr>';
                $html.='<tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;N . S . S . F</td><td class="pay" align="right">'.number_format($ns,2).'</td></tr><tr><td class="pay">&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;N . H . I . F</td><td class="pay" align="right">'.number_format($nh,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.($sch[3]==0?
                'Elimu SACCO':'Union Dues').'</td><td class="pay" align="right">'.number_format($un,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PAYE Auto (MPR = '.
                number_format($mpr,2).')</td><td class="pay" align="right">'.number_format($ta,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Salary Advance</td><td
                class="pay" align="right">'.number_format($ad,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.($sch[3]==0?'K . D . S':'SACCO').'</td><td class="pay"
                align="right">'.number_format($sac,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Welfare</td><td class="pay" align="right">'.number_format($ris,2).'</td>
                </tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.($sch[3]==0?'Rent Recovery':'Other Deductions').'</td><td class="pay" align="right">'.number_format($od,2).'</td>
                </tr><tr><td class="pay"><b>Total Deductions</b></td><td class="pay" align="right"><b>'.number_format($td,2).'</b></td></tr><tr><td class="pay"><b><i>Net Salary</i></b></td>
                <td class="pay" align="right"><b><i>'.number_format($net,2).'</i></b></td></tr></table></td></tr></table></td>';
                $i++;
            endwhile; //$pdf->writeHTML($html, true, false, true, false, ''); //$pdf->lastPage();
            $html.='</tr></table>';
        else:
                $html.='No Salary Payslip for '.$dat[0].'-'.$dat[1].'-'.$dat[2];
        endif; mysqli_free_result($rsSal);
    } $pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
    $pdf->Output("FeesReport.pdf","I");
    mysqli_close($conn);
?>
