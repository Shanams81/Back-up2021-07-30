<?php
	include_once('../../conn/pri_sch_connect.inc'); include_once('tcpdf_include.php');	include_once('../tpl/printing.tpl');
	$rec=isset($_REQUEST['rec'])?$_REQUEST['rec']:'0-0-0-0'; $rec=preg_split('/\./',$rec);//[0]0-fees 1-Analysis,[1]-start date,[2] end date
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR); 	$pdf->SetAuthor('Shanam\'s Digital Solutions');	$pdf->SetTitle('FSE');	$pdf->SetSubject('FSE');	$pdf->SetKeywords('Shanam, Digital, SOlutions, FSE, Receipt');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128)); 	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA)); 	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT); 	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER); $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO); if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {require_once(dirname(__FILE__).'/lang/eng.php');	$pdf->setLanguageArray($l);	}
	// set default font subsetting mode
	$pdf->setFontSubsetting(true); 	$pdf->AddPage();
	$css="<style>body{font-size:8pt;}table{border-collapse:collapse;}table,td{font-size:8pt;border:0.5px solid blue;}table.h,th.h,td.h{font-size:8pt;border:0px solid #fff;}
	td.b{font-size:11pt;letter-spacing:1px;word-spacing:2px;text-align:left;font-weight:bold;border:0px solid #fff;}caption{font-size:9pt;font-weight:bold;}th{font-size:8pt;
	font-weight:bold;border:0.5px solid #00f;}</style>";
	$rs=mysqli_query($conn,"SELECT scnm,scadd FROM ss;");  if(mysqli_num_rows($rs)==1) list($scnm,$scadd)=mysqli_fetch_row($rs); mysqli_free_result($rs);
	if($rec[0]==0){//Fee collection
		$res=mysqli_query($conn,"SELECT f.recno,s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',sf.stream) As cls,r.pytdate,r.cheno,r.pytfrm,f.prep FROM stud s Inner Join class sf USING (admno,
		curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN acc_incofee r On s.admno=r.admno Inner Join acc_incorecno0 f ON (r.sno=f.sno) WHERE r.commt=0 and r.markdel=0 AND (r.pytdate BETWEEN '$rec[1]' AND
		'$rec[2]') and f.prep>0 Order By recno Asc");
		$html=$css."<table class=\"h\"><tr><td rowspan=\"3\" class=\"h\" colspan=\"2\"><img src=\"/gen_img/logo.jpg\" width=\"70\" height=\"50\" vspace=\"1\" hspace=\"1\"></td><td class=\"b\" colspan=\"9\">$scnm</td></tr>
		<tr><td class=\"b\" colspan=\"9\">$scadd</td></tr><tr><td class=\"b\" colspan=\"6\">FEE PREPAID BETWEEN ".strtoupper(date("D d-M-Y",strtotime($rec[1]))." and ".date("D d-M-Y",strtotime($rec[2])))." </td><td
		colspan=\"5\" class=\"h\" align=\"right\">Printed On: ".date("D d M,Y")."</td></tr><thead><tr style=\"letter-spacing:3px;word-spacing:5px;font-weight:bold;\"><th colspan=\"2\"	style=\"letter-spacing:0px;\"
		width=\"150\">RECEIPT DETAILS</th><th colspan=\"3\" width=\"280\">RECEIVED FROM</th><th colspan=\"2\"
		width=\"175\">TRANSACTION</th><th rowspan=\"2\" width=\"80\">AMOUNT<br>PREPAID</th></tr><tr style=\"font-weight:bold;text-align:center;\"><th width=\"65\">Receipt No.</th><th width=\"85\">Received On</th>
		<th width=\"60\">Adm. No.</th><th width=\"120\">Names</th><th width=\"100\">Class/Grade</th><th width=\"90\">Mode</th><th width=\"85\">Mode No.</th></tr></thead>";
		$i=1; $ttl=0;
		if (mysqli_num_rows($res)>0){
			while (list($recno,$admno,$names,$form,$date,$chno,$pytfrm,$amt)=mysqli_fetch_row($res)){
				$html.="<tr style=\"page-break-inside:avoid;\"><td width=\"65\">$recno</td><td align=\"right\" width=\"85\">".date('d-M-Y',strtotime($date))."</td><td width=\"60\">$admno</td><td width=\"120\">$names</td>
				<td width=\"100\">$form</td><td width=\"90\">$pytfrm</td><td width=\"85\">$chno</td><td width=\"80\" align=\"right\">".number_format($amt,2)."</td></tr>";	$ttl+=$amt; 	$i++;
			}
		}else $html.="<tr><td colspan=\"8\"><br>No fees receipts were made between ".date("D d-M-Y",strtotime($rec[1]))." and ".date("D d-M-Y",strtotime($rec[2]))."</td></tr>";
		$html.="<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\">".mysqli_num_rows($res)." Fees Prepayment Record(s)</td><td colspan=\"3\" align=\"right\">Total Kshs.</td><td align=\"right\">".number_format($ttl,2).
		"</td>"; $html.="</tr></table>";
		$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
		mysqli_free_result($res);
	}else{//Fee Income Analysis
		$h="Analysis of Fee Prepayments Made Between ".date('D d M, Y',strtotime($rec[1]))." and ".date('D d M, Y',strtotime($rec[2]));
		mysqli_multi_query($conn,"SELECT f.da,min(f.srec) as srec, max(f.erec) as erec,sum(cash) as Cas,sum(cheque) as Cheq,sum(moord) as MO,sum(db) as DirBa,sum(mfee) as mf,sum(kind) as Kin,sum(cash+cheque+moord+db+mfee+
		kind) as ttl FROM (SELECT i.pytdate As Da,i.pytfrm,min(f.recno) as srec,max(f.recno) as erec,sum(if(i.pytfrm Like 'cash',f.prep,0)) As Cash,sum(if(i.pytfrm Like 'cheque',f.prep,0)) As Cheque,sum(if(i.pytfrm Like
		'money order',f.prep,0)) As MoOrd,sum(if(i.pytfrm Like 'direct banking',f.prep,0)) As db,sum(if(i.pytfrm Like 'mfees',f.prep,0)) As Mfee,sum(if(i.pytfrm Like 'kind',f.prep,0)) As Kind,i.markdel,f.markdel as mk FROM
		acc_incofee i Inner Join acc_incorecno0 f USING (sno) Inner Join acc_incoprep p USING (recno) GROUP BY i.pytdate,i.pytfrm,i.markdel,f.markdel HAVING (i.pytdate BETWEEN '$rec[1]' AND '$rec[2]') and i.markdel=0 and
		f.markdel=0)f Group By f.da ORDER BY f.da ASC; SELECT f.descr,sum(ttl) as amt FROM (SELECT date(r.recon),v.orderno,v.descr,Sum(f.amt) AS ttl FROM acc_incorecno0 r Inner Join acc_incoprep f USING (recno,acc) Inner
		Join acc_votes v on (f.voteno=v.sno) GROUP BY r.recon,r.markdel,v.orderno,v.descr HAVING r.markdel=0 and (cast(r.recon as date) Between '$rec[1]' AND '$rec[2]'))f GROUP BY f.orderno,f.descr ORDER BY f.orderno ASC;
		SELECT f.descr,sum(if(f.pytfrm Like 'Cheque',f.amt,0)) As Cheq,sum(if(f.pytfrm Like 'Direct Banking',f.amt,0)) As DB,sum(f.amt) As Ttl FROM (SELECT b.descr,i.pytdate,i.pytfrm,if(isnull(f.prep),0,f.prep) as amt
    FROM acc_incofee i Inner Join acc_banks b On (i.bankno=b.sNo) Inner join acc_incorecno0 f on (i.sno=f.sno) Inner Join acc_incoprep p On (f.recno=p.recno) WHERE i.MarkDel=0 and (i.PytDate BETWEEN '$rec[1]' AND
    '$rec[2]') and i.pytfrm IN ('cheque','direct banking'))f GROUP BY f.pytfrm,f.descr HAVING sum(f.prep)>0 Order By f.descr; SELECT f.addedby,sum(cash) as Cas,sum(cheque) as Cheq,sum(moord) as MO,sum(db) as DirBa,
    sum(mfee) as mf,sum(kind) as Kin,sum(cash+cheque+moord+db+mfee+kind) as ttl FROM (SELECT f.addedby,sum(if(f.pytfrm Like 'cash',f.ttl,0)) As Cash,sum(if(f.pytfrm Like 'cheque',f.ttl,0)) As Cheque,sum(if(f.pytfrm Like
    'money order',f.ttl,0)) As MoOrd,sum(if(f.pytfrm Like 'direct banking',f.ttl,0)) As db,sum(if(f.pytfrm Like 'mfees',f.ttl,0)) As Mfee,sum(if(f.pytfrm Like 'kind',f.ttl,0)) As Kind FROM (SELECT i.pytdate,i.pytfrm,
    i.addedby,Sum(f.prep) As TTL,i.markdel,f.markdel as mk FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) GROUP BY i.pytdate,i.pytfrm,i.addedby,i.markdel,f.markdel HAVING (f.markdel=0  and i.markdel=0 AND
    (i.pytdate Between '$rec[1]' AND '$rec[2]')))f Group By f.pytfrm,f.addedby)f Group By f.addedby ORDER BY f.addedby ASC"); 	$i=0;	$nod=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){ $nod=mysqli_num_rows($rs);
					$html=$css."<table class=\"h\"><tr><td rowspan=\"3\" class=\"h\"><img src=\"/gen_img/logo.jpg\" width=\"70\" height=\"50\" vspace=\"1\" hspace=\"1\"></td><td
					class=\"h\" class=\"b\" colspan=\"9\">$scnm</td></tr><tr><td class=\"b\" colspan=\"9\">$scadd</td></tr><tr><td class=\"b\" colspan=\"6\">".strtoupper($h)."</td><td
					colspan=\"3\" style=\"font-size:8pt;text-align:right;\" class=\"h\">Printed On ".date("D d M,Y")."</td></tr><tr><td colspan=\"12\" class=\"h\"><hr></td></tr><tr><th
					rowspan=\"2\" width=\"90\">DATE</th><th colspan=\"2\" width=\"120\">RECEIPT NO. RANGE</th><th colspan=\"6\" width=\"390\" style=\"font-weight:bold;
					letter-spacing:4px;word-spacing:6px;\">FEE COLLECTION PER MODE</th><th rowspan=\"2\" width=\"70\">DAY'S TOTAL</th></tr><tr><th width=\"60\">Start</th><th
					width=\"60\">End</th><th width=\"60\">Cash</th><th width=\"60\">Cheque</th><th width=\"70\">Money Order</th><th width=\"70\">Bankslips</th><th width=\"70\">M-Fees
					</th><th width=\"60\">Kind</th></tr>"; 		$tca=$tdb=$tch=$tmo=$tki=$tmf=$nr=0;
					if ($nod==0) $html.="<tr><td colspan=\"10\">No fees receipts were made between ".date("D d-M-Y",strtotime($rec[1]))." and ".date("D d-M-Y",strtotime($rec[2]))."</td></tr>";
					else{
						while (list($date,$sr,$er,$cas,$che,$moord,$dirba,$mfee,$kind,$ttl)=mysqli_fetch_row($rs)):
							$html.=($nr%2==0?"<tr bgcolor=\"#dddddd\">":"<tr>");
							$html.="<td>".date("D d M, Y", strtotime($date))."</td><td align=\"center\">$sr</td><td align=\"center\">$er</td><td align=\"right\">".number_format($cas,2).
							"</td><td align=\"right\">".number_format($che,2)."</td><td align=\"right\">".number_format($moord,2)."</td><td align=\"right\">".number_format($dirba,2)."</td>
							<td align=\"right\">".number_format($mfee,2)."</td><td align=\"right\">".number_format($kind,2)."</td><td align=\"right\"><b>".number_format($ttl,2)."</b></td>
							</tr>";	 $tca+=$cas;	$tch+=$che;	$tdb+=$dirba;	$tmo+=$moord; $tmf+=$mfee; $tki+=$kind; $nr++;
						endwhile;
					}$html.=($nr%2==0?"<tr bgcolor=\"#dddddd\">":"<tr>")."<th align=\"right\" colspan=\"3\">Sub totals (Kshs.)</th><th align=\"right\">".number_format($tca,2)."</th>
					<th align=\"right\">".number_format($tch,2)."</th><th align=\"right\">".number_format($tmo,2)."</th><th align=\"right\">".number_format($tdb,2)."</th><th
					align=\"right\">".number_format($tmf,2)."</th><th align=\"right\">".number_format($tki,2)."</th><th align=\"right\">".number_format(($tca+$tch+$tmo+$tdb+$tmf+$tki),
					2)."</th></tr></table>";	$pdf->writeHTML($html, true, false, true, false,'');
				}elseif($i==1){
					$html=$css."<table class=\"h\"><tr><td class=\"h\" width=\"290\"><b style=\"background-color:#777;color:#fff;font-size:12pt;font-weight:bold;\">FEE COLLECTION PER
					VOTEHEAD</b><br/><table><tr style=\"font-weight:bold;\"><th width=\"25\"></th><th width=\"150\">VOTEHEADS</th><th width=\"100\" align=\"right\">AMOUNT (Kshs.)</th>
					</tr>"; $ttl=0; $a=1;
					while ($d=mysqli_fetch_row($rs)){ $ttl+=$d[1];
						$html.=($a%2==1?"<tr bgcolor=\"#dddddd\">":"<tr>");
						$html.="<td>$a.</td><td>$d[0]</td><td align=\"right\">".number_format($d[1],2)."</td></tr>"; $a++;
					}$html.=($a%2==1?"<tr bgcolor=\"#dddddd\">":"<tr>")."<td>$a.</td><td>BANK CHARGES</td><td align=\"right\">0.00</td></tr><tr><td colspan=\"2\" align=\"right\"><b>
					TOTAL INCOME RECEIPTS</b></td><td align=\"right\"><b>".number_format($ttl,2)."</b></td></tr></table></td>";
				}elseif($i==2){
					$html.="<td class=\"h\"><b style=\"background-color:#777;color:#fff;font-size:12pt;font-weight:bold;\">BANKSLIP AND CHEQUE ANALYSIS</b><br/><table><tr><th
					class=\"b\" width=\"170\">Bank Name</th><th class=\"b\" width=\"70\">Cheques</th><th class=\"b\" width=\"70\">Bankslips</th><th class=\"b\" width=\"70\">Bank's Total
					</th></tr>"; $ttl=array(0,0,0); $a=0;
					if (mysqli_num_rows($rs)>0) while (list($ba,$ch,$db,$tt)=mysqli_fetch_row($rs)){
					 	$html.=($a%2==0?"<tr bgcolor=\"#dddddd\">":"<tr>");
						$html.="<td>$ba</td><td align=\"right\">".number_format($ch,2)."</td><td align=\"right\">".number_format($db,2)."</td><td align=\"right\">".number_format($tt,2).
						"</td></tr>"; $ttl[0]+=$ch;$ttl[1]+=$db;$ttl[2]+=$tt; $a++;
					}else $html.="<tr><td colspan=\"5\">No Cheque or direct banking receipts were made between ".date("D, d-F-Y",strtotime($rec[1]))." <br>and ".date("D, d-F-Y",
					strtotime($rec[2]))."</td></tr>";
					$html.=($a%2==0?"<tr bgcolor=\"#dddddd\">":"<tr>")."<th align=\"right\">Subtotals</th>"; foreach($ttl as $t) $html.="<th align=\"right\">".number_format($t,2).
					"</th>"; $html.="</tr></table></td></tr></table>";
					$pdf->writeHTML($html, true, false, true, false, ''); //$pdf->lastPage();
				}else{
					$html=$css."<b style=\"background-color:#777;color:#fff;font-size:12pt;font-weight:bold;\">ANALYSIS PER ACCOUNTS DEPARTMENT STAFF</b><br><table><tr><th width=\"20\">
					</th><th width=\"180\">User Name</th><th width=\"60\">Cash</th><th width=\"60\">Cheque</th><th width=\"70\">Money Order</th><th width=\"70\">Bankslips</th><th
					width=\"60\">M-Fees</th><th width=\"70\">In-Kind</th><th width=\"70\">Total</th></tr>"; $a=1;
					while (list($un,$ca,$ch,$mo,$db,$mf,$ki,$tt)=mysqli_fetch_row($rs)):
						$html.=($a%2==1?"<tr bgcolor=\"#dddddd\">":"<tr>");
						$html.="<td align=\"middle\">$a</td><td>$un</td><td align=\"right\">".number_format($ca,2)."</td><td align=\"right\">".number_format($ch,2)."</td><td
						align=\"right\">".number_format($mo,2)."</td><td align=\"right\">".number_format($db,2)."</td><td align=\"right\">".number_format($mf,2)."</td><td
						align=\"right\">".number_format($ki,2)."</td><td align=\"right\"><b>".number_format($tt,2)."</b></td></tr>"; $a++;
					endwhile;
					$html.="</table>"; $pdf->writeHTML($html, true, false, true, false, ''); //$pdf->lastPage();
				}	mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn));
	}
	$html='<br><br><br><div style="font-size:8pt;">Prepared By ______________Date__________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Confirmed By_____________Date________&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;Approved By_____________Date_______<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<b>ACCOUNTS CLERK</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>BURSAR</b>&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>
	PRINCIPAL</b></div>';
	$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
	$pdf->Output("FeesReport.pdf","I");
	mysqli_close($conn);
?>
