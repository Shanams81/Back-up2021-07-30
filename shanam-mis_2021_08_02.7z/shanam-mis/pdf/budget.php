<?php
    include_once('../../conn/pri_sch_connect.inc');		include_once('tcpdf_include.php');
    class Voteheads{
        private $vno,$vname,$amt;
        public function __construct($no,$nam, $am){$this->vno=$no; $this->vname=$nam;   $this->amt=$am;}       public function valVNo(){return $this->vno;}
        public function valVName(){return $this->vname;}    public function valAmt(){return $this->amt;}
    }
    $vono=$_REQUEST['action']; $vono=preg_split("/\-/",$vono); //$vono[0] 0-Budget 1-Draft Budget, $vono[1] Account No., vono[2] Votehead No.
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr,finyr FROM ss; SELECT descr FROM acc_voteacs WHERE acno LIKE '$vono[1]'; SELECT b.voteno,v.descr,
    if(isnull(sum(bi.prevqty)),0,sum(bi.prevqty*bi.prevup)) as prev, if(isnull(sum(bi.qty)),0,sum(bi.qty*bi.up)) as amt FROM ".($vono[0]==0?"acc_budget":"acc_budgetdraft")." b Inner
    Join acc_votes v On (b.voteno=v.sno) LEFT JOIN ".($vono[0]==0?"acc_budgitems":"acc_budgitemsdraft")." bi On (b.budgno=bi.budgno) GROUP BY b.budgno,v.descr,b.acc,b.voteno,b.markdel
    HAVING (b.markdel=0 AND b.acc LIKE '$vono[1]' AND b.voteno LIKE '$vono[2]') ORDER BY b.voteno Asc;");
    $i=$pttl=$cttl=0; $account=$voteshow=''; $voteheads=[];
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){if (mysqli_num_rows($rs)>0) list($scnm,$scadd,$finyr)=mysqli_fetch_row($rs);
            }elseif($i==1){if (mysqli_num_rows($rs)>0) list($account)=mysqli_fetch_row($rs);
            }else{$a=1;
                if (mysqli_num_rows($rs)>0) while(list($vo,$vname,$pamt,$amt)=mysqli_fetch_row($rs)){
                    $voteshow.="<tr><td class=\"gen\" width=\"30\">$a</td><td class=\"gen\" width=\"300\">$vname</td><td align=\"right\" class=\"gen\" width=\"150\">".number_format($pamt,2)."</td><td align=\"right\" "
                    . "class=\"gen\" width=\"150\">".number_format($amt,2)."</td></tr>"; $a++;
                    $voteheads[]=new Voteheads($vo,$vname,$amt); $pttl+=$pamt;  $cttl+=$amt;
                }
            }mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));  $title=($vono[0]==0?"FY$finyr BUDGET ESTIMATES":"FY".($finyr+1)." DRAFT BUDGET ESTIMATES");
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, "A4", true, 'UTF-8', false);
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Shanam\'s Digital Solutions');
    $pdf->SetTitle($title);
    $pdf->SetSubject($title);
    $pdf->SetKeywords('Shanam, Digital, SOlutions, Budget');
    //setting footer
    $pdf->setFooterData(array(0,64,0), array(0,64,128));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
    // set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    // set auto page breaks
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    // set image scale factor
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
    // set some language-dependent strings (optional)
    if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
            require_once(dirname(__FILE__).'/lang/eng.php');
            $pdf->setLanguageArray($l);
    }
    // set default font subsetting mode
    $pdf->setFontSubsetting(true);
    // Add a page
    $pdf->AddPage();
    //start pdf file
    $css='<style>.h{font-size:10pt;font-weight:bold;}table.hide,th.hide{border:0.1px dotted #fff;border-collapse:collapse;padding:1px;font-size:9pt;} table.gen,td.gen,th.gen{border:1px solid blue;font-size:9pt;'
    . 'border-collapse:collapse;}th{font-weight:bold;}</style>';
    $html=$css.'<table class="hide"><tr><th rowspan="3" style="vertical-align:middle;width:55px;text-align:left;" class="hide"><img src="/gen_img/logo.jpg" width=52 height=57></th><th class="hide" '
    . 'colspan="3" style="text-align:left;font-weight:bold;">'.$scnm.'</th></tr><tr><th class="hide" colspan="2" style="text-align:left;font-weight:bold;">'.$scadd.'</th></tr><tr><th class="hide"><b>'.$title.'</b>'
    . '</th><th class="hide" style="text-align:right;" colspan="2"><b>Printed On:'.date('D d M, Y').'</b></th></tr><tr><td colspan="3" class="hide" width="680"><hr>';
    $html.='<b cladd=\"h\">SUMMARY OF THE BUDGET PER VOTEHEAD</b><br><table class="gen"><thead><tr><th class="gen" width="30">#</th><th class="gen" width="300">VOTEHEAD</th><th class="gen" '
    . 'width="150">FY'.($vono[0]==0?($finyr-1):$finyr).' ACTUALS</th><th class="gen" width="150">FY'.($vono[0]==0?$finyr:($finyr+1)).' ESTIMATE</th></tr></thead><tbody>'.$voteshow.'</tbody><tfoot><tr><td colspan=\"2\"
    class="gen" width="330" align="right">TOTAL AMOUNT</td><td class="gen" width="150" align="right">'.number_format($pttl,2).'</td><td class="gen" width="150" align="right">'.
    number_format($cttl,2).'</td></tr></tfoot></table></td></tr></table>';
    $pdf->writeHTML($html, true, false, true, false, ''); 	$pdf->lastPage(); $html='';
    foreach($voteheads as $vh){
        $pdf->AddPage();
        $html.=$css."<h5 class=\"h\">".$vh->valVName()." BUDGET ESTIMATES FOR FY".($vono[0]==0?$finyr:($finyr+1))." - GRANDTOTAL (KSHS.) ".number_format($vh->valAmt(),2)."</h5><table
        border=1 class=\"gen\"><thead><tr><th colspan=\"3\" class=\"gen\" width=\"280\">ITEM DESCRIPTION</th><th colspan=\"3\" class=\"gen\" width=\"200\">FY".($vono[0]==0?($finyr-1):
        $finyr)." ACTUALS</th><th colspan=\"3\" class=\"gen\" width=\"200\">FY".($vono[0]==0?$finyr:($finyr+1))." ESTIMATE</th></tr><tr><th class=\"gen\" width=\"25\">#</th><th
        class=\"gen\" width=\"190\">BUDGET ITEM</th><th class=\"gen\" width=\"65\">UNITS</th><th class=\"gen\" width=\"55\">Quantity</th><th class=\"gen\" width=\"65\">Unit Cost</th><th
        class=\"gen\" width=\"80\">Amount</th><th class=\"gen\" width=\"55\">Quantity</th><th class=\"gen\" width=\"65\">Unit Cost</th><th class=\"gen\" width=\"80\">Amount</th></tr>
        </thead><tbody>";
        $sql="SELECT i.itemname,i.Units,b.prevqty,b.prevup,(b.prevqty*b.prevup) as pamt,b.Qty,b.Up,(b.qty*b.up) AS TtlAmt FROM ".($vono[0]==0?"acc_budget":"acc_budgetdraft")." bu Inner
        Join ".($vono[0]==0?"acc_budgitems":"acc_budgitemsdraft")." b USING (budgno) Inner Join items i On (b.itmcode=i.itmcode) WHERE (b.markdel=0 AND bu.acc LIKE '$vono[1]' AND
        bu.voteno LIKE '".$vh->valVNo()."') ORDER BY itemname ASC;";
        $rs=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Close this tab and try again."); //echo $sql;
        if (mysqli_num_rows($rs)>0){ $i=1;
            while ((list($itm,$uni,$pqty,$pup,$pamt,$qty,$up,$amt)=mysqli_fetch_row($rs))){
                $html.= "<tr><td class=\"gen\" width=\"25\">$i</td><td class=\"gen\" width=\"190\">$itm</td><td class=\"gen\" width=\"65\">$uni</td><td align=\"right\" class=\"gen\" width=\"55\">".number_format($pqty,2).
                "</td><td align=\"right\" class=\"gen\" width=\"65\">".number_format($pup,2)."</td><td align=\"right\" class=\"gen\" width=\"80\">".number_format($pamt,2)."</td><td align=\"right\" class=\"gen\" "
                . "width=\"55\">".number_format($qty,2)."</td><td align=\"right\" class=\"gen\" width=\"65\">".number_format($up,2)."</td><td align=\"right\" class=\"gen\" width=\"80\">".number_format($pamt,2)."</td></tr>";
                $i++;
            }
        }else{$html.= "<tr><td colspan=\"9\" class=\"gen\" width=\"680\">The are no budget items for this votehead</td></tr>";}mysqli_free_result($rs);
        $html.="</table>"; $pdf->writeHTML($html, true, false, true, false, ''); 	$pdf->lastPage(); $html='';
    }
    $pdf->Output('budgeting.pdf', 'I');
    mysqli_close($conn);
?>
