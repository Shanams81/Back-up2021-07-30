<?php
	include_once('../../conn/pri_sch_connect.inc');
	$burs=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; $burs=preg_split('/\-/',$burs);
	include_once('tcpdf_include.php');
	include_once('../tpl/printing.tpl');
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, "A4", true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('FSE Receipt');
	$pdf->SetSubject('FSE Receive');
	$pdf->SetKeywords('Shanam, Digital, SOlutions, FSE, Receipt');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128));
	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	// set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
		require_once(dirname(__FILE__).'/lang/eng.php');
		$pdf->setLanguageArray($l);
	}
	// set default font subsetting mode
	$pdf->setFontSubsetting(true);
	// Add a page
	$pdf->AddPage();
	//start pdf file
	mysqli_multi_query($conn,"SELECT scnm,scadd,mission,motto,principal FROM ss; SELECT f.bursno,f.sourcename,f.pytfrm,f.cheno,f.pytdate,f.amt,concat(ba.descr,' (',f.branch,' BRANCH)') as
	banks,concat('P.O Box ',f.po,' - ',f.pocode) as post,f.city,f.bankcharge,f.addressee FROM acc_burs f LEFT JOIN acc_banks ba on (f.bankno=ba.sNo) WHERE f.bursno LIKE '$burs[0]'; SELECT
	f.recno,s.admno,concat(s.surname,' ',s.onames) as names,concat(cn.clsname,'-',sf.stream) As cls,f.ttl FROM stud s INNER JOIN class sf USING (admno,curr_year) INNER JOIN classnames cn
	USING (clsno) INNER JOIN (SELECT f1.recno,f.admno,f.bursno,(if(isnull(f1.amt),0,(f1.amt+f1.bc))+if(isnull(f2.amt),0,(f2.amt+f2.bc))) as ttl FROM acc_incofee f Left Join acc_incorecno0 f1 
	USING (sno) Left Join acc_incorecno1 f2 USING (sno) WHERE f.markdel=0 and f.bursno LIKE '$burs[0]')f USING (admno) INNER JOIN acc_burs b USING (bursno) WHERE b.BursNo LIKE '$burs[0]'
	ORDER BY f.recno ASC;");   $i=0; $ben=''; $tttl=0; $a=1;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0) list($scnm,$scadd,$mis,$mot,$princ)=mysqli_fetch_row($rs);
			elseif($i==1) list($buno,$sona,$pytfrm,$cheno,$date,$amt,$bank,$add,$city,$bc,$addr)=mysqli_fetch_row($rs);
			else{$nob=mysqli_num_rows($rs); while (list($recno,$admno,$nam,$frm,$ttl)=mysqli_fetch_row($rs)){
				$ben.='<tr><td class="show">'.$a.'</td><td class="show">'.$recno.'</td><td class="show">'.$admno.'</td><td nowrap class="show">'.$nam.'</td><td class="show">'.$frm.'</td>
				<td align="right" class="show">'.number_format($ttl,2).'</td></tr>';
				$a++;	$tttl+=$ttl;
			}}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	$html='<style>table.hide,td.hide,th.hide{border:0.1px dotted #fff;font-size:11pt;border-collapse:collapse;padding:4px} table.show,td.show,th.show{border:0.5px dotted #00f;
	font-weight:normal;font-size:11pt;border-collapse:collapse;text-align:left;}
	</style>';
	$html.='<table class="hide"><tr><td rowspan="3" class="hide" width="10%"><img src="/gen_img/logo.jpg" width="52" height="57"></td><td class="hide" style="font-weight:bold;
	letter-spacing:1px;word-spacing:2px;" colspan="2" width="90%">'.$scnm.'</td></tr>';
	$html.='<tr><td style="font-weight:bold;" colspan="2" class="hide">'.$scadd.'</td></tr><tr><td style="font-weight:bold;" class="hide">BURSARY
	ACKNOWLEDGEMENT NOTE</td><td style="font-size:9pt;text-align:right;" class="hide">Printed On: '.date("D d-M-Y").'</td></tr><tr><td colspan="3" class="hide"><hr><b
	style="text-align:right;">Received On: '.date("D d-M-Y",strtotime($date)).'</B></td></tr>';
	$html.='<tr><td colspan="3" class="hide"><br>'.$addr.',</td></tr><tr><td colspan="3" class="hide">'.$sona.',</td></tr><tr><td colspan="3" class="hide">'.$add.',</td></tr><tr><td
	colspan="3" class="hide">'.$city.'</td></tr><tr><td class="hide" colspan="3"><br/><br/>Dear Sir/ Madam,</td></tr><tr><td colspan="3" class="hide"><br/><b><u style="letter-spacing:2px;
	word-spacing:3px;">RE: ACKNOWLEDGEMENT FOR RECEIVING BUSARY</u></b></td></tr><tr><td colspan="3" style="letter-spacing:1px;word-spacing:2px;text-align:justify;line-height:120%;
	font-size:12pt;" class="hide"><br>';
	$html.='We are writing to acknowledge to have received a bursary of the sum of Kshs. '.number_format($amt,2).' ('.NumToWord($amt).') less Kshs. '.
	number_format($bc,2).' as bank charges. <br>The bursary was received on '.date("D d F, Y",strtotime($date)).' by <b>'.$pytfrm.'</b> No. <b>'.$cheno.'</b> of '.$bank.'.<br><br>';
	if($nob>0){ //display this part if bursary is distributed
	 	$html.='Student beneficiaries of the bursary are as listed. <br></td></tr><tr><td colspan="3" align="center">';
		$html.='<table class="show"><tr><th class="show" width="45"><b>S/No.</b></th><th class="show" width="85"><b>Receipt No.</b></th><th class="show" width="80"><b>Adm. No.</b></th><th
		class="show" width="240"><b>Student\'s Names</b></th><th class="show" width="125"><b>Form</b></th><th class="show" width="90"><b>Amount</b></th></tr>'.$ben;
		$html.='<tr><td colspan="4" class="show"><b>'.$nob.' Bursary '.($nob>1?'Beneficaries':'Beneficiary').'</b></td><td align="right" class="show"><b>Subtotal</b></td><td align="right"
		class="hide"><b>'.number_format($tttl,2).'</b></td></tr></table>';
	}$html.='</td></tr><tr><td colspan="3" style="letter-spacing:1px;word-spacing:2px;text-align:justify;line-height:120%;" class="hide"><br>Thank you.<br><br>Yours faithfully,
	<br><br><br>_____________________________________<br>'.$princ.'<br>The Principal/ Secretary BoM.</td></tr></table>';
	$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
	$pdf->Output('FSEReceipt.pdf', 'I');
	mysqli_close($conn);
?>
