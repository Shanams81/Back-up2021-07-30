<?php
	include_once('../../conn/pri_sch_connect.inc'); 	include_once('tcpdf_include.php'); 	include_once('../tpl/printing.tpl');
	$dat=isset($_REQUEST['sno'])?strip_tags($_REQUEST['sno']):"0-0-0";	$dat=preg_split("/\-/",$dat);	//0 - Leaveout SNo, 1 - findby, 2 - finddetails
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR); 		$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('Leaveouts');			$pdf->SetSubject('Leaveouts');
	$pdf->SetKeywords('Shanam, Digital, SOlutions, FSE, Receipt');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128)); 	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);				$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	// set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
		require_once(dirname(__FILE__).'/lang/eng.php');
		$pdf->setLanguageArray($l);
	}
	// set default font subsetting mode
	$pdf->setFontSubsetting(true);
	// Add a page
	$pdf->AddPage();
	if(strcasecmp($dat[2],'0')!=0){ //if specific leaveout is to be printed 
	 	$sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,ld.paid,ld.bal,l.preparedon,l.leavedate,l.returndate FROM stud s INNER JOIN
		class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN acc_leaveoutstud ld USING (admno) INNER JOIN acc_leaveout l USING (sno) WHERE ld.status=0 and
		ld.sno LIKE '$dat[0]' ";
		if(strcasecmp($dat[1],"admno")==0) $sql.="and s.admno LIKE '%$dat[2]%'";
		elseif(strcasecmp($dat[1],"name")==0) $sql.="and (s.surname LIKE '%$dat[2]%' or s.onames LIKE '%$dat[2]%')";
		else  $sql.="and (cn.clsname LIKE '%$dat[2]%' or c.stream LIKE '%$dat[2]%')";
	}else $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,ld.paid,ld.bal,l.preparedon,l.leavedate,l.returndate FROM stud s INNER JOIN
	class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN acc_leaveoutstud ld USING (admno) INNER JOIN acc_leaveout l USING (sno) WHERE ld.status=0 and
	ld.sno LIKE '$dat[0]' ";
	$sql.=" ORDER BY cn.clsname,c.Stream,s.admno ASC";	$rs=mysqli_query($conn,$sql); 	$nor=mysqli_num_rows($rs);
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,mission,motto,finyr FROM ss");
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mis,$mot,$yr)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	//start pdf file
	$css='<style>table{border:0.1px solid #fff;page-break-inside:avoid;}td{border:0.1px solid #fff;font-size:12px;}th{border:0.1px solid #fff;font-size:14px;font-weight:bold;}</style>';
	if ($nor>0):
		$i=1;
		while (list($admno,$name,$cls,$paid,$bal,$pon,$lon,$ron)=mysqli_fetch_row($rs)):
			$html=$css.'<table width="850"><tr><th rowspan="3" valign="middle" width="80" align="center"><img src="/gen_img/logo.jpg" width="50" height="55" vspace="1" hspace="1"></th><th
			colspan="2">'.$scnm.'</th></tr><tr><th colspan="2">'.$scadd.'</th></tr><tr><th class="hide">FEE DEFAULTERS\' LEAVEOUT SHEET</th><th style="font-size:10px;" align="right">
			Printed On:'.date("D d F, Y").'</th></tr><tr><td colspan="3"><hr></td></tr>';
			$html.='<tr><td colspan="3"><b><u>'.$name.'</u></b> Adm. No. <b>'.$admno.'</b>, a pupil in class &nbsp;<b>'.$cls.'</b> has been sent home on <b><u>'.date('D d F, Y',
			strtotime($lon)).'</u></b> for school fees balance of Kshs. <b><u>'.number_format($bal,2).'</u></b>. Having paid fees suming to amount of Kshs. <b>'.number_format($paid,2).
			'.</b></td></tr>';
			$html.='<tr><td colspan="3">The student is expected back to school on or before <b>'.date('D d F, Y',strtotime($ron)).'</b> at 4:00pm with the fee balance.</td></tr><tr><td
			colspan="3">______________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;___________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;Approved By _________________<br><b>The Bursar/ Accounts Clerk</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Master/ Mistress on Duty &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>The Principal</b></td></tr><tr><td colspan="3">
			Parent\'s Remarks _______________________________________________________________________________________________<br></td></tr><tr><td colspan="3">.<br>Parent\'s Signature
			_________________________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date __________________________</td></tr><tr>
			<td colspan="3"><br><p style="font-size:8px;color:#888;text-align:right;">Designed By: Shanam\'s Digital Solutions +254736732168</p><hr style="border:1px dashed #00f;
			background-color:#fff;"/></td></tr></table><br>';
			$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
		endwhile;
	else:
		$html.='No Leaveout sheets'; $pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
	endif;	mysqli_free_result($rs);
	$pdf->Output("Leaveouts.pdf","I");
	mysqli_close($conn);
?>
