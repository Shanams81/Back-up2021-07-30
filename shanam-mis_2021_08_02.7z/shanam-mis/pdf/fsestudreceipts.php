<?php
	include_once('../../conn/pri_sch_connect.inc');		include_once('tcpdf_include.php');	include_once('../tpl/printing.tpl');
	$dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0-%-%";	$dat=preg_split("/\-/",$dat);	//0 - BatchNo, 1 - Form, 2 - Stream and 3 admission number	
	if($dat[3]=="%")$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, "A4", true, 'UTF-8', false); else $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, "A5", true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('FSE Receipt');
	$pdf->SetSubject('FSE Student Receipt');
	$pdf->SetKeywords('Shanam, Digital, SOlutions, FSE, Receipt');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128));
	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	// set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
		require_once(dirname(__FILE__).'/lang/eng.php');
		$pdf->setLanguageArray($l);
	}
	// set default font subsetting mode	
	$pdf->setFontSubsetting(true);
	// Add a page
	$pdf->AddPage();
	//start pdf file
	mysqli_multi_query($conn,"SELECT scnm,scadd FROM ss; SELECT acno,abbr from acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 and markdel=0 ORDER BY acno ASC; SELECT recon FROM acc_fseincome 
        WHERE batchno LIKE '$dat[0]' LIMIT 0,1;"); $a=0; $sql='';
	do{
            if($rs=mysqli_store_result($conn)){	
                if($a==0) list($scnm,$scadd)=mysqli_fetch_row($rs);
                elseif($a==1){
                    $noa=mysqli_num_rows($rs); $noa++;
                    while(list($acno,$name)=mysqli_fetch_row($rs)){	$sql.="sum(if(b.acc=$acno,b.amt,0)) as ttl$acno,";	$acname[]=$name;}
                }else{if(mysqli_num_rows($rs)>0)list($date)=mysqli_fetch_row($rs); else $date=date('Y-m-d');}mysqli_free_result($rs);
            }$a++;
	}while(mysqli_next_result($conn)); 
	$sql="SELECT b.admno,concat(s.surname,' ',s.onames) as nms,concat(c.`clsname`,'-',sf.`stream`) As frm,$sql sum(b.amt) as ttl FROM stud s Inner Join class sf USING (admno,
	curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) Inner Join acc_fseben b USING (admno) Inner Join acc_fseincome i USING (recno) GROUP BY i.batchno,b.admno,s.surname,s.onames,
	c.clsname,sf.stream,c.clsno,s.curr_year HAVING batchno like '$dat[0]' AND c.clsno LIKE '$dat[1]' and sf.stream LIKE '$dat[2]' and b.admno LIKE '$dat[3]' ORDER BY b.admno ASC";
	$rs=mysqli_query($conn,$sql);	$words='';
	$html='<style>table.hide,td.hide,th.hide{border:0.1px dotted #fff;font-size:9pt;border-collapse:collapse;padding:4px} table.gen,td.gen,th.gen{border:1px solid blue;
	border-collapse:collapse;font-size:8pt;text-align:left;}td.cat{border:0.5px dashed #0d0;padding:2px;}</style><table class="hide">';
	if (mysqli_num_rows($rs)>0){
            $a=0;
            while($d=mysqli_fetch_row($rs))	{
                if($a%2==0) $html.='<tr style="page-break-inside:avoid;"><td class="cat" width="340">'; else $html.='<td class="cat" width="340">';
                $html.='<table class="hide"><tr><th rowspan="3" style="vertical-align:middle;width:55px;text-align:left;" class="hide" width="55"><img src="/gen_img/logo.jpg" width=52 height=57>
                </th><th class="hide" colspan="3" style="font-size:9pt;text-align:left;font-weight:bold;">'.$scnm.'</th></tr><tr><th class="hide" colspan="3" style="font-size:9pt;
                text-align:left;font-weight:bold;">'.$scadd.'</th></tr><tr><th class="hide"><b>FSE RECEIPT</b></th><th class="hide" align="right" colspan="2"><b style="font-size:7pt;">Printed On:'.
                date('D d M, Y').'</b></th></tr><tr><td class="hide" colspan="4" style="max-height:5px;"><hr>Tranche: <b>'.$dat[0].'</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Received On '.date("D d-M, Y",strtotime($date)).'</td>
                </tr><tr><td class="hide" nowrap>Adm. No.</td><td class="hide" colspan="3" style="letter-spacing:1px;word-spacing:2px;font-weight:bold;">'.$d[0].' <u>'.$d[1].'</u></td>
                </tr><tr><td class="hide" colspan="2">Form: <b>'.$d[2].'</b></td><td class="hide" colspan="2">Received From: <b>MoE - GoK</b></td></tr><tr><td 
                colspan="4"><hr><table class="gen" style="font-size:11pt;"><tr><th class="gen"><b>BEING RECEIPT FOR</b></th><th class="gen" align="right"><b>AMOUNT (KSHS.)</b></th></tr>';	$i=3;
                foreach($acname as $ac){$html.='<tr><td class="gen">'.$ac.'</td><td class="gen" align="right">'.number_format($d[$i],2).'</td></tr>'; $i++;}
                $html.='<tr><th class="gen"><b>TOTAL AMOUNT RECEIVED</b></th><th class="gen" align="right"><b>'.number_format($d[$i],2).'</b></th></tr></table></td></tr>';
                if($a==0) $words=strtoupper(NumToWord($d[$i]));
                $html.='<tr><td class="hide" colspan="4">AMOUNT IN WORDS <span style="display:block;font-weight:bold;text-decoration:underline #bbb double;max-width:200px;height:60px;">'.$words.
                '</span></td></tr><tr><td class="hide" colspan="4"><hr></td></tr><tr><td class="hide" colspan="4"><br>With Thanks ___________________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Bursar/ Accounts Clerk</td></tr></table></td>';
                if($a%2==1)$html.="</tr>"; $a++;
            }if($a%2==1) $html.='</tr>';
	} else $html="<tr><td class=\"hide\">NO FSE RECEIPTS ARE AVAILABLE</td></tr>"; 
	$html.="</table>";
	$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();	
	$pdf->Output('FSEStudReceipt.pdf', 'I');
	mysqli_close($conn);
?>