<?php
	include_once('../../conn/pri_sch_connect.inc');		include_once('tcpdf_include.php');	include_once('../tpl/printing.tpl');
	$dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0-%-%";	$dat=preg_split("/\-/",$dat);	//0 - BatchNo, 1 - Form, 2 - Stream and 3 admission number	
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, "A4", true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('FSE Receipt');
	$pdf->SetSubject('FSE Student Receipt');
	$pdf->SetKeywords('Shanam, Digital, SOlutions, FSE, Receipt');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128));
	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	// set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
		require_once(dirname(__FILE__).'/lang/eng.php');
		$pdf->setLanguageArray($l);
	}
	// set default font subsetting mode	
	$pdf->setFontSubsetting(true);
	// Add a page
	$pdf->AddPage();
	//start pdf file
	mysqli_multi_query($conn,"SELECT scnm,scadd FROM ss; SELECT acno,abbr from acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 and markdel=0 ORDER BY acno ASC; SELECT recon FROM acc_fseincome 
        WHERE batchno LIKE '$dat[0]' LIMIT 0,1;"); $a=0; $sql='';
	do{
            if($rs=mysqli_store_result($conn)){	
                if($a==0) list($scnm,$scadd)=mysqli_fetch_row($rs);
                elseif($a==1){
                    $noa=mysqli_num_rows($rs); $noa+=5;
                    while(list($acno,$name)=mysqli_fetch_row($rs)){	$sql.="sum(if(b.acc=$acno,b.amt,0)) as ttl$acno,";	$acname[]=$name;}
                }else{if(mysqli_num_rows($rs)>0)list($date)=mysqli_fetch_row($rs); else $date=date('Y-m-d');}mysqli_free_result($rs);
            }$a++;
	}while(mysqli_next_result($conn)); 
	$sql="SELECT b.admno,concat(s.surname,' ',s.onames) as nms,concat(c.`clsname`,'-',sf.`stream`) As frm,$sql sum(b.amt) as ttl FROM stud s Inner Join class sf USING (admno,
	curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) Inner Join acc_fseben b USING (admno) Inner Join acc_fseincome i USING (recno) GROUP BY i.batchno,b.admno,s.surname,s.onames,
	c.clsname,sf.stream,c.clsno,s.curr_year HAVING batchno like '$dat[0]' AND c.clsno LIKE '$dat[1]' and sf.stream LIKE '$dat[2]' ORDER BY b.admno ASC";
	$rs=mysqli_query($conn,$sql);	$h=(strcasecmp($dat[1],'%')==0?"ALL":"FORM ".$dat[1])." ".(strcasecmp($dat[2],'%')==0?"":$dat[2])." BENEFICIARIES OF FSE TRANCHE ".$dat[0];
	$html='<style>table.hide,th.hide{border:0.1px dotted #fff;font-size:9pt;border-collapse:collapse;padding:3px;} table.gen,td.gen,th.gen{border:1px solid blue;
	border-collapse:collapse;font-size:8pt;text-align:left;}</style><table class="hide"><tr><th rowspan="3" style="vertical-align:middle;width:55px;text-align:left;" class="hide">
	<img src="/gen_img/logo.jpg" width=52 height=57></th><th class="hide" colspan="'.$noa.'" style="font-size:9pt;text-align:left;font-weight:bold;">'.
	$scnm.'</th></tr><tr><th class="hide" colspan="'.$noa.'" style="font-size:9pt;text-align:left;font-weight:bold;">'.$scadd.'</th></tr><tr><th class="hide" colspan="'.($noa-2).'"><b>'.$h.
	'</b></th><th class="hide" align="right" colspan="2"><b style="font-size:9pt;">Printed On:'.date('D d M, Y').'</b></th></tr><thead><tr><td class="gen" width="30"><b>S/N</b></td><td 
	class="gen" width="60"><b>ADM. NO.</b></td><td class="gen" width="150"><b>STUDENT NAMES</b></td><td class="gen" width="90"><b>FORM</b></td>'; 
	foreach($acname as $ac){$html.='<td class="gen"  width="70"><b>'.$ac.'</b></td>'; $ttl[]=0;} $ttl[]=0;
	$html.='<td class="gen"  width="70"><b>TOTAL</b></td><td class="gen" width="70"><b>SIGNATURE</b></td></tr></thead>';
	if (mysqli_num_rows($rs)>0){
	 	$a=1;
		while($d=mysqli_fetch_row($rs))	{
			$html.='<tr style="page-break-inside:avoid;"><td class="gen" width="30">'.$a.'</td><td class="gen" width="60">'.$d[0].'</td><td class="gen" width="150">'.$d[1].'</td><td 
			class="gen" width="90">'.$d[2].'</td>';	$i=3;
			foreach($acname as $ac){$html.='<td class="gen" align="right" width="70">'.number_format($d[$i],2).'</td>'; $ttl[$i-3]+=$d[$i];	$i++;}
			$html.='<td class="gen" align="right" width="70"><b>'.number_format($d[$i],2).'</b></td><td class="gen" width="70"></td></tr>'; 
			$ttl[$i-3]+=$d[$i];		$a++;
		}if($a%2==1) $html.='<tr style="background:#ddd;font-weight:bold;letter-spacing:2px;word-spacing:3px;text-align:right;">'; 
		else $html.='<tr style="font-weight:bold;letter-spacing:2px;word-spacing:3px;text-align:right;">';
		$html.='<td colspan="4" class="gen">TOTAL AMOUNT (KSHS.)</td>'; foreach($ttl as $t)$html.='<td class="gen">'.number_format($t,2).'</td>'; $html.='<td class="gen"></td></tr>';
	} else $html.="<tr><td class=\"hide\" colspan=\"".($noa+1)."\">NO FSE RECEIPTS ARE AVAILABLE</td></tr>";
	$html.="</table>";
	$pdf->writeHTML($html, true, false, true, false, ''); 	$pdf->lastPage();	
	$pdf->Output('FSEBenList.pdf', 'I');
	mysqli_close($conn);
?>