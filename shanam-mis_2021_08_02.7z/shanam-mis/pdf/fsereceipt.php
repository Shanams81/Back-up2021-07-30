<?php
	include_once('../../conn/pri_sch_connect.inc');
	include_once('tcpdf_include.php');
	include_once('../tpl/printing.tpl');
	$batch=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):"0";
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, "A5", true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('FSE Receipt');
	$pdf->SetSubject('FSE Receive');
	$pdf->SetKeywords('Shanam, Digital, SOlutions, FSE, Receipt');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128));
	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	// set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
		require_once(dirname(__FILE__).'/lang/eng.php');
		$pdf->setLanguageArray($l);
	}
	// set default font subsetting mode	
	$pdf->setFontSubsetting(true);
	// Add a page
	$pdf->AddPage();
	$rs=mysqli_query($conn,"SELECT acno,descr from acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 ORDER BY acno ASC"); $noa=mysqli_num_rows($rs); $sql1=''; $i=0;
	if($noa>0){
            $sql="SELECT recno,batchno,recon,acc,mode,noofstud,amt FROM acc_fseincome WHERE markdel=0 AND batchno=$batch and commt=0";
            $rs=mysqli_query($conn,"SELECT acno,descr from acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 ORDER BY acno ASC"); $noa=mysqli_num_rows($rs); $optAC=$sql1='';
            while(list($acno,$name)=mysqli_fetch_row($rs)){
                $sql1.="sum(if(i.acc=$acno,i.recno,0)) as rec$acno,min(i.recon) as on$acno,sum(if(i.acc=$acno,i.noofstud,0)) as nos$acno,sum(if(i.acc=$acno,i.amt,0)) as ttl$acno,"; 
                $acname[]=$name; $acsno[]=$acno;
            }$sql="SELECT i.batchno,i.mode, $sql1 sum(i.amt) as ttl FROM ($sql)i GROUP BY i.batchno,i.mode ORDER BY i.batchno ASC";
            $rsFee=mysqli_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fsefees.php">HERE</a> to go back.');	$data=mysqli_fetch_row($rsFee);	mysqli_free_result($rsFee);
            //Get School name, address, motto and mission
            $rsSch=mysqli_query($conn,"SELECT scnm,scadd FROM ss"); if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
            $trm=date('m',strtotime($data[1])); $trm=($trm<5?"ONE":($trm<9?"TWO":"THREE"));
            //start pdf file
            $html='<style>table.hide,td.hide,th.hide{border:0.1px dotted #fff;font-size:9pt;border-collapse:collapse;padding:4px} table.pay,td.pay,th.pay{border:1px dashed green;
            font-weight:normal;font-size:8pt;border-collapse:collapse;text-align:left;}table.gen,td.gen,th.gen{border:1px solid blue;border-collapse:collapse;font-size:8pt;text-align:left;}
            </style>';
            $html.='<table class="hide"><tr><td rowspan="3" style="vertical-align:middle;width:90px;text-align:left;" class="hide"><img src="/gen_img/logo.jpg" width=52 height=57></td><th 
            class="hide" colspan="3" style="font-size:11pt;word-spacing:2px;letter-spacing:1px;text-align:left;font-weight:bold;">MINISTRY OF EDUCATION<br>'.$scnm.'</th></tr><tr><th 
            class="hide" colspan="3" style="font-size:10pt;text-align:left;">'.$scadd.'</th></tr><tr><th class="hide"><b>FSE FEE RECEIPT</b></th><th class="hide" align="right"colspan="2"><b 
            style="font-size:8pt;">Printed On: '.date('D d M, Y').'</b></th></tr><tr><td class="hide" colspan="4" style="max-height:5px;"><hr></td></tr>'; 
            $html.='<tr><td class="hide">Disburse No.</td><td class="hide">'.$data[0].'</td><td class="hide" align="right" colspan="2">Received On '.date("D d-M-Y",strtotime($data[3])).'</td>
            </tr><tr><td class="hide" nowrap>Received From</td><td class="hide" colspan="3" style="letter-spacing:3px;word-spacing:5px;font-weight:bold;" nowrap>MINISTRY OF EDUCATION - FSE 
            FEES</td></tr><tr><td class="hide">Received From</td><td class="hide"><b>MoE - GoK</b></td><td class="hide"> Received in <b>EFT</b></td><td class="hide">Form: All Students</td>
            </tr><tr><td colspan="4"><table class="hide"><tr>'; 
            $i=2; $index=0; $vtable='';
            foreach($acname as $acn){
                $vtable='<table class="gen" align="center"><tr><td class="gen" style="word-spacing:3px;letter-spacing:2px;font-weight:bold;background-color:#00f;color:#fff;" colspan="2">'.$acn.
                '</td></tr><tr><td class="gen" colspan="2" style="font-size:7pt;">RECEIPT NO. '.$data[$i].' &nbsp;&nbsp; FEES FOR '.$data[$i+2].' STUDENTS</td></tr><tr><td class="gen"><b>VOTEHEAD</b></td><td '
                . 'class="gen" align="right"><b>AMOUNT</b></td></tr>';
                $sql="SELECT v.descr, if(isnull(f.amt),0,f.amt) as ttl FROM acc_votes v LEFT JOIN (SELECT f.acc,f.voteno,f.amt FROM acc_fsevotes f WHERE f.markdel=0 and 
                f.acc LIKE '$acsno[$index]' and f.recno LIKE '$data[$i]')f ON (v.sno=f.voteno and v.acc=f.acc) WHERE v.fs_defined=1 and v.acc LIKE '$acsno[$index]' ORDER BY  v.sno ASC";
                $rs=mysqli_query($conn,$sql) or die(mysqli_error($conn)); $i+=3;
                while($d=mysqli_fetch_row($rs)) $vtable.='<tr><td class="gen">'.$d[0].'</td><td class="gen" align="right">'.number_format($d[1],2).'</td></tr>';
                $vtable.='<tr><td class="gen"><b>TOTAL</b></td><td class="gen" align="right"><b>'.number_format($data[$i],2).'</b></td></tr></table>';
                $html.='<td class="hide" valign="top">'.$vtable.'</td>'; $i++; $index++;
            }
            $html.='</tr></table></td></tr><tr><td class="hide" colspan="4"><hr><b style="letter-spacing:3px;word-sapcing:4px;font-weight:bold;">FSE DISBURSEMENT GRANDTOTAL <u>'.
            number_format($data[$i],2).'</u></b></td></tr><tr><td class="hide" colspan="4" style="font-size:8pt;">'.NumToWord($data[$i]).'<hr></td></tr>';		
            $html.='<tr><td class="hide" colspan="4">.<br><br>With Thanks ___________________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Bursar/ Accounts Clerk</td></tr></table>';
            //$html.='</td></tr></table>';
	}else $html='NO FSE RECEIPT FOR TRANCHE '.$dat.' IS IN THE SYSTEM'; 
	$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();	
	$pdf->Output('FSEReceipt.pdf', 'I');
	mysqli_close($conn);
?>