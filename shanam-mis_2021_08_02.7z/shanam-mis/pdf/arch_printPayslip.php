<?php
	include_once('../conn/mysqli_connect.inc.tpl');
	include_once('tcpdf_include.php');
	include_once('../tpl/printing.tpl');
	$batch=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):"0";
	if (strcasecmp($dat[3],"%")==0) $pdf = new TCPDF(PDF_PAGE_ORIENTATION,PDF_UNIT,"A4",true,'UTF-8',false); else $pdf = new TCPDF(PDF_PAGE_ORIENTATION,PDF_UNIT,"A5",true,'UTF-8',false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('FSE Receipt');
	$pdf->SetSubject('FSE Receive');
	$pdf->SetKeywords('Shanam, Digital, Solutions, FSE, Receipt');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128));
	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	// set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
		require_once(dirname(__FILE__).'/lang/eng.php');
		$pdf->setLanguageArray($l);
	}
	// set default font subsetting mode	
	$pdf->setFontSubsetting(true);
	// Add a page
	$pdf->AddPage();
	$dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0-%-%";
	$dat=preg_split("/\-/",$dat);	//0 - Month, 1 - Year, 2 - Staff Group and 3 payroll number	
	$sql="SELECT s.idno,sd.payrollno,s.pin,s.jg,date_add(dob,Interval 60 year) as dor,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.paypoint,sp.bsalary,sp.housingallow1,
	sp.medicalallow1,sp.travelallow1,sp.empnssf,(sp.bsalary+sp.empnssf+sp.housingallow1+sp.medicalallow1+sp.travelallow1) AS GSal,(sp.nssffee1+sp.empnssf) as nssf,sp.nhiffee1,sp.union1,
	sp.mpr1,(sp.paye1-sp.mpr1) as taxes1,sp.advance,sp.sacco1,sp.welfare1,sp.otherlevies1,(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+
	sp.sacco1+sp.welfare1) AS TtlDed,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.empnssf+sp.travelallow1)-(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+
	sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1)) AS NetSal FROM Stf s Inner Join arch_stf st Using (idno) INNER JOIN Arch_SalDef sd on (st.idno=sd.idno and st.yr=sd.yr) INNER JOIN 
	Arch_SalPyt sp ON s.idno=sp.idno WHERE (sp.sal_month LIKE '$dat[0]' And sp.sal_year LIKE '$dat[1]' and st.yr LIKE '$dat[1]' and s.staffgrp LIKE '$dat[2]' and sp.payrollno LIKE '$dat[3]' 
	and sp.markdel=0) ORDER BY sp.processedon,s.surname,s.onames ASC";
	$rsSal=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsSal);
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,mission,motto FROM ss"); 
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mis,$mot)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	$html='<style>table.hide,td.hide,th.hide{border:0.1px dotted #fff;font-size:9pt;border-collapse:collapse;padding:4px} table.pay,td.pay,th.pay{border:1px dashed green;
	font-weight:normal;font-size:8pt;border-collapse:collapse;text-align:left;} table.gen,td.gen,th.gen{border:1px solid blue;border-collapse:collapse;font-size:8pt;text-align:left;}
	</style>';
	if ($nor>0){
		$i=1;	$html.='<table class="gen" cellpadding="4" cellspacing="4">';
		while (list($id,$pr,$pin,$jg,$dor,$na,$de,$pp,$bs,$ho,$me,$tr,$empnssf,$gs,$ns,$nh,$un,$mpr,$ta,$ad,$sac,$ris,$od,$td,$net)=mysqli_fetch_row($rsSal)):
			if ($i%2==1) $html.='</tr><tr><td>'; else $html.='<td>';
			$html.='<table cellspacing="0" class="hide"><tr><td rowspan="3" valign="middle" width="80" align="center" class="hide"><img src="img/logo.png" width="60" height="65" 
			vspace="1" hspace="1"></td><td class="hide">'.$scnm.'</td></tr><tr><td class="hide">'.$scadd.'</td></tr><tr><td class="hide">'.$mot.'</td></tr><tr><td colspan="2" 
			class="hide"><hr><b style="font-size:12px;">'.$dat[0].' - '.$dat[1].'</b> PAYSLIP &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Printed On:'.date("D d-M-Y").'<hr></td></tr></table><br>';
			$html.='<table class="pay" cellpadding="2" align="center"><tr><td class="pay">Payroll No. '.$pr.' &nbsp;&nbsp;<u>'.$na.'</u></td><td class="pay">ID No. '.$id.' &nbsp;
			&nbsp;&nbsp;&nbsp;Job Group '.$jg.'</td></tr><tr><td class="pay">Designation '.$de.' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; PIN No. '.$pin.'</td><td class="pay" align="right">
			Retires On '.$dor.'</td></tr><tr><td colspan="2" align="center" class="pay" bgcolor="#eeeeee"><b>'.$pp.'</b><hr></td></tr>';
			$html.='<tr><td class="pay"><b>Basic Salary</b></td><td class="pay" align="right"><b>'.number_format($bs,2).'</b></td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;Housing Allowance</td><td class="pay" align="right">'.number_format($ho,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Medical Allowance</td><td 
			class="pay" align="right">'.number_format($me,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Overtime Earnings</td><td class="pay" align="right">'.
			number_format($tr,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Employer NSSF Contribution</td><td class="pay" align="right">'.number_format($empnssf,2).
			'</td></tr><tr><td class="pay"><b>Gross Salary</b></td><td class="pay" align="right"><b>'.number_format($gs,2).'</b></td></tr><tr><td class="pay">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;N . S . S . F</td><td class="pay" align="right">'.number_format($ns,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			N . H . I . F</td><td class="pay" align="right">'.number_format($nh,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Union Dues</td><td class="pay" 
			align="right">'.number_format($un,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PAYE Auto (MPR = '.number_format($mpr,2).')</td><td class="pay" 
			align="right">'.number_format($ta,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Salary Advance</td><td class="pay" align="right">'.number_format($ad,2).
			'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SACCO</td><td class="pay" align="right">'.number_format($sac,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;Welfare</td><td class="pay" align="right">'.number_format($ris,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Other Deductions</td>
			<td class="pay" align="right">'.number_format($od,2).'</td></tr><tr><td class="pay"><b>Total Deductions</b></td><td class="pay" align="right"><b>'.number_format($td,2).'</b>
			</td></tr><tr><td class="pay"><b><i>Net Salary</i></b></td><td class="pay" align="right"><b><i>'.number_format($net,2).'</i></b></td></tr></table>';
			$i++;	
		endwhile;
		$html.='</tr></table>';
	}else $html.='No Salary Payslip for '.$dat[0].'-'.$dat[1].'-'.$dat[2];
	$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();	
	$pdf->Output('Payslip.pdf', 'I');
	mysqli_close($conn);
?>