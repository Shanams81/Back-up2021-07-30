<?php
    include_once('../../conn/pri_sch_connect.inc'); include_once('../tpl/printing.tpl');include_once('tcpdf_include.php');include_once('../tpl/printing.tpl');
    $recno=$_REQUEST['recno']; $recno=preg_split("/\-/",$recno); //$recno[0] receipt serial no., [1]-where from, [2] 0 Original 1 Duplicate reciept,[3] Voucher No. for fee inkind
    class Accounts{private $acc,$name;
        public function __construct($a,$n){$this->acc=$a; $this->name=$n;} public function valAcc(){return $this->acc;}  public function valName(){return $this->name;}
    }$pdf = new TCPDF("L", PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $pdf->SetCreator(PDF_CREATOR); $pdf->SetAuthor('Shanam\'s Digital Solutions');  $pdf->SetTitle('Reciept'); $pdf->SetSubject('Receipt');
    $pdf->SetKeywords('Shanam, Digital, SOlutions, Fee, Reciept');
    $pdf->setFooterData(array(0,64,0), array(0,64,128)); $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));//setting footer
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);// set default monospaced font
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT); $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);  $pdf->SetFooterMargin(PDF_MARGIN_FOOTER); // set margins
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);// set auto page breaks
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);// set image scale factor
    if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {require_once(dirname(__FILE__).'/lang/eng.php'); $pdf->setLanguageArray($l);}// set some language-dependent strings (optional)
    $pdf->setFontSubsetting(true);// set default font subsetting mode
    $pdf->AddPage();// Add a page
    //Get School name, address, motto and mission
    //First 0 - Print dialog on load, second 0 - from where
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr,receipt,receipttype,finyr FROM ss; SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0;
    SELECT count(f1.recno) as main,count(f2.recno) as misc,sum(if(isnull(f1.amt),0,(f1.amt+f1.bc))) as fee,sum(if(isnull(f2.amt),0,(f2.amt+f2.bc))) as mfee,sum(if(isnull(f1.bc),0,f1.bc))
    as bc,sum(if(isnull(f2.bc),0,f2.bc)) as mbc FROM acc_incofee i Left Join acc_incorecno0 f1 USING (sno) Left Join acc_incorecno1 f2 USING (sno) GROUP BY i.sno HAVING i.sno LIKE
    '$recno[0]';SELECT abbr FROM terms Inner Join ss USING (finyr) ORDER BY tno ASC;");  $ac1=$ac2=false; $i=$famt=$mfamt=$bc=$mbc=0;
    do{
        if($rs=mysqli_store_result($conn)){
          if ($i==0) list($scnm,$scadd,$recsize,$rectype,$fy)=mysqli_fetch_row($rs); //recSize [0] A4 Paper, [1] A5 Paper, recType[0] - 2in1, [1] - Single
          elseif($i==1){$noacs=mysqli_num_rows($rs); while($d=mysqli_fetch_row($rs)) $accounts[]=new Accounts($d[0],$d[1]);
          }elseif($i==2){while ($d=mysqli_fetch_row($rs)){$ac1=($d[0]>0?true:false);  $ac2=($d[1]>0?true:false); $famt=$d[2]; $mfamt=$d[3]; $bc=$d[4]; $mbc=$d[5];}
        }else{while(list($trm)=mysqli_fetch_row($rs)) $terms[]=$trm;}mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
    $css='<style>th.hideborder,td.hideborder{border:0;}th.showborder,td.showborder{border:1px solid #000;}.showhead{background-color:#777;color:#fff;font-weight:bold;text-align:center;letter-spacing:3px;
    word-spacing:5px;}table{border:0}</style>';
    $html='<table class="table table-sm table-borderless" width="100%"><tr><td rowspan="3" class="hideborder" style="border-bottom:2px solid #00d !important" width="75"><img src="/gen_img/logo.jpg"
    width="70" height="70" vspace="1" hspace="1"></td><td style="font-weight:bold;font-size:0.9rem;" colspan="2" class="hideborder">'.$scnm.'</td></tr><tr><td style="font-weight:bold;font-size:0.9rem;"
    colspan="2" class="hideborder">'.$scadd.'</td></tr><tr><td class="hideborder" style="border-bottom:2px solid #00d !important;font-weight:bold;font-size:0.9rem;letter-spacing:1px;
    word-spacing:2px;">OFFICIAL RECEIPT</td><td align="right" class="hideborder" style="border-bottom:2px solid #00d !important;">Printed On '.date("D d M,Y").'</td></tr>';
    $amtfee=0;
    if ($ac1 && $ac2) $sql="SELECT r.recno,m.recno as mrec,r.acc,f.admno,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby,month(f.pytdate) as mon,f.sno,s.curr_year FROM acc_incofee f
    Inner Join acc_incorecno0 r USING (sno) Inner Join acc_incorecno1 m USING (sno) Inner Join stud s On (f.admno=s.admno) WHERE f.sno LIKE '$recno[0]'"; //Receipt details
    elseif ($ac1 && !$ac2) $sql="SELECT r.recno,0 as mrec,r.acc,f.admno,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby,month(f.pytdate) as mon,f.sno,s.curr_year FROM acc_incofee f
    Inner Join acc_incorecno0 r USING (sno) Inner Join stud s On (f.admno=s.admno)  WHERE f.sno LIKE '$recno[0]'"; //Receipt details
    else $sql="SELECT 0 as rno, r.recno,r.acc,f.admno,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby,month(f.pytdate) as mon,f.sno,s.curr_year FROM acc_incofee f Inner Join
    acc_incorecno1 r  USING (sno) Inner Join stud s On (f.admno=s.admno) WHERE r.sno LIKE '$recno[0]'"; //reciept details
    $rsRec=mysqli_query($conn,$sql);	list($rec,$mrec,$acc,$admno,$date,$paidby,$pytfrm,$cheno,$amt,$bc,$un,$mon,$sno,$acyr)=mysqli_fetch_row($rsRec); mysqli_free_result($rsRec);
    $cheno=strlen($cheno)==0?"__________":$cheno;  if ($mon<5) $term="One"; elseif ($mon<9) $term="Two"; else $term="Three"; if($ac1){$mbc=0;}else{$mbc=$bc;$bc=0;}
    $rec=($rec>0?$rec:$mrec);
    //Details of student and respective balance
    if($acyr===$fy){
        $sql="SELECT s.admno,s.stud_names,s.cls,if(((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+
        if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))) as t1bal, if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee)-if((s.t1f-
        if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,f.fee))))) as t2bal,if((s.t3f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t3f-if(isnull(f.fee),0,f.fee)-if((s.t2f-if(isnull(f.fee),0,
        f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee))))) as t3bal,(s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0)-if(isnull(f.fee),0,f.fee)) as ybal,";
        if($noacs==1)$sql.="0 as mt1bal,0 as mt2bal,0 as mt3bal,0 as mybal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,s.curr_year,
        sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc=1,cf.T2,0)) as t2f,sum(if(v.acc=1,cf.T3,0)) as t3f FROM  stud s INNER JOIN class c USING (admno, curr_year) INNER JOIN classnames cn USING (clsno)
        INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY s.admno,s.surname,s.onames,s.Curr_Year,cn.clsname,
        c.stream,a.stud_assoc,s.present,s.markdel HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$admno')s INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.spemed) as med,
        sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM
        `acc_votesassigned`)x GROUP BY admno, markdel HAVING markdel=0 and admno LIKE '$admno')ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-
        v.spemed-v.prep-v.unifrm)) as fee FROM acc_incofee f left Join acc_incorecno0 v USING (sno) ";
        else $sql.="if(((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-
        if(isnull(f.mfee),0,f.mfee))) as mt1bal,if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-if(isnull(f.mfee),0,f.mfee)-if((s.mt1f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt1f-
        if(isnull(f.mfee),0,f.mfee))))) as mt2bal,if((s.mt3f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt3f-if(isnull(f.mfee),0,f.mfee)-if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-
        if(isnull(f.mfee),0,f.mfee))))) as mt3bal,((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee)) as mybal FROM (SELECT s.admno,
        concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,s.curr_year,sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc!=1,cf.T1,0)) as mt1f,sum(if(v.acc=1,
        cf.T2,0)) as t2f,sum(if(v.acc!=1,cf.T2,0)) as mt2f,sum(if(v.acc=1,cf.T3,0)) as t3f,sum(if(v.acc!=1,cf.T3,0)) as mt3f FROM  stud s INNER JOIN class c USING (admno, curr_year) INNER
        JOIN classnames cn USING (clsno) INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY
        s.admno,s.surname,s.onames,s.Curr_Year,cn.clsname,c.stream,a.stud_assoc,s.present,s.markdel HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$admno')s
        INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.miscbf) as marbf,sum(c.spemed) as med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when
        name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM `acc_votesassigned`)x GROUP BY admno, markdel HAVING markdel=0
        and admno LIKE '$admno')ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm)) as fee,
        if(isnull(sum(m.amt)),0,sum(m.amt-m.arrears-m.spemed-m.unifrm)) as mfee FROM acc_incofee f left Join acc_incorecno0 v USING (sno) Left Join acc_incorecno1 m USING (sno) ";
        $sql.="GROUP BY f.admno,f.markdel HAVING f.markdel=0 and f.admno LIKE '$admno')f on (s.admno=f.admno)";
        //alumni details
    }else $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream, ' ',s.curr_year) As cls,0 as t1b,0 as t2b,cf.arr as t3b,cf.arr as bal,0 as mt1b,
    0 as mt2b,0 as mt3b,0 as mbal FROM  stud s INNER JOIN class c USING (admno, curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN (SELECT admno,sum(alumniarrears) as arr FROM class
    GROUP BY admno, markdel HAVING markdel=0 and admno LIKE '$admno')cf USING (admno) WHERE s.admno LIKE '$admno'";
    $rsBal=mysqli_query($conn,$sql); list($stadmno,$stnames,$stcls,$t1,$t2,$t3,$bal,$mt1,$mt2,$mt3,$mbal)=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);
    $html.='<tr><td class="hideborder"><b>Receipt No.</b></td><td class="hideborder">'.$rec.'</td><td class="hideborder" style="text-align:right;">Received On '.date("D d-M-Y",strtotime($date)).'</td></tr><tr><td
    class="hideborder" colspan="3">Received From &nbsp;&nbsp;<span style="font-weight:bold;font-size:12pt;letter-spacing:4px;word-spacing:6px;bgcolor="#eee">'.$stnames.'</span></td></tr><tr><td class="hideborder"
    colspan="3">Admission No. '.$stadmno.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Class:</b> '.strtoupper($stcls).'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Received In '.$pytfrm.'</td></tr>';
    $html.='<tr><td class="hideborder" colspan="3">Trans/ Cheque No. '.$cheno.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fees Paid By '.$paidby.' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Term &nbsp; '.$term.'</td></tr><tr><td colspan="3" class="hideborder"><Img src="/gen_img/'.($recno[2]==0?'washout.jpg" width"=300"':'duplicate.jpg" width="400"').' height="300"
    style="position:fixed;opacity:0.3;pointer-events:none;"><table align="center" class="table table-sm table-borderless"><tr>';
    //footer of student receipt
    if($acyr===$fy) $foot='<tr><td colspan="3" class="showborder"><b>'.$terms[0].' </b>&nbsp;<u>'.number_format(($t1+$mt1),2).'</u>&nbsp;&nbsp;&nbsp;<b>'.$terms[1].' </b>&nbsp;<u>'.number_format(($t2+$mt2),2).'</u>
    &nbsp;&nbsp;&nbsp;<b>'.$terms[2].' </b>&nbsp;<u>'.number_format(($t3+$mt3),2).'</u>&nbsp;&nbsp;&nbsp;<b>Total Bal. </b>&nbsp;<u>'.number_format(($bal+$mbal),2).'</u></td></tr>';
    //footer of alumni receipt
    else $foot='<tr><td colspan="3" class="showborder"><b>Balance of Arrears B/F (KShs.)</b>&nbsp;&nbsp;&nbsp;<u>'.number_format(($bal+$mbal),2).'</u></td></tr>';
    $foot.='<tr><td colspan="3" class="hideborder"><br><br>Served By <u><b>'.$un.'</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign________________</td></tr><tr><td colspan="3" style="color:#aaa;font-size:7px;
    border-top:2px solid #009 !important" class="hideborder"><center>The receipt is invalid without official stamp. Designed By: Shanam\'s Digital Solutions +254736732168</center></td></tr></table>'; $vote='';
    //votehead allocation
    if ($rectype==0){$i=1; //2in1 reciepts
        foreach($accounts as $acc){
          $vote.='<td class="hideborder"><table class="table table-sm table-bordered" align="center" style="font-size:12pt;"><tr><th colspan="2" class="showborder" style="letter-spacing:1px;word-spacing:2px;">'.
          strtoupper($acc->valName()).' VOTEHEADS DISTRIBUTION</th></tr><tr><th class="showborder">BEING PAYMENT FOR</th><th class="showborder">AMOUNT</th></tr>';
          $sql="SELECT ucase(v.descr), if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Left Join (SELECT f.voteno,f.amt FROM acc_incovotes f Inner Join ".($i==1?"acc_incorecno0":"acc_incorecno0")." v USING (recno)
          WHERE v.sno LIKE '$sno' and f.markdel=0 and f.acc='".$acc->valAcc()."')f ON (v.sno=f.voteno) WHERE v.stud_fee=1 and v.acc='".$acc->valAcc()."' ORDER BY v.sno ASC";  $rs=mysqli_query($conn,$sql); $ttl=0;
          while(list($v,$f)=mysqli_fetch_row($rs)){$vote.='<tr><td class="showborder">'.$v.'</td><td style="text-align:right;" class="showborder">'.number_format($f,2).'</td></tr>'; $ttl+=$f;} $ttl+=($i==1?$bc:$mbc);
          $vote.='<tr><td class="showborder">BANK CHARGES</td><td style="text-align:right;" class="showborder">'.number_format(($i==1?$bc:$mbc),2).'</td></tr><tr><th class="showborder">TOTAL A/C AMOUNT</th><th
          style="text-align:right;" class="showborder">'.number_format($ttl,2).'</th></tr></table>'.($i==1?'</td><td class="hideborder">--</td>':'</td>'); $i++;
        } $ttl=($famt+$mfamt);
        $html.=$vote.'</tr></table>Total Fees Received Kshs.&nbsp;&nbsp;'.number_format($ttl,2).'<span style="font-weight:bold;text-decoration:underline blue solid;"> ('.NumToWord($ttl).')</span></td></tr><tr><td
        colspan="3" class="showborder" style="text-align:center;background:#ddd;font-weight:bold;letter-spacing:6px;word-spacing:8px;">FEES BALANCE ANALYSIS</td></tr>'.$foot;
        if ($recsize==0) $html=$css.'<table class="table table-bordered table-sm"><tr><td width="450" class="showborder">'.$html.'</td><td width="450" class="showborder">'.$html.'</td></tr></table>';
        else $html=$css.'<table class="table table-bordered table-sm"><tr><td class="showborder" width="450">'.$html.'</td></tr></table>';
    }else{ $i=0; $another=$rpt1=$rpt2='';
        foreach($accounts as $acc){
          $ttl=0; $v='<td class="showborder"><table border="1" cellpadding="2" cellspacing="0" style="width:100%;font-size:0.9rem;"><tr><td colspan="2" class="showborder"><b>'.strtoupper($acc->valName()).' VOTEHEAD
          DISTRIBUTION </td></tr><tr><td class="showborder"><b>BEING PAYMENT FOR</b></td><td class="showborder"><b>AMOUNT (KSHS.)</b></td></tr>';
          $rs=mysqli_query($conn,"SELECT ucase(v.descr),if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Left Join (SELECT f.voteno,f.amt FROM acc_incovotes f Inner Join ".($i==0?"acc_incorecno0":"acc_incorecno1").
          " v USING (recno) WHERE v.sno LIKE '$sno' and f.markdel=0 and f.acc='".$acc->valAcc()."')f ON (v.sno=f.voteno) WHERE v.stud_fee=1 and v.acc='".$acc->valAcc()."' ORDER BY v.sno ASC");
          if($i==0){$vote.=$v; while(list($v,$f)=mysqli_fetch_row($rs)){$vote.='<tr><td class="showborder">'.$v.'</td><td style="text-align:right;" class="showborder">'.number_format($f,2).'</td></tr>'; $ttl+=$f;}
            $ttl+=$bc;
          }else{ $another.=$v; while(list($v,$f)=mysqli_fetch_row($rs)){$another.='<tr><td class="showborder">'.$v.'</td><td style="text-align:right;" class="showborder">'.number_format($f,2).'</td></tr>'; $ttl+=$f;}
            $ttl+=$mbc;
          }$v='<tr><td class="showborder">BANK CHARGES</td><td style="text-align:right;" class="showborder"><b>'.number_format(($i==0?$bc:$mbc),2).'</b></td></tr><tr><td class="showborder"><b>TOTAL A/C AMOUNT</b></td>
          <td style="text-align:right;" class="showborder"><b>'.number_format($ttl,2).'</b></td></tr>';
          if ($i==0) $vote.=$v.'<tr><td colspan="2" class="showborder showhead">Total Fees Received Kshs.&nbsp;&nbsp;&nbsp;'.number_format($famt,2).'<span style="font-weight:bold;text-decoration:underline blue solid;">
          ('.NumToWord($famt).')</span></td></tr></table></td><td class="class="hideborder">--</td>';
          else $another.=$v.'<tr><td colspan="2" class="showborder showhead">Total Fees Received Kshs.&nbsp;&nbsp;&nbsp;'.number_format($mfamt,2). '<span style="font-weight:bold;text-decoration:underline blue solid;">
          ('.NumToWord($mfamt).')</span></td></tr></table></td></tr>';  $i++;
        }$rpt1=$html.$vote.'</tr></table></td></tr><tr><td colspan="3" style="text-align:center;" class="showborder showhead">FEES BALANCE ANALYSIS</td></tr>'.$foot;
        $rpt2=$html.$another.'</table></td></tr><tr><td colspan="3" style="text-align:center;" class="showborder showhead">FEES BALANCE ANALYSIS</td></tr>'.$foot;
        if ($recsize==0 && $recno[2]==0){//A4 Report
          $html=$css.'<table class="table table-bordered table-sm">';
          if($ac1 && $ac2) $html.='<tr><td style="border:1px solid #900;">'.$rpt1.'</td><td style="border:1px solid #900;">'.$rpt1.'</td></tr><tr style="page-break-inside:avoid;"><td
          style="border:1px solid #900;">'.$rpt2.'</td><td style="border:1px solid #900;">'.$rpt2.'</td></tr>';
          elseif ($ac1 && !$ac2) $html.='<tr><td style="border:1px solid #900;">'.$rpt1.'</td><td style="border:1px solid #900;">'.$rpt1.'</td></tr>';
          else $html.='<tr><td style="border:1px solid #900;">'.$rpt2.'</td><tr><td style="border:1px solid #900;">'.$rpt2.'</td></tr>';
        }else {
          $html=$css.'<table class="table table-bordered table-sm">';
          if($ac1 && $ac2) $html.='<tr><td class="showborder" width="350">'.$rpt1.'</td></tr><tr style="page-break-inside:avoid;"><td class="showborder" width="350">'.$rpt2.'</td></tr>';
          elseif ($ac1 && !$ac2) $html.='<tr><td class="showborder" width="350">'.$rpt1.'</td></tr>';
          else $html.='<tr><td class="showborder" width="350">'.$rpt2.'</td></tr>';
        } $html.='</table>';
    }/* $pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
    $pdf->Output("FeesReport.pdf","I");*/echo $html;
    mysqli_close($conn);
?>
