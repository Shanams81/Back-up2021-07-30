<?php
	include_once('../../conn/pri_sch_connect.inc');
	include_once('tcpdf_include.php');
	include_once('../tpl/printing.tpl');
	$imp=isset($_REQUEST['impno'])?strip_tags($_REQUEST['impno']):"0";
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('Imprest');
	$pdf->SetSubject('Imprest');
	$pdf->SetKeywords('Shanam, Digital, Solutions, Imprest, Voucher');
	//setting footer
	$pdf->setFooterData(array(0,64,0), array(0,64,128));
	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	// set default monospaced font
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
	// set margins
	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
	// set auto page breaks
	$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
	// set image scale factor
	$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
		require_once(dirname(__FILE__).'/lang/eng.php');
		$pdf->setLanguageArray($l);
	}
	// set default font subsetting mode
	$pdf->setFontSubsetting(true);
	// Add a page
	$pdf->AddPage();
	//Query balances
	$sql="SELECT i.idno,concat(s.surname,' ',s.onames) as st_names,i.cudate,i.rmks,i.amt,i.reqno FROM acc_imp i INNER JOIN stf s USING (idno) WHERE i.impno LIKE '$imp'";
	$rsImp=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsImp);
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,principal FROM ss");
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$princ)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	$html='<style>table{border-collapse:collapse;}table,td,th{border:0.1px solid #fff;color:#000;font-size:12px;text-align:justify;line-height:150%;padding:2px;}
	td.s,th.s{border:0.5px dotted green;}</style>';
	$a=1;
	list($idno,$nam,$date,$rmks,$amt,$reqno)=mysqli_fetch_row($rsImp);
	if ($nor>0){
		$html.='<table width="850"><tr><td rowspan="3" width="90"><img src="/gen_img/logo.jpg" width="70" height="70" vspace="1" hspace="1"></td>
		<td style="font-weight:bold;letter-spacing:2px;word-spacing:3px;" colspan="2">'.$scnm.'</td></tr><tr><td style="font-weight:bold;" colspan="2">'.$scadd.'</td></tr><tr><td
		style="font-weight:bold;">IMPREST FORM</td><td align="right">Printed On: '.date("D d-M-Y").'</td></tr><tr><td colspan="3"><hr></td></tr>';
		$html.='<tr><td align="left" colspan="2">Imprest No. <b><u>'.$imp.'</u></b></td><td align="right">Issued On: <u>'.date("D d M, Y",strtotime($date)).'</u></td></tr>';
		$rsItems=mysqli_query($conn,"SELECT i.itemname,i.units,r.approvedup,r.approvedqty,(r.approvedup*r.approvedqty) as Amt FROM acc_reqitems r Inner Join items i USING (itmcode) WHERE
		r.reqno=$reqno Order By i.itmcode Asc"); 	$noitm=mysqli_num_rows($rsItems);	$sum=0;
		$html.='<tr><td colspan="3"><br><br>Bursar/ Accounts Clerk,<br><br>You are hereby authorized to issued to '.$nam.' ID No. '.$idno.' the sum of Kenya shillings (Kshs.) '.
		number_format($amt,2).' in respect of an imprest for <b>'.$rmks.($noitm>0?'</b> of the following item(s):-':'</b>.').'</td></tr><tr><td colspan="3" align="center">';
		if ($noitm>0){
		 	$html.='<table class="s" width="100%"><tr><th class="s" width="30"><b>S/N</b></th><th class="s" width="250"><b>Item Description</b></th><th class="s" width="100"><b>Units</b>
			 </th><th class="s" width="70"><b>Unit Price</b></th><th class="s" width="60"><b>Quantity</b></th><th class="s" width="90"><b>Amount</b></th></tr>'; $a=1;
			while (list($item,$unit,$up,$qty,$ttl)=mysqli_fetch_row($rsItems)){
			 	$html.='<tr><td align="center" class="s">'.$a.'</td><td class="s">'.$item.'</td><td class="s">'.$unit.'</td><td align="right" class="s">'.number_format($up,2).'</td><td
				align="right" class="s">'.number_format($qty,2).'</td><td align="right" class="s">'.number_format($ttl,2).'</td></tr>';	 $sum+=$ttl;	$a++;
			}
			$html.='<tr><td colspan="3" class="s"><b>'.$noitm.' Imprest Item(s)</b></td><td colspan="2" align="right" class="s"><b>Total (Kshs.)</b></td><td align="right" class="s"><b>'.
			number_format($sum,2).'</b></td></tr></table>';
		}	mysqli_free_result($rsItems);
		$html.='</td></tr><tr><td colspan="3"><br><br><br>Signature _________________________________ Date ___________________</td></tr><tr><td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk<br><br><br><br><br>Authorized By
		_________________________	Date __________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.
		$princ.'<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><u>PRINCIPAL/ SECRETARY BOM</u></b><br>
		<br></td></tr>';
		$html.='<tr><td colspan="3"><br>I, <u>'.$nam.'</u>, ID No. <u>'.$idno.'</u> acknowledge to have received an imprest of the sum of Kshs. '.number_format($amt,2).' ('.
		NumToWord(preg_replace("/\,/","",number_format($amt,2))).')  which I hereby undertake to account for in full on or before <u>'.date('D d M, Y',strtotime($date.'+3 days')).'.</u> In
		the event of my failure to account for the imprest on or before the specified date, the director/ principal is authorised to recover the amount of imprest from my salary.</td>
		</tr><tr><td colspan="3"><br>.</td></tr>';
		$html.='<tr><td colspan="3">Signature _________________________ ID/Passport No. ______________________ Date __________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Imprest Holder</td></tr></table>';
	}$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
	$pdf->Output("FeesReport.pdf","I");
	mysqli_close($conn);
?>
