<?php
	include_once('../../conn/pri_sch_connect.inc'); 	include_once('tcpdf_include.php'); 	include_once('../tpl/printing.tpl');
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);	$pdf->SetCreator(PDF_CREATOR); 		$pdf->SetAuthor('Shanam\'s Digital Solutions');
	$pdf->SetTitle('Fee Notices');			$pdf->SetSubject('Fee Notices');	$pdf->SetKeywords('Shanam, Digital, SOlutions, Fee Notices');
	$pdf->setFooterData(array(0,64,0), array(0,64,128)); 	$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
	$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);	$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
	$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);	$pdf->SetFooterMargin(PDF_MARGIN_FOOTER); $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM); $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
	// set some language-dependent strings (optional)
	if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {require_once(dirname(__FILE__).'/lang/eng.php');	$pdf->setLanguageArray($l);	}
	// set default font subsetting mode
	$pdf->setFontSubsetting(true); $pdf->AddPage();
	mysqli_multi_query($conn,"SELECT scnm,concat(scadd,' Tel No. ',telno) as ad,finyr FROM ss; SELECT abbr FROM terms t Inner Join ss s USING (finyr) order By tno Asc;SELECT tno FROM terms
	WHERE curdate() between starts and ends"); $i=$tno=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0)list($scnm,$scad,$yr)=mysqli_fetch_row($rs);	elseif($i==1)while($d=mysqli_fetch_row($rs)) $terms[]=$d[0]; else list($tno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn)); $yr=isset($yr)?$yr:date('Y'); $rec=isset($_REQUEST['recno'])?strip_tags($_REQUEST['recno']):"0~%~%~%~".date('d-m-Y');	$rec=explode('~',$rec);
	$date=explode('-',$rec[4]); $date="$date[2]-$date[1]-$date[0]";
	//Query balances
	$sql="SELECT s.admno, s.stud_names, s.cls, if(((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+
	if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))) as t1bal, if(((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-
	if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))) as mt1bal,if((s.t2f-if(isnull(f.fee),0,
	f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee)-if((s.t1f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,f.fee))))) as t2bal, if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,
	(s.mt2f-if(isnull(f.mfee),0,f.mfee)-if((s.mt1f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt1f-if(isnull(f.mfee),0,f.mfee))))) as mt2bal, if((s.t3f-if(isnull(f.fee),0,f.fee))<=0,0,
	(s.t3f-if(isnull(f.fee),0,f.fee)-if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee))))) as t3bal, if((s.mt3f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt3f-
	if(isnull(f.mfee),0,f.mfee)-if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-if(isnull(f.mfee),0,f.mfee))))) as mt3bal,(s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,
	ar.uni,0)-if(isnull(f.fee),0,f.fee)) as ybal,((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee)) as mybal,if(isnull(f.amtpaid),0,
	f.amtpaid) as paid,if(isnull(f.prep),0,f.prep) as prepaid, if(isnull(f.ref),0,f.ref) as refunds FROM (SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,
	'-',c.stream) As cls, s.curr_year, sum(if(v.acc=1,cf.T1,0)) as t1f, sum(if(v.acc!=1,cf.T1,0)) as mt1f, sum(if(v.acc=1,cf.T2,0)) as t2f,sum(if(v.acc!=1,cf.T2,0)) as mt2f,sum(if(v.acc=1,
	cf.T3,0)) as t3f,sum(if(v.acc!=1,cf.T3,0)) as mt3f FROM  stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN clsfee cf USING (admno,
	curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY s.admno,s.surname,s.onames,s.curr_year,cn.clsname,c.stream,a.stud_assoc,
	s.present,s.markdel,cn.clsno HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$rec[3]' and cn.clsno LIKE '$rec[1]' and c.stream LIKE '$rec[2]')s INNER JOIN
	(SELECT	c.admno,sum(c.bbf) as arbf,sum(c.miscbf) as marbf,sum(c.spemed) as med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0
	end) as acspemed,sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM	acc_votesassigned)x GROUP BY admno,markdel HAVING admno LIKE '$rec[3]' and markdel=0)ar ON
	(s.admno=ar.admno) LEFT JOIN (SELECT f.admno,(if(isnull(sum(v.amt)),0,sum(v.amt-v.transfer))+if(isnull(sum(m.amt)),0,sum(m.amt-m.transfer))) as amtpaid, if(isnull(sum(v.prep)),0,
	sum(v.prep)) as prep,if(isnull(sum(v.refunds)),0,sum(v.refunds)) as ref,if(isnull(sum(v.arrears)),0,sum(v.arrears))as arrp,if(isnull(sum(v.spemed)),0,sum(v.spemed))as medp,
	if(isnull(sum(v.unifrm)),0,sum(v.unifrm))as unip,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm-v.transfer)) as fee,if(isnull(sum(m.arrears)),0,
	sum(m.arrears)) as marrp,if(isnull(sum(m.spemed)),0,sum(m.spemed))as mmedp,if(isnull(sum(m.unifrm)),0,sum(m.unifrm)) as munip,if(isnull(sum(m.amt)),0,sum(m.amt-m.arrears-m.spemed-m.unifrm
	-m.transfer)) as mfee	FROM stud s Inner Join	(SELECT sno,admno FROM acc_incofee WHERE markdel=0 and pytdate<='$date' and admno LIKE '$rec[3]')f USING (admno) left Join acc_incorecno0 v
	USING	(sno) Left	Join acc_incorecno1 m USING (sno) GROUP BY f.admno,s.Present HAVING s.Present=1)f on (s.admno=f.admno) ORDER BY s.cls,s.stud_names ASC";
	$rsBal=mysqli_query($conn, $sql);
	$css='<style>table.h{border:0.1px dotted #fff;page-break-inside:avoid;font-size:10pt;table-layout:fixed}td.h{border:0.1px dotted #fff;}th.h{border:0.1px dotted #fff;
		font-size:11pt;font-weight:bold;}';
	if($rec[0]==0) $css.='table.s{border:1px solid #00f;word-wrap:break-word}td.s{border:1px solid #00f;}th.s{border:1px solid #00f;font-size:11pt;font-weight:bold;}</style>';
	else $css.='table.s{border:1px solid #00f;word-wrap:break-word;font-size:10pt}td.s{border:1px solid #00f;}th.s{border:1px solid #00f;font-size:10pt;font-weight:bold;}</style>';
	if($rec[0]==1){$html=$css."<table width=\"680\" class=\"h\"><tr><th rowspan=\"3\" colspan=\"2\" width=\"90\" class=\"h\"><img src=\"../../gen_img/logo.jpg\" width=\"60\" height=\"50\"
		vspace=\"1\" hspace=\"1\"></th><th colspan=\"2\" class=\"h\" width=\"595\">$scnm</th></tr><tr><th colspan=\"2\" class=\"h\">$scad</th></tr><tr><th class=\"h\" width=\"410\">FEE BALANCE
		BALANCE AS ON ".strtoupper(date('D d M, Y',strtotime($date)))."</th><th class=\"h\"style=\"text-align:right;font-size:10pt;color:#666;\" width=\"185\">Printed	On: ".date("D d-M-Y").
		"</th></tr><tr><th class=\"s\"colspan=\"4\" width=\"380\">DETAILS OF THE STUDENT</th><th class=\"s\"colspan=\"4\" width=\"305\">FEE BALANCE ANALYISIS</th></tr><tr><th class=\"s\"
		width=\"30\">#</th><th class=\"s\" width=\"60\">AdmNo</th><th class=\"s\" width=\"200\">Names</th><th class=\"s\" width=\"90\">Form/Grade</th><th	class=\"s\"	width=\"75\">$terms[0]</th>
		<th class=\"s\" width=\"75\">$terms[1]</th><th class=\"s\" width=\"75\">$terms[2]</th><th width=\"80\" class=\"s\">Total Bal</th></tr></thead><tbody>";		$ttl=[0,0,0,0];
	}elseif($rec[0]==2){$html=$css."<table width=\"680\" class=\"h\"><tr><th rowspan=\"3\" width=\"90\" class=\"h\"><img src=\"../../gen_img/logo.jpg\" width=\"60\" height=\"50\"
		vspace=\"1\" hspace=\"1\"></th><th colspan=\"2\" class=\"h\" width=\"595\">$scnm</th></tr><tr><th colspan=\"2\" class=\"h\">$scad</th></tr><tr><th class=\"h\" width=\"410\">FEE BALANCE
		BALANCE AS ON ".strtoupper(date('D d M, Y',strtotime($date)))."</th><th class=\"h\"style=\"text-align:right;font-size:10pt;color:#666;\" width=\"185\">Printed	On: ".date("D d-M-Y").
		"</th></tr><tr><th class=\"s\" colspan=\"4\" width=\"580\">DETAILS OF THE STUDENT</th><th class=\"s\"rowspan=\"2\" width=\"100\">".$terms[$tno-1]." BALANCE</th></tr><tr><th
		class=\"s\" width=\"40\">#</th><th class=\"s\" width=\"80\">Adm. No.</th><th class=\"s\" width=\"360\">Names</th><th class=\"s\" width=\"100\">Form/Grade</th></tr><tbody>";
		$ttl=0;
	}$c=1;
	while($data=mysqli_fetch_row($rsBal)){
		if($rec[0]==0){
			$html=$css."<table width=\"680\" class=\"h\"><tr><th rowspan=\"3\" width=\"70\" class=\"h\"><img src=\"/gen_img/logo.jpg\" width=\"60\" height=\"50\" vspace=\"1\" hspace=\"1\"></th>
			<th colspan=\"2\" class=\"h\" width=\"610\">$scnm</th></tr><tr><th colspan=\"2\" class=\"h\">$scad</th></tr><tr><th class=\"h\">FEE BALANCE NOTIFICATION</th><th class=\"h\"
			style=\"text-align:right;font-size:10pt;color:#666;\">Printed	On: ".date("D d-M-Y")."</th></tr>";
	    $html.="<tr class=\"nohover\"><td colspan=\"3\" class=\"h\"><hr>Dear Parent/Guardian,<br><br><u><b>$data[1]</b></u> Admission No. <u>$data[0] </u> in form/grade <u>$data[2]</u> has
			the	following balances as on ".date('D d M, Y',strtotime($date))."<br>";
			$html.="<br><table class=\"s\"><tr><th class=\"s\">$terms[0] Balance</th><th class=\"s\">$terms[1] Balance</th><th class=\"s\">$terms[2] Balance</th><th class=\"s\">Total Year's
			Balance</th></tr><tr><td class=\"s\"	align=\"right\">".number_format(($data[3]+$data[4]),2)."</td><td class=\"s\" align=\"right\">".number_format(($data[5]+$data[6]),2)."</td><td
			class=\"s\"	align=\"right\">".number_format(($data[7]+$data[8]),2)."</td><td class=\"s\" align=\"right\">".number_format(($data[9]+$data[10]),2)."</td></tr></table><br>Having paid
			the sum of Kshs.<u><b> ".number_format($data[11],2)."</b></u> with refundable sum of Kshs.  <u><b>".number_format($data[13],2)."</b></u>	and prepaid the sum of Kshs.<u><b> ".
			number_format($data[12],2)."</b></u>.</td></tr>";
			$html.="<tr><td colspan=\"3\" class=\"h\" style=\"font-size:10px;letter-spacing:1px;word-spacing:2px;\"><br><br><br>___________________________<br>ACCOUNTS CLERK/ BURSAR</td></tr>";
			$html.="<tr><td colspan=\"3\" class=\"h\" style=\"font-size:10px;letter-spacing:1px;word-spacing:2px;\"><br><hr>Designed By: Shanam's Digital Solutions, Tel No. +254736732168</td>
			</tr></table><br><hr style=\"border:0.5px dotted #00f;background-color:#fff;height:2px;\"><br>";
			$pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
		}elseif($rec[0]==1){
			$html.="<tr><td class=\"s\">$c</td><td class=\"s\">$data[0]</td><td class=\"s\">$data[1]</td><td class=\"s\">$data[2]</td><td class=\"s\" align=\"right\">".number_format(($data[3]+
			$data[4]),2)."</td><td class=\"s\" align=\"right\">".number_format(($data[5]+$data[6]),2)."</td><td class=\"s\" align=\"right\">".number_format(($data[7]+$data[8]),2)."</td>
			<td class=\"s\" align=\"right\"><b>".number_format(($data[9]+$data[10]),2)."</b></td></tr>"; $ttl[0]+=($data[3]+$data[4]);$ttl[1]+=($data[5]+$data[6]);$ttl[2]+=($data[7]+$data[8]);
			$ttl[3]+=($data[9]+$data[10]); $c++;
		}else{
			$bal=($tno==1?($data[3]+$data[4]):($tno==2?($data[3]+$data[4]+$data[5]+$data[6]):($data[9]+$data[10])));
			$html.="<tr><td class=\"s\">$c</td><td class=\"s\">$data[0]</td><td class=\"s\">$data[1]</td><td class=\"s\">$data[2]</td><td class=\"s\" align=\"right\">".number_format($bal,2)."</td>
			</tr>"; $ttl+=$bal; $c++;
		}
	} mysqli_free_result($rsBal);  //Display data
	if($rec[0]==1 || $rec[0]==2){
		$html.="</tbody><tfoot><tr><th class=\"s\" align=\"right\" colspan=\"4\">Total Balance</th>";
		if($rec[0]==1) $html.="<th class=\"s\" align=\"right\">".number_format($ttl[0],2)."</th><th class=\"s\" align=\"right\">".number_format($ttl[1],2)."</th><th class=\"s\" align=\"right\">".
		number_format($ttl[2],2)."</th><th class=\"s\" align=\"right\">".number_format($ttl[3],2)."</th></tr>";
		else $html.="<th class=\"s\" align=\"right\">".number_format($ttl,2)."</th></tr>";
		$html.="</tfoot></table>";
		 $pdf->writeHTML($html, true, false, true, false, ''); $pdf->lastPage();
		 $pdf->Output("feebalstatus.pdf","I");
	 }else $pdf->Output("feebalancenotice.pdf","I");
	mysqli_close($conn);
?>
