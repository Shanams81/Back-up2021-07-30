<?php
    include_once('shanam.php');
    $opt=$reqno=$deptno=$stfid=$accvote=$voteno=0;
    if (isset($_POST['CmdSave'])){
        $act=isset($_POST['txtNo'])?sanitize($_POST['txtNo']):"0-0";              $act=preg_split("/\-/",$act); 	//0 - Option, 1 - Requision No.
        $deptno=isset($_POST['cboDept'])?sanitize($_POST['cboDept']):0;           $ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0; $accvote=$ac;
        $date=isset($_POST['txtDate'])?sanitize($_POST['txtDate']):date('Y-m-d'); $itmcode=isset($_POST['cboItem'])?sanitize($_POST['cboItem']):0;
        $up=isset($_POST['txtUP'])?sanitize($_POST['txtUP']):0;                   $qty=isset($_POST['txtQty'])?sanitize($_POST['txtQty']):0;
        $uniqid=isset($_POST['txtNewReq'])?sanitize($_POST['txtNewReq']):0;       $stfid=isset($_POST['cboStf'])?sanitize($_POST['cboStf']):0;
        $qty=preg_replace("/[^0-9^\.]/","",$qty); $up=preg_replace("/[^0-9^\.]/","",$up);         $opt=1;
        $reqtype=isset($_POST['cboType'])?sanitize($_POST['cboType']):"URGENT";   $date=preg_split('/\-/',$date); $date="$date[2]-$date[1]-$date[0]";
        $rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtRmks']))):''; $addby=$_SESSION['username']." (".$_SESSION['priviledge'].")";
        //details of the new items
        $r=isset($_POST['txtReqNo'])?sanitize($_POST['txtReqNo']):'0-0-0'; $r=preg_split('/\-/',$r);
        $itmname=isset($_POST['txtItem'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtItem']))):"";
        $units=isset($_POST['cboUnits'])?strtoupper(sanitize($_POST['cboUnits'])):"PIECES";
        $voteno=isset($_POST['cboVote'])?strtoupper(sanitize($_POST['cboVote'])):0;
        $max=isset($_POST['txtMax'])?sanitize($_POST['txtMax']):0;                  $max=preg_replace("/[^0-9^\.]/","",$max);
        $categ=isset($_POST['cboCateg'])?strtoupper(sanitize($_POST['cboCateg'])):"Consumable";
        $min=isset($_POST['txtMin'])?sanitize($_POST['txtMin']):0;                  $min=preg_replace("/[^0-9^\.]/","",$min);
        $itmdept=isset($_POST['cboUserDept'])?sanitize($_POST['cboUserDept']):0;    $itmdept=($itmdept==0?Null:$itmdept);
        if($_SESSION['newReq']==$uniqid){
            unset($_SESSION['newReq']);
            if ($itmcode==0 && strlen($itmname)>3 && $max>0 && $min>0 && $up>0 && strlen($categ)>2){//new item
                $mx=$itmcode=0;
                while($itmcode===0){
                    $rs=mysqli_query($conn,"SELECT max(itmcode) as mx FROM items;");    if(mysqli_num_rows($rs)>0) list($mx)=mysqli_fetch_row($rs); mysqli_free_result($rs); $mx++;
                    $sql="INSERT INTO items(itmcode,itemname,categ,deptno,units,maxstock,minstock,currstock,unitprice,addedon,addedby) VALUES ($mx,".var_export($itmname,true).",
                    '$categ',".var_export($itmdept,true).",'$units',$max,$min,0,$up,curdate(),'".$_SESSION['username']." (".$_SESSION['priviledge'].")');";
                    if(mysqli_query($conn,$sql) or die(mysqli_error($conn)."<br> Click <a href=\"requisition.php\">HERE</a> to try again.")){
                        $itmcode=$mx; $sql='';
                        if($act[0]==0) $sql="INSERT INTO itemvote(itmcode,ac,voteno) VALUES ($itmcode,$ac,$voteno);";
                        else $sql="INSERT INTO itemvote(itmcode,ac,voteno) VALUES ($itmcode,$r[2],$voteno);";
                        mysqli_query($conn,$sql);
                    }
                }
            }if($act[0]==0 && $act[0]==0 && $deptno>0 && $ac>0 && $up>0 && $qty>0 && strlen($stfid)>4 && strlen($rmks)>10){//New Requision save acc_req
              $mx=$reqno=0;
              while($reqno==0){
                  $rs=mysqli_query($conn,"SELECT max(reqno) as mx FROM acc_req;");    if(mysqli_num_rows($rs)>0) list($mx)=mysqli_fetch_row($rs); mysqli_free_result($rs); $mx++;
                  if(mysqli_query($conn,"INSERT INTO acc_req(reqno,reqdate,idno,acc,deptno,rmks,reqtype,forwarddate,forwardby,forwardrmks,forwarded) VALUES ($mx,'$date','$stfid','$ac',
                  '$deptno',".var_export($rmks,true).",'$reqtype',curdate(),'$addby','Forwarded for approval',1)") or die(mysqli_error($conn)."<br> Click <a href=\"requisition.php\">
                  HERE</a> to try again.")){$reqno=$mx;}
              }
            }else{//New item on existing requisition
                $reqno=$r[0]; $deptno=$r[1];  $accvote=$r[2]; $stfid=$r[3];
            }$sql="INSERT INTO acc_reqitems (itmcode,reqno,unitprice,qty,approvedup,approvedqty) VALUES ($itmcode,$reqno,$up,$qty,$up,$qty)";
            mysqli_query($conn,$sql) or die(mysqli_error($conn)."<br>Requisition Item details were not saved. Click <a href=\"requisition.php\">Here</a> to try again.");
            $i=mysqli_affected_rows($conn);
            if ($i==0){//inacse item was previusly deleted and now added
              mysqli_query($conn,"UPDATE acc_reqitems SET unitprice=$up,qty=$qty,approvedup=$up,approvedqty=$qty, markdel=0 WHERE itmcode='$itmcode' and reqno='$reqno'") or
              die(mysqli_error($conn)."<br>Requisition Item details were not saved. Click <a href=\"requisition.php\">Here</a> to try again.");
              $i=mysqli_affected_rows($conn);
            }
            print "<span style=\"background-color:#0a0;color:#fff;margi:0 auto;letter-spacing:1px;word-spacing:2px;font-size:12pt;\">You have sucessfully added $i items on the
            requisition.</span>";
        }
    }else{
      $r=isset($_REQUEST['reqno'])?sanitize($_REQUEST['reqno']):'0-0-0-0-0';  $r=preg_split('/\-/',$r);
      if($r[4]==1){ $reqno=$r[0]; $deptno=$r[1];  $accvote=$r[2]; $stfid=$r[3]; $opt=2; }
    }mysqli_multi_query($conn,"SELECT idno,concat(surname,' ',onames,' (',designation,')') as name FROM stf WHERE markdel=0 and present=1 Order By surname,onames ASC; SELECT deptno,
    deptname FROM depts WHERE markdel=0; SELECT categ FROM grps WHERE categ IS NOT NULL or categ Not LIKE '' ORDER BY categ ASC; SELECT acno,abbr FROM acc_voteacs WHERE markdel=0 and
    imp_assoc=1; SELECT categ FROM grps WHERE categ IS NOT NULL or categ Not LIKE '' ORDER BY categ ASC; SELECT sno,acc,descr FROM acc_votes WHERE markdel=0 and pyt_defined=1 ORDER
    BY acc,descr ASC;");
    $i=0; $stf=$dept=$categ=$reqstf=$impacs=$cat=$lstVotes=$optvotes=''; $_SESSION['newReq']=$addid=uniqid();
    do{
       if($rs=mysqli_store_result($conn)){
          if($i==0){
             while (list($idn,$name)=mysqli_fetch_row($rs)){if($idn==$stfid) $reqstf.=$name; $stf.="<option value=\"$idn\">$name</option>";}
          }elseif($i==1){
            while(list($dno,$dnam)=mysqli_fetch_row($rs)){
              if($dno==$deptno) $reqstf.=' IN '.$dnam; $dept.="<option value=\"$dno\" ".($deptno==$dno?"selected":"").">$dnam</option>";
            }
          }elseif($i==2){
            while(list($cat)=mysqli_fetch_row($rs)) $categ.="<option value=\"$cat\">$cat</option>";
          }elseif($i==3){
            while(list($ac,$nam)=mysqli_fetch_row($rs))$impacs.="<option value=\"$ac\">$nam</option>";
          }elseif($i==4){while(list($ca)=mysqli_fetch_row($rs))$cat.="<option value=\"$ca\">$ca</option>";
          }else{
            $index=0;
            while($vo=mysqli_fetch_row($rs)){
              $lstVotes.=($index==0?"":",")."new Votes($vo[0],$vo[1],'$vo[2]')";
              if($accvote==$vo[1]) $optvotes.="<option value=\"$vo[0]\" ".($vo[0]==$voteno?"selected":"").">$vo[2]</option>";
              $index++;
            }
          } mysqli_free_result($rs);
       } $i++;
    }while(mysqli_next_result($conn));
    headings('<link href="tpl/css/inputsettings.css" type="text/css" rel="stylesheet"/><link href="/date/tcal.css" type="text/css" rel="stylesheet"/>',0,0,2);
?><div class="container" style="background-color:#e6e6e6;border-radius:15px 15px 0 0;margin:2px auto;width:fit-content;padding:0 5px;">
    <div class="form-row"><div class="col-md-12 divheadings" style="text-align:center;border-radius:15px 15px 0 0"><?php if($reqno>0) echo "<a href=\"reqedit.php?reqno=$reqno\"
    title=\"Edit Requisition\">REQUISITION $reqno:</a>"; ?> &nbsp;&nbsp;&nbsp;&nbsp; NEW REQUISITION MANAGER</div></div>
    <form method="post" action="reqadd.php" onsubmit="return validateFormOnSubmit(this)"><div class="conntainer" style="margin:10px auto;width:fit-content;">
    <div class="form-row"><div class="col-md-9"><input name="txtNewReq" id="txtNewReq" type="hidden" value="<?php echo $addid; ?>"><input name="txtReqNo"
      id="txtReqNo" type="hidden" value="<?php echo "$reqno-$deptno-$accvote-$stfid"; ?>">
      <?php if($opt==0){?>
        <div class="form-row">
            <div class="col-md-6"><label for="cboDept">Department Raising Request *</label><SELECT name="cboDept" id="cboDept" size="1" class="modalinput"
              onchange="loadItems(this,<?php echo $reqno;?>)" required><option value="0" selected>Choose Department</option><?php echo $dept;?></SELECT></div>
            <div class="col-md-4"><label for="cboAC">Votehead A/C to be Costed *</label><SELECT name="cboAC" id="cboAC" size="1" class="modalinput" required onchange="showVotes(this)">
              <option value="0" selected>Choose Account</option><?php echo $impacs;?></SELECT></div>
            <div class="col-md-2"><label for="txtDate">Date</label><input name="txtDate" id="txtDate" class="tcal modalinput" value="<?php echo date('d-m-Y');?>"></div>
        </div><div class="form-row">
          <div class="col-md-6"><label for="cboStf">Name of Staff Requisitioning *</label><SELECT name="cboStf" id="cboStf" size="1" class="modalinput" required><?php echo $stf;?>
          </SELECT></div>
          <div class="col-md-6"><label for="cboStf">Narration about Requisition *</label><textarea name="txtRmks" id="txtRmks" rows="2" class="modalinput" required></textarea></div>
        </div>
      <?php }?>  <input name="txtNo" type="hidden" value="<?php echo "$opt-$reqno";?>">
        <div class="form-row">
          <div class="col-md-4"><label for="cboType">Type of Request *</label><SELECT name="cboItem" id="cboItem" size="1" class="modalinput">
            <option value="NORMAL">Normal</option><option value="URGENT" selected>Urgent</option></select></div>
          <div class="col-md-8" id="divItems"><label for="cboItem">Item Requested *</label><SELECT name="cboItem" id="cboItem" size="4" class="modalinput" onchange="showNewItem(this)">
           <?php $noitms=0; if($deptno>0){
             $rs=mysqli_query($conn,"SELECT i.itmcode,concat(i.itemname,' - ',i.units,' @ Kshs.',i.unitprice) as nam FROM items i WHERE (i.deptno is null OR i.deptno LIKE '$deptno')
           	and i.markdel=0 and i.itmcode NOT IN (SELECT itmcode FROM acc_reqitems WHERE reqno LIKE '$reqno') Order By itemname ASC") or die(mysqli_error($conn).' Error in
            database connection');           	$i=0; $noitms=mysqli_num_rows($rs);
           	if ($noitms>0) while (list($no,$name)=mysqli_fetch_row($rs)){echo '<option value="'.$no.'" '.($i==0?"selected":"").'>'.$name.'</option>'; $i++;}
          }?><option value="0" <?php echo ($deptno==0?"Selected":"");?>>New Item</option></select></div>
        </div><div class="form-row" id="divNewItem" style="border-bottom:1px solid #66f;display:<?php echo (($opt==0 || $noitms==0)?"block":"none");?>;background-color:#d9ecf2;">
          <div class="col-md-12">
            <div class="form-row"><div class="col-md-12"><label for="txtItem">New Item Description</label><input type="text" name="txtItem" id="txtItem" maxlength="29"
              class="modalinput" value=""></div>
            </div><div class="form-row">
                <div class="col-md-4"><label for="cboVote">Votehead to be Costed</label><SELECT name="cboVote" id="cboVote" size="1" class="modalinput">
                <?php if($accvote>0) echo $optvotes; echo "<option value=\"0\" ".($accvote==0?"Selected":"").">Select Votehead</option>";?>
                </SELECT></div>
                <div class="col-md-4"><label for="cboUserDept">User Department of Item</label><SELECT name="cboUserDept" id="cboUserDept" size="1" class="modalinput"><option value="0"
                selected>General Use</option><?php echo $dept;?></SELECT></div>
                <div class="col-md-4"><label for="cboCateg">Item Category *</label><SELECT name="cboCateg" id="cboCateg" size="1" class="modalinput"><?php echo $cat;?></select></div>
            </div>
            <div class="form-row"><div class="col-md-4"><label for="cboUnits">Units of Measure</label><SELECT name="cboUnits" id="cboUnits" size="1" CLASS="modalinput" required><option
              value="Pieces">Pieces</option><option value="crates">Crates</option><option value="Dozen">Dozen</option><option value="Grams">Grams</option><option value="Hours">Hours
              </option><option value="Days">Days</option><option value="Months">Months</option><option value="Kg">Kg</option><option value="Litres">Litres</option><option value="Metres">
              Metres</option><option value="Packets">Packets</option><option value="Pairs">Pairs</option><option value="Persons">Persons</option><option value="Sets">Sets</option><option
              value="Reams">Reams</option><option value="Tonnes">Tonnes</option><option value="Bag">Bag</option><option value="Bales">Bales</option></select></DIV>
              <div class="col-md-4"><label for="txtMax">Max. Stock Level *</label><Input name="txtMax" id="txtMax" type="text" value="1" maxlength="10" class="modalinput numbersinput"
              onkeyup="checkInput(this)" required="required"></div>
              <div class="col-md-4"><label for="txtMax">Min. Stock Level *</label><Input name="txtMin" id="txtMin" type="text" value="10" maxlength="10"  class="modalinput numbersinput"
              onkeyup="checkInput(this)" required="required"></div>
            </div>
          </div>
        </div><div class="form-row" style="margin-bottom:5px;">
          <div class="col-md-4"><label for="txtQty">Quantity Requested *</label><input type="text" name="txtQty" id="txtQty" required maxlength="10"  value="1" onkeyup="checkInput(this)"
          onblur="calcAmt()" class="modalinput numbersinput"></div>
          <div class="col-md-4"><label for="txtUP">Quoted Unit Price</label><INPUT name="txtUP" id="txtUP" required class="modalinput numbersinput" maxlength="10" value="10.00"
          onkeyup="checkInput(this)" onblur="calcAmt()"></div>
          <div class="col-md-4 divsubheading"><label for="txtTtl">TOTAL AMOUNT</label><input type="text" name="txtTtl" id="txtTtl" class="modalinput modalinputdisabled numbersinput"
          value="10.00" readonly></div>
        </div>
      </div><div class="col-md-3"><br><br><br>
          <div class="form-row"><div class="col-md-12"><button type="submit" name="CmdSave" id="save" class="btn btn-primary btn-block btn-lg">Save Details</button></div></div><br>
          <br><br><div class="form-row"><div class="col-md-12"><button onclick="window.open('requisition.php','_self')" type="button" name="CmdClose" class="btn btn-info btn-block btn-lg">
          Close</button>
          </div></div>
      </div></div>
    </div><div class="form-row">
      <div class="col-md-12" style="overflow-y:scroll;max-height:300px;">
        <table class="table table-striped table-sm table-hover"><thead class="thead-dark"><tr><th colspan="6">REQUISITION BY <?php echo strtoupper($reqstf);?></th></tr><tr><th>
          #</th><th>ITEM DESCRIPTION</th><th>QUANTITY</th><th>UNIT PRICE</th><th>TOTAL</th><th>ADMIN ACTION</th></tr></thead>
        <?php
            $rs=mysqli_query($conn,"SELECT r.itmcode,r.reqno,concat(i.itemname,' <em>(MEASURED IN ',i.units,')</em>') as nam,r.approvedup, r.approvedqty,(r.approvedup*r.approvedqty) as
            pamt FROM acc_reqitems r  Inner Join items i USING (itmcode) WHERE (r.markdel=0 and r.reqno='$reqno') ORDER BY i.itemname ASC;");   $ttl=0; $i=1;
            while ((list($itmcode,$reqno,$name,$up,$qty,$amt)=mysqli_fetch_row($rs))):
                print "<td>$i</td><td>$name</td><td align=\"right\">".number_format($qty,2)."</td><td align=\"right\">".number_format($up,2)."</td><td align=\"right\"><b>".
                number_format($amt,2)."</b></td><td align=\"center\"><a href=\"reqitemedit.php?action=$itmcode-$reqno\">Edit</a></td></tr>";
                $i++; $ttl+=$amt;
            endwhile;
            mysqli_free_result($rs);
            print "<tr><td colspan=\"4\" style=\"text-align:right;font-weight:bold;\">Total Budget (Kshs.)</td><td style=\"text-align:right;font-weight:bold;\">".
            number_format($ttl,2)."</td><td></td></tr></table>";
        ?>
      </div>
    </div>
</div>
<script type="text/javascript" src="tpl/js/reqadd.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<?php
  if(strlen($lstVotes)>0) echo "<script type=\"text/javascript\">votes.push($lstVotes);</script>";
  mysqli_close($conn); footer();
?>
<script type="text/javascript">
    $(document).ready(function(){//for sorting the units of sale
       var opt=$("#cboUnits option").sort(function(a,b){return a.value.toUpperCase().localeCompare(b.value.toUpperCase())});
       $("#cboUnits").append(opt);
    });
</script>
