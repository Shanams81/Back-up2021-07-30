<?php
	session_start();
	include_once("../conn/pri_sch_connect.inc");
	if(isset($_POST['CmdSave'])){
	 	$reqno=isset($_POST['TxtReqNo'])?trim(strip_tags($_POST['TxtReqNo'])):0;	 	$amt=isset($_POST['TxtAmt'])?trim(strip_tags($_POST['TxtAmt'])):0;
	 	$per=isset($_POST['CboPeriod'])?trim(strip_tags($_POST['CboPeriod'])):0;		$amtper=isset($_POST['TxtAmtPerDur'])?trim(strip_tags($_POST['TxtAmtPerDur'])):0;
	 	$rmks=isset($_POST['TxtRmks'])?strtoupper(trim(strip_tags($_POST['TxtRmks']))):0;
	 	if ((strlen($amt)==0) || (strlen($per)==0) || (strlen($rmks)<10)){
			print "SERVER ERROR <font color=\"#cc0000\">Ensure salary advance amt, recovery period and reason are validly entered before saving</font><br>";
		}else{
			$amt=preg_replace("/[^0-9^\.]/","",$amt);	$amtper=preg_replace("/[^0-9^\.]/","",$amtper); if ($amtper<($amt/$per)) $amtper=ceil(($amt/$per));
			mysqli_query($conn,"UPDATE acc_advreq SET rmks='$rmks',amt='$amt',ded_period='$per',amtperded='$amtper' WHERE reqno LIKE '$reqno'") or
			die(mysqli_error($conn)." Sorry, salary advance request was not fowarded successfully. Click <a href=\"saladvreq.php\">Here</a> to go back.");
			$i=mysqli_affected_rows($conn); if ($i==1) header("location:advreqaction.php?adv=$reqno-1"); else header("location:saladvreq.php?action=0-0");
		}	exit(0);		
	}
	$adno=$_REQUEST['advno'];
	$rsAdv=mysqli_query($conn,"SELECT r.reqno,r.reqdate,r.amt,r.ded_period,r.amtperded,r.rmks,sd.idno,sd.payrollno FROM acc_advreq r Inner Join acc_saldef sd USING
	(payrollno) WHERE r.reqno LIKE '$adno'");
	list($reqno,$reqdate,$amt,$dedper,$amtper,$rmks,$idn,$payno)=mysqli_fetch_row($rsAdv); mysqli_free_result($rsAdv);
	$rsStf=mysqli_query($conn,"SELECT concat(s.surname,' ',s.onames,' (',s.designation,')') as nam,((sd.bsal+sd.houseallow+sd.travellallow+sd.medicalallow)-(sd.nssffee+
	sd.nhiffee+sd.taxes+sd.unionfee+sd.otherlevies)) as gs FROM stf s Inner Join acc_saldef sd USING (idno) WHERE s.idno LIKE '$idn'");
	list($nam,$gs)=mysqli_fetch_row($rsStf); mysqli_free_result($rsStf);
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Salary Advance Manager</title>
	<script type="text/javascript" src="../self/tpl/saladvreq.js"></script>
</head>
<body background="img/bg3.gif">
	<?php
		print "<br><br><form name=\"frmAdvReq\" method=\"Post\" action=\"advreqeditor.php\" onsubmit=\"return validateFormOnSubmit(this)\"><table align=\"center\"
		cellspacing=\"0\" cellpadding=\"2\" border=\"1\"><tr><td><input type=\"hidden\" name=\"TxtReqNo\" value=\"$reqno\"><table align=\"center\" cellspacing=\"3\"
		cellpadding=\"5\" border=\"0\" style=\"font-size:11pt;font-color:#0000dd\"><tr><td bgcolor=\"#ff00cc\">Staff ID No. <b>$idn</b> Payroll No. <b>$payno</b>
		With Gross Salary of Kshs.".number_format($gs,2)."</td></tr>";
		print "<tr><td>".ucwords(strtolower($nam)).", requested the sum of Kshs. <input name=\"TxtAmt\" id=\"TxtAmt\" size=\"10\" maxlength=\"8\"
		value=\"$amt\" style=\"text-align:right;font-weight:bold;\" value=\"0.00\" onkeyup=\"checkInput(this)\" onChange=\"Compute(this)\"> as salary</td></tr>";
		print "<tr><td>advance on ".date('l j, F Y',strtotime($reqdate)).". The salary advance is to be recovered in";
		print "<Select name=\"CboPeriod\" size=\"1\" id=\"CboPeriod\"  onkeyup=\"checkInput(this)\" onChange=\"Compute(this)\">";
		$m=(int)date('m'); $m=13-$m; for ($i=1;$i<=$m;$i++) print "<option ".($i==$dedper?"selected":"").">$i</option>";
		print "</select> month(s) </td></tr><tr><td>at a rate of Kshs. <input name=\"TxtAmtPerDur\" id=\"TxtAmtPerDur\" size=\"10\" maxlength=\"8\"  value=\"$amtper\"
		style=\"text-align:right;font-weight:bold;\"> a month from his/ her salary.</td></tr>";
		print "<tr><td valign=\"top\">Reason given for salary advance is <textarea name=\"TxtRmks\" cols=\"70\" rows=\"3\">$rmks</textarea></td></tr><tr
		bgcolor=\"#ff00cc\"><td align=\"center\"><button name=\"CmdSave\" type=\"submit\">Update Request</button> &nbsp;&nbsp;&nbsp;&nbsp;<a href=\"saladvreq.php\">
		<button type=\"button\" name=\"CmdClose\">Close</button></a></td></tr></table>";
		print "</td></tr></table>";
		mysqli_close($conn);
	?></h2>
</body>
</html>
