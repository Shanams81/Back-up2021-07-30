<?php
	include_once('shanam.php');
	$reqno=isset($_REQUEST['reqno'])?$_REQUEST['reqno']:'0'; $reqno=preg_split('/\-/',$reqno);
	if ($reqno[1]==1){//requisition approval
		$date=date('Y-m-d'); $yr=date('Y'); $app=$_SESSION['priviledge'];
		mysqli_multi_query($conn,"INSERT INTO acc_imp(impno,acc,cudate,idno,rmks,approvedby,reqno,amt) SELECT 0,r.acc,curdate(),r.idno,r.rmks,'Principal','$reqno[0]',
		sum(i.approvedup*i.approvedqty) as amt FROM acc_req r Inner Join acc_reqitems i USING (reqno) GROUP BY r.reqno,r.idno,r.rmks,i.markdel HAVING i.markdel=0
		and r.reqno LIKE '$reqno[0]'; UPDATE acc_req SET approved='1',approvedrmks='Successfully approved',approvedate='$date',approvedby='$app' WHERE reqno LIKE '$reqno[0]'") or
		die(mysqli_error($conn). " Click <a href=\"requisition.php\">here</a> to try again.");
		$i=mysqli_affected_rows($conn); while(mysqli_next_result($conn)){}
	}elseif ($reqno[1]==2){//Unapproving approved requisition
		mysqli_query($conn,"UPDATE acc_req SET approved=0,approvedby=null,approvedrmks=null,approvedate=null WHERE reqno LIKE '$reqno[0]'") or die(mysqli_error($conn).
		" Sorry, the requisition failed to be successfully restored. Click <a href=\"requisition.php\">Here</a> to go back.");
		$i=mysqli_affected_rows($conn);
		if ($i>0)	mysqli_query($conn,"UPDATE acc_imp SET reqno=null,markdel=1,delreason=concat('Requisition $reqno associated with imprest was unapproved on ',curdate()) WHERE reqno
		LIKE '$reqno[0]'");
	}else{ //restoring rejected requisition
		mysqli_query($conn,"UPDATE acc_req SET approved=0,delreason=null,approvedate=null,approvedby WHERE reqno LIKE '$reqno[0]'") or die(mysqli_error($conn)." Sorry, the requisition failed to be successfully
		restored. Click <a href=\"requisition.php\">Here</a> to go back.");
		$i=mysqli_affected_rows($conn);
		if ($i==1) mysqli_query($conn,"UPDATE acc_reqrej SET markdel=1 WHERE reqno LIKE '$reqno[0]'") or die(mysqli_error($conn)." Sorry, the rejection not successfully. Click <a
			href=\"requisition.php\">Here</a> to go back.");
	}mysqli_close($conn);
	header("location:requisition.php?action=1-$i");
?>
