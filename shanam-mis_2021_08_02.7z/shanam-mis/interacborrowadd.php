<?php
	include_once('shanam.php');
	$rs=mysqli_query($conn,"SELECT borroadd FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'"); 	$canadd=0;
	if(mysqli_num_rows($rs)==1) list($canadd)=mysqli_fetch_row($rs); 	mysqli_free_result($rs);
	if ($canadd==0){header("location:vague.php"); exit(0);}	$act=0;//begining
	class BankACs{
		private $acsno,$acc,$bank,$bal;
		public function __construct($sn,$ac,$ba,$bl){$this->acsno=$sn; $this->acc=$ac; $this->bank=$ba; $this->bal=$bl;} public function valACSNo(){return $this->acsno;}
		public function valAcc(){return $this->acc;} public function valBank(){return $this->bank;} public function valBal(){return $this->bal;}
	}	if (isset($_POST['btnSave'])){
		$date=isset($_POST['txtDate'])?sanitize($_POST['txtDate']):date('d-m-Y'); $date=preg_split('/\-/',$date); $date=$date[2].'-'.$date[1].'-'.$date[0];
		$acdr=isset($_POST['cboACDebit'])?sanitize($_POST['cboACDebit']):0;				$bankdr=isset($_POST['cboSourceAC'])?sanitize($_POST['cboSourceAC']):0;
		$bal=isset($_POST['txtSourceBal'])?sanitize($_POST['txtSourceBal']):0; 		$bal=preg_replace('/[^0-9^\.]/',"",$bal);
		$accr=isset($_POST['cboACCredit'])?sanitize($_POST['cboACCredit']):0;			$bankcr=isset($_POST['cboDestAC'])?sanitize($_POST['cboDestAC']):-1;
		$mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'';						$modeno=isset($_POST['txtModeNo'])?strtoupper(sanitize($_POST['txtModeNo'])):'';
		$amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0; 								$amt=preg_replace('/[^0-9^\.]/',"",$amt);
		$camt=isset($_POST['txtCRDistr'])?sanitize($_POST['txtCRDistr']):0; 			$camt=preg_replace('/[^0-9^\.]/',"",$camt);
		$damt=isset($_POST['txtDRDistr'])?sanitize($_POST['txtDRDistr']):0; 			$damt=preg_replace('/[^0-9^\.]/',"",$damt);
		$token=isset($_POST['txtToken'])?sanitize($_POST['txtToken']):0;					$addedby=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtRmks']))):'';	$err='';
		//data validation
		if ($amt<=$bal && $amt>1000 && $acdr!=$accr && $bankdr!=$bankcr && $acdr!=0 && $accr!=0 && strlen($modeno)>2 && strlen($rmks)>9 && $_SESSION['token']==$token && $amt==$camt
		&& $amt==$damt){//save the record
			if(mysqli_query($conn,"INSERT INTO acc_interacborrow(interb_no,interb_date,sourceac,debitacno,destac,creditacno,rmks,mode,modeno,amt,addedby) VALUE (0,'$date','$acdr',
			'$bankdr','$accr','$bankcr',".var_export($rmks,true).",'$mode','$modeno',$amt,'$addedby')") or die(mysqli_error($conn))){
			 	$bno=mysqli_insert_id($conn);
			 	mysqli_query($conn,"INSERT INTO acc_banking(sno,transdate,bank_type,acsno,cheno,amt,transtype,transno,rmks,addedby) VALUES (0,'$date',1,$bankdr,'$modeno',$amt,6,
				$bno,'Inter account fund transfer','$addedby'),(0,'$date',0,$bankcr,'$modeno',$amt,6,$bno,'Inter account fund transfer','$addedby');") or die(mysqli_error($conn).
				".  Bank Debiting/ Crediting error."); $ino=mysqli_insert_id($conn);  $rno=0;
				//income to the receiving account
			 	if ($accr<3){
					if (mysqli_query($conn,"INSERT INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,commt,interb_no,verno,verdate,verstate,verbanked,addedby) VALUES(0,
					'I-$bno','$date','Interborrow','$mode',".var_export($modeno,true).",$bankcr,'1',$bno,$ino,'$date',1,1,'$addedby')") or die(mysqli_error($conn).". Click <a
					href=\"interacborrow.php\">HERE</a> to try again.")){
						$sno=mysqli_insert_id($conn);
						if($accr==1) $sql="INSERT INTO acc_incorecno0 (recno,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm) VALUES (0,$sno,1,0,$amt,0,0,0,0,1);";
						else $sql="INSERT INTO acc_incorecno1 (recno,sno,acc,bc,amt,arrears,spemed,unifrm) VALUES (0,$sno,'$accr',0,$amt,0,0,0);";
						if(mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"interacborrow.php\">HERE</a> to try again."))	$rno=mysqli_insert_id($conn);
					}
				}else{
					if(mysqli_query($conn,"INSERT INTO acc_fseincome (recno,noofstud,recon,batchno,acc,acsno,amt,mode,modeno,rmks,commt,interb_no,verno,verdate,verstate,verbanked,addedby)
					VALUES(0,1,'$date',1,'$accr','$bankcr',$amt,'$mode','$modeno','$rmks',1,$bno,$ino,'$date',1,1,'$addedby')") or die(mysqli_error($conn).". FSE Account fee reciept	error"))
					$rno=mysqli_insert_id($conn);
				}
				//payout the inter account fund transfer
				mysqli_multi_query($conn,"SELECT payno FROM acc_exppayee WHERE payee IN (SELECT scnm FROM ss); SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '$acdr';");
				$i=$payno=0;
				do{
						if($rs=mysqli_store_result($conn)){
								if($i==0){ if(mysqli_num_rows($rs)>0) list($payno)=mysqli_fetch_row($rs);
								}else{ if(mysqli_num_rows($rs)>0) list($vono)=mysqli_fetch_row($rs);}		mysqli_free_result($rs);
						}$i++;
				}while(mysqli_next_result($conn)); $vono++;
				if($payno==0){//paye details are not in the system
						if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) SELECT 0,curdate(),scnm,null,scadd,telno,'$addedby' FROM ss")){
							$payno=mysqli_insert_id($conn);}
				}$cvalues=$dvalues=''; $ccount=$dcount=$voteno=0;
				//voteahead distributions
				for($i=0;$i<4;$i++){
					$dval=isset($_POST["txtAmt_$i"])?sanitize($_POST["txtAmt_$i"]):0; 			$dval=preg_replace('/[^0-9^\.]/',"",$dval);
					$cval=isset($_POST["txtAmt1_$i"])?sanitize($_POST["txtAmt1_$i"]):0; 		$cval=preg_replace('/[^0-9^\.]/',"",$cval);
					$dvoteno=isset($_POST["cboVote_$i"])?sanitize($_POST["cboVote_$i"]):0;	$cvoteno=isset($_POST["cboVote1_$i"])?sanitize($_POST["cboVote1_$i"]):0;
					if($cval>0){$cvalues.=($ccount==0?"":",")."($rno,$accr,$cvoteno,$cval,0)";	$ccount++;}
					if($dval>0){$dvalues.=($dcount==0?"":",")."($vono,$acdr,$dvoteno,$dval,0)";	$dcount++;}
				} $sql='INSERT INTO '.($accr<3?'acc_incovotes':'acc_fsevotes').' (recno,acc,voteno,amt,markdel) VALUES '.$cvalues.'; INSERT INTO acc_pytvotes(vono,acc,voteno,amt,markdel)
				VALUES '.$dvalues.';';
				mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,pytfrm,cheno,acc,chamt,rmks,expno,commt,recsno,verno,addedby) values ($vono,curdate(),'$mode','$modeno','$acdr',$amt,
				'BEING PAYMENT FROM INTER-ACCOUNT	FUND TRANSFER FOR $rmks',$payno,2,$rno,$ino,'$addedby'); update acc_interacborrow SET voucherno=$vono,recieptno=$rno WHERE interb_no LIKE
				'$bno'; $sql") or die(mysqli_error($conn).". Click <a href=\"interacborrow.php\">HERE </a> to go back.");	while(mysqli_next_result($conn)){}
				unset($_SESSION["token"]); header("location:rpts/receipt.php?recno=$sno-0-$accr-$acdr-$vono-".uniqid());
				exit(0);
			}else{
				print "<div style=\"left-margin:auto;right-margin:auto;background-color:yellow;color:red;font-size:11pt;\">FUND TRANSFER RECORD NOT SAVED.Click <a href=\"interacborrow.php\">HERE</a>
				to go back.</div>"; exit(0);
			}
		}else{//display error message
			print "<div style=\"left-margin:auto;right-margin:auto;background-color:yellow;color:red;font-size:11pt;\">The Inter A/C fund transfer record has errors. Record not saved.<br>
			Click <a href=\"interacborrow.php\">HERE </a> to go back.</div>"; exit(0);
		}
	}mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE markdel=0; SELECT a.acsno,aa.accacc,concat(ba.abbr,' BANK - ',aa.branch,' A/C NO.',aa.accno) as bank,(a.bankbalbf+
	if(isnull(sum(b.bal)),0,sum(b.bal))) as amt FROM acc_acbalbf a Inner Join acc_accounts aa ON (a.acsno=aa.sno) Inner Join acc_banks ba On (aa.bankno=ba.sno) Left Join (SELECT acsno,
	(if(bank_type=0,sum(amt),0)-if(bank_type=1,sum(amt),0)) as bal FROM `acc_banking` Group By markdel,bank_type,acsno HAVING markdel=0)b USING (acsno) GROUP BY a.bankbalbf,a.acsno,
	aa.accacc; SELECT * FROM (SELECT v.sno,v.acc,v.expdescr,(if(isnull(i.inco),0,i.inco)-if(isnull(p.exp),0,p.exp)) as bal FROM acc_votes v LEFT JOIN (SELECT voteno,acc,sum(amt) as inco
	FROM acc_incovotes GROUP BY markdel,acc,voteno HAVING markdel=0)i ON (v.sno=i.voteno and v.acc=i.acc) LEFT JOIN (SELECT voteno,acc,sum(amt) as exp FROM acc_pytvotes GROUP BY markdel,
  acc,voteno HAVING markdel=0)p ON (v.sno=p.voteno and v.acc=p.acc) WHERE v.pyt_defined=1 and v.markdel=0 and v.acc IN (select acno FROM acc_voteacs WHERE stud_assoc=1 and markdel=0)
	UNION SELECT v.sno,v.acc,v.expdescr,(if(isnull(i.inco),0,i.inco)-if(isnull(p.exp),0,p.exp)) as bal FROM acc_votes v LEFT JOIN (SELECT voteno,acc,sum(amt) as inco FROM acc_fsevotes GROUP
	BY markdel,acc,voteno HAVING markdel=0)i ON (v.sno=i.voteno and v.acc=i.acc)  LEFT JOIN (SELECT voteno,acc,sum(amt) as exp FROM acc_pytvotes GROUP BY markdel,acc,voteno HAVING markdel=0)p
	ON (v.sno=p.voteno and v.acc=p.acc) WHERE v.pyt_defined=1 and v.markdel=0 and v.acc IN (select acno FROM acc_voteacs WHERE stud_assoc=0 and markdel=0))v ORDER BY v.acc,v.sno ASC");
	$i=$nob=0; $optacc=$lstbanks=$lstvotes=""; $token=uniqid();	$_SESSION["token"]=$token; //Go to distribution
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){ while($d=mysqli_fetch_row($rs)) $optacc.="<option value=\"$d[0]\">$d[1]</option>";
			}elseif($i==1){ $nob=mysqli_num_rows($rs); $count=0; while($d=mysqli_fetch_row($rs)) {$lstbanks.=($count==0?"":",")."new BankACs($d[0],$d[1],\"$d[2]\",$d[3])"; $count++;}
			}else{ $count=0; while($d=mysqli_fetch_row($rs)){$lstvotes.=($count==0?"":",")."new Votes($d[0],$d[1],\"$d[2]\",$d[3])"; $count++;}
			}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	if($nob==0){print "Sorry, there are no banks declared in the system. Click <a href=\"interacborrow.php\">HERE</a> to go back.";		exit(0);
	}else{$nob--; if(!isset($_POST["btnSave"])){$token=uniqid(); 	$_SESSION['token']=$token;}
	}headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css" /><link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css" />',0,0,2);
?>
<div class="container divlrborder" style="background-color:#e6e6e6;border-radius:15px;"><form method="post" action="interacborrowadd.php" onsubmit="return validateFormOnSubmit(this);"
	name="frmFunds" id="frmFunds"><input type="hidden" name="txtToken" value="<?php echo $token;?>">
	<div class="form-row"><div class="col-md-12 divheadings">INTER ACCOUNT FUND TRANSFER</div></div>
	<div class="form-row">
		<div class="col-md-2">Interborrowing S/No.<input class="modalinput modalinputdisabled" name="txtSerialNo" id="txtSerialNo" type="text" maxlength="5" value="Auto" readonly></div>
		<div class="col-md-8"></div>
		<div class="col-md-2">Transfer Done on<input class="modalinput tcal" name="txtDate" id="txtDate" type="text" readonly value="<?php echo	date("d-m-Y");?>"></div>
	</div><div class="form-row"><div class="col-md-12 divsubheading">ACCOUNT DEBITED</div></div>
	<div class="form-row">
		<div class="col-md-4"><label for="cboACDebit">Votehead A/C Debited</label><SELECT name="cboACDebit" id="cboACDebit" size="1" onchange="loadBank(this,0)" class="modalinput">
			<option value="0">Choose A/C</option><?php echo $optacc;?></SELECT></div>
		<div class="col-md-6"><label for="cboSourceAC">Bank A/C Debited</label><SELECT name="cboSourceAC" id="cboSourceAC" size="1" onchange="bankBal(this,0)" class="modalinput"><option
			value="0">Choose Bank Account</option></SELECT></div>
		<div class="col-md-2"><label for="txtSourceBal">Bank A/C Balance</label><input type="text" name="txtSourceBal" id="txtSourceBal" class="modalinput numbersinput modalinputdisabled"
			maxlength="12"	value="0.00" readonly style="color:#666"></div>
	</div><div class="form-row"><div class="col-md-12 divsubheading">ACCOUNT CREDITED</div></div>
	<div class="form-row">
		<div class="col-md-4"><label for="cboACCredebit">Votehead A/C Credited</label><SELECT name="cboACCredit" id="cboACCredit" size="1" onchange="loadBank(this,1)" class="modalinput">
			<option value="0">Choose A/C</option><?php echo $optacc;?></SELECT></div>
		<div class="col-md-6"><label for="cboDestAC">Bank A/C Debited</label><SELECT name="cboDestAC" id="cboDestAC" size="1" onchange="bankBal(this,1)" class="modalinput"><option
			value="0">Choose Bank Account</option></SELECT></div>
		<div class="col-md-2"><label for="txtDestBal">Bank A/C Balance</label><input type="text" name="txtDestBal" id="txtDestBal" class="modalinput numbersinput modalinputdisabled"
			maxlength="12" value="0.00" readonly  style="color:#666"></div>
	</div><div class="form-row"><div class="col-md-12 divsubheading">TRANSFER DETAILS</div></div>
	<div class="form-row">
		<div class="col-md-5"><label for="txtRmks">Narration/ Remarks about the Transfer</label><textarea name="txtRmks" id="txtRmks" placeholder="TO SETTLE PENDING BILLS IN THE ACCOUNT"
			class="modalinput" rows="2" maxlength="150" required></textarea></div>
		<div class="col-md-2"><label for="cboMode">Mode of Transfer</label><SELECT name="cboMode" id="cboMode" size="1" class="modalinput" required><option value="Cheque" selected>Cheque</option>
			<Option value="Direct Banking">Direct Banking</option></SELECT></div>
		<div class="col-md-3"><label for="txtModeNo">Transaction/ Cheque No.</label><input type="text" name="txtModeNo" id="txtModeNo" class="modalinput" maxlength="15" value=""
			placeholder="00000001112" required></div>
		<div class="col-md-2"><label for="txtAmt">Amount Transfered</label><input type="text" name="txtAmt" id="txtAmt" class="modalinput numbersinput" maxlength="13" value="0.00"
			onkeyup="checkInput(this)" onchange="fmtValue(this)" required></div>
	</div><hr>
	<div class="form-row">
		<div class="col-md-7 divheadings">DEBITED VOTEHEADS</div><div class="col-md-5 divheadings">CREDITED VOTEHEADS</div>
	</div><div class="form-row">
		<div class="col-md-7 divlrborder">
			<div class="form-row"><div class="col-md-6 divsubheading">VOTEHEAD</DIV><div class="col-md-3 divsubheading">BALANCE</DIV><div class="col-md-3 divsubheading">AMOUNT</DIV></DIV>
			<?php for($i=0;$i<4;$i++) echo '<div class="form-row"><div class="col-md-6"><Select name="cboVote_'.$i.'" id="cboVote_'.$i.'" onchange="enableAmt(0,'.$i.')" size="1"
				class="modalinput" '.($i==0?'':'disabled="disabled"').'><option value="0" selected>Choose Votehead</option></SELECT></DIV><div class="col-md-3"><input class="modalinput numbersinput
				modalinputdisabled"	name="txtVBal_'.$i.'" id="txtVBal_'.$i.'" readonly value="0.00" disabled="disabled" style="color:#066"></DIV><div class="col-md-3"><input class="modalinput
				numbersinput"	name="txtAmt_'.$i.'" id="txtAmt_'.$i.'" readonly value="0.00" onkeyup="checkInput(this)" onblur="distrValue(this,'.$i.',0)" '.($i==0?'':'disabled="disabled"').'>
				</DIV></DIV>';
			?><div class="form-row"><div class="col-md-12 divupsideheading">
				<div class="form-row">
					<div class="col-md-6">AMOUNT DISTRIBUTED<input type="text" name="txtDRDistr" id="txtDRDistr" readonly class="modalinputdisabled numbersinput" value="0.00"></div>
					<div class="col-md-6">BALANCE TO DISTRIBUTE<input type="text" name="txtDRBal" id="txtDRBal" readonly class="modalinputdisabled numbersinput" value="0.00"></div>
				</div>
			</DIV></DIV>
		</div><div class="col-md-5">
			<div class="form-row"><div class="col-md-8 divsubheading">VOTEHEAD</DIV><div class="col-md-4 divsubheading">AMOUNT</DIV></DIV>
				<?php for($i=0;$i<4;$i++) echo '<div class="form-row"><div class="col-md-8"><Select name="cboVote1_'.$i.'" id="cboVote1_'.$i.'" onchange="enableAmt(1,'.$i.')" size="1"
					class="modalinput" '.($i==0?'':'disabled="disabled"').'><option value="0" selected>Choose Votehead</option></SELECT></DIV><div class="col-md-4"><input class="modalinput numbersinput"
					name="txtAmt1_'.$i.'" id="txtAmt1_'.$i.'" readonly value="0.00"	onkeyup="checkInput(this)" onblur="distrValue(this,'.$i.',1)" '.($i==0?'':'disabled="disabled"').'></DIV></DIV>';
				?><div class="form-row"><div class="col-md-12 divupsideheading">
					<div class="form-row">
						<div class="col-md-6">AMOUNT DISTRIBUTED<input type="text" name="txtCRDistr" id="txtCRDistr" readonly class="modalinputdisabled numbersinput" value="0.00"></div>
						<div class="col-md-6">BALANCE<input type="text" name="txtCRBal" id="txtCRBal" readonly class="modalinputdisabled numbersinput" value="0.00"></div>
					</div>
				</DIV></DIV>
		</div>
	</div><hr><div class="form-row">
		<div class="col-md-4"><button type="submit" name="btnSave" id="save" class="btn btn-primary btn-md btn-block">Save Inter A/C Fund Transfer Record</button></div>
		<div class="col-md-4"></div>
		<div class="col-md-4" style="text-align:right;"><button type="button" name="btnClose" onclick="window.open('interacborrow.php','_self')" class="btn btn-disabled btn-md">Close/ Cancel
		</button></div>
	</div><hr>
</form></div>
</DIV>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/interacborrow.js"></script>
<script type="text/javascript">votes.push(<?php echo $lstvotes;?>);bankacs.push(<?php echo $lstbanks;?>);</script>
<?php mysqli_close($conn); footer();?>
