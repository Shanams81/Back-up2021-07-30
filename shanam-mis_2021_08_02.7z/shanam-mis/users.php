<?php
	session_start();
	if (!isset($_SESSION['username']) || $_SESSION['username'] == '') header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if(isset($_POST['CmdClose'])){
		header("location:useredit.php?action=0-0");
	}elseif(isset($_POST['CmdNew'])){
	   header("location:useradd.php?action=0-0");
	}else{
		$s=$_REQUEST['action']; $s=preg_split("/\-/",$s);
		$rsPriv=mysqli_query($conn,"SELECT userview,useradd,useredit,userdel,recpwd FROM gen_Priv WHERE uname LIKE '".$_SESSION['username']."'");
		if (mysqli_num_rows($rsPriv)==1) list($usvi,$usad,$used,$usdel,$repw)=mysqli_fetch_row($rsPriv);	mysqli_free_result($rsPriv);
		if ($usvi==0) header("location:vague.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>System Users</title>
		<script type="text/javascript" src="tpl/priv.js"></script>
		<script type="text/javascript" src="tpl/actionmessage.js"></script>
		<STYLE type="text/css">
			table{border:3px solid green;border-collapse:collapse; border:outset 3px;font-size:11px;}
			td,th{letter-spacing:1.5px;word-spacing:2px;border-right:2px solid #099009;border-left:2px solid #099009;border-top:1px solid 
			green;border-bottom:1px solid green;}
		</style>
    </head>
<body background="img/bg3.gif" <?php print "onload=\"actiondone($s[0],$s[1])\"";?>>
	<?php
        print "<form method=\"post\" action=\"Users.php\"><p class=\"g\">To view authentic system users click <button name=\"CmdShow\" 
		onclick=\"return canvi($usvi);\">Show Authentic Users</button></p><hr/>";
        if (isset($_POST['CmdShow'])){
            print "<center><h2>S y s t e m &nbsp;&nbsp;&nbsp; U  s e r s &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A s &nbsp;&nbsp;&nbsp;&nbsp; O n 
			&nbsp;&nbsp;&nbsp;&nbsp;".date("D d, M Y")."</h2></center><hr>
			<table cellpadding=\"2\" cellspacing=\"2\" align=\"center\"><tr><th colspan=\"5\">USER LOGIN DETAILS</th><th colspan=\"3\">Administrative Actions</th>
			</tr><tr><th>Login Name</th><th>User Names</th><th>Designation</th><th>Section</th><th>Password Expire On</th><th>Recover Password</th><th>Edit</th>
			<th>Delete</th></tr>";
    		$rsUser=mysqli_query($conn,"SELECT l.username,concat(s.surname,' ',s.onames) as st_names,s.designation,if(l.section=0,'Admin',if(l.section=1,'Accounts',if(l.section=2,'Exams',
			if(l.section=3,'Stores',if(l.section=4,'Discipline', if(l.section=5,'Guiding and Counselling','Library')))))) as sect,l.expirydate,if(l.expirydate<curdate(),1,0) as act FROM 
			login l Inner Join stf s USING (idno) WHERE (l.username Not LIKE 'shanam') Order By username Asc");
    		$n=mysqli_num_rows($rsUser);
    		if ($n>0):
    			$i=0;
    			while (list($ln,$un,$des,$sec,$ed,$act)=mysqli_fetch_row($rsUser)):
    				if($i%2==0) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>";
    				print "<td>$ln</td><td>$un</td><td>$des</td><td>$sec</td><td align=\"right\">".date("D d-M-Y",strtotime($ed))."</td>";
    				$todate=date('Y-m-d');
    				if ($act==1) print "<td align=\"center\"><a onclick=\"return confpwd($repw);\" href=\"pwdactivate.php?user=$ln\">Activate</a>
    				</td>"; else print "<td></td>";
    				print "<td align=\"center\"><a href=\"useredit.php?action=$ln\" onclick=\"return canedit($used);\">Edit</a></td><td align=\"center\"><a 
					href=\"userdelete.php?action=$ln\" onclick=\"return candel($usdel);\">Delete</td></tr>";
                    $i++;
    			endwhile;
    		else:
    			print "<tr><td colspan=\"8\">No system user has a password expired</td></tr>";
    		endif;
    		mysqli_free_result($rsUser);
            print "<tr><td colspan=\"8\"><b>$n Authorized System User(s) have expired password(s)</b></td></tr><tr><td colspan=\"8\" align=\"center\">
            <button name=\"CmdNew\" onclick=\"return canadd($usad);\">Register New User</button>&nbsp;&nbsp;&nbsp;<button name=\"CmdClose\">Close</button></td>
			</tr></table>";
        }else{
         	print "<p class=\"g\" style=\"color:#000077;\"><u><b>To View Authentic System Users </b></u></p><ol type=\"i\"><li>Click <b>Show Authentic Users</b> 
			button.<li>The authorized users are displayed and you are can add new users, edit user details, activate expired password and delete existing users.
			</ol>";
			print "<p class=\"g\" style=\"color:#000077;\"><u><b>Adding System Users </b></u></p><ol type=\"i\"><li>Click <b>Show Authentic Users</b> 
			button.<li>Click <b>Register New Users</b> button,<li>Select the staff member to registered as system user, Enter login name and temporary password 
			of the new user,Select the section of the system he/she will be authorized to access, Select the user title in the section and <li>Click <b>
			Save User Details</b> button.</ol>";
			print "<p class=\"g\" style=\"color:#000077;\"><u><b>Editing User Details</b></u></p><ol type=\"i\"><li>Click <b>Show Authentic Users</b> 
			button.<li>In the Administrative Actions of the user's table and Edit column, Click <b>Edit</b> in the row of the user to be edited<li>Make the 
			necessary user details' changes and <li><Click b>Save User Details</b> button.</ol>";
            print "<p class=\"g\" style=\"color:#000077;\"><u><b>To Recover Expired Password</b></u></p><ol type=\"i\"><li>Click <b>Show Authentic Users</b> 
			button<li>Click <i>Activate</i> to allow user for 2 days.<li>The user is expected to change his/ her recovered password within the 2 days of recovery
			</ol><p class=\"g\"><b>Note:</b> The recovered password is set to default '000000' (six zeroes).</p>";
			print "<p class=\"g\" style=\"color:#000077;\"><u><b>To Delete System User</b></u></p><ol type=\"i\"><li>Click <b>Show Authentic Users</b> 
			button.<li>Click <b>Delete</b> in the row of the user to be deleted<li>Confirm you action by clicking <b>OK</b> button in the message box.</ol>";
		}mysqli_close($conn);		
	?>
</body>
</html>