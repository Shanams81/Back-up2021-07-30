<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	$usn=strtoupper($_SESSION['username'].' ('.$_SESSION['priviledge'].')');
	if (isset($_POST['CmdSave'])){
		$vono=isset($_POST['VoucherNo'])?strip_tags($_POST['VoucherNo']):null; 				$date=isset($_POST['Date'])?$_POST['Date']:date('Y-m-d');
		$vono=(strcasecmp($vono,"auto")==0 || strlen($vono)==0)?0:$vono;					$date=preg_split("/\-/",$date);	
		if ($vono==0){
			$rs=mysqli_query($conn,"SELECT max(voucherno) as vno FROM acc_exp");
			if (mysqli_num_rows($rs)>0){ list($vono)=mysqli_fetch_row($rs); $vono++;} else $vono=1;
		}
		$idno=isset($_POST['IDNo'])?trim(strip_tags($_POST['IDNo'])):null; 					$idno=mysqli_real_escape_string($conn,$idno);
		$pytfrm=isset($_POST['PytFrm'])?$_POST['PytFrm']:'Cash';							$payee=isset($_POST['Payee'])?strtoupper(trim(strip_tags($_POST['Payee']))):Null; 	
		$payee=mysqli_real_escape_string($conn,$payee);										$add=isset($_POST['Address'])?strtoupper(trim(strip_tags($_POST['Address']))):null; 
		$add=mysqli_real_escape_string($conn,$add);											$telno=isset($_POST['TelNo'])?trim(strip_tags($_POST['TelNo'])):null;				
		$telno=mysqli_real_escape_string($conn,$telno);										$cheno=isset($_POST['CheNo'])?trim(strip_tags($_POST['CheNo'])):null;				
		$cheno=mysqli_real_escape_string($conn,$cheno);										$cash=isset($_POST['TxtCash'])?strip_tags($_POST['TxtCash']):0;						
		$cheque=isset($_POST['TxtCheque'])?strip_tags($_POST['TxtCheque']):0;				$cash=preg_replace("/[^0-9^\.]/","",$cash);					
		$cheque=preg_replace("/[^0-9^\.]/","",$cheque);											
		$rmks=isset($_POST['Remarks'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['Remarks'])))):'Being payment of '; 
		$votes=array(); $amts=array();
		$disvo="";	$disam="";
		$i=1;
		while (($i<5) && isset($_POST['Vote_'.$i]) && strlen($_POST['Vote_'.$i])!=0){
			$vote=$_POST['Vote_'.$i];
		 	switch (strtolower($vote)){
				case "tuition":
					$vote='tui'; break;
				case "boarding & meals":
					$vote='boa'; break;
				case "activity":
					$vote='act'; break;
				case "l . t & t":
					$vote='ltt'; break;
				case "r . m . i":
					$vote='rmi'; break;
				case "e . w . c":
					$vote='ewc'; break;
				case "examination":
					$vote='exa'; break;
				case "administration costs":
					$vote='admincosts'; break;
				case "admission":
					$vote='adm'; break;
				case "library":
					$vote='lib'; break;
				case "medical":
					$vote='med'; break;
				case "personal emolument":
					$vote='pem'; break;
				case "arrears":
					$vote='arr'; break;
				case "transport":
					$vote='trans'; break;
				case "other costs":
					$vote='ocosts'; break;
			}
			$disvo.="$vote,";
			$amt=$_POST['TxtAmount_'.$i];
			$amt=preg_replace("/[^0-9^\.]/","",$amt);
			$disam.="'$amt',";
			$i++;	
		}
		if (strlen($payee)>0 && (($cash+$cheque)>0) && (strlen($rmks)>16 || strcasecmp("being payment of ",$rmks)!=0) && ($bal==0) && ($_SESSION['form_token']==$_POST['form_token'])) {
			@mysqli_query($conn,"INSERT INTO acc_exp(voucherno,pytdate,curr_year,payee,idno,address,telno,payform,chequeno,caamt,chamt,rmks) VALUES ('$vono','$date[2]-$date[1]-$date[0]',
			'$date[2]','$payee',".var_export($idno,true).",'$add',".var_export($telno,true).",'$pytfrm',".var_export($cheno,true).",'$cash','$cheque',".var_export($rmks,true).")") or 
			die(mysqli_error($conn).". Payment details were not saved. Click <a href=\"imprests.php\">Here</a> to try again.</center>");
			mysqli_query($conn,"INSERT INTO acc_mainexp (voucherno,datepyt,curr_year,acc,$disvo markdel) VALUES ('$vono','$date[2]-$date[1]-$date[0]','$date[2]','1',$disam 0)");
			header("location:pettycashvoucher.php?action=$vono-0-1");
		}else{
			print "Sorry, the payments/ expenditure details had errors.<br>Please ensure all details are correctly entered before saving.<br>Click <a href=\"imprests.php\">here</a> to try 
			again.";
		}unset($_SESSION['form_token']);
		exit(1);
	}else{
	 	$form_token=uniqid();
	 	$_SESSION['form_token']=$form_token;
		$rsInco=mysqli_query($conn,"SELECT sum(tuition) as sumtui,sum(boarding) as sumboa,sum(activity) as sumact,sum(ltt) as sumltt,sum(rmi) as sumrmi,sum(ewc) as 
		sumewc,sum(exam) as sumexa,sum(admincosts) as sumadmco,sum(adm) as sumadm,sum(lib) as sumlib,sum(medical+spemed) as summed,sum(pemolu) as sumpem,sum(arrears) as sumarr,
		sum(transport) as sumtrans,sum(olevy) as sumole,year(pytdate) as yr FROM acc_feerec Group by year(pytdate),markdel HAVING yr=year(curdate()) and markdel=0");
		$inrec=mysqli_num_rows($rsInco);
		if ($inrec>0) $inco=mysqli_fetch_array($rsInco,MYSQLI_NUM); else $inco=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		mysqli_free_result($rsInco);
		$rsExp=mysqli_query($conn,"SELECT sum(tui) as sumtui,sum(boa) as sumboa,sum(act) as sumact,sum(ltt) as sumltt,sum(rmi) as sumrmi,sum(ewc) as sumewc,sum(exa) as sumexa,
		sum(admincosts) as sumadminco,sum(adm) as sumadm,sum(lib) as sumlib,sum(med) as summed,sum(pem) as sumpem,sum(arr) as sumarr,sum(trans) as sumtra,sum(ocosts) as sumocost,
		year(datepyt) as yr FROM acc_mainexp Group by year(datepyt),markdel HAVING yr=year(curdate()) and markdel=0");
		$exrec=mysqli_num_rows($rsExp);
		if ($exrec>0) $exp=mysqli_fetch_array($rsExp,MYSQLI_NUM); else $exp=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0); 
		mysqli_free_result($rsExp);
		$rsBudg=mysqli_query($conn,"SELECT vote,sum(qty*unitcost)as price FROM acc_budget GROUP BY fin_year,vote,markdel HAVING fin_year=year(curdate()) and markdel=0");
		$budvot=array(); $budamt=array(); $buitems=mysqli_num_rows($rsBudg);
		if ($buitems>0){
		 	while (list($vote,$amt)=mysqli_fetch_row($rsBudg)){
				array_push($budvot,$vote);
				array_push($budamt,$amt);
			}
		}else{
			array_push($budvot,"None","None1");
			array_push($budamt,0,0);
		}mysqli_free_result($rsBudg);
	}
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<link rel="stylesheet" type="text/css" href="../date/tcal.css" />
	<script type="text/javascript" src="../date/tcal.js"></script>
	<title>Course</title>
	<script type="text/javascript" src="tpl/pettycash.js"></script> 
	<script type="text/javascript">
		var myVotes=["Tuition", "Boarding & Meals", "Activity", "L . T & T", "R . M . I", "E . W . C", "Examination", "Administration Costs", "Admission", "Library","Medical",
		"Personal Emoluments", "Arrears", "Transport", "Other Costs"];
		var myInco=[<?php 
			$i=0; 
			foreach($inco as $amt){
			 	if($i<14)print "$amt,"; elseif($i==14)  print $amt; 
				$i++;
			}?>];		
		var myExp=[<?php 
			$i=0; 
			foreach($exp as $amt){
			 	if($i<14) print "$amt,"; elseif($i==14) print $amt; 
				$i++;
			}?>];	
		var budgVot=[(<?php  
			$i=0;
			foreach($budvot as $vot){
			 	if($i<(($buitems>0?$buitems:2)-1))print "\"$vot\","; else print "\"$vot\""; 
			 	$i++;
			}?>];
		var budgAmt=[<?php
			$i=0;  
			foreach($budamt as $amt){
			 	if($i<(($buitems>0?$buitems:2)-1)) print "$amt,"; else print $amt; 
			 	$i++;
			}?>];
		function assignAmts(a){
			checkCompute(a);
			var pos=-1;		//Initial position for expenditure and income voteheads
			var bupos=-1;	//Inital position for budget votehead
			var vote=document.getElementById("CboVote_"+a).value;
			for (var i=0;i<15;i++){
				if (vote.toLowerCase()==myVotes[i].toLowerCase()) pos=i;
				if (i<<?php print $buitems;?>){//find position of budget
					if (vote.toLowerCase()==budgVot[i].toLowerCase()) bupos=i;
				}
			}
			//budget allocation
			if (bupos!=-1){
				var amt=budgAmt[bupos];
				document.getElementById("TxtBudget_"+a).value=addCommas(amt);
			}else{
				document.getElementById("TxtBudget_"+a).value="0.00";
			}
			//Income and expenditure analysis
			if (pos!=-1){
				var examt=myExp[pos];
				var inamt=myInco[pos];
				document.getElementById("TxtIncome_"+a).value=addCommas(inamt);
				document.getElementById("TxtCost_"+a).value=addCommas(examt);
				document.getElementById("TxtAvailable_"+a).value=addCommas((inamt-examt));
				if((inamt-examt)<20000)document.getElementById("TxtAvailable_"+a).style.background='fuchsia';
				else document.getElementById("TxtAvailable_"+a).style.background='lime';
			}else{
				document.getElementById("TxtIncome_"+a).value="0.00";
				document.getElementById("TxtCost_"+a).value="0.00";
				document.getElementById("TxtAvailable_"+a).value="0.00";
				document.getElementById("TxtAvailable_"+a).style.background='fuchsia';
			}
		}
		function pytForm(me){
			if (me.value.toLowerCase()=='cash'){
				document.getElementById('TxtCash').readonly=false;
				document.getElementById('TxtCheque').value="0.00";
				document.getElementById('TxtCheque').readonly=true;
			}else if (me.value.toLowerCase()=='cheque'){
				document.getElementById('TxtCash').readonly=true;
				document.getElementById('TxtCash').value="0.00";
				document.getElementById('TxtCheque').readonly=false;
			}else{
				document.getElementById('TxtCash').readonly=false;
				document.getElementById('TxtCheque').readonly=false;
				document.getElementById('TxtCheque').value="0.00";
				document.getElementById('TxtCash').value="0.00";
				document.getElementById('TxtTotal').value="0.00";
			}
		}
	</script>
	<style>
		input.dis{text-align:right;border:0px;font-weight:bold;color:#00F;background-color:#eee;pointer-events:none}
		td.vote{text-align:center;border-bottom:0px;border-top:0px;border-left:1px solid #00d300;border-right:1px solid #00d300;}
	</style>
</head>
<body background="img/bg3.gif">
	<form method="post" action="payments.php" onsubmit="return validateFormOnSubmit(this);" name="FrmPettyPyts"><br><br><br><br><table border="1" bordercolor="#eeeeee" cellspacing="0" 
	cellpadding="1" align="center"><tr><td><table border="0" align="center" cellspacing="2" cellpadding="3">
	<?php
		print "<input type=\"hidden\" name=\"form_token\" value=\"$form_token\"><tr bgcolor=\"#eeeeee\"><td colspan=\"6\" align=\"center\" style=\"word-spacing:7px;letter-spacing:5px;
		font-weight:bold;font-size:14px;\">PETTYCASH - DETAILS OF THE PAYEE</td></td></TR>";
		print "<tr><td align=\"right\">Pettycash Voucher No.</td><td><input type=\"text\" name=\"VoucherNo\" id=\"TxtVoucherNo\" size=\"5\" maxlength=\"4\" readonly value=\"Auto\"><td 
		align=\"right\">Paid On</td><td><INPUT name=\"Date\" id=\"TxtDate\" size=\"10\" maxlength=\"10\" readonly value=\"".date('d-m-Y')."\"></td><td align=\"right\">ID No.</td><td>
		<input type=\"text\" name=\"IDNo\" id=\"TxtIDNo\" size=\"16\" maxlength=\"10\" value=\"\"></td></tr>";
		print "<tr><td align=\"right\">Name of Payee</td><td colspan=\"5\"><input type=\"text\" name=\"Payee\" id=\"TxtPayee\" size=\"78\" maxlength=\"40\" value=\"\" 
		style=\"text-transform:uppercase;\"></td></tr><tr><td align=\"right\">Address of Payee</td><td colspan=\"3\"><TEXTAREA name=\"Address\" id=\"TxtAddress\" cols=\"45\" 
		style=\"text-transform:uppercase;\" rows=\"2\" maxlength=\"75\"></textarea></td><td align=\"right\" valign=\"top\">Tel. No.</td><td valign=\"top\"><input type=\"text\" 
		name=\"TelNo\" id=\"TxtTelNo\" size=\"16\" maxlength=\"13\" value=\"\"></td></tr><tr bgcolor=\"#eeeeee\"><td colspan=\"6\" align=\"center\" style=\"word-spacing:7px;
		letter-spacing:5px;font-weight:bold;font-size:14px;\">PETTYCASH - DETAILS OF THE PAYMENT</td></td></tr>";
		print "<tr><td align=\"right\">Paid in</td><td colspan=\"3\"><SELECT name=\"PytFrm\" id=\"CboPytFrm\" size=\"1\" onblur=\"pytForm(this)\"><option selected>Cash</option><option>Cheque
		</option><option>Cash + Cheque</option></select></td><td align=\"right\">Cheque No.</td><td><input name=\"CheNo\" Id=\"TxtCheNo\" size=\"16\" maxlength=\"7\" 
		onkeyup=\"checkInput(this)\" value=\"\"></td></tr>";
		print "<tr><td align=\"right\">Cash Amount</td><td><input type=\"text\" name=\"TxtCash\" Id=\"TxtCash\" size=\"10\" maxlength=\"10\" onkeyup=\"checkInput(this)\" 
		onChange=\"sumPaid()\" value=\"0.00\" style=\"text-align:right;\"></td><td align=\"right\">Cheque Amount</td><td><input type=\"text\" name=\"TxtCheque\" Id=\"TxtCheque\" 
		size=\"10\" maxlength=\"10\" readonly onkeyup=\"checkInput(this)\" onChange=\"sumPaid()\" value=\"0.00\" style=\"text-align:right;\"></td><td align=\"right\" colspan=\"2\" 
		bgcolor=\"#dddddd\">Total Amount Spend <input name=\"TxtTotal\" Id=\"TxtTotal\" size=\"10\" maxlength=\"10\" onkeyup=\"checkInput(this)\" readonly class=\"dis\" value=\"0.00\">
		</td></tr>";
		print "<tr><td align=\"right\" valign=\"top\">Reason for the Payment</td><td colspan=\"5\"><Textarea name=\"Remarks\" id=\"TxtRemarks\" cols=\"80\" rows=\"3\" maxlength=\"250\" 
		style=\"text-transform:uppercase;\">BEING PAYMENT FOR </textarea></td></tr></TABLE></TD></TR><TR><TD><table border=\"1\" cellspacing=\"0\" cellpadding=\"2\" bordercolor=\"#dddddd\" 
		width=\"100%\"><tr bgcolor=\"#eeeeee\"><th colspan=\"6\" align=\"center\" style=\"word-spacing:7px;letter-spacing:5px;font-weight:bold;font-size:14px;\">PETTYCASH - DETAILS OF 
		VOTEHEAD DISTRIBUTION</th></tr><tr><th>Votehead</th><th>Amount Budgted</th><th>Total Income<br>in the Votehead</th><th>Total<br>Running Costs</th><th>Amount Available</th><th>
		Amount You Are<br>Costing</th></tr>";
		for ($i=1;$i<5;$i++) print "<tr><td class=\"vote\"><SELECT name=\"Vote_$i\" id=\"CboVote_$i\" size=\"1\" onChange=\"assignAmts($i)\" ".($i==1?"":"disabled")."><option 	value=\"\" 
		selected></option><option>Tuition</option><option>Activity</option><option>Administration Costs</option><option>Admission Fee</option><option>Arrears</option><option>Boarding &amp; Meals</option><option>
		Examination</option><option>E . W . C</option><option>Library</option><option>L . T & T</option><option>Medical</option><option>Personal Emolument</option><option>R . M . I</option><option>
		Transport</option><option>Other Costs</option></SELECT></td><td class=\"vote\"><input name=\"TxtBudget_$i\" Id=\"TxtBudget_$i\" size=\"10\" maxlength=\"10\" value=\"0.00\" class=\"dis\"></td><td 
		class=\"vote\"><input name=\"TxtIncome_$i\" Id=\"TxtIncome_$i\" size=\"10\" maxlength=\"10\" value=\"0.00\" class=\"dis\"></td><td class=\"vote\"><input name=\"TxtCost_$i\" Id=\"TxtCost_$i\" 
		size=\"10\" maxlength=\"10\" value=\"0.00\" class=\"dis\"></td><td class=\"vote\"><input name=\"TxtAvailable_$i\" Id=\"TxtAvailable_$i\" size=\"10\" maxlength=\"10\" value=\"0.00\" class=\"dis\">
		</td><td class=\"vote\"><input name=\"TxtAmount_$i\" Id=\"TxtAmount_$i\" size=\"10\" maxlength=\"10\" value=\"0.00\" style=\"text-align:right;\" onKeyUp=\"checkInput(this)\" 
		onChange=\"checkCompute($i)\" ".($i==1?"":"disabled")."></td></tr>";
		print "<tr><td colspan=\"6\" bgcolor=\"#eeeeee\"><hr></td></tr><tr><td colspan=\"2\" align=\"right\"><b>Total Amount Distributed (Kshs.)</b></td><td align=\"center\"><input 
		name=\"TxtCosted\" Id=\"TxtCosted\" size=\"10\" maxlength=\"10\" value=\"0.00\" class=\"dis\"></td><td colspan=\"2\" align=\"right\"><b>Balance to be Distributed (Kshs.)</b></td>
		<td align=\"center\"><input name=\"TxtBalance\" Id=\"TxtBalance\" size=\"10\" maxlength=\"10\" value=\"".number_format($impamt,2)."\" class=\"dis\"></td></tr></table>";
	?>
	<TR><TD align="center" valign="center"><br><button type="submit" name="CmdSave" id="CmdSave">Save Details</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Imprests.php"><button type="button" name="CmdClose">Close</button><a><br></td></tr></table></form>
</body>
</html>
<?php
	mysqli_close($conn);
?>