function Clickheretoprint()
{ 
	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
  	disp_setting+="scrollbars=yes,width=650, height=600, left=100, top=25"; 
	var content_vlue = document.getElementById("print_content").innerHTML; 
	var docprint=window.open("","",disp_setting); 
	docprint.document.open(); 
	docprint.document.write('<html><head><title>Shanams Digital Solutions</title>'); 
	docprint.document.write('</head><body onLoad="self.print()"><center>');          
	docprint.document.write(content_vlue);          
	docprint.document.write('</body></html>'); 
	docprint.document.close(); 
	docprint.focus(); 
}
function printSpecific(secno){ 
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
  	disp_setting+"scrollbars=yes,width=650, height=600, left=100, top=25"; 
	var content_value = document.getElementById(secno).innerHTML; 
	var docprint=window.open("","",disp_setting); 
	docprint.document.open(); 
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title>'); 
	docprint.document.write('</head><body onLoad="self.print()" style="color:#000000;font-size:10px;"><center>');          
	docprint.document.write(content_value);          
	docprint.document.write('</body></html>'); 
	docprint.document.close(); 
	docprint.focus(); 
}