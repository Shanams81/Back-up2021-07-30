function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validatUsername(theForm.TxtItem);
	reason += validateNo(theForm.TxtUnitPrice);
	reason += validateNo(theForm.TxtQty);
	if (reason != "") {
    	alert("The following fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " You didn't enter the description of the item to be purchased.\n";
	} else if (fld.value.length < 5) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The item description is too short.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The item description entered contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ \+]/g, '');     
	if (fld.value == "") {
    	error = fld.name + " requires numeric data, it is currently blank.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = fld.name + " requires numeric values, your entry contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0";
	}
}
function Compute(ob){
 	var amt=0;
	var rate=0;
	//Gross salary computation
	var n=document.getElementById("TxtUnitPrice").value; 	
	amt=parseFloat(n.replace(",",""));
	n=document.getElementById("TxtQty").value; 	rate=parseFloat(n.replace(",",""));	
	amt=amt*rate; 
	var m=amt.toFixed(2); //format to two decimal places
	document.getElementById("TxtCost").value=addCommas(m);
}