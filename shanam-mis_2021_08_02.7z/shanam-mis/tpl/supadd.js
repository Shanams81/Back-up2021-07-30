function validateFormOnSubmit(theForm) {
	var reason = "";
	if (theForm.TxtCode.value.length==0){
	 	reason+="You MUST enter supplier\'s code before saving\n";
	 	theForm.TxtCode.style.background='Yellow';
	}
  	if (theForm.TxtIDNo.value.length>0) reason += validateNo(theForm.TxtIDNo);
  	reason += validateNo(theForm.TxtTelNo);
  	reason += validateUsername(theForm.TxtNames);
  	reason += validateUsername(theForm.TxtSite);
  	reason += validateUsername(theForm.TxtSupplies);
  	if (reason != "") {
    	alert("Some supplier fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = "You didn't enter the information about the supplier.\n";
	} else if (fld.value.length < 5) {
    	fld.style.background = 'Yellow'; 
    	error = "The supplier information entered is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = "The supplier information contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\+\-\ ]/g, '');     
	if (fld.value == "") {
    	error = "Enter the supplier\'s telephone number and ID No. (if exists) before saving.\n";
    	fld.style.background = 'Yellow';
	} else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {
    	error = "The telephone number and/or ID No. entered are invalid.\n";
    	fld.style.background = 'Yellow';
	} else{
		fld.style.background = 'White';
	}
	return error;
}