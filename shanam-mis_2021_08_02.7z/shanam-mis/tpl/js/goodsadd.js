function Votes(sno,abbr,acno){
	this.sno=sno; this.abbr=abbr; this.acno=acno;
}
function clrCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function delConfirm(){
 	var ans=confirm("Are you sure you want to delete this record?\nClick OK to delete otherwise click Cancel.");
 	if (ans==true) return true; else return false;
}
function fillCBO(ac){
	clrCont("cboVote1"); 
	var htmlSelect=document.getElementById("cboVote1"); var n=votes.length;
	for (var i=0;i<n;i++){
	 	if(votes[i].acno==ac){
			selectBoxOption = document.createElement("option");
			selectBoxOption.value = votes[i].sno;
			selectBoxOption.text = votes[i].abbr;
			htmlSelect.add(selectBoxOption);	
		}
	}
}
function loadVotes(cbo){
	var ac=parseInt(cbo.value);
	fillCBO(ac);
}
function editGoodAc(opt,itm,ac,vo){
    var i=0,found=false,origac=parseInt(document.getElementById("cboAC1").value); origac=isNaN(origac)?0:origac;
    if(origac!=ac){
		document.getElementById("cboAC1").value=ac;	
		fillCBO(ac);
	}
    document.getElementById("cboVote1").value=vo; document.getElementById("txtNo1").value=opt+'-'+itm+'-'+ac+'-'+vo;
	if (opt==1) document.getElementById('spDelete').innerHTML='<a href="goodsEdit.php?delno=1-'+itm+'-'+ac+'-'+vo+'" onclick="return delConfirm()"><button type="button"  '+
	'class="cancelbtn" name="btnDelete">Delete Item/Service</button></a>'; 
	else document.getElementById('spDelete').innerHTML='';	
	document.getElementById('goodsVoteEdit').style.display='block';	
}
function validateFormOnSubmit(theForm) {
	var reason = "";
	if (theForm.cboMain.value.length==0 && theForm.cboMisc.value.length==0){
		reason="You MUST choose the votehead in Main/ Misc Account on which the items is costed\n";
		theForm.cboMain.style.background = 'Yellow';
		theForm.cboMisc.style.background = 'Yellow';
	}reason += validateNo(theForm.txtItemNo);
  	reason += validateUsername(theForm.txtItem);
  	reason += validateNo(theForm.txtMax);
  	reason += validateNo(theForm.txtMin);
  	reason += validateNo(theForm.txtUP);
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\w/; // allow letters and numbers
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = "You didn't enter the item description.\n";
	} else if (fld.value.length < 5) {
    	fld.style.background = 'Yellow'; 
    	error = "The item name is too short.\n";
	} else if (!illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = "The item name contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (fld.value == "") {
    	error = "Enter maximum stock level, minimum stock level and unit price before saving.\n";
    	fld.style.background = 'Yellow';
	} else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {
    	error = "Maximum and minimum stock level and unit price MUST be numeric.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=a;
	}
	if (ob.length==0){
	 	ob.value="0";
	}
}
function canedit(pr){
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to edit the record");
    	return false;
  	} else {
  		return true;
  	}
}