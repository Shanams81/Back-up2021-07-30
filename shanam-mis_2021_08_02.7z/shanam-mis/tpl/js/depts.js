function Dept(dno,dname,abb,cat,hod){this.dno=dno;	this.dname=dname;	this.abb=abb;	this.cat=cat;	this.hod=hod;}	var depts=[];
function findDept(dn){
	let n=depts.length; let i=0,found=false;
	while(i<n && found===false){
		if (dn==depts[i].dno){
			found=true; document.getElementById('txtInfo1').value=document.getElementById('txtDeptNo1').value=dn;
			document.getElementById('txtDeptName1').value=depts[i].dname;		 	document.getElementById('txtDeptAbbr1').value=depts[i].abb;
			document.getElementById('cboDeptCat1').value=depts[i].cat;				document.getElementById('cboHOD1').value=depts[i].hod;
			document.getElementById('divEditDept').style.display='block';
		} i++;
	}
}
function confirmDel(p){
	if(p==0){
		alert('Sorry, You do not have the priviledge to delete department details');
	}else{
		if(confirm('Are you sure you want to delete this Department?')){
			let dn=document.getElementById('txtInfo1').value.trim();
			location.href="deptdel.php?del="+dn;
		}
	}
}
function validateFormOnSubmit(theForm) {
			var reason = "";
			reason += validateUsername(theForm.txtDeptName);
	  	reason += validateUsername(theForm.txtDeptAbbr);
	  	reason += validateUsername(theForm.cboDeptCat);
	  	reason += validateNo(theForm.cboHOD);
	  	if (reason != "") {
	    	alert("Some fields need correction:\n" + reason);
	    	return false;
	  	} else {
	  		return true;
	  	}
}
function validateFormOnSubmit1(frm){
		var reason = "";
		reason += validateUsername(frm.txtDeptName1);
		reason += validateUsername(frm.txtDeptAbbr1);
		reason += validateUsername(frm.cboDeptCat1);
		reason += validateNo(frm.cboHOD1);
		if (reason != "") {
			alert("Some fields need correction:\n" + reason);
			return false;
		} else {
			return true;
		}
}
function validateUsername(fld) {
    	var error = "";
    	var illegalChars = /\d/; // allow letters, numbers, and underscores
    	if (fld.value == "") {
        	fld.style.background = 'Yellow';
        	error = "You didn't enter a username.\n";
    	} else if (fld.value.length < 3) {
        	fld.style.background = 'Yellow';
        	error = "The username is the wrong length.\n";
    	} else if (illegalChars.test(fld.value)) {
        	fld.style.background = 'Yellow';
        	error = "The username contains illegal characters.\n";
    	} else {
        	fld.style.background = 'White';
    	}
    	return error;
}
function validateNo(fld) {
    	var error = "";
    	var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');
   		if (fld.value == "") {
        	error = "You didn't enter a department number.\n";
        	fld.style.background = 'Yellow';
    	} else if ((isNaN(parseInt(stripped))) || (parseInt(stripped)==0)) {
        	error = "The department number contains illegal characters.\n";
        	fld.style.background = 'Yellow';
    	}
    	return error;
}
