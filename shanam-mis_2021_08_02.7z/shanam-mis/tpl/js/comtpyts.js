function BankBal(sno,bal){this.sno=sno; this.bal=bal;} var bankbal=[];
function showBankBal(cbo){
		var amt=0,bank=parseInt(cbo.value); bank=isNaN(bank)?0:bank;
		if(bank>0){let l=bankbal.length,c=0,found=false; while(!found && c<l){if(bankbal[c].sno==bank){amt=bankbal[c].bal;found=true;} c++;}}
		document.getElementById("txtCBank").value=addCommas(amt);
}function connect(){
	if (window.XMLHttpRequest) {return new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
  } else {return new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
  }
}function enableDel(txt){
	var t=txt.value.replace(/[a-z\ \.\,]/g,'');		txt.value=t;
	if (t.length>10) document.querySelector("#btnDelete").disabled=false; else document.querySelector("#btnDelete").disabled=true;
}function checkNames(txt){
	let nm=txt.value.replace(/[^a-z\ \.]/gi,''); txt.value=nm;
}function validateFormOnSubmit(theForm) {
	var reason = "",i=parseFloat(theForm.txtTotal.value.replace(/[^0-9\.]/g,""));
	if (i===0){theForm.txtCash.style.background='Yellow';		theForm.txtCheque.style.background='Yellow';
		reason+="You MUST enter the cash and/or Cheque amount being spend before saving.\n";
	}i=parseFloat(theForm.txtBalance.value.replace(/[^0-9\.]/g,''));
	if (i!==0){theForm.txtAmount_1.style.background='Yellow'; theForm.txtAmount_1.focus();
		reason+="Ensure the you have correctly distributed the amount to respective voteheads before saving\n";
	} i=theForm.txtCheNo.value; var acno=Number(theForm.cboBankAC.value)
  if (theForm.cboPytFrm.value.toLowerCase()!=="cash" && (i.length==0 || isNaN(acno))){reason+="You MUST enter cheque number and select bank A/C for this payment before saving\n";
		theForm.txtCheNo.style.background='Yellow';
	}if (i.length>0) reason += validateNo(theForm.txtCheNo);	i=theForm.txtRmks.value;
	if (i.toUpperCase()=="BEING PAYMENT FOR " || i.length<15){ reason+="Enter valid reason/remarks for the commitment payment\n"; theForm.txtRmks.style.background='Yellow';}
	if (reason != ""){alert("Some fields need correction before saving:\n" + reason); 	return false;} else return true;
}//function showDelete(){	document.querySelector('.modal').style.display='block';}
function validateUsername(fld) {
	var error = "",illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {fld.style.background = 'Yellow';	error = "You didn't type the information required in " + fld.name + ".\n";
	} else if (fld.value.length < 7) {	fld.style.background = 'Yellow'; 	error = "The information in " + fld.name + " is of wrong length.\n";
	} else if (illegalChars.test(fld.value)) { 	fld.style.background = 'Yellow';	error = "The information in " + fld.name + " contains illegal characters.\n";
	} else {fld.style.background = 'White';}return error;
}function validateNo(fld) {
	var error = "",stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');
	if (fld.value == "") {error = "You have no entered information required in " + fld.name + ".\n"; 	fld.style.background = 'Yellow';
	}else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {error = "Enter valid value in " + fld.name + ".\n";	fld.style.background = 'Yellow';
	}return error;
}function addCommas(nStr){
	nStr+='';	if(nStr.indexOf('.')==-1) nStr+='.00';	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');} return x1+x2;
}function checkInput(ob){
	var invalidChars=/[^0-9\.]/g; if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,"");	ob.value=addCommas(a);}	if (ob.length==0){ob.value="0.00";}
}function confirmDelete(frm){
	let txt=frm.txtDelete.value.replace(/[^a-z0-9\ \,\.]/gi,'');	frm.txtDelete.value=txt;
	if(txt.length>10){return true;} else {alert('Enter valid reason why the PV is to be deleted.');	return false;}
}function sumPaid(opt){
 	let sum=0,x=0,cash=parseFloat(document.querySelector("#txtCash").value.replace(/[^0-9\.]/g,"")),index=parseInt(document.querySelector("#txtNOV").value.replace(/[^0-9\.]/g,"")),ttl=0;
	let cheque=parseFloat(document.querySelector("#txtCheque").value.replace(/[^0-9\.]/g,"")); cash=isNaN(cash)?0:cash; cheque=isNaN(cheque)?0:cheque;
	if(opt==0){//Cash amount entered
		sum=parseFloat(document.querySelector("#txtCHand").value.replace(/[^0-9\.\-]/g,"")); sum=isNaN(sum)?0:sum; x=sum<0?0:sum;
		if(cash>sum){alert("Sorry, You can not spend more than cash at hand.\nCurrent Cash at Hand Of Kshs. "+addCommas(x.toFixed(2))+" has been set."); cash=x;
		document.querySelector("#txtCash").value=addCommas(cash.toFixed(2));}
	}else{// checking cheque amount captured
		sum=parseFloat(document.querySelector("#txtCBank").value.replace(/[^0-9\.\-]/g,"")); sum=isNaN(sum)?0:sum; x=sum<0?0:sum;
		if(cheque>sum){alert("Sorry, You can not spend more than cash at Bank.\nCurrent Cash at Bank Of Kshs. "+addCommas(x.toFixed(2))+" has been set."); cheque=x;
		document.querySelector("#txtCheque").value=addCommas(cheque.toFixed(2));}
	}sum=cash+cheque; document.querySelector("#txtBalance").value=document.querySelector("#txtTotal").value=addCommas(sum.toFixed(2));
	if (sum>0){var i=0;
		while(i<index && sum>0){var bal=Number(document.querySelector("#txtBal_"+i).value.replace(/[^0-9\.]/g,"")); bal=isNaN(bal)?0:bal;
			if(sum>=bal){sum-=bal;document.querySelector("#txtAmount_"+i).value=addCommas(bal);ttl+=bal;}else{document.querySelector("#txtAmount_"+i).value=addCommas(sum);ttl+=sum;sum=0;}i++;
		}
	}else{for(var i=0;i<index;i++) document.querySelector("#txtAmount_"+i).value="0.00";}
	document.querySelector("#txtCosted").value=addCommas(ttl); document.querySelector("#txtBalance").value=addCommas(sum);
}function checkCompute(i){
	var sum=amt=curramt=availamt=0,a=1,found=false,n=parseInt(document.querySelector("#txtNOV").value); n=isNaN(n)?1:n;
	//checking expenditure beyond available income
	curramt=Number(document.querySelector("#txtAmount_"+i).value.replace(/[^0-9\.]/g,'')); availamt=Number(document.querySelector("#txtAvailable_"+i).value.replace(/[^0-9\.]/g,''));
	availamt=(isNaN(availamt)||availamt<0)?0:availamt; curramt=(isNaN(curramt)||curramt<0)?0:curramt; amt=curramt;
	if(curramt>availamt){found=confirm("You are spending more than amount available in this votehead.\nIf you are sure click OK to continue.");
			if(!found){curramt=availamt; document.querySelector("#txtAmount_"+i).value=addCommas(curramt);}
	}	//checking expenditure beyond available income
	availamt=Number(document.querySelector("#txtBal_"+i).value.replace(/[^0-9\.]/g,'')); availamt=(isNaN(availamt)||availamt<0)?0:availamt;
	if(curramt>availamt){alert("You are spending more than balance on this votehead.\nThe correct amount has been reset.");
			document.querySelector("#txtAmount_"+i).value=addCommas(availamt); curramt=availamt;
	}	//checking expenditure beyond budget
	var budget=Number(document.querySelector("#txtBudget_"+i).value.replace(/[^0-9\.]/g,''));
	if(curramt>budget){found=confirm("You are spending more than amount budgeted in this votehead.\nIf you are sure click OK to continue.");
			if(!found){document.querySelector("#txtAmount_"+i).value="0.00";curramt=0;}
	}//calculate total distribution
	 for (var a=0;a<n;a++){amt=Number(document.querySelector("#txtAmount_"+a).value.replace(/[^0-9\.]/g,''));
 		if (!(isNaN(amt))) sum+=amt;	document.querySelector("#txtAmount_"+a).value=addCommas(amt);
	}	amt=Number(document.querySelector("#txtTotal").value.replace(/[^0-9\.]/g,'')); amt=isNaN(amt)?0:amt; amt-=sum;	//finding balance yet to be distributed
	document.querySelector("#txtCosted").value=addCommas(sum.toFixed(2));	document.querySelector("#txtBalance").value=addCommas(amt.toFixed(2));
}function checkMode(cbo){
	let mode=cbo.value.toLowerCase();
	if(mode!=='cash'){document.querySelector("#txtCash").readOnly=(mode==='cheque'?true:false); document.querySelector("#txtCheque").readOnly=false;
		document.querySelector("#cboBankAC").disabled=false;	document.querySelector("#txtCheNo").readOnly=false;
	}else{ document.querySelector("#txtCash").readOnly=false;		document.querySelector("#txtCheque").readOnly=true;
		document.querySelector("#txtCheNo").readOnly=true;		document.querySelector("#cboBankAC").disabled=true;
	}
}
