function SalDef(pfno,idno,name,desi,pp,bsal,house,med,trav,resp,empn,nssf,nssfv,nhif,paye,mpr,ole,uni,sac,welf,helb){
    this.pfno=pfno;this.idno=idno;this.name=name;this.desi=desi;this.pp=pp;this.bsal=bsal;this.house=house;this.med=med;this.trav=trav;this.resp=resp;this.empn=empn;
    this.nssf=nssf;this.nssfv=nssfv;this.nhif=nhif;this.paye=paye;this.mpr=mpr;this.ole=ole;this.uni=uni;this.sac=sac;this.welf=welf;this.helb=helb;
}var saldef=[];
function payrollVerify(opt,priv){
    if(priv==1){
        alert('Sorry you do not have the priviledge to '+(opt==0?'confirm':(opt==1?'approve':'unapprove'))+' payrolls.');
        return false;
    }else{
        if(confirm('You are about to '+(opt==0?'confirm':(opt==1?'approve':'unapprove'))+' this salary payroll.\nAre you sure of this action.')) return true;
        else return false;
    }
}
function showAmount(txt,opt){
    var n=saldef.length; var found=false,i=0; var pf=txt.value.trim();
    if(pf=="0" && opt===1){
        found=false;
    }else{
        while (i<n && found==false){
            if(saldef[i].pfno=pf){
                if(opt==0){document.getElementById("txtName").value=saldef[i].idno+' '+saldef[i].name+' ('+saldef[i].desi+')';
                }else{ document.getElementById("txtName").value='Member of Staff Selected'; document.getElementById("txtPFNo").value=pf;} document.getElementById("txtPP").value=saldef[i].pp;
                document.getElementById("txtBSal").value=saldef[i].bsal.toFixed(2);         document.getElementById("txtHouse").value=saldef[i].house.toFixed(2); 	
                document.getElementById("txtMed").value=saldef[i].med.toFixed(2);           document.getElementById("txtCommute").value=saldef[i].trav.toFixed(2); 
                document.getElementById("txtResp").value=saldef[i].resp.toFixed(2);         document.getElementById("txtEmpNSSF").value=saldef[i].empn.toFixed(2);
                document.getElementById("txtNSSF").value=saldef[i].nssf.toFixed(2);         document.getElementById("txtVolNSSF").value=saldef[i].nssfv.toFixed(2);
                document.getElementById("txtNHIF").value=saldef[i].nhif.toFixed(2);         document.getElementById("txtPAYE").value=saldef[i].paye.toFixed(2);
                document.getElementById("txtMPR").value=saldef[i].mpr.toFixed(2);           document.getElementById("txtUnion").value=saldef[i].uni.toFixed(2);
                document.getElementById("txtHELB").value=saldef[i].helb.toFixed(2);         document.getElementById("txtSACCO").value=saldef[i].sac.toFixed(2);
                document.getElementById("txtWelfare").value=saldef[i].welf.toFixed(2);      document.getElementById("txtOle").value=saldef[i].ole.toFixed(2);
                getAdvAmt(pf);//getting salary advance
                found=true;
            }
        }
    }if(found){ computeNet(); txt.style.background='white';  document.getElementById("btnSave").disabled=false;
    } else {
        alert('Sorry, either staff member of payroll '+pf+' does not earn from this account or not existing.'); txt.style.background='yellow'; 
        document.getElementById("btnSave").disabled=true;
    }
}
function getAdvAmt(pfno){
    var nocache = Math.random() * 10000; //stop caching 
    if (window.XMLHttpRequest) {
    xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    }xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200){
            var adv=this.responseText; var s=adv.split("~"); var n=parseFloat(s[0]); n=isNaN(n)?0:n;
            document.getElementById("txtAdvSql").value=s[1];
            document.getElementById("txtAdv").value=n.toFixed(2);
        }
    };
    xmlhttp.open('GET','ajax/getSalAdvAmt.php?q='+pfno+'-'+nocache,true); 
    xmlhttp.send();
}
function addCommas(nStr){
    nStr+='';
    var x=nStr.split('.');
    var x1=x[0];
    var x2=x.length>1?('.'+x[1]):'';
    var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
    return x1+x2;
}
function checkInput(ob){
    var invalidChars=/[^0-9\.]/gi;
    if (invalidChars.test(ob.value)){
            var a=ob.value.replace(invalidChars,"");
            ob.value=addCommas(a);
    }
    if (ob.length==0){
            ob.value="0";
    }
}
function getGrossSal(){
    var gsal=0;
    var n=document.getElementById("txtBSal").value; 	var x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("txtBSal").value=addCommas(x.toFixed(2));}  
    n=document.getElementById("txtHouse").value; 			x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
    if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("txtHouse").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtMed").value; 			x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
    if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("txtMed").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtCommute").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
    if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("txtCommute").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtResp").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
    if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("txtResp").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtEmpNSSF").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
    if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("txtEmpNSSF").value=addCommas(x.toFixed(2));}
    return gsal;
}
function computeNet(){
    var gsal=getGrossSal(); var ded=0;
    document.getElementById("txtGSal").value=addCommas(gsal.toFixed(2));
    //Total Deduction Calculation
    n=document.getElementById("txtNSSF").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtNSSF").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtEmpNSSF").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtEmpNSSF").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtVolNSSF").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtVolNSSF").value=addCommas(x.toFixed(2));} 
    n=document.getElementById("txtNHIF").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtNHIF").value=addCommas(x.toFixed(2));} 
    n=document.getElementById("txtPAYE").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0) {ded+=x; document.getElementById("txtPAYE").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtMPR").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0) {ded-=x; document.getElementById("txtMPR").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtUnion").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtUnion").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtHELB").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtHELB").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtAdv").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtAdv").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtSACCO").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtSACCO").value=addCommas(x.toFixed(2));} 
    n=document.getElementById("txtWelfare").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtWelfare").value=addCommas(x.toFixed(2));}
    n=document.getElementById("txtOle").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
    if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("txtOle").value=addCommas(x.toFixed(2));}
    //Net salary calculation
    gsal-=ded;	m=gsal.toFixed(2); //format to two decimal places
    document.getElementById("txtNET").value=addCommas(m);
}