function myFunction(choice){
    var input, table, tr,td, i,nos=0;
    var a=(document.getElementById("radPFNo").checked?0:(document.getElementById("radIDNo").checked?1:2)); // salary definition
    input=document.getElementById("txtFind").value.toUpperCase();
    table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
    for(i=2;i<(tr.length-1);i++){
        td=tr[i].getElementsByTagName("td")[a];
        if (td){
            if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display=""; nos++;}
            else tr[i].style.display="none";
        }
    }
    if(choice==0) document.getElementById("spTotal").innerHTML=nos+' Salary Definition Record(s).';
    else  document.getElementById("spNoAdv").innerHTML=nos+' Salary Advance Record(s).';		
}
function clrText(){
    document.getElementById("txtFind").value='';
    document.getElementById("txtFind").focus();
}
function viewSalDef(pr,pfno) {
    if (pr == 0) {
        alert("Sorry, you do not have the priviledges to view record");
    } else {
        viewPayroll(pfno);
        document.getElementById("divSalDef").style.display="block";
    }
}
function viewPayroll(pfno){
    var nocache = Math.random() * 10000; //stop caching 
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    }xmlhttp.onreadystatechange = function() {
        if (this.readyState ===4 && this.status ===200) document.getElementById("divSal").innerHTML = this.responseText;
    };
    xmlhttp.open('GET','ajax/saldefview.php?pfno='+pfno+'-'+nocache,true); 
    xmlhttp.send();	
}