function Payroll(sno,mon,yr,pon,batch,ac,vot,con,app,vac){
 	this.sno=sno; this.mon=mon; this.yr=yr; this.pon=pon; this.batch=batch; this.ac=ac; this.vot=vot; this.con=con; this.app=app;	this.vac=vac;
}function addCommas(nStr){
	nStr+='';	var x=nStr.split('.');	var x1=x[0];	var x2=x.length>1?('.'+x[1]):'';	var rgx=/(\d+)(\d{3})/;	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}function myFunction(ch){
    var input, table, tr,td, i,nos=amt=bs=gs=ns=0;
    if (ch==0){ var a=document.getElementById("radMon").checked?0:1; input=document.getElementById("txtFind").value.toUpperCase(); table=document.getElementById("myTable");
    }else{var a=document.getElementById("radPFNo1").checked?0:(document.getElementById("radIDNo1").checked?1:2);input=document.getElementById("txtFind1").value.toUpperCase();
        table=document.getElementById("myTable1");} tr=table.getElementsByTagName("tr");
    for(i=2;i<tr.length;i++){td=tr[i].getElementsByTagName("td")[a];
        if (td){ if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display="block"; nos++
          if(ch!=0){amt=Number(tr[i].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9^\.]/,''));  bs+=(isNaN(amt)?0:amt);
            amt=Number(tr[i].getElementsByTagName("td")[11].innerHTML.replace(/[^0-9^\.]/,'')); gs+=(isNaN(amt)?0:amt);
            amt=Number(tr[i].getElementsByTagName("td")[21].innerHTML.replace(/[^0-9^\.]/,'')); ns+=(isNaN(amt)?0:amt);}}else tr[i].style.display="none";}}
    if (ch==0){ document.getElementById("spTotal").innerHTML=nos+' Staff Details.';
    }else{document.getElementById("parTotals").innerHTML=nos+' Staff Salaries.'; document.getElementById("ttlBS").innerHTML=addCommas(bs.toFixed(2));
        document.getElementById("ttlGS").innerHTML=addCommas(gs.toFixed(2)); document.getElementById("ttlNS").innerHTML=addCommas(ns.toFixed(2)); }
}function clrText(a){
    if(a==0){document.getElementById("txtFind").value='';document.getElementById("txtFind").focus();}
    else{document.getElementById("txtFind1").value=''; document.getElementById("txtFind1").focus();}
}function monthName(n){
    var mon='';switch (n){
    case 0: mon='january'; break;	case 1: mon='february'; break;	case 2: mon='march'; break;		case 3: mon='april'; break;		case 4: mon='may'; break;
    case 5: mon='june'; break;		case 6: mon='july'; break;		case 7: mon='august'; break;	case 8: mon='september'; break;	case 9: mon='october'; break;
    case 10: mon='november'; break;	case 11: mon='december'; break;}return mon;
}function addNew(opt,pfno){
    if (opt==0){//new payroll
      let dt=new Date(),yr=dt.getFullYear(),mon=monthName(dt.getMonth());document.getElementById("cboMonth1").value=mon;document.getElementById("cboYear1").value=yr;
      document.getElementById("txtSNo1").value='0-0'; document.getElementById('payrollEdit').style.display='block';
    }else{//editing payroll
        let n=payroll.length, found=false, i=0;
        while (i<n && found==false){
            if (payroll[i].sno==pfno){
                document.getElementById("cboVoteAC1").value=payroll[i].vac;	loadBankAC(document.getElementById("cboVoteAC1"));
                document.getElementById("txtSNo1").value="1-"+pfno;		document.getElementById("txtPFNo1").value=pfno;		document.getElementById("txtDate1").value=payroll[i].pon;
                document.getElementById("cboMonth1").value=payroll[i].mon;	document.getElementById("cboYear1").value=payroll[i].yr;
                document.getElementById("txtBatch1").value=payroll[i].batch;	document.getElementById("cboAC1").value=payroll[i].ac;
                document.getElementById("cboVotes1").value=payroll[i].vot;	if (payroll[i].con==1) document.getElementById("chkConfirm").checked=true;
                if (payroll[i].app==1) document.getElementById("chkApprove").checked=true;
                found=true;
            }i++;
        } if (found==true){document.getElementById('payrollEdit').style.display='block';}
    }
}function validateFormOnSubmit1(frm){
    let err='',dt=new Date(),yr=dt.getFullYear(),mon=monthName(dt.getMonth()),selYr=parseInt(frm.cboYear1.value);
    if (isNaN(selYr)){err+='You have not selected a payroll year.\n';frm.cboYear1.style.background='yellow';} else frm.cboYear1.style.background='white';
    if(!isNaN(selYr) && (yr!=selYr)){if(!prompt("Are you sure you want to process salary in the financial year "+selYr+"?")) return false;}
    let selMon=frm.cboMonth1.value;
    if (selMon.length<3){err+='You have not selected a payroll month.\n'; frm.cboMonth1.style.background='yellow';} else frm.cboMonth1.style.background='white';
    if(selMon.length>2 && (yr!=selYr)){if(!prompt("Are you sure you want to process salary of "+selMon.toUpperCase()+" the financial year "+selYr+"?")) return false;}
    let ac=frm.cboAC1.value;
    if (ac.length==0){err+='You have not selected bank account on which the payroll will be debited.\n'; frm.cboAC1.style.background='yellow';} else frm.cboAC1.style.background='white';
    let vote=frm.cboVotes1.value;
    if (vote.length==0){err+='You have not selected votehead on which the payroll will be costed.\n'; frm.cboVotes1.style.background='yellow';} else frm.cboVotes1.style.background='white';
    let vt=document.getElementById("cboVotes1"); vote=vt.options[vt.selectedIndex].text;
    if (vote.toUpperCase().trim().indexOf('EMOLU')==-1){//if vote
      if(!prompt("Are you sure you want to process salary of "+selMon.toUpperCase()+" the financial year "+selYr+"?")) return false;
    }if(err.length>0){alert('The following errors are to be corrected first.\n'+err); return false;}else return true;
}function connectDBase(){
    if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    }return xmlhttp;
}function viewPayroll(nsal,canviu,pn){
    if (canviu==0){alert('You do not have the rights to view payroll details.');
    }else{var nocache = Math.random() * 10000;xmlhttp=connectDBase();
        xmlhttp.onreadystatechange = function(){if (this.readyState == 4 && this.status == 200) document.getElementById("divPayroll").innerHTML = this.responseText;};
        xmlhttp.open('GET','ajax/showpayroll.php?q='+nsal+'-'+pn+'-'+nocache,true); xmlhttp.send();
    }
}function loadBankAC(cbo){
    var acno=parseInt(cbo.value);
    if(!isNaN(acno)){ var nocache = Math.random() * 10000; xmlhttp=connectDBase();
        xmlhttp.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) document.getElementById("spBanks1").innerHTML = this.responseText;};
        xmlhttp.open('GET','ajax/showpayrollvotes.php?q=0-'+acno+'-'+nocache,true);xmlhttp.send();
    }else document.getElementById("spBanks1").innerHTML='Bank Accounts Missing!!!!!!'; loadVotes();
}function loadVotes(){
    var acno=parseInt(document.getElementById('cboVoteAC1').value);
    if(!isNaN(acno)){var nocache = Math.random() * 10000; xmlhttp=connectDBase();
        xmlhttp.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) document.getElementById("spVotes1").innerHTML = this.responseText;};
        xmlhttp.open('GET','ajax/showpayrollvotes.php?q=1-'+acno+'-'+nocache,true);xmlhttp.send();
    }else document.getElementById("spVotes1").innerHTML='Voteheads Missing!!!!!!';
}function canedit(pr) {
    if (pr == 0) {alert("Sorry, you do not have the priviledges to edit the record");return false;} else {return true;}
}function payrollVerify(opt,priv){//opt 0- Confirm, 1- Approve,2 -Unapprove payroll
  if(priv==0){alert("Sorry, You do not have the priviledge to "+(opt==0?"confirm":(opt==1?"approve":"unapprove"))+" the payroll."); return false;}
  else return true;
}
