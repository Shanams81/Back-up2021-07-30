function Voteheads(ac,vsno,vname){
  this.ac=ac; this.vsno=vsno; this.vname=vname;
}var thevotes=[],thesundry=[];
function fillVotes(cbo,cuyr){
  var ac = parseInt(cbo.value),yr=Number(document.querySelector("#txtYr_1").value);//Year of credit
  clrVotes();
  if (ac>0){
    let htmlSelect=document.querySelector("#cboVote_1"); selectBoxOption = document.createElement("option"); selectBoxOption.text="CHOOSE VOTEHEAD"; selectBoxOption.value=0;
    htmlSelect.add(selectBoxOption);
    if(cuyr==yr){
      for (var i=0;i<thevotes.length;i++){if (thevotes[i].ac==ac){
          selectBoxOption=document.createElement("option"); selectBoxOption.text=thevotes[i].vname;  selectBoxOption.value=thevotes[i].vsno; htmlSelect.add(selectBoxOption); }
      }
    }else{ //Adding Sundry creditor votehead
      for (var i=0;i<thesundry.length;i++){
        if (thesundry[i].ac==ac){
          selectBoxOption=document.createElement("option"); selectBoxOption.text=thesundry[i].vname; selectBoxOption.value=thesundry[i].vsno; htmlSelect.add(selectBoxOption); }
      }
    }document.querySelector("#cmdSave_1").disabled=false;
  }
}function voteSelected(){
  var v=parseInt(document.querySelector("#cboVote_1").value); v=isNaN(v)?0:v;
  if (v==0){alert('Sorry, You MUST select the votehead to be costed.'); document.getElementById("cmdSave_1").disabled=true;
  }else document.getElementById("cmdSave_1").disabled=false;
}function clrVotes(){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.querySelector("#cboVote_1"); if(mylistbox == null) return;	while(mylistbox.length > 0) mylistbox.remove(0);
}function validateCommt(frm){
  let err='',dt=new Date(),val=Number(frm.txtYr_1.value),yr=dt.getYear();
  if(isNaN(val) || val<yr){err+="Type valid year of commitment\n"; frm.txtYr_1.style.background='Yellow';}
  val=Number(frm.cboAC_1.value);  if(isNaN(val) || val==0){err+="Choose a valid account on which commitment is incurred\n"; frm.cboAC_1.style.background='Yellow';}
  val=Number(frm.cboVote_1.value); if(isNaN(val) || val==0){err+="Choose a valid votehead on which commitment is incurred\n"; frm.txtVote_1.style.background='Yellow';}
  val=Number(frm.txtAmount_1.value.replace(/[^0-9\.]/g,'')); if(isNaN(val) || val<1){err+="Enter valid commitment amount\n"; frm.txtAmount_1.style.background='Yellow';}
  if(frm.txtRmks_1.value.trim().length<10){err+="Type valid commitment narration/remarks\n"; frm.txtRmks_1.style.background='Yellow';}
  if(err.length<1){return true;}else{alert("The following error(s) MUST be corrected before saving\n"+err); return false; }
}function confirmDel(){
  let ans=confirm('You are about to delete this commitment.\nClick OK if you are sure of this action and type reason for it.');
  if(ans){document.querySelector('#divDel').style.display='block'; document.querySelector('.btnDiv').style.visibility='hidden';}
} function enableDel(txt){
  let rmks=txt.value.replace(/[^a-z0-9\,\ \.]/gi,'').toUpperCase();
  txt.value=rmks; document.querySelector('#cmdDelCommt').disabled=(rmks.length>15?false:true);
} function closeDel(){document.querySelector('#divDel').style.display='none'; document.querySelector('.btnDiv').style.visibility='visible';}
function fillVotesBasedOnYr(txt,finyr){
  var ac=Number(document.querySelector("#cboAC_1").value),yr=Number(txt.value);  clrVotes();
  if (ac>0){
    let htmlSelect=document.querySelector("#cboVote_1"); selectBoxOption = document.createElement("option"); selectBoxOption.text="CHOOSE VOTEHEAD"; selectBoxOption.value=0;
    htmlSelect.add(selectBoxOption);
    if(finyr==yr){
      for (var i=0;i<thevotes.length;i++){if (thevotes[i].ac==ac){
          selectBoxOption=document.createElement("option"); selectBoxOption.text=thevotes[i].vname;  selectBoxOption.value=thevotes[i].vsno; htmlSelect.add(selectBoxOption); }
      }
    }else{ //Adding Sundry creditor votehead
      for (var i=0;i<thesundry.length;i++){
        if (thesundry[i].ac==ac){
          selectBoxOption=document.createElement("option"); selectBoxOption.text=thesundry[i].vname; selectBoxOption.value=thesundry[i].vsno; htmlSelect.add(selectBoxOption); }
      }
    }
  }
}
function canedit(pr) {
 	if (pr==0) {alert("Sorry, you do not have the priviledges to edit the record");	return false;
  	} else {return true;}
}
