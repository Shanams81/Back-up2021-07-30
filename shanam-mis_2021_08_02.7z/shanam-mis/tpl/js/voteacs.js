function Accounts(acno,abbr,name,stud,sal,imp,pyt,fse,fs,wd){
	this.acno=acno; this.abbr=abbr; this.name=name; this.stud=stud; this.sal=sal; this.imp=imp; this.pyt=pyt;   this.fse=fse;   this.fs=fs; this.wd=wd;
}var accounts=[];
function showModal(dn,del){
    var i=0,found=false,a=accounts.length;
    while (found==false && i<a){
      if (accounts[i].acno==dn){
        document.getElementById('txtOrigNo1').value=accounts[i].acno;    document.getElementById('txtNo1').value=accounts[i].acno;
        document.getElementById('txtAbbr1').value=accounts[i].abbr;      document.getElementById('txtName1').value=accounts[i].name;
        if(accounts[i].stud==1) document.getElementById('chkStud1').checked=true; else document.getElementById('chkStud1').checked=false;
        if(accounts[i].sal==1) document.getElementById('chkSal1').checked=true; else document.getElementById('chkSal1').checked=false;
        if(accounts[i].imp==1) document.getElementById('chkImp1').checked=true; else document.getElementById('chkImp1').checked=false;
        if(accounts[i].pyt==1) document.getElementById('chkPyt1').checked=true; else document.getElementById('chkPyt1').checked=false;
        if(accounts[i].fse==1) document.getElementById('chkFSE1').checked=true; else document.getElementById('chkFSE1').checked=false;
        if(accounts[i].fs==1) document.getElementById('chkFS1').checked=true; else document.getElementById('chkFS1').checked=false;
	if(accounts[i].wd==1) document.getElementById('chkWithdraw1').checked=true; else document.getElementById('chkWithdraw1').checked=false;
        found=true;
      }i++;
    }if (found==true){document.getElementById('accountEdit').style.display='block';}
    if ((found==true) && (del==1)) document.getElementById('btnDelete').innerHTML='<a href=\"voteacs.php?sno=1-'+dn+'\" onclick=\"return delConfirm();\"><button type=\"button\"  ' +
    'class=\"cancelbtn\" name=\"btnDelete\">Delete Account</button></a>';
    else document.getElementById('btnDelete').innerHTML='';
}
function validateFormOnSubmit(theForm) {
    var reason = ""; reason += validateUsername(theForm.txtName);   reason += validateUsername(theForm.txtAbbr); reason += validateNo(theForm.txtNo);
    if (reason!="") { alert("Some fields need correction:\n" + reason); return false;} else return true;
}function validateUsername(fld) {
	var error = "",illegalChars = /\w/; // allow letters and numbers
	if (fld.value=="") {fld.style.background = 'Yellow'; 	error="You didn't enter the account details.\n";
	}else if (fld.value.length < 3) {fld.style.background = 'Yellow'; error="The account detail is too short.\n";
	} else if (!illegalChars.test(fld.value.replace(",",""))) {fld.style.background = 'Yellow'; error = "The account contains illegal characters.\n";
	} else fld.style.background = 'White';
	return error;
}function validateNo(fld) {
	var error = "",stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');
	if (fld.value=="") {error = "Enter account number before saving.\n"; 	fld.style.background = 'Yellow';
	}else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {	error = "Account number MUST be numeric.\n"; fld.style.background = 'Yellow';}
	return error;
}function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,"");ob.value=a;}if (ob.length==0){ob.value="0";}
}function canedit(pr) {
 	if (pr==0){alert("Sorry, you do not have the priviledges to edit the record");	return false;} else return true;
}
