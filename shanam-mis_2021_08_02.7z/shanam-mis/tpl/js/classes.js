function Lvls(lno,abbr,lna){this.lno=lno; this.lna=lna; this.abbr=abbr;} var clslvl=[];
function Classes(cno,abbr,cna,lno){this.cno=cno; this.cna=cna; this.lno=lno; this.abbr=abbr;} var cls=[];
function saveAndShow(add,opt) {
  if(add==0){alert("Sorry, you do not have priviledge to add new class details.");return;
  }else{ var sno=0,name='',abbr='';
	 	if (opt==0){name=document.getElementById("txtLName").value.trim();abbr=document.getElementById("txtLAbbr").value.trim();
      if(name.length<3 || abbr.length<1){alert('Class level details data has errors to be corrected before saving.'); return;} //class level
		}else if(opt==1){//CLass detials
  		sno=parseInt(document.getElementById("txtCSNo").value);lvl=parseInt(document.getElementById("cboCLvl").value);name=document.getElementById("txtCName").value.trim();abbr=document.getElementById("txtCAbbr").value.trim();
	    if ((isNaN(sno) || sno<1) || (isNaN(lvl) || lvl<1) || name.length<3 || abbr.length<1) {alert('Class detail data not valid. Check and correct before saving.\nSNo'+sno+', lvl'+lvl+', name:'+name+',Abbr:'+abbr); return; }
		}var nocache = Math.random()*10000; //stop caching
		if (window.XMLHttpRequest){xmlhttp=new XMLHttpRequest();}else{xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
    xmlhttp.onreadystatechange=function(){if(this.readyState==4 && this.status==200){
      if (opt===0) document.getElementById("lvlShow").innerHTML=this.responseText; else if (opt==1) document.getElementById("clsShow").innerHTML=this.responseText; }
    };if (opt===0){xmlhttp.open('GET','ajax/classessave.php?q=0-'+name+'-'+nocache,true); xmlhttp.send();	document.getElementById("frmLvl").reset();
    }else if (opt==1){xmlhttp.open('GET','ajax/classessave.php?q=1-'+sno+'-'+lvl+'-'+name+'-'+nocache,true);xmlhttp.send();	document.getElementById("frmCls").reset();}
	}
}function showModal(t,dn){
  let i=0,found=false;
	if(t===1){let a=clslvl.length;//class level details
    while (found==false && i<a){if (clslvl[i].lno==dn){document.getElementById('txtOLSNo1').value=document.getElementById('txtLSNo1').value=clslvl[i].lno;document.getElementById('txtLName1').value=clslvl[i].lna;
        document.getElementById('txtLAbbr1').value=clslvl[i].abbr;   found=true;}i++;
    }if (found===true) document.getElementById('clsLvlEdit').style.display='block';
	}else {var a=cls.length;//classes
		while (found===false && i<a){if (cls[i].cno==dn){ document.getElementById('txtOCSNo1').value=document.getElementById('txtCSNo1').value=dn;document.getElementById('cboCLvl1').value=cls[i].lno;
      document.getElementById('txtCName1').value=cls[i].cna;  document.getElementById('txtCAbbr1').value=cls[i].abbr;  found=true;  }i++;
	  }if (found===true) document.getElementById('clsEdit').style.display='block';
	}
}function checkNumber(ob){
	var invalidChars=/[^0-9]/g; if (invalidChars.test(ob.value)){let a=ob.value.replace(invalidChars,""); ob.value=a;}if (ob.length==0){ob.value=1;}
}function onSubmitConfirm1(frm){
	var err="",sno=parseInt(frm.txtLSNo1.value.trim()),name=frm.txtLName1.value.trim(),abbr=frm.txtLAbbr1.value.trim();
	if (isNaN(sno)||sno<1||name.length<3||abbr.length<1){err="Sorry, Class level data being submitted is insufficient. Verify data before saving.";}
	if (err.length>2){alert(err); return false;}else{return true;}
}function onSubmitConfirm2(frm){
	var err="",sno=parseInt(frm.txtCSNo1.value.trim()),lno=parseInt(frm.cboCLvl1.value.trim()),name=frm.txtCName1.value.trim(),abbr=frm.txtCAbbr1.value.trim();
	if (isNaN(sno)||sno<1||isNaN(lno)||lno<1||name.length<3||abbr.length<1){err="Sorry, Class data being submitted is insufficient. Verify data before saving.";}
	if (err.length>2){alert(err); return false;}else{return true;}
}
