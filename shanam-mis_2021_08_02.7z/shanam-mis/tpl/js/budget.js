function Votes(vno,vname,ac){
    this.vno=vno; this.vname=vname; this.ac=ac;
} var votes=[];
function ClearCont(){ // returns 1 if all items are sucessfully removed otherwise returns zero.
    var mylistbox = document.getElementById('CboVote');
    if(mylistbox == null) return 1;
    while(mylistbox.length > 0) mylistbox.remove(0);
    return 1;
}
function fillVotes(cbo){
    var i=ClearCont();
    var acc=parseInt(cbo.value.trim()); acc=isNaN(acc)?0:acc;
    var len=votes.length;
    var htmlSelect=document.getElementById('CboVote');
    var selectBoxOption = document.createElement("option");
    selectBoxOption.value = "%";
    selectBoxOption.text = "All";
    htmlSelect.add(selectBoxOption);
    for (var a=0;a<len;a++){
        if ((votes[a].ac==acc) && votes[a].vname.length>0){
            selectBoxOption = document.createElement("option");
            selectBoxOption.text = votes[a].vname;
            selectBoxOption.value = votes[a].vno;
            htmlSelect.add(selectBoxOption);
        }	
    }
}
function setVote(){
    var v=document.getElementById("CboVote").value.trim();
    if ((v!='%') && (isNaN(Number(v)))){
        alert("Please, select the votehead whose budget item(s) are to be added");
        return false;
    }else return true;
}
function enableAdd(a){
    var v=Number(document.getElementById("CboVote").value.trim());
    var acc=Number(document.getElementById("CboAccount").value.trim());
    if (!isNaN(v) && !isNaN(acc) && a==1) document.getElementById("cmdNew").disabled=false;
    else document.getElementById("cmdNew").disabled=true;
}