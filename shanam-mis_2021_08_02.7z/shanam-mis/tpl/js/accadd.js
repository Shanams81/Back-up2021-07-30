function Accounts(sno,name,type,acc,acno,date,bank,branch,fa){this.sno=sno; this.name=name; this.type=type; this.acc=acc; this.acno=acno;this.date=date;this.bank=bank;this.branch=branch;
this.fa=fa;}var accounts=[];
function Banks(sno,abbr,descr,addr,tel,code,swift){this.sno=sno;this.abbr=abbr;this.descr=descr;this.addr=addr;this.tel=tel;this.code=code;this.swift=swift;} var banks=[];
function showModal(opt,dn,del){
    var i=0,found=false;
    if (opt==0){
		  var a=banks.length; var delHtml=document.getElementById('btnDeleteBank');
	    while (found==false && i<a){
        if (banks[i].sno==dn){
          document.getElementById('txtBSNo1').value=banks[i].sno;    		document.getElementById('txtBankAbbr1').value=banks[i].abbr;
          document.getElementById('txtBankName1').value=banks[i].descr; document.getElementById('txtBankAddress1').value=banks[i].addr;
  				document.getElementById('txtBankTel1').value=banks[i].tel;   	document.getElementById('txtBankCode1').value=banks[i].code;
  				document.getElementById('txtBankSwift1').value=banks[i].swift;  found=true;
        }i++;
	    }if (found==true){
		 	document.getElementById('bankEdit').style.display='block';
			if (del==1) delHtml.innerHTML='<a href=\"accounts.php?sno=2-'+dn+'\" onclick=\"return delConfirm();\"><button type=\"button\" class=\"cancelbtn\" name=\"btnBDelete\">'+
			'Delete Account</button></a>'; else delHtml.innerHTML='';
		}
	}else{
		var a=accounts.length; var delHtml=document.getElementById('btnDelete');
	    while (found==false && i<a){
	        if (accounts[i].sno==dn){
	            document.getElementById('txtSNo1').value=accounts[i].sno;    	document.getElementById('cboType1').value=accounts[i].type;
	            document.getElementById('txtName1').value=accounts[i].name;     document.getElementById('cboAcc1').value=accounts[i].acc;
	            document.getElementById('txtAC1').value=accounts[i].acno;  		document.getElementById('txtDate1').value=accounts[i].date;
				      document.getElementById('cboBank1').value=accounts[i].bank;  	document.getElementById('txtBranch1').value=accounts[i].branch;
				      if (accounts[i].fa==1) document.getElementById('chkFA1').checked=true; else document.getElementById('chkFA1').checked=false;
	            found=true;
	        }i++;
	    }if (found==true){document.getElementById('accountEdit').style.display='block';}
		if ((found==true) && (del==1)) delHtml.innerHTML='<a href=\"accounts.php?sno=1-'+dn+'\" onclick=\"return delConfirm();\"><button type=\"button\"  class=\"cancelbtn\" '+
		'name=\"btnDelete\">Delete Account</button></a>';
		else delHtml.innerHTML='';
	}
}
function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateUsername(theForm.txtName);
	reason += validateNo(theForm.cboBank);
	reason += validateUsername(theForm.txtBranch);
  	reason += validateNo(theForm.txtAcc);
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}function validateBanks(theForm) {
	var reason = "";
	reason += validateUsername(theForm.txtBankName);
	reason += validateUsername(theForm.txtBankAbbr);
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}function validateBanks1(theForm) {
	var reason = "";
	reason += validateUsername(theForm.txtBankName1);
	reason += validateUsername(theForm.txtBankAbbr1);
  	if (reason!=="") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error="";
	var illegalChars = /\w/; // allow letters and numbers
	if (fld.value=="") {
    	fld.style.background = 'Yellow';
    	error = "You didn't enter the bank/account details.\n";
	} else if (fld.value.length < 2) {
    	fld.style.background = 'Yellow';
    	error = "The bank/account detail is too short.\n";
	} else if (!illegalChars.test(fld.value.replace(",",""))) {
    	fld.style.background = 'Yellow';
    	error = "The bank/account contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	}
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');
	if (fld.value == "") {
    	error = "Enter account number before saving.\n";
    	fld.style.background = 'Yellow';
	} else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {
    	error = "Account number MUST be numeric.\n";
    	fld.style.background = 'Yellow';
	}
	return error;
}
function checkInput(ob){
	var invalidChars=/[^0-9]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=a;
	}
	if (ob.length==0){
	 	ob.value="";
	}
}
function canedit(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to edit the record");
    	return false;
  	}else return true;
}
