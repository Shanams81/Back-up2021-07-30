function Voteheads(voteno,acc,vname,budget,income,cost){this.voteno=voteno; this.acc=acc; this.vname=vname; this.budget=budget; this.income=income; this.cost=cost;}
function BankBal(sno,bal){this.sno=sno; this.bal=bal;} var bankbal=[]; var voteheads=[];
function CashBal(acc,bal){this.acc=acc; this.bal=bal;} var cashbal=[];
function BankAC(sno,ac,bname){this.sno=sno; this.ac=ac; this.bname=bname;} var bankac=[];
function ExpVotes(voteno,amt){this.voteno=voteno; this.amt=amt;} var expvotes=[];
function connect(){if (window.XMLHttpRequest){return new XMLHttpRequest();}else{return new ActiveXObject("Microsoft.XMLHTTP");}}
function loadVoteBal(opt){	var nocache = Math.random() * 10000,acc=opt.value;
	if(acc>0){let	xmlhttp=connect();
	  xmlhttp.onreadystatechange = function(){if (this.readyState==4 && this.status==200) {
			var re=this.responseText,ans=re.split('~'),found=false,i=0,c=0; 	document.querySelector("#txtVNo").value=ans[0];	document.querySelector("#spBanks").innerHTML=ans[1];
			while(i<cashbal.length && !found){if(cashbal[i].acc==acc){found=true;document.querySelector("#txtCashHand").value=addCommas(cashbal[i].bal);}i++;}
			for(i=1;i<5;i++){clrLstBox("cboVote_"+i); addLstBox("cboVote_"+i,'Select Votehead',0);}
			while(c<voteheads.length){ if(voteheads[c].acc==acc){for(i=1;i<5;i++) addLstBox("cboVote_"+i,voteheads[c].vname,voteheads[c].voteno);}c++;}
		}}; xmlhttp.open('GET','ajax/votebalances.php?q=0-'+acc+'-'+nocache,true);		xmlhttp.send();
	}else{//No account selected
		document.querySelector("#txtVNo").value=''; for(var i=1;i<5;i++){clrLstBox("cboVote_"+i); addLstBox("cboVote_"+i,'Select Votehead',0);}
		document.querySelector("#spBanks").innerHTML='<SELECT name="cboBankAC" id="cboBankAC" size="1" class="modalinput" disabled><option value=\"0\" selected>Choose Bank A/C</option></SELECT>';
	}
}function showBankBal(cbo){
	let sno=parseInt(cbo.value),l=i=0,found=false; sno=isNaN(sno)?0:sno;
	if(sno>0){while(i<bankbal.length && !found){if(bankbal[i].sno==sno){found=true;document.querySelector("#txtCashBank").value=addCommas(bankbal[i].bal);}i++;}}
	else document.querySelector("#txtCashBank").value="0.00";
}function clrLstBox(lstBox){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(lstBox); if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0); return 1;
}function addLstBox(lstBox,name,value){
	let htmlSelect=document.getElementById(lstBox),selectBoxOption = document.createElement("option");
	selectBoxOption.value = value;	selectBoxOption.text = name;	htmlSelect.add(selectBoxOption);
}function loadPayee(txt){
	var idno=txt.value, nocache=Math.random()*10000; //stop caching
	if(idno.length>4){ xmlhttp=connect();
	  xmlhttp.onreadystatechange=function(){
	    if (this.readyState==4 && this.status==200){ var re=this.responseText;
				if(re.length>3){re=re.split('~'); document.querySelector("#txtPayNo").value=re[0]; document.querySelector("#txtPayee").value=re[1]; document.querySelector("#txtAddress").value=re[3];
					document.querySelector("#txtTelNo").value=re[2]; document.querySelector("#txtEMail").value=re[4];
				}else{document.querySelector("#txtPayee").readOnly=false; document.querySelector("#txtAddress").readOnly=false; document.querySelector("#txtPayNo").value=0;
					document.querySelector("#txtTelNo").readOnly=false;	document.querySelector("#txtEMail").readOnly=false;}
			}
	  }; xmlhttp.open('GET','ajax/votebalances.php?q=1-'+idno+'-'+nocache,true);	xmlhttp.send();
	}//else{alert('The ID No. '+idno+' is too short.\nEnter a valid ID No. before continuing');}
}function enableDel(txt){
	var t=txt.value.replace(/[a-z\ \.\,]/g,'');		txt.value=t;
	if (t.length>10) document.querySelector("#btnDelete").disabled=false; else document.querySelector("#btnDelete").disabled=true;
}function checkNames(txt){
	let nm=txt.value.replace(/[^a-z\ \.]/gi,''); txt.value=nm;
}function getBalances(v,a){
	var found=false, i=0, l=voteheads.length;
	while (i<l && !found){
		if (voteheads[i].voteno==v){
				found=true; document.querySelector("#txtBudget_"+a).value=addCommas(voteheads[i].budget); document.querySelector("#txtIncome_"+a).value=addCommas(voteheads[i].income);
				document.querySelector("#txtCost_"+a).value=addCommas(voteheads[i].cost);
				document.querySelector("#txtAvailable_"+a).value=addCommas(parseFloat(voteheads[i].income)-parseFloat(voteheads[i].cost));
		}i++;
	}if(!found){ document.querySelector("#txtBudget_"+a).value="0.00";	document.querySelector("#txtIncome_"+a).value="0.00"; document.querySelector("#txtCost_"+a).value="0.00";
		document.querySelector("#txtAvailable_"+a).value="0.00";
	}
}function assignAmts(a){
		var bal=calcTtl(a),vote=Number(document.querySelector("#cboVote_"+a).value);
		if(vote>0){getBalances(vote,a);
		}else if(bal<1){document.querySelector("#txtAmount_"+a).disabled=true;}
}function validateFormOnSubmit(theForm) {
	var reason="", i=parseFloat(theForm.txtTotal.value.replace(/[^0-9\.]/g,"")), acno=Number(theForm.cboBankAC.value);
	if(i==0){theForm.txtCash.style.background='Yellow'; theForm.txtCheque.style.background='Yellow';	reason+="You MUST enter the cash and/or Cheque amount being spend before saving.\n";
	} i=parseFloat(theForm.txtBalance.value.replace(/[^0-9\.]/g,''));
	if(i!=0){theForm.cboVote_1.style.background='Yellow';	theForm.txtAmount_1.style.background='Yellow'; theForm.txtAmount_1.focus();
		reason+="Ensure the you have correctly distributed the amount to respective voteheads before saving\n";
	}reason+=validateNo(theForm.txtIDNo); reason+=validateUsername(theForm.txtPayee); i=theForm.txtCheNo.value;
  if(theForm.cboPytFrm.value.toLowerCase()!=="cash" && (i.length==0 || isNaN(acno))){
		reason+="You MUST enter cheque number and select bank A/C for this pettycash payment before saving\n";	theForm.txtCheNo.style.background='Yellow';
	}if(i.length>0) reason+=validateNo(theForm.txtCheNo); i=theForm.txtEMail.value;
	if(i.length>0) reason+=validateEmail(i);	i=theForm.txtAddress.value;
	if((i.toUpperCase()=="P.O BOX ") || (i.length<10)){reason+="Enter valid postal address of the payee for this pettycash payment.\n"; theForm.txtAddress.style.background='Yellow';
	} i=theForm.txtRmks.value;
	if(i.toUpperCase()=="BEING PAYMENT FOR " || i.length<20){reason+="Enter valid reason/remarks for the pettycash payment.\n"; theForm.txtRmks.style.background='Yellow';
	}if(reason.length>0){alert("Some fields need correction before saving:\n"+reason); 	return false;
  }else{for(i=1;i<5;i++){document.querySelector("#cboVote_"+i).disabled=false;	document.querySelector("#txtAmount_"+i).disabled=false;} document.querySelector("#cboBankAC").disabled=false;
		return true;}
}function showDelete(){document.querySelector('.modal').style.display='block';}
function validateEmail(mail){var err=''; if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(mail)) err='';
	else err='This email address is invalid\n';	return err;
}function validateUsername(fld) {var error="",illegalChars=/\d/; // allow letters, numbers, and underscores
	if(fld.value==""){fld.style.background='Yellow'; error="You didn't type the information required in "+fld.name+".\n";
	}else if(fld.value.length<7){fld.style.background='Yellow'; error="The information in "+fld.name+" is of wrong length.\n";
	}else if(illegalChars.test(fld.value)){fld.style.background='Yellow';	error="The information in "+fld.name+" contains illegal characters.\n";
	}else{fld.style.background='White';} return error;
}function validateNo(fld) {
	var error = "",stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');
	if (fld.value == "") {error = "You have no entered information required in " + fld.name + ".\n"; 	fld.style.background = 'Yellow';
	} else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {error = "Enter valid value in " + fld.name + ".\n";	fld.style.background = 'Yellow';
	}return error;
}function addCommas(nStr){
	nStr+='';	if(nStr.indexOf('.')==-1) nStr+='.00';	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}function checkInput(ob){
	var invalidChars=/[^0-9\.]/g;	if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,"");	ob.value=addCommas(a);}	if (ob.length==0){ob.value="0.00";}
}function confirmDelete(frm){
	let txt=frm.txtDelete.value.replace(/[^a-z0-9\ \,\.]/gi,'');frm.txtDelete.value=txt;
	if(txt.length>10){return true;}else{alert('Enter valid reason why the PV is to be deleted.');	return false;}
}function sumPaid(act,opt){//act 0-new,1-Edit. opt 0-On Cash Amount,1-On Cheque Amount
 	let sum=x=n=m=cash=cheque=0;
	if(act==1){cash=Number(document.querySelector("#txtOCash").value.replace(/[^0-9\.]/g,""));cheque=Number(document.querySelector("#txtCheque").value.replace(/[^0-9\.]/g,""));
		cash=isNaN(cash)?0:cash; cheque=isNaN(cheque)?0:cheque; //original cash and cheque amounts
	}n=Number(document.querySelector("#txtCash").value.replace(/[^0-9\.]/g,""));m=Number(document.querySelector("#txtCheque").value.replace(/[^0-9\.]/g,""));n=isNaN(n)?0:n; m=isNaN(m)?0:m;
	if(opt==0){x=Number(document.querySelector("#txtCashHand").value.replace(/[^0-9\.]/g,""));
		if(n>(x+cash)){alert('You cannot spend more than Kshs. '+addCommas((x>0?x:0))+' at hand.\nCash amount has been reset.');document.querySelector("#txtCash").value=addCommas(cash);}
	}else{x=Number(document.querySelector("#txtCashBank").value.replace(/[^0-9\.]/g,""));
		if(m>(x+cheque)){alert('You cannot spend more than Kshs. '+addCommas((x>0?x:0))+' at bank.\nCheque amount has been reset.');document.querySelector("#txtCheque").value=addCommas(cheque);}
	}document.querySelector("#txtTotal").value=addCommas(m+n); n=calcTtl(0);
	if(act==0){if(n>0){document.querySelector("#cboVote_1").disabled=false;	document.querySelector("#txtAmount_1").disabled=false;
		}else{document.querySelector("#cboVote_1").disabled=true;	document.querySelector("#txtAmount_1").disabled=true;}
	}
}function calcTtl(i){
	var sum=x=0,a=1,found=false;
	for (a=1;a<5;a++){x=Number(document.querySelector("#txtAmount_"+a).value.replace(/[^0-9\.]/g,'')); x=isNaN(x)?0:x;sum+=x;if(x>0) document.querySelector("#txtAmount_"+a).value=addCommas(x);
	}	x=Number(document.querySelector("#txtTotal").value.replace(/[^0-9\.]/g,'')); x=isNaN(x)?0:x; x-=sum;	//finding balance yet to be distributed
	document.querySelector("#txtCosted").value=addCommas(sum.toFixed(2));	document.querySelector("#txtBalance").value=addCommas(x.toFixed(2)); return x; //balance for distribution
}function checkMode(cbo){
	let mode=cbo.value.toLowerCase();
	if(mode!=='cash'){document.querySelector("#txtCash").readOnly=(mode==='cheque'?true:false); document.querySelector("#txtCheque").readOnly=false;
		document.querySelector("#cboBankAC").disabled=false;	document.querySelector("#txtCheNo").readOnly=false;
	}else{ document.querySelector("#txtCash").readOnly=false;		document.querySelector("#txtCheque").readOnly=true;
		document.querySelector("#txtCheNo").readOnly=true;		document.querySelector("#cboBankAC").disabled=true;
	}
}function printSpecific(){
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; disp_setting+"scrollbars=yes,width=650, height=600, left=100, top=25";
	var content_value = document.getElementById("divPettyPyts").innerHTML;	var docprint=window.open("","",disp_setting);
	docprint.document.open();	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title>');
	docprint.document.write('</head><body onLoad="self.print()" style="color:#000000;font-size:10px;"><center>'+content_value+'</body></html>');
	docprint.document.close(); docprint.focus();
}function checkCompute(i){
	let x=calcTtl(i),found=false,vno=Number(document.querySelector("#cboVote_"+i).value);
	if (vno==0){alert("Please, select votehead on which the expenditure is incurred.");	document.querySelector("#cboVote_"+i).style.background='Yellow';
	}else{
		if(i>1){ //Check if user selected same votehead again
			for (var a=1;a<i;a++){if(vno==Number(document.querySelector("#cboVote_"+a).value)){found=true;alert('This votehead is already used above.\nYou can not select it again.');
				document.querySelector("#cboVote_"+a).value=0;	document.querySelector("#cboVote_"+a).style.background='Yellow';}
			}
		}if(!found){document.querySelector("#cboVote_"+i).style.background='White'; //checking expenditure beyond available income
		 	var curramt=Number(document.querySelector("#txtAmount_"+i).value.replace(/[^0-9\.]/g,'')), availamt=Number(document.querySelector("#txtAvailable_"+i).value.replace(/[^0-9\.]/g,''));
			availamt=(isNaN(availamt)||availamt<0)?0:availamt;
			if(curramt>availamt){found=confirm("You are spending more than amount available in this votehead.\nIf you are sure click OK to continue.");
				if(!found){curramt=availamt; document.querySelector("#txtAmount_"+i).value=addCommas(curramt);}
			}	//checking expenditure beyond budget
		 	var budget=Number(document.querySelector("#txtBudget_"+i).value.replace(/[^0-9\.]/g,'')), cost=Number(document.querySelector("#txtCost_"+i).value.replace(/[^0-9\.]/g,''));
			availamt=cost+curramt;
			if(availamt>budget){found=confirm("You are spending more than amount budgeted in this votehead.\nIf you are sure click OK to continue.");
				if(!found){curramt=availamt; document.querySelector("#txtAmount_"+i).value=addCommas(curramt);}
			}	i++; let nxtamt=Number(document.querySelector("#txtAmount_"+i).value.replace(/[^0-9\.]/g,''));
			if ((x>0 && i<5 && curramt>0) ||(nxtamt>0)){document.querySelector("#cboVote_"+i).disabled=false;	document.querySelector("#txtAmount_"+i).disabled=false;
			}else{document.querySelector("#cboVote_"+i).disabled=true;	document.querySelector("#txtAmount_"+i).disabled=true;}
		}
	}
}
