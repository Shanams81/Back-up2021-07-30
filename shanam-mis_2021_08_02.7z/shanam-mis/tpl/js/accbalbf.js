function checkNumber(txt){
  var v=txt.value.replace(/[^0-9\.\-]/g,""); v=v.length==0?"0.00":v;
  txt.value=v;
}function fmtNumber(dat){
	var v=dat.value.replace(/[^0-9\.\-]/g,""); v=v.length==0?"0.00":v;
	dat.value=addCommas(v);
}function addCommas(nStr){
	nStr+=''; var x=nStr.split('.');	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}function editBankBal(i){
  document.querySelector("#txtInfo1").value=document.querySelector("#txtACSNo_"+i).value;
  document.querySelector("#txtNewBal1").value=document.querySelector("#txtCurrBal1").value=document.querySelector("#txtBal_"+i).value;
  document.querySelector("#divbankacname1").innerHTML=document.querySelector("#divACName_"+i).innerHTML;
  document.querySelector("#divBankBalEdit").style.display='block';
}function editACBal(i){
  document.querySelector("#txtInfo2").value=document.querySelector("#txtACSNo1_"+i).value;
  document.querySelector("#txtNewBal2").value=document.querySelector("#txtCurrBal2").value=document.querySelector("#txtBal1_"+i).value;
  document.querySelector("#divacname2").innerHTML=document.querySelector("#divACName1_"+i).innerHTML;
  document.querySelector("#divCashBalEdit").style.display='block';
}function validateFormOnSubmit(frm){
  let orig=Number(frm.txtCurrBal1.value.replace(/[^0-9\.\-]/g,"")),curr=Number(frm.txtNewBal1.value.replace(/[^0-9\.\-]/g,"")),err='';
  if(orig==curr) err+="There was no change in Bank A/C balance B/F\n";
  if(isNaN(curr)){err+="Current A/C balance MUST be a number\n"; frm.txtNewBal1.value=0;}
  if(err.length>0){
    alert("The following error(s) to be corrected first:\n"+err); document.querySelector("#divBankBalEdit").style.display='none'; return false;
  }else return true;
}function validateFormOnSubmit2(frm){
  let orig=Number(frm.txtCurrBal2.value.replace(/[^0-9\.\-]/g,"")),curr=Number(frm.txtNewBal2.value.replace(/[^0-9\.\-]/g,"")),err='';
  if(orig==curr) err+="There was no change in Bank A/C balance B/F\n";
  if(isNaN(curr)){err+="Current A/C balance MUST be a number\n"; frm.txtNewBal2.value=0;}
  if(err.length>0){
    alert("The following error(s) to be corrected first:\n"+err); document.querySelector("#divCashBalEdit").style.display='none'; return false;
  }else return true;
}
