function canApprove(pr) {
	if (pr == 0){
		alert("Sorry, you do not have the priviledges to approve or edit the requisition record");
		return false;
	}else{
		return true;
	}
}
function myFunction(){
	var input, table, tr,td, i,nos=0,ttl=0;
	var a=(document.getElementById("radReqNo").checked?0:(document.getElementById("radDept").checked?2:3)); // Requisition search criteria
	input=document.getElementById("txtFind").value.toUpperCase();
	table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
	for(i=2;i<(tr.length-1);i++){
		td=tr[i].getElementsByTagName("td")[a];
		if (td){
			if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){
			 	tr[i].style.display=""; nos++;
				var amt=Number(tr[i].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9^\.]/,'')); ttl+=isNaN(amt)?0:amt;
			}else tr[i].style.display="none";
		}
	}
	document.getElementById("spTotal").innerHTML=addCommas(ttl.toFixed(2));
	document.getElementById("spNoImp").innerHTML=nos+' Imprest Record(s).';		
}
function clrText(){
	document.getElementById("txtFind").value='';
	document.getElementById("txtFind").focus();
}