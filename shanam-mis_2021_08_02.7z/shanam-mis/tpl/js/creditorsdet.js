function validateFormOnSubmit(theForm) {
	var reason = "";
	if (theForm.txtRmks.value.length<10){
	 	reason+="You MUST enter valid credit remarks\n";
	 	theForm.txtRmks.style.background='Yellow';
	}else{
		theForm.txtRmks.style.background='White';
	}
  	if (parseInt(theForm.cboAC.value)==0 || theForm.cboAC.value.length==0 || theForm.cboVote.value.length==0 || parseInt(theForm.cboVote.value)<0){
		reason+="You MUST select Account and Votehead costed by creditor\n";
		theForm.cboAC.style.background='Yellow'; theForm.cboVote.style.background='Yellow';
	}else{
		theForm.cboAC.style.background='white'; theForm.cboVote.style.background='white';
	}
  	reason += validateNo(theForm.txtAmount);
  	if (reason != "") {
    	alert("The following Credior\'s fields need correction :\n" + reason);
    	return false;
  	} else {
  	 	theForm.cboVote.disabled=false;//enable the combobox for submision of value
  		return true;
  	}
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\+\-\ ]/g, '');     
	if (fld.value == "") {
    	error = "Enter the Creditor\'s telephone number, Amount and ID No. (if exists) before saving.\n";
    	fld.style.background = 'Yellow';
	} else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {
    	error = "The telephone number, amount and/ or ID No. entered are invalid.\n";
    	fld.style.background = 'Yellow';
	} else{
		fld.style.background = 'White';
	}
	return error;
}
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function candel(sb){
 	if (sb==0){
		alert("You do not have the priviledge to delete this record");
		return false;
	} else{
	 	var ans=confirm("Are you sure you want to delete this record?\nClick OK to delete otherwise click Cancel.");
	 	if (ans==true){
			return true;
		}else{
			return false;
		}
	}
}
function formatnumber(obj){
	var n=obj.value;
	n=addCommas(n);
	obj.value=n;
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0.00";
	}
}