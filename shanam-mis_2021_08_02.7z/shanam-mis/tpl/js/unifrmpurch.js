function Uniform(pno,unino,qty){this.pno=pno; this.unino=unino; this.qty=qty; } var uniforms=[];
function editPurchDet(purchno,unino){
    var l=uniforms.length, found=false,i=0;
    while(!found && i<l){
        if (uniforms[i].pno==purchno && uniforms[i].unino==unino){
            found=true; document.getElementById("txtPurchNo1").value=uniforms[i].pno; document.getElementById("cboUnifrm1").value=uniforms[i].unino;
            document.getElementById("txtQty1").value=uniforms[i].qty;
            document.getElementById("txtInfo1").value=uniforms[i].pno+'-'+uniforms[i].unino+'-'+uniforms[i].qty;
        }i++;
    }if (found===true) document.getElementById("divEditUP").style.display='block';
}
function validateFormOnSubmit(frm){
    var msg="";
    var qty=Number(frm.txtQty.value.trim());
    if (isNaN(qty) || (qty<=0)){
        msg+="\nPlease enter quantity/ number of uniform pieces purchased. Quantity must be above Zero.";
        frm.txtQty.style.background='yellow'; frm.txtQty.value=0;
    }
    var uni=Number(frm.cboUnifrm.value);
    if (isNaN(uni) || uni<1){
        msg+="\nThe Select uniform being ordered.\n";
        frm.cboUnifrm.style.background='yellow'; frm.cboUnifrm.value=0;
    }
    if (msg.length!==0){
        alert(msg);
        return false;
    } else { return true;}
}
function checkInput(ob){
    var invalidChars=/[^0-9^]/gi;
    if (invalidChars.test(ob.value)){
        var a=ob.value.replace(invalidChars,"");
        ob.value=a;
    }
    if (ob.length===0){
        ob.value="0";
    }
}
function clearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
    var mylistbox = document.getElementById(listboxID);
    if(mylistbox===null) return 1;
    while(mylistbox.length > 0) mylistbox.remove(0);
    return 1;
}
function loadVotes(cbo){
    var ac=parseInt(cbo.value);
    if (!isNaN(ac) && ac>0){
        var i=clearCont('cboVotes');
        var len=votes.length; i=0;
        while(i<len){
            if(ac===votes[i].acc){
                var opt=document.createElement("option");	opt.text=votes[i].name; opt.value=votes[i].vono;
                document.getElementById('cboVotes').add(opt);
            }i++;
        }
    }else alert("Select valid votehead Account");
}
