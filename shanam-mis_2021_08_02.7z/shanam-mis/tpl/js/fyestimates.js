function addCommas(nStr){	nStr+=''; nStr=(nStr.indexOf('.')>-1?nStr:(nStr+'.00')); var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}function checkInput(ob){let no=Number(ob.value.replace(/[^0-9\.]/g,""));	no=isNaN(no)?0:no; ob.value=no;}
function fmtNumber(ob){let no=Number(ob.value.replace(/[^0-9\.]/g,""));	no=isNaN(no)?0:no; ob.value=addCommas(no);}
function mainTtl(pos,opt){
 	let ttl=0,n=0,amt=0,votes=parseInt(document.getElementById("txtNoVot_"+pos).value.replace(/[^0-9]/g,''));	votes=isNaN(votes)?0:votes;
 	for (var a=0;a<votes;a++){
		if(opt===0){n=parseFloat(document.getElementById("txtPrev_"+pos+"_"+a).value.replace(/[^0-9\.]/g,""));	n=isNaN(n)?0:n;	if(n.toString().indexOf('.')>-1) amt=n; else amt=n+'.00';
		document.getElementById("txtPrev_"+pos+"_"+a).value=addCommas(amt);}else{n=parseFloat(document.getElementById("txtCurr_"+pos+"_"+a).value.replace(/[^0-9\.]/g,""));n=isNaN(n)?0:n;if(n.toString().indexOf('.')>0) amt=n;
		else amt=n+'.00'; document.getElementById("txtCurr_"+pos+"_"+a).value=addCommas(amt);}	ttl+=n;
	} var m=ttl.toFixed(2);	if(opt===0) document.getElementById("txtPrevTtl_"+pos).value=addCommas(m); else document.getElementById("txtCurrTtl_"+pos).value=addCommas(m);
}function validateInput(frm,acc){	let nvotes=0, n=0, prev=0, curr=0;
	for(var a=0;a<acc;a++){nvotes=parseInt(document.getElementById("txtNoVot_"+a).value.replace(/[^0-9\.]/g,""));			nvotes=isNaN(nvotes)?0:nvotes;
		for(var i=0;i<nvotes;i++){n=parseFloat(document.getElementById("txtPrev_"+a+"_"+i).value.replace(/[^0-9\.]/g,""));n=isNaN(n)?0:n; prev+=n;
			n=parseFloat(document.getElementById("txtCurr_"+a+"_"+i).value.replace(/[^0-9\.]/g,"")); n=isNaN(n)?0:n; curr+=n;
		}
	}if(prev>0 || curr>0){return true;}else{alert('Sorry, You MUST define previous and current year\'s Financial estimates before saving');	return false;}
}
