function validateFormOnSubmit(theForm) {
    var reason = "";
    if(Number(document.getElementById("cboItem").value)===0){
        reason+=validateUsername(theForm.txtItem);
        reason+=validateUsername(theForm.cboCateg);
        reason+=validateNo(theForm.txtMax);
        reason+=validateNo(theForm.txtMin);
    }
    reason += validateNo(theForm.txtPQty);
    reason += validateNo(theForm.txtPUP);
    reason += validateNo(theForm.txtQty);
    reason += validateNo(theForm.txtUP);
    if (reason != "") {
        alert("The fields in yellow need correction:\n" + reason);
        return false;
    } else {
        return true;
    }
}
function validateUsername(fld) {
    var error = "";
    var txt=fld.value.replace(/[^0-9a-z\ \,\.]/gi,'');
    if (txt.length===0) {
        fld.style.background = 'Yellow'; 
        error = "You didn't enter the item desccription of the budget.\n";
    } else if (txt.length<4) {
        fld.style.background = 'Yellow'; 
        error = "The information is too short.\n";
    } else {
        fld.style.background = 'White';
    } 
    return error;
}
function validateNo(fld) {
    var error = "";
    var no=Number(fld.value.replace(/[^0-9\.]/g, ''));     
    if (no.length===0) {
        error = "Enter budget quantity and unit price before saving.\n";
        fld.style.background = 'Yellow';
    }else if (isNaN(no)) {
        error = "Budgeted quantity and unit price MUST be greater that zero (0).\n";
        fld.style.background = 'Yellow';
    } 
    return error;
}
function setVisibleNewItem(opt){
   if(opt==0){
        document.getElementById('divOtherDescr').style.display='block';
    }else{document.getElementById('divOtherDescr').style.display='none';} 
}
function showNewDescrOnLoad(){
    let itm=Number(document.getElementById('cboItem').value);
    setVisibleNewItem(itm);
}
function showDescr(cbo){
    let itm=cbo.value.trim();
    setVisibleNewItem(itm);
}
function addCommas(nStr){
    nStr+='';
    let i=nStr.indexOf('.'); if(i===-1) nStr+='.00';
    var x=nStr.split('.');
    var x1=x[0];
    var x2=x.length>1?('.'+x[1]):'';
    var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
    return x1+x2;
}
function checkInput(ob){
    var invalidChars=/[^0-9\.]/gi;
    var a=ob.value.replace(invalidChars,"");
    if (a.length===0){
        ob.value="0.00";
    }else{ob.value=a;}
}
function calcAmt(opt){
    var up=0,qty=0;
    if(opt===0){
        up=Number(document.getElementById('txtPUP').value.replace(/[^0-9\.]/g,''));     up=isNaN(up)?0:up;
        document.getElementById('txtPUP').value=addCommas(up.toFixed(2));
        qty=Number(document.getElementById('txtPQty').value.replace(/[^0-9\.]/g,''));   qty=isNaN(qty)?0:qty;
        document.getElementById('txtPQty').value=addCommas(qty.toFixed(2));
        document.getElementById('txtTtlPrev').value=addCommas((up*qty).toFixed(2));
    }else{
        up=Number(document.getElementById('txtUP').value.replace(/[^0-9\.]/g,''));     up=isNaN(up)?0:up;
        document.getElementById('txtUP').value=addCommas(up.toFixed(2));
        qty=Number(document.getElementById('txtQty').value.replace(/[^0-9\.]/g,''));   qty=isNaN(qty)?0:qty;
        document.getElementById('txtQty').value=addCommas(qty.toFixed(2));
        document.getElementById('txtTtlCur').value=addCommas((up*qty).toFixed(2));
    }
}