function validateFormOnSubmit(theForm) {
    var reason = "";
    if(Number(document.querySelector("#cboUserDept").value)==0){
      reason+="Select the Department Requisitioning\n"+document.querySelector("#cboDept").value;
      document.querySelector("#cboDept").style.background='Yellow';
    }if(Number(document.querySelector("#cboAC").value)==0){
      reason+="Select the votehead account to be costed\n";
      document.querySelector("#cboAC").style.background='Yellow';
    }
    reason+=validateNo(theForm.cboStf);
    reason+=validateUsername(theForm.txtRmks);
    if (reason != "") {
        alert("The fields in yellow need correction:\n" + reason);
        return false;
    } else {
        return true;
    }
}
function validateUsername(fld) {
    var error = "";
    var txt=fld.value.replace(/[^0-9a-z\ \,\.]/gi,'');
    if (txt.length===0 || txt.length<4) {
        fld.style.background = 'Yellow';
        error = "You didn't enter the requisition narration.\n";
    } else {
        fld.style.background = 'White';
    }
    return error;
}
function validateNo(fld) {
    var error = "";
    var no=Number(fld.value.replace(/[^0-9\.]/g, ''));
    if (no.length===0 || isNaN(no)) {
        error = "Select member of staff raising requisition before saving.\n";
        fld.style.background = 'Yellow';
    }
    return error;
}
function showDelReason(){
    document.querySelector("#divDelReason").style.display='block';
    document.querySelector("#txtDelReason").value="";
}
function countLength(txt){
    let val=txt.value.replace(/[^a-z0-9\ \.\,]/gi,'');
    txt.value=val;
    if(val.length>10){
      document.querySelector("#btnDelReq").disabled=false;
    }else{
      document.querySelector("#btnDelReq").disabled=true;
    }
}
function cancelDel(){
  document.querySelector("#txtDelReason").value="";
  document.querySelector("#divDelReason").style.display='none';
}
