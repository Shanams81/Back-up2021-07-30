function Balances(vote,acc,t1,t2,t3,ttl){this.vote=vote;this.acc=acc;this.t1=t1;this.t2=t2;this.t3=t3;this.ttl=ttl;} var balances=[];
function NoVotes(acc,nov){this.acc=acc; this.nov=nov;} var novotes=[];
function checkPyt(obj){var frm=obj.value.trim().toUpperCase(); document.getElementById('txtIDNo').readOnly=true; document.getElementById('spKind').style.display='none';
	if(frm=='CASH'){document.getElementById('txtCheNo').readonly=true; document.getElementById('cboBank').value=0; document.getElementById('txtCheNo').value='';}
	else if(frm=='CHEQUE' || frm=='DIRECT BANKING' || frm=='MONEY ORDER'){document.getElementById('txtCheNo').readonly=false; document.getElementById('cboBank').readonly=false;}
	else if(frm=='MFEES'){document.getElementById('txtCheNo').readonly=false; document.getElementById('cboBank').value=0;}
	else if(frm=='KIND'){document.getElementById('spKind').style.display='block'; document.getElementById('txtIDNo').readOnly=false;	document.getElementById('cboBank').value=0}
}function addCommas(nStr){nStr+='';	nStr=(nStr.indexOf('.')>-1?nStr:(nStr+'.00')); var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):''; var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');} return x1+x2;
}function checkInput(ch,ob){var invalidChars; invalidChars=(ch==0?/[^0-9\.\,]/g:/[^0-9]/g);
	if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,"");	ob.value=a;}if (ob.length==0){ob.value=(ch==0?'0.00':'');	}
}function loadBursaryBal(txt){var bal=0, bno=parseInt(txt.value.replace(/[^0-9]/g,''));
	if(!isNaN(bno)){var nocache = Math.random() * 10000; //stop caching
		if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} else { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); }
    xmlhttp.onreadystatechange = function() {if (this.readyState==4 && this.status==200){var ans=this.responseText; ans=ans.split(/\-/g); bal=Number(ans[3]); bal=isNaN(bal)?0:bal;
			if(bal>0){document.getElementById("txtBursBal").value=addCommas(bal.toFixed(2));	document.getElementById("cboPaidBy").value='Bursary'; document.getElementById("cboPaidBy").disabled=true;
				document.getElementById("cboPytFrm").value=ans[0];	document.getElementById("cboPytFrm").disabled=true; document.getElementById("txtCheNo").value=ans[1];	document.getElementById("txtCheNo").disabled=true;
				document.getElementById("cboBank").value=ans[2];		document.getElementById("cboBank").disabled=true;
			}else{alert('Sorry, Bursary No. '+bno+' is either fully distributed or not recognized by the system.');			document.getElementById("txtBursBal").value='';
				document.getElementById("cboPaidBy").value='Parent'; document.getElementById("cboPaidBy").disabled=false;	document.getElementById("cboPytFrm").disabled=false;
				document.getElementById("txtCheNo").disabled=false;	document.getElementById("cboBank").disabled=false;		txt.value=''; document.getElementById("cboPytFrm").focus();
			}}
    };  xmlhttp.open('GET','ajax/showbursbal.php?q=0-'+bno+'-'+nocache,true); xmlhttp.send();
	}else{ txt.value=''; document.getElementById("txtBursBal").value='';document.getElementById("cboPaidBy").value='Parent'; 	document.getElementById("cboPaidBy").disabled=false;
		document.getElementById("cboPytFrm").disabled=false;	document.getElementById("txtCheNo").disabled=false;	document.getElementById("cboBank").disabled=false;	document.getElementById("cboPytFrm").focus();
	}
}function ttlFee(nov){	var ttl=0;
	for(var a=0;a<nov;a++){	var obj=document.getElementById("txtFee_"+a); checkInput(0,obj),amt=Number(document.getElementById("txtFee_"+a).value.replace(/[^0-9\.]/,'')); ttl+=(isNaN(amt)?0:amt);}
	obj=document.getElementById("txtBC"); checkInput(0,obj);	amt=Number(document.getElementById("txtBC").value.replace(/[^0-9\.]/,'')); ttl+=(isNaN(amt)?0:amt);
	document.getElementById("txtTtlFee").value=addCommas(ttl.toFixed(2)); var bno=parseInt(document.getElementById("txtBursNo").value);
	if (!isNaN(bno) && bno>0){amt=Number(document.getElementById("txtBursBal").value.replace(/[^0-9\.]/,'')); amt=(isNaN(amt)?0:amt);
		if (amt<ttl){	alert("The sum of Kshs. "+ttl+" is higher than bursary balance of Kshs. "+amt+".\nThe correct amt has been set.");
			for(var a=0;a<nov;a++){if (a==0)document.getElementById("txtFee_"+a).value=addCommas(amt.toFixed(2)); else document.getElementById("txtFee_"+a).value="0.00";}
			document.getElementById("txtBC").value="0.00"; ttl=amt; document.getElementById("txtTtlFee").value=addCommas(ttl.toFixed(2));
		}
	}document.getElementById("txtWords").value=toWords(ttl.toFixed(2));
}function calcVotes(ch,ac){var i=0,lmt=document.getElementById("txtLimit_"+ch).value.split(/\-/g);//[0]lvl,[1]no.votes,[2]class,[3]curr a/c,[4]Spemed a/c,[5]Unifrm a/c,[6]-no.a/c,[7]curr lvl,[8]1 lastcls,0 continuingcls
	ttlFee(parseInt(lmt[6]));	var amt=Number(document.getElementById("txtFee_"+ch).value.trim().replace(/[^0-9\.]/g,'')),ttlamt=0,bal=Number(document.getElementById("txtTtlBal_"+ch).value.trim().replace(/[^0-9\.\-]/g,''));
	bal=((bal<0 || isNaN(bal))?0:bal); amt=isNaN(amt)?0:amt; //alert("The Balance is "+bal+ " and fees paid is "+amt);
	if(amt>bal && parseInt(lmt[4])!=ac){alert('Sorry, You can not recieve more than the balance of KSh. '+(addCommas(bal.toFixed(2)))+'.\nThe correct balance has been set.');//cant paymore than receivable amount on any other A/Cs
		document.getElementById("txtFee_"+ch).value=addCommas(bal.toFixed(2)); ttlFee(parseInt(lmt[6])); document.getElementById("txtFee_"+ch).focus(); return;
	}if (amt>0){var arr=0,med=0,prep=0,uni=0;
		if(amt>bal && parseInt(lmt[4])==ac && lmt[8]==0){//work out prepayment
			prep=amt-bal; alert('INFORMATION: The sum of KShs. '+addCommas(prep.toFixed(2))+' will be prepaid.'); amt=bal; document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(prep.toFixed(2));  ttlamt+=prep;
		} if(parseInt(lmt[4])==ac){i++;} 	var ul=parseInt(lmt[1]); arr=Number(document.getElementById("txtBal_"+ch+"_"+i).value.replace(/[^0-9\.]/g,''));
	 	if(arr>0){//Arrears b/f
			if(amt>=arr){alert('The sum of KShs. '+(addCommas(arr.toFixed(2)))+' will offset previous arrears'); document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(arr.toFixed(2)); 	amt-=arr; ttlamt+=arr;
			}else{alert('The whole sum of KShs. '+(addCommas(amt.toFixed(2)))+' will offset part of previous arrears');	document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(amt.toFixed(2)); ttlamt+=amt;	amt=0;}
		}i++;
		if(ac==parseInt(lmt[4]) && amt>0){med=parseFloat(document.getElementById("txtBal_"+ch+"_"+i).value.replace(/[^0-9\.]/g,'')); //Special Medical Charge
				if (med>0){if(amt>=med){alert('The sum of KShs. '+(addCommas(med.toFixed(2)))+' will offset medical bills.'); document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(med.toFixed(2)); amt-=med; ttlamt+=med;
				}else{alert('The whole sum of KShs. '+(addCommas(amt.toFixed(2)))+' will offset part of medical bill.');	document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(amt.toFixed(2)); ttlamt+=amt;		amt=0;}
			}
		} if (parseInt(lmt[4])==ac){i++;}
		if(ac==parseInt(lmt[5]) && amt>0){uni=Number(document.getElementById("txtBal_"+ch+"_"+i).value.replace(/[^0-9\.]/g,'')); //Uniform Charge
			if (uni>0){if(amt>=uni){alert('The sum of KShs. '+(addCommas(uni.toFixed(2)))+' will pay off extra uniform purchased.');document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(uni.toFixed(2));amt-=uni;ttlamt+=uni;
				}else{alert('The whole sum of KShs. '+(addCommas(amt.toFixed(2)))+' will offset part of extra uniform purchased.');	document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(amt.toFixed(2)); ttlamt+=amt;	amt=0;}
			}
		} if(ac==parseInt(lmt[5])){i++;}
		if((amt+arr+med+prep+uni)>bal && parseInt(lmt[4])==ac && lmt[8]==1){var ref=(amt+arr+med+prep+uni)-bal;	alert('The sum of KShs. '+(addCommas(ref.toFixed(2)))+' will be set as refunds');
			document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(ref.toFixed(2)); 	amt-=ref; ttlamt+=ref;
		} if (parseInt(lmt[4])==ac) i++;
		if(amt>0){ //There is MONEY for distribution to voteheads
			var newBal=balances.filter(function(e){return e.acc==ac;}); var ttl=[];	for(var index=0;index<ul;index++){ttl.push(0);} var index=0, len=newBal.length; //filter array for current ac
			while(index<len && amt>0){if(newBal[index].t1>amt){ttl[index]+=amt; ttlamt+=amt; amt=0;}else{ttl[index]+=newBal[index].t1; amt-=newBal[index].t1; ttlamt+=newBal[index].t1;}	index++; //term one
			}index=0; while(index<len && amt>0){if(newBal[index].t2>amt){ttl[index]+=amt; ttlamt+=amt; amt=0;}else{ttl[index]+=newBal[index].t2; amt-=newBal[index].t2; ttlamt+=newBal[index].t2;} index++; //term two
			}index=0; while(index<len && amt>0){if(newBal[index].t3>amt){ttl[index]+=amt; ttlamt+=amt; amt=0;}else{ttl[index]+=newBal[index].t3; amt-=newBal[index].t3; ttlamt+=newBal[index].t3;} index++; //term three
			}for(index=0;index<len;index++){document.getElementById("txtAmt_"+ch+"_"+i).value=addCommas(ttl[index].toFixed(2)); i++;}
		}
	}else{for(index=0;index<parseInt(lmt[1]);index++) document.getElementById("txtAmt_"+ch+"_"+index).value="0.00";}//amt is zero
	if(parseInt(lmt[4])==ac){document.getElementById("txtVoteBal_1").value=document.getElementById("txtVoteBal_0").value=addCommas(amt.toFixed(2));	document.getElementById("txtTtlAmt_"+ch).value=addCommas(ttlamt.toFixed(2));
	}else{document.getElementById("txtMVoteBal_1").value=document.getElementById("txtMVoteBal_0").value=addCommas(amt.toFixed(2)); document.getElementById("txtTtlAmt_"+ch).value=addCommas(ttlamt.toFixed(2));}
}function calcTotal(ch,ac,nv,pos){
	var ttl=0,lmt=document.getElementById("txtLimit_"+ch).value.trim().split(/\-/g),reg=/[^0-9\.]/g; //[0]lvl,[1]no.votes,[2]class,[3]curr a/c,[4]Spemed a/c,[5]Unifrm a/c,[6]-no.a/c,[7]curr lvl,[8]1 lastcls,0 continuingcls
	var amt=Number(document.getElementById("txtAmt_"+ch+"_"+pos).value.replace(reg,'')),curbal=Number(document.getElementById("txtBal_"+ch+"_"+pos).value.replace(reg,''));curbal=isNaN(curbal)?0:curbal;amt=isNaN(amt)?0:amt;
	if(amt>curbal){alert('You can\'t receive more than Kshs. '+(addCommas(curbal.toFixed(2)))+' on this votehead.\nThe correct balance has been set.');document.getElementById("txtAmt_"+ch+"_"+pos).value=addCommas(curbal.toFixed(2));
	}if(amt<0) document.getElementById("txtAmt_"+ch+"_"+pos).value="0.00";
	for (var i=0;i<nv;i++){amt=Number(document.getElementById("txtAmt_"+ch+"_"+i).value.replace(/[^0-9\.]/g,'')); amt=isNaN(amt)?0:amt; ttl+=amt;} document.getElementById("txtTtlAmt_"+ch).value=addCommas(ttl.toFixed(2));
	var amt=Number(document.getElementById("txtFee_"+ch).value.replace(/[^0-9\.]/g,'')); amt-=ttl;
	if(ac==parseInt(lmt[4])) document.getElementById("txtVoteBal_1").value=document.getElementById("txtVoteBal_0").value=addCommas(amt.toFixed(2));
	else document.getElementById("txtMVoteBal_1").value=document.getElementById("txtMVoteBal_0").value=addCommas(amt.toFixed(2));
}function SaveFeeRecord(theForm){ var err='',pytfrm=theForm.cboPytFrm.value.toUpperCase();
	if ((pytfrm !="CASH") && (pytfrm !="KIND")){var trno=theForm.txtCheNo.value.trim().length;
	 	if (trno<4){err+="Sorry, You MUST enter transaction/ cheque no. of this payment before saving!!\n";		theForm.txtCheNo.style.background='Yellow';	}
		if (pytfrm=="CHEQUE" || pytfrm=="MONEY ORDER" || pytfrm=="DIRECT BANKING"){	var bank=parseInt(theForm.cboBank.value.toUpperCase());
			if (isNaN(bank) || bank==0){err+="Sorry, You MUST choose the bank  of this Cheque/Bankslip/Money Order before saving!!\n";theForm.cboBank.style.background='Yellow';}else theForm.cboBank.style.background='white';}
		}else if (pytfrm=="KIND"){if (theForm.txtIDNo.value.length<7){err+="Sorry, You MUST type valid ID No. of the parent before saving!!\n";	theForm.txtKind.style.background='Yellow';
		 	}if (theForm.txtKind.value.length<10){err+="Sorry, You MUST type the description of fee receipt in kind before saving!!\n";	theForm.txtKind.style.background='Yellow';
		 	}if (theForm.txtParent.value.length<8){err+="Sorry, You MUST type the full name of the parent before saving!!\n"; theForm.txtParent.style.background='Yellow';
			}if (theForm.txtTelNo.value.length<10){err+="Sorry, You MUST type valid Telephone Number of the parent before saving!!\n";	theForm.txtTelNo.style.background='Yellow';	}
	}var main=0,misc=0,nac=parseInt(theForm.txtNoV.value),main=Number(theForm.txtTtlFee.value.replace(/[^0-9\.]/g,''));
 	if (main==0 || isNaN(main)){err+="Sorry, You MUST enter amount of fees received before saving!!!\n";for(var i=0;i<nac;i++) document.getElementById("txtFee_"+i).style.background='Yellow';} var openVote=false;
	for (var i=0;i<nac;i++){main=Number(document.getElementById("txtVoteBal_"+1).value.replace(/[^0-9\.]/,''));	misc=Number(document.getElementById("txtMVoteBal_"+1).value.replace(/[^0-9\.]/,''));
		if(main!=0 || misc!=0){	err+='Voteheads MUST be fully distributed to respective voteheads!!!\n'; 	openVote=true;}
	}document.getElementById("cboPaidBy").disabled=false;document.getElementById("cboPytFrm").disabled=false;document.getElementById("txtCheNo").disabled=false;document.getElementById("cboBank").disabled=false;
	for (var i=0;i<nac;i++){var lmt=document.getElementById("txtLimit_"+i).value.trim().split(/\-/g),ttl=0;//[0]lvl,[1]no.votes,[2]class,[3]curr a/c,[4]Spemed a/c,[5]Unifrm a/c,[6]-no.a/c,[7]curr lvl,[8]1 lastcls,0 continuingcls
		for(var a=0;a<parseInt(lmt[1]);a++){
			if((a==0 || a==3) && (lmt[3]==lmt[4])){main=Number(document.getElementById("txtAmt_"+i+"_"+a).value.replace(/[^0-9\.]/g,'')); ttl+=isNaN(main)?0:main; //skip prepayment and refunds
			}else{main=Number(document.getElementById("txtAmt_"+i+"_"+a).value.replace(/[^0-9\.]/g,'')); main=isNaN(main)?0:main; ttl+=main; misc=Number(document.getElementById("txtBal_"+i+"_"+a).value.replace(/[^0-9\.]/g,''));
				misc=isNaN(misc)?0:misc; if(main>misc){err+='Votehead amount of Kshs. '+addCommas(main.toFixed(2))+' is higher than balance of Kshs. '+addCommas(misc.toFixed(2))+'.\n';
				document.getElementById("txtAmt_"+i+"_"+a).style.background='Yellow';	openVote=true;}}
		}main=Number(document.getElementById("txtFee_"+i).value.replace(/[^0-9\.]/g,'')); main=isNaN(main)?0:main;	if(main!=ttl) err+='The fee received on A/C have not not been correctly distributed.\n';
	}if(err.length>0){alert('THE FOLLOWING ERROR MUST BE CORRECTED BEFORE SAVING.\n'+err); return false;
	}else{document.getElementById("cboPaidBy").disabled=false;document.getElementById("cboPytFrm").disabled=false;document.getElementById("txtCheNo").disabled=false;document.getElementById("cboBank").disabled=false;return true;}
}function validateTransNo(txt){	var illegal=/[^a-z0-9]/gi,n=txt.value;	if (n.length>0 && illegal.test(n)){	n=n.replace(illegal,'');	txt.value=n;}}
function verifyDuplicateTransNo(txt){var transno=txt.value.replace(/[^a-z0-9]/gi,''),nocache = Math.random() * 10000; //stop caching
	if(transno.length>0){transno=transno.toUpperCase();
		if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest(); else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200){var n=Number(this.responseText); n=isNaN(n)?0:n;
			if (n>0){if (confirm('The Trans/ Cheque No. '+transno+ ' has been used on '+n+' receipt(s).\nIs it OK to use the same Trans/ Cheque No. again?')){;}else txt.value='';}}
    }; xmlhttp.open('GET','ajax/showbursbal.php?q=1-'+transno+'-'+nocache,true); xmlhttp.send();  }
}function showKindDet(txt){var idno=txt.value.replace(/[^0-9]/g,''),nocache = Math.random() * 10000; //stop caching
	if(idno.length>0){
		if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest(); else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200){var n=this.responseText; n=n.toUpperCase();if (n!='0-0-0'){n=n.split(/\-/g); document.getElementById("txtParent").readOnly=true;
			document.getElementById("txtParent").value=n[0];document.getElementById("txtTelNo").readOnly=true;	document.getElementById("txtTelNo").value=n[1];document.getElementById("txtAddress").readOnly=true;
			document.getElementById("txtAddress").value=n[2];}else{document.getElementById("txtParent").readOnly=false;document.getElementById("txtTelNo").readOnly=false;document.getElementById("txtAddress").readOnly=false;}
			document.getElementById("txtKind").readOnly=false;}
    };xmlhttp.open('GET','ajax/showbursbal.php?q=2-'+idno+'-'+nocache,true); xmlhttp.send();
  }
}
var th = ['','Thousand','Million', 'Billion','Trillion'],tw = ['Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
var dg = ['Zero','One','Two','Three','Four', 'Five','Six','Seven','Eight','Nine'],tn = ['Ten','Eleven','Twelve','Thirteen', 'Fourteen','Fifteen','Sixteen', 'Seventeen','Eighteen','Nineteen'];
function toWords(s){
    s = s.toString(); s = s.replace(/[\, ]/g,''); if (s != parseFloat(s)) return 'not a number';
    var x = s.indexOf('.'); if (x == -1) x = s.length;  if (x > 15) return 'too big';
    var n = s.split(''),str = '',sk = 0;
    for (var i=0; i < x; i++) {
        if ((x-i)%3==2) {if (n[i]=='1') {str+=tn[Number(n[i+1])]+' ';  i++;  sk=1;} else if (n[i]!=0) {str+=tw[n[i]-2] + ' ';sk=1;}
        }else if (n[i]!=0) {str+=dg[n[i]] +' ';         if ((x-i)%3==0) str+='Hundred ';        sk=1;}
        if ((x-i)%3==1){if (sk) str+=th[(x-i-1)/3] + ' ';   sk=0; }
    }if (x!=s.length) { var y=s.length;    str+='Shillings and ';  var i=x+1;
        if (n[i]==0)  str+=dg[n[i]]+' Cents';
        else if (n[i]==1) str+=tn[n[i]+1]+' Cents';
        else{if (n[i+1]==0) str+=tw[n[i]-2] +' Cents'; else{str+=tw[n[i]-2];  str=str + '-' + dg[n[i+1]] + ' Cents'; }}
    }return str.replace(/\s+/g,' ');
}
