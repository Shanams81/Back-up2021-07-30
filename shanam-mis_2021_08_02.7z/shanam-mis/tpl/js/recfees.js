function findStudents(txt){var input,table,tr,td,i,ns=0,a=(document.getElementById("radAdm").checked?0:(document.getElementById("radName").checked?1:2));
	input=txt.value.toUpperCase();table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
	for(i=0;i<tr.length;i++){td=tr[i].getElementsByTagName("td")[a];if (td){if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display=""; ns++;}else tr[i].style.display="none";}
	}document.getElementById("spNoStud").innerHTML=ns+' Students';
}function clrText(){document.getElementById("txtFind").value='';document.getElementById("txtFind").focus();}
function showReceipt(ad,yr){var nocache=Math.random()*10000;if(window.XMLHttpRequest){xmlhttp=new XMLHttpRequest();}else{xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");} // code for IE6, IE5
  xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200) document.getElementById("divState").innerHTML=this.responseText;};
  xmlhttp.open('GET','ajax/fees_statement.php?adm='+ad+'-1-'+yr+'-'+nocache,true);xmlhttp.send();
}
