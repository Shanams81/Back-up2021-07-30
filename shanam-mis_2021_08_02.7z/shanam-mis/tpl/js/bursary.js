function addNew(){document.getElementById("bursaryAdd").style.display="block";}
function enableSave(txt,add){
 	if(add==1){var amt=Number(txt.value.replace(/[^0-9\.]/,'')); if (amt>0){document.getElementById('btnSave').disabled=false; txt.value=addCommas(amt.toFixed(2));} else  document.getElementById('btnSave').disabled=true;
	}else alert("Sorry, you do not have the priviledge to prepare students' fee leaveouts.");
}function addCommas(nStr){
	nStr+=''; var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'',rgx=/(\d+)(\d{3})/; 	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}function checkInput(ob,ch){
	var invalidChars=(ch==0?/[^0-9\.\,]/g:/[^0-9]/g); if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,""); if(ch==0) ob.value=addCommas(a); else ob.value=a;	}
	if (ob.length==0){if(ch==0) ob.value="0.00"; else ob.value=0;}
}function checkName(txt){
	var invalidChars=/[^a-zA-Z\.\ \']/gi; if (invalidChars.test(txt.value)){var a=txt.value.replace(invalidChars,"");	txt.value=a;}
}function validateData(frm){
	var err=''; var amt=Number(frm.txtAmt.value.replace(/[^0-9\.]/,''));
	if (isNaN(amt) || amt<1){err+="The Bursary amount received MUST be higher than zero.\n"; document.getElementById('txtAmt').style.background='Yellow';
	}else document.getElementById('txtAmt').style.background='white';
	if(frm.txtName.value.trim().length<8){err+="Type valid Bursary Name before saving.\n"; frm.txtName.style.background='Yellow';
	}else frm.txtName.style.background='white';
	if(frm.txtModeNo.value.trim().length<3){err+="Type valid Transaction/ Cheque No. before saving.\n";  frm.txtModeNo.style.background='Yellow';
	}else frm.txtModeNo.style.background='white';
	if (err.length>0){alert("MAKE THE FOLLOWING CORRECTIONS BEFORE SAVING.\n"+err);	return  false;
	}else return true;
}function canview(pr) {
 	if (pr==0) {alert("Sorry, you do not have the priviledges to perform this administrative task (Edit)");	return false;
  	} else return true;
}function canedit(pr) {
 	if (pr==0) {alert("Sorry, you do not have the priviledges to perform this administrative task (Edit)");	return false;
  	} else return true;
}function enableDelete(txt,del){
	if(del==0){alert('Sorry, you do not have the priviledge to cancel a bursary.'); txt.value='';
	}else{
		var invalid=/[^a-z\.\,\ ]/gi;	var d=txt.value.replace(invalid,'');
		if(d.length>0){txt.value=d; if (d.length>8) document.getElementById('btnDelBursary').disabled=false; else document.getElementById('btnDelBursary').disabled=true;}
	}
}function showBursBenef(bno){
	var nocache = Math.random() * 10000; //stop caching
	if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    }xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) document.getElementById("spBursaryBenef").innerHTML = this.responseText;
    };
    xmlhttp.open('GET','ajax/bursbeneficiary.php?bno='+bno+'-'+nocache,true); xmlhttp.send();
}
function printSpecific(){
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25",content_value = document.getElementById("spBursaryBenef").innerHTML;
	var docprint=window.open("","",disp_setting);
	docprint.document.open();
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title></head><body onLoad="self.print()" style="color:#000000;font-size:10px;"><center>'+
	content_value+'</body></html>');
	docprint.document.close(); docprint.focus();
}
function findBurs(txt){
	var input, table, tr,td, i,ns=0,amt=0,ttl=0,found=false;
	var a=(document.getElementById("radBursNo").checked?0:(document.getElementById("radRecNo").checked?1:3));
	input=txt.value.toUpperCase();	table=document.getElementById("tabBursary"); 	tr=table.getElementsByTagName("tr");
	for(i=1;i<(tr.length-1);i++){
		td=tr[i].getElementsByTagName("td")[a]; found=false;
		if (td){
			if (input.length==0) found=true;
			else if((a==0|| a==1) && Number(td.innerHTML.toUpperCase().trim())==input) found=true;
			else if(a==3 && td.innerHTML.toUpperCase().trim().indexOf(input)>-1) found=true;
		}if(found){
		 	tr[i].style.display=""; ns++;	amt=Number(tr[i].getElementsByTagName("td")[4].innerHTML.replace(/[^0-9\.]/,'')); 	ttl+=(isNaN(amt)?0:amt);
		}else tr[i].style.display="none";
	}document.getElementById("spBursNo").innerHTML=ns+'  Bursary Record(s)'; document.getElementById("spBursTtl").innerHTML=addCommas(ttl.toFixed(2));
}
function findStudent(txt){
	var input, table, tr,td, i,ns=0,amt=0,ttl=0,found=false;
	var a=(document.getElementById("radAdm").checked?2:(document.getElementById("radName1").checked?3:4));
	input=txt.value.toUpperCase();	table=document.getElementById("tabStudents"); 	tr=table.getElementsByTagName("tr");
	for(i=1;i<(tr.length-1);i++){
		td=tr[i].getElementsByTagName("td")[a]; found=false;
		if (td){
			if (input.length==0) found=true;
			else if(a==2 && Number(td.innerHTML.toUpperCase().trim())==input) found=true;
			else if(a!=2 && td.innerHTML.toUpperCase().trim().indexOf(input)>-1) found=true;
		}if(found){
		 	tr[i].style.display=""; ns++; amt=Number(tr[i].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9\.]/,'')); ttl+=(isNaN(amt)?0:amt);
		}else tr[i].style.display="none";
	}document.getElementById("spNoStud").innerHTML=ns+'  Bursary Beneficiaries'; document.getElementById("spTtl").innerHTML=addCommas(ttl.toFixed(2));
}
function clrFind(){document.getElementById("txtFind").value='';document.getElementById("txtFind").focus();}
function clrFind1(){document.getElementById("txtFind1").value='';document.getElementById("txtFind1").focus();}
