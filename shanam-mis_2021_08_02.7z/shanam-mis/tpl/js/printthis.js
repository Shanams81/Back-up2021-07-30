function Clickheretoprint()
{
	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25";
	var content_vlue = document.getElementById("print_content").innerHTML,docprint=window.open("","",disp_setting);
	docprint.document.open();
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title></head><body onLoad="self.print()"><center>'+
	content_vlue+'</body></html>'); docprint.document.close(); docprint.focus();
}function printSpecific(secno){
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25";
	var content_value = document.getElementById(secno).innerHTML,docprint=window.open("","",disp_setting);
	docprint.document.open();
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title></head><body onLoad="self.print()"><center>'+
	content_value+'</body></html>'); 	docprint.document.close(); 	docprint.focus(); 
}
