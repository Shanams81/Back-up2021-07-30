function checkData(ob){
	var invalidChars=/[^0-9]/g;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=a;
	}
	if (ob.length==0){
	 	ob.value='00000';
	}
}
function confirmData(){
	var che,err='';
	var n=Number(document.getElementById('txtNoF').value.trim()); n=isNaN(n)?0:n;
	for (var i=0;i<n;i++){
		che=document.getElementById('txtCheNo_'+i).value.trim();
		if(che.length<3){
			err+='Invalid cheque number\n'; document.getElementById('txtCheNo_'+i).style.background='Yellow';
		}else document.getElementById('txtCheNo_'+i).style.background='white';
	}if(err.length>0){
		alert('THERE ARE CHEQUE NUMBER(S) TO BE CORRECTED\n'+err);
		return false;
	}else return true;
}