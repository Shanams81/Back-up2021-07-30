function checkAnalysisData(frm){
	var dt1=frm.dtpStart.value.trim().split(/\-/g),dt2=frm.dtpEnd.value.trim().split(/\-/g),err="",dt1=new Date(dt1[2],dt1[1],dt1[0]),dt2=new Date(dt2[2],dt2[1],dt2[0]);
	var days=Math.round((dt2.getTime()-dt1.getTime())/8.64e7);
	if (days<0){err+="Invalid range of dates have been selected.\n";	frm.dtpStart.style.background='yellow'; 	frm.dtpEnd.style.background='yellow';
	}else{frm.dtpStart.style.background='white'; 	frm.dtpEnd.style.background='white';}
	if (frm.cboAC.value.length==0){err+="Select Votehead Account whose income is to be viewed.\n"; 	frm.cboAC.style.background='yellow';}else frm.cboAC.style.background='white';
	if(err.length>0){alert("ADJUST THE FOLLOWING REPORT CHOICES BEFORE CONTINTUING:\n"+err); return false;} return true;
}function canEdit(pr) {
	if (pr == 0){alert("Sorry, you do not have the priviledges to edit fees record.");return false;}else{return true;}
}function findReceipt(txt){
	var input=document.getElementById("txtFind").value.trim().toUpperCase(),td,i=0,nos=0,found=false,amt=0,tr=document.getElementById("tabReceipt").getElementsByTagName("tr"); var ttl=[0,0,0,0,0,0],l=tr.length,err='';
	var a=(document.getElementById("radRecNo").checked?0:(document.getElementById("radAdmNo").checked?3:(document.getElementById("radName").checked?4:5))); // Fee such criteria
	for(i=2;i<(l-1);i++){td=tr[i].getElementsByTagName("td")[a]; found=false
		if (td){let data=td.innerHTML.trim().toUpperCase();
		 	if (input.length==0) found=true; 	else if((a==0 || a==2) && data==input) found=true; 	else if((a==3 || a==4) && data.toUpperCase().indexOf(input)>-1) found=true;
			if(found){tr[i].style.display=""; nos++;
				amt=Number(tr[i].getElementsByTagName("td")[8].innerHTML.replace(/[^0-9\.]/g,'')); ttl[0]+=isNaN(amt)?0:amt; amt=Number(tr[i].getElementsByTagName("td")[9].innerHTML.replace(/[^0-9\.]/g,'')); ttl[1]+=isNaN(amt)?0:amt;
				amt=Number(tr[i].getElementsByTagName("td")[10].innerHTML.replace(/[^0-9\.]/g,'')); ttl[2]+=isNaN(amt)?0:amt; amt=Number(tr[i].getElementsByTagName("td")[11].innerHTML.replace(/[^0-9\.]/g,'')); ttl[3]+=isNaN(amt)?0:amt;
			}else tr[i].style.display="none";
		}else err+="Cell not found\n";
	} for(i=0;i<4;i++) document.getElementById("thTtl_"+i).innerHTML=addCommas(ttl[i].toFixed(2)); document.getElementById("spNoF").innerHTML=nos+' Fees Payment Record(s).'; if(err.length>0) alert(err);
}function clrFind(){	document.getElementById("txtFind").value='';	document.getElementById("txtFind").focus();}
function addCommas(nStr){	nStr+='';	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');} 	return x1+x2;
}
