function enablePWD(chk){
	if(chk.checked==true) document.getElementById('txtPWD').readOnly=false;
	else document.getElementById('txtPWD').readOnly=true;
}
function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit Details";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }fixStepIndicator(n)
}
function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  if (n == 1 && !validateForm()) return false;
  x[currentTab].style.display = "none";
  currentTab = currentTab + n;
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("frmStf").submit();
    return false;
  }showTab(currentTab);
}
function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i=0;i<y.length;i++) {
    if (y[i].value == "" && y[i].required==true) {
      y[i].className += " invalid";
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}
function fixStepIndicator(n) {
  var i, x=document.getElementsByClassName("step");
  for (i=0; i<x.length; i++) {
    if(n==i) x[i].style.background="#af00af";
	else x[i].style.background="#aaaaaa";
  }
}
function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.txtIDNo);
	if(theForm.txtIDNo.value.trim().length<7){
		reason+='Staff ID No. is not valid.\n'; theForm.txtIDNo.style.background='Yellow';
	}if ((theForm.txtAddress.value.length<9) || (theForm.txtAddress.value=="P.O BOX ")){
		reason+="Postal address you entered is invalid\n";
		theForm.txtAddress.style.background='Yellow';
	}
	if (theForm.txtTelNo.value.length<9){
		reason += "Telephone No. Must be valid.\n"; theForm.txtTelNo.style.background='Yellow';
	}
	if (theForm.txtEmail.value!=""){
		reason += validatUsername(theForm.txtEmail);
	}
	reason += validateUsername(theForm.txtSurname);
	reason += validateUsername(theForm.txtONames);
  	if (reason != "") {
    	alert("The following fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " You didn't enter the right information.\n";
	} else if (fld.value.length < 3) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function checkData(opt,txt){
	var invalid=opt==0?/[^0-9\+]/g:/[^a-zA-Z0-9\,\ \.\-]/g;
	if (invalid.test(txt.value)){
		txt.value=txt.value.replace(invalid,'');
	}
}
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function filldays(listboxID){
	var i=ClearCont(listboxID);
	var yr=parseInt(document.getElementById("cboYr").value);
	var mon=document.getElementById("cboMon").value;
	var n=noofdays(yr,mon);
	for (var i=n;i>0;i--) addOptions(listboxID,i,i);
}
function noofdays(y,m){
 	switch (m){
		case '01': d=31; break;
		case '02': if(((y%4 == 0) && (y%100 != 0)) || (y%400 == 0)) d=29; else d=28; break;
		case '03': d=31; break;
		case '04': d=30; break;
		case '05': d=31; break;
		case '06': d=30; break;
		case '07': d=31; break;
		case '08': d=31; break;
		case '09': d=30; break;
		case '10': d=31; break;
		case '11': d=30; break;
		case '12': d=31; break;
		default: d=1; break;
	}return d;
}