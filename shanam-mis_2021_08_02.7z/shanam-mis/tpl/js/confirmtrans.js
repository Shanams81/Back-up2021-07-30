function showBankTrans(cbo){
	var input=cbo.value.toUpperCase(), table, tr,td, i,nop=0,ttl=0;
	table=document.getElementById("tblBank"); tr=table.getElementsByTagName("tr");
	for(i=0;i<tr.length;i++){
			td=tr[i].getElementsByTagName("td")[4];
			if (td){
					if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){
							tr[i].style.display=""; nop++; amt=Number(tr[i].getElementsByTagName("td")[6].innerHTML.replace(/[^0-9\.]/g,'')); ttl+=(isNaN(amt)?0:amt);
					}else tr[i].style.display="none";
			}
	}document.getElementById("tdNOB").innerHTML=nop+' Transactions.';	document.getElementById("tdTtl").innerHTML=addCommas(ttl);
}function showCashTrans(cbo){
	var input=cbo.value.toUpperCase(), table, tr,td, i,nop=0,ttl=0;
	table=document.getElementById("tblCash"); tr=table.getElementsByTagName("tr");
	for(i=0;i<tr.length;i++){
			td=tr[i].getElementsByTagName("td")[3];
			if (td){
					if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){
							tr[i].style.display=""; nop++; amt=Number(tr[i].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9\.]/g,'')); ttl+=(isNaN(amt)?0:amt);
					}else tr[i].style.display="none";
			}
	}document.getElementById("tdNOC").innerHTML=nop+' Transactions.';	document.getElementById("tdCTtl").innerHTML=addCommas(ttl);
}function confirmData(n,mode){
	var err="",sel=false,i=1;
	while (sel==false && i<=n){
		if (document.getElementById("chkBank_"+i).checked==true) sel=true;
		i++;
	}
	if (sel==false) err+="You MUST select the fee installments to be deposited/cashed before saving.\n"; var ac=document.getElementById("cboAccount").value;
	if ((mode.toLowerCase()!="cash" || mode.toLowerCase()!="money order") && ac.length==0) err+="You MUST select the Account to which the income is to be deposited.\n";
	var amt=0,cash=0;
	if (mode.toLowerCase()!="cash" || mode.toLowerCase()!="money order") amt=parseInt(document.getElementById("txtDeposit").value.replace(/,/g,""));
	if (mode.toLowerCase()=="cash" || mode.toLowerCase()=="money order") cash=parseInt(document.getElementById("txtCash").value.replace(/,/g,""));
	if ((cash==0 || cash==isNaN) && (amt==0 || amt==isNaN)) err+="The amount deposited/cashed MUST be between Kshs. 1.00 and Kshs. 5,500,000.00.\n";
	if (err.length==0){
		document.querySelector("#busyWait").style.display='block';
		return true;
	}else{
		alert("The following error MUST be corrected.\n"+err);
		return false;
	}
}function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}function clrAC(na){
	var a=ClearCont("cboAC");a=ClearCont("cboMode");
	a=parseInt(na.value);
	var htmlSelect=document.getElementById("cboAC");
	if (a==2){//FSE Accounts
		selectBoxOption = document.createElement("option"); selectBoxOption.value = 2; selectBoxOption.text = "Tuition"; 	htmlSelect.add(selectBoxOption);
		selectBoxOption = document.createElement("option"); selectBoxOption.value = 3; selectBoxOption.text = "Operations"; htmlSelect.add(selectBoxOption);
		//mode of payment
		htmlSelect=document.getElementById("cboMode");
		selectBoxOption = document.createElement("option"); selectBoxOption.value = "E . F . T"; selectBoxOption.text = "EFT"; 	htmlSelect.add(selectBoxOption);
	}else{//Student Fees and alternative
		selectBoxOption = document.createElement("option"); selectBoxOption.value = 1; selectBoxOption.text = "Main";		htmlSelect.add(selectBoxOption);
		selectBoxOption = document.createElement("option");	selectBoxOption.value = 4; selectBoxOption.text = "Misc";		htmlSelect.add(selectBoxOption);
		//mode of payment
		htmlSelect=document.getElementById("cboMode");
		selectBoxOption = document.createElement("option"); selectBoxOption.text = "Direct Banking"; 	htmlSelect.add(selectBoxOption);
		selectBoxOption = document.createElement("option"); selectBoxOption.text = "Cash"; 				htmlSelect.add(selectBoxOption);
		selectBoxOption = document.createElement("option"); selectBoxOption.text = "Money Order"; 		htmlSelect.add(selectBoxOption);
		selectBoxOption = document.createElement("option"); selectBoxOption.text = "M-Fees"; 			htmlSelect.add(selectBoxOption);
		selectBoxOption = document.createElement("option"); selectBoxOption.text = "Cheque"; 			htmlSelect.add(selectBoxOption);
	}
}function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}function selectAll(n,mode){
	var a=document.getElementById("chkAll").checked;
	for (var i=1;i<=n;i++){
		if (a==true){document.getElementById("chkBank_"+i).checked=true;
		}else{ document.getElementById("chkBank_"+i).checked=false;}
	}calcTtl(n,mode);
}function calcTtl(n,mo){
	var ttl=0;
	for (var a=1;a<=n;a++){
		if (document.getElementById("chkBank_"+a).checked==true) ttl+=parseFloat(document.getElementById("txtAmt_"+a).value.replace(/,/g,""));
	}
	document.getElementById("txtDeposit").value=addCommas(ttl.toFixed(2));
	if (mo.toLowerCase()=="cash" ||mo.toLowerCase()=="money order") document.getElementById("txtCash").value=addCommas(ttl.toFixed(2));
}
