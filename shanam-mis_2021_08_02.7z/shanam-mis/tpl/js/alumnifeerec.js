function checkPyt(obj){
    var frm=obj.value.trim().toUpperCase(); document.getElementById('txtIDNo').readOnly=true; document.getElementById('spKind').style.display='none';
    if(frm=='CASH'){document.getElementById('txtCheNo').readonly=true; document.getElementById('cboBank').value=0; document.getElementById('txtCheNo').value='';}
    else if(frm=='CHEQUE' || frm=='DIRECT BANKING' || frm=='MONEY ORDER'){document.getElementById('txtCheNo').readonly=false; document.getElementById('cboBank').readonly=false;}
    else if(frm=='MFEES'){document.getElementById('txtCheNo').readonly=false; document.getElementById('cboBank').value=0;}
    else if(frm=='KIND'){document.getElementById('spKind').style.display='block'; document.getElementById('txtIDNo').readOnly=false;	document.getElementById('cboBank').value=0}
}function activateDel(txt){
    let rmks=txt.value.replace(/[^a-zA-Z\.\,\ ]/g,''); document.getElementById('btnDel').disabled=false;   document.getElementById('btnDel').style.background='green';
    if (rmks.length>0){txt.value=rmks.toUpperCase();
        if (rmks.length>30){document.getElementById('btnDel').disabled=false;  document.getElementById('btnDel').style.background='red';}
    }
}function addCommas(nStr){
    nStr+=''; var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
    var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}    return x1+x2;
}function checkInput(ch,ob){
    var invalidChars=(ch==0?/[^0-9\.\,]/g:/[^0-9]/g);
    if (invalidChars.test(ob.value)){ var a=ob.value.replace(invalidChars,"");   ob.value=a;}
    if (ob.length==0){ ob.value=(ch==0?'0.00':'');  }
}function loadBursaryBal(txt){
    var bal=0, bno=parseInt(txt.value.replace(/[^0-9]/g,''));
    if(!isNaN(bno)){ var nocache = Math.random() * 10000; //stop caching
        if (window.XMLHttpRequest){xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
        }else{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
        }xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200){var ans=this.responseText; ans=ans.split(/\-/g); bal=Number(ans[3]); bal=isNaN(bal)?0:bal;
            if(bal>0){document.getElementById("txtBursBal").value = addCommas(bal.toFixed(2));	document.getElementById("cboPaidBy").value='Bursary';
                document.getElementById("cboPaidBy").disabled=true;	document.getElementById("cboPytFrm").value=ans[0];	document.getElementById("cboPytFrm").disabled=true;
                document.getElementById("txtCheNo").value=ans[1];	document.getElementById("txtCheNo").disabled=true;	document.getElementById("cboBank").value=ans[2];
                document.getElementById("cboBank").disabled=true;
            }else{alert('Sorry, Bursary No. '+bno+' is either fully distributed or not recognized by the system.');			document.getElementById("txtBursBal").value='';
                document.getElementById("cboPaidBy").value='Parent'; document.getElementById("cboPaidBy").disabled=false;	document.getElementById("cboPytFrm").disabled=false;
                document.getElementById("txtCheNo").disabled=false;	document.getElementById("cboBank").disabled=false;		txt.value='';
                document.getElementById("cboPytFrm").focus();
            }
        }}; xmlhttp.open('GET','ajax/showBursBal.php?q=0-'+bno+'-'+nocache,true); xmlhttp.send();
    }else{txt.value=''; document.getElementById("txtBursBal").value='';
        document.getElementById("cboPaidBy").value='Parent'; 	document.getElementById("cboPaidBy").disabled=false;	document.getElementById("cboPytFrm").disabled=false;
        document.getElementById("txtCheNo").disabled=false;		document.getElementById("cboBank").disabled=false;		document.getElementById("cboPytFrm").focus();
    }
}function ttlFee(){
    var ttl=0,obj=document.getElementById("txtFee_0"); checkInput(0,obj);
    var amt=Number(obj.value.replace(/[^0-9\.]/,'')),bno=parseInt(document.getElementById("txtBursNo").value);; ttl+=(isNaN(amt)?0:amt); obj=document.getElementById("txtBC"); checkInput(0,obj);
    amt=Number(obj.value.replace(/[^0-9\.]/,'')); ttl+=(isNaN(amt)?0:amt); document.getElementById("txtTtlFee").value=addCommas(ttl.toFixed(2));
    if (!isNaN(bno) && bno>0){//checking if bursary balance and fee amount are okay
        amt=Number(document.getElementById("txtBursBal").value.replace(/[^0-9\.]/,'')); amt=(isNaN(amt)?0:amt);
        if (amt<ttl){ alert("The sum of Kshs. "+ttl+" is higher than bursary balance of Kshs. "+amt+".\nThe correct amt has been set."); ttl=amt;
          document.getElementById("txtFee_0").value=addCommas(amt.toFixed(2)); document.getElementById("txtBC").value="0.00"; document.getElementById("txtTtlFee").value=addCommas(ttl.toFixed(2));
        }
    }document.getElementById("txtWords").value=toWords(ttl.toFixed(2));
}function calcVotes(n){
    let amt=parseFloat(document.getElementById("txtFee_0").value.trim().replace(/[^0-9\.]/,'')),bal=parseFloat(document.getElementById("txtTtlArr").value.trim().replace(/[^0-9\.]/,''));
    let ttlamt,prevamt=amt,cur=parseFloat(document.getElementById("txtTtlCurr").value.trim().replace(/[^0-9\.]/,''));amt=isNaN(amt)?0:amt;bal=isNaN(bal)?0:bal; cur=isNaN(cur)?0:cur; ttlamt=bal+cur;
    if(amt>ttlamt){//Amount of arrears higher than arrears b/f
        alert('INFORMATION: The sum of KShs. '+addCommas(ttlamt.toFixed(2))+' is higher that arrears b/f.\nThe correct arrears b/f have been restored.'); amt=prevamt=ttlamt;
        document.getElementById("txtFee_0").value=addCommas(ttlamt.toFixed(2)); ttlFee();
    }if (amt>0){let a=0; ttlamt=0;
        while (a<n && amt>0){
            let arr=Number(document.getElementById("txtArr_"+a).value.replace(/[^0-9\.]/,'')),curr=Number(document.getElementById("txtCurr_"+a).value.replace(/[^0-9\.]/,''));
            arr=isNaN(arr)?0:arr; curr=isNaN(curr)?0:curr;   arr+=curr;
            if(amt>=arr){document.getElementById("txtAmt_"+a).value=addCommas(arr.toFixed(2)); 	amt-=arr; ttlamt+=arr;
            }else{document.getElementById("txtAmt_"+a).value=addCommas(amt.toFixed(2)); ttlamt+=amt;	amt=0;} a++;
        }document.getElementById("txtTtlAmt").value=addCommas(ttlamt.toFixed(2)); prevamt-=ttlamt; document.getElementById("txtVoteBal").value=addCommas(prevamt.toFixed(2));
    }
}function calcTotal(pos,nv){
    var ttl=0,amt=Number(document.getElementById("txtAmt_"+pos).value.replace(/[^0-9\.]/g,'')),curr=Number(document.getElementById("txtCurr_"+pos).value.replace(/[^0-9\.]/,''));
    amt=isNaN(amt)?0:amt; curr=isNaN(curr)?0:curr; var curbal=Number(document.getElementById("txtArr_"+pos).value.replace(/[^0-9\.]/g,''));  curbal=isNaN(curbal)?0:curbal; curbal+=curr;
    if(amt>curbal){alert('You can not receive more than Kshs. '+(addCommas(curbal.toFixed(2)))+' on this years arrears.\nThe correct balance has been restored.');
        document.getElementById("txtAmt_"+pos).value=addCommas(curbal.toFixed(2));
    }if(amt<0) document.getElementById("txtAmt_"+pos).value="0.00";
    for (var i=0;i<nv;i++){amt=Number(document.getElementById("txtAmt_"+i).value.replace(/[^0-9\.]/g,'')); amt=isNaN(amt)?0:amt; ttl+=amt;}
    document.getElementById("txtTtlAmt").value=addCommas(ttl.toFixed(2)); amt=Number(document.getElementById("txtFee_0").value.replace(/[^0-9\.]/g,''));
    amt-=ttl; document.getElementById("txtVoteBal").value=addCommas(amt.toFixed(2));
}function SaveFeeRecord(theForm){
    var err='',pytfrm=theForm.cboPytFrm.value.toUpperCase();
    if ((pytfrm !=="CASH") && (pytfrm !=="KIND")){
        let trno=theForm.txtCheNo.value.trim().length;
        if (trno<4){err+="Sorry, You MUST enter transaction/ cheque no. of this payment before saving!!\n"; theForm.txtCheNo.style.background='Yellow';}
        if (pytfrm==="CHEQUE" || pytfrm==="MONEY ORDER" || pytfrm==="DIRECT BANKING"){ let bank=parseInt(theForm.cboBank.value.toUpperCase());
            if (isNaN(bank) || bank===0){err+="Sorry, You MUST choose the bank  of this Cheque/Bankslip/Money Order before saving!!\n";  theForm.cboBank.style.background='Yellow';
            }else theForm.cboBank.style.background='white';
        }
    }else if (pytfrm=="KIND"){
        if (theForm.txtIDNo.value.length<7){err+="Sorry, You MUST type valid ID No. of the parent before saving!!\n";  theForm.txtKind.style.background='Yellow';
        }if (theForm.txtKind.value.length<10){err+="Sorry, You MUST type the description of fee receipt in kind before saving!!\n"; theForm.txtKind.style.background='Yellow';
        }if (theForm.txtParent.value.length<8){err+="Sorry, You MUST type the full name of the parent before saving!!\n"; theForm.txtParent.style.background='Yellow';
        }if (theForm.txtTelNo.value.length<10){err+="Sorry, You MUST type valid Telephone Number of the parent before saving!!\n"; theForm.txtTelNo.style.background='Yellow';}
    }let curr=0,arrbal=0,nac=Number(theForm.txtNoV.value),main=Number(theForm.txtTtlFee.value.replace(/[^0-9\.]/g,''));
    if (main<1){err+="Sorry, You MUST enter amount of fees arrears received before saving!!!\n"; document.getElementById("txtFee_0").style.background='Yellow';}
    main=Number(document.getElementById("txtVoteBal").value.replace(/[^0-9\.]/,''));
    if(main!==0){ err+='Voteheads MUST be fully distributed to respective voteheads!!!\n'; }
    for (var a=0;a<nac;a++){
        main=Number(document.getElementById("txtAmt_"+a).value.replace(/[^0-9\.]/g,''));    main=isNaN(main)?0:main;
        curr=Number(document.getElementById("txtCurr_"+a).value.replace(/[^0-9\.]/g,''));   curr=isNaN(curr)?0:curr;
        arrbal=Number(document.getElementById("txtArr_"+a).value.replace(/[^0-9\.]/g,''));  arrbal=isNaN(arrbal)?0:arrbal; arrbal+=curr;
        if(main>arrbal){err+='Votehead amount of Kshs. '+addCommas(main.toFixed(2))+' is higher than balance of Kshs. '+addCommas(arrbal.toFixed(2))+'.\n';
            document.getElementById("txtAmt_"+a).style.background='Yellow';   openVote=true;
        }else{document.getElementById("txtAmt_"+a).value=main;}
    }
    if(err.length>0){alert('THE FOLLOWING ERROR MUST BE CORRECTED BEFORE SAVING.\n'+err); return false;
    }else{document.getElementById("cboPaidBy").disabled=false;	document.getElementById("cboPytFrm").disabled=false;
        document.getElementById("txtCheNo").disabled=false;	document.getElementById("cboBank").disabled=false;return true;
    }
}function validateTransNo(txt){
    var illegal=/[^a-zA-Z0-9]/g,n=txt.value; if (n.length>0 && illegal.test(n)){n=n.replace(illegal,'');     txt.value=n;}
}function verifyDuplicateTransNo(txt){
    var transno=txt.value.replace(/[^a-zA-Z0-9]/g,''),nocache = Math.random() * 10000; //stop caching
    if(transno.length>0){ transno=transno.toUpperCase();
        if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
        } else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");} // code for IE6, IE5
        xmlhttp.onreadystatechange = function() {
            if (this.readyState===4 && this.status===200){    var n=Number(this.responseText); n=isNaN(n)?0:n;
                if (n>0){if (confirm('The Trans/ Cheque No. '+transno+ ' has been used on '+n+' receipt(s).\nIs it OK to use the same Trans/ Cheque No. again?')){;}else txt.value='';}
            }
        };  xmlhttp.open('GET','ajax/showBursBal.php?q=1-'+transno+'-'+nocache,true); xmlhttp.send();
    }
}function showKindDet(txt){
    var idno=txt.value.replace(/[^0-9]/g,''),nocache = Math.random() * 10000; //stop caching
    if(idno.length>0){
        if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
        } else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
        }xmlhttp.onreadystatechange = function() {if (this.readyState === 4 && this.status === 200){let n=this.responseText; n=n.toUpperCase();
            if (n!=='0-0-0'){n=n.split(/\-/g);document.getElementById("txtParent").readOnly=true;document.getElementById("txtParent").value=n[0];document.getElementById("txtAddress").readOnly=true;
                document.getElementById("txtTelNo").readOnly=true;	document.getElementById("txtTelNo").value=n[1];            	document.getElementById("txtAddress").value=n[2];
            }else{document.getElementById("txtParent").readOnly=false; 	document.getElementById("txtTelNo").readOnly=false;  document.getElementById("txtAddress").readOnly=false;}
            document.getElementById("txtKind").readOnly=false;
        }};  xmlhttp.open('GET','ajax/showBursBal.php?q=2-'+idno+'-'+nocache,true); xmlhttp.send();
    }
}var th = ['','Thousand','Million', 'Billion','Trillion'],tw = ['Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
var dg = ['Zero','One','Two','Three','Four', 'Five','Six','Seven','Eight','Nine'],tn = ['Ten','Eleven','Twelve','Thirteen', 'Fourteen','Fifteen','Sixteen', 'Seventeen','Eighteen','Nineteen'];
function toWords(s){
    s = s.toString(); s = s.replace(/[\, ]/g,''); if (s != parseFloat(s)) return 'not a number';
    var x = s.indexOf('.'); if (x == -1) x = s.length;  if (x > 15) return 'too big';
    var n = s.split(''),str = '',sk = 0;
    for (var i=0; i < x; i++) {
        if ((x-i)%3==2) {if (n[i]=='1') {str+=tn[Number(n[i+1])]+' ';  i++;  sk=1;} else if (n[i]!=0) {str+=tw[n[i]-2] + ' ';sk=1;}
        }else if (n[i]!=0) {str+=dg[n[i]] +' ';         if ((x-i)%3==0) str+='Hundred ';        sk=1;}
        if ((x-i)%3==1){if (sk) str+=th[(x-i-1)/3] + ' ';   sk=0; }
    }if (x!=s.length) { var y=s.length;    str+='Shillings and ';  var i=x+1;
        if (n[i]==0)  str+=dg[n[i]]+' Cents';
        else if (n[i]==1) str+=tn[n[i]+1]+' Cents';
        else{if (n[i+1]==0) str+=tw[n[i]-2] +' Cents'; else{str+=tw[n[i]-2];  str=str + '-' + dg[n[i+1]] + ' Cents'; }}
    }return str.replace(/\s+/g,' ');
}
