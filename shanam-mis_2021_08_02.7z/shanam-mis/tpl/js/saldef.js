function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.TxtPayrollNo);
	if (theForm.TxtACNo.value.length>0) reason += validateNo(theForm.TxtACNo);
	reason += validateUsername(theForm.CboBankBranch);
	if (theForm.TxtNSSFNO.value.length>0) reason += validateNo(theForm.TxtNSSFNO);
  	if (theForm.TxtNHIFNO.value.length>1) reason += validateUsername(theForm.TxtNHIFNO);
  	reason += validateNo(theForm.TxtHouse);
	reason += validateNo(theForm.TxtMedical);
	reason += validateNo(theForm.TxtCommuter);
	reason += validateNo(theForm.TxtEmpNSSF);
	reason += validateNo(theForm.TxtResponse);
	reason += validateNo(theForm.TxtNSSF);
	reason += validateNo(theForm.TxtNHIF);
	reason += validateNo(theForm.TxtSACCO);
	reason += validateNo(theForm.TxtWelfare);
	reason += validateNo(theForm.TxtPaye);
	reason += validateNo(theForm.TxtUnion);
	reason += validateNo(theForm.TxtOle);
	var n=document.getElementById("TxtNetSal").value; 	var nsal=parseFloat(n.replace(",",""));	
	if ((isNaN(nsal))||(nsal<1)) reason+="\nNet salary for the employee must be more than zero shillings."; 
  	if (reason != "") {
    	alert("The following fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /[^a-zA-Z0-9^]/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " You didn't enter the right information.\n";
	} else if (fld.value.length<3) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ \+]/g, '');     
	if (fld.value == "") {
    	error = fld.name + " requires numeric data, it is currently blank.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = fld.name + " requires numeric values, your entry contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0";
	}
}
function getGrossSal(){
	var gsal=0;
	var n=document.getElementById("TxtBasicSal").value; 	var x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("TxtBasicSal").value=addCommas(x.toFixed(2));}  
	n=document.getElementById("TxtHouse").value; 			x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
	if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("TxtHouse").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtMedical").value; 			x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
	if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("TxtMedical").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtCommuter").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
	if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("TxtCommuter").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtResponse").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
	if (!(isNaN(x)) && x>0){gsal+=x; document.getElementById("TxtResponse").value=addCommas(x.toFixed(2));}
	return gsal;
}
function computeGS(opt){
    var gsal=0,tax=0, nss=0,nhi=0;
    var payeamt=0, m=0,mprRate=0;
    //Gross salary and NSSF Fee computation and display
    gsal=getGrossSal();  	
    if(opt==0){ 
        nss=calcNSSF(gsal); document.getElementById("TxtEmpNSSF").value=addCommas(nss.toFixed(2));
    }else{nss=Number(document.getElementById("TxtEmpNSSF").value.replace(/[^0-9\.]/g,''));}
    document.getElementById("TxtNSSF").value=addCommas(nss.toFixed(2)); 
    m=gsal+nss;		document.getElementById("TxtGSal").value=addCommas(m.toFixed(2));
    //compute tax
    tax=calcPAYE(gsal-nss); if (tax<=mpr){tax=0; mprRate=0;} else mprRate=mpr;
    document.getElementById("TxtPaye").value=addCommas(tax.toFixed(2));
	document.getElementById("TxtMPR").value=addCommas(mprRate.toFixed(2));
    payeamt=tax-mprRate; document.getElementById("TxtPayeAuto").value=addCommas(payeamt.toFixed(2));
	//nhif computation
	m=gsal+nss; nhi=calcNHIF(m); document.getElementById("TxtNHIF").value=addCommas(nhi.toFixed(2));
	//total deductions
	computeDed();
}
function calcPAYE(gsal){
	var tax=0,amt=gsal,n=paye.length,a=0,limit=0;
	while (amt>0 && a<n){
	 	var taxable=Number(paye[a].ul)-limit;
		if (amt<=taxable){
			tax+=(amt*(Number(paye[a].rate)/100)); amt=0;
		}else{
			tax+=(taxable*(Number(paye[a].rate)/100)); amt-=taxable;
		}limit=Number(paye[a].ul);	a++;
	} return Math.ceil(tax);	
}
function calcNHIF(g){
	var n=nhif.length,a=0,found=false,nhi=0;
	while (a<n && found==false){
	 	var amt=Number(nhif[a].ul);
		if (g<=amt){
			nhi=Number(nhif[a].amt); found=true;
		}a++;
	}return nhi;	
}
function calcNSSF(g){
	var n=Math.ceil((nssfRate/100)*g);
	n=(n>1080?1080:n);
	return n;
}
function computeDed(){
 	var gsal=0,ded=0,tax=0;
 	var n=document.getElementById("TxtGSal").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));			
	if (!(isNaN(x))){gsal+=x; document.getElementById("TxtGSal").value=addCommas(x.toFixed(2));}
 	//Total Deduction Calculation
	n=document.getElementById("TxtNSSF").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("TxtNSSF").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtEmpNSSF").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("TxtEmpNSSF").value=addCommas(x.toFixed(2));} 
	n=document.getElementById("TxtNHIF").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("TxtNHIF").value=addCommas(x.toFixed(2));} 
	n=document.getElementById("TxtPaye").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0) {ded+=x; tax=x; document.getElementById("TxtPaye").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtMPR").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0) {ded-=x; tax-=x; document.getElementById("TxtMPR").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtUnion").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("TxtUnion").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtSACCO").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("TxtSACCO").value=addCommas(x.toFixed(2));} 
	n=document.getElementById("TxtWelfare").value; 	x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("TxtWelfare").value=addCommas(x.toFixed(2));}
	n=document.getElementById("TxtOle").value; 		x=parseFloat(n.replace(/[^0-9^\.]/g,""));	
	if (!(isNaN(x)) && x>0){ded+=x; document.getElementById("TxtOle").value=addCommas(x.toFixed(2));}
	document.getElementById("TxtDed").value=addCommas(ded.toFixed(2)); 	document.getElementById("TxtPayeAuto").value=addCommas(tax.toFixed(2));
	//Net salary calculation
	gsal-=ded;	m=gsal.toFixed(2); //format to two decimal places
	document.getElementById("TxtNetSal").value=addCommas(m);
}