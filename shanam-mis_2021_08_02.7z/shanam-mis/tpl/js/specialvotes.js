function Accounts(sno,name,acc,voteno,hvoteno,prot){this.sno=sno; this.voteno=voteno; this.name=name; this.hvoteno=hvoteno; this.prot=prot; this.acc=acc;} var accounts=[];
function Votes(sno,name,acc){this.sno=sno; this.acc=acc; this.name=name;} var votes=[];
function loadVotes(cbo){
	var acc=parseInt(cbo.value.trim());	var act=document.getElementById("txtOpt").value.trim();  act=act.split('-'); act[0]=Number(act[0]);
	clearCont('cboVote');	clearCont('cboCVote');	accVotes(acc); 
	if(act[0]==0) document.getElementById("btnSave").disabled=false; else document.getElementById("btnSave").disabled=true;
}
function accVotes(acc){
	if(acc>0){
		var i=votes.length;
		var cbo1=document.getElementById('cboVote'); var cbo2=document.getElementById('cboCVote');
		for (var index=0;index<i;index++){
		 	if(acc==votes[index].acc){
				var opt1=document.createElement("option"); 	var opt2=document.createElement("option");
				opt1.value=opt2.value=votes[index].sno; 	opt1.text=opt2.text=votes[index].name;
				cbo1.add(opt1); cbo2.add(opt2);
			}
		}
	}
}
function clearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function checkInput(ob){
	var invalidChars=/[^a-zA-Z]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=a;
	}
	if (ob.length==0){
	 	ob.value="";
	}
}
function canEdit(sno,pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to edit the record");
    	document.getElementById("btnSave").disabled=true;
  	} else {
  		var l=accounts.length; var i=0, found=false; clearCont('cboVote');	clearCont('cboCVote');
		while(i<l && found==false){
			if (sno==accounts[i].sno){
				found=true; document.getElementById("txtOpt").value="1-"+sno; 	document.getElementById("cboAC").value=accounts[i].acc; accVotes(parseInt(accounts[i].acc)); 
				document.getElementById("txtAbbr").value=accounts[i].name;		document.getElementById("cboVote").value=accounts[i].voteno;
				document.getElementById("cboCVote").value=accounts[i].hvoteno;
				if(accounts[i].prot==1) document.getElementById("chkProtected").checked=true; else  document.getElementById("chkProtected").checked=false;
			}i++;
		} 	
  		if(found==true) document.getElementById("btnSave").disabled=false; else document.getElementById("btnSave").disabled=true;
  	}
}
function validateData(theForm) {
	var reason = "";
	reason+=validateUsername(theForm.txtAbbr);
	reason+=validateNo(theForm.cboAC);
  	reason+=validateNo(theForm.cboVote);
  	if (reason != "") {
    	alert("The following correction(s) should be made:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = "You didn't enter the special votehead name.\n";
	} else if (fld.value.length < 3) {
    	fld.style.background = 'Yellow'; 
    	error = "The special votehead name is too short.\n";
	} else {
    	fld.style.background='White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = Number(fld.value.replace(/[^0-9]/g,''));     
	if (isNaN(stripped) || stripped<1) {
    	error="Select Votehead Account affected and votehead to receive income before saving.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}