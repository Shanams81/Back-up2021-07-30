function Hospitals(hno,name,addr,email,tel){this.hno=hno; this.name=name; this.addr=addr; this.email=email; this.tel=tel;} var hospitals=[];
function HospBills(bno,admno,hno,invno,edate,rmks,amt){this.bno=bno; this.hno=hno; this.admno=admno; this.edate=edate; this.invno=invno; this.rmks=rmks; this.amt=amt;} var hospbills=[];
function getLink(){
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    } return xmlhttp;
}
function rptHospBills(opt){//opt 1- Medical Invoices/Bills, 2- List of Hospitals
    let date1=document.getElementById('txtFrom').value;     let date2=document.getElementById('txtTo').value;
    var nocache = Math.random() * 10000; //stop caching
    var xmlhttp=getLink();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200){
            document.getElementById("divMedRpt").innerHTML = this.responseText;
            document.getElementById("printH").style.display='block';
        }
    };
    xmlhttp.open('GET','rpts/MedBillsRpt.php?q='+opt+'~'+date1+'~'+date2+'~'+nocache,true);
    xmlhttp.send();
}
function delConfirm(priv,btnSaveBill){
	if(priv==0){
		alert("Soory, You do not have the priviledge to delete hospital bills."); return false;
	}else{
		var c=confirm("You are about to delete this Hospital Bill.\If you sure type reason and click DELETE BILL button?");
		if(c==true){
                    document.getElementById('divDelRmks').style.display='block';
                    btn.disabled=false; document.getElementById('btnSaveBill').disabled=false;
                    return true;
		} else{
                    document.getElementById('divDelRmks').style.display='none';
                    btn.disabled=true; document.getElementById('btnSaveBill').disabled=true;
                    return false;
		}
	}
}
function enableDel(txt){
	let rmks=txt.value.trim().replace(/[^a-z\ \,\.\-\:]/gi,'');
	txt.value=rmks.toUpperCase();
	if(rmks.length>15) document.getElementById('btnDelete').disabled=false;
	else  document.getElementById('btnDelete').disabled=true;
}
function saveFacility() {
	var reason = "";
	reason+=validateUsername(0,document.getElementById("txtName"));
	reason+=validateUsername(2,document.getElementById("txtAddr"));
	reason+=validateUsername(2,document.getElementById("txtTel"));
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  	 	var nocache = Math.random()*10000; 		var no=document.getElementById("txtNo").value.trim();	var name=document.getElementById("txtName").value.trim().toUpperCase();
  	 	var email=document.getElementById("txtEMail").value.trim().toLowerCase();		var addr=document.getElementById("txtAddr").value.trim().toUpperCase();
			var tel=document.getElementById("txtTel").value.trim();
			xmlhttp =getLink(); // code for IE7+, Firefox, Chrome, Opera, Safari
	    xmlhttp.onreadystatechange = function() {
	      if (this.readyState == 4 && this.status == 200){
					document.getElementById("spFacilities").innerHTML = this.responseText;
					document.getElementById("divHead").innerHTML='NEW MEDICAL	FACILITY';
				}
	    };
	    xmlhttp.open('GET','ajax/showHospitals.php?q='+no+'-'+name+'-'+addr+'-'+email+'-'+tel+'-'+nocache,true);
			xmlhttp.send();
			document.getElementById("txtNo").value='';		document.getElementById("txtName").value=''; 	document.getElementById("txtEMail").value='';
			document.getElementById("txtAddr").value=''; 	document.getElementById("txtTel").value='';
  		return true;
  	}
}
function validateFormOnSubmit1(frm) {
	var reason = "";
	reason+=validateNo(frm.txtInvoice1);
	reason+=validateNo(frm.cboHosp1);
	reason+=validateNo(frm.txtAmt1);
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function verifyString(opt,ob){
	var illegalChars=(opt==0?/[^a-z0-9\.\,\ \+]/gi:(opt==1?/[^a-z0-9\.\@]/g:/[^0-9\+]/g)); // allow letters, numbers, and underscores
	let dat=ob.value.replace(illegalChars,'');
	ob.value=dat;
}
function validateUsername(cm,fld) {
	var error = "";
	var illegalChars=/\d/; // allow letters, numbers, and underscores
	if (fld.value=="") {
    	fld.style.background = 'Yellow';
    	error = "You didn't type hospital name, address and telephone number.\n";
	} else if (fld.value.length<6 && cm==0) {
    	fld.style.background = 'Yellow';
    	error = "The hospital name, address and telephone number typed is too short.\n";
	} else if (illegalChars.test(fld.value) && cm!=2) {
    	fld.style.background = 'Yellow';
    	error = "The hospital name,address and telephone number contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	}
	return error;
}
function checkNumber(opt,ob){
	var invalidChars; invalidChars=(opt==0?/[^0-9]/gi:/[^0-9\.\,]/gi);
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=a;
	}
	if (ob.length==0){
	 	ob.value=(opt==0?"":"0.00");
	}
}
function fmtNumber(ob){
	var invalidChars=/[^0-9\.]/gi;
	var a=ob.value.replace(invalidChars,"");
	if(a.length>0){
		ob.value=addCommas(a);
		document.getElementById("pWords").innerHTML=toWords(a);
	}else document.getElementById("pWords").innerHTML='Zero Shillings';
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[^0-9\.]/g, '');
	if (isNaN(parseInt(stripped)) || parseInt(stripped)==0) {
    	error = "The MUST enter all medical bill Invoice, Hospital and Amount before saving.\n";
    	fld.style.background = 'Yellow';
	} else {
    	fld.style.background = 'White';
	}
	return error;
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function editHospital(no){
    var i=0,found=false,len=hospitals.length;
    while(!found && i<len){
			if(no==hospitals[i].hno){
				found=true; document.getElementById("txtNo").value=1+'-'+hospitals[i].hno; 	document.getElementById("txtName").value=hospitals[i].name;
				document.getElementById("txtAddr").value=hospitals[i].addr;				document.getElementById("txtEMail").value=hospitals[i].email;
				document.getElementById("txtTel").value=hospitals[i].tel;					document.getElementById("divHead").innerHTML='EDITING MEDICAL	FACILITY';
			}i++;
	}
}
function getBilling(opt,billno,del){
 	var found=false, adm=document.getElementById("txtAdmNo").value;
	document.getElementById("pTitle").innerHTML=document.getElementById("spStud").innerHTML;
 	if (opt==0){//New bill information
		document.getElementById("txtNo1").value='0-0-'+adm+'-0';
		document.getElementById("btnDel").style.display='none'; found=true
	}else{//editing
		var i=0,len=hospbills.length;
	    while(!found && i<len){
			if(billno==hospbills[i].bno){
				found=true; document.getElementById("txtNo1").value=1+'-'+hospbills[i].bno+'-'+adm+'-'+hospbills[i].amt; 	document.getElementById("txtInvoice1").value=hospbills[i].invno;
				document.getElementById("cboHosp1").value=hospbills[i].hno;							document.getElementById("txtAmt1").value=addCommas(hospbills[i].amt.toFixed(2));
				document.getElementById("txtDate1").value=hospbills[i].edate;						document.getElementById("txtRmks1").value=hospbills[i].rmks;
				document.getElementById("pWords").innerHTML=toWords(hospbills[i].amt.toFixed(2));
				if (del==1) document.getElementById("btnDel").style.display='';
			}i++;
		}
	}if(found) document.getElementById('divEditBill').style.display='block';
}
//tab choice function
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
function findStud(txt) { //ch 0- find stud, 1- view uniform
    var adm; adm=parseInt(txt.value.replace(/[^0-9]/,'')); txt.value=isNaN(adm)?'':adm;
    document.getElementById("spStud").innerHTML='HOSPITAL BILLS FOR ALL STUDENTS';
		document.getElementById("btnNewBill").disabled=true;
    if (!isNaN(adm)){
			var nocache = Math.random()*10000;
			if (window.XMLHttpRequest) {
		        xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
		    } else {
		        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
		    }xmlhttp.onreadystatechange = function() {
		        if (this.readyState == 4 && this.status == 200){
							var f=this.responseText; document.getElementById("spStud").innerHTML=f;
							if(f.indexOf('ADM. NO.')>-1){
									document.getElementById("btnNewBill").disabled=false;
							} else{document.getElementById("btnNewBill").disabled=true;}
						}
				};
		    xmlhttp.open('GET','ajax/showStudName.php?q='+0+'-'+adm+'-1-'+nocache,true);
				xmlhttp.send();
		} findBills(adm);
}
function findBills(admno){
	var table, tr,td, i,nos=0,ttl=0;
	table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
	for(i=1;i<(tr.length-1);i++){
		td=tr[i].getElementsByTagName("td")[3];
		if (td){
			if(Number(td.innerHTML.trim())==admno || isNaN(admno)){
			 	tr[i].style.display=""; nos++; var amt=Number(tr[i].getElementsByTagName("td")[7].innerHTML.replace(/[^0-9\.]/,'')); ttl+=isNaN(amt)?0:amt;
			}else tr[i].style.display="none";
		}
	}document.getElementById("spNoB").innerHTML=nos+' Medical Bill(s)'; document.getElementById("spSubTtl").innerHTML=addCommas(ttl.toFixed(2));
}
var th = ['','Thousand','Million', 'Billion','Trillion'];
// uncomment this line for English Number System
// var th = ['','thousand','million', 'milliard','billion'];
var dg = ['Zero','One','Two','Three','Four', 'Five','Six','Seven','Eight','Nine'];
var tn = ['Ten','Eleven','Twelve','Thirteen', 'Fourteen','Fifteen','Sixteen', 'Seventeen','Eighteen','Nineteen'];
var tw = ['Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
function toWords(s){
 	s = s.toString();
	s = s.replace(/[\, ]/g,'');
	if (s != parseFloat(s)) return 'not a number';
	var x = s.indexOf('.');
	if (x == -1) x = s.length;
	if (x > 15) return 'too big';
	var n = s.split('');
	var str = '';
	var sk = 0;
	for (var i=0; i < x; i++) {
	 	if ((x-i)%3==2) {
		  	if (n[i] == '1') {
			   str += tn[Number(n[i+1])] + ' ';
			   i++;
			   sk=1;
			} else if (n[i]!=0) {
			 	str += tw[n[i]-2] + ' ';
				 sk=1;
			}
		} else if (n[i]!=0) {
		 	str += dg[n[i]] +' ';
			if ((x-i)%3==0) str += 'Hundred ';
			sk=1;
		}
		if ((x-i)%3==1) {
			if (sk) str += th[(x-i-1)/3] + ' ';
			sk=0;
		}
	}
	if (x != s.length) {
	 	var y = s.length;
		str += 'Shillings and ';
		var i=x+1;
		if (n[i]==0)
			str += dg[n[i]]+' Cents';
		else if (n[i]==1)
			str += tn[n[i]+1]+' Cents';
		else{
		 	if (n[i+1]==0)
		 		str += tw[n[i]-2] +' Cents';
		 	else{
				str += tw[n[i]-2];
				str =str + '-' + dg[n[i+1]] + ' Cents';
			}
		}
	}
	return str.replace(/\s+/g,' ');
}
