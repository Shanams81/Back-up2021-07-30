function validateFormOnSubmit(theForm) {
    var reason = "";
    reason += validateNo(theForm.txtQty);   reason += validateNo(theForm.txtUP);
    if (reason != "") {
        alert("The fields in yellow need correction:\n" + reason);
        return false;
    } else {
        return true;
    }
}
function validateNo(fld) {
    var error = "";
    var no=Number(fld.value.replace(/[^0-9\.]/g, ''));
    if (no.length===0) {
        error = "Enter quantity and unit price before saving.\n";
        fld.style.background = 'Yellow';
    }else if (isNaN(no) || no<1) {
        error = "Enter quantity and unit price MUST be greater that zero (0).\n";
        fld.style.background = 'Yellow';
    }
    return error;
}
function addCommas(nStr){
    nStr+='';
    let i=nStr.indexOf('.'); if(i===-1) nStr+='.00';
    var x=nStr.split('.');
    var x1=x[0];
    var x2=x.length>1?('.'+x[1]):'';
    var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
    return x1+x2;
}
function checkInput(ob){
    var invalidChars=/[^0-9\.]/gi;
    var a=ob.value.replace(invalidChars,"");
    if (a.length===0){
        ob.value="0.00";
    }else{ob.value=a;}
}
function calcAmt(){
    var up=0,qty=0;
    up=Number(document.querySelector('#txtUP').value.replace(/[^0-9\.]/g,''));     up=isNaN(up)?0:up;
    document.querySelector('#txtUP').value=addCommas(up.toFixed(2));
    qty=Number(document.querySelector('#txtQty').value.replace(/[^0-9\.]/g,''));   qty=isNaN(qty)?0:qty;
    document.querySelector('#txtQty').value=addCommas(qty.toFixed(2));
    document.querySelector('#txtTtl').value=addCommas((up*qty).toFixed(2));
}
