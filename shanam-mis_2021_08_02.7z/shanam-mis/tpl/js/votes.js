function Votes(vno,lfn,abb,des,acc,order,fs,stud,other,pyt){this.vno=vno; this.lfn=lfn,this.abb=abb; this.des=des; this.acc=acc; this.fs=fs; this.pyt=pyt; this.order=order;	this.stud=stud;		this.other=other;
} var votes=[];
function showEdit(opt,priv,ac,vot,del){
	if (priv==0){	alert("Sorry, you do not have the priviledge to "+(opt==0?"add":"edit")+" votehead details.");
	}else{	document.getElementById("txtNo1").value=opt+'-'+vot;	document.getElementById("txtVoteNo1").value=vot;
		if (opt==1){/*Editing votehead*/	var l=votes.length, found=false, i=0;
			while(found==false && i<l){	if(votes[i].vno==vot && votes[i].acc==ac){
				document.getElementById("txtAbbr1").value=votes[i].abb;document.getElementById("txtLFN1").value=votes[i].lfn; 	document.getElementById("txtDescr1").value=votes[i].des;
				document.getElementById("cboAccount1").value=votes[i].acc;	document.getElementById("txtOrder1").value=votes[i].order;
				if (votes[i].fs==1) document.getElementById("chkFee1").checked=true; else document.getElementById("chkFee1").checked=false;
				if (votes[i].stud==1) document.getElementById("chkStud1").checked=true; else document.getElementById("chkStud1").checked=false;
				if (votes[i].other==1) document.getElementById("chkOtherInco1").checked=true; else document.getElementById("chkOtherInco1").checked=false;
				if (votes[i].pyt==1) document.getElementById("chkPyt1").checked=true; else document.getElementById("chkPyt1").checked=false;
				document.getElementById('spDelete').innerHTML='<a href="votes.php?vno='+votes[i].vno+'" onclick="return delConfirm('+del+')"><button type="button" class="btn btn-info btn-md" name="btnDelete">Delete '+
        'Votehead</button></a>'; found=true;	}i++;	}
		}else{/*new votehead*/document.getElementById("txtAbbr1").value=''; 		document.getElementById("txtDescr1").value=''; 		document.getElementById("cboAccount1").value='';
			document.getElementById("chkFee1").checked=false; 	document.getElementById("chkPyt1").checked=false; found=true;
		}
	}if (found==true) document.getElementById("votesEdit").style.display='block';
}function checkValue(txt){var val=txt.value;txt.value=val.replace(/[^a-zA-Z^\&\.\,\ ]/g,'');}
function checkNumber(ob){	var invalidChars=/[^0-9]/g; if (invalidChars.test(ob.value)){	var a=ob.value.replace(invalidChars,"");	ob.value=a;}if (ob.length==0) ob.value='';}
function delConfirm(del){if (del==0){alert("Sorry, you do not have the priviledge to delete voteheads."); return false;}
  else{var ans=confirm("Are you sure you want to delete this votehead?\nClick OK to delete otherwise click Cancel.");	if (ans==true) return true; else return false;}}
