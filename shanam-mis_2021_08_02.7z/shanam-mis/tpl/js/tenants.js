function canView(pr) {
	if (pr == 0){	alert("Sorry, you do not have the priviledges to view the tenant details"); return false;
	}else{return true;}
}function canAdd(pr) {
	if (pr == 0){ alert("Sorry, you do not have the priviledges to receive rent");return false;
	}else{return true;}
}function canEdit(pr) {
	if (pr == 0){ alert("Sorry, you do not have the priviledges to edit received rent");return false;
	}else{return true;}
}function canRevoke(pr) {
	if (pr == 0){	alert("Sorry, you do not have the priviledges to revoke/ cancel imprest approval");	return false;
	}else{return true;}
}function canClear(pr) {
	if (pr == 0){	alert("Sorry, you do not have the priviledges to capture imprest surrendering details");return false;
	}else{return true;}
}function printSpecific(rpts){
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,";  disp_setting+="scrollbars=yes,width=650, height=600, left=100, top=25";
	var content_value = document.getElementById(rpts).innerHTML;	var docprint=window.open("","",disp_setting); docprint.document.open();
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title></head><body onLoad="self.print()" '+
	'style="color:#000000;font-size:10px;"><center>'+content_value+'</body></html>');	docprint.document.close(); docprint.focus();
}function xmlConnect(){
	if (window.XMLHttpRequest) {xmlhttp=new XMLHttpRequest();} else {xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
	return xmlhttp;
}function showRentPaid(){
	let ac=document.querySelector("#cboAC").value,sdate=document.querySelector("#txtFrom").value, edate=document.querySelector("#txtTo").value;
	var nocache = Math.random() * 10000,xmlhttp=xmlConnect();
	xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {document.querySelector("#divRentPaid").innerHTML=this.responseText; document.querySelector("#printH").style.display='block';}
  }; xmlhttp.open('GET','rpts/rentrpt.php?q='+ac+'~'+sdate+'~'+edate+'~'+nocache,true);		xmlhttp.send();
}function rentRegister(opt,tno){
	if(opt==0){var tno=document.querySelector('#txtRegFind').value.trim(),findby=(document.querySelector('#radRegIDNo').checked==true?'idno':'tno');}
	else var findby='tno';	tno=(tno.length==0?'%':tno);
	let nocache = Math.random() * 10000,xmlhttp=xmlConnect();
	xmlhttp.onreadystatechange = function() {
    if (this.readyState==4 && this.status==200){
			if(opt==1){document.querySelector("#divRentRegIndiv").innerHTML=this.responseText; document.querySelector("#printIReg").style.display='block';}
			else{document.querySelector("#divRentReg").innerHTML=this.responseText; document.querySelector("#printAll").style.display='block';}
		}
  }; xmlhttp.open('GET','rpts/rentregister.php?q='+tno+'~'+findby+'~'+nocache,true);		xmlhttp.send();
}function myFunction(){
	var input, table, tr,td, i,nos=0,ttl=0,a=(document.getElementById("radImpNo").checked?0:(document.getElementById("radIDNo").checked?1:2)); // impreset such criteria
	input=document.getElementById("txtFind").value.toUpperCase(); table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
	for(i=2;i<(tr.length-1);i++){
		td=tr[i].getElementsByTagName("td")[a];
		if (td){if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){
			 	tr[i].style.display=""; nos++; var amt=Number(tr[i].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9^\.]/,'')); ttl+=isNaN(amt)?0:amt;
			}else tr[i].style.display="none";
		}
	}document.getElementById("spTotal").innerHTML=addCommas(ttl.toFixed(2));document.getElementById("spNoImp").innerHTML=nos+' Imprest Record(s).';
} function clrText(){
	document.getElementById("txtFind").value=''; document.getElementById("txtFind").focus();
} function addCommas(nStr){
	nStr+=''; var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
} function calcTotal(txt){
	let ttl=0,amt=parseFloat(document.querySelector("#txtArrears1").value.replace('/[^0-9\.]/g',''));
	ttl+=isNaN(amt)?0:amt; amt=parseFloat(document.querySelector("#txtRent1").value.replace('/[^0-9\.]/g',''));
	ttl+=isNaN(amt)?0:amt; amt=parseFloat(document.querySelector("#txtFurn1").value.replace('/[^0-9\.]/g',''));
	ttl+=isNaN(amt)?0:amt; amt=parseFloat(document.querySelector("#txtWater1").value.replace('/[^0-9\.]/g',''));
	ttl+=isNaN(amt)?0:amt; amt=parseFloat(document.querySelector("#txtElect1").value.replace('/[^0-9\.]/g',''));
	ttl+=isNaN(amt)?0:amt; document.querySelector("#txtTotalBill").value=addCommas(ttl); cleanAmt(txt);
} function cleanAmt(txt){
	let amt=txt.value.replace('/[^0-9\.]/g',''); txt.value=(amt.length==0?"0.00":amt);
} function fmtNumber(txt){
	let amt=txt.value.replace('/[^0-9\.]/g',''); txt.value=addCommas(amt);
} function validateFormOnSubmit(frm){
	var err="";
	if(frm.txtTNo1.value.length!=6){ err+="Tenant No. is too short. It MUST be six characters\n"; frm.txtTNo1.style.background='Yellow';}
	if(frm.txtRent1.value.replace(/[^0-9\.]/g,'')=="0.00"){err+="Rent amount should be valid\n";  frm.txtRent1.style.background='Yellow';}
	if(isNaN(Number(frm.txtHNo1.value.replace(/[^0-9]/g,'')))){err+="House number should be valid\n";  frm.txtHNo1.style.background='Yellow';}
	if(err.length==0){return true;}else{alert('CORRECT THE FOLLOWING ERRORS BEFORE SAVING\n'+err); return false;}
} function showDelete(p){
	if(p==0){alert('Sorry, You do not have the priviledges to delete tenant.');
	}else{
		if(confirm('Are you sure you want to delete this tenant? \nClick OK to type reason for delete.')){
			document.querySelector("#divDelTenant").style.display='block'; document.querySelector("#divBtns").style.visibility='hidden';
		}
	}
} function cancelDel(){
	document.querySelector("#divDelTenant").style.display='none'; document.querySelector("#divBtns").style.visibility='visible';
}function checkRmks(txt){
	let rmks=txt.value.replace(/[^a-z\ \,\.\-]/gi,''); txt.value=rmks;
	if (rmks.length>10) document.querySelector('#btnDelete').disabled=false; else document.querySelector('#btnDelete').disabled=true;
}
