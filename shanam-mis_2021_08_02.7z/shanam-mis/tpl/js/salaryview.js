function disableCmd(choice,acc){
    var salno=Number(document.querySelector("#txtSalNo").value); 	salno=isNaN(salno)?0:salno;
    if(choice==0){
        var opt=Number(document.querySelector("#cboTypeRpt").value);	var grp=document.querySelector("#cboStfGrp").value;
        if(salno>0 && opt>0){
            document.querySelector("#busyWait").style.display="block";
            window.open("pdf/payrollnpayslip.php?action="+opt+"-"+salno+"-"+grp+"-"+(Math.floor(Math.random()*20)),"_blank");
        }else alert('You have no '+(opt==1?"payroll":"payslips")+" to be viewed!!.");
    }else{
       var opt1=document.querySelector("#cboPV").value.trim();
       if(salno>0 && opt1.length>0){
            opt1=opt1.split("-"); //[0] - Voucher No. [1] - Pay No.
            document.querySelector("#busyWait").style.display="block";
            window.open("rpts/pv.php?action="+opt1[0]+"-0-"+opt1[1]+"-"+acc,"_blank");
        }else alert('You have no payment voucher to be viewed!!.');
    }
}
