function ClassName(sno,nam,lvl){this.sno=sno; this.nam=nam; this.lvl=lvl;} var classname=[];
function showClass(cbo){var lvl=parseInt(cbo.value),l=classname.length,cboCls=document.querySelector("#cboClass"); clrCbo(cboCls); addItem(cboCls,"%","All");
  for(var i=0;i<l;i++){if(isNaN(lvl) || lvl===classname[i].lvl) addItem(cboCls,classname[i].sno,classname[i].nam);}
}function clrCbo(cbo){if(cbo == null) return; while(cbo.length>0) cbo.remove(0);}
function addItem(cbo,val,txt){var selectBoxOption=document.createElement("option");	selectBoxOption.value=val; selectBoxOption.text=txt;	cbo.add(selectBoxOption);}
function myFunction(){var input, tr,td, i,nop=0,ttl=0,amt=0,a=(document.getElementById("radAdmNo").checked?0:(document.getElementById("radNEMISNo").checked?1:2));
    input=document.getElementById("txtFind").value.toUpperCase();  tr=document.getElementById("myTable").getElementsByTagName("tr");
    for(i=0;i<tr.length;i++){td=tr[i].getElementsByTagName("td")[a];
      if (td){if(a==0){if(td.innerHTML.trim()==input || input.length==0){tr[i].style.display=""; nop++;} else tr[i].style.display="none"; //find by adm no
      }else{if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1 || input.length==0){tr[i].style.display=""; nop++; amt=Number(tr[i].getElementsByTagName("td")[6].innerHTML.replace(/[^0-9\.]/g,'')); ttl+=(isNaN(amt)?0:amt);
      }else tr[i].style.display="none";}}
    }document.getElementById("spTotal").innerHTML=nop+' Students Displayed.';	document.getElementById("divAmt").innerHTML=addCommas(ttl);
}function clrText(){ document.getElementById("txtFind").value='';  document.getElementById("txtFind").focus();}
function addCommas(nStr){nStr+='';   if (nStr.indexOf('.')==-1) nStr+='0.00';
	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):''; var rgx=/(\d+)(\d{3})/;while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}function canedit(a){ //a==1 then can edit otherwise can not
	if (a==0){alert("Sorry, you do not have the priviledges to edit student record. Contact your Admin/ Bursar/ Senior Teacher");return false;}else{return true;}
}function candelete(a){ //a==1 then can delete otherwise can not
	if (a==0){alert("Sorry, you do not have the priviledges to delete student record. Contact your Admin/ Bursar/ Senior Teacher");	return false;	}else{
	 	var ans=confirm("Are you sure you want to delete this student from this financial year?\nClick OK to delete otherwise click Cancel.");
	 	if (ans==true){return true;}else{	return false;	}
	}
}
