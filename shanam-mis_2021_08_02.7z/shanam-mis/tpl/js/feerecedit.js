function checkPyt(obj){
    var frm=obj.value.trim().toUpperCase(); var origpf=document.getElementById('txtOrigPF').value.toUpperCase();
    if(origpf==='KIND' && frm!==KIND){if(!confirm('You want to change mode from '+origpf+' to '+frm+'.\nThis will result to lose of related Payment Voucher.\nClick OK if you are sure.')) return;
        else obj.value='KIND';
    } document.getElementById('txtIDNo').readOnly=true; document.getElementById('spKind').style.display='none';
    if(frm==='CASH'){document.getElementById('txtCheNo').readonly=true; document.getElementById('cboBank').value=0; document.getElementById('txtCheNo').value='';}
    else if(frm==='CHEQUE' || frm==='DIRECT BANKING' || frm==='MONEY ORDER'){document.getElementById('txtCheNo').readonly=false; document.getElementById('cboBank').readonly=false;}
    else if(frm==='MFEES'){document.getElementById('txtCheNo').readonly=false; document.getElementById('cboBank').value=0;}
    else if(frm==='KIND'){document.getElementById('spKind').style.display='block'; document.getElementById('txtIDNo').readOnly=false;	document.getElementById('cboBank').value=0}
}function addCommas(nStr){
    nStr+='';   var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';   var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}  return x1+x2;
}function checkInput(ch,ob){
    var invalidChars; invalidChars=(ch===0?/[^0-9\.\,]/g:/[^0-9]/g);
    if (invalidChars.test(ob.value)){ var a=ob.value.replace(invalidChars,"");   ob.value=a; }
    if (ob.length===0){ob.value=(ch===0?'0.00':'');}
}function loadBursaryBal(txt){
    var bal=0, bno=parseInt(txt.value.replace(/[^0-9]/g,'')), borig=parseInt(document.getElementById("txtOrigBursNo").value);
    var amt=Number(document.getElementById("txtOrigFee").value.replace(/[^0-9\.]/g,''));	amt=isNaN(amt)?0:amt; 
    if(!isNaN(bno)){let nocache = Math.random() * 10000; //stop caching 
        if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
        } else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");} // code for IE6, IE5
        xmlhttp.onreadystatechange = function() {if (this.readyState=== 4 && this.status=== 200){
            var ans=this.responseText; ans=ans.split(/\-/g); bal=Number(ans[3]); bal=isNaN(bal)?0:bal; if(bno==borig) bal+=amt;
            if(bal>0){ bal+=amt;  document.getElementById("txtBursBal").value = addCommas(bal.toFixed(2));	document.getElementById("cboPaidBy").value='Bursary'; 
                document.getElementById("cboPaidBy").disabled=true;document.getElementById("cboPytFrm").value=ans[0];document.getElementById("cboPytFrm").disabled=true;	
                document.getElementById("txtCheNo").value=ans[1];  document.getElementById("txtCheNo").disabled=true;document.getElementById("cboBank").value=ans[2];
                document.getElementById("cboBank").disabled=true;
            }else{alert('Sorry, Bursary No. '+bno+' is either fully distributed or not recognized by the system.');	document.getElementById("txtBursBal").value='';
                document.getElementById("cboPaidBy").value='Parent';document.getElementById("cboPaidBy").disabled=false;document.getElementById("cboPytFrm").disabled=false;	
                document.getElementById("txtCheNo").disabled=false; document.getElementById("cboBank").disabled=false;	txt.value=''; 
                document.getElementById("cboPytFrm").focus();
            }
        }};  xmlhttp.open('GET','ajax/showBursBal.php?q=0-'+bno+'-'+nocache,true); xmlhttp.send();
    }else{ txt.value=''; document.getElementById("txtBursBal").value=''; document.getElementById("cboPaidBy").value='Parent';document.getElementById("cboPaidBy").disabled=false;
        document.getElementById("cboPytFrm").disabled=false;document.getElementById("txtCheNo").disabled=false;	document.getElementById("cboBank").disabled=false;
        document.getElementById("cboPytFrm").focus();
    } 
}function ttlFee(){
    var ttl=0,obj=document.getElementById("txtFee"); checkInput(0,obj),amt=Number(obj.value.replace(/[^0-9\.]/g,'')); ttl+=(isNaN(amt)?0:amt); obj=document.getElementById("txtBC"); checkInput(0,obj);
    amt=Number(document.getElementById("txtBC").value.replace(/[^0-9\.]/g,'')); ttl+=(isNaN(amt)?0:amt);   document.getElementById("txtTtlFee").value=addCommas(ttl.toFixed(2));
    var bno=parseInt(document.getElementById("txtBursNo").value);
    if (!isNaN(bno) && bno>0){//checking if bursary balance and fee amount are okay
        amt=Number(document.getElementById("txtBursBal").value.replace(/[^0-9\.]/g,'')); amt=(isNaN(amt)?0:amt);
        if (amt<ttl){alert("The sum of Kshs. "+ttl+" is higher than bursary balance of Kshs. "+amt+".\nThe correct amt has been set.");
          document.getElementById("txtFee").value=addCommas(amt.toFixed(2));document.getElementById("txtBC").value="0.00"; ttl=amt; 
          document.getElementById("txtTtlFee").value=addCommas(ttl.toFixed(2));
        }
    }document.getElementById("txtWords").value=toWords(ttl.toFixed(2));
}function calcTtl(){
    var ttl=0,n=parseInt(document.getElementById("txtNoV").value.trim()),amt=Number(document.getElementById("txtFee").value.replace(/[^0-9\.]/g,'')),vot=0; amt=(isNaN(amt)?0:amt);
    for(var i=0;i<n;i++){vot=Number(document.getElementById("txtAmt_"+i).value.replace(/[^0-9\.]/g,'')); ttl+=(isNaN(vot)?0:vot);}amt-=ttl; 
    document.getElementById("txtVoteBal").value=addCommas(amt.toFixed(2));
}function calcVotes(pos){
    var i=0,nov=parseInt(document.getElementById("txtNoV").value.trim()), locked=document.getElementById("txtLocked").value.trim().split(/\-/g);
    var amt=Number(document.getElementById("txtTtlFee").value.trim().replace(/[^0-9\.]/,'')),ttl=0;
    for(var i=0;i<nov;i++){var vot=Number(document.getElementById("txtAmt_"+i).value.trim().replace(/[^0-9\.]/,'')),len=locked.length,found=false,index=0; vot=isNaN(vot)?0:vot;
        while (index<len && !found){if(i==locked[index]) found=true; index++;}
        if(pos===i){var bal=Number(document.getElementById("txtBal_"+pos).value.trim().replace(/[^0-9\.]/,'')),bal1=Number(document.getElementById("txtCurr_"+pos).value.trim().replace(/[^0-9\.]/,''));
            bal=isNaN(bal)?0:bal; bal1=isNaN(bal)?0:bal1;      bal+=bal1;
            if(!found && (bal<vot)){alert('Sorry, You can not allocate more than Kshs. '+addCommas(bal.toFixed(2))+' on this votehead.\nPrevious Amount has been restored.'); 
            document.getElementById("txtAmt_"+pos).value=document.getElementById("txtCurr_"+pos).value; document.getElementById("txtAmt_"+pos).style.background='yellow'; vot=bal1;}
        }ttl+=vot;
    }amt-=ttl; document.getElementById("txtVoteBal").value=addCommas(amt.toFixed(2));
}function SaveFeeRecord(theForm){
    var err='',pytfrm=theForm.cboPytFrm.value.toUpperCase(),origpf=theForm.txtOrigPF.value.toUpperCase(),bc=Number(theForm.txtBC.value.replace(/[^0-9\.]/g,'')); 
    bc=isNaN(bc)?0:bc; theForm.CmdSave.disabled=true;
    if ((pytfrm!=="CASH") && (pytfrm!=="KIND")){
        var trno=theForm.txtCheNo.value.trim().length;
        if (trno<4){err+="Sorry, You MUST enter transaction/ cheque no. of this payment before saving!!\n"; theForm.txtCheNo.style.background='Yellow';
        }if(pytfrm!=="CHEQUE" && bc>0){err+="Sorry, You can not charge Bank charges on Non-Cheque modes.\nZero has been set as Bank Charges.\n"; theForm.txtBC.value="0.00"; ttlFee();} 
        if (pytfrm==="CHEQUE" || pytfrm==="MONEY ORDER" || pytfrm==="DIRECT BANKING"){
            let bank=parseInt(theForm.cboBank.value.toUpperCase());
            if (isNaN(bank) || bank===0){ err+="Sorry, You MUST choose the banker of this Cheque/ Bankslip/ Money Order before saving!!\n";  theForm.cboBank.style.background='Yellow';
            }else theForm.cboBank.style.background='white';
        }
    }if (pytfrm==="KIND"){
        if (theForm.txtIDNo.value.length<7){err+="Sorry, You MUST type valid ID No. of the parent before saving!!\n";   theForm.txtKind.style.background='Yellow';
        }if (theForm.txtKind.value.length<10){err+="Sorry, You MUST type the description of fee receipt in kind before saving!!\n";  theForm.txtKind.style.background='Yellow';
        }if (theForm.txtParent.value.length<8){err+="Sorry, You MUST type the full name of the parent before saving!!\n"; theForm.txtParent.style.background='Yellow';
        }if (theForm.txtTelNo.value.length<10){ err+="Sorry, You MUST type valid Telephone Number of the parent before saving!!\n"; theForm.txtTelNo.style.background='Yellow';}
    }if(pytfrm!=="KIND" && origpf==="KIND"){
        if(!confirm('Changing mode of payment from KIND will result in cancellation of related PV.\nClick OK if sure you want to change the mode')){
            err+='Mode of fee payment has been restored to KIND!'; theForm.cboPytFrm.value='KIND'; theForm.cboPytFrm.style.background='Yellow';
        }
    }var nov=Number(theForm.txtNoV.value),amt=Number(theForm.txtFee.value.replace(/[^0-9\.]/g,'')),locked=document.getElementById("txtLocked").value.trim().split(/\-/g),len=locked.length; 
    if (amt===0){err+="Sorry, You MUST enter amount of fees received before saving!!!\n";  document.getElementById("txtFee").style.background='Yellow'; }
    amt=Number(document.getElementById("txtVoteBal").value.replace(/[^0-9\.]/g,''));     if(amt!==0) err+='Voteheads MUST be fully distributed to respective voteheads!!!\n';
    for (var a=0;a<nov;a++){let found=false,index=0,amt1=0;
        while (index<len && !found){if(a==locked[index]) found=true; index++;}
        if(!found){amt=Number(document.getElementById("txtBal_"+a).value.replace(/[^0-9\.]/g,''));     amt=isNaN(amt)?0:amt;
            amt1=Number(document.getElementById("txtCurr_"+a).value.replace(/[^0-9\.]/g,''));   amt1=isNaN(amt1)?0:amt1; amt1+=amt;
            amt=Number(document.getElementById("txtAmt_"+a).value.replace(/[^0-9\.]/g,''));     amt=isNaN(amt)?0:amt;
            if(amt>amt1){err+='Votehead amount of Kshs. '+addCommas(amt.toFixed(2))+' is higher than balance of Kshs. '+addCommas(amt1.toFixed(2))+'.\n';
                document.getElementById("txtAmt_"+a).style.background='Yellow';				
            }	
        }
    }if(err.length>0){alert('THE FOLLOWING ERROR MUST BE CORRECTED BEFORE SAVING.\n'+err); theForm.CmdSave.disabled=false;  return false;
    }else{document.getElementById("cboPaidBy").disabled=false;document.getElementById("cboPytFrm").disabled=false;document.getElementById("txtCheNo").disabled=false;
        document.getElementById("cboBank").disabled=false; return true;
    } 
}function validateTransNo(txt){
    var illegal=/[^a-zA-Z0-9]/g,n=txt.value;
    if (n.length>0 && illegal.test(n)){n=n.replace(illegal,''); txt.value=n;}
}function verifyDuplicateTransNo(txt){
    var transno=txt.value.replace(/[^a-zA-Z0-9]/g,''),nocache = Math.random() * 10000; //stop caching 
    if(transno.length>0){transno=transno.toUpperCase();
        if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
        } else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");} // code for IE6, IE5
        xmlhttp.onreadystatechange=function() {if (this.readyState===4 && this.status===200){
            let n=Number(this.responseText); n=isNaN(n)?0:n; 
            if (n>0){if (confirm('The Trans/ Cheque No. '+transno+ ' has been used on '+n+' receipt(s).\nIs it OK to use the same Trans/ Cheque No. again?')){;}else txt.value='';}
        }}; xmlhttp.open('GET','ajax/showBursBal.php?q=1-'+transno+'-'+nocache,true); xmlhttp.send();
    }
}function showKindDet(txt){
    var idno=txt.value.replace(/[^0-9]/g,''),nocache = Math.random() * 10000; //stop caching 
    if(idno.length>0){
        if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
        } else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");} // code for IE6, IE5
        xmlhttp.onreadystatechange = function() {if (this.readyState===4 && this.status===200){
            var n=this.responseText; n=n.toUpperCase();
            if (n!='0-0-0'){n=n.split(/\-/g); document.getElementById("txtParent").readOnly=true;document.getElementById("txtParent").value=n[0];document.getElementById("txtTelNo").readOnly=true;
                document.getElementById("txtTelNo").value=n[1]; document.getElementById("txtAddress").readOnly=true; 	document.getElementById("txtAddress").value=n[2];
            }else{document.getElementById("txtParent").readOnly=false; 	document.getElementById("txtTelNo").readOnly=false;document.getElementById("txtAddress").readOnly=false;}
            document.getElementById("txtKind").readOnly=false;
        }};   xmlhttp.open('GET','ajax/showBursBal.php?q=2-'+idno+'-'+nocache,true); xmlhttp.send();
    }
}var th = ['','Thousand','Million', 'Billion','Trillion'],tw = ['Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
// uncomment this line for English Number System
// var th = ['','thousand','million', 'milliard','billion'];
var dg = ['Zero','One','Two','Three','Four', 'Five','Six','Seven','Eight','Nine'],tn = ['Ten','Eleven','Twelve','Thirteen', 'Fourteen','Fifteen','Sixteen', 'Seventeen','Eighteen','Nineteen'];
function toWords(s){
    s = s.toString(); s = s.replace(/[\, ]/g,''); if (s != parseFloat(s)) return 'not a number';
    var x = s.indexOf('.'); if (x == -1) x = s.length;  if (x > 15) return 'too big';
    var n = s.split(''),str = '',sk = 0;
    for (var i=0; i < x; i++) {
        if ((x-i)%3==2) {if (n[i]=='1') {str+=tn[Number(n[i+1])]+' ';  i++;  sk=1;} else if (n[i]!=0) {str+=tw[n[i]-2] + ' ';sk=1;}
        }else if (n[i]!=0) {str+=dg[n[i]] +' ';         if ((x-i)%3==0) str+='Hundred ';        sk=1;}
        if ((x-i)%3==1){if (sk) str+=th[(x-i-1)/3] + ' ';   sk=0; }
    }if (x!=s.length) { var y=s.length;    str+='Shillings and ';  var i=x+1;
        if (n[i]==0)  str+=dg[n[i]]+' Cents';
        else if (n[i]==1) str+=tn[n[i]+1]+' Cents';
        else{if (n[i+1]==0) str+=tw[n[i]-2] +' Cents'; else{str+=tw[n[i]-2];  str=str + '-' + dg[n[i+1]] + ' Cents'; }}
    }return str.replace(/\s+/g,' ');
}function showDel(del){
    if(del==0){alert("Sorry, You do not have the privilege to delete fee record."); document.getElementById('feeDel').style.display='none';
    }else{if(confirm('You are about to delete this fee record.\n Click OK to delete, otherwise click CANCEL.')) document.getElementById('feeDel').style.display='block';}
}function confirmDel(v){
    if(v===0){alert('Sorry, You do not have the priviledge to delete income.'); return false;
    }else{let rmks=document.getElementById('txtReason').value.trim();
        if(rmks.length<10){alert('Sorry, You MUST type valid reason for deleting this income.'); document.getElementById('txtReason').style.background='yellow'; return false;
        }else return true;
    }
}function showKind(m){
    if(m.toUpperCase()==='KIND'){document.getElementById('spKind').style.display='block'; document.getElementById('txtKind').readOnly=false;
        document.getElementById('txtCheNo').readOnly=true; 		 document.getElementById('cboBank').disabled=true;
    }else document.getElementById('spKind').style.display='none';
}