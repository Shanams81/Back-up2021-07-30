function Votes(vno,acc,names){this.vno=vno; this.acc=acc;   this.names=names;};
var votes=[];
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
    var mylistbox = document.getElementById(listboxID);
    if(mylistbox == null) return 1;
    while(mylistbox.length > 0) mylistbox.remove(0);
    return 1;
}
function fillVotes(listboxID){
    var i=ClearCont(listboxID); var len=votes.length;
    var ac = document.getElementById("cboAccount").value;
    var htmlSelect=document.getElementById(listboxID);
    selectBoxOption = document.createElement("option");
    selectBoxOption.value = "%";
    selectBoxOption.text = "All";
    htmlSelect.add(selectBoxOption);
    for (var i=0;i<len;i++){
        if (votes[i].acc==ac){
            selectBoxOption = document.createElement("option");
            selectBoxOption.text = votes[i].names;
            selectBoxOption.value = votes[i].vno;
            htmlSelect.add(selectBoxOption);
        }
    }
}
function printBudget(opt){
    let vot=document.getElementById('cboVote').value;         let acc=Number(document.getElementById('cboAccount').value);
    vot=vot.length==0?'%':vot;                                acc=isNaN(acc)?1:acc;
    if(opt==1){
      window.open('rpts/budget.php?action='+opt+'-'+acc+'-'+vot,'_blank');
    }else{
      window.open('pdf/budget.php?action='+opt+'-'+acc+'-'+vot,'_blank');
    }
}
