function canView(pr) {if(pr==0){alert("Sorry, you do not have the priviledges to view the imprest details"); return false;}else	return true;}
function canIssue(pr){if(pr==0){alert("Sorry, you do not have the priviledges to issue imprests");return false;}else return true;}
function canRevoke(pr){if(pr==0){alert("Sorry, you do not have the priviledges to revoke/ cancel imprest approval");return false;}else return true;}
function canClear(pr){if(pr==0){alert("Sorry, you do not have the priviledges to capture imprest surrendering details");return false;}else return true;}
function printSpecific(){
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25",content_value = document.getElementById("divImprests").innerHTML;
	var docprint=window.open("","",disp_setting); docprint.document.open();
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title></head><body onLoad="self.print()" style="color:#000000;font-size:10px;">'+content_value+
	'</body></html>');docprint.document.close(); docprint.focus();
}function myFunction(){
	var input=document.getElementById("txtFind").value.toUpperCase(), tr=document.getElementById("myTable").getElementsByTagName("tr"),td, i,nos=0,ttl=0;
	var a=(document.getElementById("radImpNo").checked?0:(document.getElementById("radIDNo").checked?1:2)); // impreset such criteria
	for(i=2;i<(tr.length-1);i++){td=tr[i].getElementsByTagName("td")[a];if (td){
		if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display="";nos++;var amt=Number(tr[i].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9^\.]/,'')); ttl+=isNaN(amt)?0:amt;}
		else tr[i].style.display="none";}
	}document.getElementById("spTotal").innerHTML=addCommas(ttl.toFixed(2));document.getElementById("spNoImp").innerHTML=nos+' Imprest Record(s).';
}function clrText(){	document.getElementById("txtFind").value='';	document.getElementById("txtFind").focus();}
function addCommas(nStr){nStr+=''; var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}
