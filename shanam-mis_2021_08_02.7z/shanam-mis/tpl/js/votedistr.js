function myFunction(){var input=document.getElementById("txtFind").value.toUpperCase(); var tr=document.getElementById("tblStud").getElementsByTagName("tr"),td;
  var a=(document.getElementById("radAdmNo").checked?1:(document.getElementById("radNEMISNo").checked?2:3));
  for(var i=1;i<tr.length;i++){td=tr[i].getElementsByTagName("td")[a];
    if (td){if(a==0){if(parseInt(td.innerHTML.trim())===parseInt(input) || input.length==0) tr[i].style.display=""; else tr[i].style.display="none"; //find by adm no
    }else{if(td.innerHTML.toUpperCase().indexOf(input)>-1 || input.length==0) tr[i].style.display=""; else tr[i].style.display="none";}}
  }
}function clrText(){document.getElementById("txtFind").value='';  document.getElementById("txtFind").focus();}
