function myFunction(){
	var input, table, tr,td, i,noi=0;;
	var a=(document.getElementById("radNo").checked?1:(document.getElementById("radName").checked?2:(document.getElementById("radCateg").checked?3:4))); // salary definition
	input=document.getElementById("txtFind").value.toUpperCase();
	table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
	for(i=2;i<tr.length;i++){
		td=tr[i].getElementsByTagName("td")[a];
		if (td){
			if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){ tr[i].style.display=""; noi++; tr[i].getElementsByTagName("td")[0].innerHTML=noi;}
			else tr[i].style.display="none";
		}
	}document.getElementById("spNoI").innerHTML=noi+" Item and Services Record(s).";		
}
function clrText(){
	document.getElementById("txtFind").value='';
	document.getElementById("txtFind").focus();
}