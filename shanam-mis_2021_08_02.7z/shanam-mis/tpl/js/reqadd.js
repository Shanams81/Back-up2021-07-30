function Votes(vno,vacc,vname){this.vno=vno; this.vacc=vacc; this.vname=vname;} var votes=[];
function showVotes(ac){
  clrCbo();
  let acno=Number(ac.value),i=0,l=votes.length,htmlSelect=document.querySelector("#cboVote"),selectBoxOption; acno=isNaN(acno)?0:acno;
  selectBoxOption = document.createElement("option");
  selectBoxOption.value = 0;
  selectBoxOption.text = "Select Votehead";
  htmlSelect.add(selectBoxOption);
  if(acno>0){
    while(i<l){
      if(acno==votes[i].vacc){
        selectBoxOption = document.createElement("option");
    		selectBoxOption.value = votes[i].vno;
    		selectBoxOption.text = votes[i].vname;
    		htmlSelect.add(selectBoxOption);
      }i++;
    }
  }
}
function clrCbo(){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox=document.querySelector("#cboVote");
	if(mylistbox==null) return;
	while(mylistbox.length>0) mylistbox.remove(0);
}
function validateFormOnSubmit(theForm) {
    var reason = "";
    if(Number(document.querySelector("#cboDept").value)==0){
      reason+="Select the Department Requisitioning\n"+document.querySelector("#cboDept").value;
      document.querySelector("#cboDept").style.background='Yellow';
    }if(Number(document.querySelector("#cboAC").value)==0){
      reason+="Select the votehead account to be costed\n";
      document.querySelector("#cboAC").style.background='Yellow';
    }
    reason+=validateNo(theForm.cboStf); reason+=validateUsername(theForm.txtRmks);
    if(Number(document.querySelector("#cboItem").value)==0){
        reason+=validateUsername(theForm.txtItem);
        reason+=validateUsername(theForm.cboCateg);
        reason+=validateNo(theForm.txtMax);  reason+=validateNo(theForm.txtMin);
        if(Number(document.querySelector("#cboVote").value)==0){
          reason+="Select the votehead to be costed\n";
          document.querySelector("#cboDept").style.background='Yellow';
        }
    }
    reason += validateNo(theForm.txtQty);   reason += validateNo(theForm.txtUP);
    if (reason != "") {
        alert("The fields in yellow need correction:\n" + reason);
        return false;
    } else {
        return true;
    }
}
function validateUsername(fld) {
    var error = "";
    var txt=fld.value.replace(/[^0-9a-z\ \,\.]/gi,'');
    if (txt.length===0) {
        fld.style.background = 'Yellow';
        error = "You didn't enter the item desccription of the budget.\n";
    } else if (txt.length<4) {
        fld.style.background = 'Yellow';
        error = "The information is too short.\n";
    } else {
        fld.style.background = 'White';
    }
    return error;
}
function validateNo(fld) {
    var error = "";
    var no=Number(fld.value.replace(/[^0-9\.]/g, ''));
    if (no.length===0) {
        error = "Enter quantity and unit price before saving.\n";
        fld.style.background = 'Yellow';
    }else if (isNaN(no)) {
        error = "Enter quantity and unit price MUST be greater that zero (0).\n";
        fld.style.background = 'Yellow';
    }
    return error;
}
function showNewItem(opt){
   if(Number(opt.value)==0){
        document.querySelector('#divNewItem').style.display='block';
    }else{document.querySelector('#divNewItem').style.display='none';}
}
function addCommas(nStr){
    nStr+='';
    let i=nStr.indexOf('.'); if(i===-1) nStr+='.00';
    var x=nStr.split('.');
    var x1=x[0];
    var x2=x.length>1?('.'+x[1]):'';
    var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
    return x1+x2;
}
function checkInput(ob){
    var invalidChars=/[^0-9\.]/gi;
    var a=ob.value.replace(invalidChars,"");
    if (a.length===0){
        ob.value="0.00";
    }else{ob.value=a;}
}
function calcAmt(){
    var up=0,qty=0;
    up=Number(document.querySelector('#txtUP').value.replace(/[^0-9\.]/g,''));     up=isNaN(up)?0:up;
    document.querySelector('#txtUP').value=addCommas(up.toFixed(2));
    qty=Number(document.querySelector('#txtQty').value.replace(/[^0-9\.]/g,''));   qty=isNaN(qty)?0:qty;
    document.querySelector('#txtQty').value=addCommas(qty.toFixed(2));
    document.querySelector('#txtTtl').value=addCommas((up*qty).toFixed(2));
}
function loadItems(cbo,reqno){
	var dept=parseInt(cbo.value.replace(/[^0-9]/g,''));    dept=isNaN(dept)?0:dept;
	if(dept>0){
		var nocache = Math.random() * 10000; //stop caching
		if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
        } else {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
        }xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200){
      			 	document.querySelector("#divItems").innerHTML=this.responseText;
              let itm=Number(document.querySelector("#divItems").value);
              if(itm==0){document.querySelector('#divNewItem').style.display='block';}
              else{document.querySelector('#divNewItem').style.display='none';}
      			}
        }; xmlhttp.open('GET','ajax/showitem.php?q=0-'+dept+'-'+reqno+'-'+nocache,true); xmlhttp.send();
	}else{
		alert('You MUST select the Department raising requisition');
    cbo.focus();
	}
}
