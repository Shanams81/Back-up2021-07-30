function canview(pr){if(pr==0){alert("Sorry, you do not have the priviledges to perform this administrative task (Edit)");return false;} else	return true;}
function canedit(pr,sn){if(pr==0){alert("Sorry, you do not have the priviledges to perform this administrative task (Edit)");return false;}else{findGrps(sn); return true;}}
function candel(pr){if(pr==0){alert("Sorry, you do not have the priviledge to perform this administrative task (Delete).");return false;}
  else{if(confirm("Are you sure you want to delete this group?\nClick OK to delete otherwise click Cancel.")) return true; else	return false;}
}function showNew(){
  document.querySelector('#divGrpEdit').style.display='block'; document.querySelector('#txtAction').value='0-0';   document.querySelector('#txtStf').value='';
  document.querySelector('#txtStudGrp').value=''; document.querySelector('#txtFGrp').value=''; document.querySelector('#txtStrm').value=''; document.querySelector('#txtPP').value='';
  document.querySelector('#txtBranch').value='';  document.querySelector('#txtCateg').value='';document.querySelector('#txtCore').value='';
}function validateFormOnSubmit(theForm) {
	var reason = "";
	if ((theForm.txtStf.value.length==0) && (theForm.txtStrm.value==0) && (theForm.txtPP.value==0) && (theForm.txtBranch.value==0) && (theForm.txtStudGrp.value==0) &&
	(theForm.txtCore.value==0) && (theForm.txtCateg.value==0)){
		reason+="No Data entered. Please enter either staff or student group, stream, class, paypoint, branch, item category or core value before saving\n";
		theForm.txtStf.style.background='Yellow'; theForm.txtStrm.style.background='Yellow';	theForm.txtPP.style.background='Yellow';	theForm.txtBranch.style.background='Yellow';
		theForm.txtCore.style.background='Yellow'; theForm.txtCateg.style.background='Yellow';
	}else{if (theForm.txtStf.value.length>0){reason += validateUsername(theForm.txtStf);} if (theForm.txtStrm.value.length>0){reason += validateUsername(theForm.txtStrm);}
  	if (theForm.txtStudGrp.value.length>0){reason += validateUsername(theForm.txtStudGrp);} if (theForm.txtPP.value.length>0){reason += validateUsername(theForm.txtPP);}
  	if (theForm.txtBranch.value.length>0){reason += validateUsername(theForm.txtBranch);} if (theForm.txtCore.value.length>0){reason += validateUsername(theForm.txtCore);}
  	if (theForm.txtCateg.value.length>0){reason += validateUsername(theForm.txtCateg);}
	}	if (reason.length>0){alert("These fields need correction:\n" + reason);return false;} else return true;
}function validateUsername(fld){var error = "",illegalChars = /\d/; // allow letters, numbers, and underscores
	if (illegalChars.test(fld.value)){fld.style.background = 'Yellow';error = "The information contains illegal characters.\n";} else fld.style.background = 'White'; return error;
}function Grps(sn,stf,strm,pp,bb,cv,cat,stud){this.sn=sn; this.stf=stf; this.strm=strm; this.stud=stud;this.pp=pp; this.bb=bb; this.cv=cv;this.cat=cat;} var grps=[];
function findGrps(gn){let found=false,l=grps.length,i=0;
  while(!found && i<l){if(grps[i].sn===gn){found=true;document.querySelector('#txtAction').value='1-'+gn;document.querySelector('#txtStf').value=grps[i].stf;
      document.querySelector('#txtStudGrp').value=grps[i].stud; document.querySelector('#txtCore').value=grps[i].cv;document.querySelector('#txtStrm').value=grps[i].strm;
      document.querySelector('#txtPP').value=grps[i].pp;document.querySelector('#txtBranch').value=grps[i].bb;      document.querySelector('#txtCateg').value=grps[i].cat;
    }i++;
  }if(found){document.querySelector('#divGrpEdit').style.display='block';}
}function validateTermData(frm){let t1a=frm.txtAbbr_0.value.toLowerCase(),t1d=frm.txtDescr_0.value.toLowerCase(),t2a=frm.txtAbbr_1.value.toLowerCase(),t2d=frm.txtDescr_1.value.toLowerCase();
  let t3a=frm.txtAbbr_2.value.toLowerCase(),t3d=frm.txtDescr_2.value.toLowerCase(), err='';
  const t1s=new Date(frm.txtStart_0.value.trim()),t1e=new Date(frm.txtEnd_0.value.trim()),t2s=new Date(frm.txtStart_1.value.trim()),t2e=new Date(frm.txtEnd_1.value.trim());
  const t3s=new Date(frm.txtStart_2.value.trim()),t3e=new Date(frm.txtEnd_2.value.trim());
  if(t1a===t2a || t1a===t3a || t2a===t3a || t1d===t2d || t1d===t3d || t2d===t3d) err='Terms\' short and full names should not be the same.';
  if((t2s.getTime()<=t1e.getTime() && t2s.getTime()>=t1s.getTime())||(t3s.getTime()<=t2e.getTime() && t3s.getTime()>=t2s.getTime()) || t1s>t1e || t2s>t2e || t3s>t3e)
    err+='\nThe terms\' start and end dates should be of valid range';
  if(err.length>0){alert('ERRORS TO BE CORRECTED:\n'+err); return false;}else return true;
}function chkValues(txt){let v=txt.value.replace(/[^a-z0-9\&\ ]/gi,''); txt.value=v.toUpperCase();}
function showGRP(row,sno,priv){if(priv===0){alert("Sorry, you DO NOT have the priviledge to edit fees group details");}
  else{document.querySelector("#txtFGSNo").value=sno; document.querySelector("#txtFGAct").value=1; let td=document.querySelector("#tblFG").getElementsByTagName("tr")[row].getElementsByTagName("td");
    if(td){document.querySelector("#txtFGAbbr").value=td[1].innerHTML.toUpperCase(); document.querySelector("#txtFGDescr").value=td[2].innerHTML.toUpperCase();}}
}function validateFeeGrp(frm){
  let err=""; if(frm.txtFGAbbr.value.length<3){err+="Fee group abbreviation is too short.\n"; frm.txtFGAbbr.style.background='Yellow';}
  if(frm.txtFGDescr.value.length<5){err+="Fee group description is too short.\n"; frm.txtFGDescr.style.background='Yellow';}
  if(err.length>0){alert("The following error(s) MUST be corrected before saving\n"+err); return false;} else return true;
}
