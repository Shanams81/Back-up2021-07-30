function Votes(sno,ac,descr,bal){this.sno=sno; this.ac=ac; this.descr=descr; this.bal=bal;} var votes=[];
function BankACs(sno,ac,bank,bal){this.sno=sno; this.ac=ac; this.bank=bank; this.bal=bal;} var bankacs=[];
function addCommas(nStr){
	nStr+=''; if(nStr.indexOf('.')<0) nStr+='.00'; let x=nStr.split('.');x1=x[0],x2=x.length>1?('.'+x[1]):'',rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');} return x1+x2;
}function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/g;
	if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,""); ob.value=addCommas(a);}
	if (ob.length==0) ob.value="0.00";
}function loadBank(cbo,ch){
  let ac=Number(cbo.value),nor=0,c=0; ac=isNaN(ac)?0:ac;
	clrCont(document.querySelector(ch==0?"#cboSourceAC":"#cboDestAC"),0); for (index=0;index<4;index++) clrCont(document.querySelector(ch==0?"#cboVote_"+index:"#cboVote1_"+index),1);
  if(ac>0){ nor=bankacs.length;
  	while(c<nor){if(bankacs[c].ac==ac){
			addVote(document.querySelector(ch==0?"#cboSourceAC":"#cboDestAC"),bankacs[c].sno,bankacs[c].bank);
		}c++;} 	nor=votes.length; c=0;
  	while(c<nor){if(votes[c].ac==ac){
			addVote(document.querySelector(ch==0?"#cboVote_0":"#cboVote1_0"),votes[c].sno,votes[c].descr); addVote(document.querySelector(ch==0?"#cboVote_1":"#cboVote1_1"),votes[c].sno,votes[c].descr);
			addVote(document.querySelector(ch==0?"#cboVote_2":"#cboVote1_2"),votes[c].sno,votes[c].descr); addVote(document.querySelector(ch==0?"#cboVote_3":"#cboVote1_3"),votes[c].sno,votes[c].descr);
		}c++;}
  }
}function clrCont(listboxID,opt){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	if(listboxID!=null) while(listboxID.length > 0) listboxID.remove(0);
  addVote(listboxID,0,(opt==0?"CHOOSE BANK ACCOUNT":"CHOOSE VOTEHEAD")); listboxID.value=0;
	return 1;
}function addVote(listboxID,val,txt){
	var selectBoxOption = document.createElement("option");
	selectBoxOption.value = val;	selectBoxOption.text = txt; listboxID.add(selectBoxOption);
}function bankBal(cbo,ch){
	let acsno=parseInt((cbo.value)); acsno=isNaN(acsno)?0:acsno;
	if (acsno>0){	let found=false,nob=bankacs.length,c=0;
		while (!found && c<nob){if(bankacs[c].sno==acsno){document.querySelector(ch==0?"#txtSourceBal":"#txtDestBal").value=addCommas(bankacs[c].bal); found=true;}c++;}
	}else{document.querySelector(ch==0?"#txtSourceBal":"#txtDestBal").value="0.00";}
}function fmtValue(txt){
	let val=Number(txt.value.replace(/[^0-9\.]/g,'')),acbal=Number(document.querySelector("#txtSourceBal").value.replace(/[^0-9\.]/g,'')); val=isNaN(val)?0:val; acbal=isNaN(acbal)?0:acbal;
	if(val==0){alert("Sorry, You can not borrow zero shillings."); txt.focus();
	}else if(val>acbal){alert("Sorry, you can not borrow more than account balance.\nAmount borrowed has been reset to zero."); txt.value="0.00"; txt.focus();
	}else{txt.value=document.querySelector("#txtDRBal").value=document.querySelector("#txtCRBal").value=addCommas(val);}
}function distrValue(txt,pos,ch){
	let ttl=amt=0,npos=pos+1,val=Number(document.querySelector("#txtAmt").value.replace(/[^0-9\.]/g,'')),vbal=Number(document.querySelector("#txtVBal_"+pos).value.replace(/[^0-9\.]/g,''));
	let curramt=Number(document.querySelector(ch==0?"#txtAmt_"+pos:"#txtAmt1_"+pos).value.replace(/[^0-9\.]/g,''));	val=isNaN(val)?0:val; vbal=isNaN(vbal)?0:vbal;
	if(curramt>vbal && curramt>0){ alert('The sum of Kshs. '+addCommas(curramt)+' is higher than votehead balance of Kshs. '+addCommas(vbal)+'.\nCurrent balance has been set as amount.');
		curramt=(vbal>0?vbal:0);	document.querySelector("#txtAmt_"+pos).value=addCommas(curramt);
	}for(i=0;i<=pos;i++){amt=Number(document.querySelector(ch==0?"#txtAmt_"+i:"#txtAmt1_"+i).value.replace(/[^0-9\.]/g,'')); 	amt=isNaN(amt)?0:amt; ttl+=amt;}
	let ttlbal=val-ttl;
	if(curramt>0){
		if(ttlbal==curramt){let npos=pos+1; document.querySelector(ch==0?"#txtAmt_"+npos:"#txtAmt1_"+npos).readOnly=true;
			for(i=npos;i<4;i++){document.querySelector(ch==0?"#cboVote_"+i:"#cboVote1_"+i).value=0; document.querySelector(ch==0?"#txtAmt_"+i:"#txtAmt1_"+i).value="0.00";}
		}else if(ttl>val){alert("The sum of Kshs. "+addCommas(curramt)+" distributed is higher than balance of KShs. "+addCommas(ttlbal)+" borrowed.\nCurrent Votehead amount has been reset to zero.\n");
			ttl-=curramt; ttlbal-=curramt;	document.querySelector(ch==0?"#txtAmt_"+pos:"#txtAmt1_"+pos).value="0.00";
		}else{document.querySelector(ch==0?"#cboVote_"+npos:"#cboVote1_"+npos).disabled=false; document.querySelector(ch==0?"#txtAmt_"+npos:"#txtAmt1_"+npos).value="0.00";}
		document.querySelector(ch==0?"#txtDRDistr":"#txtCRDistr").value=addCommas(ttl); 	document.querySelector(ch==0?"#txtDRBal":"#txtCRBal").value=addCommas(ttlbal);
	}
}function enableAmt(ch,pos){
	document.querySelector(ch==0?"#txtAmt_"+pos:"#txtAmt1_"+pos).readOnly=false;	document.querySelector(ch==0?"#txtAmt_"+pos:"#txtAmt1_"+pos).disabled=false;
	document.querySelector(ch==0?"#txtAmt_"+pos:"#txtAmt1_"+pos).focus();
	if (ch==0){//find votehead balance
		let vno=document.querySelector("#cboVote_"+pos).value; votes.forEach(function(value){if(value.sno==vno){document.querySelector("#txtVBal_"+pos).value=addCommas(value.bal);return;}});
	}
}function validateFormOnSubmit(frm){
	let err='',amt=Number(frm.txtAmt.value.replace(/[^0-9\.]/g,'')),dbal=Number(frm.txtDRBal.value.replace(/[^0-9\.]/g,'')),cbal=Number(frm.txtCRBal.value.replace(/[^0-9\.]/g,''));
	if(parseInt((frm.cboACDebit.value))==0 || parseInt((frm.cboACCredit.value))==0){err+="Ensure you select Votehead A/C debited and credited\n";
		if(parseInt((frm.cboACDebit.value))==0) frm.cboACDebit.style.background='Yellow'; if(parseInt((frm.cboACCredit.value))==0) frm.cboACCredit.style.background='Yellow';
	}if(parseInt((frm.cboACDebit.value))==parseInt((frm.cboACCredit.value))){	err+="Ensure votehead A/C credited and Debited are not similar.\n";
		frm.cboACDebit.style.background='Yellow'; frm.cboACCredit.style.background='Yellow';
	}if(parseInt((frm.cboSourceAC.value))==0 || parseInt((frm.cboDestAC.value))==0){err+="Ensure you select Bank A/C debited and credited\n";
		if(parseInt((frm.cboSourceAC.value))==0) frm.cboSourceAC.style.background='Yellow'; if(parseInt((frm.cboDestAC.value))==0) frm.cboDestAC.style.background='Yellow';
	}if(parseInt((frm.cboSourceAC.value))==parseInt((frm.cboDestAC.value))){err+="Ensure the Bank A/C debited and credited are not similar\n";
		if(parseInt((frm.cboSourceAC.value))==0) frm.cboSourceAC.style.background='Yellow'; if(parseInt((frm.cboDestAC.value))==0) frm.cboDestAC.style.background='Yellow';
	}if(cbal!=0 || dbal!=0){err+="Ensure amount borrowed has been distributed to voteheads in both Credited and Debited Votehead A/C\n";
	}if(amt<1000){err+="Amount Transfered MUST be higher than Kshs. 1,000.00\n"; frm.txtAmt.style.background='Yellow';
	}if(frm.txtModeNo.value.length<4){err+="Cheque/ Transaction No. must be valid\n"; frm.txtModeNo.style.background='Yellow';
	}if(err.length>0){alert('ERROR(S) TO BE CORRECTED BEFORE SAVING\n'+err); return false;
	}else{for(var i=0;i<4;i++){document.querySelector("#txtAmt_"+i).disabled=false;	document.querySelector("#txtAmt1_"+i).disabled=false;
		document.querySelector("#cboVote_"+i).disabled=false;	document.querySelector("#cboVote1_"+i).disabled=false;}return true;}
}
