function validateFormOnSubmit(theForm) {
		var reason = "";
		var i=Number(theForm.txtTotal.value.replace(/[^0-9\.]/g,"")); 	i=isNaN(i)?0:i;
		if (i==0){
		 	theForm.txtCash.style.background='Yellow';	theForm.txtCheque.style.background='Yellow';
			reason+="You MUST enter the cash and/or Cheque amount being spend before saving.\n";
		}else{
			theForm.txtCash.style.background='White';		theForm.txtCheque.style.background='White';
		}
		var amt=parseFloat(theForm.txtOrig.value.replace(/[^0-9\.]/g,"")); 	amt=isNaN(amt)?0:amt;
		if(i>amt){
			theForm.txtCash.style.background='Yellow';	theForm.txtCheque.style.background='Yellow';
			reason+="You can not the amount "+addCommas(i)+" is higher than "+addCommas(amt)+" refundable fee.\n";
			theForm.txtCash.value=theForm.txtCheque.value="0.00";
		}
		i=parseFloat(theForm.txtBalAmt.value.replace(/[^0-9\.]/g,"")); 			i=isNaN(i)?0:i;
		if (i!=0){
		 	theForm.txtAmt_0.style.background='Yellow';
			reason+="Ensure the you have correctly distributed the amount to respective voteheads before saving\n";
		}else{theForm.txtAmt_0.style.background='White';}
  	reason+=validateNo(theForm.txtIDNo);	reason+=validateUsername(theForm.txtPayee);
  	i=theForm.txtCheNo.value.trim();
  	var frm=theForm.cboMode.value.trim();
		if ((frm.toLowerCase()!=="cash") && (i.length==0)) {
			reason+="You MUST enter cheque number for this refund payment before saving\n";
			theForm.txtCheNo.style.background='Yellow';
		}var bank=Number(theForm.cboBank.value);	bank=isNaN(bank)?0:bank;
		if ((frm.toLowerCase()!=="cash") && bank===0) {
			reason+="You MUST Select bank A/C on which the cheque is debited before saving\n";
			theForm.cboBank.style.background='Yellow';
		}	if (i.length>0) reason += validateNo(theForm.txtCheNo);
	  i=theForm.txtAddress.value;
	  if (i.length<10){
		   reason+="Enter valid postal address of the payee for this pettycash payment\n";
		   theForm.txtAddress.style.background='Yellow';
		}
  	i=theForm.txtRmks.value.trim();
  	if (i.toUpperCase()=="BEING PAYMENT FOR " || i.length<20){
		   reason+="Enter valid reason/remarks for the refund payment\n";
		   theForm.txtRmks.style.background='Yellow';
		}else{reason += validateUsername(theForm.txtRmks);}
		if (reason!="") {
    	alert("Some fields need correction before saving:\n" + reason);
    	return false;
  	} else {theForm.cboBank.disabled=false; return true;}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /[^a-zA-Z0-9\.\ \,]/g; // allow letters, numbers, and underscores
	var rmks=fld.value.trim().replace(illegalChars,'');
	fld.value=rmks;
	if (rmks.length<10) {
    	fld.style.background = 'Yellow';
    	error = "You MUST have a valid payee or reason for refund.\n";
	} else {
    	fld.style.background = 'White';
	}
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[^0-9\.]/g, '');
	if (fld.value == "") {
    	error = "You have no entered information required in " + fld.name + ".\n";
    	fld.style.background = 'Yellow';
	} else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {
    	error = "Enter valid value in " + fld.name + ".\n";
    	fld.style.background = 'Yellow';
	}
	return error;
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){ob.value="0.00";}
}
function findIDNo(txt){
	var  idno=txt.value.replace(/[^0-9]/g,''); 	txt.value=idno;
	var nocache = Math.random() * 10000; //stop caching
	if(idno.length>4){
			if (window.XMLHttpRequest) {
          xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
      } else {
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
      }xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200){
			 	var n=this.responseText; n=n.toUpperCase();
				if (n!='0-0-0'){
				 	n=n.split(/\-/g); document.getElementById("txtPayee").readOnly=true; 	document.getElementById("txtPayee").value=n[0];
					document.getElementById("txtTelNo").readOnly=true;		document.getElementById("txtTelNo").value=n[1];
					document.getElementById("txtAddress").readOnly=true; 	document.getElementById("txtAddress").value=n[2];
				}else{
					document.getElementById("txtPayee").readOnly=false;		document.getElementById("txtTelNo").readOnly=false;
					document.getElementById("txtAddress").readOnly=false; 
				}
			}
    };
    xmlhttp.open('GET','ajax/showBursBal.php?q=2-'+idno+'-'+nocache,true); xmlhttp.send();
	}
}
function sumPaid(){
 	var sum=0;
 	var n=Number(document.getElementById("txtCash").value.trim().replace(/[^0-9\.]/g,''));
 	if (!(isNaN(n))) sum+=n;
	n=Number(document.getElementById("txtCheque").value.trim().replace(/[^0-9\.]/g,''));
 	if (!(isNaN(n))) sum+=n;
	n=Number(document.getElementById("txtOrig").value.trim().replace(/[^0-9\.]/g,''));
	if(sum>n){
		alert('You can not pay more than refundable amount.\nZero has been set in amounts.');
		document.getElementById("txtTotal").value=document.getElementById("txtCash").value=document.getElementById("txtAmt_0").value=0;
		document.getElementById("txtTtlAmt").value=document.getElementById("txtCheque").value=document.getElementById("txtBalAmt").value="0.00";
		return;
	}
	document.getElementById("txtAmt_0").value=document.getElementById("txtTtlAmt").value=document.getElementById("txtTotal").value=addCommas(sum.toFixed(2));
}
function confirmAmt(txt){
 	var amt=0;
	var x=Number(document.getElementById("txtTotal").value.trim().replace(/[^0-9\.]/g,''));
 	if (!(isNaN(x))) x=0;	//finding balance yet to be distributed
	var amt=Number(txt.trim().replace(/[^0-9\.]/g,'')); if (!(isNaN(amt))) amt=0; amt=x-amt;
	document.getElementById("txtBalAmt").value=addCommas(amt.toFixed(2));
 	document.getElementById("txtTtlAmt").value=addCommas(x.toFixed(2));
}
function activateCashCheque(cbo){
	var m=cbo.value.trim().toLowerCase();
	if(m==='cash'){
			document.getElementById("txtCheNo").readOnly=document.getElementById("txtCheque").readOnly=true;
			document.getElementById("txtCash").readOnly=false;	document.getElementById("txtCheque").value="0.00";
			document.getElementById("cboBank").value="0";				document.getElementById("cboBank").disabled=true;
	}else{
			document.getElementById("txtCheNo").readOnly=document.getElementById("txtCheque").readOnly=false;
			document.getElementById("txtCash").readOnly=true;		document.getElementById("txtCash").value="0.00";
			document.getElementById("cboBank").disabled=false;
	}	sumPaid();
}
