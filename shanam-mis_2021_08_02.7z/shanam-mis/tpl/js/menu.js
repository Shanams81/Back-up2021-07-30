function img_focus(obj){
 	obj.style.width='150px';
	obj.style.height='130px';
}
function img_blur(obj){
 	obj.style.width='120px';
	obj.style.height='100px';
}
function canvi(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to view record");
    	return false;
  	} else {
  		return true;
  	}
}