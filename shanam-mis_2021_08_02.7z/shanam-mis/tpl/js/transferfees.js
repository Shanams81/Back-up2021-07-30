function Accounts(sn,name){this.sn=sn; this.name=name;} var account=[];
function connect(){if (window.XMLHttpRequest) return new XMLHttpRequest(); else return new ActiveXObject("Microsoft.XMLHTTP");}
function enableRecNo(opt){if(opt==0){let ac=parseInt(document.querySelector("#cboAC").value); if(ac>0){document.querySelector("#txtReceiptNo").readOnly=false;document.querySelector("#cboAC").style.background='White';}
  else {document.querySelector("#txtReceiptNo").readOnly=true; alert('Select Fee A/C affected in this transfer.');document.querySelector("#cboAC").style.background='Yellow';}}
  else{}
}function findStud(obj,no){var val=obj.value,nocache=Math.random()*10000;
  if (no==1 || no==3){let adno=document.querySelector(no==1?"#spAdmNo":"#spAdmNo1").innerHTML.trim(); if (val!=adno){alert("Sorry, the Adm. No. "+val+" is not the one who paid the fees."+adno); obj.value=''; obj.focus(); return;}
  document.querySelector("#divNames_1").innerHTML="No Student has Adm. No. "+val;} else{document.querySelector("#divNames_2").innerHTML="No Student has Adm. No. "+val;}
  if(val.length>0){var xmlhttp=connect();
    xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200){document.querySelector(no==1?"#divNames_1":(no==2?"#divNames_2":"#divNames_3")).innerHTML=this.responseText;}};
    xmlhttp.open('GET','ajax/returnstuddetails.php?q=0-'+val+'-'+nocache,true);		xmlhttp.send();
  }
}function findReceipt(opt,txt){var rec=parseInt(txt.value),nocache=(Math.random()*1000000),acc=0; if(opt==0) acc=parseInt(document.querySelector("#cboAC").value); else acc=parseInt(document.querySelector("#cboACDebit1").value);
  if (rec>0 && acc>0){ var xmlhttp=connect();
    xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200){let ans=this.responseText.split('~'),disp="";
      if(parseInt(ans[0]==0)){disp="NO FEES HAS BEEN PAID ON RECEIPT NO. "+rec;} else {let dt=new Date(ans[1]); disp="RECEIPT PAID ON "+dt.toDateString().toUpperCase()+", MODE: "+ans[2]+" MODE NO. "+ans[3];}
      disp+="<span id=\""+(opt==0?"spAdmNo":"spAdmNo1")+"\" style=\"display:none;\">"+ans[0]+"</span><BR><table class=\"table table-sm table-hover table-bordered\" id=\""+(opt==0?"tblStudTransfer":"tblACTransfer")+"\"><thead "+
      "class=\"thead-light\"><tr><th>FEES</th><th>PREPAID</th><th>ARREARS</th><th>REFUNDS</th><th>MEDICAL</th><th>UNIFORM</th><th>TOTAL</th></tr></thead><tbody><tr><td class=\"numbersinput\">"+addCommas(ans[4])+"</td><td "+
      "class=\"numbersinput\">"+addCommas(ans[8])+"</td><td class=\"numbersinput\">"+addCommas(ans[5])+"</td><td class=\"numbersinput\">"+addCommas(ans[9])+"</td><td class=\"numbersinput\">"+addCommas(ans[6])+"</td><td "+
      "class=\"numbersinput\">"+addCommas(ans[7])+"</td><td class=\"numbersinput\">"+addCommas(ans[10])+"</td></tr></tbody></table>";  document.querySelector(opt===0?"#divRecDetails":"#divTableFee").innerHTML=disp;
      if(opt==0){document.querySelector("#txtAmt").value=addCommas(ans[10]); document.querySelector("#chkRefunds").checked=true;}
      if(parseInt(ans[11])>0) alert("This fees was paid by bursary.\nNote: Transferring it implies change of busary beneficiary.");
      if(parseFloat(ans[9])>0) alert("This fees has refundable amount.\nNote: Transferring it implies change of refund amount.");
		}}; xmlhttp.open('GET','ajax/returnstuddetails.php?q=1-'+rec+'-'+acc+'-'+nocache,true);		xmlhttp.send();
  }else{alert('Ensure you enter correct Receipt No. and select Fees A/C');}
}function showAcDebit(cbo){clrACs(); let ac=parseInt(cbo.value),a=0; addItem(0,'Choose A/C'); if(ac>0){do{if(ac!=account[a].sn){addItem(account[a].sn,account[a].name);} a++;}while(a<account.length);
  document.getElementById("txtRecNoDebit1").readOnly=false;}
}function clrACs(){var cbo=document.getElementById("cboACCredit1");	if(cbo==null) return;  while(cbo.length>0) cbo.remove(0);	return;}
function addItem(val,txt){var cbo=document.getElementById("cboACCredit1"),optSelect=document.createElement("option");	optSelect.value=val; optSelect.text=txt;	cbo.add(optSelect);}
function confirmAmt(opt,txt){let recamt=parseFloat(document.querySelector(opt==0?"#tblStudTransfer":"#tblACTransfer").getElementsByTagName("tr")[1].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9\.]/g,''));
  let amt=parseFloat(txt.value.replace(/[^0-9\.]/g,'')); if(amt>recamt || isNaN(amt) || isNaN(recamt)){alert("Ensure valid Amount being transfered is entered."); txt.value=0;txt.focus();}
}function setAmt(){let td=document.querySelector("#tblStudTransfer").getElementsByTagName("tr")[1].getElementsByTagName("td");
  let ty=parseInt(document.getElementById("cboType").value),recamt=parseFloat(document.querySelector("#spAmt").innerHTML.replace(/[^0-9\.]/g,''));
	if (ty==1){document.getElementById("txtAmt").readOnly=true;	document.getElementById("txtAmt").style.background='lime';document.getElementById("txtAmt").value=addCommas(recamt);
	}else{document.getElementById("txtAmt").readOnly=false;	document.getElementById("txtAmt").style.background='White';	document.getElementById("txtAmt").value=0.00;}
}function validData(frm,opt){let msg="",oamt=parseFloat(document.querySelector(opt==0?"#tblStudTransfer":"#tblACTransfer").getElementsByTagName("tr")[1].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9\.]/g,''));
  let amt=parseFloat(document.querySelector(opt==0?"#txtAmt":"#txtCredAmt1").value.replace(/[^0-9\.]/g,''));
  if(amt>oamt && amt<=0){msg+="You can not transfer more than receipt amount of Kshs. "+addCommas(oamt)+". Fee amount has been set.\n";document.querySelector(opt==0?"#txtAmt":"#txtCredAmt1").value=addCommas(oamt); amt=oamt;}
  if(opt===0){if(frm.txtRmks.value.length<15){msg+="You MUST type a valid reason for the transfer\n";	frm.txtRmks.style.background='Yellow';}
  	if(frm.txtReceiptNo.value.length==0){msg+="You MUST type a receipt number to be transfered\n";	frm.txtReceiptNo.style.background='Yellow';}
  	if(parseInt(frm.cboType.value)==2 && amt<1){
  		msg+="You MUST enter the amount to be transfered to "+frm.txtNames_2.value+"\n";	frm.txtAmt.style.background='Yellow'; frm.txtAmt.readOnly=false;
  	}if(frm.txtSourceAdmNo.value.length==0 ){msg+="You MUST type the admission number from which the fee record is transfered\n"; frm.txtSourceAdmNo.style.background='Yellow';
    }else if(frm.txtNames_1.value.toLowerCase().indexOf("student")>0){
      msg+="There is no student with the Adm. No. "+frm.txtSourceAdmNo.value+"\n";	frm.txtSourceAdmNo.style.background='Yellow';
    }if(frm.txtDestAdmNo.value.length==0){msg+="You MUST type the admission number to which the fee record is transfered\n";	frm.txtDestAdmNo.style.background='Yellow';
    }else if(frm.txtNames_2.value.toLowerCase().indexOf("student")>0){ msg+="There is no student with the Adm. No. "+frm.txtDestAdmNo.value+"\n";	frm.txtDestAdmNo.style.background='Yellow';
    }if (frm.txtSourceAdmNo.value==frm.txtDestAdmNo.value){	msg+="You can not transfer fees to the same student\n";	frm.txtSourceAdmNo.style.background='Yellow';	frm.txtDestAdmNo.style.background='Yellow';
    }else{frm.txtSourceAdmNo.style.background='White';	frm.txtDestAdmNo.style.background='White';	}
  }else{if(frm.txtRecNoDebit1.value.length<1){msg+="Enter Receipt No. to be transferred\n"; frm.txtRecNoDebit1.style.background='Yellow';}else frm.txtRecNoDebit1.style.background='White';
    if(parseInt(frm.cboACDebit1.value)){msg+="Select the Fee A/C debited in the transfer\n"; frm.cboACDebit1.style.background='Yellow';}else frm.cboACDebit1.style.background='White';
    if(parseInt(frm.cboACCredit1.value)){msg+="Select the Fee A/C credited in the transfer\n"; frm.txtRecNoDebit1.style.background='Yellow';}else frm.cboACCredit1.style.background='White';
    let bal=parseFloat(document.querySelector("#txtAcBal1").value.replace(/[^0-9\.]/g,''));
    if(parseInt(frm.cboACCredit1.value)!=1 && bal<amt){msg+="Sorry, you can not transfer amount higher than A/C balance. Balance has been set.\n"; document.querySelector("#txtCredAmt1").value=addCommas(bal);}
    if(frm.txtRmks1.value.length<15){msg+="The narration is too short and therefore invalid.\n";  frm.txtRmks1.style.background='Yellow';}
  }
	if (msg==""){	var con=confirm("You're about to transfer fees to another student.\nAre you sure?");		if (con==true) return true; else return false;}else{alert("Please correct the following\n"+msg);	return false;}
}function checkInput(ob){var invalidChars=/[^0-9\.]/gi;	if (invalidChars.test(ob.value)){	ob.value=ob.value.replace(invalidChars,"");} if (ob.length==0) ob.value="0";}
function addCommas(nStr){nStr+='';  let i=nStr.indexOf('.'); if(i===-1) nStr+='.00';  var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';  var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}   return x1+x2;
}function showAcCredit(cbo){let ac=parseInt(cbo.value),admno=document.getElementById("txtAdmNo1").value;
  if(ac>0){var xmlhttp=connect(),nocache=(Math.random()*1000000); xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200){document.querySelector("#txtAcBal1").value=addCommas(this.responseText);
    document.querySelector("#txtCredAmt1").value=addCommas(this.responseText);}}; xmlhttp.open('GET','ajax/returnstuddetails.php?q=2-'+admno+'-'+ac+'-'+nocache,true);		xmlhttp.send();
  }
}
