function BankBal(sn,ac,bank,bal){this.sn=sn; this.ac=ac; this.bank=bank;this.bal=bal;} var bankbal=[];
function CashBal(ac,bal){this.ac=ac; this.bal=bal;} var cashbal=[];
function loadAC(cbo){let ac=parseInt(cbo.value); ac=isNaN(ac)?0:ac;
  if(ac>0){clrCbo("cboBank"); let c=0,i=cashbal.length,found=false; while(c<i && !found){if(ac==cashbal[c].ac){ document.querySelector("#txtCashHand").value=cashbal[c].bal; found=true;}c++;}
    c=0,i=bankbal.length; addCBOItem("cboBank",0,"Select Bank A/C");  while(c<i){if(ac==bankbal[c].ac) addCBOItem("cboBank",bankbal[c].sn,bankbal[c].bank); c++;}
  }
}function checkNumber(txt){let val=txt.value.replace(/[^0-9\.]/g,''); if(val.length>0) txt.value=val; else txt.value=0;}
function loadBankBal(cbo){let acno=parseInt(cbo.value);if(acno>0){let i=0,found=false,l=bankbal.length; while(i<l && !found){if(bankbal[i].sn==acno){found=true;document.querySelector("#txtCashBank").value=bankbal[i].bal;}
  i++;}} else document.querySelector("#txtCashBank").value="0.00";
} function clrCbo(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);	if(mylistbox==null) return; while(mylistbox.length > 0) mylistbox.remove(0);
} function addCBOItem(listboxID,val,txt){
	let htmlSelect=document.getElementById(listboxID), selectBoxOption=document.createElement("option"); selectBoxOption.value=val;	selectBoxOption.text=txt;	htmlSelect.add(selectBoxOption);
}function modeChange(cbo){let mode=cbo.value.trim().toLowerCase();if(mode=="cheque"){document.getElementById('cboBank').disabled=false;document.getElementById('txtModeNo').readOnly=false;}
  else{document.getElementById('cboBank').disabled=true;document.getElementById('txtModeNo').readOnly=true;document.getElementById('cboBank').value=0;document.getElementById('txtModeNo').value="";}
}function calcAmtPerDur(){let mode=document.getElementById('cboMode').value.trim().toLowerCase(),amt=parseFloat(document.getElementById("txtAmt").value.replace(/[^0-9\.]/,"")),bal=0; amt=(isNaN(amt)?0:amt);
  if(mode=="cash") bal=parseFloat(document.getElementById('txtCashHand').value.replace(/[^0-9\.\-]/g,'')); else bal=parseFloat(document.getElementById('txtCashBank').value.replace(/[^0-9\.\-]/g,''));
  if(amt>bal){alert('Cash at '+(mode=='cash'?'Hand':'Bank')+' is less than Advance amount.\nAdvance amount has been reset to zero.'); document.getElementById("txtAmt").value=0;return;}
  var dur=parseFloat(document.getElementById("cboDur").value.replace(/[^0-9\.]/,"")); dur=(isNaN(dur)?0:dur);//alert(amt+' but balance is '+bal);
  if (amt>0 && dur>0){amt=Math.ceil(amt/dur); document.getElementById("txtAmtDur").value=amt.toFixed(2);}else document.getElementById("txtAmtDur").value="0.00";
} function findNetSal(cbo){var idno=cbo.value.trim(); var nocache = Math.random() * 10000; //stop caching
    if(idno.length>0){
      if (window.XMLHttpRequest){xmlhttp = new XMLHttpRequest();} else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); }// code for IE6, IE5
      xmlhttp.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) document.getElementById("txtBal").value = this.responseText;};
      xmlhttp.open('GET','ajax/shownetsal.php?q='+idno+'-'+nocache,true); xmlhttp.send();
    }else alert('Please, Select member of staff receiving salary advance');
} function verifyData(frm){
    var err="",act=frm.txtAct.value; action=act.split("-",2);
    if (parseInt(action[0])==0){//New advance, confirm third of salary rule
        var ns=parseFloat(frm.txtBal.value.replace(/[^0-9\.]/,"")); 	ns=isNaN(ns)?0:ns; //current net salary
        var apd=parseFloat(frm.txtAmtDur.value.replace(/[^0-9\.]/,"")); apd=isNaN(apd)?0:apd; //Amount per duration
        if (ns>0 && apd>0){if ((ns/3)<apd) err+="Net salary after recovery amount per month (Kshs."+apd+") MUST not be below a third of salary (Kshs. "+ns+").\n";
        }else err+="Ensure Net salary and Amount to be recovered per month are valid.\n";
    } if (frm.dtpDate.value.length<10) err+="Invalid date of issuance has been selected\n";
    var e=document.getElementById("cboStf"); if (e.options[e.selectedIndex].value.length<1) err+="Member of Staff being issued with advance has not been selected.\n";
    let mode=document.getElementById('cboMode').value.trim().toLowerCase(),amt=parseFloat(document.getElementById("txtAmt").value.replace(/[^0-9^\.]/,""));
    if(mode=='cheque' && document.getElementById('txtModeNo').value.trim().length<2 && parseInt(document.getElementById('cboBank').value)<1) err+="Select Bank A/C and enter Cheque No. of salary Advance.\n";
    if(amt<100 || isNaN((amt))) err+='Salary Advance amount should be higher than Kshs. 100.\n';  if (frm.txtRmks.value.length<10) err+="The narration.remarks on advance is too short.\n";
    if (err.length>0){alert("The following error MUST be corrected before saving advance record: -\n"+err);return false;}
    else{document.getElementById('cboBank').disabled=false;document.getElementById('txtModeNo').disabled=false;document.getElementById('cboACNo').disabled=false; return true;}
} function confirmDel(sb){
    if (sb==0){alert("You do not have the priviledge to delete salary advance records.");  return false;
  } else{var ans=confirm("Are you sure you want to delete this salary advance record?\nClick OK to delete otherwise click Cancel.");if (ans==true){return true;}else{return false;}}
} function myFunction(choice){
    var input, table, tr,td, i,nos=0,a=(document.getElementById("radPFNo").checked?0:(document.getElementById("radIDNo").checked?1:2)); // salary definition
    input=document.getElementById("txtFind").value.toUpperCase(); table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
    for(i=2;i<(tr.length-1);i++){td=tr[i].getElementsByTagName("td")[a];
        if (td){if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display=""; nos++;} else tr[i].style.display="none";}
    }if(choice==0) document.getElementById("spTotal").innerHTML=nos+' Salary Definition Record(s).';else  document.getElementById("spNoAdv").innerHTML=nos+' Salary Advance Record(s).';
}function clrText(){document.getElementById("txtFind").value='';document.getElementById("txtFind").focus();}
function canedit(pr){if (pr==0){alert("Sorry, you do not have the priviledges to edit the record");return false;}else{return true;}}
function canadd(pr){if(pr==0){alert("Sorry, you do not have the priviledges to add the record");	return false;}else{return true;	}}
function enableDel(txt){let rmks=txt.value.replace(/[^A_Z0-9\,\.\ ]/gi,''); if(rmks.length>10) document.querySelector("#btnDelAdv").disabled=false; else document.querySelector("#btnDelAdv").disabled=false; txt.value=rmks;}
function confirmAdvDel(frm){let err='',rmks=frm.txtDelRmks.value;if(rmks.length>10){if(confirm('You are about to delete this salary advance.\nIf sure of this action, Click OK.')) return true;} return false;}
function checkRmks(txt){let rmks=txt.value.replace(/[^A-Z0-9\,\.\ ]/gi,''); txt.value=rmks;}
