function Balances(voteno,budget,income,cost,avail){this.voteno=voteno; this.budget=budget; this.income=income; this.cost=cost; this.avail=avail;}var balances=[];
function assignAmts(a){
		var found=false,bal=calcTtl(a),vote=Number(document.querySelector("#cboVote_"+a).value), l=balances.length, i=0;
		if(vote>0){while (i<l && !found){
				if (balances[i].voteno==vote){found=true;
						document.querySelector("#txtBudget_"+a).value=addCommas(balances[i].budget);		document.querySelector("#txtIncome_"+a).value=addCommas(balances[i].income);
						document.querySelector("#txtCost_"+a).value=addCommas(balances[i].cost);				document.querySelector("#txtAvailable_"+a).value=addCommas(balances[i].avail);
				}i++;
			}if(!found){document.querySelector("#txtBudget_"+a).value="0.00";	document.querySelector("#txtIncome_"+a).value="0.00";	document.querySelector("#txtCost_"+a).value="0.00";
				document.querySelector("#txtAvailable_"+a).value="0.00";
			}
		}else if(bal<1){document.querySelector("#txtAmount_"+a).disabled=true;}//There is no amount to distribute
}function validateFormOnSubmit(theForm) {
	var reason = "",i=parseFloat(theForm.txtTotal.value.replace(/[^0-9\.]/g,""));
	if (i==0){theForm.txtCash.style.background='Yellow';		theForm.txtCheque.style.background='Yellow'; reason+="You MUST enter the cash and/or Cheque amount being spend before saving.\n";
	}i=parseFloat(theForm.txtBalance.value.replace(/[^0-9\.]/g,''));
	if (i!=0){theForm.cboVote_1.style.background='Yellow';	theForm.txtAmount_1.style.background='Yellow'; theForm.txtAmount_1.focus();
		reason+="Ensure the you have correctly distributed the amount to respective voteheads before saving\n";
	}reason += validateNo(theForm.txtIDNo); reason += validateUsername(theForm.txtPayee);  i=theForm.txtCheNo.value; var acno=Number(theForm.cboBankAC.value)
  if ((theForm.cboPytFrm.value.toLowerCase()!=="cash") && (i.length==0) && isNaN(acno)){reason+="You MUST enter cheque number for this pettycash payment before saving\n";theForm.txtCheNo.style.background='Yellow';
	}	if (i.length>0) reason += validateNo(theForm.txtCheNo);	i=theForm.txtEMail.value; if(i.length) reason+=validateEmail(i);	i=theForm.txtAddress.value;
	if ((i.toUpperCase()=="P.O BOX ") || (i.length<10)){reason+="Enter valid postal address of the payee for this pettycash payment\n";	   theForm.txtAddress.style.background='Yellow';}
	i=theForm.txtRmks.value; if (i.toUpperCase()=="BEING PAYMENT FOR " || i.length<15){reason+="Enter valid reason/remarks for the pettycash payment\n"; theForm.txtRmks.style.background='Yellow';}
	if (reason != "") {alert("Some fields need correction before saving:\n" + reason); return false;
  }else{for(i=1;i<5;i++){document.querySelector("#cboVote_"+i).disabled=false;document.querySelector("#txtAmount_"+i).disabled=false;} document.querySelector("#cboBankAC").disabled=false;	return true;}
}function validateEmail(mail){
	var err='';
 	if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(mail)){err='';}else{err='This email address is invalid\n';}
}function validateUsername(fld) {
	var error = "",illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == ""){fld.style.background = 'Yellow';	error = "You didn't type the information required in " + fld.name + ".\n";
	}else if(fld.value.length < 7){fld.style.background = 'Yellow';	error = "The information in " + fld.name + " is of wrong length.\n";
	}else if(illegalChars.test(fld.value)) {fld.style.background = 'Yellow';	error = "The information in " + fld.name + " contains illegal characters.\n";
	}else{fld.style.background = 'White';}return error;
}function validateNo(fld) {
	var error="",stripped=fld.value.replace(/[\(\)\.\-\ ]/g, '');
	if (fld.value==""){error = "You have no entered information required in " + fld.name + ".\n";	fld.style.background = 'Yellow';
	}else if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {	error = "Enter valid value in " + fld.name + ".\n";	fld.style.background = 'Yellow';}	return error;
}function addCommas(nStr){
	nStr+='';if(nStr.indexOf('.')==-1) nStr+='.00';
	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}function checkInput(ob){
	var invalidChars=/[^0-9\.]/g;
	if (invalidChars.test(ob.value)){	var a=ob.value.replace(invalidChars,"");ob.value=addCommas(a);}	if (ob.length==0){ob.value="0.00";}
}function sumPaid(){
 	var sum=0,x=0,n=Number(document.querySelector("#txtCash").value.replace(/[^0-9\.]/g,""))
	if (!(isNaN(n))) sum+=n; n=Number(document.querySelector("#txtCheque").value.replace(/[^0-9\.]/g,""));	if (!(isNaN(n))) sum+=n;
	document.querySelector("#txtBalance").value=document.querySelector("#txtTotal").value=addCommas(sum.toFixed(2));
	if (sum>0){	document.querySelector("#cboVote_1").disabled=false;	document.querySelector("#txtAmount_1").disabled=false;
	}else{document.querySelector("#cboVote_1").disabled=true;document.querySelector("#txtAmount_1").disabled=true;}
}function calcTtl(i){
	var sum=0,a=1,x=0,found=false;
	for (var a=1;a<=i;a++){var x=Number(document.querySelector("#txtAmount_"+a).value.replace(/[^0-9\.]/g,''));
 		if (!(isNaN(x))) sum+=x;	document.querySelector("#txtAmount_"+a).value=addCommas(x);
	}	n=Number(document.querySelector("#txtTotal").value.replace(/[^0-9\.]/g,''));	if (!(isNaN(x))) x=n-sum;	//finding balance yet to be distributed
	document.querySelector("#txtCosted").value=addCommas(sum.toFixed(2));	document.querySelector("#txtBalance").value=addCommas(x.toFixed(2));	return x; //balance for distribution
}function checkMode(cbo){
	let mode=cbo.value.toLowerCase();
	if(mode!=='cash'){document.querySelector("#txtCash").readOnly=(mode==='cheque'?true:false);	document.querySelector("#txtCheque").readOnly=false;	document.querySelector("#cboBankAC").disabled=false;
		document.querySelector("#txtCheNo").readOnly=false;
	}else{document.querySelector("#txtCash").readOnly=false;		document.querySelector("#txtCheque").readOnly=true;	document.querySelector("#txtCheNo").readOnly=true;		document.querySelector("#cboBankAC").disabled=true;}
}function checkCompute(i){
	var x=calcTtl(i),found=false,vno=Number(document.querySelector("#cboVote_"+i).value);
	if (vno==0){alert("Please, select votehead on which the expenditure is incurred.");	document.querySelector("#cboVote_"+i).style.background='Yellow';
	}else{
		if(i>1){ //Check if user selected same votehead again
			for (var a=1;a<i;a++){if(vno==Number(document.querySelector("#cboVote_"+a).value)){found=true;alert('This votehead is already used above.\nYou can not select it again.');document.querySelector("#cboVote_"+a).value=0;
				document.querySelector("#cboVote_"+a).style.background='Yellow';}
			}
		}if(!found){document.querySelector("#cboVote_"+i).style.background='White';
			//checking expenditure beyond available income
		 	var curramt=Number(document.querySelector("#txtAmount_"+i).value.replace(/[^0-9\.]/g,'')), availamt=Number(document.querySelector("#txtAvailable_"+i).value.replace(/[^0-9\.]/g,''));
			availamt=(isNaN(availamt)||availamt<0)?0:availamt;
			if(curramt>availamt){found=confirm("You are spending more than amount available in this votehead.\nIf you are sure click OK to continue.");
					if(!found){curramt=availamt; document.querySelector("#txtAmount_"+i).value=addCommas(curramt);}
			}	//checking expenditure beyond budget
		 	var budget=Number(document.querySelector("#txtBudget_"+i).value.replace(/[^0-9\.]/g,'')), cost=Number(document.querySelector("#txtCost_"+i).value.replace(/[^0-9\.]/g,''));	availamt=cost+curramt;
			if(availamt>budget){found=confirm("You are spending more than amount budgeted in this votehead.\nIf you are sure click OK to continue.");
					if(!found){curramt=availamt; document.querySelector("#txtAmount_"+i).value=addCommas(curramt);}
			}	i++;
			if ((x>0) && (i<5) && (curramt>0)){	document.querySelector("#cboVote_"+i).disabled=false;	document.querySelector("#txtAmount_"+i).disabled=false;
			}else{document.querySelector("#cboVote_"+i).disabled=true;	document.querySelector("#txtAmount_"+i).disabled=true;}
		}
	}
}
