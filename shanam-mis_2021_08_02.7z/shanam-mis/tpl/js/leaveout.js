function validateData(frm){var err=''; var amt=Number(frm.txtBal.value.replace(/[^0-9\.]/,''));
	if (isNaN(amt) || amt<1){err+="The Minimum balance MUST be higher than zero.\n"; document.getElementById('txtBal').style.background='Yellow';
	}else document.getElementById('txtBal').style.background='white';
	var dt1=frm.txtLeaveOn.value.trim().split(/\-/g),dt2=frm.txtReturnOn.value.trim().split(/\-/g),dt=new Date(dt1[2],dt1[1],dt1[0]),dt1=new Date(dt2[2],dt2[1],dt2[0]),days=Math.round((dt1.getTime()-dt.getTime())/8.64e7);
	if(days<0){err+="Ensure date of return is after date of leaving institution.\n"; document.getElementById('txtLeaveOn').style.background=document.getElementById('txtReturnOn').style.background='Yellow';
	}if (err.length>0){alert("MAKE THE FOLLOWING CORRECTIONS BEFORE SAVING.\n"+err);return  false;}else return true;
}function enableSave(txt,add){
 	if(add==1){var amt=Number(txt.value.replace(/[^0-9\.]/,'')); if (amt>0) document.getElementById('btnSave').disabled=false; else  document.getElementById('btnSave').disabled=true;
	}else alert("Sorry, you do not have the priviledge to receive bursary.");
}function addCommas(nStr){nStr+=''; nStr+=(nStr.indexOf('.')<0?'.00':'');
	var x=nStr.split('.'),x1=x[0],x2=(x.length>1?('.'+x[1]):''),rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}function checkInput(ob){	var invalidChars=/[^0-9\.\,]/gi; if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,"");	ob.value=addCommas(a);}	if (ob.length==0)	ob.value="0.00";
}function showLeaveouts(sno,d,opt){var nocache = Math.random() * 10000; //stop caching
	if (window.XMLHttpRequest) xmlhttp = new XMLHttpRequest(); else xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
  xmlhttp.onreadystatechange = function(){
    if (this.readyState==4 && this.status==200){document.getElementById("spListStuds").innerHTML = this.responseText;	document.getElementById("txtFindSNo").value=sno+'.'+d;
			if (opt==0){document.getElementById("btnViewDeleted").disabled=false;	document.getElementById("spPrint").style.display='';
			}else{document.getElementById("btnViewDeleted").disabled=true;	document.getElementById("spPrint").style.display='none';}
		}
  };if(opt==0) var da='0.'+sno+'.'+d+'.'+nocache; else var da='1.'+sno+'.'+d+'.'+nocache;
	xmlhttp.open('GET','ajax/leaveoutstud.php?sno='+da,true); xmlhttp.send();
}function showCancelledLeaveouts(){var sno=document.getElementById('txtFindSNo').value.trim().split(/\./g);
	if (parseInt(sno[0])>0 && !isNaN(parseInt(sno[1]))) showLeaveouts(sno[0],sno[1],1); else alert('Sorry, There was an error. You can not view cancelled leaveouts.');
}function printLeaveouts(){var sno=document.getElementById("txtFindSNo").value.trim().split(/\./g);
	var findby=(document.getElementById("radAdm").checked?"admno":(document.getElementById("radName").checked?"name":"form")),find=document.getElementById("txtFind").value.trim();
	find=(find.length>0?find:0); if (sno.length>0) parent.open('pdf/leaveoutsheet.php?sno='+sno[0]+'-'+findby+'-'+find); else alert("There are no leaveout session currently active for printing.");
}function findStudents(txt){var input, table, tr,td, i,ns=0,paid=0,bal=0,amt=0,found=false,a=(document.getElementById("radAdm").checked?1:(document.getElementById("radName").checked?2:3));
	input=txt.value.toUpperCase(); table=document.getElementById("tabDefaulter"); tr=table.getElementsByTagName("tr");
	for(i=1;i<(tr.length-1);i++){td=tr[i].getElementsByTagName("td")[a]; found=false;
		if (td){if(a==1 && Number(td.innerHTML.toUpperCase().trim())==input) found=true; else if(a!=1 && td.innerHTML.toUpperCase().trim().indexOf(input)>-1) found=true;
		}if(found){tr[i].style.display=""; ns++; tr[i].getElementsByTagName("td")[0].innerHTML=ns;
		 	amt=Number(tr[i].getElementsByTagName("td")[4].innerHTML.replace(/[^0-9\.]/,'')); paid+=(isNaN(amt)?0:amt);	amt=Number(tr[i].getElementsByTagName("td")[5].innerHTML.replace(/[^0-9\.]/,'')); bal+=(isNaN(amt)?0:amt);
		}else tr[i].style.display="none";
	}document.getElementById("spNoStud").innerHTML=ns+' Student(s)\' Leaveout Sheets'; document.getElementById("spPaid").innerHTML=addCommas(paid.toFixed(2)); document.getElementById("spBal").innerHTML=addCommas(bal.toFixed(2));
}function clrText(){document.getElementById("txtFind").value='';document.getElementById("txtFind").focus();}
function printSpecific(){
 	let disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25",content_value = document.getElementById("spListStuds").innerHTML;
	let docprint=window.open("","",disp_setting);	docprint.document.open();
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title></head><body onLoad="self.print()"><center>'+content_value+'</body></html>');
	docprint.document.close();	docprint.focus();
}function leaveSession(sno,pon,lon,ron,lvlno,bal){this.sno=sno; this.pon=pon; this.lon=lon; this.ron=ron; this.lvlno=lvlno; this.bal=bal;} var leavesessions=[];
function LstClass(clsno,clsname,lvlno){this.clsno=clsno;this.clsname=clsname;this.lvlno=lvlno;}var lstclass=[];
function getLeaveSession(n){var l=leavesessions.length,found=false,i=0;
	while(!found && (i<l)){
		if(leavesessions[i].sno==n){found=true;document.getElementById('txtSNo1').value=n;document.getElementById('txtProcessedOn1').value=leavesessions[i].pon;document.getElementById('txtLeaveOn1').value=leavesessions[i].lon;
			document.getElementById('txtReturnOn1').value=leavesessions[i].ron;	document.getElementById('txtOBal1').value=document.getElementById('txtBal1').value=leavesessions[i].bal;
			document.getElementById('cboLvl1').value=leavesessions[i].lvlno;showClass(1,leavesessions[i].lvlno);
		}i++;
	}if(found) document.getElementById('leaveoutSessionEdit').style.display='block';
}function validateLeaveSessionEdit(frm){
	var err=''; var amt=Number(frm.txtBal1.value.replace(/[^0-9\.]/,'')); var orig=Number(frm.txtOBal1.value.replace(/[^0-9\.]/,''));
	if (isNaN(amt) || amt<1){
		err+="The Minimum balance MUST be higher than zero.\n"; document.getElementById('txtBal1').style.background='Yellow';
	}else document.getElementById('txtBal1').style.background='white';
	var dt1=frm.txtLeaveOn1.value.trim().split(/\-/g);	var dt2=frm.txtReturnOn1.value.trim().split(/\-/g),dt1=new Date(dt1[2],dt1[1],dt1[0]),dt2=new Date(dt2[2],dt2[1],dt2[0]);
	var days=Math.round((dt2.getTime()-dt1.getTime())/8.64e7);
	if(days<0){	err+="Ensure date of return is after date of leaving institution.\n";
		document.getElementById('txtLeaveOn1').style.background=document.getElementById('txtReturnOn1').style.background='Yellow';
	}if (err.length>0){	alert("MAKE THE FOLLOWING CORRECTIONS BEFORE SAVING.\n"+err);	return  false;
	}else{if(amt!=orig){
		if(confirm('You are changing minimum balance from '+addCommas(orig.toFixed(2))+' to '+addCommas(amt.toFixed(2))+'.\nAre you sure it is OK?')) return true;
		 else {frm.txtBal1.style.background='yellow'; return false;}
	}else return true;}
}function canDel(opt,sb){if (sb==0){	alert("You do not have the priviledge to delete this record"); return false;
}else{let qn=(opt==0?"You are cancelling this student\'s leaveout.\nIs it OK?":"The student will be restored to list sent home.\nIs it Ok?");if(confirm(qn))	return true;} return false;
}function enableDelete(opt,txt,del){var val=txt.value.replace(/[^a-zA-Z\.\,]/g,'');
	if(opt==0){if(val.length>10 && del==1) document.getElementById('btnDelLeave').disabled=false; else document.getElementById('btnDelLeave').disabled=true;}
	else{if(val.length>10 && del==1) document.getElementById('btnDel').disabled=false; else document.getElementById('btnDel').disabled=true;}	txt.value=val;
}function closeSesDel(){document.getElementById('divLeaveSessDel').style.visibility='hidden'; document.getElementById('divSessDelBtn').style.visibility='visible';}
function showSessDelRmks(){document.getElementById('divLeaveSessDel').style.visibility='visible'; document.getElementById('divSessDelBtn').style.visibility='hidden';}
function leaveOutStudDel(row,lsn,adm){ var tr=document.getElementById("tabDefaulter").getElementsByTagName("tr")[row],td;
	td=tr.getElementsByTagName("td");	document.getElementById("trInfo").innerHTML="<td>"+td[1].innerHTML+"</td><td>"+td[2].innerHTML+"</td><td>"+td[3].innerHTML+"</td><td style=\"text-align:right;\">"+
	td[4].innerHTML+"</td><td style=\"text-align:right;\">"+td[5].innerHTML+"</td>"; document.getElementById("txtDet").value=lsn+'-'+adm;	document.getElementById("leaveoutDelete").style.display='block';
}function showClass(opt,cbo){
	let l=lstclass.length,i=0,lvl=parseInt(cbo.value); clrCbo(opt); addCbo(opt,'%','All'); while(i<l){if(lstclass[i].lvlno==lvl || isNaN(lvl)){addCbo(opt,lstclass[i].clsno,lstclass[i].clsname);}i++;}
}function clrCbo(op){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var cbo=(op==0?'cboCls':'cboCls1'), mylistbox=document.getElementById(cbo); if(mylistbox==null) return; while(mylistbox.length>0) mylistbox.remove(0);
}function addCbo(op,value,name){
	var cbo=(op==0?'cboCls':'cboCls1'),htmlSelect=document.getElementById(cbo),selectBoxOption=document.createElement("option"); selectBoxOption.value=value;	selectBoxOption.text=name;	htmlSelect.add(selectBoxOption);
}
