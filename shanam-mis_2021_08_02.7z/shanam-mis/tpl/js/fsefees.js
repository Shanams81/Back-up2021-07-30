function canEdit(pr) {
 	if (pr == 0) {alert("Sorry, you do not have the priviledges to edit the record"); 	return false;
  }else return true;
}function receiveFSE(){	document.getElementById('FSEIncome').style.display='block';}
function addCommas(nStr){
	nStr+='';	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}function checkData(opt,ob){
	var invalidChars=(opt==0?/[^0-9]/g:/[^0-9\.\,]/g);
	if (invalidChars.test(ob.value)){	var a=ob.value.replace(invalidChars,"");	ob.value=(opt==0?addCommas(a):addCommas(a.toFixed(2)));	}
	if (ob.length==0){ob.value=(opt==1?"0.00":"0");	}
}function getConnection(){
  if (window.XMLHttpRequest) {return new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
  } else {return new ActiveXObject("Microsoft.XMLHTTP");} // code for IE6, IE5
}function loadTranchAC(cbo){
  var nocache = Math.random() * 10000,acc=Number(cbo.value);
  if(!isNaN(acc)){  //Getting Tranche No.
    xmlhttp=getConnection();
    xmlhttp.onreadystatechange = function() { if (this.readyState == 4 && this.status == 200){
      var txt=this.responseText; let data=txt.split('~',3); document.getElementById("txtTranchNo").value=data[0];  document.getElementById("spBankAC").innerHTML=data[1];
      document.getElementById("spVotes").innerHTML=data[2];}
    }; xmlhttp.open('GET','ajax/showfsedata.php?rno=0-'+acc+'-'+nocache,true); xmlhttp.send();
  }else{alert("Sorry, You MUST select Votehead Account the FSE Fee is received."); cbo.focus();}
}function confirmNo(txt){
	var nob=Number(txt.value.replace(/[^0-9]/g,'')), nos=Number(document.getElementById("txtTtlStud").value.replace(/[^0-9]/g,''));
	if(nob<1 || isNaN(nob)){ alert("Sorry, You MUST have number of students benefiting from the FSE fund."); txt.style.background='Yellow'; txt.focus(); return;
	}if(nob!=nos){
		if(!confirm("The "+nob+" beneficiaries are not equal to number of "+nos+" students registered in the system.\nClick OK to continue with "+nob+" students.")){
			txt.style.background='Yellow'; txt.focus(); return; }
	}
} function calcTotal(){
	var nov=Number(document.getElementById("txtNOV").value.replace(/[^0-9\.]/g,'')); 		nov=isNaN(nov)?0:nov;
	var bal=0,ttldistr=0,amt=Number(document.getElementById("txtAmt").value.replace(/[^0-9\.]/g,'')); 	amt=isNaN(amt)?0:amt;
	for(var i=0;i<nov;i++){bal=Number(document.getElementById("txtVAmt_"+i).value.replace(/[^0-9\.]/g,''));	ttldistr+=isNaN(bal)?0:bal;
	} document.getElementById("txtTtlVAmt").value=addCommas(ttldistr.toFixed(2)); amt-=ttldistr;	document.getElementById("txtBal").value=addCommas(amt.toFixed(2));
}function distributeVotes(txt){
	var amt=Number(txt.value.replace(/[^0-9\.]/g,'')),ttl=Number(document.getElementById("txtTtlBal").value.replace(/[^0-9\.]/g,''));;
	if(isNaN(amt) || amt<1){alert("Sorry, You MUST have valid amount of FSE received."); txt.style.background='Yellow'; txt.focus(); return;
	}if(amt>ttl){alert("Sorry, You cannot receive FSE Fee higher than fee balance per student.\nCurrent balance has been set."); txt.value=addCommas(ttl.toFixed(2));
		amt=ttl; txt.style.background='Yellow';
	}var nov=Number(document.getElementById("txtNOV").value.replace(/[^0-9\.]/g,'')); 		nov=isNaN(nov)?0:nov;
	if(nov>0){
	 	var bal=0,ttldistr=0,ttl=isNaN(ttl)?0:ttl;
		for(var i=0;i<nov;i++){
			bal=Number(document.getElementById("txtBal_"+i).value.replace(/[^0-9\.]/g,''));		bal=isNaN(bal)?0:bal;
			var vamt=(bal>0?Math.round((amt*bal)/ttl):0); 	ttldistr+=vamt;			document.getElementById("txtVAmt_"+i).value=addCommas(vamt.toFixed(2));
		} calcTotal();
	}
}function confirmBal(pos){
	var bal=Number(document.getElementById("txtBal_"+pos).value.replace(/[^0-9\.]/g,'')), amt=Number(document.getElementById("txtVAmt_"+pos).value.replace(/[^0-9\.]/g,''));
	bal=isNaN(bal)?0:bal;	amt=isNaN(amt)?0:amt;
	if (amt>bal){alert("Sorry, You can not receive amount higher than votehead balance.\nCorrect balance has been set.");
    document.getElementById("txtVAmt_"+pos).value=document.getElementById("txtBal_"+pos).value;
	}else document.getElementById("txtVAmt_"+pos).value=addCommas(amt);	calcTotal();
}function validateData(frm){
	var err=''; calcTotal();
	if(isNaN(Number(frm.cboAC.value))){	err+="You MUST select votehead Account on which FSE is recieved.\n";	frm.cboAC.style.background='Yellow';
	}if(Number(frm.txtNOB.value)<1 || isNaN(Number(frm.txtNOB.value))){err+="You MUST enter number of student beneficiaries of FSE recieved.\n";	frm.txtNOB.style.background='Yellow';
	}if(frm.cboMode.value.toUpperCase()==='CHEQUE' && frm.txtCheNo.value.trim().length<3){err+="You MUST enter cheque number of the FSE recieved.\n";	frm.txtCheNo.style.background='Yellow';
	}if(isNaN(Number(frm.cboBank.value))){err+="You MUST select bank account in which the FSE was recieved.\n";	frm.cboBank.style.background='Yellow';
	}if(Number(document.getElementById("txtBal").value.replace(/[^0-9\.]/g,''))!=0){err+="You MUST distribute fully the FSE fee recieved to respective voteheads.\n";
	}if(err.length==0){return true;	}else{alert("THE FOLLOWING ERROR(S) MUST BE CORRECTED BEFORE SAVING:\n"+err); return false;}
}
