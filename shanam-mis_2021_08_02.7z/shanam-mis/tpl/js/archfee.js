function verifyDate(frm){
	var yr1=parseInt(frm.CboYr1.value);		var yr2=parseInt(frm.CboYr2.value);
	var mon1=parseInt(frm.CboMon1.value);	var mon2=parseInt(frm.CboMon2.value);
	var day1=parseInt(frm.CboDays1.value);	var day2=parseInt(frm.CboDays2.value); var err='';
	if (isNaN(yr1)||isNaN(yr2)||isNaN(mon1)||isNaN(mon2)||isNaN(day1)||isNaN(day2))err+='Choose valid dates whose fee reciepts are to be viewed.\n';
	if (yr1!=yr2) err+='The dates choosen MUST be in the same financial year!.\n';
	if(((yr1==yr2) && (mon1>mon2)) || ((yr1==yr2) && (mon1==mon2) && (day1>day2))) err+='The date range selected is invalid. Starting date MUST be before/same as ending date!.\n';
	if (err.length>0){
		alert('ERROR ON DATE RANGE\n'+err); return false;
	}else return true;
}
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function filldays(listboxID){
	var i=ClearCont(listboxID); 
	if (listboxID=='CboDays1'){
		var lstYr='CboYr1'; var lstMon='CboMon1';
	}else{
		var lstYr='CboYr2'; var lstMon='CboMon2';
	}
	var yr=parseInt(document.getElementById(lstYr).value);
	var mon=document.getElementById(lstMon).value;
	var n=noofdays(yr,mon);
	var htmlSelect=document.getElementById(listboxID);
	for (var i=1;i<=n;i++){
		selectBoxOption = document.createElement("option");
		selectBoxOption.value = i;
		selectBoxOption.text = i;
		htmlSelect.add(selectBoxOption);
	}
}
function noofdays(y,m){
 	switch (m){
		case '01': d=31; break;
		case '02': if(((y%4 == 0) && (y%100 != 0)) || (y%400 == 0)) d=29; else d=28; break;
		case '03': d=31; break;
		case '04': d=30; break;
		case '05': d=31; break;
		case '06': d=30; break;
		case '07': d=31; break;
		case '08': d=31; break;
		case '09': d=30; break;
		case '10': d=31; break;
		case '11': d=30; break;
		case '12': d=31; break;
		default: d=1; break;
	}
	return d;
}
function Clickheretoprint(){ 
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
  	disp_setting+"scrollbars=yes,width=650, height=600, left=100, top=25"; 
	var content_vlue = document.getElementById("print_content").innerHTML; 
	var docprint=window.open("","",disp_setting); 
	docprint.document.open(); 
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title>'); 
	docprint.document.write('</head><body onLoad="self.print()" style="color:#000000;font-size:10px;"><center>');          
	docprint.document.write(content_vlue);          
	docprint.document.write('</body></html>'); 
	docprint.document.close(); 
	docprint.focus(); 
}