var mpr=0,nssfRate=0.12;
function payeRate(ul,rate){
	this.ul=ul; this.rate=rate;
}
function nhifRate(ul,amt){
	this.ul=ul; this.amt=amt;
}