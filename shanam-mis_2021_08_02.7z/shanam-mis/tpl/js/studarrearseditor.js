function ValidateInput(myForm,ac){
	var dat="";
	if (myForm.txtRmks.value.length<15 && ac==2){
		dat+="You MUST have full narration for the change of arrears before saving";
		myForm.txtRmks.style.background='Yellow';
	}else{myForm.txtRmks.style.background='White';}
	if (myForm.txtArr.value.length==0 || parseFloat(myForm.txtArr.value.replace(",",""))<0 || isNaN(parseFloat(myForm.txtArr.value.replace(",","")))){
		dat+="The Main account arrears MUST be either 0.00 or higher amount.";
		myForm.txtArr.style.background='Yellow';
	}else myForm.txtArr.style.background='White';
	if (myForm.txtMArr.value.length==0  || parseFloat(myForm.txtMArr.value.replace(",",""))<0 || isNaN(parseFloat(myForm.txtMArr.value.replace(",","")))){
		dat+="The Miscelleanous account arrears MUST  either 0.00 or higher amount.";
		myForm.txtMArr.style.background='Yellow';
	}else myForm.txtMArr.style.background='White';
	if (myForm.txtRef.value.length==0  || parseFloat(myForm.txtRef.value.replace(",",""))<0 || isNaN(parseFloat(myForm.txtRef.value.replace(",","")))){
		dat+="The refundable amount MUST be either 0.00 or higher amount.";
		myForm.txtRef.style.background='Yellow';
	}else myForm.txtRef.style.background='White';
	if (dat==""){
	 	return true;
	}else{
	 	alert(dat);
		return false;
	}
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkNumber(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0.00";
	}
}
