function myFunction(){
	var input, table, tr,td, i,amt=0,nop=0,ttl=[0,0,0];
	var a=(document.querySelector("#radVNo").checked?0:(document.querySelector("#radIDNo").checked?1:(document.querySelector("#radName").checked?2:3))); // impreset such criteria
	input=document.querySelector("#txtFind").value.toUpperCase(); table=document.querySelector("#tblPV"); tr=table.querySelectorAll("tr");
	for(i=2;i<(tr.length-1);i++){
		td=tr[i].querySelectorAll("td")[a];
		if (td){
			if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){
			 	tr[i].style.display=""; nos++; 		amt=Number(tr[i].querySelectorAll("td")[8].innerHTML.replace(/[^0-9^\.]/,'')); 	ttl[0]+=isNaN(amt)?0:amt;
				amt=Number(tr[i].querySelectorAll("td")[9].innerHTML.replace(/[^0-9^\.]/,'')); 	ttl[1]+=isNaN(amt)?0:amt;
				amt=Number(tr[i].querySelectorAll("td")[10].innerHTML.replace(/[^0-9^\.]/,'')); ttl[2]+=isNaN(amt)?0:amt;
			}else tr[i].style.display="none";
		}
	}	document.getElementById("trTtls").innerHTML="<tr><th colspan=\"5\">"+nop+" Payment Record(s)</th><th colspan=\"3\" align=\"right\">Payment Subtotals</th><th align=\"right\">"+
	addCommas(ttl[0].toFixed(2))+"</th><th align=\"right\">"+addCommas(ttl[1].toFixed(2))+"</th><th align=\"right\">"+addCommas(ttl[0].toFixed(2))+"</th><th colspan=\"2\"></th></tr>";
}function clrText(){	document.getElementById("txtFind").value='';	document.getElementById("txtFind").focus();}
function addCommas(nStr){
	nStr+=''; 	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/; while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');} return x1+x2;
}function printSpecific(){
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25";
	var content_value = document.getElementById("divPettyPyts").innerHTML,docprint=window.open("","",disp_setting); docprint.document.open();
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title></head><body onLoad="self.print()" style="font-size:10px;">');
	docprint.document.write(content_value+'</body></html>');	docprint.document.close();	docprint.focus();
}
