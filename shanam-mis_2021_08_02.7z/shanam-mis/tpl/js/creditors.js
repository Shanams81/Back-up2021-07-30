function validateCreditor(theForm) {
 	var reason = "";
	if (theForm.txtName.value.length<8){
	 	reason+="You MUST enter the name of the creditor before saving.\n"; theForm.txtName.style.background='Yellow';
	}else{ theForm.txtName.style.background='White';	}
	var ndat=new Date();
	if (parseInt(theForm.txtYr.value)>ndat.getFullYear()){
	 	reason+="You MUST enter a valid year of credit. Year must be/ before "+parseInt(theForm.txtYr.value)+"\n"; 	theForm.txtYr.style.background='Yellow';
	}else{ theForm.txtYr.style.background='White';}
	if (theForm.txtIDNo.value.length>0) reason += validateNo(theForm.txtIDNo);
	reason += validateUsername(theForm.txtName);
	if (theForm.txtTelNo.value.length>0) reason += validateNo(theForm.txtTelNo);
	if (reason != "") {
  	alert("The following Credior\'s fields need correction :\n" + reason);  	return false;
	} else {	return true;}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d\w/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 	error = "You didn't enter the information about the Creditor.\n";
	} else if (fld.value.length < 5) {
    	fld.style.background = 'Yellow'; 	error = "The Creditor information entered is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 	error = "The Creditor information contains illegal characters.\n";
	} else { 	fld.style.background = 'White';	}
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped =Number(fld.value.replace(/[^0-9\.]/g,''));
	if ((isNaN(parseFloat(stripped))) || (parseFloat(stripped)<=0)) {
    	error = "The telephone number, amount and/ or ID No. entered are invalid.\n";   	fld.style.background = 'Yellow';
	} else{	fld.style.background = 'White';	}
	return error;
}
function candel(sb,n){
 	if (n>0){		alert("Sorry, this creditor has "+n+" commitments in the system.\nRecord can not be deleted.");
	}else{
	 	if (sb==0){	alert("You do not have the priviledge to delete this record");
		}else{
		 	var ans=confirm("Are you sure you want to delete this record?\nClick OK to delete otherwise click Cancel.");
		 	if (ans==true){document.querySelector("#txtDelReason").value="";      document.querySelector("#divDelRmks").style.display='block';}
		}
	}
}
function checkReason(txt){
  let rmks=txt.value.replace(/[^a-z\ \. \,]/gi,'');   txt.value=rmks;
  if(rmks.length>10) document.querySelector("#btnDelete").disabled=false;  else document.querySelector("#btnDelete").disabled=true;
}
function checkInput(ob){
	var invalidChars=/[^0-9]/g;
	if (invalidChars.test(ob.value)){		var a=ob.value.replace(invalidChars,""); 	ob.value=a;
	}if (ob.length==0){ob.value="";}
}
function formatnumber(obj){
	let n=obj.value.replace(/[^0-9\.]/g,'');	n=addCommas(n);	obj.value=n;
}
function addCommas(nStr){
	nStr+=''; var x=nStr.split('.'); var x1=x[0];	var x2=x.length>1?('.'+x[1]):''; 	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1; while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
