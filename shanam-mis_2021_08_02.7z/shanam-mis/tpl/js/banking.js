function AccBal(acsno,ac,bal,acname){this.acsno=acsno; this.ac=ac; this.bal=bal; this.acname=acname;} var accbal=[];
function showBal(cbo){ let acsno=parseInt(cbo.value),found=false,l=accbal.length,c=bal=0; acsno=isNaN(acsno)?0:acsno;
	document.querySelector("#divACName").innerHTML=""; document.querySelector("#txtAmt").readOnly=true;
	while(!found && c<l){if(accbal[c].acsno==acsno){found=true; bal=accbal[c].bal; document.querySelector("#txtAmt").readOnly=false; document.querySelector("#txtAC").value=accbal[c].ac;
	document.querySelector("#divACName").innerHTML='<br>CREDITING CASH AT HAND OF <BR>'+accbal[c].acname;}c++;}	document.getElementById('txtBal').value=addCommas(bal);
}function checkAmt(txt,opt){ //opt==1 Editing otherwise new transaction
	let inv=/[^0-9\-\.]/g,origamt=parseFloat(document.querySelector("#txtOrigAmt").value.replace(inv,''));
	let amt=parseFloat(txt.value.replace(inv,'')),type=parseInt(document.querySelector("#cboType").value),bal=parseFloat(document.querySelector("#txtBal").value.replace(inv,''));
	if(amt>(bal+origamt) && type==1){//withdrawing more than account balance
		amt=(bal+origamt)<0?0:(bal+origamt); alert('Sorry, You CAN NOT withdraw more than account balance.\nThe sum of Kshs. '+addCommas(amt)+' has been set for withdrawal.');
	}txt.value=addCommas(amt);
}function actiondone(a,b){ // a = 0 is normal,1 editing and 2 deleting. b is the number of records edited or deleted
	if ((a==1) && (b>0)){alert(b+" record(s) were sucessfully added/ edited/ restored.");}else if ((a==2) && (b>0)){alert(b+" record(s) were sucessfully deleted.");
	}else if ((a==1) && (b==0))	{alert("No record has been successfully added or edited");}else if ((a==2) && (b==0)){alert("The record has not sucessfully been deleted");}
}function validateInput(myForm){
	var dat="",n=parseFloat(myForm.txtAmt.value.replace(/[^0-9\.]/g,''));
	if(isNaN(n) || n<1000){dat+="The Amount transacted must be numeric and higher than Kshs. 1,000.00\n";	myForm.txtAmt.style.background='Yellow'; myForm.txtAmt.value=0;}
	if(myForm.txtRmks.value.trim().length<20){dat+="Enter full description of transaction remarks.\n";	myForm.txtRmks.style.background='Yellow';}
	if(myForm.txtCheNo.value.trim().length<3){dat+="Cheque No. MUST be validly entered before saving\n"; myForm.txtCheNo.style.background='Yellow';}
	if(myForm.cboAC.value.trim()=="0"){dat+="\nYou MUST select bank A/C being debited.\n"; myForm.cboAC.style.background='Yellow';}
	if (dat==""){return true;}else{	alert(dat);	return false;}
}function addCommas(nStr){
 	nStr+=''; nStr=nStr.indexOf('.')<0?(nStr+'.00'):nStr; var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):''; var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	 return x1+x2;
}function checkInput(ob){
	var invalidChars=/[^0-9\.]/g;
	if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,""); ob.value=addCommas(a);}
	if (ob.length==0){ob.value="0.00";}
}function showDel(){document.querySelector('#divDel').style.visibility='visible';document.querySelector('#divBtn').style.visibility='hidden';}
function closeDel(){document.querySelector('#divDel').style.visibility='hidden';document.querySelector('#divBtn').style.visibility='visible';}
function enableDel(txt){if(txt.value.trim().length>10) document.querySelector('#btnDel').disabled=false; else document.querySelector('#btnDel').disabled=true;}
