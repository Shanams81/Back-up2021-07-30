function actiondone(a,b){ // a = 0 is normal,1 editing and 2 deleting. b is the number of records edited or deleted
	if ((a==1) && (b>0)){alert(b+" banking transaction(s) were sucessfully added/ edited/ restored.");
	}else if ((a==2) && (b>0)){alert(b+" banking transaction(s) were sucessfully deleted.");
	}else if ((a==1) && (b==0))	{alert("No banking transaction has been successfully added or edited");
	}else if ((a==2) && (b==0))alert("The banking transaction has not sucessfully been deleted");
}function canedit(pr,opt) {
 	if (pr==0) alert("Sorry, you do not have the priviledges to edit the banking transaction"); else window.open('banking.php?tno='+opt,'_self');
}function candel(sb){
 	if (sb==0){alert("You do not have the priviledge to delete this banking transaction");return false;
	} else{	var ans=confirm("Are you sure you want to restore this bank transaction?\nClick OK to restore otherwise click Cancel.");
	 	if (ans==true) return true; else return false;
	}
}
