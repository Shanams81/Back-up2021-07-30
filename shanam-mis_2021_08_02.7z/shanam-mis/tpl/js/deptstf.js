function confirmDept(cbo){
    let d=Number(cbo.value);
    if(isNaN(d) || d===0){
        alert('You MUST select a valid department before continuing');
        cbo.focus(); cbo.sytle.background='Yellow';
    }else cbo.sytle.background='white';
}
function verSec(txt){
    let sec=txt.value.trim();
    if(sec.length>0){
        sec=sec.replace(/[^a-zA-Z]/g,'');
        txt.value=sec.toUpperCase();
    }
}
function checkData(frm){
    var err='';
    if (isNaN(Number(frm.cboDept.value)) || Number(frm.cboDept.value)===0){
        err+='You MUST select a valid department before saving.\n'; frm.cboDept.style.background='yellow';
    }else if(frm.txtSection.value.trim()<3){
        err+='Type valid section name before saving.\n'; frm.txtSection.style.background='yellow';
    }
    if(err.length===0){
        return true;
    }else{
        alert ("CORRECTION TO MAKE BEFORE SAVING.\n"+err); return false;
    }
}