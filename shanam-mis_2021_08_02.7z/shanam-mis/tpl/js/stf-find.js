function myFunction(){
	var input, table, tr,td, i,nos=0;
	var a=(document.getElementById("radIDNo").checked?0:(document.getElementById("radName").checked?1:(document.getElementById("radGender").checked?2:7)));
	input=document.getElementById("txtFind").value.toUpperCase();
	table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
	for(i=0;i<tr.length;i++){
		td=tr[i].getElementsByTagName("td")[a];
		if (td){
			if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display=""; nos++;}
			else tr[i].style.display="none";
		}
	}document.getElementById("spTotal").innerHTML=nos+' Staff Details.';		
}
function clrText(){
	document.getElementById("txtFind").value='';
	document.getElementById("txtFind").focus();
}