function canEdit(pr) {
 	if (pr == 0) {alert("Sorry, you do not have the priviledges to edit the record"); 	return false;	} else 	return true;
}function receiveFSE(){	document.getElementById('FSEIncome').style.display='block';
}function addCommas(nStr){
	nStr+='';	var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');} return x1+x2;
}function checkData(ob){
	var invalidChars=/[^0-9\.\,]/g;
	if (invalidChars.test(ob.value)){	var a=ob.value.replace(invalidChars,"");	ob.value=addCommas(a.toFixed(2));	}
	if (ob.length==0)	ob.value="0.00";
}function getConnection(){
	if (window.XMLHttpRequest) return new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
  else return new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
}function loadVotehead(cbo){
	var nocache = Math.random() * 10000,acc=Number(cbo.value);
	if(!isNaN(acc)){
	 	//Getting Votehead Balances
		xmlhttp=getConnection();
		xmlhttp.onreadystatechange = function() {
	    	if (this.readyState == 4 && this.status == 200){
          var data=this.responseText;  let da=data.split('~',2); document.getElementById("spVotes").innerHTML=da[0]; document.getElementById("spBankAC").innerHTML=da[1];
        }
	    }; xmlhttp.open('GET','ajax/showfsedata.php?rno=1-'+acc+'-'+nocache,true); xmlhttp.send();
	}else{alert("Sorry, You MUST select Votehead Account the FSE Fee is received."); cbo.focus();}
}function validateData(frm){
	var err='';
	if(isNaN(Number(frm.cboAC.value))|| Number(frm.cboAC.value)===0){	err+="You MUST select votehead Account on which FSE is recieved.\n";	frm.cboAC.style.background='Yellow';
  }if(isNaN(Number(frm.cboVotes.value)) || Number(frm.cboVotes.value)===0){	err+"You MUST select votehead on which the FSE is received.\n"; frm.cboVotes.style.background='Yellow';
	}if(frm.cboMode.value.toUpperCase()==='CHEQUE' && frm.txtCheNo.value.trim().length<3){err+="You MUST enter cheque number of the FSE recieved.\n";	frm.txtCheNo.style.background='Yellow';
  }if(isNaN(Number(frm.cboBank.value)) || Number(frm.cboBank.value)===0){err+="You MUST select bank account in which the FSE was recieved.\n";	frm.cboBank.style.background='Yellow';
	}if(Number(document.getElementById("txtAmt").value.replace(/[^0-9\.]/g,''))<2){err+="You MUST type the correct amount of grant received.\n";  frm.txtAmt.style.background='Yellow';
	}if(document.getElementById("txtRmks").value.trim().length<10){err+="You MUST type proper remarks on FSE grand recieved.\n"; frm.txtRmks.style.background='Yellow';
	}if(err.length==0){return true;}else{alert("THE FOLLOWING ERROR(S) MUST BE CORRECTED BEFORE SAVING:\n"+err); return false;}
}
