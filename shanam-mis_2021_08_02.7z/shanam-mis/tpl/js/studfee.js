function myFunction(){ var input,table,tr,td,i,nos=0,a=(document.getElementById("radAdm").checked?0:(document.getElementById("radName").checked?1:2));
    input=document.getElementById("txtFind").value.toUpperCase(); table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
    for(i=0;i<tr.length;i++){ td=tr[i].getElementsByTagName("td")[a];if (td){
      if (a==0){if(td.innerHTML.trim()==input || input.length==0){nos++; tr[i].style.display="";}else tr[i].style.display="none";
      }else{if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){nos++; tr[i].style.display="";} else tr[i].style.display="none";}
    }}document.getElementById("spNoS").innerHTML=nos+' Student Record(s)'; document.getElementById("divState").innerHTML='';
}function clrText(){document.getElementById("txtFind").value=''; document.getElementById("txtFind").focus();}
function showReceipt(ad,yr) { var nocache = Math.random() * 10000; //stop caching
	if (window.XMLHttpRequest){xmlhttp = new XMLHttpRequest();}else{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
  xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200) document.getElementById("divState").innerHTML = this.responseText; };
  xmlhttp.open('GET','ajax/fees_statement.php?adm='+ad+'-0-'+yr+'-'+nocache,true); xmlhttp.send();
}
