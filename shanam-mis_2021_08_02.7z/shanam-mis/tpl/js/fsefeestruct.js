function showFS(opt,ac) {
  var nocache = Math.random() * 10000; //stop caching
	if (window.XMLHttpRequest) { xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    }xmlhttp.onreadystatechange = function() {if (this.readyState == 4 && this.status == 200) document.getElementById("divFeeStruct").innerHTML = this.responseText;};
    xmlhttp.open('GET','ajax/showfsefeestruct.php?q='+opt+'-'+ac+'-'+nocache,true); xmlhttp.send();
}function canedit(pr,ac) {
    if (pr==0) {	alert("Sorry, You do not have the priviledges to edit the FSE Fee Structure.");	return false;
  } else { showFS(1,ac); return true; }
}function addCommas(nStr){
    nStr+='';
    var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';
    var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
    return x1+x2;
}function checkData(ob){
    var invalidChars=/[^0-9\.\,]/g,a=ob.value.replace(invalidChars,"");
    if (ob.length==0) ob.value="0.00"; else ob.value=addCommas(a);
}function getTotal(pos,v){
    var t1=Number(document.getElementById("txtT1_"+pos).value.replace(/[^0-9^\.]/g,''));	var t2=Number(document.getElementById("txtT2_"+pos).value.replace(/[^0-9^\.]/g,''));
    var t3=Number(document.getElementById("txtT3_"+pos).value.replace(/[^0-9^\.]/g,''));	var ttl=t1+t2+t3;
    document.getElementById("txtTtl_"+pos).value=addCommas(ttl.toFixed(2));                     var termttl=[0,0,0,0];
    for (var i=0;i<v;i++){
        t1=Number(document.getElementById("txtT1_"+i).value.replace(/[^0-9^\.]/g,''));  t2=Number(document.getElementById("txtT2_"+i).value.replace(/[^0-9^\.]/g,''));
        t3=Number(document.getElementById("txtT3_"+i).value.replace(/[^0-9^\.]/g,''));  var y=Number(document.getElementById("txtTtl_"+i).value.replace(/[^0-9^\.]/g,''));
        termttl[0]+=(isNaN(t1)?0:t1); termttl[1]+=(isNaN(t2)?0:t2);    termttl[2]+=(isNaN(t3)?0:t3);   termttl[3]+=(isNaN(y)?0:y);
    }document.getElementById("txtTermTtl_0").value=addCommas(termttl[0].toFixed(2));  document.getElementById("txtTermTtl_1").value=addCommas(termttl[1].toFixed(2));
    document.getElementById("txtTermTtl_2").value=addCommas(termttl[2].toFixed(2));   document.getElementById("txtTermTtl_3").value=addCommas(termttl[3].toFixed(2));
}
/*function validateData(frm){
	var i=0; var dat=Number(frm.txtNoAC.value);
	for (var ac=0;ac<dat;ac++){
		var nov=document.getElementById("txtNoFS_"+ac).value.trim().split('/\-/g');
		for(var a=0;a<nov[0];a++){
			if (Number(document.getElementById("txtT1_"+ac+"_"+a).value.replace(/[^0-9^\.]/g,''))>=0 && Number(document.getElementById("txtT2_"+ac+"_"+a).value.replace(/[^0-9^\.]/g,''))>=0
			&& Number(document.getElementById("txtT3_"+ac+"_"+a).value.replace(/[^0-9^\.]/g,''))>=0){
				i=0;
			}else{ i=1; break;}
		}
	}if (i==0){
		if (confirm('The changes will affect fee definition of all students in this level.\nAre you sure of this?')){
			return true;
		}else return false;
	}else{
		alert('Ensure all votehead amount are correctly entered before saving.');
		return false;
	}
}*/
