function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.txtAdmNo);
	if (theForm.txtBirthNo.value.length!=0){
		reason += validateNo(theForm.txtBirthNo);
	}
	reason += validateUsername(theForm.txtSurname);
	reason += validateUsername(theForm.txtONames);
	if(isNaN(parseFloat(theForm.cboLevel.value.trim()))){
		reason+="Select grade/class level.\n"; theForm.cboLevel.style.background='Yellow';
	} if(isNaN(parseFloat(theForm.cboForm.value.trim()))){
		reason+="Select the alumni grade/form.\n"; theForm.cboForm.style.background='Yellow';
	}if(theForm.cboStream.value.trim().length()){
		reason+="Select grade/class stream.\n"; theForm.cboStream.style.background='Yellow';
	}	if (theForm.txtTelNo.value.length!=0){
		reason += validateNo(theForm.txtTelNo);
	}	if (theForm.txtGuardian.value.length!=0){
		reason += validateUsername(theForm.txtGuardian);
	}
	reason += validateNo(theForm.txtArrears);
	reason += validateNo(theForm.txtRef);
	var arr=parseFloat(theForm.txtArrears.value.replace(',',''));
	var ref=parseFloat(theForm.txtRef.value.replace(',',''));
	if (arr>0 && ref>0){
		reason+="The alumni CAN NOT have arrears and refunds at the same time\n";
		theForm.txtArrears.style.background='Yellow';
		theForm.txtRef.style.background='Yellow';
	}else{
		theForm.txtArrears.style.background='white';
		theForm.txtRef.style.background='white';
	}
	if (reason != "") {
  	alert("The following fields need correction:\n" + reason);
  	return false;
	} else {
		return true;
	}
}
function checkData(ob,opt){
	var invalidChars=(opt==0?/[^0-9\.\,]/g:/[^0-9\+]/g);
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=(opt==0?addCommas(a):a);
	}
	if (ob.length==0){
	 	ob.value=(opt==0?"0.00":"");
	}
}
function frmtNumber(dat){
	var v=dat.value.replace(/[^0-9\.]/g,"");
	dat.value=addCommas(v);
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow';
    	error = fld.name + " You didn't enter the right information.\n";
	} else if (fld.value.length < 3) {
    	fld.style.background = 'Yellow';
    	error = fld.name + " The information is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow';
    	error = fld.name + " The information contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	}
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ \+]/g, '');
	if (fld.value == "") {
    	error = fld.name + " requires numeric data, it is currently blank.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = fld.name + " requires numeric values, your entry contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	}
	return error;
}
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function filldays(listboxID){
	var i=ClearCont(listboxID);
	var yr=parseInt(document.getElementById("cboYr").value);
	var mon=document.getElementById("cboMon").value;
	var n=noofdays(yr,mon);
	var htmlSelect=document.getElementById(listboxID);
	for (var i=n;i>0;i--){
		selectBoxOption = document.createElement("option");
		selectBoxOption.value = i;
		selectBoxOption.text = i;
		htmlSelect.add(selectBoxOption);
	}
}
function noofdays(y,m){
 	switch (m){
		case '01': d=31; break;
		case '02': if(((y%4 == 0) && (y%100 != 0)) || (y%400 == 0)) d=29; else d=28; break;
		case '03': d=31; break;
		case '04': d=30; break;
		case '05': d=31; break;
		case '06': d=30; break;
		case '07': d=31; break;
		case '08': d=31; break;
		case '09': d=30; break;
		case '10': d=31; break;
		case '11': d=30; break;
		case '12': d=31; break;
		default: d=1; break;
	}
	return d;
}
function canedit_amt(yes){
	if (yes==0) {
    	alert("Sorry, you do not have the priviledges to edit arrears and refund amounts");
    	return false;
  	} else {
  		return true;
  	}
}
function loadClasses(cbo) {
    var lvl=parseInt(cbo.value.trim());
    if (!isNaN(lvl)){
		var nocache = Math.random() * 10000; //stop caching
		if (window.XMLHttpRequest) {
	        xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
	    } else {
	        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
	    }xmlhttp.onreadystatechange = function() {
	        if (this.readyState == 4 && this.status == 200) document.getElementById("clsNames").innerHTML = this.responseText;
	    };
	    xmlhttp.open('GET','ajax/clsLoad.php?q=0-'+lvl+'-'+nocache,true); xmlhttp.send();
	}
}
