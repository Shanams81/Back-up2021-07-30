function Voteheads(vno,acc,abbr){this.vno=vno; this.acc=acc; this.abbr=abbr;} var voteheads=[];
function accChange(cbo){let ac=Number(cbo.value),val=''; ac=isNaN(ac)?0:ac;	if(ac>0 && voteheads.length>0){let vote=voteheads.filter(function (v){return v.acc==ac;});
		vote.forEach(function getVotes(item,index){if(v.abbr.toLowerCase()=='arrears')val=this.vno; else val+='-'+this.vno;});}document.querySelector('#txtVArrRent').value=val;
}function canClear(pr) {if (pr == 0){	alert("Sorry, you do not have the priviledges to capture imprest surrendering details");return false;}else{return true;}}
function addCommas(nStr){nStr+=''; var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):'';var rgx=/(\d+)(\d{3})/;while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}function calcTotal(txt){let ttl=0, amt=parseFloat(document.querySelector("#txtArrears").value.replace(/[^0-9\.]/g,''));	ttl+=(isNaN(amt)?0:amt);
	amt=parseFloat(document.querySelector("#txtRent").value.replace(/[^0-9\.]/g,''));	ttl+=(isNaN(amt)?0:amt); document.querySelector("#txtTotal").value=addCommas(ttl); cleanAmt(txt);
} function cleanAmt(txt){	let amt=txt.value.replace(/[^0-9\.]/g,''); txt.value=(amt.length==0?"0.00":amt);
} function fmtNumber(txt){let amt=txt.value.replace(/[^0-9\.]/g,''); txt.value=addCommas(amt);
} function validateFormOnSubmit(frm){	var err="";
	if(frm.cboMode.value.trim().toLowerCase()!='cash' && frm.txtModeNo.value.length<3){ err+="Transaction/Cheque No. is required before saving\n"; frm.txtModeNo.style.background='Yellow';}
	if(parseInt(frm.cboBank.value)===0 && (frm.cboMode.value.toLowerCase()=='cheque' || frm.cboMode.value.toLowerCase()=='direct banking')){
		err+="Select cheque/ direct banking banker.\n";  frm.cboBank.style.background='Yellow';
	}let amt=Number(document.querySelector("#txtAmt").value.replace(/[^0-9\.]/g,'')); if(amt==0 || isNaN(amt)){err+="You have not entered rent amount received.\n";
	frm.txtAmt.style.background='Yellow'; frm.txtBC.style.background='Yellow';} let ttl=0,rent=Number(document.querySelector("#txtRent").value.replace(/[^0-9\.]/g,''));
	ttl+=(isNaN(rent)?0:rent); let rentarr=Number(frm.txtArrears.value.replace(/[0-9\.]/g,'')); ttl+=(isNaN(rentarr)?0:rentarr);
	if(ttl!=amt){err+="Rent amount received has not been distributed to arrears or/and monthly rent.\n";  frm.txtRent.style.background='Yellow'; frm.txtArrears.style.background='Yellow';}
	let arrbal=Number(frm.txtArrBal.value.replace(/[0-9\.]/g,'')); arrbal=isNaN(arrbal)?0:arrbal;
	if(arrbal>0 && arrbal<rentarr){err+="Arrears paid can\'t be higher than arrears B/F. The correct arrears has been set";frm.txtArrears.value=addCommas(arrbal);calcTotal(frm.txtArrears);}
	if(err.length==0){document.querySelector('#cboBank').disabled=false; document.querySelector('#txtModeNo').disabled=false; return true;}
	else{alert('CORRECT THE FOLLOWING ERRORS BEFORE SAVING\n'+err); return false;}
} function showDelete(p){
	if(p==0){alert('Sorry, You do not have the priviledges to delete tenant.');}else{if(confirm('Are you sure you want to delete this tenant? \nClick OK to type reason for delete.')){
			document.querySelector("#divDelTenant").style.display='block'; document.querySelector("#divBtns").style.visibility='hidden';}}
} function cancelDel(){	document.querySelector("#divDelTenant").style.display='none'; document.querySelector("#divBtns").style.visibility='visible';
} function checkRmks(txt){let rmks=txt.value.replace(/[^a-z\ \,\.\-]/gi,''); txt.value=rmks;
	if (rmks.length>10) document.querySelector('#btnDelete').disabled=false; else document.querySelector('#btnDelete').disabled=true;
} function checkMode(cbo){let mode=cbo.value.toLowerCase().trim();
	if(mode=='cash'){ document.querySelector('#txtModeNo').value=''; document.querySelector('#txtModeNo').readOnly=true; document.querySelector('#cboBank').value=0;
		document.querySelector('#cboBank').disabled=true; document.querySelector('#txtBC').value='0.00';	document.querySelector('#txtBC').readOnly=true;
	}else if(mode=='mfees'){document.querySelector('#txtModeNo').readOnly=false; document.querySelector('#cboBank').value=0;	document.querySelector('#cboBank').disabled=true;
		document.querySelector('#txtBC').value='0.00';	document.querySelector('#txtBC').readOnly=true;
	}else{document.querySelector('#txtModeNo').readOnly=false;	document.querySelector('#cboBank').disabled=false;	document.querySelector('#txtBC').readOnly=false;}
}function getTotal(){let ttl=0, amt=parseFloat(document.querySelector("#txtAmt").value.replace(/[^0-9\.]/g,''));	ttl+=(isNaN(amt)?0:amt);
	amt=parseFloat(document.querySelector("#txtBC").value.replace(/[^0-9\.]/g,''));	ttl+=(isNaN(amt)?0:amt); document.querySelector("#txtTtlAmt").value=addCommas(ttl);
}function distrAmt(txt){
	getTotal(); let amt=parseFloat(txt.value.replace(/[^0-9\.]/g,'')); amt=isNaN(amt)?0:amt; if(amt>0){ let arr=parseFloat(document.querySelector("#txtArrBal").value.replace(/[^0-9\.]/g,''));
	if(arr>0){let ramt=(arr>=amt?amt:arr);document.querySelector("#txtArrears").value=addCommas(ramt); amt-=ramt;} document.querySelector("#txtRent").value=addCommas(amt);}
	calcTotal(document.querySelector("#txtRent"));
}
