function addCommas(nStr){nStr+='';	nStr=(nStr.indexOf('.')>-1?nStr:(nStr+'.00')); var x=nStr.split('.'),x1=x[0],x2=x.length>1?('.'+x[1]):''; var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');} return x1+x2;
}function checkInput(ch,ob){var invalidChars; invalidChars=(ch==0?/[^0-9\.\,]/g:/[^0-9]/g);
	if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,"");	ob.value=a;}if (ob.length==0){ob.value=(ch==0?'0.00':'');	}
}function calcVotes(pos){var i=0,lmt=parseInt(document.getElementById("txtNoV").value),locked=document.getElementById("txtLocked").value.split(/\=/g); //prepos=arrpos=medpos=burspos=xtraunipos
	var err=cmpAmount(pos,parseInt(locked[0])); if (err.length>5) alert(err);//cant paymore than receivable amount on any other A/Cs
	lmt=isNaN(lmt)?0:lmt; calcTotal(lmt);
}function cmpAmount(pos,prep){
	var bal=Number(document.getElementById("txtBal_"+pos).value.trim().replace(/[^0-9\.]/g,'')),curr=Number(document.getElementById("txtCurr_"+pos).value.trim().replace(/[^0-9\.\-]/g,''));
	var amt=Number(document.getElementById("txtAmt_"+pos).value.trim().replace(/[^0-9\.\-]/g,'')); bal=isNaN(bal)?0:bal;	curr=isNaN(curr)?0:curr;	amt=isNaN(amt)?0:amt;
	if(amt>(bal+curr) && pos!==prep){ document.getElementById("txtAmt_"+pos).value=addCommas(curr.toFixed(2));
		return 'Sorry, You can not recieve more than votehead balance.\nThe previous balance has been reset.';//cant paymore than receivable amount on any other A/Cs
	}else return '';
}function calcTotal(nov){
	var ttl=i=amt=0;
	for (var i=0;i<nov;i++){amt=Number(document.getElementById("txtAmt_"+i).value.replace(/[^0-9\.]/g,'')); amt=isNaN(amt)?0:amt; ttl+=amt;} document.getElementById("txtTtl_2").value=addCommas(ttl.toFixed(2));
	var amt=Number(document.getElementById("txtTtl_1").value.replace(/[^0-9\.]/g,'')); amt-=ttl; document.getElementById("txtDistrBal").value=addCommas(amt.toFixed(2));
}function SaveFeeRecord(theForm){ var err='',lmt=parseInt(document.getElementById("txtNoV").value),locked=document.getElementById("txtLocked").value.split(/\=/g); lmt=isNaN(lmt)?0:lmt;//prepos=arrpos=medpos=burspos=xtraunipos	
	for(var i=0;i<lmt;i++){ let er=cmpAmount(i,parseInt(locked[0])); if(er.length>2) err+=er+"\n";} calcTotal(lmt);
	var bal=Number(document.getElementById("txtDistrBal").value.trim().replace(/[^0-9\.]/g,'')),err='';
	bal=isNaN(bal)?0:bal; if (bal!==0) err+="Sorry, You MUST correctly distribute the fees to voteheads before saving!!\n";
	if(err.length>0){alert('THE FOLLOWING ERROR MUST BE CORRECTED BEFORE SAVING.\n'+err); return false;
	}else{return true;}
}
