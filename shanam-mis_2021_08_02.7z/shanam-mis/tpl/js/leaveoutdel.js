function validateData(theForm) {
	var reason = "";
	var reas=theForm.txtReason.value;
	if (reas.length<7){
		reason+='The delete reason for deleting the leaveout MUST be valid';
		theForm.txtReason.style.background='Yellow';
	}else{
		theForm.txtReason.style.background='White';
	}
	reason += validateString(theForm.txtReason);
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateString(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = "The reason for deleting leaveout session contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}