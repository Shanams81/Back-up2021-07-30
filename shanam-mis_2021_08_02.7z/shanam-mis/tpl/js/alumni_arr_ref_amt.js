function addCommas(nStr){
	nStr+='';
	let x=nStr.split('.');
	let x1=x[0];
	let x2=x.length>1?('.'+x[1]):'';
	let rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkNumber(ob){
	let invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0.00";
	}
}
function enableSave(){
	let rmks=document.getElementById('txtRmks').value.replace(/[^a-z\,\.\ ]/gi,'');
	if(rmks.length>10){
		document.getElementById('cmdSave').disabled=false;
	}else{document.getElementById('cmdSave').disabled=true;}
	document.getElementById('txtRmks').value=rmks;
}
function validateData(frm){
	let change=false, err='',len=Number(document.getElementById('txtMax').value.trim()); len=isNaN(len)?0:len;
	let prevRef=0, prevArr=0, curRef=0, curArr=0;
	for(let index=0;index<len;index++){
		prevRef=Number(document.getElementById('txtPRef_'+index).value.replace(/[^0-9\.]/g,''));
		curRef=Number(document.getElementById('txtRef_'+index).value.replace(/[^0-9\.]/g,''));
		prevArr=Number(document.getElementById('txtPArr_'+index).value.replace(/[^0-9\.]/g,''));
		curArr=Number(document.getElementById('txtArr_'+index).value.replace(/[^0-9\.]/g,''));
		if(curRef>0 && curArr>0){
			err+='The alumni can not have refund and arrears in the same financial year.\n';
			document.getElementById('txtRef_'+index).style.background='magenta';
			document.getElementById('txtArr_'+index).style.background='magenta';
		}
		if(prevRef!==$curRef){change=true; break;}
		if(prevArr!==$curArr){change=true; break;}
	}if(!change){
		err+='There MUST be a change in Arrears or Refunds before saving.\n';
		for(let index=0;index<len;index++){
			document.getElementById('txtRef_'+index).style.background='Yellow';
			document.getElementById('txtArr_'+index).style.background='Yellow';
		}
	}
	if(document.getElementById('txtRmks').value.trim().length<10){
		err+='The reason for arrears/refund change is too short.\n';
		document.getElementById('txtRmks').style.background='Yellow';
	}
	if(err.length==0){
		return true;
	}else{
		alert('The following error(s) MUST be corrected before saving.\n'+err);
		return false;
	}	
}