function canadd(pr) {
    if (pr===0) {alert("Sorry, you do not have the priviledges to receive alumni arrears");  return false;
    } else { return true; }
}function canedit(pr) {
    if (pr===0) {alert("Sorry, you do not have the priviledges to edit the arrears record");  return false;
    } else { return true; }
}function myArrFunction(){
    let input=document.getElementById("txtArrFind").value.toUpperCase(),tr=document.getElementById("arrTable").getElementsByTagName("tr"),td,i,nop=0;
    let a=(document.getElementById("radArrAdmNo").checked?2:(document.getElementById("radArrRecNo").checked?0:3));
    for(i=0;i<tr.length;i++){td=tr[i].getElementsByTagName("td")[a];
        if (td){
            if(a===1 || a===2){if(td.innerHTML.trim()==input){tr[i].style.display=""; nop++;}  else tr[i].style.display="none";
            }else{if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display=""; nop++;} else tr[i].style.display="none"; }
        }
    }document.getElementById("spArrTotal").innerHTML=nop+' Alumni Fee Arrears Recovery Record(s).';
}function clrArrText(){document.getElementById("txtArrFind").value=''; document.getElementById("txtArrFind").focus();}
function myRefFunction(txt){
    let input=txt.value.toUpperCase(),tr=document.getElementById("refTable").getElementsByTagName("tr"),td, i,nop=0;
    let a=(document.getElementById("radRefVNo").checked?0:(document.getElementById("radRefIDNo").checked?2:(document.getElementById("radRefAdmNo").checked?3:4)));
    for(i=0;i<tr.length;i++){ td=tr[i].getElementsByTagName("td")[a];
        if (td){
            if(a<4){ if(td.innerHTML.trim()==input){tr[i].style.display=""; nop++;} else tr[i].style.display="none";
            }else{if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display=""; nop++;}  else tr[i].style.display="none"; }
        }
    }document.getElementById("spRefTotal").innerHTML=nop+' Fee Refund Record(s).';
}
function clrRefText(){document.getElementById("txtRefFind").value=''; document.getElementById("txtRefFind").focus();}
