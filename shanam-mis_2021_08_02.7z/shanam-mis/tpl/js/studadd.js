function candel(sb){if(sb==0){alert("You do not have the priviledge to delete this record"); return false;
  }else{if (confirm("Are you sure you want to delete this record?\nClick OK to delete otherwise click Cancel.")) return true; else return false	}
}function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
    var mylistbox = document.getElementById(listboxID);	if(mylistbox == null) return 1;
    while(mylistbox.length > 0) mylistbox.remove(0);	return 1;
}function filldays(listboxID){
    var i=ClearCont(listboxID),yr=parseInt(document.getElementById("cboYr").value),mon=document.getElementById("cboMon").value,n=noofdays(yr,mon),htmlSelect=document.getElementById(listboxID);
    for (var i=n;i>0;i--){selectBoxOption = document.createElement("option");	selectBoxOption.value=selectBoxOption.text=i;	htmlSelect.add(selectBoxOption);}
}function noofdays(y,m){
    switch (m){
        case '01': d=31; break;	case '02': if(((y%4 == 0) && (y%100 != 0)) || (y%400 == 0)) d=29; else d=28; break;	case '03': d=31; break;	case '04': d=30; break;	case '05': d=31; break;
        case '06': d=30; break;	case '07': d=31; break;	case '08': d=31; break;	case '09': d=30; break;	case '10': d=31; break;	case '11': d=30; break;	case '12': d=31; break;default: d=1; break;
    }	return d;
}function validateFormOnSubmit(theForm) {var reason="";
    if ((theForm.txtPAddress.value.length<4) || (theForm.txtPAddress.value=='P.O Box')){reason+="Postal address you entered is invalid\n";theForm.txtPAddress.style.background='Yellow';}
    reason+=validateUsername(theForm.txtSurname); reason+=validateUsername(theForm.txtONames); 	reason+=validateUsername(theForm.txtGuardian); 	reason+=validateUsername(theForm.txtLocation);
    reason += validateUsername(theForm.txtSubLocation); 	reason+=validateUsername(theForm.txtVillage); 	if(theForm.txtBirthNo.value.length>0)reason += validateNo(theForm.txtBirthNo);
    if (theForm.txtTelNo.value.length>1) reason+=validateNo(theForm.txtTelNo); reason+=validateNo(theForm.cboCounty);	reason+=validateNo(theForm.cboConst);	reason+=validateNo(theForm.cboWard);
    if (reason!=""){alert("Some fields need correction:\n" + reason);	return false;}else return true;
}function validateUsername(fld){	var error="",illegalChars = /\d/; // allow letters, numbers, and underscores
    if(fld.value==""){fld.style.background='Yellow';error="You didn't enter the right information.\n";
    }else if(fld.value.length<5){fld.style.background='Yellow';error="The information is the wrong length.\n";
    }else if(illegalChars.test(fld.value)){fld.style.background='Yellow';error="The information contains illegal characters.\n"} else fld.style.background = 'White'; return error;
}function validateNo(fld){var error="",stripped=fld.value.replace(/[^0-9]/g, '');
    if(fld.value==""){error="You didn't not enter arrears. Enter 0 if the student has no arrears.\n";	fld.style.background='Yellow';
    }else if (isNaN(parseInt(stripped))){error="The amount contains illegal characters.\n"; fld.style.background='Yellow';}	return error;
}function loadClasses(cbo){ var lvl=parseInt(cbo.value.trim());
  if (!isNaN(lvl)){var nocache=Math.random()*10000; //stop caching
    if (window.XMLHttpRequest) xmlhttp = new XMLHttpRequest(); else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
        xmlhttp.onreadystatechange=function(){if (this.readyState==4 && this.status==200) document.getElementById("clsNames").innerHTML=this.responseText;};
        xmlhttp.open('GET','ajax/clsload.php?q=0-'+lvl+'-'+nocache,true); xmlhttp.send();
    }
}
