function Votes(vno,acc,descr){this.vno=vno;	this.acc=acc;	this.descr=descr;} var votes=[];
function checkInput(ch,ob){
    var invalidChars; invalidChars=(ch==0?/[^0-9\+]/g:(ch==1?/[^0-9\.\,]/g:/[^a-zA-Z\.\'\ ]/g));
    if (invalidChars.test(ob.value)){
            var a=ob.value.replace(invalidChars,"");
            ob.value=a;
    }if (ob.length==0){
            ob.value=(ch==0?'':'0.00');
    }
}
function showDetails(txt){
    var idno=txt.value.replace(/[^0-9]/g,'');
    var nocache = Math.random() * 10000; //stop caching 
    if(idno.length>0){
            if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    }xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200){
                var n=this.responseText; n=n.toUpperCase();
                if (n!=='0-0-0'){
                    var dat=n.split(/\-/g); document.getElementById("txtName").readOnly=true; 	document.getElementById("txtName").value=dat[0];
                    document.getElementById("txtTelNo").readOnly=true;		document.getElementById("txtTelNo").value=dat[1]; 
                    document.getElementById("txtAddress").readOnly=true; 	document.getElementById("txtAddress").value=dat[2];
                }else{
                    document.getElementById("txtName").readOnly=false; 	document.getElementById("txtTelNo").readOnly=false;
                    document.getElementById("txtAddress").readOnly=false;
                }
        }
    };
    xmlhttp.open('GET','ajax/showBursBal.php?q=3-'+idno+'-'+nocache,true); xmlhttp.send();
    }
}
function clrCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
    var mylistbox = document.getElementById(listboxID);
    if(mylistbox == null) return 1;
    while(mylistbox.length > 0) mylistbox.remove(0);
    return 1;
}
function showVotes(cbo){
    clrCont("cboVote");
    var ac=parseInt(cbo.value);
    if(ac>0){
        var l=votes.length,a=0,htmlSelect=document.getElementById("cboVote"); 
        while(a<l){
            if(votes[a].acc==ac){	
                selectBoxOption = document.createElement("option");
                selectBoxOption.value = votes[a].vno;
                selectBoxOption.text = votes[a].descr;
                htmlSelect.add(selectBoxOption);
            }a++;
        }	
    }else alert("Select a valid account. Voteheads have not been displayed!!");	
}
function showHireDetails(cbo){
	var prod=cbo.value.trim().toUpperCase();
	if(prod==="HIRE SERVICES") document.getElementById("spHire").style.display='block';
	else document.getElementById("spHire").style.display='none';
}
function actPytFrm(cbo){
	var pf=cbo.value.trim().toUpperCase(); 				document.getElementById("txtCheNo").readOnly=true; document.getElementById("spKind").style.display='none';
	document.getElementById("cboBank").disabled=true; 	document.getElementById("txtBC").readOnly=true;
	if(pf!="CASH" && pf!='KIND'){
		document.getElementById("txtCheNo").readOnly=false;
		if (pf!="MFEES") document.getElementById("cboBank").disabled=false;
		if (pf=="CHEQUE") document.getElementById("txtBC").readOnly=false;
	}else if(pf=="KIND") document.getElementById("spKind").style.display='block';
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function calcTtl(){
	var ttl=0,amt=Number(document.getElementById("txtAmt").value.replace(/[^0-9\.]/g,'')); ttl+=isNaN(amt)?0:amt;
	amt=Number(document.getElementById("txtBC").value.replace(/[^0-9\.]/g,'')); ttl+=isNaN(amt)?0:amt;
	document.getElementById("txtTtl").value=addCommas(ttl.toFixed(2));
}
function checkAnalysisData(frm){
	var dt1=frm.dtpStart.value.trim().split(/\-/g);	var dt2=frm.dtpEnd.value.trim().split(/\-/g); var err="";
	var dt1=new Date(dt1[2],dt1[1],dt1[0]); 		var dt2=new Date(dt2[2],dt2[1],dt2[0]); 
	var days=Math.round((dt2.getTime()-dt1.getTime())/8.64e7);
	if (days<0){
		err+="Invalid range of dates have been selected.\n";	frm.dtpStart.style.background='yellow'; 	frm.dtpEnd.style.background='yellow';
	}else{frm.dtpStart.style.background='white'; 	frm.dtpEnd.style.background='white';}
	if (frm.cboAC.value.length==0){
		err+="Select Votehead Account whose income is to be viewed.\n"; 	frm.cboAC.style.background='yellow'; 
	}else frm.cboAC.style.background='white'; 
	if(err.length>0){
		alert("ADJUST THE FOLLOWING REPORT CHOICES BEFORE CONTINTUING:\n"+err); return false;
	}return true;
}
function canEdit(pr) {
	if (pr == 0){
		alert("Sorry, you do not have the priviledges to edit fees record.");
		return false;
	}else{
		return true;
	}
}
function findReceipt(txt){
	var input, table, tr,td, i,nos=0,found=false,amt=0; var ttl=0;
	var a=(document.getElementById("radRecNo").checked?0:(document.getElementById("radIDNo").checked?2:3)); // Fee such criteria
	input=document.getElementById("txtFind").value.toUpperCase().trim();	table=document.getElementById("tabReceipt"); 	tr=table.getElementsByTagName("tr");
	for(i=1;i<(tr.length-1);i++){
		td=tr[i].getElementsByTagName("td")[a]; found=false;
		if (td){
		 	var data=td.innerHTML.trim();
		 	if (input.length==0) found=true;
		 	else if((a==0 || a==2) && data==input) found=true;
		 	else if(a==3 && data.toUpperCase().indexOf(input)>-1) found=true;
			if(found){
			 	tr[i].style.display=""; nos++;
				amt=Number(tr[i].getElementsByTagName("td")[8].innerHTML.replace(/[^0-9\.]/g,'')); ttl+=isNaN(amt)?0:amt;
			}else tr[i].style.display="none";
		}
	} document.getElementById("spTtl").innerHTML=addCommas(ttl.toFixed(2));	document.getElementById("spNoF").innerHTML=nos+' Fees Payment Record(s).';		
}
function clrFind(){
	document.getElementById("txtFind").value='';
	document.getElementById("txtFind").focus();
}
function validateData(frm){
	var err='';
	var pytfrm=frm.cboMode.value.toUpperCase();
	if (frm.txtName.value.length<8){
		err+="Sorry, You MUST type the full name of the income source before saving!!\n";
 		frm.txtName.style.background='Yellow';
	}if (frm.txtTelNo.value.length<10){
		err+="Sorry, You MUST type valid Telephone Number of the parent before saving!!\n";
 		frm.txtTelNo.style.background='Yellow';
	}if ((pytfrm !="CASH") && (pytfrm !="KIND")){
	 	var trno=frm.txtCheNo.value.trim().length;
	 	if (trno<4){
	 		err+="Sorry, You MUST enter transaction/ cheque no. of this payment before saving!!\n";
	 		frm.txtCheNo.style.background='Yellow';
		}if (pytfrm=="CHEQUE" || pytfrm=="MONEY ORDER" || pytfrm=="DIRECT BANKING"){
			var bank=parseInt(frm.cboBank.value);
			if (isNaN(bank) || bank==0){
				err+="Sorry, You MUST choose the bank  of this Cheque/Bankslip/Money Order before saving!!\n";
	 			frm.cboBank.style.background='Yellow';
			}else frm.cboBank.style.background='white';
		}
	}if (pytfrm=="KIND"){
	 	if(frm.txtKind.value.length<10){
			err+="Sorry, You MUST type the description of fee receipt in kind before saving!!\n";
		 	frm.txtKind.style.background='Yellow';
		}if(frm.txtIDNo.value.length<7){
			err+="Sorry, You MUST type the ID No. of the one paying in Kind!!\n";
		 	frm.txtIDNo.style.background='Yellow';
		}
	}if (frm.txtRmks.value.length<10){
		err+="Sorry, You MUST type the remarks/narration for on income before saving!!\n";
 		frm.txtRmks.style.background='Yellow';
	}if (frm.cboProduct.value.trim().toUpperCase()=='HIRE SERVICES'){
		var dt1=frm.dtpHiredOn.value.trim().split(/\-/g);	var dt2=new Date(); 	var dt1=new Date(dt1[2],dt1[1],dt1[0]);	 var days=Math.round((dt1.getTime()-dt2.getTime())/8.64e7);
		if(days<0){
			err+="Sorry, Date of hiring the service has to be ahead.!!\n";
	 		frm.dptHiredOn.style.background='Yellow';
		}
	}var amt=Number(frm.txtAmt.value.replace(/[^0-9\.]/g,'')); 
 	if (amt==0 || isNaN(amt)){
		err+="Sorry, You MUST enter amount of income received before saving!!!\n";
		document.getElementById("txtAmt").style.background='Yellow';
	}if(err.length>0){
		alert('The following MUST be corrected before saving.\n'+err); return false;
	}else{
		document.getElementById("cboBank").disabled=false; return true;
	}
}
function showDelete(v){
	if(v==1){
	 	if(confirm("You are about to cancel/delete this income.\nClick OK to continue with deletion.")) document.getElementById('otherIncomeDel').style.display='block';
	}else{
		document.getElementById('otherIncomeDel').style.display='none';
		alert('Sorry, You do not have the priviledge to delete income.');
	} 
}
function confirmDel(v){
	if(v==0){
		alert('Sorry, You do not have the priviledge to delete income.'); return false;
	}else{
		var rmks=document.getElementById('txtReason').value.trim();
		if(rmks.length<10){
			alert('Sorry, You MUST type valid reason for deleting this income.'); document.getElementById('txtReason').style.background='yellow'; return false;
		}else return true;
	}
}