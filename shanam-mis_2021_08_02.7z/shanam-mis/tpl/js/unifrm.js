function Uniform(unino,name,units,amt){this.unino=unino; this.name=name; this.units=units; this.amt=amt;} var uniform=[];
function getLink(){
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    } return xmlhttp;
}
function rptOrders(opt){//opt 1- Uniform Orders, 2- List of Uniforms
    let date1=document.getElementById('txtFrom').value;     let date2=document.getElementById('txtTo').value;
    var nocache = Math.random() * 10000; //stop caching
    var xmlhttp=getLink();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200){
            document.getElementById("divUniRpt").innerHTML = this.responseText;
            document.getElementById("printH").style.display='block';
        }
    };
    xmlhttp.open('GET','rpts/unifrmrpt.php?q='+opt+'~'+date1+'~'+date2+'~'+nocache,true);
    xmlhttp.send();
}
function delConfirm(){
    var c=confirm("You are about to delete this uniform definition.\nAre you sure of this action?");
    if(c==true) return true; else return false;
}
function validateFormOnSubmit(opt,theForm) {
    var reason = "";
    if(opt==0){
      reason += validateUsername(theForm.txtUnifrm);
      reason += validateNo(theForm.txtPrice);
    }else{
        reason += validateUsername(theForm.txtUnifrm1);
        reason += validateNo(theForm.txtPrice1);
    }
    if (reason != "") {
    alert("Some fields need correction:\n" + reason);
    return false;
    } else {
            return true;
    }
}
function validateUsername(fld) {
    var error = "";
    var illegalChars = /\d/; // allow letters, numbers, and underscores
    if (fld.value == "") {
        fld.style.background = 'Yellow';
        error = "You didn't type uniform desciption.\n";
    } else if (fld.value.length < 5) {
        fld.style.background = 'Yellow';
        error = "The uniform description typed is too short.\n";
    } else if (illegalChars.test(fld.value)) {
        fld.style.background = 'Yellow';
        error = "The uniform description contains illegal characters.\n";
    } else {
        fld.style.background = 'White';
    } return error;
}
function validateNo(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');
    if (fld.value == "") {
    error = "You didn't the price of the uniform.\n";
    fld.style.background = 'Yellow';
    } else if ((isNaN(parseInt(stripped))) || (parseInt(stripped)==0)) {
    error = "The unit price of the uniform must be numeric.\n";
    fld.style.background = 'Yellow';
    } else {
    fld.style.background = 'White';
    }
    return error;
}
function addCommas(nStr){
    nStr+='';
    var x=nStr.split('.');
    var x1=x[0];
    var x2=x.length>1?('.'+x[1]):'';
    var rgx=/(\d+)(\d{3})/;
    while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
    return x1+x2;
}
function editUniform(unino){
    var i=0,found=false,len=uniform.length;
    while(!found && i<len){
        if(unino==uniform[i].unino){
            found=true;         document.getElementById("txtUniNo1").value=unino;     document.getElementById("txtUnifrm1").value=uniform[i].name;
            document.getElementById("txtPrice1").value=uniform[i].amt;                document.getElementById("cboUnits1").value=uniform[i].units;
        }i++;
    }
    if(found) document.getElementById('divEditPrice').style.display='block';
}
function newOrder(yr){
    var adm=parseInt(document.getElementById("txtAdmNo").value.trim());
    if (!isNaN(adm)) return true;
    else {
        alert('Enter admission number of the student making the order.');
        return false;
    }
}
function checkInput(dat){
    var invalidChars=/[^0-9]/gi;
    if (invalidChars.test(dat)){
        return dat.replace(invalidChars,"");
    }else return dat;
}
function findStud(ch,txt) { //ch 0- find stud, 1- view uniform
    var adm; if(ch==0){adm=parseInt(checkInput(txt.value.trim())); if (!isNaN(adm)) txt.value=adm; else txt.value='';} else adm=txt;
    document.getElementById("btnNewOrder").disabled=true;
    if (!isNaN(adm)){
        var nocache = Math.random() * 10000; //stop caching
        var xmlhttp=getLink();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200){
                if (ch==0){
                    var disp=this.responseText;
                    document.getElementById("spStud").innerHTML = disp;
                    if(disp.indexOf("ADM. NO.")>-1) document.getElementById("btnNewOrder").disabled=false;
                    else document.getElementById("btnNewOrder").disabled=true;
                } else{
                    document.getElementById("spListUniform").innerHTML = this.responseText;
                    document.getElementById("printOrders").style.display='block';
                }
            }
        };
        xmlhttp.open('GET','ajax/showstudname.php?q='+ch+'-'+adm+'-0-'+nocache,true);
        xmlhttp.send();
    }else if(ch==0){
        txt.value='';
        document.getElementById("spStud").innerHTML='UNIFORM ORDERS BY ALL STUDENTS'; $adm='%';
    }
    if(ch==0){
        showUnifrmOrders(adm); document.getElementById("spListUniform").innerHTML = '';
    }
}
function showUnifrmOrders(adm) {
    var table, tr,td, i,nos=0,ttl=0;
    table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr");
    for(i=1;i<(tr.length-1);i++){
        td=tr[i].getElementsByTagName("td")[1];
        if (td){
            if(Number(td.innerHTML.trim())==adm || isNaN(adm)){
                tr[i].style.display=""; nos++; var amt=Number(tr[i].getElementsByTagName("td")[3].innerHTML.replace(/[^0-9\.]/,'')); ttl+=isNaN(amt)?0:amt;
            }else tr[i].style.display="none";
        }
    }document.getElementById("spNoU").innerHTML=nos+' Medical Bill(s)'; document.getElementById("spSubTtl").innerHTML=addCommas(ttl.toFixed(2));
}
