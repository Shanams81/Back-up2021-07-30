function Consti(sno,name,county){this.sno=sno; this.name=name; this.county=county;}
function MCA(sno,name,consti){this.sno=sno; this.name=name; this.consti=consti;}
function loadConstituency(cbo){
	var c=cbo.value.trim(),l=mp.length;
	if(c.length>0){
		ClrCont("cboConst"); let htmlSelect=document.getElementById("cboConst");
		for(var i=0;i<l;i++) if(c==mp[i].county) addOptions("cboConst",mp[i].sno,mp[i].name);
		loadWards(htmlSelect);
	}
}
function loadWards(cbo){
	var c=cbo.value.trim(),l=mca.length;
	if(c.length>0){
		ClrCont("cboWard");
		for(var i=0;i<l;i++) if(c==mca[i].consti) addOptions("cboWard",mca[i].sno,mca[i].name);
	}
}
function addOptions(cbo,val,txt){
	let htmlSelect=document.getElementById(cbo);
	selectBoxOption = document.createElement("option");
	selectBoxOption.value = val;
	selectBoxOption.text = txt;
	htmlSelect.add(selectBoxOption);	
}
function ClrCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}