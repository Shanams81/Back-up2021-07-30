function canedit(a){ //a==1 then can edit otherwise can not
	if (a==0){alert("Sorry, you do not have the priviledges to edit student record. Contact your Admin/ Bursar/ Senior Teacher");return false;}else{return true;}
}function candelete(a){ //a==1 then can delete otherwise can not
	if (a==0){alert("Sorry, you do not have the priviledges to delete student record. Contact your Admin/ Bursar/ Senior Teacher");	return false;	}else{
	 	var ans=confirm("Are you sure you want to delete this student from this financial year?\nClick OK to delete otherwise click Cancel.");
	 	if (ans==true){return true;}else{	return false;	}
	}
}
