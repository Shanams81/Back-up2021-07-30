function checkInput(ob){
 	var a=ob.value;
 	var b=a;
	var invalidChars=/[^0-9]/gi;
	if (invalidChars.test(a)){
		a=a.replace(invalidChars,"");
	}ob.value=a;
}
function checkData(frm){
	let err='';
	err+=validateString(frm.txtScNm);	err+=validateString(frm.txtScAbb);	err+=validateString(frm.txtMotto);	err+=validateString(frm.txtScNm);
	err+=validateString(frm.txtPrinc);
	if(isNaN(Number(frm.txtNSSRate.value.replace(/[^0-9\.]/,'')))){
		err+="NSSF Deduction Rate MUST be captured.\n"; 	frm.txtNSSRate.style.background='Yellow';
	}if(isNaN(Number(frm.txtMPR.value.replace(/[^0-9\.]/,'')))){
		err+="Monthly PAYE Relief MUST be captured.\n"; 	frm.txtMPR.style.background='Yellow';
	}if(isNaN(Number(frm.txtImprest.value.replace(/[^0-9]/,''))) || Number(frm.txtImprest.value.replace(/[^0-9]/,''))<1){
		err+="Maximum No. of Imprests held MUST be captured.\n"; 	frm.txtImprest.style.background='Yellow';
	}if(isNaN(Number(frm.txtFinYr.value.replace(/[^0-9\.]/,'')))){
		err+="Current Financial Year MUST be captured.\n"; 	frm.txtFinYr.style.background='Yellow';
	}
	if(err.length==0){
		return true;
	}else{
		alert("The following errors MUST be corrected before saving:\n"+err);
		return false;
	}	
}
function validateString(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " You didn't enter the right information.\n";
	} else if (fld.value.length < 3) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
