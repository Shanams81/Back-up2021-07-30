function showFS(dat,ac) { var nocache = Math.random() * 10000; //stop caching
	if (window.XMLHttpRequest){xmlhttp = new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    } else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
    }xmlhttp.onreadystatechange=function(){if(this.readyState==4 && this.status==200) document.getElementById("divFeeStruct").innerHTML = this.responseText;};
    xmlhttp.open('GET','ajax/showfeestruct.php?q='+dat+'-'+ac+'-'+nocache,true);
	xmlhttp.send();
}function closeFS(){document.getElementById('divFeeStruct').innerHTML='Fee Structure Details';
}function canedit(dat,ac,pr){if (pr==0) {alert("Sorry, you do not have the priviledges to edit the record"); return false; } else {showFS(dat,ac);return true;	}
}function canvi(pr) {if (pr==0) { alert("Sorry, you do not have the priviledges to view record"); return false; }else{return true;}
}function addCommas(nStr){nStr+=''; var x=nStr.split('.'),x1=x[0], x2=x.length>1?('.'+x[1]):'';	var rgx=/(\d+)(\d{3})/; while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}	return x1+x2;
}function checkData(ob){var invalidChars=/[^0-9\.\,]/gi; if (invalidChars.test(ob.value)){var a=ob.value.replace(invalidChars,"");ob.value=addCommas(a);}	if (ob.length==0){ob.value="0.00";}
}function getTotal(pos,v){ var t1=Number(document.getElementById("txtT1_"+pos).value.replace(/[^0-9^\.]/g,'')),t2=Number(document.getElementById("txtT2_"+pos).value.replace(/[^0-9^\.]/g,''));
	var t3=Number(document.getElementById("txtT3_"+pos).value.replace(/[^0-9^\.]/g,'')),ttl=(t1+t2+t3),termttl=[0,0,0,0];
	document.getElementById("txtTtl_"+pos).value=addCommas(ttl.toFixed(2));    document.getElementById("btnRefreshStudFee").disabled=true;
	for (var i=0;i<v;i++){ t1=Number(document.getElementById("txtT1_"+i).value.replace(/[^0-9^\.]/g,''));  t2=Number(document.getElementById("txtT2_"+i).value.replace(/[^0-9^\.]/g,''));
    t3=Number(document.getElementById("txtT3_"+i).value.replace(/[^0-9^\.]/g,''));  var y=Number(document.getElementById("txtTtl_"+i).value.replace(/[^0-9^\.]/g,''));
    termttl[0]+=(isNaN(t1)?0:t1); termttl[1]+=(isNaN(t2)?0:t2);    termttl[2]+=(isNaN(t3)?0:t3);   termttl[3]+=(isNaN(y)?0:y);
	}document.getElementById("txtTermTtl_0").value=addCommas(termttl[0].toFixed(2)); document.getElementById("txtTermTtl_1").value=addCommas(termttl[1].toFixed(2));
 	document.getElementById("txtTermTtl_2").value=addCommas(termttl[2].toFixed(2)); document.getElementById("txtTermTtl_3").value=addCommas(termttl[3].toFixed(2));
}function getTotal1(pos,ac,v){var t1=Number(document.getElementById("txtT1_"+ac+"_"+pos).value.replace(/[^0-9^\.]/g,''));	var t2=Number(document.getElementById("txtT2_"+ac+"_"+pos).value.replace(/[^0-9^\.]/g,''));
	var t3=Number(document.getElementById("txtT3_"+ac+"_"+pos).value.replace(/[^0-9^\.]/g,''));	var ttl=t1+t2+t3; document.getElementById("txtTtl_"+ac+"_"+pos).value=addCommas(ttl.toFixed(2));
  var termttl=[0,0,0,0];
	for (var i=0;i<v;i++){t1=Number(document.getElementById("txtT1_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));  t2=Number(document.getElementById("txtT2_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));
    t3=Number(document.getElementById("txtT3_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));  var y=Number(document.getElementById("txtTtl_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));
    termttl[0]+=(isNaN(t1)?0:t1); termttl[1]+=(isNaN(t2)?0:t2);    termttl[2]+=(isNaN(t3)?0:t3);   termttl[3]+=(isNaN(y)?0:y);
	}document.getElementById("txtTermTtl_"+ac+"_0").value=addCommas(termttl[0].toFixed(2)); document.getElementById("txtTermTtl_"+ac+"_1").value=addCommas(termttl[1].toFixed(2));
 	document.getElementById("txtTermTtl_"+ac+"_2").value=addCommas(termttl[2].toFixed(2)); document.getElementById("txtTermTtl_"+ac+"_3").value=addCommas(termttl[3].toFixed(2));
}function allowEdit(){var nac=Number(document.getElementById("txtNoAC").value.replace(/[^0-9^\.]/g,''));	nac=(isNaN(nac)?0:nac);
	for(var a=0;a<nac;a++){var nfs=document.getElementById("txtNoFS_"+a).value;	nfs=nfs.split('-');		nfs[0]=Number(nfs[0]);  nfs[0]=(isNaN(nfs[0])?0:nfs[0]);
		for(var i=0;i<nfs[0];i++){document.getElementById("txtT1_"+a+"_"+i).readOnly=false; document.getElementById("txtT2_"+a+"_"+i).readOnly=false; document.getElementById("txtT3_"+a+"_"+i).readOnly=false;}
	}document.getElementById("btnEdit1").disabled=true;	document.getElementById("btnSaveFS1").disabled=false;
}function validateData(frm){var i=0; var dat=frm.txtData.value; 		dat=dat.split('-'); 	dat[3]=Number(dat[3]); 		dat[3]=isNaN(dat[3])?0:dat[3];
	for(var a=0;a<dat[3];a++){if (Number(document.getElementById("txtT1_"+a).value.replace(/[^0-9^\.]/g,''))>=0 && Number(document.getElementById("txtT2_"+a).value.replace(/[^0-9^\.]/g,''))>=0 &&
    Number(document.getElementById("txtT3_"+a).value.replace(/[^0-9^\.]/g,''))>=0){i=0;}else{ i=1; break;}
	}if (i==0){if (confirm('The changes will affect fee definition of all students in this level.\nAre you sure of this?')){return true;}else return false;
	}else{alert('Ensure all votehead amount are correctly entered before saving.');return false;}
}
