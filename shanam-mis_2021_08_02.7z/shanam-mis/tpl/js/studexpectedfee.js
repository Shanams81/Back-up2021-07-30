function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkData(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
	}
	if (ob.length==0){
	 	a=0;
	}ob.value=addCommas(a.toFixed(2));
}
function getTotal(ac,pos,v){
	var t1=Number(document.getElementById("txtT1_"+ac+"_"+pos).value.replace(/[^0-9^\.]/g,''));	var t2=Number(document.getElementById("txtT2_"+ac+"_"+pos).value.replace(/[^0-9^\.]/g,''));
	var t3=Number(document.getElementById("txtT3_"+ac+"_"+pos).value.replace(/[^0-9^\.]/g,''));	var ttl=t1+t2+t3;
	document.getElementById("txtTtl_"+ac+"_"+pos).value=addCommas(ttl.toFixed(2));              var termttl=[0,0,0,0];
	for (var i=0;i<v;i++){
        t1=Number(document.getElementById("txtT1_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));  t2=Number(document.getElementById("txtT2_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));
        t3=Number(document.getElementById("txtT3_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));  var y=Number(document.getElementById("txtTtl_"+ac+"_"+i).value.replace(/[^0-9^\.]/g,''));
        termttl[0]+=(isNaN(t1)?0:t1); termttl[1]+=(isNaN(t2)?0:t2);    termttl[2]+=(isNaN(t3)?0:t3);   termttl[3]+=(isNaN(y)?0:y);
	}document.getElementById("txtTermTtl_"+ac+"_0").value=addCommas(termttl[0].toFixed(2)); document.getElementById("txtTermTtl_"+ac+"_1").value=addCommas(termttl[1].toFixed(2));
 	document.getElementById("txtTermTtl_"+ac+"_2").value=addCommas(termttl[2].toFixed(2)); document.getElementById("txtTermTtl_"+ac+"_3").value=addCommas(termttl[3].toFixed(2));
}
function allowEdit(){
	var nac=document.getElementById("txtNoAcc").value;	nac=nac.split('-'); nac[2]=Number(nac[2]); 	nac[2]=(isNaN(nac[2])?0:nac[2]);
	for(var a=0;a<nac[2];a++){
		var nfs=Number(document.getElementById("txtNo_"+a).value);	nfs=(isNaN(nfs)?0:nfs);
		for(var i=0;i<nfs;i++){
			document.getElementById("txtT1_"+a+"_"+i).readOnly=false; document.getElementById("txtT2_"+a+"_"+i).readOnly=false;
			document.getElementById("txtT3_"+a+"_"+i).readOnly=false; 
		}
	}document.getElementById("btnEdit1").disabled=true;	document.getElementById("btnSaveFS1").disabled=false;
}
function validateData(frm){
	var i=0; var dat=frm.txtNoAcc.value; 		dat=dat.split('-'); 	dat[2]=Number(dat[2]); 		dat[2]=isNaN(dat[2])?0:dat[2];
	for(var a=0;a<dat[2];a++){
	 	var nfs=Number(document.getElementById("txtNo_"+a).value);	nfs=(isNaN(nfs)?0:nfs);
	 	for(var b=0;b<nfs;b++){
			if (Number(document.getElementById("txtT1_"+a+"_"+b).value.replace(/[^0-9^\.]/g,''))>=0 && Number(document.getElementById("txtT2_"+a+"_"+b).value.replace(/[^0-9^\.]/g,''))>=0 && 
	        Number(document.getElementById("txtT3_"+a+"_"+b).value.replace(/[^0-9^\.]/g,''))>=0){
				i=0;	
			}else{ i=1; break;}	
		}
		if (i==1) break;
	}
	if (i==0){
		if (confirm('The changes will affect fee definition of all students in this level.\nAre you sure of this?')){
			return true;
		}else return false;
	}else{
		alert('Ensure all votehead amount are correctly entered before saving.');
		return false;
	}
}