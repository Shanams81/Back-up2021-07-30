function calcRow(acc,r){
	var sum=0,x=0;
	if (acc==1){
		var n=document.getElementById("TxtVal_"+r+"_1").value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x; 
	  	var n=document.getElementById("TxtVal_"+r+"_2").value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x; 
	  	var n=document.getElementById("TxtVal_"+r+"_3").value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x; 
	}else{
		var n=document.getElementById("TxtMis_"+r+"_1").value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x; 
	  	var n=document.getElementById("TxtMis_"+r+"_2").value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x; 
	  	var n=document.getElementById("TxtMis_"+r+"_3").value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x; 
	}
	return sum;
}
function calcCol(acc,r,c){
 	var sum=0,x=0;
	if (acc==1){
	 	for (var i=1;i<13;i++){ 
	 	 	var n=document.getElementById("TxtVal_"+i+"_"+c).value; 
	 	 	x=parseFloat(n.replace(",",""));
		  	if (!(isNaN(x))) sum+=x;
			document.getElementById("TxtVal_"+i+"_"+c).value=addCommas(n);
		}
	}else{
		for (var i=1;i<8;i++){ 
	 	 	var n=document.getElementById("TxtMis_"+i+"_"+c).value; 
	 	 	x=parseFloat(n.replace(",",""));
		  	if (!(isNaN(x))) sum+=x;
			document.getElementById("TxtMis_"+i+"_"+c).value=addCommas(n); 
		}	
	}
	return sum;
}
function Compute(r,c){
 	var sum=0; x=0;
 	//compute rows total
	var sumrow=calcRow(1,r);
	var x=sumrow.toFixed(2); //format to two decimal places
	document.getElementById("TxtVal_"+r).value=addCommas(x);
	//compute column total
	var sumcol=calcCol(1,r,c);
	var x=sumcol.toFixed(2); //format to two decimal places
	document.getElementById("TxtTotal"+c).value=addCommas(x);
	//compute grand total
	var n=document.getElementById("TxtTotal1").value; 
 	x=parseFloat(n.replace(",",""));
  	if (!(isNaN(x))) sum+=x;
	var n=document.getElementById("TxtTotal2").value; 
 	x=parseFloat(n.replace(",",""));
  	if (!(isNaN(x))) sum+=x;
	var n=document.getElementById("TxtTotal3").value; 
 	x=parseFloat(n.replace(",",""));
  	if (!(isNaN(x))) sum+=x; 
	var x=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTotal").value=addCommas(x);  
}
function MisCompute(r,c){
 	var sum=0; x=0;
 	//compute rows total
	var sumrow=calcRow(2,r);
	var x=sumrow.toFixed(2); //format to two decimal places
	document.getElementById("TxtMis_"+r).value=addCommas(x);
	//compute column total
	var sumcol=calcCol(2,r,c);
	var x=sumcol.toFixed(2); //format to two decimal places
	document.getElementById("TxtMTotal"+c).value=addCommas(x);
	//compute grand total
	var n=document.getElementById("TxtMTotal1").value; 
 	x=parseFloat(n.replace(",",""));
  	if (!(isNaN(x))) sum+=x;
	var n=document.getElementById("TxtMTotal2").value; 
 	x=parseFloat(n.replace(",",""));
  	if (!(isNaN(x))) sum+=x;
	var n=document.getElementById("TxtMTotal3").value; 
 	x=parseFloat(n.replace(",",""));
  	if (!(isNaN(x))) sum+=x; 
	var x=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtMTotal").value=addCommas(x);  
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0.00";
	}
}
function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.TxtVal_1_1);			reason += validateNo(theForm.TxtVal_1_2);		reason += validateNo(theForm.TxtVal_1_3);	
	reason += validateNo(theForm.TxtMis_1_1);			reason += validateNo(theForm.TxtMis_1_2);		reason += validateNo(theForm.TxtMis_1_3);
	reason += validateNo(theForm.TxtVal_2_1);			reason += validateNo(theForm.TxtVal_2_2);		reason += validateNo(theForm.TxtVal_2_3);	
	reason += validateNo(theForm.TxtMis_2_1);			reason += validateNo(theForm.TxtMis_2_2);		reason += validateNo(theForm.TxtMis_2_3);
	reason += validateNo(theForm.TxtVal_3_1);			reason += validateNo(theForm.TxtVal_3_2);		reason += validateNo(theForm.TxtVal_3_3);	
	reason += validateNo(theForm.TxtMis_3_1);			reason += validateNo(theForm.TxtMis_3_2);		reason += validateNo(theForm.TxtMis_3_3);
	reason += validateNo(theForm.TxtVal_4_1);			reason += validateNo(theForm.TxtVal_4_2);		reason += validateNo(theForm.TxtVal_4_3);	
	reason += validateNo(theForm.TxtMis_4_1);			reason += validateNo(theForm.TxtMis_4_2);		reason += validateNo(theForm.TxtMis_4_3);
	reason += validateNo(theForm.TxtVal_5_1);			reason += validateNo(theForm.TxtVal_5_2);		reason += validateNo(theForm.TxtVal_5_3);	
	reason += validateNo(theForm.TxtMis_5_1);			reason += validateNo(theForm.TxtMis_5_2);		reason += validateNo(theForm.TxtMis_5_3);
	reason += validateNo(theForm.TxtVal_6_1);			reason += validateNo(theForm.TxtVal_6_2);		reason += validateNo(theForm.TxtVal_6_3);
	reason += validateNo(theForm.TxtVal_7_1);			reason += validateNo(theForm.TxtVal_7_2);		reason += validateNo(theForm.TxtVal_7_3);
	reason += validateNo(theForm.TxtVal_8_1);			reason += validateNo(theForm.TxtVal_8_2);		reason += validateNo(theForm.TxtVal_8_3);
	reason += validateNo(theForm.TxtVal_9_1);			reason += validateNo(theForm.TxtVal_9_2);		reason += validateNo(theForm.TxtVal_9_3);
	reason += validateNo(theForm.TxtVal_10_1);			reason += validateNo(theForm.TxtVal_10_2);		reason += validateNo(theForm.TxtVal_10_3);
	reason += validateNo(theForm.TxtVal_11_1);			reason += validateNo(theForm.TxtVal_11_2);		reason += validateNo(theForm.TxtVal_11_3);
	reason += validateNo(theForm.TxtVal_12_1);			reason += validateNo(theForm.TxtVal_12_2);		reason += validateNo(theForm.TxtVal_12_3);
	var n=document.getElementById("TxtTotal3").value; 	var mainttl=parseFloat(n.replace(",",""));
	n=document.getElementById("TxtMTotal3").value; 		var miscttl=parseFloat(n.replace(",",""));
	if (mainttl==0 && miscttl==0) reason+="\nSorry, fee structure defined has no amount to be saved";
	if (reason != "") {
    	alert("The following fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ \+]/g, '');     
	if (fld.value == "") {
    	error = fld.name + " requires numeric data, it is currently blank.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = fld.name + " requires numeric values, your entry contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}