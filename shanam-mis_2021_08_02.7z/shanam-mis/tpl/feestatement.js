function PrintWindow()
{                      
   CheckWindowState();
   window.print();    
}
function CheckWindowState()
{            
    if(document.readyState=="complete")
    { //window.close();  
	}else {            
        setTimeout("CheckWindowState()", 5000);
    }
}       
PrintWindow();
function clickedButton(a) {
 	if (a==0){window.location = 'student.php?action=0-0';}
    if (a==1){window.location = 'feecollection.php';}
    if (a==2){window.location = 'studfee.php';}
}