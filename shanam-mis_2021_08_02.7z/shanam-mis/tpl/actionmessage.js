function actiondone(a,b){ // a = 0 is normal,1 editing and 2 deleting. b is the number of records edited or deleted
	if ((a==1) && (b>0)){
	 	alert(b+" record(s) were either added, edited or restored sucessfully.");
	}else if ((a==2) && (b>0)){
	 	alert(b+" record(s) were sucessfully deleted.");
	}else if ((a==1) && (b==0))	{
		alert("Sorry, the record has neither been added nor edited");
	}else if ((a==2) && (b==0)){
		alert("Sorry,the record has NOT been deleted");
	}		
}
