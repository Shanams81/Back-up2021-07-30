function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.TxtInst);		reason += validateNo(theForm.TxtFSNo);		reason += validateNo(theForm.TxtBBF);
  	reason += validateNo(theForm.TxtAttNo);		reason += validateNo(theForm.TxtAdm);		reason += validateNo(theForm.TxtId);
  	reason += validateNo(theForm.TxtAdmin);		reason += validateNo(theForm.TxtOle);		reason += validateNo(theForm.TxtCentre);
  	reason += validateNo(theForm.TxtLib);		reason += validateNo(theForm.TxtHostel);	reason += validateNo(theForm.TxtTuit);
  	reason += validateNo(theForm.TxtComp);		reason += validateNo(theForm.TxtCaut);		reason += validateNo(theForm.TxtTrip);
  	reason += validateNo(theForm.TxtWorks);		reason += validateNo(theForm.TxtExam);		reason += validateNo(theForm.TxtRenew);
  	reason += validateNo(theForm.TxtTShirt);	reason += validateNo(theForm.TxtAct);
  	if (parseFloat(theForm.TxtTtl.value)==0) reason+="You MUST specify fee to be paid by the students";
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (fld.value == "") {
    	error = "You didn't not enter arrears. Enter 0 if the student has no arrears.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = "The amount contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0.00";
	}
}
function Compute(k){
 	var sum=0;
	var x=0;
 	for (var i=0;i<k;i++){ 
 	 	var n=document.getElementById("TxtVal"+i).value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x;
		document.getElementById("TxtVal"+i).value=addCommas(n);
	}
	var m=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtl").value=addCommas(m);
}