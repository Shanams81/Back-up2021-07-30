function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.TxtAdmNo);
	if ((theForm.TxtPAddress.value.length<9) || (theForm.TxtPAddress.value=="P.O BOX ")){
		reason+="Postal address you entered is invalid\n";
		theForm.TxtPAddress.style.background='Yellow';
	}
	if (theForm.TxtBirthNo.value!=""){
		reason += validateNo(theForm.TxtBirthNo);
	}
	if (theForm.TxtTelNo.value!=""){
		reason += validateNo(theForm.TxtTelNo);
	}
	reason += validateUsername(theForm.TxtNames);
  	reason += validateUsername(theForm.TxtGuardian);
  	reason += validateUsername(theForm.TxtSubCounty);
  	reason += validateUsername(theForm.TxtConstituency);
  	reason += validateUsername(theForm.TxtLocation);
  	reason += validateUsername(theForm.TxtSubLocation);
  	reason += validateUsername(theForm.TxtVillage);
  	reason += validateNo(theForm.TxtMarks);
  	reason += validateUsername(theForm.TxtIllness);
  	reason += validateUsername(theForm.TxtAllergy);
  	if (reason != "") {
    	alert("The following fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " You didn't enter the right information.\n";
	} else if (fld.value.length < 4) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ \+]/g, '');     
	if (fld.value == "") {
    	error = fld.name + " requires numeric data, it is currently blank.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = fld.name + " requires numeric values, your entry contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function filldays(listboxID){
	var i=ClearCont(listboxID);
	var yr=parseInt(document.getElementById("CboYr").value);
	var mon=document.getElementById("CboMon").value;
	var n=noofdays(yr,mon);
	var htmlSelect=document.getElementById(listboxID);
	for (var i=n;i>0;i--){
		selectBoxOption = document.createElement("option");
		selectBoxOption.value = i;
		selectBoxOption.text = i;
		htmlSelect.add(selectBoxOption);
	}
}
function noofdays(y,m){
 	switch (m){
		case '01': d=31; break;
		case '02': if(((y%4 == 0) && (y%100 != 0)) || (y%400 == 0)) d=29; else d=28; break;
		case '03': d=31; break;
		case '04': d=30; break;
		case '05': d=31; break;
		case '06': d=30; break;
		case '07': d=31; break;
		case '08': d=31; break;
		case '09': d=30; break;
		case '10': d=31; break;
		case '11': d=30; break;
		case '12': d=31; break;
		default: d=1; break;
	}
	return d;
}