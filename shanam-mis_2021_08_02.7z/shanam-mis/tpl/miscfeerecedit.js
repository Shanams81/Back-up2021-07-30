function checkPyt(ob){
	var pytfrm=ob.value;
	if(pytfrm.toUpperCase()=="KIND"){
		document.getElementById("TxtCheNo").readOnly=true;
		document.getElementById("CboBank").disabled=true;
		document.getElementById("TxtBC").readOnly=true;
		document.getElementById("TxtKind").readOnly=false;
	}else if (pytfrm.toUpperCase()=="CHEQUE" || pytfrm.toUpperCase()=="DIRECT BANKING" || pytfrm.toUpperCase()=="MONEY ORDER" || pytfrm.toUpperCase()=="M-FEES"){
		document.getElementById("TxtCheNo").readOnly=false;
		document.getElementById("CboBank").disabled=false;
		document.getElementById("TxtKind").readOnly=true;
		if (pytfrm.toUpperCase()=="CHEQUE"){document.getElementById("TxtBC").readOnly=false;} 
	}else{
		document.getElementById("TxtCheNo").readOnly=true;
		document.getElementById("CboBank").disabled=true;
		document.getElementById("TxtBC").readOnly=true;
		document.getElementById("TxtKind").readOnly=true;
	}
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0.00";
	}
}
function ttlFees(){
 	var x=0;
 	var sum=0;
 	var n=document.getElementById("TxtBC").value; 
 	x=parseFloat(n.replace(",",""));
	sum+=x; 
 	n=document.getElementById("TxtMiscFee").value; 
 	x=parseFloat(n.replace(",",""));
 	sum+=x;
 	var ttl=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtlFee").value=addCommas(ttl);
	document.getElementById("TxtWords").value=toWords(ttl);
	n=document.getElementById("TxtVal").value; 
 	x=parseFloat(n.replace(",",""));
 	x=sum-x;
 	document.getElementById("TxtVoteBal").value=addCommas(addCommas(x));
}
function checkMiscBal() {
	var fee=0;
 	var bal=0;
 	var n=document.getElementById("TxtMiscFee").value; 
 	fee=parseFloat(n.replace(",",""));
 	n=document.getElementById("TxtBal").value; 
 	bal=parseFloat(n.replace(",",""));
 	n=document.getElementById("TxtCur").value; 
 	bal+=parseFloat(n.replace(",",""));
 	fee-=bal;
 	//if student has fees arrears
	n=document.getElementById("TxtBal8").value; 
 	var amt=parseFloat(n.replace(",",""));
 	if ((amt>0) && (fee>0)){
		n=document.getElementById("TxtCur8").value;
 		var curamt=parseFloat(n.replace(",",""));
		if (amt>=fee){
		 	curamt+=fee;
		 	document.getElementById("TxtVal8").value=addCommas(curamt.toFixed(2));	
			fee=0;
		}else{
		 	curamt+=amt;
			document.getElementById("TxtVal8").value=addCommas(curamt.toFixed(2));	
			fee-=amt;
		}	
	}
	 // if student has uniform fee
 	n=document.getElementById("TxtBal7").value; 
 	amt=parseFloat(n.replace(",",""));
 	if((amt>0) && (fee>0)){
		n=document.getElementById("TxtCur7").value;
 		var curamt=parseFloat(n.replace(",",""));
		if (amt>=fee){
		 	curamt+=fee;
			document.getElementById("TxtVal7").value=addCommas(fee.toFixed(2));	
			fee=0;
		}else{
		 	curamt+=amt;
			document.getElementById("TxtVal7").value=addCommas(amt.toFixed(2));	
			fee-=amt;	
		}	
	}
	n=document.getElementById("TxtMiscFee").value; 
 	fee=parseFloat(n.replace(",",""));
	var ttldis=0;
	for (i=0;i<9;i++){
		n=document.getElementById("TxtVal"+i).value; 
		amt=parseFloat(n.replace(",",""));
		ttldis+=amt;
	}
	fee-=ttldis;
	document.getElementById("TxtVal").value=addCommas(ttldis.toFixed(2));
	document.getElementById("TxtVoteBal").value=addCommas(fee.toFixed(2));
}
function misComputeVote(){
 	var sum=0;	var x=0;	var bal=0;
	var n=document.getElementById("TxtMiscFee").value; 
	var y=parseFloat(n.replace(",",""));
 	for (var i=0;i<9;i++){ 
 	 	if (i<7){
			n=document.getElementById("TxtBal"+i).value; 
 	 		bal=parseFloat(n.replace(",",""));
			n=document.getElementById("TxtCur"+i).value; 
 	 		bal+=parseFloat(n.replace(",",""));	
		}else{bal=0;}
		n=document.getElementById("TxtVal"+i).value; 
 	 	voteamt=parseFloat(n.replace(",",""));
	 	if ((voteamt>bal) && (i<7) && (bal>0)){
			alert ("Sorry, you have allocated higher amount to this votehead.\nThe previous amount has been reallocated");
			n=document.getElementById("TxtCur"+i).value; 
 	 		voteamt=parseFloat(n.replace(",",""));
			document.getElementById("TxtVal"+i).value=document.getElementById("TxtCur"+i).value;
		}
		sum+=voteamt;		
	}
	var ttl=y-sum; //format to two decimal places
	document.getElementById("TxtVal").value=addCommas(sum.toFixed(2));
	document.getElementById("TxtVoteBal").value=(ttl.toFixed(2));
}
function SaveFeeRecord(theForm){
 	var errorn=0;
	var pytfrm=theForm.CboPytFrm.value.toUpperCase();
	if ((pytfrm !="CASH") && (pytfrm !="KIND")){
	 	var trno=theForm.TxtCheNo.value.length;
	 	if (trno<4){
	 		alert("Sorry, You MUST enter transaction/ cheque no. of this payment before saving!!");
	 		theForm.TxtCheNo.style.background='Yellow';
			theForm.TxtCheNo.focus;
			return false;
		}
		if (pytfrm=="CHEQUE"){
			var bank=theForm.CboBank.value.toUpperCase();
			if (bank=="NONE"){
				alert("Sorry, You MUST choose the banker  of this cheque payment before saving!!");
	 			theForm.CboBank.style.background='Yellow';
				theForm.CboBank.focus;
				return false;
			}
		}
	}else if ((pytfrm=="KIND") && (theForm.TxtKind.value.length<5)){
	 	alert("Sorry, You MUST type/enter the description of fee receipt in kind before saving!!");
	 	theForm.TxtKind.style.background='Yellow';
		theForm.TxtKind.focus;
		return false;
	}
	var main=0;
 	var misc=0;
 	var n=theForm.TxtTtlFee.value; //No amount or zero fee amount entered
 	main=parseFloat(n.replace(",",""));
 	if (main==0){
		alert("Sorry, You MUST enter valid school fees amount before saving!!!");
		theForm.TxtMiscFee.style.background='Yellow';
		theForm.TxtMiscFee.focus;
		return false;
	}
	n=theForm.TxtMiscFee.value; 
 	main=parseFloat(n.replace(",",""));
	n=theForm.TxtVoteBal.value; 
 	misc=parseFloat(n.replace(",","")); //misc fee votehead distribution balance
 	if (main>0 && misc!=0){
		alert("Sorry, You MUST fully distribute the Misc Account fees before saving.");
		for (var a=0;a<9;a++){document.getElementById("TxtVal"+a).style.background='Yellow';}
		theForm.TxtValID.focus;
		return false;
	}
	return true;
}
var th = ['','Thousand','Million', 'Billion','Trillion'];
var dg = ['Zero','One','Two','Three','Four', 'Five','Six','Seven','Eight','Nine']; 
var tn = ['Ten','Eleven','Twelve','Thirteen', 'Fourteen','Fifteen','Sixteen', 'Seventeen','Eighteen','Nineteen']; 
var tw = ['Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety']; 
function toWords(s){
 	s = s.toString(); 
	s = s.replace(/[\, ]/g,''); 
	if (s != parseFloat(s)) return 'not a number'; 
	var x = s.indexOf('.'); 
	if (x == -1) x = s.length; 
	if (x > 15) return 'too big'; 
	var n = s.split(''); 
	var str = ''; 
	var sk = 0; 
	for (var i=0; i < x; i++) {
	 	if ((x-i)%3==2) {
		  	if (n[i] == '1') {
			   str += tn[Number(n[i+1])] + ' '; 
			   i++; 
			   sk=1;
			} else if (n[i]!=0) {
			 	str += tw[n[i]-2] + ' ';
				 sk=1;
			}
		} else if (n[i]!=0) {
		 	str += dg[n[i]] +' '; 
			if ((x-i)%3==0) str += 'Hundred ';
			sk=1;
		} 
		if ((x-i)%3==1) {
			if (sk) str += th[(x-i-1)/3] + ' ';
			sk=0;
		}
	} 
	if (x != s.length) {
	 	var y = s.length; 
		str += 'Shillings and '; 
		var i=x+1;
		if (n[i]==0)
			str += dg[n[i]]+' Cents';
		else if (n[i]==1)
			str += tn[n[i]+1]+' Cents';	
		else{
		 	if (n[i+1]==0)
		 		str += tw[n[i]-2] +' Cents';
		 	else{
				str += tw[n[i]-2];
				str =str + '-' + dg[n[i+1]] + ' Cents';
			}	
		}
	} 
	return str.replace(/\s+/g,' ');
}