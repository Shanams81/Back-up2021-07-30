function validateFormOnSubmit(theForm) {
	var reason = "";
	if ((theForm.TxtExam.value.length==0) && (theForm.TxtFGrp.value.length==0) && (theForm.TxtStfGrp.value.length==0) && (theForm.TxtPP.value.length==0) && 
	(theForm.TxtBB.value.length==0) && (theForm.TxtCV.value.length==0) && (theForm.TxtDept.value.length==0)){
		reason+="No Data entered. Please enter the new setup data before saving\n";
		theForm.TxtExam.style.background='Yellow';
		theForm.TxtFGrp.style.background='Yellow';
		theForm.TxtStfGrp.style.background='Yellow';
		theForm.TxtPP.style.background='Yellow';
		theForm.TxtBB.style.background='Yellow';
		theForm.TxtCV.style.background='Yellow';
	}
	if (theForm.TxtExam.value.length>0){reason += validateUsername(theForm.TxtExam);} 
  	if (theForm.TxtFGrp.value.length>0){reason += validateUsername(theForm.TxtFGrp);} 
  	if (theForm.TxtStfGrp.value.length>0){reason += validateUsername(theForm.TxtStfGrp);} 
  	if (theForm.TxtPP.value.length>0){reason += validateUsername(theForm.TxtPP);} 
  	if (theForm.TxtBB.value.length>0){reason += validateUsername(theForm.TxtBB);} 
  	if (theForm.TxtCV.value.length>0){reason += validateUsername(theForm.TxtCV);} 
  	if (theForm.TxtDept.value.length>0){reason += validateUsername(theForm.TxtDept);} 
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /[^a-zA-Z0-9]/; // allow letters, numbers, and underscores
	if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = fld.value + " contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}