function validateFormOnSubmit(theForm) {
	var reason = "";
  	if(theForm.TxtCode.value.length<3) reason +="Sorry, the course code must have at least 4 alphanumeric characters" ;
  	reason += validateUsername(theForm.TxtName);
  	reason += validateUsername(theForm.CboExamBody);
  	reason += validateUsername(theForm.TxtAbb);
  	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = "You didn't enter the right information.\n";
	} else if (fld.value.length < 2) {
    	fld.style.background = 'Yellow'; 
    	error = "The information is the wrong length.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = "The information contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}