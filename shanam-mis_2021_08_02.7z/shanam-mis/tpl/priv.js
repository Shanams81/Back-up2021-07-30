function canedit(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to edit the record");
    	return false;
  	} else {
  		return true;
  	}
}
function confpwd(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to add the reactivate password");
    	return false;
  	} else {
  		return true;
  	}
}
function canadd(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to add the record");
    	return false;
  	} else {
  		return true;
  	}
}
function canvi(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to view record");
    	return false;
  	} else {
  		return true;
  	}
}
function candel(sb){
 	if (sb==0){
		alert("You do not have the priviledge to delete this record");
		return false;
	} else{
	 	var ans=confirm("Are you sure you want to delete this record?\nClick OK to delete otherwise click Cancel.");
	 	if (ans==true){
			return true;
		}else{
			return false;
		}
	}
}
function Clickheretoprint(){ 
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
  	disp_setting+"scrollbars=yes,width=650, height=600, left=100, top=25"; 
	var content_vlue = document.getElementById("print_content").innerHTML; 
	var docprint=window.open("","",disp_setting); 
	docprint.document.open(); 
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title>'); 
	docprint.document.write('</head><body onLoad="self.print()" style="color:#000000;font-size:10px;"><center>');          
	docprint.document.write(content_vlue);          
	docprint.document.write('</body></html>'); 
	docprint.document.close(); 
	docprint.focus(); 
}