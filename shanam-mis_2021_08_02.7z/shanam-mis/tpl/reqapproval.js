function candel(sb){
 	if (sb==0){
		alert("You do not have the priviledge to delete this record");
		return false;
	} else{
	 	var ans=confirm("Are you sure you want to delete this record?\nClick OK to delete otherwise click Cancel.");
	 	if (ans==true){
			return true;
		}else{
			return false;
		}
	}
}
function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.TxtAmt);
	reason += validateNo(theForm.TxtAmtPerDur);
	reason += validatUsername(theForm.TxtRmks);
	if (reason != "") {
    	alert("The following fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	var illegalChars = /\d/; // allow letters, numbers, and underscores
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " You didn't enter the reason for the salary advance.\n";
	} else if (fld.value.length < 10) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The reason for the salary advance is too short.\n";
	} else if (illegalChars.test(fld.value)) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The salary advance reason contains illegal characters.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ \+]/g, '');     
	if (fld.value == "") {
    	error = fld.name + " requires numeric data, it is currently blank.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = fld.name + " requires numeric values, your entry contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}