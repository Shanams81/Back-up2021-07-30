function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += ValidateName(theForm.TxtUName);
	reason += ValidatePw(theForm.TxtCPW);
	reason += ValidatePw(theForm.TxtNPW);
	reason += ValidatePw(theForm.TxtConfirm);
	if (theForm.TxtNPW.value != theForm.TxtConfirm.value) {
		reason+="\nSorry, new password and its confirmation of are not similar.";
	}
	if (reason != "") {
    	alert("Some fields need correction:\n" + reason);
    	theForm.TxtNPW.value='';
    	theForm.TxtCPW.value='';
    	theForm.TxtConfirm.value='';
    	return false;
  	} else {
  		return true;
  	}
}
function ValidateName(fld) {
	var error = "";
	if (fld.value==""){
		fld.style.background = 'Yellow'; 
    	error = "Sorry, Username has not been entered.\n";
	}
	else if (fld.value.length < 3) {
    	fld.style.background = 'Yellow'; 
    	error = "Sorry, Username MUST be more than 3 alphanumeric character.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function ValidatePw(fld) {
	var error = "";
	if (fld.value==""){
		fld.style.background = 'Yellow'; 
    	error = "Sorry, Password Not Entered.\n";
	}
	else if (fld.value.length < 6) {
    	fld.style.background = 'Yellow'; 
    	error = "Sorry, Password MUST be more than 5 alphanumeric character.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}