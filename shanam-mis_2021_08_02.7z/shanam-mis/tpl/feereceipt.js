function checkPyt(ob){
	var pytfrm=ob.value;
	if(pytfrm.toUpperCase()=="KIND"){
		document.getElementById("TxtCheNo").readOnly=true;document.getElementById("CboBank").disabled=true;
		document.getElementById("TxtBC").readOnly=true;	document.getElementById("TxtKind").readOnly=false;
	}else if (pytfrm.toUpperCase()=="CHEQUE" || pytfrm.toUpperCase()=="DIRECT BANKING" || pytfrm.toUpperCase()=="MONEY ORDER" || pytfrm.toUpperCase()=="M-FEES"){
		document.getElementById("TxtCheNo").readOnly=false;document.getElementById("CboBank").disabled=false;document.getElementById("TxtKind").readOnly=true;
		if (pytfrm.toUpperCase()=="CHEQUE"){document.getElementById("TxtBC").readOnly=false;}
	}else{
		document.getElementById("TxtCheNo").readOnly=true;document.getElementById("CboBank").disabled=true;document.getElementById("TxtBC").readOnly=true;
		document.getElementById("TxtKind").readOnly=true;
	}
	//alert(pytfrm.toUpperCase());
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){	var a=ob.value.replace(invalidChars,""); ob.value=addCommas(a);
	}if (ob.length==0){ob.value="0.00";}
}
function ttlFees(){
 	var x=0,sum=0,n=document.getElementById("TxtBC").value;
 	x=parseFloat(n.replace(",",""));sum+=x; n=document.getElementById("TxtMainFee").value; x=parseFloat(n.replace(",",""));
 	sum+=x; n=document.getElementById("TxtMiscFee").value; 	x=parseFloat(n.replace(",","")); 	sum+=x;
	var ttl=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtlFee").value=addCommas(ttl);	document.getElementById("TxtWords").value=toWords(ttl);
}
function checkMainBal(cls,voteBal) {
	var fee=0,bal=0,n=document.getElementById("TxtMainFee").value; fee=parseFloat(n.replace(",",""));	n=document.getElementById("TxtBal").value; bal=parseFloat(n.replace(",",""));
 	document.getElementById("TxtVal15").value="0.00";	document.getElementById("TxtVal16").value="0.00";
 	//Is the pupils in class eight
 	if (fee>bal){
 	 	var net=fee-bal;
		if (cls.toUpperCase()=="EIGHT"){
			alert("Notice!!, the sum of Kshs. "+(addCommas(fee.toFixed(2)))+" is higher than the student's balance of Kshs. "+(addCommas(bal.toFixed(2)))+"\nThe extra amount of Kshs. "+
			(addCommas(net.toFixed(2)))+"has been set to refunds."); document.getElementById("TxtVal15").value=addCommas(net.toFixed(2));
		}else{
			alert("Notice!!, the sum of Kshs. "+(addCommas(fee.toFixed(2)))+" is higher than the student's balance of Kshs. "+(addCommas(bal.toFixed(2)))+"\nThe extra amount of Kshs. "+
			(addCommas(net.toFixed(2)))+" has been set to prepayment."); document.getElementById("TxtVal16").value=addCommas(net.toFixed(2));
		}	fee-=net;
 	}
	//if student has fees arrears
	document.getElementById("TxtVal13").value="0.00";	n=document.getElementById("TxtBal13").value; var amt=parseFloat(n.replace(",",""));
 	if ((amt>0) && (fee>0)){
		if (amt>=fee){alert("The entire sum of Kshs. " + fee.toFixed(2) + " has cleared part fee arrears owed to the institution.");
			document.getElementById("TxtVal13").value=addCommas(fee.toFixed(2));	fee=0;
		}else{alert("The sum of Kshs. " + amt.toFixed(2) + " has cleared fee arrears owed to the institution."); document.getElementById("TxtVal13").value=addCommas(amt.toFixed(2));
			fee-=amt;
		}
	}
	 // if student has special medical charges
	document.getElementById("TxtVal14").value="0.00"; n=document.getElementById("TxtBal14").value; amt=parseFloat(n.replace(",",""));
 	if((amt>0) && (fee>0)){
		if (amt>=fee){ document.getElementById("TxtVal14").value=addCommas(fee.toFixed(2));	fee=0;
		}else{document.getElementById("TxtVal14").value=addCommas(amt.toFixed(2)); fee-=amt;}
	}
 	//votehead distribution of the amount
 	if (fee>0){ //Term I balance distribution
	 	let i=0; for (i=0;i<13;i++){	document.getElementById("TxtVal"+i).value="0.00";} 	i=0;
		while ((i<13) && (fee>0)){
	 	 	if (voteBal[i]>0){
	 	 	 	if (voteBal[i]>=fee){	document.getElementById("TxtVal"+i).value=addCommas(fee.toFixed(2));  fee=0;
				}else{document.getElementById("TxtVal"+i).value=addCommas(voteBal[i].toFixed(2));	fee-=voteBal[i];}
			}	i++;
		}
	}if  (fee>0){ //Term II
		let i=0, sumamt=0;
		while ((i<13) && (fee>0)){
	 	 	if (voteBal[(i+14)]>0){n=document.getElementById("TxtVal"+i).value; amt=parseFloat(n.replace(",",""));
				if (voteBal[(i+14)]>=fee){sumamt=fee+amt;fee=0;
				}else{sumamt=voteBal[(i+14)]+amt; 	fee-=voteBal[(i+14)];
				} document.getElementById("TxtVal"+i).value=addCommas(sumamt.toFixed(2));
			} i++;
		}
	}
	if (fee>0){ //Term III
		var i=0;
		while ((i<13) && (fee>0)){
	 	 	if (voteBal[(i+28)]>0){n=document.getElementById("TxtVal"+i).value; amt=parseFloat(n.replace(",",""));
				if (voteBal[(i+28)]>=fee){sumamt=fee+amt;fee=0;
				}else{sumamt=voteBal[(i+28)]+amt;	fee-=voteBal[(i+28)];	}
				document.getElementById("TxtVal"+i).value=addCommas(sumamt.toFixed(2));
			} i++;
		}
	}
	var ttldis=0;
	for (i=0;i<17;i++){n=document.getElementById("TxtVal"+i).value; amt=parseFloat(n.replace(",",""));ttldis+=amt;}
	document.getElementById("TxtTtl").value=addCommas(ttldis.toFixed(2)); 	document.getElementById("TxtVoteBal").value=addCommas(fee.toFixed(2));
}
function ComputeVote(){
 	var sum=0,x=0,bal=0,n=document.getElementById("TxtMainFee").value;
	var y=parseFloat(n.replace(",",""));
 	for (var i=0;i<17;i++){
 	 	if (i<15){
			n=document.getElementById("TxtBal"+i).value;
 	 		bal=parseFloat(n.replace(",",""));
		}else{bal=0;}
		n=document.getElementById("TxtVal"+i).value;
 	 	voteamt=parseFloat(n.replace(",",""));
	  	sum+=voteamt;
	 	if ((voteamt>bal) && (i<15)){
			alert ("Sorry, you have allocated higher amount to this votehead.\nThe right amount has been allocated");
			document.getElementById("TxtVal"+i).value=addCommas(bal.toFixed(2));
		}else{document.getElementById("TxtVal"+i).value=addCommas(voteamt.toFixed(2));}
	}
	var ttl=y-sum; //format to two decimal places
	document.getElementById("TxtTtl").value=addCommas(sum.toFixed(2));
	document.getElementById("TxtVoteBal").value=(ttl.toFixed(2));
}
function checkMiscBal(cls,miscBal) {
 	var fee=0;
 	var bal=0;
 	var n=document.getElementById("TxtMiscFee").value;
 	fee=parseFloat(n.replace(",",""));
 	n=document.getElementById("TxtMisBal").value;
 	bal=parseFloat(n.replace(",",""));
 	//Is the misc fee more than school fees
 	if (fee>bal){
 	 	alert("Notice!!, the sum of Kshs. "+fee+" is higher than the student's balance of Kshs. "+bal+"\nThe correct amount has been set.");
		document.getElementById("TxtMiscFee").value=addCommas(bal.toFixed(2));
		fee=bal;
		ttlFees();
 	}
	//if student has misc fee arrears
	document.getElementById("TxtMisVal8").value="0.00";
 	n=document.getElementById("TxtMisBal8").value;
	var amt=parseFloat(n.replace(",",""));
 	if ((amt>0) && (fee>0)){
		if (amt>=fee){
			document.getElementById("TxtMisVal8").value=addCommas(fee.toFixed(2));
			fee=0;
		}else{
			document.getElementById("TxtMisVal8").value=addCommas(amt.toFixed(2));
			fee-=amt;
		}
	}
	 // if student has uniform charges
 	document.getElementById("TxtMisVal7").value="0.00";
	n=document.getElementById("TxtMisBal7").value;
 	amt=parseFloat(n.replace(",",""));
 	if((amt>0) && (fee>0)){
		if (amt>=fee){
			document.getElementById("TxtMisVal7").value=addCommas(fee.toFixed(2));
			fee=0;
		}else{
			document.getElementById("TxtMisVal7").value=addCommas(amt.toFixed(2));
			fee-=amt;
		}
	}
 	//votehead distribution of the amount
 	if (fee>0){ //Term I balance distribution
	 	var i=0;
		for (i=0;i<7;i++){document.getElementById("TxtMisVal"+i).value="0.00";}
		i=0;
		while ((i<7) && (fee>0)){
	 	 	if (miscBal[i]>0){
	 	 	 	if (miscBal[i]>=fee){
	 	 	 	 	document.getElementById("TxtMisVal"+i).value=addCommas(fee.toFixed(2));
				    fee=0;
				}else{
				 	document.getElementById("TxtMisVal"+i).value=addCommas(miscBal[i].toFixed(2));
					fee-=miscBal[i];
				}
			}i++;
		}
	}
	if (fee>0){ //Term II vote distribution
		var i=0; var sumamt=0;
		while ((i<7) && (fee>0)){
	 	 	if (miscBal[(i+8)]>0){
	 	 	 	n=document.getElementById("TxtMisVal"+i).value;
		 		amt=parseFloat(n.replace(",",""));
				if (miscBal[(i+8)]>=fee){
				 	sumamt=fee+amt;
				 	fee=0;
				}else{
				 	sumamt=miscBal[(i+8)]+amt;
				 	fee-=miscBal[(i+8)];
				}
				document.getElementById("TxtMisVal"+i).value=addCommas(sumamt.toFixed(2));
			}
			i++;
		}
	}
	if (fee>0){ //Term III vote distribution
		var i=0;
		while ((i<7) && (fee>0)){
	 	 	if (miscBal[(i+16)]>0){
	 	 	 	n=document.getElementById("TxtMisVal"+i).value;
		 		amt=parseFloat(n.replace(",",""));
				if (miscBal[(i+16)]>=fee){
				 	sumamt=fee+amt;
				 	fee=0;
				}else{
				 	sumamt=miscBal[(i+16)]+amt;
				 	fee-=miscBal[(i+16)];
				}
				document.getElementById("TxtMisVal"+i).value=addCommas(sumamt.toFixed(2));
			}
			i++;
		}
	}
	var ttldis=0;
	for (i=0;i<9;i++){
		n=document.getElementById("TxtMisVal"+i).value;
		amt=parseFloat(n.replace(",",""));
		ttldis+=amt;
	}
	document.getElementById("TxtMisTtl").value=addCommas(ttldis.toFixed(2));
	document.getElementById("TxtMisVoteBal").value=addCommas(fee.toFixed(2));
}
function misComputeVote(){
 	var sum=0;	var x=0;	var bal=0;
	var n=document.getElementById("TxtMiscFee").value;
	var y=parseFloat(n.replace(",",""));
 	for (var i=0;i<9;i++){
 	 	n=document.getElementById("TxtMisBal"+i).value;
 	 	bal=parseFloat(n.replace(",",""));
 	 	n=document.getElementById("TxtMisVal"+i).value;
 	 	voteamt=parseFloat(n.replace(",",""));
	  	sum+=voteamt;
	 	if (voteamt>bal){
			alert ("Sorry, you have allocated higher amount to this votehead.\nThe right amount has been allocated");
			document.getElementById("TxtMisVal"+i).value=addCommas(bal.toFixed(2));
		}else{document.getElementById("TxtMisVal"+i).value=addCommas(voteamt.toFixed(2));}
	}
	var ttl=y-sum; //format to two decimal places
	document.getElementById("TxtMisTtl").value=addCommas(sum.toFixed(2));
	document.getElementById("TxtMisVoteBal").value=(ttl.toFixed(2));
}
function SaveFeeRecord(theForm){
 	var error='',pytfrm=theForm.CboPytFrm.value.toUpperCase();
	if ((pytfrm !="CASH") && (pytfrm !="KIND")){
	 	var trno=theForm.TxtCheNo.value.length;
	 	if (trno<4){error+="Sorry, You MUST enter transaction/ cheque no. of this payment before saving!!\n"; theForm.TxtCheNo.style.background='Yellow';theForm.TxtCheNo.focus;}
		if (pytfrm=="CHEQUE"){var bank=theForm.CboBank.value.toUpperCase();
			if (bank==0){error+="Sorry, You MUST choose the banker  of this cheque payment before saving!!\n";	theForm.CboBank.style.background='Yellow';theForm.CboBank.focus;}
		}
	}else if ((pytfrm=="KIND") && (theForm.TxtKind.value.length<5)){
	 	error+="Sorry, You MUST type/enter the description of fee receipt in kind before saving!!\n";theForm.TxtKind.style.background='Yellow';	theForm.TxtKind.focus;
	}let main=0,misc=0,n=theForm.TxtTtlFee.value;  	main=parseFloat(n.replace(",",""));
 	if (main==0){error+="Sorry, You MUST enter valid school fees amount before saving!!!\n"; theForm.TxtMainFee.style.background='Yellow';
		theForm.TxtMiscFee.style.background='Yellow'; theForm.TxtMainFee.focus;
	}	n=theForm.TxtMainFee.value; main=parseFloat(n.replace(",",""));	n=theForm.TxtVoteBal.value; misc=parseFloat(n.replace(",","")); //main fee votehead distribution balance
 	if (main>0 && misc!=0){err+="Sorry, You MUST fully distribute the Main Account fees before saving.";
		for (var a=0;a<17;a++){document.getElementById("TxtVal"+a).style.background='Yellow';} theForm.TxtTui.focus;
	}n=theForm.TxtMiscFee.value;misc=parseFloat(n.replace(",",""));n=theForm.TxtMisVoteBal.value;main=parseFloat(n.replace(",","")); //misc votehead distribution balance
 	if (misc>0 && main!=0){error+="Sorry, You MUST fully distribute the MIscellaneous Account fees before saving.";
		for (var a=0;a<9;a++){document.getElementById("TxtMisVal"+a).style.background='Yellow';}	theForm.TxtMisID.focus;
	}
	if(error.length>0){alert("THE FOLLOWING ERRORS MUST BE CORRECTED FIRST\n"+error); return false}
	else{theForm.CboBank.disabled=false; theForm.TxtCheNo.disabled=false; return true;}
}
var th = ['','Thousand','Million', 'Billion','Trillion'];
// uncomment this line for English Number System
// var th = ['','thousand','million', 'milliard','billion'];
var dg = ['Zero','One','Two','Three','Four', 'Five','Six','Seven','Eight','Nine'];
var tn = ['Ten','Eleven','Twelve','Thirteen', 'Fourteen','Fifteen','Sixteen', 'Seventeen','Eighteen','Nineteen'];
var tw = ['Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
function toWords(s){
 	s = s.toString();
	s = s.replace(/[\, ]/g,'');
	if (s != parseFloat(s)) return 'not a number';
	var x = s.indexOf('.');
	if (x == -1) x = s.length;
	if (x > 15) return 'too big';
	var n = s.split('');
	var str = '';
	var sk = 0;
	for (var i=0; i < x; i++) {
	 	if ((x-i)%3==2) {
		  	if (n[i] == '1') {
			   str += tn[Number(n[i+1])] + ' ';
			   i++;
			   sk=1;
			} else if (n[i]!=0) {
			 	str += tw[n[i]-2] + ' ';
				 sk=1;
			}
		} else if (n[i]!=0) {
		 	str += dg[n[i]] +' ';
			if ((x-i)%3==0) str += 'Hundred ';
			sk=1;
		}
		if ((x-i)%3==1) {
			if (sk) str += th[(x-i-1)/3] + ' ';
			sk=0;
		}
	}
	if (x != s.length) {
	 	var y = s.length;
		str += 'Shillings and ';
		var i=x+1;
		if (n[i]==0)
			str += dg[n[i]]+' Cents';
		else if (n[i]==1)
			str += tn[n[i]+1]+' Cents';
		else{
		 	if (n[i+1]==0)
		 		str += tw[n[i]-2] +' Cents';
		 	else{
				str += tw[n[i]-2];
				str =str + '-' + dg[n[i+1]] + ' Cents';
			}
		}
	}
	return str.replace(/\s+/g,' ');
}
