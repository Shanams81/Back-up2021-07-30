function validateFormOnSubmit(theForm) {
	var reason = "";
	reason += validateNo(theForm.TxtBSal);
	reason += validateUsername(theForm.TxtPP);
	reason += validateNo(theForm.TxtHousing);
	reason += validateNo(theForm.TxtMedical);
	reason += validateNo(theForm.TxtCommuter);
	reason += validateNo(theForm.TxtEmpNSSF);
	reason += validateNo(theForm.TxtNSSF);
	reason += validateNo(theForm.TxtNHIF);
	reason += validateNo(theForm.TxtSACCO);
	reason += validateNo(theForm.TxtWelfare);
	reason += validateNo(theForm.TxtUnion);
	reason += validateNo(theForm.TxtAdvance);
	reason += validateNo(theForm.TxtPAYE);
	reason += validateNo(theForm.TxtMPR);
	reason += validateNo(theForm.TxtOle);
	var n=document.getElementById("TxtNS").value; 	var nsal=parseFloat(n.replace(",",""));	
	if ((isNaN(nsal))||(nsal<1)) reason+="\nNet salary for the employee must be more than zero shillings."; 
  	if (reason != "") {
    	alert("The following fields need correction:\n" + reason);
    	return false;
  	} else {
  		return true;
  	}
}
function validateUsername(fld) {
	var error = "";
	if (fld.value == "") {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " You didn't enter the right information.\n";
	} else if (fld.value.length < 3) {
    	fld.style.background = 'Yellow'; 
    	error = fld.name + " The information is the wrong length.\n";
	} else {
    	fld.style.background = 'White';
	} 
	return error;
}
function validateNo(fld) {
	var error = "";
	var stripped = fld.value.replace(/[\(\)\.\-\ \+]/g, '');     
	if (fld.value == "") {
    	error = fld.name + " requires numeric data, it is currently blank.\n";
    	fld.style.background = 'Yellow';
	} else if (isNaN(parseInt(stripped))) {
    	error = fld.name + " requires numeric values, your entry contains illegal characters.\n";
    	fld.style.background = 'Yellow';
	} 
	return error;
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0";
	}
}
function Compute(){
 	var gsal=0;
 	var ded=0;
 	var netsal=0;
 	var paye=0; 
	//Gross salary computation
	var n=document.getElementById("TxtBSal").value; 		x=parseFloat(n.replace(",",""));			if (!(isNaN(x))) gsal+=x; 
	n=document.getElementById("TxtHousing").value; 			x=parseFloat(n.replace(",",""));			if (!(isNaN(x))) gsal+=x; 
	n=document.getElementById("TxtMedical").value; 			x=parseFloat(n.replace(",",""));			if (!(isNaN(x))) gsal+=x; 
	n=document.getElementById("TxtCommuter").value; 		x=parseFloat(n.replace(",",""));			if (!(isNaN(x))) gsal+=x; 
	var m=gsal.toFixed(2); //format to two decimal places
	document.getElementById("TxtGS").value=addCommas(m);
	//Total Deduction Calculation
	n=document.getElementById("TxtNSSF").value; 	x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) ded+=x; 
	n=document.getElementById("TxtNHIF").value; 	x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) ded+=x; 
	n=document.getElementById("TxtPAYE").value; 	x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) paye+=x;
	n=document.getElementById("TxtMPR").value; 		x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) paye-=x;
	n=document.getElementById("TxtUnion").value; 	x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) ded+=x; 
	n=document.getElementById("TxtSACCO").value; 	x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) ded+=x; 
	n=document.getElementById("TxtWelfare").value; 	x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) ded+=x; 
	n=document.getElementById("TxtAdvance").value; 	x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) ded+=x; 
	n=document.getElementById("TxtOle").value; 		x=parseFloat(n.replace(",",""));	if (!(isNaN(x))) ded+=x; 
	ded+=paye; 
	m=ded.toFixed(2); //format to two decimal places
	document.getElementById("TxtDed").value=addCommas(m);
	//payee calculation
	m=paye.toFixed(2); //format to two decimal places
	document.getElementById("TxtPayeAuto").value=addCommas(m);
	netsal=gsal-ded;
	m=netsal.toFixed(2); //format to two decimal places
	document.getElementById("TxtNS").value=addCommas(m);
}