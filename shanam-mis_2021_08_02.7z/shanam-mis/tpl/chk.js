function actiondone(a,b){ // a = 0 is normal,1 editing and 2 deleting. b is the number of records edited or deleted
	if (a==1){alert(b+" record(s) were sucessfully added/ updated.");}
	if (a==2){alert(b+" record(s) were sucessfully deleted.");}		
}
function ClearCont(listboxID){ // returns 1 if all items are sucessfully removed otherwise returns zero.
	var mylistbox = document.getElementById(listboxID);
	if(mylistbox == null) return 1;
	while(mylistbox.length > 0) mylistbox.remove(0);
	return 1;
}
function filldays(listboxID){
	var i=ClearCont(listboxID);
	var yr=parseInt(document.getElementById("CboYr").value);
	var mon=document.getElementById("CboMon").value;
	var n=noofdays(yr,mon);
	var htmlSelect=document.getElementById(listboxID);
	for (var i=n;i>0;i--){
		selectBoxOption = document.createElement("option");
		selectBoxOption.value = i;
		selectBoxOption.text = i;
		htmlSelect.add(selectBoxOption);
	}
}
function noofdays(y,m){
 	switch (m){
		case '01': d=31; break;
		case '02': if(((y%4 == 0) && (y%100 != 0)) || (y%400 == 0)) d=29; else d=28; break;
		case '03': d=31; break;
		case '04': d=30; break;
		case '05': d=31; break;
		case '06': d=30; break;
		case '07': d=31; break;
		case '08': d=31; break;
		case '09': d=30; break;
		case '10': d=31; break;
		case '11': d=30; break;
		case '12': d=31; break;
		default: d=1; break;
	}
	return d;
}
function canedit(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to edit the record");
    	return false;
  	} else {
  		return true;
  	}
}
function confpwd(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to add the reactivate password");
    	return false;
  	} else {
  		return true;
  	}
}
function canadd(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to add the record");
    	return false;
  	} else {
  		return true;
  	}
}
function canvi(pr) {
 	if (pr == 0) {
    	alert("Sorry, you do not have the priviledges to view record");
    	return false;
  	} else {
  		return true;
  	}
}
function candel(sb){
 	if (sb==0){
		alert("You do not have the priviledge to delete this record");
		return false;
	} else{
	 	var ans=confirm("Are you sure you want to delete this record?\nClick OK to delete otherwise click Cancel.");
	 	if (ans==true){
			return true;
		}else{
			return false;
		}
	}
}
function addCommas(nStr){
	nStr+='';
	var x=nStr.split('.');
	var x1=x[0];
	var x2=x.length>1?('.'+x[1]):'';
	var rgx=/(\d+)(\d{3})/;
	while (rgx.test(x1)){x1=x1.replace(rgx,'$1'+','+'$2');}
	return x1+x2;
}
function checkInput(ob){
	var invalidChars=/[^0-9\.\,]/gi;
	if (invalidChars.test(ob.value)){
		var a=ob.value.replace(invalidChars,"");
		ob.value=addCommas(a);
	}
	if (ob.length==0){
	 	ob.value="0.00";
	}
}
function Compute(k){
 	var sum=0;
	var x=0;
 	for (var i=0;i<k;i++){ 
 	 	var n=document.getElementById("TxtVal"+i).value; 
 	 	x=parseFloat(n.replace(",",""));
	  	if (!(isNaN(x))) sum+=x; 
	}
	var m=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtl").value=addCommas(m);
}
function ComputeVote(){
 	var sum=0;
	var x=0;
	var n=document.getElementById("TxtFee").value; 
	var y=parseFloat(n.replace(",",""));
 	for (var i=0;i<18;i++){ 
 	 	if (i<17){
 	 	    var m=document.getElementById("TxtBal"+i).value; 
 	 	    bal=parseFloat(m.replace(",",""));
 	 	}else{
 	 	    bal=0;
 	 	}
 	 	var n=document.getElementById("TxtVal"+i).value; 
 	 	voteamt=parseFloat(n.replace(",",""));
	  	if (!(isNaN(voteamt)))
		{
		 	sum+=voteamt;
		 	if (sum>y)
		   {
				alert ("You have distributed higher amount in the voteheads!!!");
				document.getElementById("TxtVal"+i).value=0;
				sum-=voteamt;
				break;
			}
			if ((voteamt>bal) && (bal>0)){
				alert ("Sorry, you have allocated higher amount to this votehead.\nThe right amount has been allocated");
				voteamt=bal;
				document.getElementById("TxtVal"+i).value=bal;
			}
		}else{
		 	alert("Illegal value entered!!!!!!!");
		}
	}
	var ttl=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtl").value=addCommas(ttl);
	document.getElementById("TxtVoteBal").value=(y-sum);
}
function ComputeVote1(){
 	var sum=0;
	var x=0;
	var n=document.getElementById("TxtFee").value; 
	var y=parseFloat(n.replace(",","")); 
 	for (var i=0;i<18;i++) { 
 	 	if (i<17){
 	 	    var m=document.getElementById("TxtBal"+i).value; 
 	 	    bal=parseFloat(m.replace(",",""));
 	 	}else{
 	 	    bal=0;
 	 	} 
		var cubal=(bal+val[i+2]);
 	 	var n=document.getElementById("TxtVal"+i).value;  voteamt=parseFloat(n.replace(",",""));
  		if ((voteamt>cubal) && (i<17) && (bal>0)) {
			alert ("Sorry, you have allocated higher amount to this votehead.\nThe right amount has been allocated");
			voteamt=val[i+2];
			document.getElementById("TxtVal"+i).value=val[i+2];
		}
	    sum+=voteamt;
	    if (sum>y) {
			alert ("You have allocated higher amount!!!");
			document.getElementById("TxtVal"+i).value=val[i+2];
			sum-=(voteamt-val[i+2]);
			break;
		}
	}
	var ttl=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtl").value=addCommas(ttl);
	document.getElementById("TxtVoteBal").value=(y-sum);
}
function ttlfees() {
 	var x=0;
 	var bal=0;
 	var sum=0;
 	var n=document.getElementById("TxtBC").value; 
 	x=parseFloat(n.replace(",",""));
	sum+=x; 
 	n=document.getElementById("TxtFee").value; 
 	x=parseFloat(n.replace(",",""));
 	document.getElementById("TxtVoteBal").value=x;
	sum+=x;
	var ttl=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtlFee").value=addCommas(ttl);
	document.getElementById("TxtWords").value=toWords(ttl);
}
function ttlfees1() {
 	var x=0;
 	var bal=0;
 	var sum=0;
 	var n=document.getElementById("TxtBC").value; 
 	x=parseFloat(n.replace(",",""));
	sum+=x; 
 	n=document.getElementById("TxtFee").value; 
 	x=parseFloat(n.replace(",",""));
 	var n=document.getElementById("TxtBal").value; 
 	bal=parseFloat(n.replace(",",""));
 	if (x>(bal+val[1])){
 	 	alert("Warning!!, the amount entered (Kshs. "+x+") is higher than the student's balance of Kshs. "+bal+
		"\nThe amount has therefore been reset to the balance.");
 	 	document.getElementById("TxtFee").value=val[1];
 	 	document.getElementById("TxtVoteBal").value=0;
		sum+=val[1];
	}else{
	 	document.getElementById("TxtVoteBal").value=x-val[1];
		sum+=x;
	}
 	var ttl=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtlFee").value=addCommas(ttl);
	document.getElementById("TxtWords").value=toWords(ttl);
}
function Clickheretoprint(){ 
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
  	disp_setting+"scrollbars=yes,width=650, height=600, left=100, top=25"; 
	var content_vlue = document.getElementById("print_content").innerHTML; 
	var docprint=window.open("","",disp_setting); 
	docprint.document.open(); 
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title>'); 
	docprint.document.write('</head><body onLoad="self.print()" style="color:#000000;font-size:10px;"><center>');          
	docprint.document.write(content_vlue);          
	docprint.document.write('</body></html>'); 
	docprint.document.close(); 
	docprint.focus(); 
}
function PrintSpecific(secno){ 
 	var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
  	disp_setting+"scrollbars=yes,width=650, height=600, left=100, top=25"; 
	var content_value = document.getElementById(secno).innerHTML; 
	var docprint=window.open("","",disp_setting); 
	docprint.document.open(); 
	docprint.document.write('<html><head><link href="tpl/accprint.css" rel="stylesheet" type="text/css"/><title>Printing</title>'); 
	docprint.document.write('</head><body onLoad="self.print()" style="color:#000000;font-size:10px;"><center>');          
	docprint.document.write(content_value);          
	docprint.document.write('</body></html>'); 
	docprint.document.close(); 
	docprint.focus(); 
}
function SaveRecord(theForm){
	var pytfrm=theForm.CboPytFrm.value;
	if ((pytfrm !="Cash") && (theForm.TxtCheNo.value.length==0)){
	 	alert("Sorry, You MUST enter transaction/ cheque no. before saving!!");
	 	theForm.TxtCheNo.style.background='Yellow';
		theForm.TxtCheNo.focus;
		return false;
	}else if ((pytfrm=="Cheque") && (theForm.CboBank.value=="None")){
	 	alert("Sorry, You MUST select cheque\'s banker before saving!!");
	 	theForm.CboBank.style.background='Yellow';
		theForm.CboBank.focus;
		return false;
	}
	var x=0;
 	var sum=0;
 	if (theForm.TxtFee.value.length==0){
		alert("Sorry, You MUST enter valid fee amount!!!");
		theForm.TxtFee.style.background='Yellow';
		theForm.TxtFee.focus;
		return false;
	}
 	var n=theForm.TxtVoteBal.value; 
 	x=parseFloat(n.replace(",",""));
 	if (x!=0){
		alert("Sorry, You must fully distribute the fees before saving.");
		theForm.TxtAdm.focus;
		return false;
	}
	return true;
}
var th = ['','Thousand','Million', 'Billion','Trillion'];
// uncomment this line for English Number System
// var th = ['','thousand','million', 'milliard','billion'];
var dg = ['Zero','One','Two','Three','Four', 'Five','Six','Seven','Eight','Nine']; 
var tn = ['Ten','Eleven','Twelve','Thirteen', 'Fourteen','Fifteen','Sixteen', 'Seventeen','Eighteen','Nineteen']; 
var tw = ['Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety']; 
function toWords(s){
 	s = s.toString(); 
	s = s.replace(/[\, ]/g,''); 
	if (s != parseFloat(s)) return 'not a number'; 
	var x = s.indexOf('.'); 
	if (x == -1) x = s.length; 
	if (x > 15) return 'too big'; 
	var n = s.split(''); 
	var str = ''; 
	var sk = 0; 
	for (var i=0; i < x; i++) {
	 	if ((x-i)%3==2) {
		  	if (n[i] == '1') {
			   str += tn[Number(n[i+1])] + ' '; 
			   i++; 
			   sk=1;
			} else if (n[i]!=0) {
			 	str += tw[n[i]-2] + ' ';
				 sk=1;
			}
		} else if (n[i]!=0) {
		 	str += dg[n[i]] +' '; 
			if ((x-i)%3==0) str += 'Hundred ';
			sk=1;
		} 
		if ((x-i)%3==1) {
			if (sk) str += th[(x-i-1)/3] + ' ';
			sk=0;
		}
	} 
	if (x != s.length) {
	 	var y = s.length; 
		str += 'Shillings and '; 
		var i=x+1;
		if (n[i]==0)
			str += dg[n[i]]+' Cents';
		else if (n[i]==1)
			str += tn[n[i]+1]+' Cents';	
		else{
		 	if (n[i+1]==0)
		 		str += tw[n[i]-2] +' Cents';
		 	else{
				str += tw[n[i]-2];
				str =str + '-' + dg[n[i+1]] + ' Cents';
			}	
		}
	} 
	return str.replace(/\s+/g,' ');
}
function ttlArr() {
 	var x=0;
 	var bal=0;
 	var sum=0;
 	var n=document.getElementById("TxtBC").value; 
 	x=parseFloat(n.replace(",",""));
	sum+=x; 
 	n=document.getElementById("TxtFee").value; 
 	x=parseFloat(n.replace(",",""));
 	var n=document.getElementById("TxtBBF").value; 
 	bal=parseFloat(n.replace(",",""));
 	if (bal>0){
		if (x>bal){
	 	 	alert("The sum of Kshs. "+bal+" will be used to offset student's fee arrears.");
	 	 	document.getElementById("TxtVal13").value=bal;
	 	 	sum+=x;
			document.getElementById("TxtVoteBal").value=(sum-bal);
		}else{
			alert("The whole of Kshs. "+x+"will be used to offset part of student's fee arrears.");
			document.getElementById("TxtVal13").value=x;
			sum+=x;
			document.getElementById("TxtVoteBal").value="0.00";
		}
		document.getElementById("TxtBal").value=(x>bal?bal:x);		
	}else{
	 	document.getElementById("TxtVoteBal").value=x;
		sum+=x;
	}
 	var ttl=sum.toFixed(2); //format to two decimal places
	document.getElementById("TxtTtlFee").value=addCommas(ttl);
	document.getElementById("TxtWords").value=toWords(ttl);
}