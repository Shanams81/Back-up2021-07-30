<?php
  include_once('shanam.php');
  mysqli_multi_query($conn,"SELECT finyr FROM ss; SELECT abbr FROM acc_voteacs WHERE markdel=0 and stud_assoc=1;"); $noacs=$i=0;
  do{if($rs=mysqli_store_result($conn)){if($i==0){if (mysqli_num_rows($rs)>0) list($yr)=mysqli_fetch_row($rs); else $yr=date('Y');
    }else{$noacs=mysqli_num_rows($rs); while($d=mysqli_fetch_row($rs)) $accounts[]=$d[0];}mysqli_free_result($rs); } $i++;
  }while (mysqli_next_result($conn)); $info=isset($_POST['txtFind'])?trim(strip_tags($_POST['txtFind'])):"%";		$findby=isset($_POST['radFind'])?$_POST['radFind']:"stud_names";
  $info=strlen($info)==0?"%":$info; headings('',0,0,2);
?><div class="container" style="background:#e6e6e6;margin:15px auto;border-radius:20px 0;max-width:1000px;"><div class="form-row"><div class="col-md-12" style="font-size:0.9rem;
margin:5px;">
<form method="post" action="#"><a href="pupil_manager.php"><Img src="img\ani_back.gif" Align="left" Height="20" width="60" hspace="5"></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  Find Student By either <input type="radio" name="radFind" id="radAdm" value="admno" onclick="clrText()">Adm. No.&nbsp; <input type="radio" name="radFind" id="radCls" value="class"
  onclick="clrText()">Class &nbsp;&nbsp;&nbsp;<input type="radio" name="radFind" id="radName" value="stud_names" checked onclick="clrText()">Names &nbsp;&nbsp;<input type="text"
  maxlength="13" size="20" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Search for a Pupil" title="Type what to search here"></form></div></div>
<div class="form-row"><div class="col-md-12" style="background-color:#f6f6f6;border:0.5px groove #007;border-radius:10px 10px 0 0;max-height:270px;max-width:1000px;min-height:50px;
overflow-y:scroll;">
<table id="myTable" class="table table-sm table-striped table-hover table-bordered" style="font-size:0.8rem;margin:0 auto;"><thead class="thead-dark"><tr><th colspan="4">DETAILS
  OF PUPILS</th><th	colspan="<?php echo $noacs;?>">ARREARS B/F</th><th colspan="2">OTHER CHARGES</th><th colspan="2">ADMIN ACTION</th></tr><tr><th>ADM. NO.</th><th>NAMES</th><th>
  FORM/GRADE</th><th>TEL.	NO.</th><?php foreach($accounts as $ac) echo "<th>$ac</th>";?><th>MEDICAL</th><th>UNIFORM</th><th>FEES</th><th>STATEMENT</th></tr></tr></thead><tbody>
<?php
    $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,s.telno,";
    if($noacs>1) $sql.="a.arbf,a.marbf,";	else $sql.="a.arbf,";
    $sql.="a.med,a.uni FROM  stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN (SELECT admno,sum(bbf) as arbf,sum(miscbf) as marbf,
    sum(spemed) as med,sum(unifrm) as uni FROM class group by	admno)a USING (admno) WHERE s.present=1 and s.markdel=0 and s.curr_year IN (SELECT finyr FROM ss) ORDER BY admno ASC";
    $rsStud=mysqli_query($conn,$sql); $nos=0;
    while ($rsS=mysqli_fetch_array($rsStud,MYSQLI_NUM)){     print "<tr>"; $a=0; $nos++;
        foreach($rsS as $sr){
            if ($a==0) $adnum=$sr; if ($a<4) print "<td valign=\"top\">$sr</td>";
            else {print "<td align=\"right\" class=\"b\">".number_format($sr,2)."</td>";}            $a++;
        }print "<td align=\"center\"><a href=\"feerec.php?cod=$adnum-$yr\">Receive</a></td><td align=\"center\"><a onclick=\"showReceipt($adnum,$yr)\" href=\"#\">View</a></td></tr>";
    } mysqli_free_result($rsStud);
?></tbody></table></div></div>
<div class="form-row"><div class="col-md-12" id="spNoS" style="font-size:10pt;font-weight:bold;color:#00f;border:0px;border-radius:2px;padding:3px;"><?php echo $nos;?> Student(s)'
  Records</div>
</div><div class="form-row"><div class="col-md-12" style="border:1px dotted #ff0;border-radius:8px;background:#e6e6e6;color:#000;font-size:0.8rem;padding:5px;overflow-y:scroll;
  max-height:600px;text-align:center;" id="divState">Student Fee Statement will appear here</div>
</div>
</div>
<script type="text/javascript" src="tpl/printthis.js"></script><script type="text/javascript" src="tpl/js/studfee.js"></script>
<?php mysqli_close($conn);	footer(); ?>
