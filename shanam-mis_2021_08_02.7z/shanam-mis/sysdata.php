<?php
	include_once("shanam.php");
	$s=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0';  $s=preg_split("/\-/",$s);
	headings('',$s[0],$s[1],1);
	mysqli_multi_query($conn,"SELECT sysdata FROM gen_priv WHERE uname LIKE '".$_SESSION["username"]."'; SELECT s.sysDate,s.scnm,s.scabb,s.scadd,s.telno,s.principal,s.motto,s.mission,s.vision,
	s.nssfno,s.nhifno,s.emppin,s.finyr,s.mpr,s.nssfrate,s.bursreceipt,s.typerecno,s.bursType,s.paybillNo,s.paybillAC,s.receipt,s.receiptType,s.NoImps,c.name,m.name as mp,w.name as mca FROM
	`ss` s Inner Join county c On (s.county=c.code) Inner Join constituency m on (s.constituency=m.code) Inner Join ward w on (s.ward=w.code);"); $i=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){
			 	if (mysqli_num_rows($rs)>0) list($add)=mysqli_fetch_row($rs); else $add=0;
			}else{
				if (mysqli_num_rows($rs)>0){
					list($sysdate,$scnm,$scabb,$scadd,$tel,$princ,$motto,$mission,$vision,$nssf,$nhif,$pin,$finyr,$mpr,$nsrate,$bursrec,$typrec,$burstype,$pbno,$pbac,$recno,$rectype,$noimp,
					$gov,$mp,$mca)=mysqli_fetch_row($rs);		$sysdate=date('l j - F - Y',strtotime($sysdate));
				}else{
					$sysdate=date('l j - F - Y');	$scnm='School Name Not Set';	$scadd='';	$princ='';		$nssf='';	$nhif='';	$pin='';	$mission='';	$motto='';
					$minbal='';	$minbal='';		$finyr='';	$vision=''; $noimp=1;	$mpr=0;		$nrec=0;		$nsrate=2;	$typrec=0;	$rectype=0;	$burstype=0;	$bursrec=0;		$scabb='';
					$pbno='';	$pbac='';		$gov='';	$mp='';		$mca='';	$tel='';
				}
			}mysqli_free_result($rs);
		}$i++;
	}while (mysqli_next_result($conn));
?><h1 style="letter-spacing:3px;word-spacing:4px;text-align:center;">DETAILS OF THE INSTITUTION</h1>
<div class="container" style="border:1px dotted #fff;border-radius:15px 15px 0 0;padding:5px 10px;max-width:700px;background-color:#eee;">
	<div class="form-row">
		<div class="col-md-5"><label for="pName">Name of the Institution</label><p id="pName" class="pout"><?php echo $scnm;?></p></div>
		<div class="col-md-3"><label for="pAbbr">Abbreviation of Name</label><p id="pAbbr" class="pout"><?php echo $scabb;?></p></div>
		<div class="col-md-4"><label for="pMotto">Motto:</label><p id="pMotto" class="pout"><?php echo $motto;?></p></div>
	</div>
	<div class="form-row">
		<div class="col-md-8"><label for="pAddr">Postal Address:</label><p id="pAddr" class="pout"><?php echo $scadd;?></p></div>
		<div class="col-md-4"><label for="pTel">Telephone/ Mobile No.:</label><p id="pTel" class="pout"><?php echo $tel;?></p></div>
	</div>
	<div class="form-row">
		<div class="col-md-8"><label for="pMission">Mission:</label><p id="pMission" class="pout"><?php echo $mission;?></p></div>
		<div class="col-md-4"><label for="pVision">Vision:</label><p id="pVision" class="pout"><?php echo $vision;?></p></div>
	</div>
	<div class="form-row">
		<div class="col-md-2"><label for="pNHIF">NHIF Code:</label><p id="pNHIF" class="pout"><?php echo $nhif;?></p></div>
		<div class="col-md-2"><label for="pNSSF">NSSF Code:</label><p id="pNSSF" class="pout"><?php echo $nssf;?></p></div>
		<div class="col-md-3"><label for="pNSSFR">NSSF Deduction Rate</label><p id="pNSSFR" class="pout"><?php echo $nsrate;?>%</p></div>
		<div class="col-md-3"><label for="pKRA">KRA PIN No. :</label><p id="pKRA" class="pout"><?php echo $pin;?></p></div>
		<div class="col-md-2"><label for="pMPR">PAYE Relief</label><p id="pMPR" class="pout"><?php echo number_format($mpr,2);?></p></div>
	</div><div class="form-row">
		<div class="col-md-2"><label for="pMBN">M-Fee Business No.</label><p id="pMBN" class="pout"><?php echo $pbno;?></p></div>
		<div class="col-md-2"><label for="pMAN">M-Fee Account No.</label><p id="pMAN" class="pout"><?php echo $pbac;?></p></div>
		<div class="col-md-3"><label for="pNOI">Max No. of Imprests:</label><p id="pNOI" class="pout"><?php echo $noimp;?></p></div>
		<div class="col-md-3"><label for="pImp">Receipt Paper Size</label><p id="pImp" class="pout"><?php echo ($recno==0?'A4':'A5').' RECEIPT';?></p></div>
		<div class="col-md-2"><label for="p2in1">2 in 1 Receipt?</label><p id="p2in1" class="pout"><?php echo ($rectype==0?'YES (2 in 1 Receipt)':'Each A/C Receipt');?></p></div>
	</div><div class="form-row">
		<div class="col-md-12"><label for="pLoc">The Institution is Located in</label><p id="pLoc" class="pout"><?php echo $gov.' COUNTY, '.$mp.' CONSTITUENCY, '.$mca.' WARD';?></p></div>
	</div><div class="form-row">
		<div class="col-md-6"><label for="pMotto">Director/Headteacher/ Principal:</label><p id="pMotto" class="pout"><?php echo $princ;?></p></div>
		<div class="col-md-3"><label for="pBRA">Bursary Received As:</label><p id="pBRA" class="pout"><?php echo $burstype==0?"CHEQUE":"CASH";?></p></div>
		<div class="col-md-3"><label for="pBR">Print Bursary Receipt?</label><p id="pBR" class="pout"><?php echo ($bursrec==1?'YES PRINT':'DON\'T PRINT');?></p></div>
	</div>
</div><br><center><a href="sysdataedit.php"><button name="CmdEdit" <?php if ($add==0) print "disabled";?> type="button" style="border:1px groove #ddd;border-radius:5px;padding:3px;
letter-spacing:3px;word-spacing:4px;font-weight:bold;">Edit System Data</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="settings_manager.php"><button name="cmdCLose" type="button" style="border:1px groove #ddd;border-radius:5px;padding:3px;
letter-spacing:3px;word-spacing:4px;font-weight:bold;">Close</button></a></center>
<?php mysqli_close($conn); footer();?>
