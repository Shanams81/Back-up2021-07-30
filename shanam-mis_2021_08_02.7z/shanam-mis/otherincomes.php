<?php
    include_once('shanam.php');
    if(isset($_POST['btnSave'])){
        $token=sanitize($_POST['txtTkn']);                                                          $code=isset($_POST['txtCode'])?sanitize($_POST['txtCode']):'';
        $idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):0;                               $date=isset($_POST['dtpRecOn'])?sanitize($_POST['dtpRecOn']):date('Y-m-d');
        $name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName']))):null;
        $telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):null;                         $acc=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;
        $address=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):null;
        $mode=isset($_POST['cboMode'])?strtoupper(sanitize($_POST['cboMode'])):'DIRECT BANKING';    $vote=isset($_POST['cboVote'])?sanitize($_POST['cboVote']):0;
        $modeno=isset($_POST['txtCheNo'])?strtoupper(sanitize($_POST['txtCheNo'])):null;            $bankno=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;
        $prod=isset($_POST['cboProduct'])?sanitize($_POST['cboProduct']):'';                        $bankno=($bankno>0?$bankno:null);	 $date=preg_split('/\-/',$date);
        $amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0;                                  $bc=isset($_POST['txtBC'])?sanitize($_POST['txtBC']):0;
        $amt=preg_replace('/[^0-9\.]/','',$amt); $bc=preg_replace('/[^0-9\.]/','',$bc);             $modeno=strlen($modeno)>0?$modeno:null;
        $addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';            $hireon=isset($_POST['dtpHiredOn'])?strtoupper(sanitize($_POST['dtpHiredOn'])):date('d-m-Y');
        $kind=isset($_POST['txtKind'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtKind']))):null; 	$kind=strlen($kind)>0?$kind:null;
        $rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtRmks']))):null; $rmks=strlen($rmks)>0?$rmks:null;
        $hireon=preg_split('/\-/',$hireon);		$date="$date[2]-$date[1]-$date[0]";         $hireon="$hireon[2]-$hireon[1]-$hireon[0]";         $vono=0;
        if (($amt<=0) || ((strcasecmp($mode,"Cash")!=0 && strcasecmp($mode,"Kind")!=0) && strlen($modeno)==0) || (strcasecmp($mode,"Kind")==0  && strlen($kind)<10 && strlen($name)<8
        && strlen($telno)<9 && strlen($idno)<7) || ((strcasecmp($mode,"cheque")==0 || strcasecmp($mode,"direct banking")==0) && (is_null($bankno) || is_null($modeno))) || (strcasecmp($mode,
        "mfees")==0 && is_null($modeno)) || ($_SESSION['form_token']!=$token) || is_null($rmks) || strlen($rmks)<10 || $acc<1 || $vote<1 && strlen($code)<5){
            print "Sorry, the alternative income record had errors. The reciept was not sucessfully saved. Click <a href=\"otherincomes.php\">here</a> to try again";
            unset($_SESSION['form_token']); exit(0);
        }else{
            $recno=0; unset($_SESSION['form_token']);	$norec=0;
            $sql="INSERT INTO acc_alterincome(code, alt_names, telno,idno,paddress,product,hiredate, rmks, acc, voteno, addedby) VALUES('$code',".var_export($name,true).",'$telno',".
            var_export($idno,true).",".var_export($address,true).",'$prod','$hireon',".var_export($rmks,true).",$acc,$vote,'$addby')";
            if (mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"otherincomes.php\">HERE</a> to try again.")){
              $sql="INSERT INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,kinddescr,addedby,commt) VALUES(0,'$code','$date','In-Person','$mode',
              ".var_export($modeno,true).",Null,".var_export($bankno,true).",".var_export($kind,true).",'$addby',2)";
              if (mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"otherincomes.php\">HERE</a> to try again.")){
                $sno=mysqli_insert_id($conn);
                $sql="INSERT INTO ".($acc==1?"acc_incorecno0":"acc_incorecno1")." (recno,sno,acc,bc,amt) VALUES (0,$sno,'$acc',$bc,$amt);";
                if(mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"otherincomes.php\">HERE</a> to try again.")){
                  $recno=mysqli_insert_id($conn);  mysqli_query($conn,"INSERT INTO acc_incovotes(recno,acc,voteno,pytdate,amt,markdel) VALUES($recno,'$acc','$vote','$date',$amt,0)") or
                  die(mysqli_error($conn).". Click <a href=\"otherincomes.php\">HERE</a> to try again.");
                }
              }$norec=1;
            }if(strlen($kind)>0 && $norec>0){//Income received in kind
              mysqli_multi_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno'; SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '1';") or die(mysqli_error($conn).". Click <a "
              . "href=\"otherincomes.php\">HERE</a> to try again.");
              $i=$payno=$vono=0;
              do{
                  if($rs=mysqli_store_result($conn)){
                    if($i==0){$no=mysqli_num_rows($rs); if ($no>0) list($payno)=mysqli_fetch_row($rs);
                    }else{$no=mysqli_num_rows($rs); if ($no>0) list($vono)=mysqli_fetch_row($rs);
                    } mysqli_free_result($rs);
                  }$i++;
              }while(mysqli_next_result($conn)); $vono++;
              if($payno==0){//paye details are not in the system
                if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES(0,curdate(),'$name','$idno',".var_export($addr,true).",'$telno',
                '$addby')") or die(mysqli_error($conn).". Click <a href=\"otherincomes.php\">HERE</a> to try again.")){
                    $payno=mysqli_insert_id($conn);
                }
              }mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,pytfrm,acc,caamt,rmks,expno,addedby,recsno) values ($vono,curdate(),'Cash',$acc,$amt,'BEING PAYMENT TO CLEAR
              FEES INKIND - $kind',$payno,'$addby',$sno); INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,$acc,$vote,$amt);") or die(mysqli_error($conn));
            }
    } header("Location:rpts/receiptoi.php?recno=$sno-$acc-$vono-0");
}else{$act=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):'0-0'; 		$act=preg_split('/\-/',$act);	$cuyr=date('Y');}
$sdate= isset($_REQUEST['dtpStart'])?$_REQUEST['dtpStart']:date("d-m-Y",strtotime("-30 days"));	$edate= isset($_REQUEST['dtpEnd'])?$_REQUEST['dtpEnd']:date("d-m-Y");
$acc=isset($_POST['cboAccount'])?strtoupper(strip_tags($_POST['cboAccount'])):1;	$opt=isset($_POST['cboType'])?strtoupper(strip_tags($_POST['cboType'])):'%';
$sdate=preg_split('/\-/',$sdate); $sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];		$edate=preg_split('/\-/',$edate); $edate=$edate[2].'-'.$edate[1].'-'.$edate[0];
$tkn=uniqid();  	$_SESSION['form_token']=$tkn;
headings('<link rel="stylesheet" href="/date/tcal.css" /><link href="tpl/css/headers.css" rel="stylesheet" /><link rel="stylesheet" href="tpl/css/modalfrm.css" /><link rel="stylesheet" href="tpl/css/inputsettings.css" />',
$act[0],$act[1],2);
?><div class="head"><form method="post" action="otherincomes.php" onsubmit="return checkAnalysisData(this)">Alternative Incomes Received in <SELECT name="cboAccount" id="cboAccount" size="1">
<?php
    mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0; SELECT feeedit FROM acc_priv WHERE '".$_SESSION['username']."'; SELECT max(convert(substring(code,2),unsigned integer))
    as co FROM acc_alterincome;"); $i=$edit=0;
    do{if($rs=mysqli_store_result($conn)){
        if($i==0) while($d=mysqli_fetch_row($rs)){if($acc==$d[0]) $acname=$d[1]; print "<option value=\"$d[0]\" ".($acc==$d[0]?"selected":"").">$d[1]</option>";}
        elseif($i==1)list($edit)=mysqli_fetch_row($rs); else{$code=0; if(mysqli_num_rows($rs)>0) list($code)=mysqli_fetch_row($rs); $code++; $n=strlen($code);
        $code=($n==1?"A0000$code":($n==2?"A000$code":($n==3?"A00$code":($n==3?"A0$code":"A$code"))));}    mysqli_free_result($rs);
      }$i++;}while(mysqli_next_result($conn));
    print "</select> ";
    print "&nbsp; Between <input name=\"dtpStart\" id=\"dtpStart\" class=\"tcal\" type=\"text\" value=\"".date("d-m-Y",strtotime($sdate))."\" readonly size=8 style=\"background:#fff;\"> and <input name=\"dtpEnd\"
    name=\"dtpEnd\" class=\"tcal\" style=\"background:#fff;\" type=\"text\" value=\"".date("d-m-Y",strtotime($edate))."\" readonly size=8>";
?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name="Show">View Income Received</button></form></div>
<?php
    $h=$acname." Alternative Income Received Between <font color=\"#00f\">".date("D d-M-Y",strtotime($sdate))."</font> and <font color=\"#00f\">".date("D d-M-Y",strtotime($edate)).
    "</font>";
    print '<div id="FeesPaid" style="border:1px groove #eee;border-radius:20px 20px 0 0;background-color:#ffe;padding:10px;width:fit-content;margin:auto;"><div style="background-color:#666;color:#fff;padding:3px;">
    Find Income By &nbsp;<input type="radio" name="radFindBy" id="radRecNo" value="recieptno" checked onclick="clrFind()">Receipt No.&nbsp;&nbsp;<input type="radio" name="radFindBy"
    id="radName" value="names" onclick="clrFind()">Names &nbsp;&nbsp;<input type="radio" name="radFindBy" id="radIDNo" value="form" onclick="clrFind()">ID No. &nbsp;&nbsp;&nbsp;&nbsp;
    <input type="text" maxlength=10 size=25 id="txtFind" name="txtFind" value="" placeholder="Type here what to find" onkeyup="findReceipt(this)">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button type="button" name="btnNew" onclick="document.getElementById(\'otherIncomeEdit\').style.display=\'block\'">Receive New Income</button></div><br><h6>'.strtoupper($h).'</h6>';
    print '<div id="dispBursary" style="border:1px dotted #eee;max-height:550px;overflow-y:scroll;padding:3px;"><span id="showFeesPaid">';
    $res=mysqli_query($conn,"SELECT r.sno,f.recno,a.idno,a.alt_names,a.telno,concat(ac.abbr,'<br>',v.descr) as vote,r.pytdate,r.pytfrm,r.cheno,a.product,(f.amt+f.bc) As Ttl,if(r.verbanked=0,
    'Unverified',if(r.verbanked=1,'Banked','Cashed')) as tr,r.verbanked FROM acc_alterincome a Inner Join acc_incofee r ON (a.code=r.admno) INNER JOIN ".($acc==1?"acc_incorecno0":
    "acc_incorecno1")." f ON (r.sno=f.sno) INNER JOIN acc_voteacs ac On (a.acc=ac.acno) Inner Join acc_votes v On (a.voteno=v.sno) WHERE r.markdel=0 AND (r.pytdate BETWEEN '$sdate' AND
    '$edate') Order By f.recno Asc");
    print "<table id=\"tabReceipt\" class=\"table table-striped table-hover table-bordered table-sm\"><thead class=\"thead-dark\"><tr><th>RECEIPT</th><th>RECEIVED ON</th><th>ID NO.
    </th><th>NAMES</th><th>TEL NO.</th><th>VOTEHEAD</th><th>MODE</th><th>MODE NO.</th><th>INCOME FROM</th><th>AMOUNT</th><th>STATUS</th><th>RECEIPT</th></tr></thead><tbody>"; $ttl=0;
    if (mysqli_num_rows($res)>0) while (list($sno,$recno,$idno,$names,$tel,$vote,$date,$pytfrm,$chno,$prod,$amt,$status,$no)=mysqli_fetch_row($res)){
        $days=(strtotime(date('Y-m-d'))-strtotime($date))/86400;
        print "<tr><td>$recno</td><td align=\"right\">".date('D d M, Y',strtotime($date))."</td><td>$idno</td><td>$names</td><td>$tel</td><td>$vote</td><td>$pytfrm</td><td>$chno</td><td>
        $prod</td><td align=\"right\"><b>".number_format($amt,2)."</b></td><td>$status</td><td align=\"center\">".(($days<2 && $no==0)?"<a style=\"background:inherit;\"
        onclick=\"return canEdit($edit)\" href=\"otherincomesedit.php?rec=$acc-$sno\"><img src=\"../gen_img/edit.ico\" width=18 height=16 title=\"Edit\"></a>&nbsp;&nbsp;&nbsp;":"").
        "<a style=\"background:inherit;\" href=\"rpts/receiptoi.php?recno=$sno-$acc-0-1\" target=\"_BLANK\"><img src=\"../gen_img/print.ico\" width=18 height=16 title=\"Print\"></a></td></tr>";	$ttl+=$amt;
    }else print "<tr><td colspan=\"12\"><br>No alternative income received between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate))."</td></tr>";
    print "</tbody><tfoot><tr><th colspan=5 align=\"left\"><span id=\"spNoF\">".mysqli_num_rows($res)." Fees Payment Record(s)</span></th><th colspan=4	align=\"right\">
    Total Kshs.</th><th align=\"right\"><span id=\"spTtl\">".number_format($ttl,2)."</span></th><th colspan=2></th></tr></tfoot></table>";
    mysqli_free_result($res);
    print "</span></div><span align=\"center\"><br><a href=\"pdf/feevoteanalysis.php?rec=0.$sdate.$edate.$acc.2\" target=\"_BLANK\"><img src=\"../gen_img/print.ico\" height=25 width=25>
    Printable Report</a></div>";
?>
<div id="otherIncomeEdit" class="modal"><div class="container divmodalmain">
    <div class="imgcontainer"><span onclick="document.getElementById('otherIncomeEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
    <form name="frmOtherIncomes" method="post" action="otherincomes.php" onsubmit="return validateData(this)"><INPUT name="txtTkn" type="hidden" size=4 value="<?php echo $tkn;?>" id="txtTkn">
    <div class="form-row">
        <div class="col-md-4"><label for="txtCode">Source Code</label><input class="modalinput" type="text" name="txtCode" id="txtCode"required readonly value="<?php echo $code;?>"></div>
        <div class="col-md-4"><label for="txtRecNo">Receipt No.</label><input class="modalinput" type="text" name="txtRecNo" id="txtRecNo" readonly value="" placeholder="Auto"></div>
        <div class="col-md-4"><label for="dtpRecOn">Received On</label><input type="text" name="dtpRecOn" id="dtpRecOn" class="tcal modalinput" required readonly value="<?php echo date('d-m-Y');?>"></div>
    </div><div class="form-row">
        <div class="col-md-12 divheadings">DETAILS OF THE SOURCE OF INCOME</div>
    </div><div class="form-row">
        <div class="col-md-6"><label for="txtIDNo">ID No. </label><input type="text" class="modalinput" name="txtIDNo" id="txtIDNo" maxlength=10 onkeyup="checkInput(0,this)" onchange="showDetails(this)"></div>
        <div class="col-md-6"><label for="txtTelNo">Tel. No. *</label><input class="modalinput" type="text" name="txtTelNo" id="txtTelNo" required maxlength=13 value="" placeholder="+254700000000"
        onkeyup="checkInput(0,this)"></div>
    </div><div class="form-row">
        <div class="col-md-12"><label for="txtName">Income Received From *</label><input type="text" name="txtName" id="txtName" required maxlength=30 class="modalinput" placeholder="Names of Income Source"
        onkeyup="checkInput(2,this)"></div>
    </div><div class="form-row">
        <div class="col-md-12"><label for="txtAddress">Postal Address *</label><input type="text" name="txtAddress" id="txtAddress" maxlength=35 class="modalinput" placeholder="P.O Box 111-50406, Funyula"></div>
    </div><div class="form-row">
        <div class="col-md-12 divheadings">DETAILS OF THE INCOME RECEIVED</div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="cboAC">Account Receiving Income *</label><SELECT name="cboAC" id="cboAC" onchange="showVotes(this)" size=1 class="modalinput"><option value=0 selected>None</option>
        <?php
            mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0; SELECT sno,acc,descr FROM acc_votes WHERE other_inco=1 and sno>4 and acc IN (SELECT acno FROM
            acc_voteacs WHERE stud_assoc=1); SELECT sno,descr FROM acc_banks WHERE markdel=0 ORDER BY descr ASC;"); $i=0;
            do{
                if($rs=mysqli_store_result($conn)){
                    if($i==0) while($d=mysqli_fetch_row($rs)) echo "<option value=\"$d[0]\">$d[1]</option>";
                    elseif($i==1){ $a=0; $optVote='';  $votes='';
                        while($d=mysqli_fetch_row($rs)){if($d[1]==1) $optVote.="<option value=\"$d[0]\">$d[2]</option>"; $votes.=($a==0?"":",")."new Votes($d[0],$d[1],'$d[2]')"; $a++;}
                    }else{$optBank=''; while($d=mysqli_fetch_row($rs)) $optBank.="<option value=\"$d[0]\">$d[1]</option>";}
                    mysqli_free_result($rs);
                }$i++;
            }while(mysqli_next_result($conn));
        ?></select></div>
        <div class="col-md-8"><label for="cboVote">Votehead *</label><SELECT name="cboVote" id="cboVote" size=1 class="modalinput"><option value=0 selected>None</option><?php echo $optVote;?></SELECT></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="cboProduct">Being Income From *</label><SELECT name="cboProduct" id="cboProduct" Size=1 onchange="showHireDetails(this)" class="modalinput"><?php echo $optProd;?></SELECT></div>
        <div class="col-md-8"><label for="txtRmks">Narration on the Income *</label><textarea name="txtRmks" class="modalinput" id="txtRmks" maxlength=75 rows=2
        placeholder="Hire of school bus to wedding... or .... Sale of 10 litres of milk."></textarea></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="cboProduct">Mode of Income </label><SELECT name="cboMode" id="cboMode" size=1 onchange="actPytFrm(this)" class="modalinput"><option value="CASH" selected>
        Cash</option><option value="KIND">Kind</option><option value="CHEQUE">Cheque</option><option value="DIRECT BANKING">Direct Banking</option><option value="MONEY ORDER">Money Order
        </option><option value="MFEES">M-Fees</option></SELECT></div>
        <div class="col-md-4"><label for="txtCheNo">Trans/ Cheque No.</label><input type="text" name="txtCheNo" id="txtCheNo" readonly value="" placeholder="01234" maxlength=15 class="modalinput"></div>
        <div class="col-md-4"><label for="cboBank">Banker (if Cheque/ Bankslip)</label><SELECT name="cboBank" id="cboBank" size=1 disabled class="modalinput"><option value=0 selected>None</option><?php
        echo $optBank;?></SELECT></div>
    </div><div class="form-row" id="spKind" style="display:none;">
        <div class="col-md-12"><label for="txtKind">Kind Description (If paid in Kind) *</label><textarea name="txtKind" id="txtKind" rows=2 maxlength=145 class="modalinput" placeholder="2 90KG
        BAGS OF MAIZE"></textarea></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="txtAmt">Amount Received *</label><input type="text" name="txtAmt" id="txtAmt" value="0.00" style="text-align:right;" class="modalinput" onkeyup="checkInput(1,this)"
        onchange="calcTtl()"></div>
        <div class="col-md-4"><label for="txtBC">Bank Charges *</label><input type="text" name="txtBC" id="txtBC" value="0.00" style="text-align:right;" class="modalinput" onkeyup="checkInput(1,this)"
        readonly onchange="calcTtl()"></div>
        <div class="col-md-4"><label for="txtTtl">Total Amount Received *</label><input type="text" name="txtTtl" id="txtTtl" disabled value="0.00" class="modalinput"></div>
    </div><div class="form-row" id="spHire" style="display:none;">
        <div class="col-md-12">
            <div class="form-row"><div class="col-md-12 divheadings">ASSET/ FACILITY HIRED FOR DATE</div></div>
            <div class="form-row"><div class="col-md-4"><label for="dtpHiredOn">Hired On * </label><input type="text" name="dtpHiredOn" id="dtpHiredOn" readonly class="tcal modalinput"
                value="<?php echo date('d-m-Y',strtotime('+2 days'));?>"></div>
            </div>
        </div>
    </div><br><div class="form-row">
        <div class="col-md-4"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSave">Save Changes</button></div>
        <div class="col-md-4" id="spDelete" style="text-align:center;"></div>
        <div class="col-md-4" style="text-align:right;"><button type="button" onclick="document.getElementById('otherIncomeEdit').style.display='none'" class="btn btn-info btn-md">Close</button></div>
     </div></form>
    </div>
</div>
<script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/otherincomes.js"></script>
<?php
    if(isset($votes)){echo '<script type="text/javascript"> votes.push('.$votes.');</script>';}
    mysqli_close($conn); footer();
?>
