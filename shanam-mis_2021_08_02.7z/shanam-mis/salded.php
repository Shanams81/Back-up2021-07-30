<?php
	include_once('../conn/pri_sch_connect.inc');
	include_once('../mpdf/mpdf.php');
	$dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0-0-0";
	$dat=preg_split("/\-/",$dat);	//0 - Month, 1 - Year, 2 - deduction name and 3 - Cheque number
	//Name of deduction
	if (strcasecmp($dat[2],"nssf")==0) $ded="N . S . S . F"; elseif (strcasecmp($dat[2],"nhif")==0) $ded="N . H . I . F";
	elseif (strcasecmp($dat[2],"tax")==0) $ded="PAYE Tax"; elseif (strcasecmp($dat[2],"union")==0) $ded="Union Dues";
	elseif (strcasecmp($dat[2],"ole")==0) $ded="Other Deductions"; elseif (strcasecmp($dat[2],"sacco")==0) $ded="SACCO"; 
	elseif (strcasecmp($dat[2],"welfare")==0) $ded="Worker's Welfare"; else $ded="Salary Advances";
	//fieldname of the deduction
	if (strcasecmp($dat[2],"union")==0) $field="union1"; elseif (strcasecmp($dat[2],"tax")==0) $field="taxes1"; 
	elseif (strcasecmp($dat[2],"ole")==0) $field="otherlevies1"; else $field="advance";
	$h=strtoupper($dat[0].'-'.$dat[1].' '.$ded.' Monthly remittance');
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,mission,motto,emppin,nhifno,nssfno FROM ss"); 
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mis,$mot,$epin,$nsno,$nhno)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	//start pdf file
	$mpdf=new mPDF('c','A4','','',10,10,12,12,10,10); 
	$mpdf->useOnlyCoreFonts = true;    // false is default
	$mpdf->SetWatermarkText("$ded Monthly Remittances of $dat[0]-$dat[1]");
	$mpdf->showWatermarkText = true;
	$mpdf->watermark_font = 'DejaVuSansCondensed';
	$mpdf->watermarkTextAlpha = 0.1;
	$mpdf->SetDisplayMode('fullpage');
	$mpdf->setFooter('Invalid Without the official stamp										Page {PAGENO} of {nbpg} Pages');
	$html='<html><head><title>'.$dat[0].' - '.$dat[1].' Payroll</title><style> 
			table.hide {border:0px;collapse;font-size:12px;font-weight:bold;letter-spacing:2px;word-spacing:3px;}
			td.hide,th.hide{border:0px;}
			table.gen,td,th {border:1px solid blue;border-collapse:collapse;font-weight:normal;font-size:12px;}
			p{font-size:12px;line-spacing:6pt;}
			</style></head><body>';
	$dat[2]=trim($dat[2]);
	$html.='<table cellspacing="0" width="100%" class="hide"><tr><td rowspan="3" valign="middle" width="90" align="center" class="hide"><img 
	src="img/logo.png" width="70" height="80" vspace="1" hspace="1"></td><td class="hide">'.$scnm.'</td></tr><tr><td class="hide">'.$scadd.'
	</td></tr><tr><td class="hide">'.$mot.'</td></tr><tr><td colspan="2" class="hide"><hr><b style="font-size:12px;">'.$h.'</b>&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;Printed On:'.date("D d-M-Y").'<hr></td></tr></table>';
	$html.='<p>Employer\'s PIN No. <u>'.$epin.'</u>&nbsp;&nbsp;&nbsp;&nbsp;'.((strcasecmp($dat[2],"nssf")==0||strcasecmp($dat[2],"nhif")==0)?
	("Employer\'s $ded No. ".(strcasecmp($dat[2],"nssf")==0?$nsno:$nhno)):"").'.<br><br>Dear Sir/ Madam,<br>You are hereby kindly informed that 
	the attached cheque number '.$dat[3].' is the '.$dat[0].'-'.$dat[1].' '.$ded.' monthly contributions from members listed below.</p>';
	//SQL to retrieve data
	if (strcasecmp($dat[2],"nssf")==0) $sql="SELECT sd.nssfno,s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.dob,(sp.empnssf+sp.nssffee1) as nssf FROM Stf s 
	INNER JOIN Acc_SalDef sd Using (idno) INNER JOIN Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And 
	(sp.sal_year LIKE '$dat[1]') and (sp.nssffee1>0) and sp.markdel=0) ORDER BY s.surname,s.onames ASC";
	elseif (strcasecmp($dat[2],"nhif")==0) $sql="SELECT sd.nhifno,s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.dob,sp.nhiffee1 FROM Stf s INNER JOIN 
	Acc_SalDef sd Using (idno) INNER JOIN Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And (sp.sal_year LIKE 
	'$dat[1]') and (sp.nhiffee1>0) and sp.markdel=0) ORDER BY s.surname,s.onames ASC";
	elseif (strcasecmp($dat[2],"tax")==0) $sql="SELECT s.krapin,s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.dob,(sp.paye1-sp.mpr1) as taxes1 FROM Stf s INNER 
	JOIN Acc_SalDef sd Using (idno) INNER JOIN Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And (sp.sal_year 
	LIKE '$dat[1]') and ((sp.paye1-sp.mpr1)>0) and sp.markdel=0) ORDER BY s.surname,s.onames ASC";
	elseif (strcasecmp($dat[2],"sacco")==0) $sql="SELECT ('xxxxxx') as num,s.idno,sd.payrollno,s.st_names,s.dob,sp.sacco1 FROM Stf s INNER 
	JOIN Acc_SalDef sd Using (idno) INNER JOIN Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And (sp.sal_year 
	LIKE '$dat[1]') and (sp.sacco1>0) and sp.markdel=0) ORDER BY s.st_names ASC";
	elseif (strcasecmp($dat[2],"welfare")==0) $sql="SELECT ('xxxxxx') as num,s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.dob,sp.welfare1 FROM Stf s INNER 
	JOIN Acc_SalDef sd Using (idno) INNER JOIN Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And (sp.sal_year 
	LIKE '$dat[1]') and (sp.welfare1>0) and sp.markdel=0) ORDER BY s.surname,s.onames ASC";
	else $sql="SELECT ('xxxx') as num,s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.dob,sp.$field FROM Stf s INNER JOIN Acc_SalDef sd Using (idno) INNER JOIN 
	Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And (sp.sal_year LIKE '$dat[1]') and (sp.$field>0) and sp.markdel=0) ORDER BY 
	s.surname,s.onames ASC";
	$rsSal=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsSal);
	$html.='<table cellpadding="1" cellspacing="0" class="gen" align="center"><tr bgcolor="#eeeeee"><th><b>S/N</b></th><th><b>'.(strcasecmp($dat[2],"tax")!=0?$ded:"PIN").' No.</b>
	</th><th><b>ID. No.</b></th><th><b>Payroll No.</b></th><th><b>Names</b></th><th><b>Date of Birth</b></th><th><b>Amount</b></th></tr>';
	$tot=0; $i=0;
	if ($nor>0):
		while (list($no,$id,$pr,$na,$dob,$amt)=mysqli_fetch_row($rsSal)):
			if (($i%2)==0) $html.='<tr>'; else $html.='<tr bgcolor="#eeeeee">';
			$html.='<td>'.($i+1).'</td><td>'.$no.'</td><td>'.$id.'</td><td>'.$pr.'</td><td>'.$na.'</td><td align="right">'.date('D d, F Y',
			strtotime($dob)).'</td><td align="right">'.number_format($amt,2).'</td></tr>';
			$tot+=$amt; 	$i++;
		endwhile;
	else:
		$html.='<tr><td colspan="7">No Salary Remittances for '.$dat[0].'-'.$dat[1].'</td></tr>';
	endif;
	$html.='<tr bgcolor="#eeaaaa"><td colspan="4" align="left" class="b"><b>'.$nor.' Staff Members\' Remittances</b></td><td colspan="2" 
	align="right"><b>Total Remittances (Kshs.)</b></td><td align="right"><b>'.number_format($tot,2).'</b></tr></table>';
	mysqli_free_result($rsSal);		$rsSal=mysqli_query($conn,"SELECT principal FROM ss"); 	list($princ)=mysqli_fetch_row($rsSal); 
	mysqli_free_result($rsSal);
	$html.='<br>Thank you.<br>Yours Faithfully, <br><br><br>_________________________<br>'.$princ.'<br>The Director/Principal';
	$html.='</body></html>';
	$mpdf->WriteHTML($html);
	$mpdf->Output();
	mysqli_close($conn);
?>