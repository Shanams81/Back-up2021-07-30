<!DOCTYPE html>
<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):'0-0'; 	$act=preg_split('/\-/',$act);	$cuyr=date('Y');
    $sdate= isset($_REQUEST['dtpStart']) ? $_REQUEST['dtpStart']:date("d-m-Y");	$edate= isset($_REQUEST['dtpEnd'])?$_REQUEST['dtpEnd']:date("d-m-Y");
    $acc=isset($_POST['cboAC'])?strtoupper(strip_tags($_POST['cboAC'])):1;      $opt=isset($_POST['cboType'])?strtoupper(strip_tags($_POST['cboType'])):'%';
    $optName=($opt=='%'?"":($opt==1?"Students Fee":"Alternative Income")); 	$sdate=preg_split('/\-/',$sdate); $sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];
    $edate=preg_split('/\-/',$edate); $edate=$edate[2].'-'.$edate[1].'-'.$edate[0];
    headings('<link rel="stylesheet" href="/date/tcal.css" /><link href="tpl/css/headers.css" rel="stylesheet" /><style>.r{text-align:right}.b{font-weight:bold}a{font-size:0.8rem;font-weigh:bold;letter-spacing:2px;}
    </style>',$act[0],$act[1],2);
?><div class="head">
<form method="post" action="feecollection.php" onsubmit="return checkAnalysisData(this)"><a href="pupil_manager.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20"
align="left"></a>&nbsp;View <select name="cboAC" id="cboAC" size=1>
<?php
    mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0; SELECT feeedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT finyr FROM ss;");
    $i=$fedit=0; $finyr=date('Y');
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0) while($d=mysqli_fetch_row($rs)){if($acc==$d[0]) $acname=$d[1]; print "<option value=\"$d[0]\" ".($acc==$d[0]?"selected":"").">$d[1]</option>";}
            elseif($i==1) list($fedit)=mysqli_fetch_row($rs); else list($finyr)=mysqli_fetch_row($rs);
            mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    print "</select> Receipts from <select name=\"cboType\" id=\"cboType\" size=1 onchange=\"showForm(this)\"><option value=\"%\" selected>All Sources</option><option value=\"1\">Students</option>
    <option value=\"2\">Alternative Incomes</option></select>";
    print "&nbsp; Between <input name=\"dtpStart\" id=\"dtpStart\" class=\"tcal\" type=\"text\" value=\"".date("d-m-Y",strtotime($sdate))."\" readonly size=8 style=\"background-color:#fff;height:20px\">
    and <input name=\"dtpEnd\" name=\"dtpEnd\" class=\"tcal\" style=\"background-color:#fff;height:20px\" type=\"text\" value=\"".date("d-m-Y",strtotime($edate))."\" readonly size=8>";
?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name="Show">View Income Receipts</button>&nbsp;&nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp;&nbsp;<button type="submit"
accesskey="a" name="Analysis">View Income Analysis</button></form></div>
<?php
  if (isset($_POST["Analysis"])){
    $h=$acname." Analysis of $optName From <font color=\"#0000ff\">".date("D d-M-Y",strtotime($sdate))."</font> To <font color=\"#0000ff\">".date("D d-M-Y",strtotime($edate))."</font>";
    print '<div id="feesAnalysis" style="border:1px groove #eee;border-radius:20px;background-color:#ffe;margin:2px auto;padding:10px;max-width:90%;width:fit-content;"><h3 style="font-weight:bold;
    font-size:9pt;">'.strtoupper($h).'</h3><div id="showAnalysis" style="border:0.5px dotted #eee;border-radius:10px;max-height:650px;overflow-y:scroll;">';
    $sql="SELECT f.da,min(f.srec) as srec, max(f.erec) as erec,sum(cash) as Cas,sum(cheque) as Cheq,sum(moord) as MO,sum(db) as DirBa,sum(mfee) as mf,sum(kind) as Kin,sum(cash+cheque+moord+db+mfee+kind) as ttl FROM
    (SELECT i.pytdate As Da,i.pytfrm,min(f.recno) as srec,max(f.recno) as erec,sum(if(i.pytfrm Like 'cash',(f.amt+f.bc-f.transfer),0)) As Cash,sum(if(i.pytfrm Like 'cheque',(f.amt+f.bc-f.transfer),0)) As Cheque,
    sum(if(i.pytfrm Like 'money order',(f.amt+f.bc-f.transfer),0)) As MoOrd,sum(if(i.pytfrm Like 'direct banking',(f.amt+f.bc-f.transfer),0)) As db,sum(if(i.pytfrm Like 'mfees',(f.amt+f.bc-f.transfer),0)) As Mfee,
    sum(if(i.pytfrm Like 'kind',(f.amt+f.bc-f.transfer),0)) As Kind,i.markdel,f.markdel as mk FROM acc_incofee i Inner Join ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno) GROUP BY i.pytdate,i.pytfrm,
    i.markdel,f.markdel HAVING (i.pytdate BETWEEN '$sdate' AND '$edate') and i.markdel=0 and f.markdel=0)f Group By f.da ORDER BY f.da ASC; SELECT f.descr,sum(ttl) as amt FROM (SELECT date(r.recon),v.orderno,v.descr,
    Sum(f.amt) AS ttl FROM ".($acc==1?"acc_incorecno0":"acc_incorecno1")." r Inner Join acc_incovotes f USING (recno,acc) Inner Join acc_votes v on (f.voteno=v.sno) GROUP BY r.recon,r.markdel,v.orderno,v.descr HAVING
    r.markdel=0 and (date(r.recon) Between '$sdate' AND '$edate'))f GROUP BY f.orderno,f.descr ORDER BY f.orderno ASC; SELECT f.descr,sum(if(f.pytfrm Like 'Cheque',f.amt,0)) As Cheq,sum(if(f.pytfrm Like
    'Direct Banking',f.amt,0)) As DB,sum(f.amt) As Ttl FROM (SELECT b.descr,i.pytdate,i.pytfrm,if(isnull(f.amt),0,(f.amt+f.bc-f.transfer)) as amt FROM acc_incofee i Inner Join acc_banks b On (i.bankno=b.sNo) left join ".
    ($acc==1?"acc_incorecno0":"acc_incorecno1")." f on (i.sno=f.sno) WHERE i.MarkDel=0 and (i.PytDate BETWEEN '$sdate' AND '$edate') and i.pytfrm IN ('cheque','direct banking'))f GROUP BY f.pytfrm,f.descr HAVING
    sum(f.amt)>0 Order By f.descr; SELECT f.addedby,sum(cash) as Cas,sum(cheque) as Cheq,sum(moord) as MO,sum(db) as DirBa,sum(mfee) as mf,sum(kind) as Kin,sum(cash+cheque+moord+db+mfee+kind) as ttl FROM (SELECT f.addedby,
    sum(if(f.pytfrm Like 'cash',f.ttl,0)) As Cash,sum(if(f.pytfrm Like 'cheque',f.ttl,0)) As Cheque,sum(if(f.pytfrm Like 'money order',f.ttl,0)) As MoOrd,sum(if(f.pytfrm Like 'direct banking',f.ttl,0)) As db,
    sum(if(f.pytfrm Like 'mfees',f.ttl,0)) As Mfee,sum(if(f.pytfrm Like 'kind',f.ttl,0)) As Kind FROM (SELECT i.pytdate,i.pytfrm,i.addedby,Sum(f.amt+f.bc-f.transfer) As TTL,i.markdel,f.markdel as mk FROM acc_incofee i
    Inner Join ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno) GROUP BY i.pytdate,i.pytfrm,i.addedby,i.markdel,f.markdel HAVING (f.markdel=0  and i.markdel=0 AND (i.pytdate Between '$sdate' AND '$edate')))f
    Group By f.pytfrm,f.addedby)f Group By f.addedby ORDER BY f.addedby ASC";
    mysqli_multi_query($conn,$sql); $i=$nod=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){ $nod=mysqli_num_rows($rs);
              print "<table class=\"table table-striped table-sm table-bordered\"><thead class=\"thead-dark\"><tr><th rowspan=2>DATE</th><th colspan=2>RECEIPT NO. RANGE</th><th colspan=6>FEE COLLECTION PER MODE</th><th
              rowspan=2>DAY'STOTAL</th></tr><tr><th>Start</th><th>End</th><th>Cash</th><th>Cheque</th><th>Money Order</th><th>Bank Slips</th><th>M-Fees</th><th>Kind</th></tr></thead><tbody>";$tca=$tdb=$tch=$tmo=$tki=$tmf=0;
              if ($nod==0)print "<tr><td colspan=\"10\">No fees receipts were made between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate))."</td></tr>";
              else{
                  while (list($date,$sr,$er,$cas,$che,$moord,$dirba,$mfee,$kind,$ttl)=mysqli_fetch_row($rs)):
                    print "<tr><td>".date("D d M, Y", strtotime($date))."</td><td align=\"center\">$sr</td><td align=\"center\">$er</td><td class=\"r\">".number_format($cas,2)."</td><td class=\"r\">".
                    number_format($che,2)."</td><td class=\"r\">".number_format($moord,2)."</td><td class=\"r\">".number_format($dirba,2)."</td><td class=\"r\">".number_format($mfee,2)."</td><td class=\"r\">".
                    number_format($kind,2)."</td><td class=\"r b\">".number_format($ttl,2)."</td></tr>";	$tca+=$cas;	$tch+=$che;	$tdb+=$dirba;	$tmo+=$moord; $tmf+=$mfee; $tki+=$kind;
                  endwhile;

              }print "</tbody><tfoot class=\"thead-light\"><tr><th align=\"right\" colspan=3>Sub totals (Kshs.)</th><th class=\"r b\">".number_format($tca,2)."</th><th class=\"r b\">".number_format($tch,2)."</th>
              <th class=\"r b\">".number_format($tmo,2)."</th><th class=\"r b\">".number_format($tdb,2)."</th><th class=\"r b\">".number_format($tmf,2)."</th><th class=\"r b\">".number_format($tki,2)."</th><th
              class=\"r b\">".number_format(($tca+$tch+$tmo+$tdb+$tmf+$tki),2)."</th></tr></tfoot></table>";
            }elseif($i==1){
                print "<br><br><table class=\"table table-borderless\"><tr class=\"nohover\"><td><table class=\"table table-striped table-sm table-bordered\"><caption style=\"font-weight:bold;"
                . "font-size:12px;\">FEE COLLECTION PER VOTEHEAD</caption><thead class=\"thead-dark\"><tr><th></th><th>Votehead</th><th>Amount (Kshs.)</th></tr></thead><tbody>";  $ttl=0; $a=1;
                while ($d=mysqli_fetch_row($rs)){ $ttl+=$d[1]; print"<tr><td>$a.</td><td>$d[0]</td><td class=\"r\">".number_format($d[1],2)."</td></tr>"; $a++;}
                print "<tr><td>$a.</td><td>BANK CHARGES</td><td class=\"r\">0.00</td></tr></tbody><tfoot class=\"thead-light\"><tr><th colspan=2class=\"r b\">Total Income Receipts (Kshs)</td><th class=\"r b\">".
                number_format($ttl,2)."</th></tr></tfoot></table></td>";
            }elseif($i==2){
                print "<td> &nbsp;&nbsp; - &nbsp;&nbsp; - &nbsp;&nbsp; - &nbsp;&nbsp; </td><td valign=\"top\"><b><u>DIRECT BANKING AND CHEQUE RECEIPTS' ANALYSIS</U></B><table
                class=\"table table-striped table-condensed table-bordered\"><thead class=\"thead-dark\"><tr><th>Bank Name</th><th>Cheque Amt</th><th>Direct Banking</th><th>Bank's Total</th></tr></thead>";
                $ttl=[0,0,0]; if (mysqli_num_rows($rs)>0) while (list($ba,$ch,$db,$tt)=mysqli_fetch_row($rs)){print "<tr><td>$ba</td><td class=\"r\">".number_format($ch,2)."</td><td class=\"r\">".number_format($db,2).
                "</td><td class=\"r b\">".number_format($tt,2)."</td></tr>"; $ttl[0]+=$ch;$ttl[1]+=$db;$ttl[2]+=$tt;}
                else print "<tr><td colspan=\"5\">No Cheque or direct banking receipts were made between ".date("D, d-F-Y",strtotime($sdate))." and ".date("D, d-F-Y",strtotime($edate))."</td></tr>";
                print "<tfoot class=\"thead-light\"><tr><th class=\"r b\">Subtotals</th>"; foreach($ttl as $t) print "<th class=\"r b\">".number_format($t,2)."</th>"; print "</tr></tfoot></table>"
                . "</td></tr></table>";
            }else{
                print "<br><h3 style=\"letter-spacing:5px;word-spacing:8px;font-size:11pt;\">ANALYSIS PER ACCOUNTS DEPARTMENT STAFF</h3><table class=\"table table-striped table-condensed table-bordered\">
                <thead class=\"thead-dark\"><tr><th></th><th>User Name</th><th>Cash</th><th>Cheque</th><th>Money Order</th><th>Bank Slips</th><th>M-Fees</th><th>In-Kind</th><th>Total</th></tr></thead>"; $a=1;
                while (list($un,$ca,$ch,$mo,$db,$mf,$ki,$tt)=mysqli_fetch_row($rs)){
                  print "<tr><td align=\"middle\">$a</td><td>$un</td><td class=\"r\">".number_format($ca,2)."</td><td class=\"r\">".number_format($ch,2)."</td><td class=\"r\">".number_format($mo,2)."</td><td
                  class=\"r\">".number_format($db,2)."</td><td class=\"r\">".number_format($mf,2)."</td><td class=\"r\">".number_format($ki,2)."</td><td class=\"r b\">".number_format($tt,2)."</b></td></tr>"; $a++;
                } print "</table>";
            }mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    print "</div><a href=\"pdf/feevoteanalysis.php?rec=1.$sdate.$edate.$acc.$opt\" target=\"_BLANK\"><img src=\"../gen_img/print.ico\" height=25 width=25>Printable Analysis</a></div>";
  }else{
    print '<div id="FeesPaid" style="border:0px;border-radius:20px 20px 0 0;background-color:#e6e6e6;margin:10px auto;width:fit-content;font-size:10pt;" class="container"><div class="form-row"><div class="col-md-12"
    style="padding:5px;background-color:#555;color:#fff;">Find Fees By &nbsp;<input type="radio" name="radFindBy" id="radRecNo" value="recieptno"
    checked onclick="clrFind()">Receipt No.&nbsp;&nbsp;<input type="radio" name="radFindBy" id="radAdmNo" value="admno"  onclick="clrFind()">Adm/ID No.&nbsp;&nbsp;<input type="radio" name="radFindBy"
    id="radName" value="names" onclick="clrFind()">Names &nbsp;&nbsp;<input type="radio" name="radFindBy" id="radForm" value="form" onclick="clrFind()">Form &nbsp;&nbsp;<input type="text" maxlength=10
    size=25 id="txtFind" name="txtFind" value="" placeholder="Type here what to find" onkeyup="findReceipt(this)"></div></div>';
    $h=$acname." $optName Receipts Between <font color=\"#0000ff\">".date("D d-M-Y",strtotime($sdate))."</font> and <font color=\"#0000ff\">".date("D d-M-Y",strtotime($edate))."</font>";
    print '<div class="form-row"><div class="col-md-12" id="dispBursary" style="border:1px dotted #eee;background-color:inherit;max-height:600px;overflow-y:scroll;padding:3px;"><span id="showFeesPaid"><center><h5>'
    .strtoupper($h).'</h5></center>';
    if ($opt==1) $fee="SELECT r.sno,f.recno,s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',sf.stream) As cls,r.pytdate,r.cheno,r.pytfrm,f.arrears,".($acc==1?"f.refunds":"0 as refunds").",
		(f.amt-".($acc==1?"f.refunds":"0")."-f.arrears-f.transfer+f.bc) as fee, (f.amt-f.transfer+f.bc) As Ttl,0 as comm,s.curr_year as yr FROM stud s Inner Join class sf USING (admno,curr_year) INNER JOIN classnames cn
    USING (clsno) INNER JOIN (acc_incofee r Inner Join ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno)) On s.admno=r.admno WHERE r.commt=0 and r.markdel=0 AND (r.pytdate BETWEEN '$sdate' AND '$edate')
    UNION SELECT f.sno,f.recno,'-' as admno,b.sourcename as stud_names,'-' as cls,b.pytdate,b.cheno,b.pytfrm,0 as arrears,0 as refunds,b.Amt as fee, b.amt as ttl,1 as comm,year(pytdate) as yr FROM acc_burs b INNER
    JOIN (SELECT f.sno,f.recno,substring(i.admno,(locate('-',i.admno)+1)) as bursno FROM acc_incorecno0 f Inner Join acc_incofee i USING (sno) WHERE i.commt=0 and f.markdel=0 and i.admno LIKE 'Burs%')f USING (bursno)
    WHERE (b.pytdate BETWEEN '$sdate' AND '$edate') and b.markdel=0 and b.status=0 Order By recno Asc";
    elseif ($opt==2) $fee="SELECT r.sno,f.recno,a.idno as admno,a.alt_names as stud_names,a.telno as cls,r.pytdate,r.cheno,r.pytfrm,f.arrears,".($acc==1?"f.refunds":"0 as ref").",(f.amt-".($acc==1?"f.refunds":0).
		"+f.bc)	as fee,(f.amt+f.bc) As Ttl,2 as comm,year(r.pytdate) as yr FROM acc_incofee r Inner Join ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON (r.sno=f.sno) INNER JOIN acc_alterincome a ON a.code=r.admno
    WHERE r.commt=2 and	r.markdel=0 AND (r.pytdate Between '$sdate' AND '$edate') UNION SELECT f.sno,i.recieptno as recno,i.interb_no as admno,concat('FUNDS TRANSFERRED FROM ',va.abbr,' - A/C NO. ',a.accno)
    as stud_names,'--' as cls,i.interb_date as pytdate,i.modeno as cheno,i.mode as pytfrm,0 as arrears,0 as refunds,i.amt as fee,i.amt as ttl,3 as comm,year(i.interb_date) as yr FROM acc_interacborrow i Inner Join ".
    ($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON (i.recieptno=f.recno) INNER JOIN acc_incofee ic ON (f.sno=ic.sno) INNER JOIN acc_accounts a On (i.sourceac=a.sno) Inner Join acc_voteacs va ON (a.accacc=va.acno)
    WHERE ic.commt=1 and (i.interb_date BETWEEN '$sdate' and '$edate') and i.markdel=0 and i.sourceac=$acc UNION SELECT ic.sno,f.recno,ic.admno,concat(s.sal_month,'-',s.sal_year,' SALARY RECOVERIES') as stud_names,'--'
    as cls,ic.pytdate,ic.cheno,ic.pytfrm,f.arrears,0 as refunds,f.amt as fee,f.amt as ttl,4 as comm,year(ic.pytdate) as yr FROM acc_salaries s Inner Join acc_incofee ic ON (s.salno=ic.interb_no and ic.commt=3) INNER
    JOIN ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON (ic.sno=f.sno) WHERE s.acc=$acc and (ic.pytdate BETWEEN '$sdate' and '$edate') and ic.markdel=0 UNION SELECT ic.sno,f.recno,s.idno as admno,concat(s.surname,
    ' ',s.onames) as stud_names,s.telno as cls,ic.pytdate,ic.cheno,ic.pytfrm,f.arrears,0 as refunds,f.amt as fee,f.amt as ttl,5 as comm,year(ic.pytdate) as yr FROM stf s Inner Join acc_tenants t USING (idno) Inner Join
    acc_incofee ic ON (t.tno=ic.admno and ic.commt=2) INNER JOIN ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON (ic.sno=f.sno) WHERE f.acc=$acc and (ic.pytdate BETWEEN '$sdate' and '$edate') and ic.markdel=0
    Order By recno Asc";
    else $fee="SELECT r.sno,f.recno,s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',sf.stream) As cls,r.pytdate,r.cheno,r.pytfrm,f.arrears,".($acc==1?"f.refunds":"0 as refunds").",
		(f.amt-".($acc==1?"f.refunds":"0")."-f.arrears-f.transfer+f.bc) as fee, (f.amt-f.transfer+f.bc) As Ttl,0 as comm,s.curr_year as yr FROM stud s Inner Join class sf USING (admno,curr_year) INNER JOIN classnames cn
    USING (clsno) INNER JOIN (acc_incofee r Inner Join ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno)) On s.admno=r.admno WHERE r.commt=0 and r.markdel=0 AND (r.pytdate BETWEEN '$sdate' AND '$edate')
    UNION SELECT f.sno,f.recno,'-' as admno,b.sourcename as stud_names,'-' as cls,b.pytdate,b.cheno,b.pytfrm,0 as arrears,0 as refunds,b.Amt as fee, b.amt as ttl,1 as comm,year(pytdate) as yr FROM acc_burs b INNER
    JOIN (SELECT f.sno,f.recno,substring(i.admno,(locate('-',i.admno)+1)) as bursno FROM acc_incorecno0 f Inner Join acc_incofee i USING (sno) WHERE i.commt=0 and f.markdel=0 and i.admno LIKE 'Burs%')f USING (bursno)
    WHERE (b.pytdate BETWEEN '$sdate' AND '$edate') and b.markdel=0 and b.status=0 UNION SELECT r.sno,f.recno,a.idno as admno,a.alt_names as stud_names,a.telno as cls,r.pytdate,r.cheno,r.pytfrm,f.arrears,".($acc==1?
    "f.refunds":"0 as ref").",(f.amt-".($acc==1?"f.refunds":0)."+f.bc)	as fee,(f.amt+f.bc) As Ttl,2 as comm,year(r.pytdate) as yr FROM acc_incofee r Inner Join ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON
    (r.sno=f.sno) INNER JOIN acc_alterincome a ON a.code=r.admno WHERE r.commt=2 and	r.markdel=0 AND (r.pytdate Between '$sdate' AND '$edate') UNION SELECT f.sno,i.recieptno as recno,i.interb_no as admno,concat('FUNDS
    TRANSFERRED FROM ',va.abbr,' - A/C NO. ',a.accno) as stud_names,'--' as cls,i.interb_date as pytdate,i.modeno as cheno,i.mode as pytfrm,0 as arrears,0 as refunds,i.amt as fee,i.amt as ttl,3 as comm,year(i.interb_date)
    as yr FROM acc_interacborrow i Inner Join ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON (i.recieptno=f.recno) INNER JOIN acc_incofee ic ON (f.sno=ic.sno) INNER JOIN acc_accounts a On (i.sourceac=a.sno) Inner
    Join acc_voteacs va ON (a.accacc=va.acno) WHERE ic.commt=1 and (i.interb_date BETWEEN '$sdate' and '$edate') and i.markdel=0 and i.sourceac=$acc UNION SELECT ic.sno,f.recno,ic.admno,concat(s.sal_month,'-',s.sal_year,
    ' SALARY RECOVERIES') as stud_names,'--' as cls,ic.pytdate,ic.cheno,ic.pytfrm,f.arrears,0 as refunds,f.amt as fee,f.amt as ttl,4 as comm,year(ic.pytdate) as yr FROM acc_salaries s Inner Join acc_incofee ic ON
    (s.salno=ic.interb_no and ic.commt=3) INNER JOIN ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON (ic.sno=f.sno) WHERE s.acc=$acc and (ic.pytdate BETWEEN '$sdate' and '$edate') and ic.markdel=0 UNION SELECT ic.sno,
    f.recno,s.idno as admno,concat(s.surname,' ',s.onames) as stud_names,s.telno as cls,ic.pytdate,ic.cheno,ic.pytfrm,f.arrears,0 as refunds,f.amt as fee,f.amt as ttl,5 as comm,year(ic.pytdate) as yr FROM stf s Inner Join
    acc_tenants t USING (idno) Inner Join acc_incofee ic ON (t.tno=ic.admno and ic.commt=2) INNER JOIN ".($acc==1?"acc_incorecno0":"acc_incorecno1")." f ON (ic.sno=f.sno) WHERE f.acc=$acc and (ic.pytdate BETWEEN '$sdate'
    and '$edate') and ic.markdel=0 Order By recno Asc";
    $res=mysqli_query($conn,$fee) or die(mysqli_error($conn).". Click <a href=\"feecollection.php\">HERE</a> to go back.");
    print "<table id=\"tabReceipt\" class=\"table table-hover table-striped table-sm table-bordered table-responsive\" style=\"font-size:0.7rem;\"><thead class=\"thead-dark\"><tr><th colspan=2>RECEIPT DETAILS</th>
    <th colspan=\"3\">RECEIVED FROM</th><th colspan=\"2\">TRANSACTION</th><th colspan=\"4\">DISTRIBUTION OF AMOUNT RECEIVED</th><th rowspan=\"2\">FEE<br>RECEIPT</th></tr><tr><th style=\"display:none\"></th>
    <th>Receipt</th><th>Received On</th><th>Adm./ID No.</th><th>Names </th><th>Grade/ Tel No.</th><th>Mode</th><th>Mode No.</th><th>Arrears</th><th>Refunds</th><th>Fees</th><th>Total</th></tr></thead><tbody>";
    $i=0; $ttl=[0,0,0,0]; $recs=mysqli_num_rows($res);
    if ($recs>0) while (list($sno,$recno,$admno,$names,$form,$date,$chno,$pytfrm,$arr,$ref,$fee,$tt,$com,$yr)=mysqli_fetch_row($res)){
      $days=(strtotime(date('Y-m-d'))-strtotime($date))/86400;
      print "<tr><td style=\"display:none\">$recno</td><td>".(($fedit==1 && $com==0)?"<a href=\"votedistredit.php?rec=1-$recno-$admno-1\">$recno</a>":"$recno")."</td><td align=\"right\">".date('D d M, Y',strtotime($date)).
      "</td><td>$admno</td><td>$names</td><td>$form</td><td>$pytfrm</td><td>$chno</td><td align=\"right\">".number_format($arr,2)."</td><td align=\"right\">".number_format($ref,2)."</td><td align=\"right\">".
      number_format($fee,2)."</td><td align=\"right\"><b>".number_format($tt,2)."</b></td><td align=\"center\" class=\"noprint\">".(($days<2 && $com==0)?"<a style=\"background:inherit;\" onclick=\"return canEdit($fedit)\"
      href=\"".($finyr===$yr?"feerecedit.php?rec=$acc-$sno-$admno":"alumniarrclearance.php?admno=1-$admno-$sno-0")."\"><img src=\"../gen_img/edit.ico\" width=18 height=16 title=\"Edit\"></a>&nbsp;&nbsp;&nbsp;":"").
      ($com==0?"<a style=\"background:inherit;\" href=\"rpts/receiptcopy.php?recno=$sno-1-1-0\"><img src=\"/gen_img/print.ico\" width=18 height=16 title=\"Print\"></a>":"")."</td></tr>";
      $ttl[0]+=$arr; 	$ttl[1]+=$ref;  $ttl[2]+=$fee;   $ttl[3]+=$tt;   	$i=$i+1;
    }else print "<tr><td colspan=\"15\"><br>No fees receipts were made between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate))."</td></tr>";
    print "</tbody><tfoot class=\"thead-light\"><tr bgcolor=\"#eaa\"><th colspan=4 align=\"left\"><span id=\"spNoF\">".mysqli_num_rows($res)." Fees Payment Record(s)</span></th><th colspan=\"3\"
    align=\"right\">Total Kshs.</th>"; $i=0;
    foreach ($ttl as $amt){print "<th align=\"right\" id=\"thTtl_$i\">".number_format($amt,2)."</th>"; $i++;}
    print "<th></th></tr></tfoot></table>";
    mysqli_free_result($res);
    print "</div></div></div>".($recs>0?"<br><center><a href=\"pdf/feevoteanalysis.php?rec=0.$sdate.$edate.$acc.$opt\"\" target=\"_BLANK\"><img src=\"../gen_img/print.ico\" height=25 width=25>Printable Report</a></center>":"");
  }
?><script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/feecollection.js"></script>
<?php mysqli_close($conn); footer();?>
