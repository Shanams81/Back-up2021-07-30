<?php
	if (isset($_POST['cmdAdd'])) header("location:creditors.php?action=0-%-%");
	session_start();
	if (!isset($_SESSION['username']) || ($_SESSION['username'] == ''))	header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	$dat=isset($_REQUEST['dat'])?$_REQUEST['dat']:'0-0';	$dat=preg_split('/\-/',$dat); //[0] -type, [1]- yr, [2]-name, [3]-clr, and [4] - account
?>
<!DOCTYPE html>
<html lang="en">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">	
	<title>Creditors</title>
	<link rel="shortcut icon" href="../gen_img/phone.ico"/>
	<link rel="stylesheet" type="text/css" href="tpl/hightlight.css">
	<script type="text/javascript" src="tpl/printthis.js"></script>
</head>
<body background="../gen_img/bg3.gif" style="background-size:100%;">
<?php
	print "<center><div id=\"print_content\"><table style=\"border:0px;\">";
	if (strcasecmp($dat[0],"1")==0) $sql="SELECT c.cred_no,c.lpono,concat(if(c.acno LIKE '1','Main',if(c.acno LIKE '2','Tuition',if(c.acno LIKE '3','Operations','Miscellaneous'))),' (',
	v.abbr,')') as ac,name,c.telno,c.idno,c.amt,c.rmks,c.regdate,c.yr FROM acc_creditors c Inner Join acc_votes v On (c.voteno=v.sno) WHERE acno LIKE '$dat[4]' and yr='$dat[1]' and name 
	LIKE '$dat[2]' and ".($dat[3]==1?"amt>0":"amt=0")." ORDER BY yr,cred_no ASC";
	elseif (strcasecmp($dat[0],"0")==0) $sql="SELECT c.cred_no,c.lpono,concat(if(c.acno LIKE '1','Main',if(c.acno LIKE '2','Tuition',if(c.acno LIKE '3','Operations','Miscellaneous'))),' (',
	v.abbr,')') as ac,name,c.telno,c.idno,c.amt,c.rmks,c.regdate,c.yr FROM acc_creditors c Inner Join acc_votes v On (c.voteno=v.sno)  WHERE acno LIKE '$dat[4]' and yr<'$dat[1]' and name 
	LIKE '$dat[2]' and ".($dat[3]==1?"amt>0":"amt=0")." ORDER BY yr,cred_no ASC";
	else $sql="SELECT c.cred_no,c.lpono,concat(if(c.acno LIKE '1','Main',if(c.acno LIKE '2','Tuition',if(c.acno LIKE '3','Operations','Miscellaneous'))),' (',v.abbr,')') as ac,name,c.telno,
	c.idno,c.amt,c.rmks,c.regdate,c.yr FROM acc_creditors c Inner Join acc_votes v On (c.voteno=v.sno)  WHERE acno LIKE '$dat[4]' and name LIKE '$dat[2]' and ".($dat[3]==1?"amt>0":"amt=0").
	" ORDER BY yr,cred_no ASC";
	$rs=mysqli_query($conn,$sql);		$no=mysqli_num_rows($rs); 		$ttl=0;
	$h=($dat[0]=='%' && $dat[4]=='%')?'list of all creditors':(($dat[0]!='%' && $dat[4]=='%')?'All '.($dat[0]=='1'?$dat[1].' Creditors':'Sundry Creditors'):(($dat[0]=='%' && $dat[4]!='%')?
	'All '.$dat[4].' Creditor':(($dat[0]=='1'?$dat[1].' Creditors':'Sundry Creditors').' In '.$dat[4].' Account')));
	$h.=' with '.($clr==1?'Credit':'No').' Balance';
	$rsDet=mysqli_query($conn,"SELECT scnm,scadd FROM ss"); if (mysqli_num_rows($rsDet)>0) list($scnm,$scadd)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	print "<tr><td rowspan=\"3\" width=\"5%\"><img src=\"../gen_img/logo.jpg\" width=\"50\" height=\"50\" vspace=\"1\" hspace=\"1\"></td><td class=\"hide\" style=\"font-weight:bold;
	font-size:12pt;letter-spacing:2px;word-spacing:3px;font-weight:bold;\" width=\"95\">$scnm</td></tr><tr><td style=\"font-weight:bold;font-size:10pt;\" colspan=\"2\">$scadd</td></tr>
	<tr><td style=\"font-weight:bold;font-size:10pt;\">".strtoupper($h)."&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
	Printed On ".date("D d-M-Y")."</td></tr><tr><td colspan=\"2\"><hr></td></tr><tr><td colspan=\"2\">";
	print "<table border=\"1\" cellpadding=\"1\" cellspacing=\"0\"><tr style=\"background-color:#eee;letter-spacing:2px;word-spacing:4px;\"><th colspan=\"4\">DETAILS OF 
	CREDIT</th><th colspan=\"4\">DETAILS OF CREDITORS</th><th rowspan=\"2\">Credit Remarks</th><th rowspan=\"2\">Current<br>Balance</th></tr><tr><th>S/No.</th><th>L.P.O<br>No.</th><th>
	Account &amp;<br>Votehead</th><th>Registered On</th><th>ID No.</th><th>Name of Creditor</th><th>Tel. No.</th><th>Year</th></tr>";
	if($no>0){
	 	$a=0;
		while (list($cn,$lpo,$acct,$names,$telno,$idno,$amt,$rmks,$date,$typ)=mysqli_fetch_row($rs)){
			if ($a%2==0) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>";
			print "<td>$cn</td><td>$lpo</td><td>$acct</td><td align=\"right\">".date("D d M,Y",strtotime($date))."</td><td>$idno</td><td>$names</td><td>$telno</td><td>$typ</td><td>
			$rmks</td><td align=\"right\">".number_format($amt,2)."</td></tr>";	$ttl+=$amt; $a++;
		}
	}else print "<tr><td colspan=\"10\">There are No creditors register on specified criteria</td></tr>";
	print "<tr><td colspan=\"4\"><b>$no Creditor(s) Displayed</b></td><td colspan=\"5\" align=\"right\"><b>Total Creditor's Amount (Kshs.)</b></td><td align=\"right\"><b>".
	number_format($ttl,2)."</b></td></tr></table></td></tr><table></div><br><br><div align=\"left\" id=\"btns_only\">Click <a href=\"creditorsall.php\"><b>H E R E</b></a> to go back.&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Click <a href=\"javascript:Clickheretoprint()\"><img src=\"../gen_img/print.ico\" 
	height=\"40\" width=\"40\"></a> to print</div>";
	mysqli_close($conn);
?>
</table>
</body>
</html>