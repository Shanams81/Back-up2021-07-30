<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else {
		include_once('../conn/pri_sch_connect.inc');
		$rsPriv=mysqli_query($conn,"SELECT feeview FROM Acc_Priv WHERE uname LIKE '".$_SESSION['username']."'");
		if (mysqli_num_rows($rsPriv)==1) list($feevi)=mysqli_fetch_row($rsPriv);	mysqli_free_result($rsPriv);
	}
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" /><link href="tpl/headers.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Student Manager</title>
</head>
<body background="img/bg3.gif"><div class="head"><form method="post" action="feenotice.php"><a href="home.php"><Img src="img/ani_back.gif" Align="left" Height="25" width="60" hspace="5">
</a>Fee Notice of Class <select name="CboCls" size="1" id="Class"><option selected value="%">All</option>
<?php 
	$str=@mysqli_query($conn,"SELECT clsno,clsname FROM classnames"); 
	if (mysqli_num_rows($str)>0) while (list($clsno,$clsname)=mysqli_fetch_row($str)) print "<option value=\"$clsno\">$clsname</option>";	mysqli_free_result($str);
	print "</select> - <select name=\"CboStream\" size=\"1\" id=\"stream\"><option selected value=\"%\">All</option>";
	$rsStr=mysqli_query($conn,"SELECT strm FROM grps WHERE strm is not null or strm not like ''") or die(mysqli_error($conn).' Error in database connection'); 
	if (mysqli_num_rows($rsStr)>0) while (list($strm)=mysqli_fetch_row($rsStr)) print "<option>$strm</option>";
	mysqli_free_result($rsStr);
?>
</select><label for="adno">&nbsp;Or Pupil of Adm. No.</label>&nbsp;<input type="text" maxlength="5" size="10" name="TxtAdmNo" id="adno" value="%">&nbsp;&nbsp; <button type="submit" 
name="Stud" <?php print($feevi==0)?"disabled":"";?>>Show Fee Notice</button> 
</form>
</div><h3 style="text-transform:uppercase;word-spacing:5px;letter-spacing:3px;">Viewing 
&amp; Printing Fee Notice</h3>
<hr>
<p class="g">Fee notice, is a document generated to inform a guardian about school balance of a given pupil. To view fee notice either </p><ol type="a"><li>Select class and stream level 
(Select All in either class or stream level to view fee notices of all pupils) and <li>Click <b>Show Fee Notice</b> command button<br>or<br><li>To view and print individual pupil fee 
notice, enter admission number of the pupil and  <li>Click <b>Show Fee Notice</b> button.</ol>
</body>
</html>
<?php
	mysqli_close($conn);
?>