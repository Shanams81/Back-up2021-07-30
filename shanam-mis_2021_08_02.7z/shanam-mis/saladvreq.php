<?php
    include_once('shanam.php');
    $type=isset($_POST['CboType'])?sanitize($_POST['CboType']):0;           $from=isset($_POST['TxtFrom'])?sanitize($_POST['TxtFrom']):date('d-m-Y',strtotime('-30 days'));
    $to=isset($_POST['TxtTo'])?sanitize($_POST['TxtTo']):date('d-m-Y');     $from=preg_split("/\-/",$from);	$to=preg_split("/\-/",$to);	$from="$from[2]-$from[1]-$from[0]";     $to="$to[2]-$to[1]-$to[0]";
    $action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0";	$action=preg_split("/\-/",$action);
    $rsSP=mysqli_query($conn,"SELECT advview,Advreqapproval FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
    $advreqviu=0; $advreqapp=0;	list($advreqviu,$advreqapp)=mysqli_fetch_row($rsSP);	mysqli_free_result($rsSP);
    if ($advreqviu==0) header("location:vague.php");
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css" /><link href="../date/tcal.css" rel="stylesheet" type="text/css" />',$action[0],$action[1],2);
?><div class="head">
<form name="FrmAdv" method="post" action="saladvreq.php"><a href="advance_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;  View <SELECT
name="CboType" size="1"><option value="1">APPROVED</option><option value="0" selected>UN APPROVED</option><option value="2">REJECTED</option></Select> Advances Requests Between <input
name="TxtFrom" class="tcal" size="10" readonly value="<?php echo date("d-m-Y");?>"> And <input name="TxtTo" id="TxtTo" class="tcal" size="10" readonly value="<?php echo date("d-m-Y"); ?>">
&nbsp;&nbsp;<button type="submit" name="CmdShow">Show Requests</button></form></div>
<div class="container" style="background-color:#f6f6f6;border-radius:20px;max-width:950px;padding:5px;margin:5px auto 5px auto;">
<?php
    if (isset($_POST['CmdShow'])){
        if ($type==1) $h="Approved salary advance request made between ";
        elseif ($type==0) $h="Un approved Salary advance requests made between ";
        else $h="Rejected Salary advance requests made between ";
    } else{
        $h= "Approved salary advance request made between";
    } $h.=" ".date("D d, M Y",strtotime($from))." and ".date("D d, M Y",strtotime($to));
    print "<h6 style=\"text-align:center;text-decoration:underline overline double #000;padding:2px;\">".strtoupper($h)."</h6>";
    if ($type<2) $sql="SELECT a.reqno,sd.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.designation,((sd.bsal+sd.houseallow+sd.medicalallow+sd.travellallow)-
    ((sd.paye-sd.mpr)+sd.nssffee+sd.nhiffee+sd.unionfee+sd.otherlevies)-if(isnull(b.ded),0,b.ded)) as net,a.reqdate,a.amt,concat(ded_period,' Month(s)') as per,a.amtperded,
    a.rmks FROM stf s Inner Join acc_saldef sd USING (idno) Inner JOIN acc_advreq a ON (sd.payrollno=a.payrollno) LEFT Join (SELECT payrollno,sum(amtperduration) as ded FROM
    (SELECT a.advno,a.payrollno,a.amtperduration,(a.amt-if(isnull(sum(c.amt_clr)),0,sum(c.amt_clr))) as clr,if(isnull(c.markdel),0,c.markdel) as cmkd  FROM `acc_adv` a Inner Join
    acc_advclr c ON (a.advno=c.advano) GROUP BY a.advno,a.payrollno,a.amt,a.amtperduration,a.markdel, if(isnull(c.markdel),0,c.markdel) HAVING a.markdel=0 and cmkd=0 and clr>0)a
    GROUP BY payrollno)b On (sd.payrollno=b.payrollno) WHERE a.markdel=0 and a.adv_status=$type and (a.reqdate BETWEEN '$from[2]-$from[1]-$from[0]' AND '$to[2]-$to[1]-$to[0]')";
    else $sql="SELECT a.reqno,sd.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.designation,a.reqdate,a.amt,concat(ded_period,' Month(s)') as per,a.amtperded,
    a.rmks,j.rej_date,j.rmks FROM stf s Inner Join acc_saldef sd USING (idno) Inner JOIN acc_advreq a ON (sd.payrollno=a.payrollno) Inner Join Acc_advrej j On
    (a.reqno=j.advreqno) WHERE (a.markdel=0 and j.markdel=0 and (j.rej_date BETWEEN '$from[2]-$from[1]-$from[0]' AND '$to[2]-$to[1]-$to[0]'))";
    $rsSA=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"advance_manager.php\">HERE</a> to go back");
    if ($type<2){
        print "<table class=\"table table-striped table-hover table-bordered table-sm\" style=\"font-size:0.7rem\"><thead class=\"thead-dark\"<tr align=\"middle\"><th colspan=\"6\">Employee's Details</th><th
        colspan=\"5\">Salary Advance Request Details</th><th colspan=\"3\">Administrative Actions</th></tr><tr><th>Request<br>No.</th><th>ID. No.</th><th>Payroll No.</th><th>Names</th>
        <th>Designation</th><th>Current<br>Net Salary</th><th>Made On</th><th>Amount</th><th>Recovered In</th><th>Amount Per<br>Recovery</th><th>Reason for the Advance Request</th><th>
        Edit</th><th>Approve</th><th>Decline</th></tr></thead></tbody>";
        $i=0; $norows=mysqli_num_rows($rsSA);
        if ($norows>0):
            while ($res=mysqli_fetch_array($rsSA,MYSQLI_NUM)):
                 print "<tr>";    $ai=0;
                foreach($res as $rse) {
                    if (($ai<5) || ($ai==8) || ($ai==10)):
                        if ($ai==0) $ps=$rse;
                        print "<td>$rse</td>";
                    elseif ($ai==6):
                        $rse=date("D, d-F-Y",strtotime($rse));
                        print "<td>$rse</td>";
                    else:
                        print "<td align=\"right\">".number_format($rse,2)."</td>";
                    endif;
                    $ai++;
                }
                if ($type==0) print "<td align=\"center\"><a onclick=\"return canedit($advreqapp)\" href=\"AdvReqeditor.php?advno=$ps\">Edit</a></td><td align=\"center\"><a  onclick=\"return canadd($advreqapp)\"
                href=\"AdvReqAction.php?adv=$ps-1\">Approve</a></td><td align=\"center\"><a onclick=\"return canadd($advreqapp)\" href=\"AdvReqAction.php?adv=$ps-2\">Decline</a></td>";
                else print "<td align=\"center\">-</td></td><td align=\"center\">-</td><td align=\"center\">-</td>";
                print "</tr>"; $i++;
            endwhile;
        else:
                print "<tr><td colspan=\"14\">Sorry no salary advance requests exits</td></tr>";
        endif;
        print "</tbody><tfoot><tr bgcolor=\"#eeaaaa\"><td colspan=\"14\" align=\"left\" class=\"b\">$norows Salary Advance Resquester(s)</tr></tfoot></table>";
    }else{
        print "<table class=\"table table-hover table-striped table-sm table-bordered\" style=\"font-size:0.7rem\"><thead class=\"thead-dark\"><tr align=\"middle\"><th colspan=\"5\">Employee's Details</th>
        <th colspan=\"5\">Salary Advance Request Details</th><th colspan=\"2\">Salary Advance Request Rejection</th><th>Administrative Action</th></tr><tr><th>Request<br>No.
        </th><th>ID. No.</th><th>Payroll No.</th><th>Names</th><th>Designation</th><th>Made On</th><th>Amount</th><th>Recovered In</th><th>@ KShs.</th><th>Reason for the Advance
        Request</th><th>Rejected On</th><th>Reason Given</th><th>Restore</th></tr></thead><tbody>";
        $i=0; $norows=mysqli_num_rows($rsSA);
        if ($norows>0):
            while ($res=mysqli_fetch_array($rsSA,MYSQLI_NUM)):
                print "<tr>";
                $ai=0;
                foreach($res as $rse) {
                    if (($ai<5) || ($ai==7) || ($ai==9) || ($ai==11)):
                        if ($ai==0) $ps=$rse;
                        print "<td>$rse</td>";
                    elseif (($ai==5) || ($ai==10)):
                        $rse=date("D, d-F-Y",strtotime($rse));
                        print "<td>$rse</td>";
                    else:
                        print "<td align=\"right\">".number_format($rse,2)."</td>";
                    endif;
                    $ai++;
                }
                print "<td align=\"center\"><a onclick=\"return canedit($advadd)\" href=\"AdvReqAction.php?adv=$ps-3\">Restore</a></td></tr>";
                $i++;
            endwhile;
        else:
                print "<tr><td colspan=\"15\">Sorry, there are no rejected salary advance requests in the system</td></tr>";
        endif;
        print "</body><tfoot><tr><td colspan=\"15\" align=\"left\" class=\"b\">$norows Rejected Salary Advance Resquest(s)</tr></tfoot></table>";
    }
    mysqli_free_result($rsSA);
    print "</div><h6 style=\"text-align:center;color:#fff;\">Report Generated on ".date("l F d, Y")."</h6><script type=\"text/javascript\" src=\"../date/tcal.js\"></script><script type=\"text/javascript\"
    src=\"tpl/priv.js\"></script>";
    mysqli_close($conn); footer();
?>
