<?php
	session_start();
	session_destroy();
?>
<html>
<head><title>Guest</title></head>
<body background="img/bg1.jpg" link="#aaaaa0" alink="#aa0000" vlink="#aaaaaa">
	<p style="color:#00FF33;text-align:right;background-color:#8888AA;font-style:normal;font-size:14px;">Welcome <b>Guest</b></p>
	<?php
		print "<hr><b><center><font size=\"+2\">School Management Information System</font></center></b><br><hr><br><br>";
		print "<p style=\"margin-left:40px;\">Click <a href=\"\index.php\"><b>here</b></a> to provide login credentials (Username and 
		Password) to use the system.<br><br>";
		print "If you do not have Username and Password, Consult your administrator to provide you with them (It is a mandatory 
		requirement to use the system).<br><br>";
		print "Change your password within 30 days. Otherwise your password will expire and you will be locked out of the system use.";
		print "<br><br>Server Time ".date('l j-F-Y h:i:s a');
	?></p>
</body>
</html>