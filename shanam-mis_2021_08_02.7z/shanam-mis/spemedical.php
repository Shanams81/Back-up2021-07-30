<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $act=preg_split('/\-/',$act);		$un=$_SESSION['username'];
    mysqli_multi_query($conn,"SELECT feeview,feeadd,feeedit,feedel FROM acc_priv Where Uname LIKE '$un'; SELECT finyr FROM ss;  SELECT acc,voteno FROM acc_votesassigned WHERE name LIKE
    'spemed'");    $vie=$add=$edi=$del=$vacc=$vvote=0; $finyr=date("Y"); $i=0;
    do{
        if($rs=mysqli_store_result($conn)){
          if($i==0) list($vie,$add,$edi,$del)=mysqli_fetch_row($rs); elseif($i==1) list($finyr)=mysqli_fetch_row($rs); else list($vacc,$vvote)=mysqli_fetch_row($rs);mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
    if($vie==0){ header("location:vague.php"); exit(0);}
    if (isset($_POST['btnSaveBill'])){
      $no=isset($_POST['txtNo1'])?sanitize($_POST['txtNo1']):"0-0-0-0"; 						$no=preg_split('/\-/',$no); //[0] 0 new 1 edit,[1] bill No, [2] admno [3] original amt
      $accvote=isset($_POST['txtAccVote1'])?sanitize($_POST['txtAccVote1']):"0-0"; 	$accvote=preg_split('/\-/',$accvote); //[0] 0 Account, [1] Votehead, [2] Token
      $inv=isset($_POST['txtInvoice1'])?sanitize($_POST['txtInvoice1']):0; 					$hosp=isset($_POST['cboHosp1'])?sanitize($_POST['cboHosp1']):0;
      $amt=isset($_POST['txtAmt1'])?sanitize($_POST['txtAmt1']):0;		 							$amt=preg_replace('/[^0-9^\.]/','',$amt);	$sql=''; $act[1]=0; $act[0]=1;
      $date=isset($_POST['txtDate1'])?sanitize($_POST['txtDate1']):date('Y-m-d');		$date=preg_split('/\-/',$date);	 		$de=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
      $rmks=isset($_POST['txtRmks1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtRmks1']))):'';			$date="$date[2]-$date[1]-$date[0]"; $act[1]=0;
      if($inv>0 && $hosp>0 && $amt>0 && $amt>0 && strlen($rmks)>15){
        if($accvote[2]===$_SESSION['tkn_add']){
          unset($_SESSION['tkn_add']);
          if ($no[0]==0){ //new record
            $sql.="INSERT INTO acc_creditorsdet(detno,admno,cred_no,inv_no,inv_date,rmks,acc,voteno,amt,estimatedamt,addedby) VALUES (0,$no[2],$hosp,'$inv','$date',".
            var_export($rmks,true).",$accvote[0],$accvote[1],$amt,$amt,'$de'); UPDATE class SET spemed=spemed+$amt WHERE admno LIKE '$no[2]' and curr_year IN (SELECT finyr FROM ss);";
          }else{ //editing
            $sql.="UPDATE acc_creditorsdet SET inv_no='$inv',cred_no='$hosp',inv_date='$date',acc=$accvote[0],voteno=$accvote[1],amt=amt+$bal,estimatedamt=$amt,rmks=".var_export($rmks,true)."
            WHERE detno LIKE '$no[1]'; UPDATE class SET spemed=spemed+$bal WHERE admno LIKE '$no[2]' and curr_year IN (SELECT finyr FROM ss);";			$amt-=$no[3];
          }if(strlen($sql)>0){
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Medical bill was not saved.<br>Click <a href=\"spemedical.php\">HERE</a> to try again.");
            $act[1]=mysqli_affected_rows($conn); while(mysqli_next_result($conn)){;}
          }
        }
      }else  print "<font size=\"+2\" color=\"#f00\">Ensure medical bill details are validly entered before saving.</font><br>Click <a href=\"spemedical.php\">HERE</a> to try again.";
    }elseif(isset($_POST['btnDelete'])){
        $no=isset($_POST['txtNo1'])?sanitize($_POST['txtNo1']):'0-0-0-0';		$no=preg_split('/\-/',$no); //[0] 0 new 1 edit,[1] bill No, [2] admno [3] original amt
        if ($no[0]>0){
            mysqli_multi_query($conn,"UPDATE acc_hospbills SET markdel=1 WHERE billno LIKE '$no[1]'; UPDATE class SET spemed=spemed-$no[3] WHERE admno LIKE '$no[2]' and curr_year IN
            (SELECT finyr FROM ss);"); $act[1]=mysqli_affected_rows($conn); while(mysqli_next_result($conn)){;}
        }else $act[1]=0; $act[0]=2;
    } $_SESSION['tkn_add']=uniqid();
    headings('<link rel="stylesheet" href="/date/tcal.css" type="text/css"/><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet"
    href="tpl/css/inputsettings.css" type="text/css"/>',$act[0],$act[1],2);
?>
<div class="container divmain">
<h3>MEDICAL BILLS MANAGER</h3>
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#divBills" role="tab" aria-controls="fee" aria-selected="true">MEDICAL BILLS</a></li>
    <li class="nav-item"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#divFacilities" role="tab" aria-controls="votes" aria-selected="false">MEDICAL FACILITIES</a></li>
    <li class="nav-item"><a class="nav-link" id="rpt-tab" data-toggle="tab" href="#divRpt" role="tab" aria-controls="rpt" aria-selected="false">MEDICAL BILL REPORTS</a></li>
</ul>
<div class="tab-content" id="myTabContent">
    <div class="tab-pane fade show active" id="divBills" role="tabpanel" aria-labelledby="home-tab" style="border:0.5px dotted blue;border-radius:10px;padding:5px 0;">
        <div class="form-row"><div class="col-md-12"><form method="post" name="frmNewBill" action="spemedical.php" onsumit="return newBill()">HOSPITAL BILL FOR ADM. NO. <input
            name="txtFindAdm" id="txtFindAdm" onkeyup="findStud(this)" value="" type="text" size=20 maxlength=7 placeholder="Enter Adm No. Here"> <button type="button" name="btnNewBill"
            id="btnNewBill" class="btn btn-info btn-sm" disabled onclick="getBilling(0,0,0)">New Medical Bill</button></div>
        </div><div class="form-row">
            <div class="col-md-12 divheadings" id="spStud">HOSPITAL BILLS BY ALL STUDENTS <input name="txtAdmNo" id="txtAdmNo" type="hidden" value=""></span></form></div>
        </div><div class="form-row"><div class="col-md-12" id="spBills" style="overflow-y:scroll;">
            <table id="myTable" class="table table-striped table-hover table-bordered"><thead class="thead-dark"><tr><th>INVOICE NO.</th><th>INVOICED ON</th><th>NAME OF HOSPITAL</th><th>ADM. NO.</th><th>
            NAME OF STUDENT</th><th>GRADE/FORM</th><th>NARRATION ON THE INVOICE</th><th>AMOUNT</th><th>ADMIN ACTION</th></tr></thead><tbody>
            <?php
                $rsBills=mysqli_query($conn,"SELECT b.detno,b.cred_no,cr.name,b.admno,concat(s.surname,' ',s.onames) as nam, concat(cn.clsname,' ',c.stream) as cls,b.inv_no,b.inv_date,
                b.rmks,b.estimatedamt FROM stud s Inner Join class c USING (admno, curr_year) Inner Join classnames cn USING (clsno) Inner Join acc_creditorsdet b USING (admno) Inner Join
                acc_creditors cr On (b.cred_no=cr.cred_no) WHERE b.markdel=0 and cr.categ=1 Order By b.detno ASC");
                $i=mysqli_num_rows($rsBills); $a=1; $ttl=0; $listBills='';
                while (list($billno,$hospno,$hospname,$adm,$nam,$cls,$invno,$invdate,$rmks,$amt)=mysqli_fetch_row($rsBills)){
                    $listBills.=($a==1?"":",")."new HospBills($billno,$adm,$hospno,'$invno','".date('d-m-Y',strtotime($invdate))."','$rmks',$amt)";
                    $diff=(strtotime(date('Y-m-d'))-strtotime($invdate))/86400;
                    print "<tr><td>$invno</td><td align=\"right\">".date('D d M, Y',strtotime($invdate))."</td><td>$hospname</td><td>$adm</td><td>$nam</td><td>$cls</td><td>$rmks</td><td
                    align=\"right\">".number_format($amt,2)."</td><td align=\"center\">".($diff<7?"<a href=\"#\" onclick=\"getBilling(1,$billno,$del)\">Edit</a>":"-")."</td></tr>";
                    $a++;	$ttl+=$amt;
                } mysqli_free_result($rsBills);
            ?>
            </tbody><tfoot class="thead-light"><tr><th colspan="4" id="spNoB" style="letter-spacing:3px;word-spacing:5px;font-weight:bold;"><?php echo $i;?> Medical Bill(s)</th><th style="text-align:right" colspan="3">
            Total Bills (Kshs.)</th><th id="spSubTtl" style="letter-spacing:1px;text-align:right;"><?php echo number_format($ttl,2); ?></th><th></th></tr></tfoot></table></div>
        </div>
    </div>
    <div class="tab-pane fade show divmain" id="divFacilities" role="tabpanel" aria-labelledby="home-tab">
	<div class="form-row"><div class="col-md-4" style="border-radius:10px;border-right:3px solid #f66;">
            <form Action=\"#\" name=\"Adding\" Method=\"POST\">
            <div class="form-row"><div class="col-md-12 divmainheading" id="divHead">NEW MEDICAL	FACILITY</div></div>
            <div class="form-row"><div class="col-md-12"><input type="hidden" name="txtNo" id="txtNo" value="0-0"><label for="txtName">Name of Facility *</label><input type="text" name="txtName" id="txtName"
                value="" maxlength="70" required placeholder="Name of Hospital" class="form-control" onkeyup="verifyString(0,this)"></div>
            </div><div class="form-row">
                <div class="col-md-12">Postal Address </label><input type="text" name="txtAddr" id="txtAddr" maxlength="50" value="P.O Box" placeholder="P.O Box 440 - 50406, FYL" class="form-control"
                onkeyup="verifyString(0,this)"></div>
            </div><div class="form-row">
                <div class="col-md-12">E-Mail Address </label><input type="email" name="txtEMail" id="txtEMail" maxlength="35" value="" placeholder="someone@website.com" class="form-control"
                style="text-transform:lowercase;" onkeyup="verifyString(1,this)"></div>
            </div><div class="form-row">
                <div class="col-md-12"><label for="txtTel">Telephone/Mobile No. *</label><INPUT name="txtTel" id="txtTel" type="text" value="" required placeholder="254712609945" class="form-control"
                onkeyup="verifyString(2,this)"></div>
            </div><div class="form-row">
                    <div class="col-md-12" style="text-align:center;"><hr><button type="button" name="cmdAdd" <?php echo ($add==1?" ":"disabled"); ?> onclick="return saveFacility()"
                    class="btn btn-info btn-sm btn-block">Save Medical Facility Details</button></div>
            </div></form>
	</div><div class="col-md-7" style="border-radius:10px;border-left:3px solid #f66;">
            <div class="form-row">
                <div class="col-md-12" id="spFacilities"><h6>LIST OF HEALTH FACILITIES WHERE STUDENTS ARE TREATED</h6>
                    <table class="table table-striped table-hover table-bordered table-sm"><thead class="thead-dark"><tr><th>#</th><th>Name of Facility</th><th>Address</th><th>E - Mail</th><th>Telno</th><th>Registered On
                    </th><th>Action</th></tr></thead><tbody>
                    <?php
                        $rsHos=mysqli_query($conn,"SELECT cred_no,name,paddress,email,telno,regdate FROM acc_creditors WHERE markdel=0 and categ=1");
                        $i=mysqli_num_rows($rsHos); $a=1; $optHosp=$listHosp='';
                        if ($i>0) while (list($credno,$name,$addr,$email,$tel,$date)=mysqli_fetch_row($rsHos)){
                            $optHosp.="<option value=\"$credno\">$name</option>";
                            print "<tr><td>$a</td><td>$name</td><td>$addr</td><td>$email</td><td>$tel</td><td>".date('D d M, Y',strtotime($date))."</td><td align=\"center\">".($edi==1?"<a href=\"#\"
                            onclick=\"editHospital($credno)\">Edit</a>":"-")."</td></tr>";
                            $listHosp.=($a==1?"":",")."new Hospitals($credno,\"$name\",\"$addr\",\"$email\",\"$tel\")"; 		$a++;
                        } mysqli_free_result($rsHos);
                    ?></tbody><tfoot class="thead-light"><tr><th colspan="7" style="letter-spacing:6px;word-spacing:9px;"><?php echo $i;?> Hospital Facilities</th></tr></tfoot></table></div>
            </div>
        </div></div>
    </div>
    <div class="tab-pane fade show divmain" id="divRpt" role="tabpanel" aria-labelledby="home-tab">
        <form name="frmSMedRPT" method="get" action="">
        <div class="form-row" style="margin:1px;">
            <div class="col-md-9" style="border-radius:6px;border-right:3px solid #f66;border-left:3px solid #f66;">
                Surcharged Medical Bills Between <Input type="text" name="txtFrom" id="txtFrom" class="tcal" size="8" value="<?php echo date('d-m-Y',strtotime('-30days')); ?>">  and <Input
                type="text" name="txtTo" id="txtTo" class="tcal" size="8" value="<?php echo date('d-m-Y');?>">
                <button type="button" name="btnMedRpt" id="btnMedRpt" onclick="rptHospBills(1)" class="btn btn-info btn-sm">View Medical<br>Bills Incurred</button>&nbsp;&nbsp;or &nbsp;&nbsp;
                <button type="button" name="btnMedRpt" id="btnMedRecRpt" onclick="rptHospBills(2)" class="btn btn-info btn-sm">View Medical<br>Recoveries</button>
            </div>
            <div class="col-md-3" style="border-radius:6px;min-height:2rem;border-right:3px solid #f66;border-left:3px solid #f66;text-align:right;">
                <button type="button" name="btnHospDebtRpt" id="btnHospDebtRpt" onclick="rptHospBills(3)"  class="btn btn-info btn-sm">Medical Bill<br>Debtors</button> &nbsp;
                <button type="button" name="btnHospRpt" id="btnHospRpt" onclick="rptHospBills(4)"  class="btn btn-info btn-sm">List of Medical<br>Facilities</button>
            </div>
        </div></form><hr><div class="form-row">
            <div class="col-md-12" style="max-height:500px;overflow-y:scroll;" id="divMedRpt"></div>
        </div><div class="form-row" style="margin:1px;">
            <div class="col-md-12" style="text-align:center;margin:1px;"><a href="#" onclick="printSpecific('divMedRpt')" style="float:right;display:none;" id="printH"><img height=20 width=30
            src="/gen_img/print.ico" alt="Print Report">Print Report</a></div>
        </div>
    </div>
</div>
<div class="row"><div class="col-md-12" style="text-align:right;"><hr><a href="pupil_manager.php"><button name="close" type="button" class="btn btn-info btn-sm">Close Interface</button></a></div>
</div></div>
<div id="divEditBill" class="modal" style="font-size:1rem;">
    <form action="spemedical.php" Method="Post" name="frmBillEdit" onsubmit="return validateFormOnSubmit1(this)">
    <div class="imgcontainer"><span onclick="document.getElementById('divEditBill').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span>
    <h4 id="pTitle" style="color:#fff;text-decoration:underline overline double #fff;"></h4></div><input type="hidden" name="txtAccVote1" id="txtAccVote1"
    value="<?php echo "$vacc-$vvote-".$_SESSION['tkn_add'];?>">
    <div class="container">
        <div class="form-row"><div class="col-md-11"><input type="hidden" name="txtNo1" id="txtNo1" value=""><label for="txtInvoice1">Invoice No. *</label><input type="text"
            name="txtInvoice1" value="" id="txtInvoice1" maxlength="9" required class="form-control"></div>
        </div><div class="form-row"><div class="col-md-11"><label for="cboHosp1">Name of Hospital *</label><Select name="cboHosp1" id="cboHosp1" size="1" required class="form-control">
            <?php echo $optHosp;?></select></div>
        </div><div class="form-row"><div class="col-md-5"><label for="txtDate1">Date of Invoice *<br><input type="text" name="txtDate1" id="txtDate1" readonly class="form-control tcal"
            value="<?php print date('d-m-Y');?>"></div><div class="col-md-6"><label for="txtAmt1">Bill Amount *</label><Input name="txtAmt1" id="txtAmt1" type="text" onkeyup="checkNumber(1,this)"
            onblur="fmtNumber(this)" value="0.00" required class="form-control" style="font-weight:bold;"></div>
        </div><div class="form-row"><div class="col-md-11"><label for="txtRmks1">Narration of Hospital Bill Invoice *</label><textarea rows="3" name="txtRmks1" id="txtRmks1" class="form-control"
            placeholder="Medical Bill for Hospitalization" style="text-transform:uppercase;" maxlength="250"></textarea></div>
        </div><div class="form-row"><div class="col-md-11"><p id="pWords"	style="font-weight:bold;color:#fff;">Zero Shillings and Zero Cents</p><br></div>
    </div><div class="form-row"><div class="col-md-4"><button name="btnSaveBill" class="btn btn-primary btn-block" type="submit">Save Medical Bill</button></div><div class="col-md-4"
        style="text-align:right;"><button type="button" class="btn btn-info btn-sm" name="btnDel" id="btnDel" <?php print "onclick=\"return delConfirm($del)\"";?> style="display:none;">
        Delete</button></div><div class="col-md-3" style="text-align:right;"><button type="button" onclick="document.getElementById('divEditBill').style.display='none'"
        class="btn btn-success btn-sm">Cancel/Close</button></div>
    </div><div class="form-row" style="display:none;" id="divDelRmks"><div class="col-md-8"><hr><label for="txtDelRmks1">Reason for Deleting</label><textarea name="txtDelRmks1" id="txtDelRmks1"
        rows="2" style="text-transform:uppercase;" placeholder="Hospital bill was erroneously captured" onkeyup="enableDel(this)"></textarea></div><div class="col-md-3" style="text-align:right;">
        <button type="submit" name="btnDelete" id="btnDelete" class="btn btn-danger btn-lg" disabled>Delete Bill</button></div>
    </div></div></form>
</div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/spemedical.js"></script>
<script type="text/javascript"><?php if(strlen($listHosp)>0) print "hospitals.push($listHosp);"; if(strlen($listBills)>0) print "hospbills.push($listBills);";?>
</script><script type="text/javascript" src="tpl/printthis.js"></script>
<?php mysqli_close($conn); footer(); ?>
