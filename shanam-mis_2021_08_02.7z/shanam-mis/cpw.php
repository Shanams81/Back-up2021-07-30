<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>Change Password</title>
		<link href="tpl/acc.css" rel="stylesheet" type="text/css"/>
		<STYLE type="text/css">
			table{border:3px solid green;border-collapse:collapse; border:outset 3px;font-size:15px;position:absolute;top:180px;
			left:250px;}
			td,th{letter-spacing:6px;word-spacing:10px;border-right:2px solid #099009;border-left:2px solid #099009;border-top:1px solid 
			green;border-bottom:1px solid green;}
			input,select{font-size:15px;text-align:left;letter-spacing:5px;}
			button{font-size:15px;font-weight:bold;letter-spacing:6px;word-spacing:10px;position:absolute;top:450px;}
		</style>
		<script type="text/javascript" src="tpl/cpw.js"></script>
    </head>
<body background="img/bg3.gif">
	<form method="post" onsubmit="return validateFormOnSubmit(this)" action="cpw_change.php" name="FrmCPW">
	<table cellpadding="10" cellspacing="6" Align="center"><tr><th bgcolor="#888888" colspan="2" style="color:#ffffff;word-spacing:7px;
	letter-spacing:10px;font-size:12px;">CHANGING PASSWORD</th></tr><input type="hidden" name="TxtCName" value=<?php print $_SESSION['username']; 
	?>><tr><td align="right" width="70%">Your Current Username:</td><td width="30%"><input type="text" name="TxtUName" value=<?php print 
	$_SESSION['username']; ?> size="20" maxlength="12" id="TxtUName"></td></tr>
	<tr><td align="right">Enter Your Current Password</td><td><input type="password" size="20" name="TxtCPW" maxlength="12" id="TxtCPW"></td></tr>
	<tr><td align="right">Enter Your New Password</td><td><input type="Password" size="20" name="TxtNPW" maxlength="12" id="TxtNPW"></td></tr>
	<tr><td align="right">Retype Your New Password</td><td><input type="Password" size="20" name="TxtConfirm" maxlength="12" id="TxtConfirm"></td>
	</tr></table><br><br>
    <button type="submit" accesskey="c" name="save" style="left:350px"><u>C</u>hange Password</button><a href="home.php"><button type="button" 
	accesskey="c" name="cancel"  style="left:650px">Exit</button></a></font>
	</form>
</body>
</html>