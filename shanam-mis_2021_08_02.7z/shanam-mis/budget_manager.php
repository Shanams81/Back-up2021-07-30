<?php
	session_start();
	if (!isset($_SESSION['username']) || ($_SESSION['username'] == ''))	header ("Location:../index.php"); else include_once("../conn/Pri_Sch_connect.inc");
	$rsDet=mysqli_query($conn,"SELECT budgview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");	$budgv=0;	
	if (mysqli_num_rows($rsDet)>0) list($budgv)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	if($budgv==0) header("location:vague.php");
?>
<!DOCTYPE html>
<html lang="en">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">	
	<title>School MIS Manager</title>
	<link rel="shortcut icon" href="../gen_img/phone.ico"/>
	<script type="text/javascript" src="tpl/menu.js"></script>
</head>
<body background="img/bg3.gif" style="background-size:100%;">
<?php
	print "<table border=\"0\" cellspacing=\"2\" cellpadding=\"3\" align=\"center\" style=\"position:relative;top:100px;\"><tr><td style=\"color:#00FF33;text-align:center;
	background-color:#8888AA;font-style:bold;font-size:12pt;word-spacing:5px;letter-spacing:3px;\" colspan=\"2\">FINANCIAL ESTIMATES &amp; BUDGET MANAGEMENT INTERFACE.<br> Log In Time: ".
	$_SESSION['logintime']."</td></tr>"; 
 	print "<tr><td width=\"35%\" align=\"center\"><a href=\"budget.php\" onclick=\"return canvi($budgv);\"><img src=\"img/budg.jpg\" id=\"img2\" width=\"120\" height=\"100\" 
	onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Budgeting</td>";
	print "<td width=\"35%\" align=\"center\"><a onclick=\"return canvi($budgv);\" href=\"fyestimates.php\"><img src=\"img/goods.jpg\" id=\"img1\" width=\"120\" height=\"100\" 
	onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>FY Estimates</td></tr>"; 
	print "<tr><td colspan=\"2\" style=\"background-color:#88A;color:#00FF33;text-align:center;font-style:bold;font-size:12pt;word-spacing:5px;letter-spacing:3px;color:#0F3;
	text-align:center;\">Shanam's Digital Solutions - Bridging Digital Divide</td></tr>";
	mysqli_close($conn);
?>
</table>
</body>
</html>