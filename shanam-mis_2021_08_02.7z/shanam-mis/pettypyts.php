<?php
	include_once('shanam.php');
	$rsStf=mysqli_query($conn,"SELECT pytview,pytadd,pytedit,pytdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'"); $pytviu=$pytedi=$pytadd=$pytdel=0;
	list($pytviu,$pytadd,$pytedi,$pytdel)=mysqli_fetch_row($rsStf);	mysqli_free_result($rsStf); if($pytviu==0) header("location:vague.php");
	if(isset($_POST['CmdAddNew'])) header("location:pettycash.php"); $action=isset($_POT['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
	$sdate=isset($_POST['dtpFrom'])?sanitize($_POST['dtpFrom']):date("d-m-Y",strtotime("-1days"));	$edate=isset($_POST['dtpTo'])?sanitize($_POST['dtpTo']):date("d-m-Y");
	$acc=isset($_POST['cboAc'])?sanitize($_POST['cboAc']):'%';
	headings('<link href="tpl/css/headers.css" rel="stylesheet"/><link rel="stylesheet" href="/date/tcal.css"/><link href="tpl/css/inputsettings.css" rel="stylesheet"/>',
	$action[0],$action[1],2);
	mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE markdel=0 ORDER BY acno ASC; SELECT v.vono,p.idno,p.payee,p.telno,v.pytdate,v.pytfrm,v.cheno,v.rmks,v.caamt,
	v.chamt,(v.caamt+v.chamt) As Amt,datediff(curdate(),v.pytdate) as nd,p.payno,v.acc FROM	acc_exp v Inner Join acc_exppayee p On (v.expno=p.payno) WHERE (v.markdel=0 and v.commt='0'
	and (v.pytdate BETWEEN '".date('Y-m-d',strtotime($sdate))."' and '".date('Y-m-d',strtotime($edate))."') and v.acc LIKE '$acc') ORDER BY v.vono desc;");
	$i=0; $optacc='<option value="%" selected>All A/Cs</option>'; $table=""; $ttl=[0,0,0]; $acname='All';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){if (mysqli_num_rows($rs)>0){while ($dt=mysqli_fetch_row($rs)){$optacc.="<option value=\"$dt[0]\" ".($dt[0]==$acc?"selected":"").">$dt[1]</option>";
				if($dt[0]==$acc) $acname=$dt[1];}}
			}else{ $noexp=mysqli_num_rows($rs);
				if($noexp>0) while($d=mysqli_fetch_row($rs)){
					$table.="<tr><td>$d[0]</td><td>$d[1]</td><td>$d[2]</td><td>$d[3]</td><td>".date('D d M, Y',strtotime($d[4]))."</td><td>$d[5]</td><td>$d[6]</td><td>$d[7]</td><td
					align=\"right\">".number_format($d[8],2)."</td><td align=\"right\">".number_format($d[9],2)."</td><td align=\"right\">".number_format($d[10],2)."</td><td align=\"center\">".
					(($d[11]<2 && $pytedi==1)?"<span class=\"spedit\" onclick=\"window.open('pettycashedit.php?vono=$d[13]-$d[0]','_self')\" title=\"Edit PV\">&#x270d;</a>":"")."</td><td
					align=\"center\"><a href=\"rpts/pv.php?action=$d[0]-1-$d[12]-$d[13]\"><img src=\"/gen_img/print.ico\" height=15 width=20 title=\"Print PV\"></a></td></tr>";
					$ttl[0]+=$d[8]; $ttl[1]+=$d[9];	 $ttl[2]+=$d[10];
				}else{$table.="<tr><td colspan=\"13\">No PettyCash payment records made</td></tr>";}
				$table.="</tbody><tfoot class=\"thead-light\" id=\"trTtls\"><tr><th colspan=\"5\">$noexp Payment Record(s)</th><th colspan=\"3\" align=\"right\">Payment Subtotals</th><th
				align=\"right\">".number_format($ttl[0],2)."</th><th align=\"right\">".number_format($ttl[1],2)."</th><th align=\"right\">".number_format($ttl[2],2)."</th><th colspan=\"2\">
				</th></tr></tfoot>";
			} mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	$h= $acname." Petty Cash Payments Made Between <font color=\"#00F\">".date("D, d-F-Y",strtotime($sdate))."</font> and <font color=\"#00f\">".date("D, d-F-Y",strtotime($edate)).
	"</font>.";
?><div class="head"><form action="pettypyts.php" method="POST">View <label for="date3">View <select name="cboAc" id="cboAc" size=1><?php echo $optacc;?></SELECT> Pettycash Payments
Between </label><input name="dtpFrom" class="tcal" type="text" value="<?php echo $sdate;?>" readonly size="8"><label for="date4">&nbsp;and&nbsp;</label><input name="dtpTo" class="tcal"
type="text" value="<?php echo $edate; ?>" readonly size="8">&nbsp;&nbsp;<button type="submit"	name="CmdView">View Payments</button>&nbsp;&nbsp;&nbsp;<button type="submit" name="CmdAddNew"
<?php echo ($pytadd==0?"disabled":"");?>>New Payment Record</button></form></div>
<div class="container divmain">
	<div class="form-row"><div class="col-md-12" style="border:0.5px dotted green;border-radius:10px 10px 10px 10px;padding:6px;"><form name="frmFind" action="#" method="post">
	Find Payment By &nbsp;<input type="radio" name="radFind" id="radVNo" value="vono" onclick="clrText()" selected>PV No.&nbsp; <input type="radio" name="radFind" id="radName"
	value="names" checked onclick="clrText()">Payee's Names &nbsp; <input type="radio" name="radFind" id="radIDNo"	value="idno" onclick="clrText()">ID No. &nbsp; <input type="radio"
	name="radFind" id="radTelNo"	value="telno" onclick="clrText()">Tel No. &nbsp;&nbsp; <input type="text" maxlength="15" size="25" name="txtFind" id="txtFind" value=""
	onkeyup="myFunction()" placeholder="Type/ Enter what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;"></form></div></div>
	<div class="form-row"><div class="col-md-12" style="max-height:600px;overflow-y:scroll" id="divPettyPyts"><?php echo "<h5>".strtoupper($h)."</h5>";?>
	<table class="table table-sm table-hover table-striped table-bordered" id="tblPV"><thead class="thead-dark"><tr><th rowspan="2">VOUCHER<br>NO.</th><th colspan="3">PAYEE'S DETAILS</th>
	<th	colspan="4">PETTY CASH PAYMENT DETAILS</th><th colspan="3">AMOUNT PAID</th><th colspan="2">ADMIN ACTION</th></tr><th>ID. NO.</th><th>PAYEE</th><th>TEL. NO.</th><th>DATE</th>
	<th>MODE</th><th>CHEQUE NO.</th><th>REASON FOR PAYMENT</th><th>CASH</th><th>CHEQUE</th><th>TOTAL</th><th>EDIT</th><th>VOUCHER</th></tr><?php echo $table;?></table></div>
	</div><div class="form-row">
		<div class="col-md-12" style="text-align:right;"><img onclick="printSpecific()" src="/gen_img/print.ico" height=20 width=30 title="Print List"></div>
  </div>
</div>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/pettypyts.js"></script>
<?php mysqli_close($conn); footer(); ?>
