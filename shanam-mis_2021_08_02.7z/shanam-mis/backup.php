<?php
    //Enter your database information here and the name of the backup file
    echo '<!DOCTYPE html><html><head><title>Database Backup</title><style>#myProgress{position:relative; width:100%;height:30px; background-color:#00bfff;}myBar{position:absolute;width:5%;
    height:100%;background-color:#f0f;}a:hover,a:active{background-color:#ff5733;text-decoloration:underline;background-color:#3498DB;border:1px dotted #3498DB;diplay:inline-block;
    height:10px;border-radius:5px;color:#fff;font-size:10pt;letter-spacing:1px;}</style><body background="../gen_img/bg3.gif"><center>';
    if (isset($_POST["btnBackup"])){
      include_once('../conn/par.inc.tpl'); include_once('../conn/dump.php');
      try{
        $world_dumper = Shuttle_Dumper::create(array('host' => $host,'username' => $user,'password' => $pw,'db_name' => $db));
        // dump the database to gzipped file
        $world_dumper->dump($file);
        echo '<center><div style="border:1px dotted #3498DB;diplay:inline-block;height:160px;width:50%;border-radius:5px;position:relative;top:100px;"><div
        style="background-color:#6495ed;color:#0ff;letter-spacing:4px;word-spacing:8px;font-size:12pt;text-align:center;">SHANAM\'S DIGITAL SOLUTIONS <br><br>SUCCESSFUL BACKUP
        </div><br>The database has successfully been backed up in the name <b><u>' .$file .'</u></b> .<br><br>Click &nbsp;&nbsp;<a href="'.$file.'" download="'.$file.'">HERE</a>
        &nbsp;&nbsp; to download a copy of backup.</div></center>';
      }catch(Shuttle_Exception $e){echo "Couldn't create database backup due to: " . $e->getMessage();}
    }else{print "No back up was done";}
?>
