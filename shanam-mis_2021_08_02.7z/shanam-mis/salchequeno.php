<?php
    include_once('shanam.php');
    if(isset($_POST['btnSave'])){
        $sno=isset($_POST['txtNoF'])?sanitize($_POST['txtNoF']):0; $sql='';
        for($i=0;$i<$sno;$i++){
            $no=isset($_POST['txtNo_'.$i])?trim(sanitize($_POST['txtNo_'.$i])):'0-0-0';           $no=preg_split('/\-/',$no);
            $cheno=isset($_POST['txtCheNo_'.$i])?sanitize($_POST['txtCheNo_'.$i]):'0000';
            if (strlen($cheno)>2){
                if($no[0]==0) $sql.="UPDATE acc_salppcheques SET chequeno='$cheno' WHERE salno LIKE '$no[1]' and paypoint LIKE '%$nos[2]%'; ";
                else $sql.="UPDATE acc_exp SET cheno='$cheno' WHERE salno LIKE '$no[1]' and expno LIKE '$no[2]' and vono LIKE '$no[3]'; ";
            }
        }$i=0;
        if(strlen($sql)>0){
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"payroll.php\">HERE</a> to try again.");
            do{ $i+=mysqli_affected_rows($conn);} while(mysqli_next_result($conn));
        }header("location:payroll.php?action=1-$i"); exit(0);
    }
    $salno=isset($_REQUEST['salno'])?sanitize($_REQUEST['salno']):0;
    headings('<style>hr.style-one{border:0;height:1px;background-image:linear-gradient(to right, rgba(0,0,0,0),rgba(0,0,0,0.75),rgba(0,0,0,0));}</style>',0,0,2);
    mysqli_multi_query($conn,"SELECT schtype FROM ss; SELECT concat(s.sal_month,'-',s.sal_year) as mon,concat(b.abbr,' (',a.accno,')') as bank,concat(ac.abbr,' (',v.descr,')') as vote
    FROM acc_salaries s Inner Join acc_accounts a On (s.acsno=a.sno) Inner Join acc_banks b On (a.bankno=b.sNo) Inner Join acc_voteacs ac On (a.accacc=ac.acno) Inner Join acc_votes v On
    (s.voteno=v.sno) WHERE s.salno LIKE '$salno'; SELECT paypoint,amt,chequeno FROM acc_salppcheques WHERE salno LIKE '$salno'; SELECT p.payno,if(isnull(e.vono),0,e.vono) as vno,p.payee,
    if(isnull(e.caamt),0,(e.caamt+e.chamt)) as amt, if(isnull(e.cheno),'',e.cheno) as chno FROM acc_exppayee p LEFT JOIN acc_exp e ON (p.payno=e.expno) WHERE (e.salno LIKE '$salno' or
    isnull(salno)) and (p.payno BETWEEN 2 and 9) and (e.markdel=0 or isnull(e.markdel)) ORDER BY p.payno ASC;"); $schtype=$i=$counter=0;
    echo '<form method="post" action="salchequeno.php" role="form" onsubmit="return confirmData()"><div class="container" style="background-color:#eee;border:0px;border-radius:10px;margin:auto;'
    . 'max-width:650px;padding:5px;border:2px dashed #eff;font-size:11pt;">';
    echo '<div class="panel panel-default"><div class="panel-body"><div class="form-row"><div class="col-md-12" style="font-weight:bold;font-size:12pt;background:#666;color:#fff;'
    . 'underline overline double #fff;">';
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){
                list($schtype)=mysqli_fetch_row($rs);
            }elseif($i==1){
                list($mon,$bank,$vote)=mysqli_fetch_row($rs);
                echo strtoupper('cheque numbers for '.$mon.' salary processed from <br>'.$vote.' on a/c '.$bank).'</div></div></div></div>';
                echo '<div class="row" style="font-weight:bold;"><div class="col-md-6">DESCRIPTION OF CHEQUE</div><div class="col-md-3">CHEQUE NO.</div><div class="col-md-3">AMOUNT (KSHS.)'
                . '</div></div>';
            }elseif($i==2){//Paypoint
                while(list($pp,$amt,$cheq)=mysqli_fetch_row($rs)){ //paypoint, amt, cheno
                    echo '<hr class="style-one"><div class="row"><div class="col-md-6"><input type="hidden" name="txtNo_'.$counter.'" id="txtNo_'.$counter.'" value="0-'.$salno.'-'.$pp.'">'
                    .$pp.'</div><div class="col-md-3"><input type="text" name="txtCheNo_'.$counter.'" id="txtCheNo_'.$counter.'" value="'.$cheq.'" maxlength="7" onkeyup="checkData(this)" '
                    .'style="text-align:right;"></div><div class="col-md-3" style="text-align:right;">'.number_format($amt,2).'</div></div>';
                    if($amt>0) $counter++;
                }
            }else{ //deductions
                while(list($payno,$vno,$paye,$amt,$cheq)=mysqli_fetch_row($rs)){ //Vono,Payee,amt,cheno
                    if($schtype==0) $paye=($payno==6?'RENT RECOVERIES':($payno==7?'ELIMU SACCO':($payno==8?'K . D . S SACCO':$paye)));
                    echo '<hr class="style-one"><div class="row"><div class="col-md-6">'.($amt>0?'<input type="hidden" name="txtNo_'.$counter.'" id="txtNo_'.$counter.'" '
                    .'value="1-'.$salno.'-'.$payno.'-'.$vno.'">':'').$paye.'</div><div class="col-md-3">'.($amt>0?'<input type="text" name="txtCheNo_'.$counter.'" id="txtCheNo_'.$counter.'" '
                    .'value="'.$cheq.'" onkeyup="checkData(this)" style="text-align:right;" maxlength="7">':'').'</div><div class="col-md-3" style="text-align:right;">'.number_format($amt,2).
                    '</div></div>';
                    if($amt>0) $counter++;
                }
            }mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
?>
<hr class="style-one"><div class="row"><div class="col-md-7" style="text-align:center;"><button type="submit" name="btnSave">Save Cheque Numbers</button></div><div class="col-md-5"
style="text-align:right"><a href="Payroll.php"><button type="button" name="btnClose">Cancel/Close</button></a></div></div></div>
<input type="hidden" name="txtNoF" value="<?php echo $counter;?>" id="txtNoF">
</form></div>
<script src="tpl/js/salcheques.js" type="text/javascript"></script>
<?php footer(); mysqli_close($conn);?>
