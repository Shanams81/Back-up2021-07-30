<Frameset cols="185,*" noresize border="1">
	<frame name="menu" src="menu.php" scrolling="no">
	<frame name="det" src="home.php" scrolling="auto">
</frameset>
<?php mysqli_close($conn); footer(); ?>
<script type="text/javascript">
    var idleTime = 0;
    $(document).ready(function () {
        //Increment the idle time counter every two minutes.
        setInterval(timerIncrement, 120000); // 2 minute
        //Zero the idle timer on mouse movement.
        $(this).mousemove(resetTimer);		$(this).mouseover(resetTimer);
        $(this).mousedown(resetTimer);		$(this).DOMMouseScroll(resetTimer);
        $(this).MSPointerMove(resetTimer);$(this).keypress(resetTimer);
        $(this).touchmove(resetTimer);		$(this).mousewheel(resetTimer);
    });
    function timerIncrement() {
        idleTime = idleTime + 2;
        if (idleTime > 5) { //5 minutes
            document.location.href="/index.php";
        }
    }
    function resetTimer() {
        /* Hide the timer text
        document.querySelector(".timertext").style.display = 'none'; */
        idleTime = 0;
    }
</script>
