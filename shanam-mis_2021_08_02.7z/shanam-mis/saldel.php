<?php
	include_once('../conn/pri_sch_connect.inc');
	$inf=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0-0-0"; 	$inf=preg_split('/\-/',$inf);
	if ($inf[0]==0){	//confirm delete
		$ac=2;
		mysqli_query($conn,"UPDATE acc_salpyt SET markdel=2 WHERE payrollno LIKE '$inf[1]' and sal_month LIKE '$inf[2]' and sal_year LIKE '$inf[3]'") or 
		die(mysqli_error($conn)." Salary not sucessfully deleted. Click <a href=\"payroll.php\">here</a> to try again.");
	}else{ //restore deleted
		$ac=1;
		mysqli_query($conn,"UPDATE acc_salpyt SET markdel=0 WHERE payrollno LIKE '$inf[1]' and sal_month LIKE '$inf[2]' and sal_year LIKE '$inf[3]'") or 
		die(mysqli_error($conn)." Salary not restored. Click <a href=\"payroll.php\">here</a> to try again.");
	}
	$i=mysqli_affected_rows($conn);
	header("location:payroll.php?action=$ac-$i");
?>