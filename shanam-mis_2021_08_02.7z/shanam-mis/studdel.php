<?php
	include_once("../conn/pri_sch_connect.inc");
	$adm=isset($_REQUEST['admno'])?$_REQUEST['admno']:0; $i=0;
	$rs=mysqli_query($conn,"SELECT recieptno FROM acc_feerec WHERE admno LIKE '$adm'"); $i=mysqli_num_rows($rs); mysqli_free_result($rs);
	if ($i==0){
		$rs=mysqli_query($conn,"SELECT recipetno FROM acc_miscfeepyts WHERE payeesno LIKE '$adm'"); 
		$i=mysqli_num_rows($rs); mysqli_free_result($rs);
	}
	$yr=date('Y');
	if ($i>0){
		mysqli_query($conn,"UPDATE stud SET markdel=1,present=0,type=0 WHERE admno LIKE '$adm'");	
		$i=mysqli_affected_rows($conn);
		if ($i==1) mysqli_query($conn,"UPDATE class SET markdel=1 WHERE admno LIKE '$adm' AND curr_year LIKE '$yr'");
	}else{
		mysqli_query($conn,"DELETE FROM stud WHERE admno LIKE '$adm'");
		$i=mysqli_affected_rows($conn);
		if ($i==1) mysqli_query($conn,"DELETE FROM class WHERE admno LIKE '$adm'");
	}
	header("location:student.php?action=2-$i");
?>