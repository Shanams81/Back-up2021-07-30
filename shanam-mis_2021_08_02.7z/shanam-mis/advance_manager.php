<?php
    include_once("shanam.php");
    $rsDet=mysqli_query($conn,"SELECT advreqapproval,advview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");	$adv=0; $reqv=0;
    if (mysqli_num_rows($rsDet)>0) list($adva,$advv)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
    //number of pending advance requests
    $rs=mysqli_query($conn,"SELECT count(reqno) as nos FROM acc_advreq GROUP BY adv_status,markdel HAVING (adv_status=0 and markdel=0)");
    $advno=0; if (mysqli_num_rows($rs)>0) list($advno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
    headings('',0,0,0);
    print "<table><tr><td colspan=\"2\"><p><a href=\"stf_manager.php\"><img src=\"img/ani_back.gif\" hspace=\"1\" width=\"45\" height=\"20\" align=\"left\"></a>&nbsp;SALARY ADVANCE MANAGEMENT
    INTERFACE.<br> Log In Time: ".$_SESSION['logintime']."</p>";
    print "</td></tr><tr><td width=\"35%\" align=\"center\"><a href=\"saladvreq.php\" onclick=\"return canvi($adva);\"><img src=\"../gen_img/acc.jpeg\" id=\"img2\" width=\"120\"
    height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br><font color=\"#ee0000\">($advno)</font> Salary Advance Request(s)</td>";
    print "<td width=\"35%\" align=\"center\"><a href=\"saladv.php\" onclick=\"return canvi($advv);\"><img src=\"../gen_img/adv.jpeg\" id=\"img2\" width=\"120\"
    height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Salary Advance</td></tr>";
    print "<tr><td colspan=\"3\"><p>Shanam's Digital Solutions - Bridging Digital Divide</p></td></tr></table>";
    print "<a href=\"stf_manager.php\" style=\"position:absolute;bottom:300px;right:300px;\"><button type=\"button\" name=\"btnClose\" id=\"btnClose\" class=\"btn btn-info btn-md\">Close/Go
    Back</button></a><script type=\"text/javascript\" src=\"tpl/menu.js\"></script>";
    mysqli_close($conn); footer();
?>
