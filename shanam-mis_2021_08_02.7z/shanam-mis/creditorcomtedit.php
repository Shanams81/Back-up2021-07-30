<?php
	include_once('shanam.php');
	$recno=isset($_REQUEST['rec'])?sanitize($_REQUEST['rec']):0;
	mysqli_multi_query($conn,"SELECT c.cred_no,c.name,ci.inv_date,ci.yr,ci.inv_no,ci.lpono,ci.acc,ci.voteno,ci.estimatedamt,ci.rmks FROM acc_creditorsdet ci INNER JOIN
	acc_creditors c USING (cred_no) WHERE ci.detno LIKE '$recno'; SELECT finyr FROM ss; SELECT acc,sno,descr FROM acc_votes WHERE markdel=0 and pyt_defined=1 ORDER BY sno ASC; SELECT
	credadd,creddel,crededit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT acno,descr FROM acc_voteacs WHERE markdel=0 and pyt_assoc=1 ORDER BY descr ASC; SELECT acc,sno,
	expdescr FROM acc_votes WHERE markdel=0 and expabbr LIKE 'sundry' ORDER BY descr ASC;"); $canadd=$candel=$edit=$i=0; $optvotes=$optacc=$lstvotes=$lstsundry="";
	do{
		if($rs=mysqli_store_result($conn)){
			if($i===0) list($credno,$name,$cdate,$yr,$invno,$clpo,$cacc,$cvote,$ceamt,$crmks)=mysqli_fetch_row($rs);
			elseif($i===1) list($cuyr)=mysqli_fetch_row($rs);
			elseif($i===2){$x=0; while ($d=mysqli_fetch_row($rs)){
					$lstvotes.=($x==0?"":",")."new Voteheads($d[0],$d[1],'$d[2]')"; $x++;
					if($d[0]==$cacc && $yr==$cuyr) $optvotes.="<option value=\"$d[1]\" ".($d[1]==$cvote?"selected":"").">$d[2]</option>";
				}
			}elseif($i===3) list($canadd,$candel,$edit)=mysqli_fetch_row($rs);
			elseif($i===4) while($d=mysqli_fetch_row($rs)) $optacc.="<option value=\"$d[0]\" ".($cacc==$d[0]?"selected":"").">$d[1]</option>";
			else{$x=0; while ($d=mysqli_fetch_row($rs)){
					$lstsundry.=($x==0?"":",")."new Voteheads($d[0],$d[1],'$d[2]')"; $x++;
					if($d[0]==$cacc && $yr!=$cuyr) $optvotes.="<option value=\"$d[1]\" ".($d[1]==$cvote?"selected":"").">$d[2]</option>";
				}
			}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link rel="stylesheet" href="../date/tcal.css" /><link rel="stylesheet" href="tpl/css/inputsettings.css" />',0,0,2);
?>
<div class="container divmodalmain"><form method="post" action="creditorcommtadd.php" onsubmit="return validateCommt(this)" name="frmCommt">
	<div class="form-row"><div class="col-md-12 divheadings">EDIT <?php echo $name;?>'S COMMITMENT DETAILS</div></div>
	<div class="form-row"><input type="hidden" name="txtType_1" id="txtType_1" value="2"><input type="hidden" name="txtInfo_1" id="txtInfo_1" value="<?php echo $recno;?>">
		<div class="col-md-3"><label for="txtCredNo_1">Creditor's Code</label><Input Name="txtCredNo_1" id="txtCredNo_1" Type="Text" readonly value="<?php echo $credno;?>"
			maxlength="4" class="modalinput"></div>
		<div class="col-md-6"></div>
		<div class="col-md-3"><label for="txtDate_1">Date of Commitment</label><input name="txtDate_1" id="txtDate_1" readonly class="tcal modalinput" value="<?php
			echo date("d-m-Y",strtotime($cdate));?>"></div>
	</div><div class="form-row">
		<div class="col-md-3"><label for="txtYr_1">Year of Credit</label><input type="text" name="txtYr_1" id="txtYr_1" value="<?php echo $yr;?>" class="modalinput"
				maxlength="4"	onkeyup="checkInput(this)" onchange="fillVotesBasedOnYr(this,<?php echo $cuyr;?>)"></div>
		<div class="col-md-4"><label for="cboAC_1">Commitment Account</label><SELECT name="cboAC_1" id="cboAC_1" onchange="fillVotes(this,<?php echo $yr;?>)" size="1"
			class="modalinput"><option value=0>Choose Account</option><?php echo $optacc;?></SELECT></div>
		<div class="col-md-5"><label for="cboVote_1">Votehead Costed</label><SELECT name="cboVote_1" id="cboVote_1" size="1" onblur="voteSelected(<?php echo $canadd;?>)"
			class="modalinput"><option value="0">Choose Votehead</option><?php echo $optvotes;?></SELECT></div>
	</div><div class="form-row">
		<div class="col-md-12"><label for="txtRmks_1">Commitment Narration</label><TextArea name="txtRmks_1" id="txtRmks_1" type="text" class="modalinput" rows="2" maxlength="250"
			placeholder="AUTOMATION OF ACCOUNT AND INSTALLATION OF LAN SERVICES"><?php echo $crmks;?></textarea></div>
	</div><div class="form-row">
		<div class="col-md-3"><label for="txtLPONo_1">LPO/LSO No.</label><input name="txtLPONo_1" id="txtLPONo_1" type="text" value="<?php echo $clpo;?>" onkeyup="checkInput(this)"
			class="modalinput modalinputdisabled"	maxlength="10"	readonly></div>
		<div class="col-md-3"><label for="txtInvNo_1">Invoice No.</label><Input Name="txtInvNo_1" id="txtInvNo_1" Type="text" value="<?php echo $invno;?>" maxlength="7" class="modalinput
				numbersinput"></div>
		<div class="col-md-3"></div>
		<div class="col-md-3"><label for="txtAmount_1">Commitment Amount</label><input name="txtAmount_1" id="txtAmount_1" class="modalinput numbersinput" maxlength="11" type="text"
			value="<?php echo number_format(floatval($ceamt),2);?>"	onkeyup="checkInput(this)" onblur="formatnumber(this)"><input name="txtAmtOrig_1" id="txtAmtOrig_1" type="hidden"
			value="<?php echo $ceamt;?>"></div>
	</div><hr><div class="form-row btnDiv">
		<div class="col-md-4"><button type="submit" accesskey="s" name="cmdSave_1" class="btn btn-block btn-md btn-warning" id="cmdSave_1">Save Commitment Changes</button></div>
 		<div class="col-md-4" style="text-align:right"><button type="button" name="cmdDel" class="btn btn-md btn-warning" id="cmdDel" <?php echo $candel==0?"disabled":"";?>
			onclick="confirmDel()">Delete</button></div>
		<div class="col-md-4" style="text-align:right"><button type="button" name="cmdClose" class="btn btn-md btn-warning" id="cmdClose"
			onclick="window.open('creditorsummary.php?recno=<?php echo $credno;?>-0-0','_self')">Close/ Cancel</button></div>
	</div><hr>
	<div class="form-row">
		<div class="col-md-12 divlrborder"  id="divDel" style="display:none;">
			<div class="form-row">
				<div class="col-md-12"><label for="txtDelRmks">Reason for cancellation of the commitment</label><textarea name="txtDelRmks" id="txtDelRmks" rows="3" class="modalinput"
					onkeyup="enableDel(this)"	placeholder="ERRONEOUSLY CAPTURED MULTIPLE TIMES"></textarea></div>
			</div><div class="form-row">
				<div class="col-md-4"><button type="submit" name="cmdDelCommt" id="cmdDelCommt" class="btn btn-block btn-md btn-warning" disabled>Delete Commitment</button></div>
				<div class="col-md-4"></div>
				<div class="col-md-4"><button type="button" name="cmdDelClose" id="cmdDelClose" class="btn btn-block btn-md btn-warning" onclick="closeDel()">Cancel Delete</button></div>
			</div>
		</div>
	</div></form>
</div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/creditors.js"></script>
<script type="text/javascript" src="tpl/js/creditorsummary.js"></script>
<script type="text/javascript">
	thevotes.push(<? echo $lstvotes;?>); thesundry.push(<? echo $lstsundry;?>);
</script>
<?php mysqli_close($conn); footer();?>
