<?php
	include_once('../conn/pri_sch_connect.inc');
	$un=$_REQUEST['user'];
	$date=date("Y-m-d",strtotime("+2days"));
	@mysqli_query($conn,"UPDATE login SET expirydate='$date',pw=md5('000000') WHERE username LIKE '$un'") or die(mysqli_error($conn). " Password Activation 
	was not successful");
	$i=mysqli_affected_rows($conn);
	header("location:users.php?action=1-$i");
	mysqli_close($conn);
?>