<?php
	include_once('shanam.php');
	if (isset($_POST['CmdSave'])){
            $scnm=isset($_POST['txtScNm'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtScNm'])))):'';
            $scabb=isset($_POST['txtScAbb'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtScAbb'])))):'';
            $scadd=isset($_POST['txtScAdd'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtScAdd'])))):'';
            $motto=isset($_POST['txtMotto'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtMotto'])))):Null;
            $mission=isset($_POST['txtMission'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtMission'])))):'';
            $vision=isset($_POST['txtVision'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtVision'])))):'';
            $telno=isset($_POST['txtTel'])?trim(strip_tags($_POST['txtTel'])):Null;			$burstype=isset($_POST['cboBursType'])?trim($_POST['cboBursType']):0;
            $nssf=isset($_POST['txtNSSF'])?trim(strip_tags($_POST['txtNSSF'])):Null;			$nhif=isset($_POST['txtNHIF'])?trim(strip_tags($_POST['txtNHIF'])):Null;
            $pin=isset($_POST['txtPin'])?strtoupper(trim(strip_tags($_POST['txtPin']))):'A00000000Z';	$county=isset($_POST['cboCounty'])?trim($_POST['cboCounty']):'001';
            $mp=isset($_POST['cboConst'])?trim($_POST['cboConst']):'001';				$ward=isset($_POST['cboWard'])?trim($_POST['cboWard']):'0001';
            $princ=isset($_POST['txtPrinc'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtPrinc'])))):'';
            $finyr=isset($_POST['txtFinYr'])?trim(strip_tags($_POST['txtFinYr'])):date('Y');	$bursrec=isset($_POST['cboBursRec'])?trim(strip_tags($_POST['cboBursRec'])):0;
            $da=date("m")>11?(date("Y")+1):date("Y"); $da.="-12-31";				$rec=isset($_POST['cboPaper'])?trim($_POST['cboPaper']):0;
            $pbno=isset($_POST['txtBusNo'])?strtoupper(strip_tags($_POST['txtBusNo'])):Null;	$pbac=isset($_POST['txtACNo'])?strtoupper(strip_tags($_POST['txtACNo'])):Null;
            $rectype=isset($_POST['cbo2in1'])?trim($_POST['cbo2in1']):0;			$burstype=isset($_POST['cboBursType'])?trim($_POST['cboBursType']):0;
            $nssfrate=isset($_POST['txtNSSFRate'])?trim(strip_tags($_POST['txtNSSFRate'])):0;	$mpr=isset($_POST['txtMPR'])?trim(strip_tags($_POST['txtMPR'])):0;
            $noimp=isset($_POST['txtImprest'])?trim(strip_tags($_POST['txtImprest'])):0;	$nssfrate=preg_replace('/[^0-9\.]/','',$nssfrate);
            $noimp=preg_replace('/[^0-9\.]/','',$noimp);	$mpr=preg_replace('/[^0-9\.]/','',$mpr);
            if (strlen($scnm)<10 || strlen($scabb)<5 || strlen($scadd)<5 || strlen($princ)<10 || $nssfrate==0 || $noimp==0 || $mpr<1408 || $finyr<2020 || strlen($motto)<5){
                print "Sorry, you MUST type School name, address and principals name. The NSSF Deduction Rate, Number Imprests Held at a time and Monthly PAYE Relief (MPR)
                MUST be higher than zero. Click <a href=\"sysdata.php\">here</a> to try again.";
                exit(0);
            }else{
                mysqli_query($conn,"UPDATE ss SET sysdate='$da',scnm='$scnm',scabb='$scabb',scadd='$scadd',telno=".var_export($telno,true).",principal='$princ',motto=".var_export($motto,true).",
                vision=".var_export($vision,true).",mission=".var_export($mission,true).",nssfno='$nssf',nhifno='$nhif',emppin='$pin',finyr='$finyr',mpr='$mpr',nssfrate='$nssfrate',
                bursreceipt='$bursrec',burstype='$burstype',receipt='$rec',receipttype='$rectype',noimps='$noimp',paybillno=".var_export($pbno,true).",paybillac=".var_export($pbac,true).",
                county='$county',constituency='$mp',ward='$ward';");
                $i=mysqli_affected_rows($conn);
                header("location:sysdata.php?action=1-$i");
            }
	}
	headings('',0,0,1);
	mysqli_multi_query($conn,"SELECT s.sysDate,s.scnm,s.scabb,s.scadd,s.telno,s.principal,s.motto,s.mission,s.vision,s.nssfno,s.nhifno,s.emppin,s.finyr,s.mpr,s.nssfrate,s.bursreceipt,
	s.typerecno,s.bursType,s.paybillNo,s.paybillAC,s.receipt,s.receiptType,s.NoImps,s.county,s.constituency,s.ward FROM `ss` s;SELECT code,name FROM county ORDER BY name ASC; SELECT code,name,
	codecounty FROM constituency ORDER BY codecounty,name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,
	name ASC;"); $i=0; $optCounty=$optMP=$optMCA='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){
				if (mysqli_num_rows($rs)>0){
					list($sysdate,$scnm,$scabb,$scadd,$tel,$princ,$motto,$mission,$vision,$nssf,$nhif,$pin,$finyr,$mpr,$nsrate,$bursrec,$typrec,$burstype,$pbno,$pbac,$rec,$typrec,$impno,
					$gov,$const,$ward)=mysqli_fetch_row($rs);	$sysdate=date('l j - F - Y',strtotime($sysdate));
				}else{
					$sysdate=date('l j - F - Y');		$scnm='School Name Not Set';		$scadd='';				$finyr=date('Y');	$gov='001';
					$princ='';		$pbno='';					$nssf='';			$nhif='';					$pin='A0000000Z';	$mission='';			$mp='001';
					$motto='';		$pbac='';					$bal=0;				$vision='';				$rec=1;						$impno=1;					$mca='0001';
					$mpr=2400;		$typrec=0;				$nsrate=12;		$bursrec=0;				$scabb='';				$burstype=0;			$tel='';
				}
			}if($i==1) while (list($s,$n)=mysqli_fetch_row($rs)) $optCounty.="<option ".($gov==$s?"selected":"")." value=\"$s\">$n</option>";
			elseif($i==2){ $mp=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
				$mp.=($a==0?"":",")."new Consti(\"$s\",\"$n\",\"$c\")"; if($gov==$c) $optMP.="<option ".($const==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
			}else{ $mca=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
	   			$mca.=($a==0?"":",")."new MCA(\"$s\",\"$n\",\"$c\")"; if($c==$const) $optMCA.="<option ".($ward==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
	  	}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));

?>
<h1 style="letter-spacing:3px;word-spacing:4px;text-align:center;">DETAILS OF THE INSTITUTION</h1><form name="frmSysData" method="Post" action="sysdataedit.php"
onsubmit="return checkData(this)" role="form">
<div style="border:1px dotted #fff;border-radius:15px;padding:10px;max-width:800px;margin:auto;background-color:#eee;">
	<div class="form-row">
		<div class="col-md-8"><label for="txtScNm">Name of the Institution *</label><input type="text" name="txtScNm" id="txtScNm" readonly maxlength="75" value="<?php echo $scnm;?>"
		required></div>
		<div class="col-md-4"><label for="txtScAbb">Abbreviation of Name *</label><input type="text" name="txtScAbb" id="txtScAbb" maxlength="15" value="<?php echo $scabb;?>" required></div>
	</div><div class="form-row">
		<div class="col-md-8 mb-3"><label for="txtScAdd">Postal Address </label><input type="text" name="txtScAdd" id="txtScAdd" maxlength="75" value="<?php echo $scadd;?>"></div>
		<div class="col-md-4 mb-3"><label for="txtTel">Telephone/ Mobile No.</label><input type="text" name="txtTel" id="txtTel" maxlength="13" value="<?php echo $tel;?>"></div>
	</div><div class="form-row">
		<div class="col-md-4"><label for="txtMotto">Motto *</label><textarea name="txtMotto" id="txtMotto" maxlength="35" rows="3" required><?php echo $motto;?></textarea></div>
		<div class="col-md-4"><label for="txtVision">Vision:</label><textarea name="txtVision" id="txtVision" maxlength="150" rows="3"><?php echo $vision;?></textarea></div>
		<div class="col-md-4"><label for="txtMission">Mission:</label><textarea name="txtMission" id="txtMission" maxlength="150" rows="3"><?php echo $mission;?></textarea></div>
	</div><div class="form-row">
		<div class="col-md-3 mb-3"><label for="txtNHIF">NHIF Code:</label><input type="text" name="txtNHIF" id="txtNHIF" maxlength="9" value="<?php echo $nhif;?>"></div>
		<div class="col-md-2 mb-3"><label for="txtNSSF">NSSF Code:</label><input type="text" name="txtNSSF" id="txtNSSF" maxlength="9" value="<?php echo $nssf;?>" onblur="checkInput(this)">
		</div>
		<div class="col-md-3 mb-3"><label for="txtNSSFRate">NSSF Deduction Rate *</label><input name="txtNSSFRate" id="txtNSSFRate" type="text" maxlength="2" required value="<?php
		echo $nsrate;?>" onblur="checkInput(this)" style="text-align:right;"></div>
		<div class="col-md-2 mb-3"><label for="txtPin">KRA PIN No. :</label><input type="text" name="txtPin" id="txtPin" maxlength="15" value="<?php echo $pin; ?>"></div>
		<div class="col-md-2 mb-3"><label for="txtMPR">PAYE Relief *</label><input type="text" name="txtMPR" id="txtMPR" maxlength="8" style="text-align:right;" required value="<?php
		echo number_format($mpr,2);?>" onblur="checkInput(this)" title="Monthly PAYE Relief (MPR)"></div>
	</div><div class="form-row">
		<div class="col-md-3 mb-3"><label for="txtBusNo">M-Fee Business No.</label><input type="text" name="txtBusNo" id="txtBusNo" value="<?php echo $pbno;?>" maxlength=7></div>
		<div class="col-md-2 mb-3"><label for="txtACNo">M-Fee A/C No.</label><input type="text" name="txtACNo" id="txtACNo" value="<?php echo $pbac;?>" maxlength=12></div>
		<div class="col-md-3 mb-3"><label for="txtImprest">No. of Imprests *</label><input name="txtImprest" id="txtImprest" type="text" maxlength="1" required value="<?php echo $impno; ?>"
		style="text-align:right;" onblur="checkInput(this)" title="Maximum number of imprests a member of staff can have."></div>
		<div class="col-md-2 mb-3"><label for="cboPaper">Receipt Paper</label><SELECT name="cboPaper" id="cboPaper" size="1"><option value="0" <?php ($rec==0?'Selected':'');?>>
		A4 Receipt</option><option value="1" <?php ($rec==1?'Selected':'');?>>A5 Receipt</option></SELECT></div>
		<div class="col-md-2 mb-3"><label for="cbo2in1">2 in 1 Receipt?</label><SELECT name="cbo2in1" id="cbo2in1" size="1"><option value="0" <?php ($typrec==0?'Selected':'');?>>
		2in1 Receipt</option><option value="1" <?php ($typrec==1?'Selected':'');?>>Each A/C Receipt</option></SELECT></div>
	</div><div class="form-row">
    	<div class="col-md-4 mb-3"><label for="cboCounty">Home County *</label><SELECT name="cboCounty" id="cboCounty" size="1" required onChange="loadConstituency(this)">
		<?php echo $optCounty; ?></SELECT></div>
		<div class="col-md-4 mb-3"><label for="cboConst">Constituency *</label><SELECT name="cboConst" id="cboConst" size="1" onChange="loadWards(this)" required><?php echo $optMP; ?>
		</SELECT></div>
		<div class="col-md-4 mb-3"><label for="cboWard">County Ward *</label><SELECT name="cboWard" id="cboWard" size="1" required><?php echo $optMCA; ?></SELECT></div>
  	</div><div class="form-row">
		<div class="col-md-4 mb-3"><label for="txtPrinc">Headteacher/ Principal *</label><input type="text" name="txtPrinc" id="txtPrinc" maxlength="25" value="<?php echo $princ;?>" required>
		</div>
		<div class="col-md-2 mb-3"><label for="txtFinYr">Financial Year *</label><input type="text" name="txtFinYr" id="txtFinYr" maxlength="4" onblur="checkInput(this)" required
		value="<?php echo $finyr;?>"></div>
		<div class="col-md-3 mb-3"><label for="cboBursRec">Bursary Received As:</label><SELECT name="cboBursRec" id="cboBursRec" size="1"><option value="1" <?php echo ($burstype==1?
		"selected":"");?>>Cash</option><option value="0" <?php echo ($burstype==0?"selected":"");?>>Cheque</option></SELECT></div>
		<div class="col-md-3 mb-3"><label for="cboBursType">Print Bursary Receipt?</label><SELECT name="cboBursType" id="cboBursType" size="1"><option value="1" <?php echo ($bursrec==1?
		"selected":"");?>>Yes</option><option value="0" <?php echo ($bursrec==0?"selected":"");?>>No</option></SELECT></div>
	</div><div class="form-row"><div class="col-md-12 mb-3"><hr style="background-color:#00f;border:0.5px dashed red;"></div></div><div class="form-row">
		<div class="col-md-6 mb-3" style="text-align:center;"><button name="CmdSave" type="submit">Save System Data</button></div>
		<div class="col-md-6 mb-3" style="text-align:right;"><a href="sysdata.php"><button name="CmdClose" type="button">Close</button></a></div>
	</div>
</div></form>
<script type="text/javascript" src="tpl/js/sysdata.js"></script><script type="text/javascript" src="tpl/js/iebc.js"></script>
<?php
	if(isset($mp) && strlen($mp)>0){
		echo '<script type="text/javascript">var mp=['.$mp.'];';
		if(strlen($mca)>0) echo 'var mca=['.$mca.'];';
		echo '</script>';
	}
	mysqli_close($conn); footer();
?>
