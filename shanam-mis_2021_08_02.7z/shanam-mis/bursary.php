<?php
    include_once('shanam.php');
    if(isset($_POST['btnSave'])){
        $ron=isset($_POST['txtReceivedOn'])?sanitize($_POST['txtReceivedOn']):date('d-m-Y'); $ron=explode('-',$ron); $ron=$ron[2].'-'.$ron[1].'-'.$ron[0];
        $name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName']))):'';  $po=isset($_POST['txtPO'])?sanitize($_POST['txtPO']):0;
        $code=isset($_POST['txtPOCode'])?sanitize($_POST['txtPOCode']):null;    $town=isset($_POST['txtTown'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtTown']))):null;
        $mode=isset($_POST['cboMode'])?strtoupper(sanitize($_POST['cboMode'])):'CHEQUE'; 	$modeno=isset($_POST['txtModeNo'])?sanitize($_POST['txtModeNo']):null;
        $bank=isset($_POST['cboBank'])?strtoupper(sanitize($_POST['cboBank'])):0;		$bank=($bank==0?null:$bank); $branch=isset($_POST['txtBranch'])?strtoupper(sanitize($_POST['txtBranch'])):null;
        $ack=isset($_POST['txtAck'])?strtoupper(sanitize($_POST['txtAck'])):'THE CHAIRPERSON';   $amt=isset($_POST['txtAmt'])?strtoupper(sanitize($_POST['txtAmt'])):0;	$amt=preg_replace('/[^0-9\.]/','',$amt);
        $bno=isset($_POST['txtBursNo'])?strtoupper(sanitize($_POST['txtBursNo'])):0;		$burs=isset($_POST['txtBurs'])?strtoupper(sanitize($_POST['txtBurs'])):'0-0-0';
        $token=sanitize($_POST['txtUniqueId']);	$burs=explode('-',$burs);   //[0] Bursary Reciept(0-no,1-yes),[1] Mode (0-Cheque,1-Cash) and [2] Bursary votehead
        if($bno>0 && strlen($name)>8 && $po>0 && strlen($town)>3 && strlen($modeno)>2 && $amt>0 && strlen($ack)>3 && ($_SESSION['uniqueid']==$token)){
            $sql="INSERT INTO acc_burs (bursno,sourcename,pytfrm,cheno,pytdate,amt,addedby,addressee,bankno,branch,po,pocode,city) VALUES($bno,".var_export($name,true).",'$mode','$modeno','$ron',$amt,'".
            $_SESSION['username']." (".$_SESSION['priviledge'].")','$ack',".var_export($bank,true).",".var_export($branch,true).",'$po',".var_export($code,true).",'$town')";
            unset($_SESSION['uniqueid']);
            if(mysqli_query($conn,$sql) or die(mysqli_error($conn))){$action[1]=mysqli_affected_rows($conn);
                if($burs[0]==1){
                    $sql="INSERT INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bankno,addedby) VALUES (0,'Burs-$bno','$ron','Bursary',".($burs[1]==0?"'Cheque','$modeno'":"'Cash',null").",".
                    var_export($bank,true).",'".$_SESSION['username']." (".$_SESSION['priviledge'].")')";
                    if(mysqli_query($conn,$sql) or die(mysqli_error($conn).". Error in saving bursary as income")){ $sno=0; $recno=0;  $sno=mysqli_insert_id($conn);
                        if($sno>0){if(mysqli_query($conn,"INSERT INTO acc_incorecno0(recno,sno,acc,amt) VALUES(0,$sno,1,$amt)")){$recno=mysqli_insert_id($conn);
                            mysqli_query($conn,"INSERT INTO acc_incovotes (recno,acc,voteno,pytdate,amt) VALUES($recno,1,$burs[2],'$ron',$amt)");}
                        }//Bursary PV
                        $rs=mysqli_query($conn,"SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '1';"); $payno=$vono=0; list($vono)=mysqli_fetch_row($rs); mysqli_free_result($rs); $vono++;
                        if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES(0,'$ron',".var_export($name,true).",'Burs-$bno','P.O Box
                        $po - $code, $town',null,'".$_SESSION['username']." (".$_SESSION['priviledge'].")')")){$payno=mysqli_insert_id($conn);
                        }mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,addedby) values ($vono,'$ron',1,".($burs[1]==0?"'Cheque',
                        '$modeno',0,$amt":"'Cash',null,$amt,0").",'BEING PAYMENT TO CLEAR BURSARY NO. $bno',$payno,'".$_SESSION['username']." (".$_SESSION['priviledge'].")');
                        INSERT INTO acc_pytvotes(vono,acc,voteno,pytdate,amt) VALUES ($vono,1,$burs[2],'$ron',$amt);") or die(mysqli_error($conn));      while(mysqli_next_result($conn)){;}
                    }
                }
            } else $action[1]=0;
        }else{$action[1]=0; unset($_SESSION['uniqueid']);} $action[0]=1;
    }else {$action=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; 	$action=preg_split("/\-/",$action);}
    mysqli_multi_query($conn,"SELECT bursview,bursadd,bursedit,bursdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT max(bursno) from acc_burs; SELECT
    bursreceipt,burstype FROM ss; SELECT voteno FROM acc_votesassigned WHERE name LIKE 'bursary';");
    $bursRec=$bursType=$viu=$edi=$del=$add=$i=$bursno=0; $bursVote=5; //bursrec 0 No receipt, 1 receipt required, burstype 0 cheque receipt 1 cash receipt
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){list($viu,$add,$edi,$del)=mysqli_fetch_row($rs);	if($viu==0) header("location:vague.php");
            }elseif($i==1){if(mysqli_num_rows($rs)>0)list($bursno)=mysqli_fetch_row($rs);
            }elseif($i==2){if(mysqli_num_rows($rs)>0)list($bursRec,$bursType)=mysqli_fetch_row($rs);
            }else{if(mysqli_num_rows($rs)>0)list($bursVote)=mysqli_fetch_row($rs);}
            mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn)); $bursno++;	$frm_token=uniqid();	$_SESSION['uniqueid']=$frm_token;
    $sdate=isset($_POST['txtFrom'])?$_POST['txtFrom']:date("d-m-Y",strtotime('-30 days'));			$edate=isset($_REQUEST['txtTo'])?$_REQUEST['txtTo']:date("d-m-Y");
    headings('<link href="tpl/accprint.css" rel="stylesheet" type="text/css" media="print"/><link href="tpl/css/headers.css" rel="stylesheet" type="text/css" /><link rel="stylesheet"
    type="text/css" href="../date/tcal.css" /><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"
    type="text/css"/>',$action[0],$action[1],2);
?><div class="head">
<form method="post" name="frmFind" action="Bursary.php"><a href="pupil_manager.php"><img src="../gen_img/ani_back.gif" hspace=1 width=44 height=20 align="left"></a>&nbsp;Bursaries
Received From&nbsp;<input name="txtFrom" id="txtFrom" class="tcal" type="text" value="<?php echo $sdate;?>" readonly size=9> &nbsp;To&nbsp; <input name="txtTo" id="txtTo" class="tcal"
type="text" value="<?php echo $edate;?>" readonly size=9>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name="Show">Show Bursaries</button></form></div></br>
<div class="container" style="background-color:#f6f6f6;width:fit-content;margin:5px margin;"><div class="form-row">
<div class="col-md-12 divlrborder" id="showBursary">
<form name="frmFindBurs" id="frmFindBurs">Find Bursary By <Input type="radio" name="radFind" id="radBursNo" value="bursno" onclick="clrFind()">Bursary No. &nbsp;<Input type="radio"
name="radFind" id="radRecNo" value="recno" onclick="clrFind()">Receipt &nbsp;<Input type="radio" name="radFind" id="radName" value="sourcename" checked onclick="clrFind()">Name
&nbsp;&nbsp;<input type="text" maxlength="10" size="15" id="txtFind" name="txtFind" value="" onkeyup="findBurs(this)" placeholder="Type data to find">&nbsp;&nbsp; OR &nbsp; <button
name="btnNew" id="btnNew" type="button" onclick="addNew()" "<?php echo ($add==1?"":"disabled");?>" class="btn btn-primary btn-md">New Bursary</button>
<a href="pupil_manager.php" style="color:#f00;background:inherit;font-size:1.5rem;font-weight:bold;border:0px;float:right;" title="Close">&times;</a></form>
<div class="form-row">
  <div class="col-md-12" id="dispBursary" style="background-color:inherit;max-height:350px;overflow-y:scroll;display:block;padding:3px;">
  <?php
      $sdate=preg_split("/\-/",$sdate); 	$sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];
      $edate=preg_split("/\-/",$edate); 	$edate=$edate[2].'-'.$edate[1].'-'.$edate[0];
      if (isset($_POST["Show"])){
          $h= "Bursaries Received Between <font color=\"#0000ff\">".date("D d-M-Y",strtotime($sdate))."</font> And <font color=\"#0000ff\">".date("D d-M-Y",strtotime($edate))."</font>";
          print "<h6>".strtoupper($h)."</h6></center>";
          $sql="SELECT b.BursNo,if(isnull(f.recno),'--',f.recno) as recieptno,b.pytdate,b.sourcename,b.pytfrm,b.cheno,b.Amt,concat(ba.descr,' (',b.branch,')') as banks FROM acc_burs b
          LEFT JOIN acc_banks ba on (b.bankno=ba.sNo) LEFT JOIN (SELECT f.recno,substring(i.admno,(locate('-',i.admno)+1)) as bursno FROM acc_incorecno0 f Inner Join acc_incofee i USING
          (sno) WHERE f.markdel=0 and i.admno LIKE 'Burs%')f USING (bursno) WHERE (b.pytdate BETWEEN '$sdate' AND '$edate') and b.markdel=0 and b.status=0 Order By b.bursno Desc";
      }else $sql="SELECT b.BursNo,if(isnull(f.recno),'',f.recno) as recieptno,b.pytdate, b.sourcename,b.pytfrm,b.cheno,b.Amt,concat(ba.descr,' (',b.branch,')') as banks FROM acc_burs b
      INNER JOIN acc_banks ba on (b.bankno=ba.sNo) LEFT JOIN (SELECT f.recno,substring(i.admno,(locate('-',i.admno)+1)) as bursno FROM acc_incorecno0 f Inner Join acc_incofee i USING (sno)
      WHERE f.markdel=0 and i.admno LIKE 'Burs%')f USING (bursno) WHERE b.markdel=0 and b.status=0 Order By b.bursno Desc";
      $rs=mysqli_query($conn,$sql);
      print "<table id=\"tabBursary\" class=\"table table-hover table-sm table-stripped table-bordered\"><thead class=\"thead-dark\"><tr><th>#</th><th>Receipt</th>
      <th>Received On</th><th>Source Name</th><th>Amount</th><th>Beneficiary</th><th>Printouts</th><th>Edit</th></tr></thead><tbody>";
      $i=0;	$ttl=0; $bursary='';
      if (mysqli_num_rows($rs)>0):
          while (list($bn,$rec,$da,$sn,$mode,$ch,$am,$ban)=mysqli_fetch_row($rs)): $random=mt_rand();
              print "<tr><td>$bn</td><td>$rec</td><td>".date("D d M,Y",strtotime($da))."</td><td>$sn, $ban, $mode NO. $ch</td><td align=\"right\">".number_format($am,
              2)."</td><td align=\"center\" valign=\"middle\"><a href=\"#\" onclick=\"showBursBenef($bn)\">View</a></td><td align=\"center\" valign=\"middle\"><a target=\"_BLANK\"
              href=\"pdf/bursackletter.php?action=$bn-$random\" onclick=\"return canview($viu);\">Acknowledgement</a>".($rec>0?"<br><a
              href=\"rpts/bursaryrecpv.php?recno=$bn-1-$random\" target=\"_BLANK\">Receipt &amp; PV</a>":"")."</td><td align=\"center\" valign=\"middle\"><a href=\"bursaryedit.php?bno=$bn\"
              onclick=\"return canEdit($edi);\">Edit</a></td></tr>"; 	$ttl+=$am;  	$i++;
          endwhile;
      else:
          print "<tr><td colspan=\"8\">No bursaries were received between ".date("D d-M-Y",strtotime($sdate))." and ".date("D d-M-Y",strtotime($edate))."</td></tr>";
      endif;
      print "</tbody><tfoot class=\"thead-light\"><tr><td colspan=3><span id=\"spBursNo\" style=\"font-weight:bold;\">".mysqli_num_rows($rs)." Bursary Record(s)</span>
      </td><td align=\"right\"><b>Subtotal Kshs.</b></td><td align=\"right\"><span id=\"spBursTtl\" style=\"font-weight:bold;\">".number_format($ttl,2)."</span></td><td colspan=\"3\">
      </td></tr></tfoot></table>";
    mysqli_free_result($rs);
?></div></div>
</div></div><hr>
<div class="form-row"><div class="col-md-12 divlrborder" id="spShowBeneficiary">
  <div class="form-row"><div class="col-md-12">
	<form name="frmFindBenef" method="post" action="#" style="font-weight:bold;">Find Beneficiary By <input type="radio" checked name="radFind" id="radAdm" onclick="clrText1()">
	Adm. No. <input type="radio" name="radFind" id="radName1" onclick="clrText1()">Names <input type="radio" name="radFind" id="radFrm" onclick="clrText1()">Class <input type="text"
	name="txtFind1" id="txtFind1" size=30 value="" placehoder="Type what to find here" onkeyup="findStudent(this)"></form></div></div><hr>
  <div class="form-row"><div class="col-md-12" id="spBursaryBenef" style="max-height:300px;overflow-y:scroll;"><span style="letter-spacing:2px;word-spacing:3px;color:#00a;
  font-weight:bold;font-size:0.9rem;">BENEFICIARIES OF SELECTED BURSARY</span><table id="tabStudents" class="table table-hover table-sm table-stripped
  table-bordered"><thead class="thead-dark"><tr class="nohover"><th>Receipt No.</th><th>Date</th><th>Adm. No.</th><th>Student Names</th><th>Form</th><th>Amount</th></tr></thead>
  <tbody>
	<?php
		$rsBen=mysqli_query($conn,"SELECT f.recno,f.pytdate,s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,f.ttl FROM stud s INNER JOIN class c
		USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN (SELECT f.recno,i.pytdate,i.bursno,i.admno,((f.amt-f.refunds-f.transfer)+If(isnull(m.amt),0, m.amt)) AS
		TTL FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) LEFT JOIN (SELECT sno,(amt-transfer) as amt FROM acc_incorecno1 m WHERE markdel=0)m ON (i.sno=m.sno) WHERE
		i.markdel=0 AND i.bursno IN (SELECT * FROM (SELECT bursno FROM acc_burs WHERE markdel=0 ORDER BY bursno DESC Limit 0,1)b))f ON s.admno= f.admno ORDER BY f.recno,s.surname,
		s.onames ASC");	$nben=mysqli_num_rows($rsBen);
		$bttl=0;
		if ($nben>0):
			while (list($brn,$dt,$ad,$bsn,$bfr,$btt)=mysqli_fetch_row($rsBen)):
				print "<tr><td>$brn</td><td align=\"right\">".date("D d M, Y",strtotime($dt))."</td><td>$ad</td><td>$bsn</td><td>$bfr</td><td align=\"right\">".number_format($btt,2)."</td>
				</tr>";		$bttl+=$btt;
			endwhile;
		else:
			print "<td colspan=6 style=\"font-size:12pt;font-weight:bold;letter-spacing:4px;word-spacing:6px;color:#f00;\">This bursary has not been distributed to beneficiaries</td></tr>";
		endif;
		print "</tbody><tfoot class=\"thead-light\"><tr><td colspan=3><span id=\"spNoStud\">$nben Bursary Beneficiaries</span></td><td align=\"right\" colspan=2><b>Subtotals</td><td
    align=\"right\"><span	id=\"spTtl\">".number_format($bttl,2)."</span></td></tr></tfoot>";
		mysqli_free_result($rsBen);
	?></table></div></div>
  <br><div class="form-row"><div class="col-md-12" style="text-align:right;"><img onclick="printSpecific()" src="/gen_img/print.ico" height=20 width=30 title="Print List"></div>
  </div>
</div></div></div></div>
<div id="bursaryAdd" class="modal">
	<form class="modal-content animate" method="post" action="bursary.php" name="frmBursary" onsubmit="return validateData(this);"><input type="hidden" name="txtBurs" id="txtBurs"
	value="<?php echo "$bursRec-$bursType-$bursVote";?>">
	<div class="imgcontainer"><span onclick="document.getElementById('bursaryAdd').style.display='none'" class="close" title="Close">&times;</span></div><br/>
	<div class="container divmodalmain">
		<div class="form-row"><div class="col-md-12 divheadings">REGISTRATION OF NEW BURSARY</div>
    </div><div class="form-row"><input type="hidden" name="txtUniqueId" id="txtUniqueId" size=7 value="<?php echo $frm_token;?>">
      <div class="col-md-4"><label for="txtBursNo">Bursary No. </label><input type="text" name="txtBursNo" id="txtBursNo" type="text" value="<?php echo $bursno;?>"
      readonly class="modalinput"></div>
      <div class="col-md-4"></div>
      <div class="col-md-4"><label for="txtReceivedOn">Received On</label><input type="text" name="txtReceivedOn" id="txtReceivedOn" class="tcal" readonly value="<?php
      echo date('d-m-Y',strtotime($edate));?>"></div>
    </div><div class="form-row">
      <div class="col-md-12"><label for="txtName">Bursary Name *</label><input type="text" type="text" name="txtName" id="txtName" maxlength=40 placeholder="NG CDF" value=""
      class="modalinput" required onkeyup="checkName(this)"></div>
    </div><div class="form-row">
      <div class="col-md-4"><label for="txtPO">P.O Box *</label><input type="text" name="txtPO" id="txtPO" class="modalinput" maxlength=5 value="" placeholder="440"
		      onkeyup="checkInput(this,1)" required></div>
      <div class="col-md-4"><label for="txtPOCode">Postal Code</label><input type="text" name="txtPOCode" id="txtPOCode" class="modalinput" maxlength=6 value="" placeholder="50406"
        onkeyup="checkInput(this,1)"></div>
      <div class="col-md-4"><label for="txtTown">Town/City *</label><input type="text" name="txtTown" id="txtTown" class="modalinput" maxlength=25 value="" placeholder="Mumias"
        required></div>
    </div><div class="form-row">
      <div class="col-md-4"><label for="cboMode">Received In *</label><Select name="cboMode" id="cboMode" size=1 class="modalinput"><option selected>Cheque</option><option>
        Direct Banking</option><option>M-Fees</option></SELECT></div>
      <div class="col-md-4"><label for="txtModeNo">Trans/ Cheque No. *</label><input type="text" type="text" name="txtModeNo" id="txtModeNo" class="modalinput" maxlength=15
		     required value="" placeholder="0001245"></div>
      <div class="col-md-4"><label for="cboBank">Banker (If received in Cheque)</label><SELECT name="cboBank" id="cboBank" size=1 class="modalinput"><option value="0" selected>
        None</Option><?php $rs=mysqli_query($conn,"SELECT sno,`descr` FROM acc_banks WHERE markdel=0 ORDER BY `descr`");
  		  while($d=mysqli_fetch_row($rs))  echo "<option value=\"$d[0]\">$d[1]</option>"; mysqli_free_result($rs);?></select></div>
    </div><div class="form-row">
      <div class="col-md-4"><label for="txtBranch">Bank Branch *</label><input type="text" name="txtBranch" id="txtBranch" class="modalinput" maxlength=25 value=""
        placeholder="Mumias"></div>
      <div class="col-md-4"><label for="txtAmt">Amount Received *</label><input type="text" name="txtAmt" id="txtAmt" class="modalinput numbersinput" maxlength=10 value=""
        placeholder="0.00" onkeyup="checkInput(this,0)" required></div>
      <div class="col-md-4"><label for="txtAck">Acknowledgement Addressee *</label><input type="text" name="txtAck" id="txtAck" class="modalinput" maxlength=20 value=""
        required placeholder="The Chairperson"></div>
      </div><hr><div class="form-row">
        <div class="col-md-6"><button type="submit" class="btn btn-block btn-primary btn-md" name="btnSave" id="btnSave">Save New Bursary Details</button></div>
        <div class="col-md-6" style="text-align:right;"><button type="button" onclick="document.getElementById('bursaryAdd').style.display='none'" class="btn btn-md btn-info
          disabled">Cancel/ Close</button></div>
      </div>
	</div></form>
</div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/bursary.js"></script>
<?php mysqli_close($conn); footer(); ?>
