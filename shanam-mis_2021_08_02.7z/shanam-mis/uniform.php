<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $act=preg_split('/\-/',$act);
    $un=$_SESSION['username'];
    mysqli_multi_query($conn,"SELECT struview,struadd,struedit,strudel FROM acc_priv Where Uname LIKE '$un';SELECT finyr FROM ss; SELECT v.sno,v.acc,a.abbr FROM acc_votes v Inner
    Join acc_voteacs a On (v.acc=a.acno) WHERE v.abbr LIKE 'uniform%';");
    $vie=$add=$edi=$del=$unifv=0; $finyr=date("Y"); $i=0; $acc=1; $accname='';
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0) list($vie,$add,$edi,$del)=mysqli_fetch_row($rs);
            elseif($i==1) list($finyr)=mysqli_fetch_row($rs);
            else{if (mysqli_num_rows($rs)>0) list($unifv,$acc,$accname)=mysqli_fetch_row($rs);
            } mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
    if($vie==0){ header("location:vague.php"); exit(0);}
    if (isset($_POST['CmdAdd']) || isset($_POST['cmdSaveEdit'])){
        if(isset($_POST['CmdAdd'])){
            $unifrm=isset($_POST['txtUnifrm'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtUnifrm']))):"";
            $amt=isset($_POST['txtPrice'])?sanitize($_POST['txtPrice']):0;	$unitsale=isset($_POST['cboUnitSale'])?sanitize($_POST['cboUnitSale']):"0";
            $amt=preg_replace('/[^0-9^\.]/','',$amt); $adb=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
            $sql="INSERT INTO uniforms (uname,unitsale,amt,addedby) VALUES (".var_export($unifrm,true).",'$unitsale','$amt','$adb')";
        }else{
            $unifrm=strlen(trim(strip_tags($_POST['txtUnifrm1'])))>0?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtUnifrm1']))):"";
            $amt=strlen(trim(strip_tags($_POST['txtPrice1'])))>0?sanitize($_POST['txtPrice1']):0; $unitsale=isset($_POST['cboUnits1'])?sanitize($_POST['cboUnits1']):0;
            $no=isset($_POST['txtUniNo1'])?sanitize($_POST['txtUniNo1']):-1;	$amt=preg_replace('/[^0-9^\.]/','',$amt);
            $sql="UPDATE uniforms SET uname=".var_export($unifrm,true).",unitsale='$unitsale',amt=$amt WHERE unifrmno LIKE '$no'";
        }
        if (strlen($unifrm)>4 && $amt>0 && strcasecmp($unitsale,"0")!=0){
            mysqli_query($conn,$sql) or die(mysqli_error($conn)." uniform details not saved. Click <a href=\"uniform.php\">here</a> to go back.");
            $act[1]=mysqli_affected_rows($conn);
        }else{
            print "<font size=\"+2\" color=\"#f66\">Ensure uniform description and unit price are validly entered before saving</font>";
            $act[1]=0;
        } $act[0]=1;
    }elseif(isset($_POST['btnDelete'])){
        $no=isset($_POST['txtUniNo1'])?sanitize($_POST['txtUniNo1']):-1;
        if ($no>-1){
            mysqli_query($conn,"UPDATE uniforms SET markdel=1 WHERE unifrmno LIKE '$no'"); $act[1]=mysqli_affected_rows($conn);
        }else $act[1]=0;
        $act[0]=2;
    } headings('<link rel="stylesheet" href="/date/tcal.css" type="text/css"/><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet"
    href="tpl/css/inputsettings.css" type="text/css"/>',$act[0], $act[1], 2);
?>
<div class="container" style="background-color:#e6e6e6;">
<h3 style="border:#0a6;border-radius:20px 20px 0 0;letter-spacing:4px;word-spacing:8px;background-color:#55f;color:#fff;padding:5px;">SCHOOL UNIFORM MANAGER</h3>
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#divOrders" role="tab" aria-controls="fee" aria-selected="true">PURCHASES</a></li>
    <li class="nav-item"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#divPrices" role="tab" aria-controls="votes" aria-selected="false">UNIT PRICES</a></li>
    <li class="nav-item"><a class="nav-link" id="rpt-tab" data-toggle="tab" href="#divRpt" role="tab" aria-controls="rpt" aria-selected="false">UNIFORM REPORTS</a></li>
</ul><br>
<div class="tab-content" id="myTabContent">
    <div class="tab-pane fade show active" id="divOrders" role="tabpanel" aria-labelledby="home-tab" style="border:0.5px dotted blue;border-radius:10px;padding:5px 0;">
        <div class="container">
        <div class="form-row"><div class="col-md-6 divlrborder">
        <form method="post" name="frmNewOrder" action="unifrmpurch.php" onsumit="return newOrder()"><input name="txtVote" id="txtVote" type="hidden" value="<?php print "$finyr-$unifv-$acc";?>">
        <div class="form-row"><div class="col-md-7"><?php echo ($unifv>0)?('UNIFORM ORDER FOR ADM. NO.<input name="txtFindAdm" id="txtFindAdm" onkeyup="findStud(0,this)" value="" type="text"
            maxlength="7" placeholder="Type Adm. No. Here" size="12">'):'<h4 style="color:#f66">THERE IS NO UNIFORM VOTE HEAD IN THE SYSTEM</h4>';?></div><div class="col-md-5"><button
            type="submit"  name="btnNewOrder" id="btnNewOrder" disabled>New Uniform Order</button></div>
        </div><div class="form-row">
            <div class="col-md-12" id="spStud"><br><hr>UNIFORM ORDERS BY ALL STUDENTS <input  name="txtAdmNo" id="txtAdmNo" type="hidden" value=""></div>
        </div></form>
        <div class="form-row"><div class="col-md-12" id="spOrders" style="max-height:420px;overflow-y:scroll;">
            <table id="myTable" class="table table-striped table-hover table-sm table-bordered"><thead class="thead-dark"><tr><th>Purchased On</th><th>Adm No.</th><th>Name</th><th>
            Class</th><th>Amount</th><th colspan=2>Admin Action</th></tr></thead><tbody>
            <?php
                $rsUni=mysqli_query($conn,"SELECT s.admno,concat(s.surname,' ',s.onames) as nam, concat(cn.clsname,' ',c.stream) as cls,up.purchno,up.purchasedon,u.price,up.clrd FROM stud s
                Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) Inner Join unifrmpurchase up On (s.admno=up.admno) Inner Join (SELECT pd.purchno,sum(u.amt*
                pd.qty) as price FROM unipurchdetails pd Inner Join uniforms u USING (unifrmno) GROUP BY pd.purchno,pd.markdel HAVING pd.markdel=0)u On (up.purchno=u.purchno) WHERE up.markdel=0
                Order By purchno DESC");
                $i=mysqli_num_rows($rsUni); $a=1; $ttl=0;
                while (list($adm,$nam,$cls,$purchno,$date,$amt,$clrd)=mysqli_fetch_row($rsUni)){
                    $diff=(strtotime(date('Y-m-d'))-strtotime($date))/86400;
                    echo "<tr><td align=\"right\">".date('d M, Y',strtotime($date))."</td><td>$adm</td><td>$nam</td><td>$cls</td><td align=\"right\">".number_format($amt,2)."</td><td
                    align=\"center\"><a href=\"#\" onclick=\"findStud(1,$purchno)\">View</a></td><td align=\"center\">".(($diff<2 && $clrd==0 && $edi==1)?"<a
                    href=\"unifrmpurch.php?admno=0-0-$purchno\">Edit</a>":"-")."</td></tr>"; $a++;	$ttl+=$amt;
                }
                echo "</tbody><tfoot class=\"thead-light\"><tr class=\"nohover\" style=\"font-weight:bold;\"><td colspan=\"2\"><span id=\"spNoU\">$i Uniform Item(s)</td><td
                align=\"right\" colspan=\"2\"><b>Total Amount</b></td><td align=\"right\"><span id=\"spSubTtl\" >".
                number_format($ttl,2)."</span></td><td colspan=\"2\"></td></tr></tfoot></table>";
            ?>
        </div></div>
      </div><div class="col-md-6 divlrborder">
        <div class="form-row"><div class="col-md-12" id="spListUniform">Details of Order</div></div>
        <div class="form-row"><div class="col-md-12" style="text-align:right"><hr><a href="#" onclick="printSpecific('spListUniform')" style="float:right;display:none;" id="printOrders"><img
        src="/gen_img/print.ico" height=20 width=30 alt="Print Report">Print Report</a></div></div>
      </div></div></div>
    </div>
    <div class="tab-pane fade show" id="divPrices" role="tabpanel" aria-labelledby="home-tab" style="border:0.2px dotted blue;border-radius:10px;background-color:#e6e6f6;padding:6px;">
        <div class="container">
        <div class="form-row"><div class="col-md-4 divlrborder">
            <form Action="uniform.php" name="Adding" Method="POST" onsubmit="return validateFormOnSubmit(0,this)">
            <div class="form-row"><div class="col-md-12 divheadings">NEW UNIFORM DEFINITION</div>
            </div><div class="form-row">
                <div class="col-md-12"><label for="txtUnifrm">Uniform Description *</label><input class="form-control" type="text" name="txtUnifrm" id="txtUnifrm" value="" maxlength="20"
                required></div>
            </div><div class="form-row">
                <div class="col-md-12"><label for="txtPrice">Unit Price *</label><input class="form-control"  type="text" name="txtPrice" id="txtPrice" maxlength=10 value="0.00"></div>
            </div><div class="form-row">
                <div class="col-md-12"><label for="cboUnitSale">Unit of Sale *</label><SELECT name="cboUnitSale" size="1"  class="form-control"><option>Pair</option><option selected>Piece
                    </option><option>Set</option></select>
                </div>
            </div><br><hr><div class="form-row">
                <div class="col-md-12" style="text-align:center;"><button class="btn btn-primary btn-md" name="CmdAdd" <?php echo ($add==1?" ":"disabled");?>>Save Uniform Details</button>
                </div>
            </div></form>
        </div><div class="col-md-7 divlrborder">
            <?php
                $rsUni=mysqli_query($conn,"SELECT unifrmno,uname,unitsale,amt  FROM uniforms WHERE markdel=0 Order By uname ASC");
                print "<table class=\"table table-striped table-hover table-sm table-bordered\"><thead class=\"thead-dark\"><tr><th>S/No.</th><th>Uniform Description</th><th>Unit of Sale</th><th>Unit Price"
                . "</th><th>Admin Action</th></tr></thead><tbody>";
                $rsUni=mysqli_query($conn,"SELECT unifrmno,uname,unitsale,amt FROM uniforms WHERE markdel=0");
                $i=mysqli_num_rows($rsUni); $a=1; $listUni='';
                if ($i>0) while (list($unino,$uniname,$unisale,$uniamt)=mysqli_fetch_row($rsUni)){
                    print "<tr><td>$a</td><td>$uniname</td><td>$unisale</td><td align=\"right\">".number_format($uniamt,2)."</td><td align=\"center\">".($edi==1?"<a href=\"#\"
                    onclick=\"editUniform($unino)\">Edit</a>":"-")."</td></tr>";  $listUni.=($a==1?"":",")."new Uniform($unino,\"$uniname\",\"$unisale\",$uniamt)";
                    $a++;
                }print "</thbody><tfoot class=\"thead-dark\"><tr><td colspan=\"7\" style=\"letter-spacing:6px;word-spacing:9px;font-weight:bold;\">$i Uniform Item(s)</td></tr></tfoot></table></td></tr></table>";
            ?>
        </div></div></div>
    </div>
    <div class="tab-pane fade show" id="divRpt" role="tabpanel" aria-labelledby="rpt-tab" style="border:0.5px dotted blue;border-radius:10px;background-color:#e6e6f6;padding:5px 0;">
        <form name="frmOrderRPT" method="get" action="unifrm.php">
        <div class="form-row" style="margin:1px;">
            <div class="col-md-9 divlrborder">
                Uniform Purchases Between <Input type="text" name="txtFrom" id="txtFrom" class="tcal" size="8" value="<?php echo date('d-m-Y',strtotime('-30days')); ?>">  and <Input
                type="text" name="txtTo" id="txtTo" class="tcal" size="8" value="<?php echo date('d-m-Y');?>">
                <button type="button" name="btnOrdersRpt" id="btnOrdersRpt" onclick="rptOrders(1)" class="btn btn-info btn-sm">Uniform<br>Purchases</button>&nbsp;&nbsp;or&nbsp;&nbsp;
                <button type="button" name="btnUniFeeRecRpt" id="btnUniFeeRecRpt" onclick="rptOrders(2)" class="btn btn-info btn-sm">Uniform<br>Fee Receipts</button>
            </div>
            <div class="col-md-3 divlrborder">
                <button type="button" name="btnOrdersDebtRpt" id="btnOrdersDebtRpt" onclick="rptOrders(3)"  class="btn btn-info btn-sm">Uniform<br>Debtors</button> &nbsp;
                <button type="button" name="btnOrdersRpt" id="btnOrdersRpt" onclick="rptOrders(4)"  class="btn btn-info btn-sm">List of<br>Uniforms</button>
            </div>
        </div></form><hr><div class="form-row" style="margin:1px;">
          <div class="col-md-12" style="max-height:500px;overflow-y:scroll;" id="divUniRpt"></div>
        </div>
        <div class="form-row" style="margin:1px;">
          <div class="col-md-12" style="text-align:center;margin:1px;"><a href="#" onclick="printSpecific('divUniRpt')" style="float:right;display:none;" id="printH"><img height=20
          src="/gen_img/print.ico" width=30 alt="Print Report">Print Report</a></div>
        </div>
    </div>
    <div class="row"><div class="col-md-12" style="text-align:right;"><hr><a href="pupil_manager.php"><button name="close" type="button">Close Interface</button></a></div></div>
</div>
<div id="divEditPrice" class="modal">
    <form action="uniform.php" Method="Post" name="frmUnifrmEdit" onsubmit="return validateFormOnSubmit1(1,this)">
    <div class="imgcontainer"><span onclick="document.getElementById('divEditPrice').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
    <div class="container divmodalmain" style="font-size:12pt;color:#fff;"><input type="hidden" name="txtUniNo1" id="txtUniNo1" value="">
      <div class="form-row">
          <div class="col-md-12"><label for="txtUnifrm1">Uniform Description *</label><input type="text" name="txtUnifrm1" id="txtUnifrm1" value="" maxlength="20" class="modalinput"></div>
      </div><div class="form-row">
          <div class="col-md-12"><label for="txtPrice1">Unit Price *</label><input type="text" name="txtPrice1" id="txtPrice1"	maxlength="10" class="modalinput" value=""></div>
      </div><div class="form-row">
          <div class="col-md-12"><label for="cboUnits1">Unit of Sale *</label><SELECT name="cboUnits1" id="cboUnits1" size="1" class="modalinput"><option value="Pair">Pair</option>
          <option value="Piece">Piece</option><option value="Set">Set</option></select></div>
      </div><br><hr><div class="form-row">
          <div class="col-md-4"><button type="submit" name="cmdSaveEdit" class="btn btn-primary btn-md btn-block">Save Uniform</button></div>
          <div class="col-md-4" style="text-align:right;"><button type="submit" class="btn btn-info btn-md disabled" name="btnDelete" <?php print ($del==0?"disabled":
          "onclick=\"return delConfirm()\"");?>>Delete Uniform</button></div>
          <div class="col-md-4" style="text-align:right;"><button type="button" onclick="document.getElementById('divEditPrice').style.display='none'" class="btn btn-info btn-md disabled">
            Cancel/ Close</button></div>
      </div></div>
</div>
<script type="text/javascript" src="tpl/js/unifrm.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript"><?php if(strlen($listUni)>0) print "uniform.push($listUni);";?></script>
<script type="text/javascript" src="tpl/printthis.js"></script>
<?php mysqli_close($conn); footer(); ?>
