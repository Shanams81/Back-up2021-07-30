<?php
	declare(strict_types=1); 	include_once('shanam.php');
	class Credits{
		private $vno,$vname,$amt,$budg,$yr;
		public function __construct($vn,$na,$am,$bu,$y){$this->vno=$vn; $this->vname=$na;	$this->amt=$am;	$this->budg=$bu; $this->yr=$y;}
		public function valVoteNo(){return $this->vno;}		public function valName(){return $this->vname;} 	public function valYear(){return $this->yr;}
		public function valAmt(){return $this->amt;}			public function valBudget(){return $this->budg;}
	}	class Voteheads{
		private $vno,$yr,$cost,$inco;
		public function __construct($v,$y,$c,$i){$this->vno=$v;	$this->yr=$y;	$this->cost=$c;	$this->inco=$i;}
		public function valVoteNo(){return $this->vno;}		public function valYear(){return $this->yr;}
		public function valCost(){return $this->cost;}		public function valIncome(){return $this->inco;}
	}class CreditDet{
		private $detno,$voteno,$amt; public function __construct($no,$v,$am){$this->detno=$no; $this->voteno=$v; $this->amt=$am;} public function valDetNo(){return $this->detno;}
		public function valAmt(){return $this->amt;}	public function valVoteNo(){return $this->voteno;}
	} $usn=strtoupper($_SESSION['username'].' ('.$_SESSION['priviledge'].')');
	$rec=isset($_REQUEST['recno'])?sanitize($_REQUEST['recno']):'0-0'; $recno=explode('-',$rec); //[0]- Creditor No. [1] - Account
	if (isset($_POST['CmdSave'])){
		$info=isset($_POST['txtInfo'])?sanitize($_POST['txtInfo']):'0-0';		$info=explode('-',$info); //[0] -Creditor No. [1] -Account
		$tkn=isset($_POST['txtToken'])?sanitize($_POST['txtToken']):'000';	$vono=isset($_POST['txtVNo'])?sanitize($_POST['txtVNo']):1;
		$date=isset($_POST['txtDate'])?$_POST['txtDate']:date('Y-m-d'); 		$date=preg_split("/\-/",$date); $date="$date[2]-$date[1]-$date[0]";
		$bankac=isset($_POST['cboBankAC'])?sanitize($_POST['cboBankAC']):0;	$pytfrm=isset($_POST['cboPytFrm'])?sanitize($_POST['cboPytFrm']):'Cash';
		$cheno=isset($_POST['txtCheNo'])?sanitize($_POST['txtCheNo']):null; $cheno=strlen($cheno)>0?$cheno:null;				$bankac=strcasecmp($pytfrm,'cash')==0?null:$bankac;
		$cash=isset($_POST['txtCash'])?sanitize($_POST['txtCash']):0;				$cash=preg_replace("/[^0-9^\.]/","",$cash);
		$cheque=isset($_POST['txtCheque'])?sanitize($_POST['txtCheque']):0;	$cheque=preg_replace("/[^0-9^\.]/","",$cheque);
		$bal=isset($_POST['txtBalance'])?sanitize($_POST['txtBalance']):0;	$bal=preg_replace("/[^0-9^\.]/","",$bal);
		$nov=isset($_POST['txtNOV'])?sanitize($_POST['txtNOV']):0;					$nov=intval($nov);
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtRmks'])))):'BEING PAYMENT OF ';
		if ((($cash+$cheque)>0) && (strlen($rmks)>16 || strcasecmp("being payment of ",$rmks)!=0) && ($bal==0) && ($_SESSION['form_token']==$tkn) && ((strcasecmp($pytfrm,"cash")!=0 &&
		$bankac>0 && strlen($cheno)>0) || (strcasecmp($pytfrm,"cash")==0))) {
			unset($_SESSION['form_token']);
			$set=false; $i=1;
			while(!$set && ($i<8)){
				if (mysqli_query($conn,"INSERT INTO acc_exp(vono,acsno,pytdate,acc,pytfrm,cheno,commt,caamt,chamt,rmks,expno,addedby) VALUES ('$vono',".var_export($bankac,true).",'$date',
				'$info[1]','$pytfrm',".var_export($cheno,true).",1,'$cash','$cheque',".var_export($rmks,true).",'$info[0]','$usn')") or die(mysqli_error($conn).".	CommitmentPayment details
				were not saved. Click	<a	href=\"creditors.php\">Here</a> to try again.")) $set=true; else $vono++; 	$i++;
			}if($set){ $sql=''; //expenditure details were saved save votehead
				if($cash>0) $sql.="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES(0,'$info[1]',1,curdate(),'Commitment Payment',$cash,2,$vono,'$usn');";
				if($cheque>0) $sql.="INSERT acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,addedby) VALUES (0,curdate(),1,$bankac,'$cheno',$cheque,'Commitment Payment',
				1,$vono,'$usn');"; $ttl=$cash+$cheque;
				for ($i=0;$i<$nov;$i++){
					$amt=isset($_POST["txtAmount_$i"])?sanitize($_POST["txtAmount_$i"]):0; 			$amt=preg_replace('/[^0-9\.]/','',$amt);
					if($amt>0){
						$cred=isset($_POST["txtVoteDet_$i"])?sanitize($_POST["txtVoteDet_$i"]):'0-0-0';	$cred=explode('~',$cred); //Pairs of Creditor Details No. and AMOUNT
						foreach($cred as $det){
							$det=explode('-',$det); $vamt=floatval($det[1]); //[0] Creditor Details No. [0] Credit Amount
							if($ttl>0){
								if($vamt>$ttl){
									$sql.="UPDATE acc_creditorsdet SET amt=amt-$ttl WHERE detno LIKE '$det[0]'; INSERT INTO acc_creditordetpaid VALUES ('$det[0]',$vono,$info[1],$ttl);";	$ttl=0;
								}else{$sql.="UPDATE acc_creditorsdet SET amt=amt-$vamt WHERE detno LIKE '$det[0]'; INSERT INTO acc_creditordetpaid VALUES ('$det[0]',$vono,$info[1],$vamt);"; $ttl-=$vamt;}
							}
						}$vote=isset($_POST["txtVote_$i"])?sanitize($_POST["txtVote_$i"]):'0-0-0';	$vote=explode('-',$vote); //[0]-Vote No. [1]-A/C, [2]-Year
						if($vote>0 && $amt>0) $sql.="INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,$info[1],$vote[0],$amt);";
					}
				}mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Commitment Payment votehead details were not saved. Click <a href=\"creditors.php\">Here</a> to try again.</center>");
				while(mysqli_next_result($conn)){} 	header("location:rpts/commtpv.php?action=$vono-1-$info[0]-$info[1]");
			}
		}else{
			print "Sorry, the Commitment Payment details had errors.<br>Please ensure all details are correctly entered before saving.<br>Click <a href=\"creditors.php\">here</a> to try
			again."; unset($_SESSION['form_token']);
		}	exit(1);
	}else{
	 	$_SESSION['form_token']=$form_token=uniqid();
	 	mysqli_multi_query($conn,"SELECT c.idno,c.name,c.telno,c.paddress,c.email,group_concat(DISTINCT cd.rmks) as narr,ss.finyr FROM acc_creditors c Inner Join acc_creditorsdet cd USING
		(cred_no), ss WHERE c.markdel=0 and cd.markdel=0 and c.categ=0 and c.cred_No LIKE '$recno[0]'; SELECT c.voteno,v.expdescr,sum(c.amt) as tamt,if(isnull(sum(b.curest)),0,sum(b.curest))
		as budget,c.yr FROM acc_creditorsdet c Inner Join acc_votes v On (c.voteno=v.sno) LEFT Join (SELECT f.voteno,f.curest FROM acc_fyestimates f Inner Join ss s ON (f.finyr=s.finyr))b On
		(c.voteno=b.voteno) GROUP BY c.voteno,v.expdescr,c.yr,c.markdel,c.acc,c.cred_No HAVING sum(c.amt)>0 and c.markdel=0	and c.cred_No LIKE '$recno[0]' and c.acc LIKE '$recno[1]';
		SELECT descr FROM acc_voteacs WHERE acno LIKE	'$recno[1]'; SELECT max(vono) as nv FROM acc_exp GROUP BY acc HAVING acc='$recno[1]'; SELECT a.sno,concat(b.abbr,' - ',a.accno) as ac
		FROM acc_accounts a Inner Join  acc_banks b ON (a.bankno=b.sno) WHERE a.accacc LIKE '$recno[1]'; SELECT finyr FROM ss; SELECT v.sno as voteno,if(isnull(p.exp),0,p.exp) as cost,
		if(isnull(i.inco),0,i.inco) as income FROM acc_votes v	LEFT JOIN (SELECT voteno,sum(amt) as inco FROM ".($recno[1]<3?"acc_incovotes":"acc_fsevotes")."	GROUP BY markdel,acc,voteno
		HAVING markdel=0 and acc LIKE '$recno[1]')i ON (v.sno=i.voteno) LEFT JOIN (SELECT voteno,sum(amt) as exp FROM acc_pytvotes GROUP BY markdel,acc,voteno HAVING markdel=0 and acc LIKE
		'$recno[1]')p ON (v.sno=p.voteno) WHERE v.acc LIKE '$recno[1]' and v.sno IN (SELECT voteno FROM acc_creditorsdet	WHERE amt>0 and markdel=0	and cred_No LIKE '$recno[0]'and acc LIKE
		'$recno[1]') Order By v.sno ASC; SELECT v.sno,a.arr_year,if(isnull(p.exp),0,p.exp) as cost,a.inco FROM acc_votes v INNER JOIN (SELECT arr_year,ac,sum(amt) as inco FROM acc_arrrefclr
		GROUP BY arr_year,ac,transtype,markdel HAVING	transtype=0 and MarkDel=0)a on (v.acc=a.ac) LEFT JOIN (SELECT voteno,sum(amt) as exp FROM acc_pytvotes GROUP BY markdel,acc,voteno HAVING
		markdel=0 and acc LIKE '$recno[1]')p ON	(v.sno=p.voteno) WHERE markdel=0 and expabbr LIKE '%sundry%'	ORDER BY a.arr_year,v.expabbr ASC; SELECT detno,voteno,amt FROM acc_creditorsdet
		WHERE	amt>0 and markdel=0 and cred_No LIKE '$recno[0]' and acc LIKE '$recno[1]' and isnull(admno) ORDER BY voteno,detno ASC; SELECT a.acsno,(a.bankbalbf+if(isnull(b.bal),0,b.bal))
    as amt FROM acc_acbalbf a Inner Join acc_accounts c ON (a.acsno=c.sno) Left Join (SELECT acsno,sum(if(bank_type=0,amt,0)-if(bank_type=1,amt,0)) as bal FROM `acc_banking` Group
    By markdel,acsno HAVING markdel=0)b USING (acsno) WHERE c.accacc LIKE '$recno[1]'; SELECT (a.cashbalbf+if(isnull(b.dr),0,b.dr)) as amt FROM acc_votebalbf a Left Join (SELECT acc,
		sum(if(cftype=0,amt,0)-if(cftype=1,amt,0)) as dr FROM `acc_cashflow` GROUP BY acc,markdel HAVING markdel=0 and acc LIKE	'$recno[1]')b USING (acc) WHERE a.acc LIKE '$recno[1]';");
		$cashbal=$credbal=$vono=$i=0; $optbank="<option value=\"\" Selected>Choose A/C</option>"; $bankbal='';
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){$cred=mysqli_fetch_row($rs);
				}elseif($i===1){while($dat=mysqli_fetch_row($rs)) $credits[]=new Credits($dat[0],$dat[1],floatval($dat[2]),floatval($dat[3]),$dat[4]);
				}elseif($i===2){list($accname)=mysqli_fetch_row($rs);
				}elseif($i===3){if(mysqli_num_rows($rs)>0) list($vono)=mysqli_fetch_row($rs);
				}elseif($i===4){while($dat=mysqli_fetch_row($rs)) $optbank.="<option value=\"$dat[0]\">$dat[1]</option>";
				}elseif($i===5){list($finyr)=mysqli_fetch_row($rs);
				}elseif($i===6){while ($d=mysqli_fetch_row($rs)) $voteheads[]=new Voteheads($d[0],$cred[6],floatval($d[1]),floatval($d[2]));
				}elseif($i===7){while ($d=mysqli_fetch_row($rs)) $sundry[]=new Voteheads($d[0],$d[1],floatval($d[2]),floatval($d[3]));
				}elseif($i===8){while ($d=mysqli_fetch_row($rs)){$creditdet[]=new CreditDet($d[0],intval($d[1]),floatval($d[2])); $credbal+=floatval($d[2]);}
				}elseif($i===9){$a=0; while ($d=mysqli_fetch_row($rs)){$bankbal.=($a==0?"":",")."new BankBal($d[0],$d[1])"; $a++;}
				}else{if(mysqli_num_rows($rs)>0) list($cashbal)=mysqli_fetch_row($rs);}mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn)); $vono++;
	} headings('<link rel="stylesheet" href="/date/tcal.css"><link rel="stylesheet" href="tpl/css/inputsettings.css">',0,0,2);
?>
<div class="container divmain"><form method="post" action="creditorpv.php" onsubmit="return validateFormOnSubmit(this);" name="FrmPettyPyts">
	<input type="hidden" name="txtToken" value="<?php echo $form_token;?>"><input type="hidden" name="txtInfo" value="<?php echo "$recno[0]-$recno[1]";?>">
	<div class="form-row"><div class="col-md-12 divsubheading">COMMITMENT PAYMENTS TO A CREDITOR</div></div>
	<div class="form-row">
		<div class="col-md-2"><label for="txtVNo">Voucher No.</label><input type="text" name="txtVNo" id="txtVNo" class="modalinput" maxlength="4" readonly placeholder="Auto"
			value="<?php echo $vono;?>"></div>
		<div class="col-md-7" STYLE="text-align:center;font-weight:bold"><BR><?php echo $accname; ?></div>
		<div class="col-md-3"><label for="txtDate">Paid On</label><INPUT name="txtDate" id="txtDate" class="tcal modalinput" maxlength="10" readonly value="<?php
		echo date('d-m-Y');?>"></div>
	</div><div class="form-row"><div class="col-md-12 divlrborder" style="background-color:#40a8c4;">
		<div class="form-row">
			<div class="col-md-2"><label for="txtCredNo">Creditor's No.</label><input type="text" name="txtCredNo" id="txtCredNo" class="modalinput" maxlength="10" value="<?php echo $recno[0];?>"
				placeholder="0000000"	readonly></div>
			<div class="col-md-7"><label for="txtPayee">Name of Payee</label><input type="text" name="txtPayee" id="txtPayee" class="modalinput" maxlength="40" placeholder="Namatsi"
				value="<?php echo $cred[1];?>" readOnly></div>
			<div class="col-md-3"><label for="txtTelNo">Tel. No.</label><input type="text"	name="txtTelNo" id="txtTelNo" class="modalinput" maxlength="13" placeholder="0712609945"
				value="<?php echo $cred[2];?>" readOnly></div>
		</div><div class="form-row">
			<div class="col-md-2"><label for="txtIDNo">ID No.</label><input type="text" name="txtIDNo" id="txtIDNo" class="modalinput" maxlength="10" value="<?php echo $cred[0];?>"
					placeholder="0000000"	readonly></div>
			<div class="col-md-7"><label for="txtAddress">Address of Payee</label><input type="text" name="txtAddress" id="txtAddress" class="modalinput" value="<?php echo $cred[3];?>"
				readOnly></div>
			<div class="col-md-3"><label for="txtEMail">E - Mail Address</label><input type="text" name="txtEMail" id="txtEMail" class="modalinput" maxlength="50" readOnly
				placeholder="someone@somewebsite.com" value="<?php echo $cred[4];?>" style="text-transform:lowercase"></div>
		</div>
	</div></div>
	<div class="form-row">
		<div class="col-md-2"><label for="cboPytFrm">Paid in</label><SELECT name="cboPytFrm" id="cboPytFrm" size="1" class="modalinput" onchange="checkMode(this)"><option selected value="Cash">
			Cash</option><option value="Cheque">Cheque</option><option value="Cash+Cheque">Cash + Cheque</option></select></div>
		<div class="col-md-2"><label for="txtCheNo">Cheque No.</label><input name="txtCheNo" id="txtCheNo" class="modalinput" maxlength="7" onkeyup="checkInput(this)" value="" readonly>
		</div>
		<div class="col-md-2"><label for="cboBankAC">Debited A/C</label><SELECT name="cboBankAC" id="cboBankAC" size="1" class="modalinput" disabled onchange="showBankBal(this)">
			<?php echo $optbank;?></SELECT></div>
		<div class="col-md-2 divsubheading"><label for="txtCHand">Cash at Hand</label><input type="text" name="txtCHand" id="txtCHand" class="modalinput numbersinput modalinputdisabled"
			readonly maxlength="10" value="<?php echo number_format(floatval($cashbal),2);?>"></div>
		<div class="col-md-2 divsubheading"><label for="txtCBank">Cash at Bank</label><input type="text" name="txtCBank" id="txtCBank" class="modalinput numbersinput modalinputdisabled"
			maxlength="10"	readonly value="0.00"></div>
		<div class="col-md-2 divsubheading"><label for="txtTotal">Creditor's Bal</label><input name="txtCredTotal" id="txtCredTotal" class="modalinput numbersinput modalinputdisabled"
				maxlength="10" onkeyup="checkInput(this)" readonly value="<?php echo number_format(floatval($credbal),2);?>"></div>
	</div><div class="form-row">
		<div class="col-md-4"></div><div class="col-md-2"><br><br> AMOUNT PAID (KSHS.)</div>
		<div class="col-md-2"><label for="txtCash">Cash Amount</label><input type="text" name="txtCash" id="txtCash" class="modalinput numbersinput" maxlength="10"
		onkeyup="checkInput(this)" onChange="sumPaid(0)" value="0.00" placeholder="KShs. 0.00"></div>
		<div class="col-md-2"><label for="txtCheque">Cheque Amount</label><input type="text" name="txtCheque" id="txtCheque" class="modalinput numbersinput" maxlength="10" readonly
		onkeyup="checkInput(this)" onChange="sumPaid(1)" value="0.00" placeholder="KShs. 0.00"></div>
		<div class="col-md-2 divsubheading"><label for="txtTotal">Total Amount	Paid </label><input name="txtTotal" id="txtTotal" class="modalinput numbersinput modalinputdisabled"
		maxlength="10" onkeyup="checkInput(this)" readonly value="0.00"></div>
	</div><hr><div class="form-row">
		<div class="col-md-12"><label for="txtCash">Narration of Pettycash Payment</label><Textarea name="txtRmks" id="txtRmks" class="modalinput" rows="2" maxlength="250" placeholder="BEING
			PAYMENT FOR ">BEING PAYMENT FOR <?php echo $cred[5];?></textarea></div>
	</div><div class="form-row"><div class="col-md-12"  STYLE="font-size:12pt;text-align:center;font-weight:bold;letter-spacing:4px;word-spacing:7px;">DETAILS OF VOTEHEAD DISTRIBUTION
	</div></div>
	<div class="form-row"><div class="col-md-12 divlrborder" style="background-color:#40a8c4;">
		<div class="form-row">
			<div class="col-md-3 divsubheading">VOTEHEAD COSTED</div><div class="col-md-2 divsubheading">VOTE'S BUDGET</div><div class="col-md-1 divsubheading">INCOME</div><div
			class="col-md-2	divsubheading">VOTEHEAD'S BAL</div><div class="col-md-2 divsubheading">CREDITOR'S BAL</div><div class="col-md-2 divsubheading">AMOUNT PAID</div>
		</div>
		<?php $index=0;
			foreach($credits as $cr){
				if($index<4){//Allow viewing only 4 voteheads per payment
					$voteno=$cr->valVoteNo(); $yrcredit=$cr->valYear(); $budg=$cr->valBudget(); $voteamt=$cr->valAmt(); $found=false; $inco=$avail=0;
					if($yrcredit==$finyr){ $len=count($voteheads); $i=0; while(!$found && $i<$len){
							if($voteheads[$i]->valVoteNo()==$voteno){$found=true; $inco=$voteheads[$i]->valIncome(); $avail=($voteheads[$i]->valIncome()-$voteheads[$i]->valCost());} $i++;}
					}else{$len=count($sundry); $i=0; while(!$found && $i<$len){
							if($sundry[$i]->valVoteNo()==$voteno){$found=true; $inco=$sundry[$i]->valIncome(); $avail=($sundry[$i]->valIncome()-$sundry[$i]->valCost());} $i++;}
					}$i=$count=0; $len=count($creditdet); $cdet='';
					while($i<$len){if($voteno==$creditdet[$i]->valVoteNo()){$cdet.=($count==0?"":"~").$creditdet[$i]->valDetNo()."-".$creditdet[$i]->valAmt(); $count++;}$i++;}
					print "<div class=\"form-row\"><div class=\"col-md-3\">".$cr->valName()."<input name=\"txtVote_$index\" id=\"txtVote_$index\" type=\"hidden\" value=\"$voteno-$recno[1]-$yrcredit\">
					<input name=\"txtVoteDet_$index\" id=\"txtVoteDet_$index\" type=\"hidden\" value=\"$cdet\"></div><div class=\"col-md-2\"><input name=\"txtBudget_$index\" id=\"txtBudget_$index\"
					class=\"modalinput modalinputdisabled numbersinput\" value=\"".number_format($budg,2)."\"	readonly></div><div class=\"col-md-1\"><input name=\"txtIncome_$index\"
					Id=\"txtIncome_$index\" class=\"modalinput numbersinput modalinputdisabled\" value=\"".number_format($inco,2)."\"></div><div class=\"col-md-2\"><input
					name=\"txtAvailable_$index\" Id=\"txtAvailable_$index\"  class=\"modalinput numbersinput modalinputdisabled\" value=\"".number_format($avail,2)."\"></div><div
					class=\"col-md-2\"><input name=\"txtBal_$index\" Id=\"txtBal_$index\" class=\"modalinput numbersinput modalinputdisabled\" value=\"".number_format($voteamt,2)."\"></div>
					<div class=\"col-md-2\"><input name=\"txtAmount_$index\" id=\"txtAmount_$index\" maxlength=\"10\" value=\"0.00\" class=\"modalinput numbersinput\" onKeyUp=\"checkInput(this)\"
					onChange=\"checkCompute($index)\"></div></div>"; $index++;
				}
			}print "<input type=\"hidden\" name=\"txtNOV\"  id=\"txtNOV\" value=\"$index\">";
		?></div>
	</div><div class="form-row">
		<div class="col-md-4"><label for="txtCosted">Amount Distributed</label><input class="numbersinput modalnoinput" name="txtCosted" id="txtCosted" maxlength="10"
		value="0.00" readonly></div>
		<div class="col-md-4"></div>
		<div class="col-md-4"><label>Balance to be Distributed</label><input name="txtBalance" id="txtBalance" class="numbersinput modalnoinput" maxlength="10" value="0.00" readonly></div>
	</div><br><hr>
	<div class="form-row">
		<div class="col-md-4"><button type="submit" name="CmdSave" id="CmdSave" class="btn btn-primary btn-md btn-block">Save Commitment Payment</button></div>
		<div class="col-md-4"></div>
		<div class="col-md-4" style="text-align:right"><button type="button" name="CmdClose" onclick="window.open('creditors.php','_self')" class="btn btn-info btn-md">Close/ Cancel</button>
		</div>
	</div>
</form></div>
<script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/comtpyts.js"></script>
<script type="text/javascript">bankbal.push(<?php echo $bankbal;?>);</script>
<?php
	mysqli_close($conn); footer();
?>
