<?php
    include_once("shanam.php");
    $rsDet=mysqli_query($conn,"SELECT reqview,impview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");	$adv=0; $reqv=0;
    if (mysqli_num_rows($rsDet)>0) list($req,$impv)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
    //number of pending requisitions
    $rs=mysqli_query($conn,"SELECT count(reqno) as nos FROM acc_req GROUP BY approved,markdel HAVING (approved=0 and markdel=0)");
    $reqno=0; if (mysqli_num_rows($rs)>0) list($reqno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
    headings('',0,0,0);
    print "<table class=\"table table-responsive table-borderless\" style=\"width:50%;color:#fff;position:relative;top:100px;\"><tr><td colspan=\"2\"><p style=\"text-align:center;\">
    IMPREST MANAGEMENT INTERFACE.<br> Log In Time: ".$_SESSION['logintime']."</p></td></tr>";
    print "<tr><td  align=\"center\"><a onclick=\"return canvi($req);\" href=\"requisition.php\"><img src=\"../gen_img/acc.jpeg\"
    id=\"img1\" width=\"120\" height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br><font color=\"#ee0000\">($reqno)</font> Imprest
    Request(s)</td>";
    print "<td  align=\"center\"><a href=\"imprests.php?action=0-0\" onclick=\"return canvi($impv);\"><img src=\"../gen_img/adv.jpeg\" id=\"img2\" width=\"120\"
    height=\"100\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Imprest Issuance</td></tr>";
?><tr><td colspan="3"><p style="text-align:center;">Shanam's Digital Solutions - Bridging Digital Divide</p></td></tr></table>
<script type="text/javascript" src="tpl/menu.js"></script>
<?php
    mysqli_close($conn);    footer();
?>
