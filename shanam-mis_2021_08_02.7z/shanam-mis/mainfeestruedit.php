<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['CmdSave'])){
	 	//capture data
	 	$dat=isset($_POST['TxtInfo'])?$_POST['TxtInfo']:"0-0-0"; 				$dat=preg_split('/\-/',$dat);
		$feegrp=isset($_POST['CboFeeGrp'])?$_POST['CboFeeGrp']:Null; 			$lvl=isset($_POST['CboLvl'])?$_POST['CboLvl']:Null; $yr=date('Y');
		$tui1=isset($_POST['TxtTui1'])?strip_tags($_POST['TxtTui1']):0; 		$tui2=isset($_POST['TxtTui2'])?strip_tags($_POST['TxtTui2']):0; 
		$tui3=isset($_POST['TxtTui3'])?strip_tags($_POST['TxtTui3']):0; 		$boa1=isset($_POST['TxtBoa1'])?strip_tags($_POST['TxtBoa1']):0; 
		$boa2=isset($_POST['TxtBoa2'])?strip_tags($_POST['TxtBoa2']):0; 		$boa3=isset($_POST['TxtBoa3'])?strip_tags($_POST['TxtBoa3']):0; 
		$act1=isset($_POST['TxtAct1'])?strip_tags($_POST['TxtAct1']):0; 		$act2=isset($_POST['TxtAct2'])?strip_tags($_POST['TxtAct2']):0; 
		$act3=isset($_POST['TxtAct3'])?strip_tags($_POST['TxtAct3']):0;			$ltt1=isset($_POST['TxtLTT1'])?strip_tags($_POST['TxtLTT1']):0; 
		$ltt2=isset($_POST['TxtLTT2'])?strip_tags($_POST['TxtLTT2']):0;			$ltt3=isset($_POST['TxtLTT3'])?strip_tags($_POST['TxtLTT3']):0;
		$rmi1=isset($_POST['TxtRMI1'])?strip_tags($_POST['TxtRMI1']):0; 		$rmi2=isset($_POST['TxtRMI2'])?strip_tags($_POST['TxtRMI2']):0; 
		$rmi3=isset($_POST['TxtRMI3'])?strip_tags($_POST['TxtRMI3']):0;			$ewc1=isset($_POST['TxtEWC1'])?strip_tags($_POST['TxtEWC1']):0; 
		$ewc2=isset($_POST['TxtEWC2'])?strip_tags($_POST['TxtEWC2']):0;			$ewc3=isset($_POST['TxtEWC3'])?strip_tags($_POST['TxtEWC3']):0;
		$exa1=isset($_POST['TxtExam1'])?strip_tags($_POST['TxtExam1']):0;		$exa2=isset($_POST['TxtExam2'])?strip_tags($_POST['TxtExam2']):0; 
		$exa3=isset($_POST['TxtExam3'])?strip_tags($_POST['TxtExam3']):0;		$adm1=isset($_POST['TxtAdm1'])?strip_tags($_POST['TxtAdm1']):0; 
		$adm2=isset($_POST['TxtAdm2'])?strip_tags($_POST['TxtAdm2']):0;			$adm3=isset($_POST['TxtAdm3'])?strip_tags($_POST['TxtAdm3']):0;
		$lib1=isset($_POST['TxtLib1'])?strip_tags($_POST['TxtLib1']):0; 		$lib2=isset($_POST['TxtLib2'])?strip_tags($_POST['TxtLib2']):0;
		$lib3=isset($_POST['TxtLib3'])?strip_tags($_POST['TxtLib3']):0;			$med1=isset($_POST['TxtMed1'])?strip_tags($_POST['TxtMed1']):0;  
		$med2=isset($_POST['TxtMed2'])?strip_tags($_POST['TxtMed2']):0;			$med3=isset($_POST['TxtMed3'])?strip_tags($_POST['TxtMed3']):0;
		$pem1=isset($_POST['TxtPem1'])?strip_tags($_POST['TxtPem1']):0; 		$pem2=isset($_POST['TxtPem2'])?strip_tags($_POST['TxtPem2']):0;
		$pem3=isset($_POST['TxtPem3'])?strip_tags($_POST['TxtPem3']):0; 		$ole1=isset($_POST['TxtOle1'])?strip_tags($_POST['TxtOle1']):0; 		
		$ole2=isset($_POST['TxtOle2'])?strip_tags($_POST['TxtOle2']):0;			$ole3=isset($_POST['TxtOle3'])?strip_tags($_POST['TxtOle3']):0;
		//remove commas
		$tui1=preg_replace('/[^0-9^\.]/','',$tui1); 	$tui2=preg_replace('/[^0-9^\.]/','',$tui2);		$tui3=preg_replace('/[^0-9^\.]/','',$tui3);
		$boa1=preg_replace('/[^0-9^\.]/','',$boa1);		$boa2=preg_replace('/[^0-9^\.]/','',$boa2);		$boa3=preg_replace('/[^0-9^\.]/','',$boa3);
		$act1=preg_replace('/[^0-9^\.]/','',$act1); 	$act2=preg_replace('/[^0-9^\.]/','',$act2);		$act3=preg_replace('/[^0-9^\.]/','',$act3); 
		$ltt1=preg_replace('/[^0-9^\.]/','',$ltt1);		$ltt2=preg_replace('/[^0-9^\.]/','',$ltt2);		$ltt3=preg_replace('/[^0-9^\.]/','',$ltt3);
		$rmi1=preg_replace('/[^0-9^\.]/','',$rmi1); 	$rmi2=preg_replace('/[^0-9^\.]/','',$rmi2);		$rmi3=preg_replace('/[^0-9^\.]/','',$rmi3);
		$ewc1=preg_replace('/[^0-9^\.]/','',$ewc1);		$ewc2=preg_replace('/[^0-9^\.]/','',$ewc2);		$ewc3=preg_replace('/[^0-9^\.]/','',$ewc3);
		$exa1=preg_replace('/[^0-9^\.]/','',$exa1);		$exa2=preg_replace('/[^0-9^\.]/','',$exa2);		$exa3=preg_replace('/[^0-9^\.]/','',$exa3);
		$adm1=preg_replace('/[^0-9^\.]/','',$adm1); 	$adm2=preg_replace('/[^0-9^\.]/','',$adm2);		$adm3=preg_replace('/[^0-9^\.]/','',$adm3);
		$lib1=preg_replace('/[^0-9^\.]/','',$lib1);		$lib2=preg_replace('/[^0-9^\.]/','',$lib2);		$lib3=preg_replace('/[^0-9^\.]/','',$lib3);
		$med1=preg_replace('/[^0-9^\.]/','',$med1);		$med2=preg_replace('/[^0-9^\.]/','',$med2);		$med3=preg_replace('/[^0-9^\.]/','',$med3);
		$pem1=preg_replace('/[^0-9^\.]/','',$pem1);		$pem2=preg_replace('/[^0-9^\.]/','',$pem2);		$pem3=preg_replace('/[^0-9^\.]/','',$pem3);
		$ole1=preg_replace('/[^0-9^\.]/','',$ole1); 	$ole2=preg_replace('/[^0-9^\.]/','',$ole2);		$ole3=preg_replace('/[^0-9^\.]/','',$ole3);
		//computation
		$tui2+=$tui1;	$tui3+=$tui2;	$boa2+=$boa1;	$boa3+=$boa2; 	$act2+=$act1;	$act3+=$act2;	$ltt2+=$ltt1;	$ltt3+=$ltt2;
		$rmi2+=$rmi1;	$rmi3+=$rmi2;	$ewc2+=$ewc1;	$ewc3+=$ewc2; 	$exa2+=$exa1;	$exa3+=$exa2;	$adm2+=$adm1;	$adm3+=$adm2;
		$lib2+=$lib1;	$lib3+=$lib2;	$med2+=$med1;	$med3+=$med2; 	$pem2+=$pem1;	$pem3+=$pem2;	$ole2+=$ole1;	$ole3+=$ole2;	
		$t1=$tui1+$boa1+$act1+$ltt1+$rmi1+$ewc1+$exa1+$adm1+$lib1+$med1+$pem1+$ole1;
		$t2=$tui2+$boa2+$act2+$ltt2+$rmi2+$ewc2+$exa2+$adm2+$lib2+$med2+$pem2+$ole2;	
		$t3=$tui3+$boa3+$act3+$ltt3+$rmi3+$ewc3+$exa3+$adm3+$lib3+$med3+$pem3+$ole3;
		if ($t3<1){
			print "<font color=\"#dd0000\" size=\"+2\">YOU CANNOT SAVE A FEE STRUCTURE WHOSE TOTAL AMOUNT IS ZERO!!!!!</FONT><BR>";
		}else{
			mysqli_query($conn,"UPDATE Acc_Feeoutline SET feegrp='$feegrp',lvlno='$lvl',t1tui='$tui1',t1board='$boa1',t1act='$act1',t1ltt='$ltt1',t1rmi='$rmi1',t1ewc='$ewc1',
			t1exam='$exa1',t1adm='$adm1',t1lib='$lib1',t1med='$med1',t1pemol='$pem1',t1olevies='$ole1',maint1='$t1',t2tui='$tui2',t2board='$boa2',t2act='$act2',t2ltt='$ltt2',
			t2rmi='$rmi2',t2ewc='$ewc2',t2exam='$exa2',t2adm='$adm2',t2lib='$lib2',t2med='$med2',t2pemol='$pem2',t2olevies='$ole2',maint2='$t2',tui='$tui3',board='$boa3',act='$act3',
			ltt='$ltt3',rmi='$rmi3',ewc='$ewc3',exam='$exa3',adm='$adm3',lib='$lib3',med='$med3',pemol='$pem3',olevies='$ole3',maint3='$t3' WHERE (curr_year LIKE 
			'$dat[0]' and feegrp LIKE '$dat[1]' and lvlNO LIKE '$dat[2]')") or die(mysqli_error($conn)." Fee structure as edited is not saved. Click <a 
			href=\"feestruct.php\">here</a> to try again.");
			$i=mysqli_affected_rows($conn); 
			header("location:feestruct.php?action=1-$i");
		}
	}else{
		$dat=isset($_REQUEST['adm'])?$_REQUEST['adm']:"0-0-0"; 	$dat=preg_split('/\-/',$dat);
		$rsCo=mysqli_query($conn,"SELECT feegrp,lvlno,t1tui,t1board,t1act,t1ltt,t1rmi,t1ewc,t1exam,t1adm,t1lib,t1med,t1pemol,t1olevies,maint1,(t2tui-t1tui) as tui2,(t2board-t1board) as 
		boa2,(t2act-t1act) as act2, (t2ltt-t1ltt) as ltt2,(t2rmi-t1rmi) as rmi2,(t2ewc-t1ewc) as ewc2,(t2exam-t1exam)as exa2,(t2adm-t1adm) as adm2,(t2lib-t1lib) as lib2,(t2med-t1med) 
		as med2,(t2pemol-t1pemol) as pem2,(t2olevies-t1olevies) as ole2,(maint2-maint1) as ttl2,(tui-t2tui) as tui3,(board-t2board) as boa3,(act-t2act) as act3,(ltt-t2ltt) as ltt3,(rmi-
		t2rmi) as rmi3,(ewc-t2ewc) as ewc3,(exam-t2exam)as exa3,(adm-t2adm) as adm3,(lib-t2lib) as lib3,(med-t2med) as med3,(pemol-t2pemol) as pem3,(olevies-t2olevies) as ole3,
		(maint3-maint2) as ttl3, tui,board,act,ltt,rmi,ewc,exam,adm,lib,med,pemol,olevies,maint3 FROM Acc_feeoutline WHERE curr_year LIKE '$dat[0]' and feegrp LIKE '$dat[1]' and lvlno 
		LIKE '$dat[2]'");
		//fetch fee data from database
		if (mysqli_num_rows($rsCo)>0) list($feegrp,$lvl,$t1tui,$t1boa,$t1act,$t1ltt,$t1rmi,$t1ewc,$t1exa,$t1adm,$t1lib,$t1med,$t1pem,$t1ole,$t1,$t2tui,$t2boa,$t2act,$t2ltt,$t2rmi,
		$t2ewc,$t2exa,$t2adm,$t2lib,$t2med,$t2pem,$t2ole,$t2,$t3tui,$t3boa,$t3act,$t3ltt,$t3rmi,$t3ewc,$t3exa,$t3adm,$t3lib,$t3med,$t3pem,$t3ole,$t3,$tui,$boa,$act,$ltt,$rmi,$ewc,
		$exa,$adm,$lib,$med,$pem,$ole,$yt)=mysqli_fetch_row($rsCo); 
		mysqli_free_result($rsCo);
	}
	
?>
<html>
<head>
	<link href="tpl/fmtForms.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Fee Structure</title>
	<script type="text/javascript" src="tpl/feestruct.js"></script>
</head>
<body background="img/bg3.gif">
	<form method="post" action="MainFeeStruEdit.php" name="feestruct" onsubmit="return validateFormOnSubmit(this)"><div class="fmtDiv"><table align="center"><tr><th colspan="5"><h2>
	MAIN ACCOUNT FEE STRUCTURE EDITOR</h2></td></tr><tr><td colspan="5" align="left">-<br>Fee Structure Of 
	<?php
		print "<input type=\"hidden\" name=\"TxtInfo\" value=\"$dat[0]-$dat[1]-$dat[2]\"><select name=\"CboLvl\" size=\"1\" id=\"course\">";
		$rs=mysqli_query($conn,"SELECT lvlno,lvlname FROM ClassLvl Order BY lvlno ASC"); 
		if (mysqli_num_rows($rs)>0) while (list($lno,$lname)=mysqli_fetch_row($rs)) print "<option value=\"$lno\"".(strcasecmp($lvl,$lno)==0?"selected":"").">$lname</option>"; 
		mysqli_free_result($rs);
		print "</select>-<select name=\"CboFeeGrp\" size=\"1\" id=\"course\">";
		$cour=mysqli_query($conn,"SELECT fee FROM grps WHERE (fee is not null and fee not like '') Order BY fee ASC"); 
		if (mysqli_num_rows($cour)>0) while (list($cona)=mysqli_fetch_row($cour)) print "<option ".(strcasecmp($cona,$feegrp)==0?"selected":"").">$cona</option>";
		mysqli_free_result($cour);
		print "</select><br>-</td></tr>";
		print "<tr bgcolor=\"#eeeeee\"><th>Votehead</td><th>Term I</td><th>Term II</th><th>Term III</th><th>Total</th></tr>";
		print "<tr><td>Tuition</td><td><input name=\"TxtTui1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1tui,2)."\" style=\"text-align:right;\" id=\"TxtVal_1_1\" 
		onChange=\"Compute(1,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTui2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2tui,2)."\" style=\"text-align:right;\" id=\"TxtVal_1_2\" onChange=\"Compute(1,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTui3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3tui,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_1_3\" onChange=\"Compute(1,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTui4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($tui,2)."\" style=\"text-align:right;\" id=\"TxtVal_1\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Boarding/ Lunch</td><td><input name=\"TxtBoa1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1boa,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_2_1\" onChange=\"Compute(2,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtBoa2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2boa,2)."\" style=\"text-align:right;\" id=\"TxtVal_2_2\" onChange=\"Compute(2,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtBoa3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3boa,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_2_3\" onChange=\"Compute(2,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtBoa4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($boa,2)."\" style=\"text-align:right;\" id=\"TxtVal_2\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Activity</td><td><input name=\"TxtAct1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1act,2)."\" style=\"text-align:right;\" 
		id=\"TxtVal_3_1\" onChange=\"Compute(3,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAct2\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t2act,2)."\" style=\"text-align:right;\" id=\"TxtVal_3_2\" onChange=\"Compute(3,2)\" onkeyup=\"checkInput(this)\"></td><td><input 
		name=\"TxtAct3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3act,2)."\" style=\"text-align:right;\" id=\"TxtVal_3_3\" 
		onChange=\"Compute(3,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAct4\" maxlength=\"9\" size=\"9\" value=\"".number_format($act,2).
		"\" style=\"text-align:right;\" id=\"TxtVal_3\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>L . T &amp; T</td><td><input name=\"TxtLTT1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ltt,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_4_1\" onChange=\"Compute(4,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLTT2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2ltt,2)."\" style=\"text-align:right;\" id=\"TxtVal_4_2\" onChange=\"Compute(4,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLTT3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3ltt,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_4_3\" onChange=\"Compute(4,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLTT4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($ltt,2)."\" style=\"text-align:right;\" id=\"TxtVal_4\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>R . M . I</td><td><input name=\"TxtRMI1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1rmi,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_5_1\" onChange=\"Compute(5,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRMI2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2rmi,2)."\" style=\"text-align:right;\" id=\"TxtVal_5_2\" onChange=\"Compute(5,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRMI3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3rmi,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_5_3\" onChange=\"Compute(5,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRMI4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($rmi,2)."\" style=\"text-align:right;\" id=\"TxtVal_5\" disabled class=\"bg\"></td></tr>";
		//row six
		print "<tr><td>E . W . C</td><td><input name=\"TxtEWC1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ewc,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_6_1\" onChange=\"Compute(6,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtEWC2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2ewc,2)."\" style=\"text-align:right;\" id=\"TxtVal_6_2\" onChange=\"Compute(6,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtEWC3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3ewc,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_6_3\" onChange=\"Compute(6,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtEWC4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($ewc,2)."\" style=\"text-align:right;\" id=\"TxtVal_6\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Examination/ CATs</td><td><input name=\"TxtExam1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1exa,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_7_1\" onChange=\"Compute(7,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtExam2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2exa,2)."\" style=\"text-align:right;\" id=\"TxtVal_7_2\" onChange=\"Compute(7,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtExam3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3exa,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_7_3\" onChange=\"Compute(7,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtExam4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($exa,2)."\" style=\"text-align:right;\" id=\"TxtVal_7\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Administration Costs</td><td><input name=\"TxtAdm1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1adm,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_8_1\" onChange=\"Compute(8,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAdm2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2adm,2)."\" style=\"text-align:right;\" id=\"TxtVal_8_2\" onChange=\"Compute(8,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAdm3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3adm,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_8_3\" onChange=\"Compute(8,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtAdm4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($adm,2)."\" style=\"text-align:right;\" id=\"TxtVal_8\" disabled class=\"bg\"></tr>";
		print "<tr><td>Library</td><td><input name=\"TxtLib1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1lib,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_9_1\" onChange=\"Compute(9,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLib2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2lib,2)."\" style=\"text-align:right;\" id=\"TxtVal_9_2\" onChange=\"Compute(9,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLib3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3lib,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_9_3\" onChange=\"Compute(9,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtLib4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($lib,2)."\" style=\"text-align:right;\" id=\"TxtVal_9\" disabled class=\"bg\"></tr>";
		print "<tr><td>Medical</td><td><input name=\"TxtMed1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1med,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_10_1\" onChange=\"Compute(10,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMed2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2med,2)."\" style=\"text-align:right;\" id=\"TxtVal_10_2\" onChange=\"Compute(10,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMed3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3med,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_10_3\" onChange=\"Compute(10,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMed4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($med,2)."\" style=\"text-align:right;\" id=\"TxtVal_10\" disabled class=\"bg\"></tr>";
		//row 11
		print "<tr><td>Personal Emolument</td><td><input name=\"TxtPem1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1pem,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_11_1\" onChange=\"Compute(11,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtPem2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2pem,2)."\" style=\"text-align:right;\" id=\"TxtVal_11_2\" onChange=\"Compute(11,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtPem3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3pem,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_11_3\" onChange=\"Compute(11,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtPem4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($pem,2)."\" style=\"text-align:right;\" id=\"TxtVal_11\" disabled class=\"bg\"></tr>";
		print "<tr><td>Other Levies</td><td><input name=\"TxtOle1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ole,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_12_1\" onChange=\"Compute(12,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtOle2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2ole,2)."\" style=\"text-align:right;\" id=\"TxtVal_12_2\" onChange=\"Compute(12,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtOle3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3ole,2)."\" 
		style=\"text-align:right;\" id=\"TxtVal_12_3\" onChange=\"Compute(12,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtOle4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($ole,2)."\" style=\"text-align:right;\" id=\"TxtVal_12\" disabled class=\"bg\"></tr>";
		print "<tr><td>Total Fees</td><td><input name=\"TxtTotal1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1,2)."\"  id=\"TxtTotal1\"
		style=\"text-align:right;\" disabled class=\"bg\"></td><td><input name=\"TxtTotal2\" maxlength=\"9\" size=\"9\" value=\"".number_format($t2,2)."\" 
		style=\"text-align:right;\" id=\"TxtTotal2\" disabled class=\"bg\"></td><td><input name=\"TxtTotal3\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t3,2)."\" style=\"text-align:right;\" id=\"TxtTotal3\" disabled class=\"bg\"></td><td><input name=\"TxtTotal\" maxlength=\"9\" 
		size=\"9\" value=\"".number_format($yt,2)."\" style=\"text-align:right;\" id=\"TxtTotal\" disabled class=\"bg\"></td></tr>";
		mysqli_close($conn);
	?></table></div><div class="fmtDiv">
	<center><button type="submit" name="CmdSave">Save Fee Structure</button>&nbsp;&nbsp;&nbsp;<a href="feestruct.php?action=0-0"><button 
	type="button" name="CmdClose">Close</button></a></form></div>
</body>
</html>