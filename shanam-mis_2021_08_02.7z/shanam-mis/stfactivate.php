<?php
	include_once('../conn/mysqli_connect.inc.tpl');
	$idno=isset($_REQUEST['idno'])?$_REQUEST['idno']:'00';
	mysqli_query($conn,"UPDATE stf SET markdel=0,type=0,st_status=1 WHERE idno LIKE '$idno'");
	$i=mysqli_affected_rows($conn);
	mysqli_close($conn);
	header("location:delstf.php?action=1-$i");
?>