<?php
	session_start();
	include_once("../conn/pri_sch_connect.inc");
	$act=isset($_REQUEST['adv'])?$_REQUEST['adv']:"10-10"; $act=preg_split("/\-/",$act);
	$rsSP=mysqli_query($conn,"SELECT Advreqapproval FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$advadd=0;	list($advadd)=mysqli_fetch_row($rsSP);	mysqli_free_result($rsSP);
	if ($advadd==1){
		 if ($act[1]==0){ //Editing salary advance request details
			header("location:advreqeditor.php?advno=$act[0]");
			exit();
		}elseif($act[1]==1){ //Approving salary advance for issuing
			$rsAdv=mysqli_query($conn,"SELECT payrollno,reqno,amt,ded_period,amtperded,rmks FROM acc_advreq WHERE reqno LIKE '$act[0]'");
			list($payno,$reqno,$amt,$dedper,$amtper,$rmks)=mysqli_fetch_row($rsAdv); 	mysqli_free_result($rsAdv);
			$date=date('Y-m-d'); $yr=date('Y');	$addby=$_SESSION['username']." (".$_SESSION['priviledge'].")";
			mysqli_query($conn,"INSERT INTO acc_adv (advno,payrollno,advreqno,adv_date,curr_year,amt,authorisedby,rmks,duration,amtperduration,addedby) VALUES (null,'$payno',
			'$reqno','$date','$yr','$amt','".$_SESSION['priviledge']."','$rmks','$dedper','$amtper','$addby')") or die(mysqli_error($conn)." Click <a href=saladvreq.php>
			Here</a> to try again!!.");
			$i=mysqli_affected_rows($conn);
			if ($i==1) mysqli_query($conn,"UPDATE acc_advreq SET adv_status=1 WHERE reqno LIKE '$reqno'");
		}elseif($act[1]==2){ //Declining/ rejecting advance request
			header("location:advreqdeny.php?advno=$act[0]");
			exit();
		}elseif($act[1]==3){ //Cancelling salary advance declination
			mysqli_query($conn,"UPDATE acc_advreq SET adv_status=0 WHERE reqno LIKE '$act[0]'") or die(mysqli_error($conn)." Click <a href=saladvreq.php>Here</a> to 
			try again!!.");
			$i=mysqli_affected_rows($conn);
			if ($i==1) mysqli_query($conn,"UPDATE acc_advrej SET markdel=1 WHERE advreqno LIKE '$act[0]'") or die(mysqli_error($conn)." Click <a href=saladvreq.php>
			Here</a> to try again!!.");
		}else{ //No Action to be done
			$i=0;
		}
	}else{
		$i=0;
	}
	mysqli_close($conn);
	header("location:saladvreq.php?action=1-$i");
?>