<?php
	include_once('shanam.php');
	$rsStf=mysqli_query($conn,"SELECT pytview,pytadd,pytedit,pytdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$pytviu=0;	$pytedi=0;	$pytadd=0;	$pytdel=0;
	list($pytviu,$pytadd,$pytedi,$pytdel)=mysqli_fetch_row($rsStf);	mysqli_free_result($rsStf);
	if ($pytviu==0) header("location:vague.php");
	$action=isset($_POT['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
	$sdate=isset($_POST['dtpFrom'])?sanitize($_POST['dtpFrom']):date("d-m-Y",strtotime("-30days"));	$edate=isset($_POST['dtpTo'])?sanitize($_POST['dtpTo']):date("d-m-Y");
	$acc=isset($_POST['cboAc'])?sanitize($_POST['cboAc']):'%';
	headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" type="text/css" href="/date/tcal.css" />',$action[0],$action[1],2);
	mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE markdel=0 ORDER BY acno ASC; SELECT e.vono,v.abbr,p.idno,p.name,p.telno,e.pytdate,e.pytfrm,e.cheno,
	if(length(e.rmks)>75,concat(left(e.rmks,75),' ...'),e.rmks) as nar,e.caamt,e.chamt,(e.caamt+e.chamt) As Amt, datediff(curdate(),e.pytdate) as nd,p.cred_no FROM	acc_exp e Inner
	Join acc_creditors p On (e.expno=p.cred_No) Inner Join acc_voteacs v On	(e.acc=v.acno) WHERE (e.markdel=0 and e.commt=1 and (e.pytdate BETWEEN '".date('Y-m-d',strtotime($sdate))."'
	and '".date('Y-m-d',strtotime($edate))."') and e.acc LIKE '$acc') ORDER BY e.pytdate,e.vono ASC;");
	$i=0;	$table="";	$ttl=[0,0,0];	$optacc="<option value=\"%\" selected>All A/Cs</option>"; $acname="all accounts'";
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){
				if (mysqli_num_rows($rs)>0) while($dt=mysqli_fetch_row($rs)){$optacc.="<option value=\"$dt[0]\" ".($dt[0]==$acc?"selected":"").">$dt[1]</option>";if($dt[0]==$acc) $acname=$dt[1];}
			}else{
				$noexp=mysqli_num_rows($rs);
				if($noexp>0) while($d=mysqli_fetch_row($rs)){
					$table.="<tr><td>$d[0]</td><td>$d[1]</td><td>$d[2]</td><td>$d[3]</td><td>$d[4]</td><td>".date('D d M, Y',strtotime($d[5]))."</td><td>$d[6]</td><td>$d[7]</td><td
					align=\"right\">".number_format($d[9],2)."</td><td align=\"right\">".number_format($d[10],2)."</td><td align=\"right\">".number_format($d[11],2)."</td><td align=\"center\">".
					(($d[12]<2 && $pytedi)?"<a href=\"creditorcomtedit.php?vono=$acc-$d[0]\" title=\"Edit PV\">Edit</a>":"")."</td><td align=\"center\"><img src=\"/gen_img/print.ico\" height=20
					onclick=\"window.open('rpts/commtpv.php?action=$d[0]-8-$d[13]-$acc','_self')\" width=20 title=\"Print PV\"></td></tr>";
					$ttl[0]+=$d[9]; $ttl[1]+=$d[10];	 $ttl[2]+=$d[11];
				}else{$table.="<tr><td colspan=\"13\">No Commitment payments made between ".date("D, d-F-Y",strtotime($sdate))." and ".date("D, d-F-Y",strtotime($edate))." in $acname</td></tr>";
				}$table.="</tbody><tfoot class=\"thead-light\" id=\"trTtls\"><tr><th colspan=\"5\">$noexp Payment Record(s)</th><th colspan=\"3\" align=\"right\">Payment Subtotals</th><th
				align=\"right\">".number_format($ttl[0],2)."</th><th align=\"right\">".number_format($ttl[1],2)."</th><th align=\"right\">".number_format($ttl[2],2)."</th><th colspan=\"2\">
				</th></tr></tfoot></table>";
			} mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	$h= $acname." Commitment Payments Made Between <font color=\"#00F\">".date("D, d-F-Y",strtotime($sdate))."</font> and <font color=\"#00f\">".date("D, d-F-Y",strtotime($edate)).
	"</font>.";
?><div class="head"><form action="creditorcommtpyts.php" method="POST"><label for="date3">View <select name="cboAc" id="cboAc" size=1><?php echo $optacc;?></SELECT> Commitment Payments
Made Between </label><input name="dtpFrom" class="tcal" type="text" value="<?php echo $sdate;?>" readonly size="8"><label for="date4">&nbsp;and&nbsp;</label><input name="dtpTo"
class="tcal" type="text" value="<?php echo $edate; ?>" readonly size="8">&nbsp;&nbsp;<button type="submit"	name="CmdView">View Payments</button></form></div>
<div class="container" style="background-color:#e6e6e6;width:fit-content;border-radius:10px;font-size:0.9rem;margin:5px auto">
	<div class="form-row"><div class="col-md-12" style="border:0.5px dotted green;border-radius:10px;padding:6px;"><form name="frmFind" action="#" method="post">Find Commitment Payment By
		&nbsp;<input type="radio" name="radFind" id="radVNo" value="vono" onclick="clrText()" selected>PV No.&nbsp; <input type="radio" name="radFind" id="radName" value="names" checked
		onclick="clrText()">Creditor's Names &nbsp; <input type="radio" name="radFind" id="radIDNo"	value="idno" onclick="clrText()">ID No. &nbsp; <input type="radio" name="radFind"
		id="radTelNo"	value="telno" onclick="clrText()">Tel No. &nbsp;&nbsp; <input type="text" maxlength="15" size="25" name="txtFind" id="txtFind" value="" onkeyup="myFunction()"
		placeholder="Type what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;"></form></div>
	</div><div class="form-row"><div class="col-md-12" style="max-height:600px;overflow-y:scroll" id="divComtPyts"><?php echo "<h6>".strtoupper($h)."</h6>";?>
	<table class="table table-sm table-hover table-striped table-bordered" id="tblPV"><thead class="thead-dark"><tr><th rowspan="2">VOUCHER<br>NO.</th><th rowspan="2">ACCOUNT</th><th
	colspan="3">CREDITORS' DETAILS</th><th colspan="3">COMMITMENT DETAILS</th><th colspan="3">AMOUNT PAID</th><th colspan="2">ADMIN ACTION</th></tr><th>ID. NO.</th><th>PAYEE</th>
	<th>TEL. NO.</th><th>DATE</th><th>MODE</th><th>CHEQUE NO.</th><th>CASH</th><th>CHEQUE</th><th>TOTAL</th><th>EDIT</th><th>VOUCHER</th></tr>
	<?php echo $table;?></div>
	</div><div class="form-row"><div class="col-md-12" style="text-align:right;"><img onclick="printSpecific()" src="/gen_img/print.ico" height=20 width=30 title="Print"></div></div>
</div>
<script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/creditorcommtpyts.js"></script>
<?php mysqli_close($conn); footer(); ?>
