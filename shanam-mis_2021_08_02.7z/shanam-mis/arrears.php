<?php
	include_once('shanam.php');	$action=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0';	 $action=explode("-",$action);
	$selYr=isset($_POST['cboYear'])?strip_tags($_POST['cboYear']): date("Y")-1;	$fr=isset($_POST['cboCls'])?strip_tags($_POST['cboCls']): "%";
	$st=isset($_POST['cboStream'])?strip_tags($_POST['cboStream']):"%";	$find=isset($_POST['txtFind'])?strip_tags($_POST['txtFind']):"%";
	$search=isset($_POST['search'])?strip_tags($_POST['search']):"stud_names"; $i=$viu=$edi=$del=0; $optyr=$optcls=$optstrm='';
	mysqli_multi_query($conn,"SELECT feeview,feeedit,feedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT finyr FROM ss; SELECT min(curr_year) as yr FROM class;
	SELECT clsno,clsname FROM classnames ORDER BY clsno;SELECT strm FROM grps WHERE strm is not null ORDER BY strm ASC; SELECT DISTINCT curr_year FROM class WHERE curr_year NOT IN
	(SELECT finyr FROM ss) ORDER By curr_year DESC");
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){if (mysqli_num_rows($rs)==1) list($viu,$edi,$del)=mysqli_fetch_row($rs);}elseif($i==1) list($cuyr)=mysqli_fetch_row($rs);  elseif($i==2) list($fyr)=mysqli_fetch_row($rs);
			elseif($i==3) while ($d=mysqli_fetch_row($rs)) $optcls.="<option value=\"$d[0]\" ".($fr==$d[0]?"selected":"").">$d[1]</option>";
			elseif($i==4) while ($d=mysqli_fetch_row($rs)) $optstrm.="<option value=\"$d[0]\" ".($st==$d[0]?"selected":"").">$d[0]</option>";
			else while ($d=mysqli_fetch_row($rs)) $optyr.="<option value=\"$d[0]\" ".($st==$d[0]?"selected":"").">$d[0]</option>";	mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link href="tpl/css/headers.css" rel="stylesheet" /><link href="tpl/accprint.css" rel="stylesheet" media="print" />',$action[0],$action[1],2);
?><div class="head"><form method="post" action="arrears.php"><a href="home.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;Financial Year
	<SELECT name="cboYear" id="cboYear" size="1"><?php echo $optyr;?></select> Arrears for <label for="form">Class</label>&nbsp;<select name="cboCls" size="1" id="form"><option value="%"
	selected>All</option><?php echo $optcls;?></select>-<select name="cboStream" size="1" id="stream"><option value="%" selected>All</option><?php echo $optstrm;?></select>&nbsp;
	&nbsp;&nbsp;Or Search By <input type="radio" name="search" value="admno" checked>Adm. No.&nbsp;<input type="radio" name="search" value="stud_names">Names&nbsp;<input type="text"
	maxlength="15" size="15" name="txtFind" id="adno" value="%">&nbsp;&nbsp;<button type="submit" name="Stud" <?php echo (($viu==1)?"":"disabled");?>>Show Report</button></form>
</div><h3>
	<?php if(isset($_POST['Stud'])){$h= $selYr." Fee Arrears Brought Forward By "; if (strlen($fr)>1) $h=$h." Form/Grade ".$fr;		if (strlen($st)>1) $h=$h." ".$st." Students";
	}else $h= $selYr." Fee Arrears B/F";?>
<div class="container" style="background-color:#ddd;"><div class="form-row"><div class="col-md-12"><h3 style="text-align:center"><?php echo strtoupper($h)." AS ON ".
	strtoupper(date("D d-M-Y"));?></h3></div></div>
	<div class="form-row"><div class="col-md-12" style="max-height:700px;overflow-y:scroll;font-size:0.8rem;"><table class="table table-sm table-hover table-striped table-bordered">
		<thead class="thead-dark"><tr><th colspan="6">DETAILS OF STUDENT</th><th rowspan="2">ARREARS B/F</th></tr><tr><th>Adm. No.</th><th>Names</th><th>Class</th><th>Level</th><th>
		Admitted On</th><th>Tel. No.</th></tr></THEAD><tbody>
		<?php
			$find=strcasecmp($find,"%")!=0?$find:"%";
			$sql="SELECT s.`admno`,concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname,'-',sf.stream,' -In FY',sf.curr_year) As frm,cl.lvlname,s.admdate,s.telno,(sf.bbf+sf.miscbf) As
			Ttl FROM stud s Inner	Join class sf USING (admno) Inner Join classnames c USING (clsno) inner Join classlvl cl ON (sf.lvlno=cl.lvlno) WHERE ";
			if ($cuyr==$selYr){
				if (strcasecmp("%",$find)==0)$sql.="(sf.bbf+sf.miscbf)>0 And s.Markdel=0 and s.type=0 and s.present=1 And sf.clsno LIKE '$fr' and sf.stream LIKE '$st' and sf.curr_year LIKE
				'$selYr' ";
				else{if (strcasecmp($search,"admno")==0)	$sql.="(sf.bbf+sf.miscbf)>0 and s.Markdel=0 and	s.type=0 and s.present=1 And s.admno LIKE '$find' and sf.curr_year LIKE '$selYr' ";
					else $sql="((sf.bbf+sf.miscbf)>0 and s.Markdel=0 and s.type=0 and s.present=1 And (s.surname LIKE '%$find%' Or s.onames LIKE '%$find%') and sf.curr_year LIKE '$selYr'";
				}
			}else{if(strcasecmp("%",$find)==0)	$sql.="(sf.bbf+sf.miscbf)>0 and sf.clsno LIKE '$fr' and sf.stream LIKE '$st' and sf.curr_year LIKE '$selYr'";
				else{if(strcasecmp($search,"admno")==0) $sql.="(sf.bbf+sf.miscbf)>0 and sf.admno LIKE '$find' And	sf.curr_year LIKE '$selYr' ";
					else $sql.="(sf.bbf+sf.miscbf)>0 and (s.surname LIKE '%$find%' Or s.onames LIKE '%$find%') And sf.curr_year LIKE '$selYr' ";
				}
			}$sql.="Order By s.surname,s.onames ASC";
			$rsStud=mysqli_query($conn,$sql);		$tarr=$i=0;
			if (mysqli_num_rows($rsStud)>0){
				while ($rsS=mysqli_fetch_row($rsStud)){
					print "<tr>";$a=0;
					foreach($rsS as $sr){
					 	if($a==0) $admno=$sr; if($a<6 && $a!=4) print "<td>".$sr."</td>"; elseif($a==4){$sr=date("D, d-F-Y",strtotime($sr));print "<td>".$sr."</td>";}
						else{	$tarr+=$sr;	print "<td align=\"right\">".number_format($sr,2)."</td>";} $a++;
					}print "</tr>"; $i++;
				}
			}else	print "<tr><td colspan=\"10\"><br />There are no pupils with arrears b/f.</td></tr>";
			print "<tr><td colspan=\"4\" align=\"left\" class=\"b\">".mysqli_num_rows($rsStud)." Fee Arrear(s)' Records</td><td colspan=\"2\" align=\"right\" class=\"b\">Subtotals (Kshs.)</td>
			<td align=\"right\" class=\"b\"><b>".number_format($tarr,2)."</b></td></tr></table>"; mysqli_free_result($rsStud);
	?></div>
</div></div>
<script type="text/javascript" src="tpl/js/actionmessage.js"></script>
<?php mysqli_close($conn); footer();?>
