<?php
	include_once("../conn/pri_sch_connect.inc");
	$rec=isset($_REQUEST['rec'])?$_REQUEST['rec']:'0';
	mysqli_query($conn,"UPDATE grps SET markdel=1 WHERE grp_no LIKE '$rec'");
	$i=mysqli_affected_rows($conn);
	header("location:sysgroup.php?action=2-$i");
?>