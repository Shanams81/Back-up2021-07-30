<?php
	include_once("shanam.php");
	$rsDet=mysqli_query($conn,"SELECT arr_waive,saladvwaive,loanwaive FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'");	$arr=0;	$loan=0; $adv=0;
	if (mysqli_num_rows($rsDet)>0) list($arr,$adv,$loan)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	headings('',0,0,0);
	print "<table border=\"0\" cellspacing=\"2\" cellpadding=\"3\" align=\"center\" style=\"position:relative;top:100px;\"><tr><td colspan=\"3\"><p>WAIVING/PARDON MANAGEMENT INTERFACE.<br> Log In Time: ".
	$_SESSION['logintime']."</p></td></tr>";
 	print "<tr><td width=\"35%\" align=\"center\"><a href=\"waive_arrears.php\" target=\"det\" onclick=\"return canvi($arr);\"><img src=\"/gen_img/arrears.jpg\" id=\"img1\"
	width=\"100\" height=\"80\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Waive Arrears</td>";
	print "<td width=\"35%\" align=\"center\"><a href=\"waive_advance.php\" target=\"det\" onclick=\"return canvi($adv);\"><img src=\"/gen_img/adv.jpeg\" id=\"img2\"
	width=\"100\" height=\"80\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Salary Advances (BOM)</td>";
	print "<td width=\"30%\" align=\"center\"><a href=\"waive_subloan.php\" target=\"det\" onclick=\"return canvi($loan);\"><img src=\"/gen_img/loan.jpg\" id=\"img2\"
	width=\"100\" height=\"80\" onmouseover=\"img_focus(this)\" onmouseout=\"img_blur(this)\"></a><br>Subloans (TSC)</td></tr>";
	print "<tr><td colspan=\"3\"><p>Shanam's Digital Solutions - Bridging Digital Divide</p></td></tr></table>";
	mysqli_close($conn); footer();
?>
