<?php
	include_once('shanam.php');
	if(isset($_POST['btnSave'])){
		$tkn=isset($_POST['txtTkn'])?sanitize($_POST['txtTkn']):0;					$recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0;
		$date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('d-m-Y');	$date=preg_split('/\-/',$date);	$date=$date[2].'-'.$date[1].'-'.$date[0];
		$ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;						$voteno=isset($_POST['cboVotes'])?sanitize($_POST['cboVotes']):0;
		$mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'EFT';			$modeno=isset($_POST['txtModeNo'])?sanitize($_POST['txtModeNo']):null;
		$rmks=isset($_POST['txtRmks'])?strtoupper(sanitize($_POST['txtRmks'])):null; $tkn=preg_split('/\-/',$tkn); //[0] Token, [1] bank, [2] Votehead
		$amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0; 	$modeno=strlen($modeno)>0?$modeno:null;
		$bank=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;				$amt=preg_replace('/[^0-9\.]/','',$amt);
		if($_SESSION['tkn']!=$tkn[0] || $ac==0 || $voteno==0 || $bank==0 || (strcasecmp($mode,'cheque')==0 && strlen($modeno)==0) || $amt<1 || strlen($rmks)<11){
			echo 'FSE Receipt Grant has errors. Can not be saved as entered. Click <a href="fseothergrants.php">HERE</a> to go back'; unset($_SESSION['tkn']); exit(0);
		}else{
			$sql="UPDATE acc_fseincome SET recon='$date',acc=$ac,acsno=$bank,amt=$amt,mode='$mode',modeno=".var_export($modeno,true).",rmks=".var_export($rmks,true)." WHERE recno LIKE
			'$recno'; ";
			if ($tkn[2]!=$voteno) $sql.="DELETE FROM acc_fsevotes WHERE recno LIKE '$recno' and voteno LIKE '$tkn[2]'; INSERT INTO acc_fsevotes (recno,acc,voteno,amt) VALUES ('$recno','$ac',
			'$voteno','$amt');"; else $sql.="UPDATE acc_fsevotes SET amt=$amt WHERE recno LIKE '$recno' and voteno LIKE '$tkn[2]';";
			if($tkn[1]!=$bank) $sql.="DELETE FROM acc_banking WHERE transtype=0 and transno LIKE '$recno'; INSERT INTO acc_banking (sno,transdate,bank_type,acsno,amt,rmks,transtype,transno,
			addedby) VALUES(0,'$date',0,$bank,$amt,'FSE Grant Income',0,$recno,'".$_SESSION['username']." (".$_SESSION['priviledge']."');";
			else $sql="UPDATE acc_banking SET amt=$amt WHERE transtype=0 and transno LIKE '$recno';";
			mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fseothergrants.php">HERE</a> to go back'); $i=0;
			do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=($i>0?1:0); header("location:fseothergrants.php?action=1-$i"); exit(0);
		}
	}elseif(isset($_POST['btnDel'])){
		$recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0; $rmks=isset($_POST['txtDel'])?sanitize($_POST['txtDel']):''; $ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;
		if($recno==0 || strlen($rmks)<15){
			echo 'FSE Receipt Record Can not be deleted until a valid reason is given. Click <a href="fsefees.php">HERE</a> to go back'; unset($_SESSION['tkn']); exit(0);
		}else{
		 	$sql="UPDATE acc_fseincome SET markdel=1, delreason='$rmks' WHERE recno LIKE '$recno'; UPDATE acc_fsevotes SET markdel=1 WHERE recno LIKE '$recno' and acc LIKE '$ac'; UPDATE
			acc_banking SET markdel=1, delreason='$rmks' WHERE transtype=0 and transno=$recno;";
			mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fseothergrants.php">HERE</a> to go back'); $i=0;
			do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=($i>0?1:0);
			unset($_SESSION['tkn']); header("location:fseothergrants.php?action=2-$i"); exit(0);
		}
	}$rec=isset($_REQUEST['rec'])?sanitize($_REQUEST['rec']):'0-0'; $rec=preg_split('/\-/',$rec); //[0] receipt number, [1] - ACC [2] unique id
	$_SESSION['tkn']=$tkn=uniqid();
	$sql="SELECT acno,descr from acc_voteacs WHERE stud_assoc=0 and acno LIKE  '$rec[1]' ORDER BY acno ASC; SELECT a.sno,concat(b.abbr,' - A/C ',a.accno) as acc FROM acc_accounts a Inner
	Join acc_banks b ON (a.bankno=b.sno) WHERE accacc LIKE '$rec[1]'; SELECT gofeedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT v.sno,v.descr FROM acc_votes v WHERE
	acc LIKE '$rec[1]'; SELECT f.recno,f.recon,f.acc,f.acsno,f.amt,f.mode,f.modeno,f.rmks,v.voteno FROM acc_fseincome f Inner Join acc_fsevotes v USING (recno,acc) WHERE f.recno LIKE
	'$rec[0]' and f.commt=4;";
	mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"fsefees.php\">HERE</a> to go back."); 	$i=$viu=$del=0; $table=$optVotes=$optBanks=$optACs='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){while($d=mysqli_fetch_row($rs)) $optACs.='<option value="'.$d[0].'">'.$d[1].'</option>';
			}elseif($i==1){while($d=mysqli_fetch_row($rs)) $optBanks.='<option value="'.$d[0].'">'.$d[1].'</option>';
			}elseif($i==2){if(mysqli_num_rows($rs)>0) list($del)=mysqli_fetch_row($rs);
			}elseif($i==3){if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $optVotes.="<option value=\"$d[0]\">$d[1]</option>";
			}else{if(mysqli_num_rows($rs)>0) $fee=mysqli_fetch_row($rs);
				$table.='<div class="form-row"><INPUT name="txtTkn" type="hidden" size=4 value="'.$tkn.'" id="txtTkn"><div class="col-md-4"><label for="txtRecNo">Receipt No. *</label><input
				type="text" name="txtRecNo" id="txtRecNo" readonly value="'.$fee[0].'" placeholder="Auto" class="modalinput"></div><div class="col-md-4"></div><div class="col-md-4"><label
				for="dtpDate">Received On *</label><input type="text" name="dtpDate" id="dtpDate" readonly value="'.date('d-m-Y',strtotime($fee[1])).'" class="tcal modalinput"></div></div>';
				$table.='<div class="form-row"><div class="col-md-6"><label for="cboAC">Votehead Account Credited *<label><SELECT name="cboAC" id="cboAC" onchange="loadVotehead(this)"
				size=1 class="modalinput">'.$optACs.'</SELECT></div><div class="col-md-6"><label for="cboVotes">Votehead Credited. *</label><span id="spVotes"><SELECT name="cboVotes" id="cboVotes"
				size=1 class="modalinput">'.$optVotes.'</SELECT></span></div></div>';
				$table.='<div class="form-row"><div class="col-md-6"><label for="cboMode">Grant Received In *</label><SELECT name="cboMode" id="cboMode" size="1" class="modalinput"><option
				value="EFT" '.(strcasecmp($fee[5],'eft')==0?'selected':'').'>Electronic Fund Transfer</option><option value="CHEQUE" '.(strcasecmp($fee[5],'cheque')==0?'selected':'').'>Cheque
				</option></SELECT></div><div class="col-md-6"><label for="txtModeNo">Transaction/ Cheque No.</label><input type="text" name="txtModeNo" id="txtModeNo" readonly value="'.
				$fee[6].'" class="modalinput"></div></div>';
				$table.='<div class="form-row"><div class="col-md-12"><label for="txtRmks">Narration about the Grant *</label><textarea name="txtRmks" id="txtRmks" rows=3 class="modalinput"
				placeholder="FUNDS TO BUILD CLASSROOMS AND LABORATORY" style="letter-spacing:1px;word-spacing:2px;" required>'.$fee[7].'</textarea></div></div>';
				$table.='<div class="form-row"><div class="col-md-6"><label for="cboBank">Bank A/C Credited *<br><span id="spBankAC"><SELECT name="cboBank" id="cboBank" size=1 class="modalinput"
				onload="setBank('.$fee[3].')">'.$optBanks.'</SELECT></span></div><div class="col-md-6"><label for="txtAmt">Amount Received *</label><input type="text" name="txtAmt" id="txtAmt"
				value="'.number_format($fee[4],2).'" maxlength=12 class="modalinput numbersinput" onkeyup="checkData(this)"></div></div><hr>';
			}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css"/><link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css"/>',0,0,2);
?>
<div class="container" style="margin:100px auto;max-width:650px;background:#eee;border-radius:20px;"><form name="frmNewIncome" method="post" action="fsegrantedit.php"
	onsubmit="return validateData(this)"><INPUT name="txtTkn" type="hidden" size=4 value="<?php echo "$tkn-$fee[3]-$fee[8]";?>" id="txtTkn">
	<div class="form-row"><div class="col-md-12 divheadings">OTHER FREE SECONDARY EDUCATION (FSE) GRANTS EDITOR</div></div><?php echo $table;?>
	<div class="form-row"><div class="col-md-6"><button type="submit" name="btnSave" id="btnSave" class="btn btn-block btn-primary btn-md">Save Changes</button></div><div class="col-md-3"
		style="text-align:center"><button id="btnDelShow" name="btnDelShow" type="button" onclick="confirmDel()" <?php echo $del==1?"":"disabled";?> class="btn btn-info btn-md">Delete</button>
		</div><div class="col-md-3" style="text-align:right"><a href="fseothergrants.php"><button type="button" name="btnClose" id="btnClose" class="btn btn-info btn-md">Close</button></a>
		</div>
	</div><hr><div class="form-row" id="spDel" style="display:none"><div class="col-md-10"><label for="txtDel">Reason for Deleting *</del><textarea cols="80" rows="4" class="modalinput"
		name="txtDel" id="txtDel" style="letter-spacing:2px;word-spacing:3px;" placeholder="FSE Receipt Details Erroneously captured" onkeyup="enableDelete(this)"></textarea></div><div
		class="col-md-2"><div class="form-row"><div class="col-md-12"><button name="btnDel" id="btnDel" type="submit" disabled class="btn btn-block btn-warning btn-md">Delete Receipt</button>
		</div><div class="form-row"><div class="col-md-12"><button name="btnCancel" id="btnCancel" type="button" onclick="cancelDel()" class="btn btn-info btn-md btn-block">Cancel</button>
		</div></div></div></div>
	</div>
</div>
<script type="text/javascript" src="tpl/js/fsefeeedit.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript">
	function setSelect(ac,bank,v){document.getElementById('cboAC').value=ac;document.getElementById('cboBank').value=bank;document.getElementById('cboVotes').value=v;}
	setSelect(<?php echo"$fee[2],$fee[3],$fee[8]";?>);
</script>
<?php mysqli_close($conn); footer(); ?>
