<?php
  	include_once('../conn/pri_sch_connect.inc');
  	$yr=date('Y');
	   $ad=strip_tags($_REQUEST['del']);	$ad=preg_split('/\-/',$ad); //id 0 - purchase no,1 - uniform number, 2- Adm No. and 3 - Amount
  	mysqli_query($conn,"DELETE FROM unipurchdetails WHERE purchno LIKE '$ad[0]' and unifrmno LIKE '$ad[1]' and curr_year IN (SELECT finyr FROM ss)") or
  	die(mysqli_error($conn). " Record not deleted");
  	$i=mysqli_affected_rows($conn);
  	if ($i>0) mysqli_query($conn,"UPDATE class SET unifrm=unifrm-$ad[3] WHERE admno LIKE '$ad[2]' and curr_year LIKE '$yr'");
  	header("location:studarrears.php?action=$ad[0]-$yr-1");
  	mysqli_close($conn);
?>
