<?php
    include_once('shanam.php');
    if(isset($_POST['cmdNew'])){header("location:SalAdvNew.php?act=0-0-0"); exit(0);}//issuing new addvance
    $action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0";	$action=preg_split("/\-/",$action,2);
    if (isset($_POST['btnSave'])){
        $date=isset($_POST['dtpDate'])?strip_tags($_POST['dtpDate']):date('d-m-Y'); $date=preg_split("/\-/",$date); $acc=isset($_POST['cboACNo'])?sanitize($_POST['cboACNo']):1;
        $pfn=isset($_POST['cboStf'])?strip_tags($_POST['cboStf']):0; $dur=isset($_POST['cboDur'])?strip_tags($_POST['cboDur']):0; $modeno=isset($_POST['txtModeNo'])?sanitize($_POST['txtModeNo']):null;
        $amt=isset($_POST['txtAmt'])?strip_tags($_POST['txtAmt']):0; $amt=preg_replace('/[^0-9^\.]/','',$amt); $mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'Cash';
        $amtpd=isset($_POST['txtAmtDur'])?strip_tags($_POST['txtAmtDur']):0;        $amtpd=preg_replace('/[^0-9^\.]/','',$amtpd); $modeno=strlen($modeno)>1?$modeno:null; $date="$date[2]-$date[1]-$date[0]";
        $rmks=isset($_POST['txtRmks'])?strtoupper(strip_tags($_POST['txtRmks'])):'';	$advno=isset($_POST['txtAdvNo'])?strip_tags($_POST['txtAdvNo']):0; $advno=strlen($advno)==0?0:$advno;
        $bankac=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;   $bankac=($bankac==0 || $bankac=='')?null:$bankac; $adb=$_SESSION['username']." (".$_SESSION['priviledge'].")";
        if (strlen($pfn)>0 && $amt>=$amtpd && strlen($rmks)>9 && $dur>0 && (strcasecmp($mode,'cash')==0 || (strcasecmp($mode,'cheque')==0 && !isnull($bankac) && strlen($modeno)>1))){
          $sql="INSERT INTO acc_adv(advno,payrollno,adv_date,amt,rmks,duration,amtperduration,addedby,acc,pytfrm,cheno,acsno) VALUES (0,'$pfn','$date',$amt,'$rmks','$dur',$amtpd,'$adb','$acc','$mode',
          ".var_export($modeno,true).",".var_export($bankac,true)."); SELECT p.payno FROM acc_exppayee p Inner JOIn acc_saldef s USING (idno) WHERE s.payrollno LIKE '$pfn'; SELECT max(vono) as vn FROM
          acc_exp GROUP BY acc HAVING acc LIKE '$acc'; SELECT sno FROM acc_votes WHERE acc LIKE '$acc' and abbr LIKE '%advance%';";
          mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Advance record not saved. Click <a href=\"saladv.php\">HERE</a> to try again."); $i=$payno=$pvno=$vno=0;
          do{if($i==0){$advno=mysqli_insert_id($conn); $action[1]=mysqli_affected_rows($conn);}else{if($rs=mysqli_store_result($conn)){if(mysqli_num_rows($rs)>0){if($i==1)list($payno)=mysqli_fetch_row($rs);
            elseif($i==2)list($pvno)=mysqli_fetch_row($rs);  else list($vno)=mysqli_fetch_row($rs);} mysqli_free_result($rs);}}  $i++;
          }while(mysqli_next_result($conn)); $pvno++; $cash=$cheque=0; if(strcasecmp($mode,"cash")==0) $cash=$amt; else $cheque=$amt;
          if($action[1]==1){//Successful Insertion
            if($payno==0){//New payee
      				if(mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,telno,address,email,addedby) SELECT 0,'$date',concat(s.surname,' ',s.onames) as nms,s.idno,s.telno,s.address,s.email,'$adb'
              as ad FROM stf s Inner Join acc_saldef d USING (idno) WHERE d.payrollno LIKE '$pfn'")) $payno=mysqli_insert_id($conn);
      			}$set=false; $i=1;
      			while(!$set && ($i<8)){
      				if (mysqli_query($conn,"INSERT INTO acc_exp(vono,acsno,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,addedby) VALUES ('$pvno',".var_export($bankac,true).",'$date',$acc,'$mode',".var_export($modeno,true).
              ",'$cash','$cheque',".var_export($rmks,true).",$payno,'$adb')") or die(mysqli_error($conn).".	Payment details were not saved. Click <a	href=\"saladv.php\">Here</a> to try again.")) $set=true;
              else $pvno++;	$i++;
      			}if($set){//Expenditure details were saved save votehead
      				$sql='';
      				if($cash>0) $sql.="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES(0,$acc,1,'$date','Salary Advance',$cash,2,$pvno,'$adb');";
      				if($cheque>0) $sql.="INSERT acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,addedby) VALUES (0,'$date',1,$bankac,'$cheno',$cheque,'Salary Advance,1,$pvno,'$adb');";
      				$sql.="INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($pvno,$acc,$vno,$amt); UPDATE acc_adv SET vono='$pvno' WHERE advno=$advno;";
      				mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Payment votehead details were not saved. Click <a href=\"pettypyts.php\">Here</a> to try again.</center>");
      				while(mysqli_next_result($conn)){}
      			}header("location:rpts/pv.php?action=$pvno-1-$payno-$acc");
          }
        }else{$action[1]=0; echo 'Data has errors. Salary advance record not saved. Click <a href=\"saladv.php\">HERE</a> to try again.';} $action[0]=1;
    } $from=isset($_POST['TxtFrom'])?sanitize($_POST['TxtFrom']):date('d-m-Y',strtotime(date('Y').'-01-01')); $acc=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):'%';
    $to=isset($_POST['TxtTo'])?sanitize($_POST['TxtTo']):date("d-m-Y"); $type=isset($_POST['CboType'])?sanitize($_POST['CboType']):0; $cacc=($acc=="%"?1:$acc);
    mysqli_multi_query($conn,"SELECT advview,advadd,advedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT l.idno FROM login l Inner Join acc_saldef sd USING (idno) WHERE l.username LIKE '".
    $_SESSION['username']."'; SELECT acno,descr FROM acc_voteacs WHERE markdel=0 and sal_assoc=1 ORDER BY acno ASC; SELECT sd.payrollno,concat(s.surname,' ',s.onames,' (',s.designation,') - ID NO. ',s.idno) as nam
    FROM stf s Inner Join acc_saldef sd USING (idno) WHERE s.markdel=0 and s.present=1 order by s.surname,s.idno ASC; SELECT a.acsno,ac.accAcc,concat(ba.abbr,'-',ac.branch,' A/C NO.',ac.accNo) as bank,(a.bankbalbf+
    if(isnull(b.bal),0,b.bal)) as amt FROM acc_acbalbf a Inner Join acc_accounts ac ON (a.acsno=ac.sNo) Inner Join acc_banks ba ON (ac.bankno=ba.sNo) Inner Join acc_voteacs va ON (ac.accacc=va.acno) Left Join (SELECT
    acsno,sum(if(bank_type=0,amt,0)-if(bank_type=1,amt,0)) as bal FROM acc_banking Group By markdel,acsno HAVING markdel=0)b USING (acsno) GROUP BY a.bankbalbf,a.acsno,ac.accAcc,ba.abbr,ac.accNo,va.sal_assoc HAVING
    va.sal_assoc=1 ORDER BY a.acsno; SELECT a.acc,(a.cashbalbf+if(isnull(b.amt),0,b.amt)) as amt FROM acc_votebalbf a Inner Join acc_voteacs v On (a.acc=v.acno) Left Join (SELECT acc,(sum(if(cftype=0,amt,0))-
    sum(if(cftype=1,amt,0))) as amt FROM acc_cashflow GROUP BY acc,markdel HAVING markdel=0)b USING (acc)	GROUP BY a.acc,a.cashbalbf,v.sal_assoc HAVING v.sal_assoc=1;");
    $advviu=$advadd=$advedit=$i=$cbal=0;  $idno=$optac=$acname=$optstf=$lstbankbal=$lstcashbal='';
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0) list($advviu,$advadd,$advedit)=mysqli_fetch_row($rs); elseif($i==1) list($idno)=mysqli_fetch_row($rs);
        elseif($i==2) while($d=mysqli_fetch_row($rs)){$optac.="<option value=\"$d[0]\">$d[1]</option>"; if($d[0]==$acc){$cbal=$d[1]; $acname=$d[1];}}
        elseif($i==3) while($d=mysqli_fetch_row($rs)) $optstf.="<option value=\"$d[0]\">$d[1]</option>";
        elseif($i==4){$c=0; while($d=mysqli_fetch_row($rs)){$lstbankbal.=($c==0?"":",")."new BankBal($d[0],$d[1],'$d[2]',$d[3])"; $c++;}}
        else{$c=0; while($d=mysqli_fetch_row($rs)){$lstcashbal.=($c==0?"":",")."new CashBal($d[0],$d[1])"; $c++;}} mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn));  if ($advviu==0) header("location:vague.php");
    headings('<link href="tpl/css/headers.css" rel="stylesheet"/><link href="/date/tcal.css" rel="stylesheet"/><link rel="stylesheet" href="tpl/css/modalfrm.css" /><link rel="stylesheet" href="tpl/css/inputsettings.css"/>',
    $action[0],$action[1],2);
?><div class="head"><form name="FrmAdv" method="post" action="saladv.php"><a href="advance_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;View <SELECT name="cboAC"
id="cboAC" size="1"><option value="%">All A/Cs</option><?php echo $optac;?></SELECT> - <SELECT name="CboType" size="1"><option value="0" selected>Un-Issued</option><option value="1">Issued</option><option value="2">
Recovered</option><option value="3">Unrecovered</option></Select> Salary Advance(s) Issued Between <input name="TxtFrom" class="tcal" size="8" readonly value="<?php echo date('d-m-Y',strtotime($from));?>"> And <input
name="TxtTo" class="tcal" size="8" readonly value="<?php echo date("d-m-Y",strtotime($to));?>"> &nbsp;&nbsp;<button type="submit" name="CmdShow">View Advances</button>&nbsp;&nbsp;&nbsp;&nbsp;<button type="button"
name="cmdNew" <?php echo ($advadd==0?"disabled":"");?> onclick="document.getElementById('divSalAdvNew').style.display='block'">New Salary Advance</button></form></div>
<div class="container" style="background-color:#f6f6f6;border-radius:10px;max-width:950px;padding:5px;margin:5px auto">
<?php
    if (strlen($idno)>0) print "<a href=\"Advreq.php?idn=$idno\">--</a>";
    if (isset($_POST['CmdShow'])){
        if ($type==1) $h="salary advances issued Between ".date("D d, M Y",strtotime($from))." and ".date("D d, M Y",strtotime($to));
        elseif ($type==0) $h="Approved Salary advances yet to be issued to staff";
        elseif ($type==2) $h="Salary advances issued and recovered ";
        else $h="Salary advances yet to be recovered, issued between ".date("D d, M Y",strtotime($from))." and ".date("D d, M Y",strtotime($to));
        $from=preg_split("/\-/",$from);		$to=preg_split("/\-/",$to);
        $sql="SELECT sd.payrollno,s.idno,concat(s.surname,' ',s.onames,' (',s.designation,')') as nam,a.advno,a.adv_date,a.dur,a.amt,a.amtperduration,a.AmtClrd,a.Bal,a.rmks,a.issued,a.vono,a.acc FROM stf s Inner Join
        acc_saldef sd USING (idno) INNER JOIN (SELECT a.advno,a.payrollno,a.adv_date,concat(a.duration,' Month(s)') as dur,a.amt,a.amtperduration,IF(isnull(sum(c.amt_clr)),0,Sum(c.amt_clr)) AS AmtClrd,(a.amt-
        IF(isnull(sum(c.amt_clr)),0,Sum(c.`amt_clr`))) AS Bal,a.rmks,a.issued,a.vono,a.acc FROM acc_adv a LEFT JOIN acc_advclr c ON a.advno=c.advano GROUP BY a.adv_date,a.advno,a.amtperduration,a.amt,a.rmks,a.duration,
        a.markdel,a.issued,a.vono,a.acc HAVING a.acc LIKE '$acc' and a.markdel=0 and (a.adv_date BETWEEN '$from[2]-$from[1]-$from[0]' AND '$to[2]-$to[1]-$to[0]') ";
        if ($type==0) $sql.=" and a.issued=0)a USING (payrollno)";
        elseif ($type==1) $sql.=" and a.issued=1)a USING (payrollno)";
        elseif ($type==2) $sql.=")a USING (payrollno) WHERE bal=0";
        else  $sql.="a.markdel=0 and USING (payrollno) WHERE bal>0";
    }else{
        $h="All Approved Salary advances yet to be issued to staff";
        $sql="SELECT sd.payrollno,s.idno,concat(s.surname,' ',s.onames,' (',s.designation,')') as nam,a.advno,a.adv_date,a.dur,a.amt,a.amtperduration,a.AmtClrd,a.Bal,a.rmks,a.issued,a.vono,a.acc FROM stf s Inner Join
        acc_saldef sd USING (idno) INNER JOIN (SELECT a.advno,a.payrollno,a.adv_date,concat(a.duration,' Month(s)') as dur,a.amt,a.amtperduration,IF(isnull(sum(c.amt_clr)),0,Sum(c.amt_clr)) AS AmtClrd,(a.`amt`-
        IF(isnull(sum(c.`amt_clr`)),0,Sum(c.`amt_clr`))) AS Bal,a.rmks,a.issued,a.vono,a.acc FROM acc_adv a LEFT JOIN acc_advclr c ON a.advno=c.advano GROUP BY a.adv_date,a.advno,a.amtperduration,a.amt,a.rmks,
        a.duration,a.markdel,a.issued,a.vono,a.acc HAVING a.markdel=0 and a.issued=0 and a.acc LIKE '$acc')a USING (payrollno)";
    }$h=($acc=="%"?"":$acname).$h;
    print "<h6 style=\"background-color:#555;color:#fff;letter-spacing:3px;word-spacing:5px;padding:2px;border-radius:6px 6px 0 0;\">".strtoupper($h)."</h6>";
?><span style="background:white;border:0.5px dotted green;border-radius:10px 10px 10px 10px;padding:6px;display:block;width:100%;font-size:12px;height:fit-content;"><form  name="frmFind" action="#" method="post">
Find Salary Advance By&nbsp;<input type="radio" name="radFind" id="radIDNo" value="idno" onclick="clrText()">ID No. &nbsp; <input type="radio" name="radFind" id="radName" value="st_names" checked onclick="clrText()">
Names &nbsp; <input type="radio" name="radFind" id="radPFNo" value="pfno" onclick="clrText()">Payroll No. &nbsp;&nbsp; <input type="text" maxlength="17" size="30" name="txtFind" id="txtFind" value=""
onkeyup="myFunction(1)" placeholder="Type/ Enter what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;"></form></span>
<div style="background-color:#e6e6e6;max-height:600px;overflow-y:scroll;"><table class="table table-striped table-hover table-bordered table-sm" id="myTable" style="font-size:0.7rem"><thead class="thead-dark"><tr><th
colspan="3">Staff Member's Details</th><th colspan="6">Advance Details</th><th rowspan="2">Reason for the Salary Advance</th><th colspan="3">Admin  actions</th></tr><tr><th>PF No.</th><th>ID. No.</th><th>Names</th><th>
Issued On</th><th>Recovered In<th>Advance Amt</th><th>Rate of Deduction</th><th>Amt Cleared</th><th>Balance</th><th>Issue</th><th>Edit</th><th>Print</th></tr></thead><tbody>
<?php
    $rsSA=mysqli_query($conn,$sql);$ttl=array(0,0,0,0); $i=0; $noadv=mysqli_num_rows($rsSA);
    if ($noadv>0){
      while ($res=mysqli_fetch_row($rsSA)){
        print "<tr>";	$ai=$acno=$vono=0;
        foreach($res as $rse) {
          if ($ai<11){
            if (($ai<4) || ($ai==10) || ($ai==5)){if ($ai==0) $pfno=$rse; if ($ai==3) $ps=$rse; else print "<td>$rse</td>";
            }elseif ($ai==4){$rse=date("D, d-F-Y",strtotime($rse)); print "<td>$rse</td>";
            }else{if ($ai==6) $amt=$rse; elseif ($ai==9) $bal=$rse;  $ttl[($ai-6)]+=$rse;  print "<td align=\"right\">".number_format($rse,2)."</td>";}
          }else{if($ai==11)$iss=$rse; elseif($ai==12) $vono=$rse; else $acno=$rse;}  $ai++;
        } if (($amt==$bal) && ($iss==0)) print "<td align=\"center\"><a onclick=\"return canadd($advadd)\" href=\"rpts/saladvprintout.php?adv=$ps-0-$acno-$vono\">Issue</a></td><td align=\"center\"><a
        onclick=\"return canedit($advedit)\" href=\"saladvnew.php?act=1-$ps-$pfno\">Edit</a></td><td align=\"center\">-</td>";
        else print "<td align=\"center\">-</td><td align=\"center\">-</td><td align=\"center\"><a href=\"rpts/saladvprintout.php?adv=$ps-1-$acno-$vono\">Print</a></td>";
        print "</tr>"; $i++;
      }
    } print "</tbody><tfoot><tr><td align=\"right\" class=\"b\" colspan=\"5\"><b>Advance's Subtotals (Kshs.)</b></td>";
    foreach($ttl as $t) print "<td align=\"right\" class=\"b\">".number_format($t,2)."</td>"; print "<td colspan=\"4\"></td></tr></tfoot></table></div></div";    mysqli_free_result($rsSA);
    print "<center><span id=\"spNoAdv\" style=\"background:#eaa;border-bottom:2px groove #ddd;font-weight:bold;\"><b>$noadv Salary Advance Record(s)</b>.</span> Report Generated on ".date("l F d, Y")."</center>";
?>
<div id="divSalAdvNew" class="modal"><div class="container divmodalmain">
  <div class="imgcontainer"><span onclick="document.getElementById('divSalAdvNew').style.display='none'" class="close" title="Close Advance" style="color:#fff;">&times;</span></div><br/>
  <form method="post" action="saladv.php" onsubmit="return verifyData(this)">
    <div class="form-row"><div class="col-md-12 divheadings">NEW SALARY ADVANCE</div></div>
    <div class="form-row">
        <div class="col-md-2"><label for="txtAdvNo">Advance No.</label><input class="modalinput" type="text" name="txtAdvNo" id="txtAdvNo" placeholder="Advance No." value="" readonly/></div>
        <div class="col-md-5"><label for="cboACNo">A/C Issued From</label><SELECT name="cboACNo" id="cboACNo" size="1" class="modalinput" onchange="loadAC(this)"><option value="0" selected>Select A/C</option>
          <?php echo $optac; ?></SELECT></div>
        <div class="col-md-2"></div>
        <div class="col-md-3"><label for="dtpDate">Issued On *</label><input class="modalinput tcal" type="text" name="dtpDate" id="dtpDate" required="required" value="<?php print date("d-m-Y");?>" readonly></div>
    </div><div class="form-row">
        <div class="col-md-9"><label for="cboStf">Issued To*</span></label><select class="modalinput" name="cboStf" id="cboStf" required="required" onchange="findNetSal(this)"><option value="0" selected></option>
          <?php echo $optstf;?></select></div>
        <div class="col-md-3"><label for="txtBal">Net Salary</label><input readonly type="text" name="txtBal" id="txtBal" value="0.00" class="modalinput numbersinput modalinputdisabled"></div>
    </div><div class="form-row">
      <div class="col-md-2"><label for="cboMode">Advanced In *</label><SELECT class="modalinput" size="1" name="cboMode" id="cboMode" required="required" onchange="modeChange(this)"><option value="Cash" selected>
        Cash</option><option value="Cheque">Cheque</option></select></div>
      <div class="col-md-4"><label for="cboACNo">Bank A/C Debited</label><SELECT name="cboBank" id="cboBank" size="1" class="modalinput" onchange="loadBankBal(this)" disabled><option value="0" selected>SELECT A/C
        </option></SELECT></div>
      <div class="col-md-2"><label for="txtModeNo">Cheque No. *</label><input class="modalinput" type="text" name="txtModeNo" id="txtModeNo" placeholder="00001" value="" readonly onkeyup="checkNumber(this)"/></div>
      <div class="col-md-2 divsubheading" style="letter-spacing:0;word-spacing:1px;"><label for="txtCashHand">Cash at Hand</label><Input name="txtCashHand" id="txtCashHand" class="modalinput numbersinput
        modalinputdisabled"  value="<?php echo number_format($cbal,2);?>"></div>
      <div class="col-md-2 divsubheading" style="letter-spacing:0;word-spacing:1px;"><label for="txtCashBank">Cash at Bank</label><Input name="txtCashBank" id="txtCashBank" class="modalinput numbersinput
        modalinputdisabled" value="0.00"></div>
    </div><div class="form-row">
      <div class="col-md-2"><label for="txtAmt">Amount *</label><input class="modalinput numbersinput" type="text" name="txtAmt" id="txtAmt" required="required" placeholder="Amount Issued" value="0.00"
          onkeyup="checkNumber(this)" onchange="calcAmtPerDur()"/></div>
      <div class="col-md-4"><label for="cboDur">Advance To be Recovered in *</label><select class="modalinput" name="cboDur" id="cboDur" required="required" onchange="calcAmtPerDur()">
          <?php for ($i=1;$i<13;$i++) print "<option value=\"$i\" ".($i==1?"selected":"").">".($i==1?"1 Month":"$i Months")."</option>";?>
          </select>
      </div><div class="col-md-3"></div>
      <div class="col-md-3"><label for="txtAmtDur">@ (Kshs. Per Month) *</label><input type="text" name="txtAmtDur" id="txtAmtDur" value="0.00" class="modalinput numbersinput modalinputdisabled"
            readonly/></div>
    </div><div class="form-row">
        <div class="col-md-12"><label for="txtRmks">Narration About Salary Advance *</label><textarea class="modalinput" name="txtRmks" required="required" placeholder="Being salary advance for medical purposes"
          id="txtRmks" rows="2" onkeyup="checkRmks(this)"></textarea></div>
    </div><br>
    <div class="form-row">
        <div class="col-md-4"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSave">Save Changes</button></div>
        <div class="col-md-4"></div>
        <div class="col-md-4" style="text-align:right;"><button type="button" onclick="document.getElementById('divSalAdvNew').style.display='none'" class="btn btn-info btn-md">Close</button></div>
     </div></form>
    </div>
</div>
<script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/saladv.js"></script>
<script type="text/javascript">bankbal.push(<?php echo $lstbankbal;?>); cashbal.push(<?php echo $lstcashbal;?>);</script>
<?php mysqli_close($conn); footer(); ?>
