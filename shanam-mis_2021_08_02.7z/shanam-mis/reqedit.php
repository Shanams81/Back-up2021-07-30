<?php
	include_once('shanam.php');
	if(isset($_POST['CmdNext'])){
	 	$r=isset($_POST['txtReqNo'])?sanitize($_POST['txtReqNo']):"0-0-0-0-0";			$r=preg_split('/\-/',$r);
		$date=isset($_POST['dptDate'])?sanitize($_POST['dtpDate']):date('d-m-Y'); 	$date=preg_split('/\-/',$date);
		$reqtype=isset($_POST['cboType'])?strtoupper(sanitize($_POST['cboType'])):'URGENT';						$acc=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,sanitize($_POST['txtRmks'])):"Requisition for";	$rmks=strtoupper($rmks);
		$dept=isset($_POST['cboUserDept'])?sanitize($_POST['cboUserDept']):1;				$stf=isset($_POST['cboStf'])?sanitize($_POST['cboStf']):'000';
		if (strlen($reqtype)>3 && strlen($rmks)>10 && $acc>0 && $dept>0 && strlen($stf)>4) mysqli_query($conn,"UPDATE acc_req SET reqdate='$date[2]-$date[1]-$date[0]',idno='$stf',
		deptno='$dept',acc='$acc',rmks='$rmks',reqtype='$reqtype',approvedate='$date[2]-$date[1]-$date[0]' WHERE reqno LIKE '$r[0]'") or die(mysqli_error($conn). ". Requisition details
		not saved. Click	<a href=\"reqadd.php?reqno=$r[0]-$r[1]-$r[2]-$r[3]-1\">here</a> to try again.");
		header("location:reqadd.php?reqno=$r[0]-$r[1]-$r[2]-$r[3]-1"); exit(0);
	}elseif (isset($_POST['btnDelReq'])){
		$r=isset($_POST['txtReqNo'])?sanitize($_POST['txtReqNo']):"0-0-0-0-0";			$r=split('/\-/',$r);
		$rmks=isset($_POST['txtDelReason'])?sanitize($_POST['txtDelReason']):"";
		if(strlen($rmks)>0){
			$sql="UPDATE acc_req SET markdel=1,delreason='$rmks' WHERE reqno LIKE '$r[0]';UPDATE acc_reqitems SET markdel=1 WHERE reqno LIKE '$r[0]'; UPDATE acc_reqrej SET markdel=1
			WHERE reqno LIKE '$r[0]';";
			mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)." Requisition details not deleted. Click <a href=\"reqadd.php?reqno=$r[0]-$r[1]-$r[2]-$r[3]-1\">here</a> to try again.");
			while (mysqli_next_result($conn)){;}
		}header("location:reqadd.php?reqno=$r[0]-$r[1]-$r[2]-$r[3]"); exit(0);
	}	$reqno=isset($_REQUEST['reqno'])?$_REQUEST['reqno']:"0";
	mysqli_multi_query($conn,"SELECT r.deptno,r.acc,s.idno,r.reqdate,concat(s.surname,' ',s.onames,' (',s.designation,')') as nam,d.deptname,r.rmks,r.reqtype FROM acc_req r Inner Join
	depts d USING	(deptno) INNER JOIN stf s On (r.idno=s.idno) WHERE r.reqno LIKE '$reqno'; SELECT deptno,deptname FROM depts WHERE markdel=0 ORDER BY deptname ASC; SELECT acno,abbr FROM
	acc_voteacs WHERE markdel=0 and imp_assoc=1; SELECT idno,concat(surname,' ',onames,' (',designation,')') as name FROM stf WHERE markdel=0 and present=1 Order By surname,onames ASC;");
	$i=0; $optDept=$optAcc=$optStf='';
	do{
		if($rs=mysqli_store_result($conn)){
			if ($i==0){list($deptno,$accvote,$idno,$reqdate,$name,$dept,$rmks,$type)=mysqli_fetch_row($rs); $reqdate=preg_split('/\-/',$reqdate);
			}elseif($i==1){ while (list($dno,$dname)=mysqli_fetch_row($rs)) $optDept.="<option value=\"$dno\" ".(strcasecmp($dno,$deptno)==0?"selected":"").">$dname</option>";
			}elseif($i==2){while (list($acno,$acname)=mysqli_fetch_row($rs)) $optAcc.="<option value=\"$acno\" ".(strcasecmp($acno,$accvote)==0?"selected":"").">$acname</option>";
			}else{while (list($id,$idname)=mysqli_fetch_row($rs)) $optStf.="<option value=\"$id\" ".(strcasecmp($id,$idno)==0?"selected":"").">$idname</option>";
			}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css" /><link rel="stylesheet" type="text/css" href="../date/tcal.css" />',0,0,2);
?>
<div class="container divgen">
	<div class="form-row"><div class="col-md-12 divsubheading">REQUISITION EDITOR MANAGER <br><br><b>OFFICER'S ID NO. <?php echo	$idno." &nbsp;&nbsp; ".$name; ?></b></div></div>
	<form name="FrmReq" method="post" action="reqedit.php">
		<div class="form-row"><input name="txtReqNo" id="txtReqNo" type="hidden" value="<?php echo "$reqno-$deptno-$accvote-$idno";?>">
			<div class="col-md-4"><label for="txtReqNo">Type of Requist</label><SELECT name="cboType" id="cboType" size="1" class="modalinput"><Option <?php echo (strcasecmp($type,"Normal")==0?
			"selected":"");?>>Normal</Option><option <?php echo (strcasecmp($type,"urgent")==0?"selected":"");?>>Urgent</option></SELECT></div>
			<div class="col-md-4"></div>
			<div class="col-md-4"><label for="dtpDate">Raised On </label><Input name="dtpDate" id="dtpDate" readonly value="<?php echo "$reqdate[2]-$reqdate[1]-$reqdate[0]";?>"
			class="modalinput tcal"></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="cboStf">Name of Staff Requisitioning *</label><SELECT name="cboStf" id="cboStf" size="1" class="modalinput" required><?php echo $optStf;?>
			</SELECT></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="cboUserDept">Department Requisitioning</label><SELECT name="cboUserDept" id="cboUserDept" size="1" class="modalinput"><?php echo $optDept;?>
			</SELECT></div>
			<div class="col-md-6"><label for="cboAC">A/C to be Costed *</label><SELECT name="cboAC" id="cboAC" size="1" class="modalinput" required><?php echo $optAcc;?></SELECT></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtReqNo">Narration/ Reason for Requisition</label><textarea name="txtRmks" id="txtRmks" class="modalinput" rows="3" maxlength="100"
				id="txtRmks"><?php echo $rmks;?></textarea></div>
		</div><br><hr><br><div class="form-row">
			<div class="col-md-4"><button name="CmdNext" type="submit" class="btn btn-primary btn-md btn-block">Save Changes</button></div>
			<div class="col-md-4" style="text-align:right;"><button name="CmdDel" type="button" class="btn btn-info btn-md" onclick="showDelReason()">Start Delete</button></div>
			<div class="col-md-4" style="text-align:right;"><button name="CmdClear"	type="button" class="btn btn-info btn-md" onclick="window.open('reqadd.php?<?php
			echo "reqno=$reqno-$deptno-$accvote-$idno-1";?>','_self')">Close</button></div>
		</div><br><hr><div class="form-row divlrborder" id="divDelReason" style="display:none;">
			<div class="col-md-9">
				<label for="txtDelReason">Reason for deleting request *</label><textarea name="txtDelReason" rows="3" maxlength="150" class="modalinput" onkeyup="countLength(this)"
				placeholder="The event has been cancelled/ postponed" id="txtDelReason"></textarea>
			</div><div class="col-md-3">
				<div class="form-row"><div class="col-md-12"><button name="btnDelReq" type="submit" class="btn btn-primary btn-sm btn-block" id="btnDelReq" disabled>Complete Delete</button>
				</div></div><br>
				<div class="form-row"><div class="col-md-12"><button name="btnCancel" type="button" class="btn btn-warning btn-sm btn-block disabled" id="btnCancel" onclick="cancelDel()">
					Cancel Delete</button></div></div>
			</div>
		</div></form>
</div>
<script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/reqedit.js"></script>
<?php mysqli_close($conn); footer(); ?>
