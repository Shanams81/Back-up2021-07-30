<?php
	include_once('shanam.php');
	if (isset($_POST['cmdSave'])):
		$itmno=isset($_POST['txtData'])?sanitize($_POST['txtData']):'0-0--0-0';	$itmno=preg_split('/\-/',$itmno); //[0]-itemcode, [1]-reqno,[2]-Dept, [3]-Acc, [4]-ID No.
		$up=isset($_POST['txtUP'])?sanitize($_POST['txtUP']):0; 						$up=preg_replace("/[^0-9^\.]/","",$up);
		$qty=isset($_POST['txtQty'])?sanitize($_POST['txtQty']):0;					$qty=preg_replace("/[^0-9^\.]/","",$qty);
		if($up>0 && $qty>0) mysqli_query($conn,"UPDATE acc_reqitems SET unitprice='$up',approvedup='$up',qty='$qty',approvedqty='$qty' WHERE itmcode LIKE '$itmno[0]' and reqno LIKE
		'$itmno[1]'") or die(mysqli_error($conn). " Item detail not edited. Click <a href=\"reqadd.php?reqno=$itmno[1]-$itmno[2]-$itmno[3]-$itmno[4]-1\">here</a>to go try again.");
		header("location:reqadd.php?reqno=$itmno[1]-$itmno[2]-$itmno[3]-$itmno[4]-1");
	elseif (isset($_POST['cmdDel'])):
		$itmno=isset($_POST['txtData'])?sanitize($_POST['txtData']):'0-0--0-0';	$itmno=preg_split('/\-/',$itmno); //[0]-itemcode, [1]-reqno,[2]-Dept, [3]-Acc, [4]-ID No.
		mysqli_query($conn,"DELETE FROM acc_reqitems WHERE itmcode LIKE '$itmno[0]' and reqno LIKE '$itmno[1]'") or die(mysqli_error($conn). " Item Description
		not deleted. Click <a href=\"reqadd.php?reqno=$itmno[1]-$itmno[2]-$itmno[3]-$itmno[4]-1\">here</a>to go try again.");
		header("location:reqadd.php?reqno=$itmno[1]-$itmno[2]-$itmno[3]-$itmno[4]-1");
	endif;
	$itmno=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; 	$itmno=preg_split('/\-/',$itmno); //itmno[0]-itemcode, [1]-reqno
	$rsReq=mysqli_query($conn,"SELECT r.reqdate,d.deptno,r.acc,s.idno,concat(s.surname,' ',s.onames,' (',s.designation,')') as name,r.rmks,ri.approvedup,ri.approvedqty,
	(ri.approvedup*ri.approvedqty) as amt,concat(i.itemname,' - ',i.units,' @ Kshs.',i.unitprice) as nam FROM acc_req r Inner Join depts d USING (deptno) Inner Join stf s
	On (r.idno=s.idno) Inner Join acc_reqitems ri On (r.reqno=ri.reqno) Inner Join items i On (ri.itmcode=ri.itmcode)	 WHERE ri.reqno LIKE '$itmno[1]' and ri.itmcode LIKE
	'$itmno[0]' and i.itmcode LIKE '$itmno[0]' and ri.markdel=0");
 	list($reqdate,$deptno,$acc,$idno,$stf,$rmks,$up,$qty,$amt,$itm)=mysqli_fetch_row($rsReq); 	mysqli_free_result($rsReq);
	headings('<link href="tpl/css/inputsettings.css" rel="stylesheet" type="text/css">',0,0,2);
?><div class="container divgen" style="font-size:1rem;">
	<div class="form-row"><div class="col-md-12 divsubheading"> REQUISITION RAISED ON <?php echo strtoupper(date('D d M, Y',strtotime($reqdate)))." BY $stf <br>
		FOR <u>$rmks</u>.";?></DIV>
	</div><FORM action="reqitemedit.php" name="Adding" Method="POST" onsubmit="return validateFormOnSubmit(this)">
	<input type="hidden" name="txtData" value="<?php echo "$itmno[0]-$itmno[1]-$deptno-$acc-$idno";?>" id="txtData">
	<div class="form-row"><div class="col-md-12">REQUISITION OF: <?php echo $itm;?></div></div>
	<div class="form-row" style="margin:10px 0;">
		<div class="col-md-4"><label for="txtQty">Quantity Requested *</label><input type="text" name="txtQty" id="txtQty" required maxlength="10"  value="<?php
		echo number_format($qty,2);?>" onkeyup="checkInput(this)" onblur="calcAmt()" class="modalinput numbersinput"></div>
		<div class="col-md-4"><label for="txtUP">Quoted Unit Price</label><INPUT name="txtUP" id="txtUP" required class="modalinput numbersinput" maxlength="10" value="<?php
		echo number_format($up,2);?>"	onkeyup="checkInput(this)" onblur="calcAmt()"></div>
		<div class="col-md-4 divsubheading"><label for="txtTtl">TOTAL AMOUNT</label><input type="text" name="txtTtl" id="txtTtl" class="modalinput modalinputdisabled numbersinput"
		value="<?php echo number_format($amt,2);?>" readonly></div>
	</div><hr><br><div class="form-row">
		<div class="col-md-4"><button name="cmdSave" type="submit" class="btn btn-primary btn-md btn-block">Save Changes</button></div>
		<div class="col-md-4" style="text-align:right;"><button name="cmdDel" type="submit" class="btn btn-info btn-md">Delete Item</button></div>
		<div class="col-md-4" style="text-align:right;"><button name="CmdClear"	type="button" class="btn btn-info btn-md" onclick="window.open('reqadd.php?<?php
		echo "reqno=$itmno[1]-$deptno-$acc-$idno-1";?>','_self')">Close</button></div>
	</div></form>
</div>
<script type="text/javascript" src="tpl/js/reqitemedit.js"></script>
<?php mysqli_close($conn); footer();?>
