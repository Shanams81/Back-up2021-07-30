<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['CmdSave'])){
		$recno=isset($_POST['TxtRecNo'])?trim(strip_tags($_POST['TxtRecNo'])):0; 		$paidby=isset($_POST['CboPaidBy'])?trim(strip_tags($_POST['CboPaidBy'])):'Guardian';	
		$bursno=isset($_POST['TxtBursNo'])?trim(strip_tags($_POST['TxtBursNo'])):Null;	$bursno=strlen($bursno)==0?Null:$bursno;		
		$pytfrm=isset($_POST['CboPytFrm'])?trim(strip_tags($_POST['CboPytFrm'])):'Cash'; 
		$cheno=isset($_POST['TxtCheNo'])?trim(strip_tags($_POST['TxtCheNo'])):Null; 	$cheno=strlen($cheno)==0?Null:strtoupper($cheno);
		$bank=strcasecmp($pytfrm,"cash")==0?None:trim($_POST['CboBank']);				$bank=strcasecmp($bank,"none")==0?Null:$bank; 
		$kind=isset($_POST['TxtKind'])?trim(strip_tags($_POST['TxtKind'])):Null; 		$kind=strlen($kind)==0?Null:strtoupper($kind);
		$bc=isset($_POST['TxtBC'])?trim(strip_tags($_POST['TxtBC'])):0;					$miscamt=isset($_POST['TxtMiscFee'])?trim(strip_tags($_POST['TxtMiscFee'])):0; 	
		$misid=isset($_POST['TxtValID'])?trim(strip_tags($_POST['TxtValID'])):0;		$misqa=isset($_POST['TxtValQA'])?trim(strip_tags($_POST['TxtValQA'])):0;
		$misrem=isset($_POST['TxtValRem'])?trim(strip_tags($_POST['TxtValRem'])):0;		$misht=isset($_POST['TxtValHT'])?trim(strip_tags($_POST['TxtValHT'])):0;
		$misgra=isset($_POST['TxtValGrad'])?trim(strip_tags($_POST['TxtValGrad'])):0;	$mistrip=isset($_POST['TxtValTrip'])?trim(strip_tags($_POST['TxtValTrip'])):0;
		$misuni=isset($_POST['TxtValUni'])?trim(strip_tags($_POST['TxtValUni'])):0;		$misarr=isset($_POST['TxtValArr'])?trim(strip_tags($_POST['TxtValArr'])):0;
		$misole=isset($_POST['TxtValOle'])?trim(strip_tags($_POST['TxtValOle'])):0;		$curuni=isset($_POST['TxtCurUni'])?trim(strip_tags($_POST['TxtCurUni'])):0;
		$curarr=isset($_POST['TxtCurArr'])?trim(strip_tags($_POST['TxtCurArr'])):0;		$bc=preg_replace("/[^0-9^\.]/","",$bc);		$miscamt=preg_replace("/[^0-9^\.]/","",$miscamt); 
		$curuni=preg_replace("/[^0-9^\.]/","",$curuni);		$curarr=preg_replace("/[^0-9^\.]/","",$curarr);
		//misc account voteheads
		$misid=preg_replace('/[^0-9^\.]/','',$misid);  		$misqa=preg_replace('/[^0-9^\.]/','',$misqa); 		$misrem=preg_replace('/[^0-9^\.]/','',$misrem);
		$misht=preg_replace('/[^0-9^\.]/','',$misht); 		$misgra=preg_replace('/[^0-9^\.]/','',$misgra); 	$mistrip=preg_replace('/[^0-9^\.]/','',$mistrip);
		$misuni=preg_replace('/[^0-9^\.]/','',$misuni); 	$misarr=preg_replace('/[^0-9^\.]/','',$misarr);		$misole=preg_replace('/[^0-9^\.]/','',$misole); 
		$miscttl=$misid+$misqa+$misrem+$misht+$misgra+$mistrip+$misuni+$misarr+$misole; 
		//SQL statement to save record
		if ((($miscamt!=$miscttl)) || ((strcasecmp($pytfrm,"Cheque")==0 || strcasecmp($pytfrm,"Direct Banking")==0 || strcasecmp($pytfrm,"Money Order")==0 || strcasecmp($pytfrm,"M-Fees")==0) 
		&& strlen($cheno)==0) || (strcasecmp($pytfrm,"Kind")==0  && strlen($kind)==0)) {
			print "Sorry, the fee receipt record had errors. The reciept was not sucessfully saved. Click <a href=\"feecollection.php\">here</a> to try again";
			exit();
		}
		$i=0;
		if($miscamt>0){
		 	$sql="UPDATE Acc_miscfeepyts SET paidby='$paidby',pytfrm='$pytfrm',cheno=".var_export($cheno,true).",bursaryno=".var_export($bursno,true).",amt='$miscamt',bankcharges='$bc',
			qa='$misqa',idcard='$misid',remedial='$misrem',olevy='$misole',arrears='$misarr',ht='$misht',uni='$misuni',grad='$misgra',acatrip='$mistrip',bank=".var_export($bank,true).",
			kinddescr=".var_export($kind,true)." WHERE recipetno LIKE '$recno'";
			mysqli_query($conn,$sql) or die(mysqli_error($conn).". Misc. Account Fees record not updated. Click <a href=\"feecollection.php\">here</a> to try again."); 
			$i=mysqli_affected_rows($conn);
			if ($i==1 && ($misuni!=$curuni || $misarr!=$curarr)){
			 	$misuni-=$curuni; $misarr-=$curarr;
				mysqli_query($conn,"UPDATE class SET unifrm=(unifrm-$misuni),miscbf=(miscbf-$misarr) WHERE (admno Like '$admno' AND curr_year=year(curdate()))") or die(mysqli_error($conn). 
				" Misc Account Fee Balance Not Updated");
			}
		}
		header("location:feecollection.php?action=1-$i");
	}elseif (isset($_POST['CmdDel'])){
	 	$recno=isset($_POST['TxtRecNo'])?trim(strip_tags($_POST['TxtRecNo'])):0;
	 	mysqli_query($conn,"UPDATE acc_miscfeepyts SET markdel=1 where recipetno LIKE '$recno'"); $i=mysqli_affected_rows($conn);
	 	header("location:feecollection.php?action=2-$i");
	}else{
	 	include_once('tpl/printing.tpl');
	 	$info=isset($_REQUEST['recno']) ? strip_tags($_REQUEST['recno']): "0";
		$rsData=mysqli_query($conn,"SELECT recipetno,payeesno,pytdate,paidby,pytfrm,cheno,bursaryno,amt,bankcharges,qa,idcard,remedial,ht,uni,grad,acatrip,arrears,olevy,bank,kinddescr FROM 
		acc_miscfeepyts WHERE recipetno LIKE '$info'");
		list($recno,$admno,$date,$paidby,$pyfrm,$cheno,$bursno,$amt,$bc,$qa,$id,$rem,$ht,$uni,$gra,$aca,$arr,$ole,$bank,$kind)=mysqli_fetch_row($rsData); mysqli_free_result($rsData);
		$rsMisc=mysqli_query($conn,"SELECT s.admno,s.names,s.cls,s.miscbf,s.unifrm,f.misidcard,f.misqa,f.misremedial,f.misht,f.misgrad,f.mistrip,f.misole,(f.misct3+s.miscbf+s.unifrm+s.arrp
		+s.unf+s.bcp) as ttl,(f.misidcard-idp) as idbal,(f.misqa-qap) as qabal,(f.misremedial-remp) as rembal,(f.misht-htp) as htbal,(f.misgrad-gradp) as gradbal, (f.mistrip-tripp) as 
		tripbal,(f.misole-olep) as olebal,(f.misct3+s.miscbf+s.unifrm-amtp) as bal,s.idp,s.qap,s.remp,s.htp,s.gradp,s.tripp,s.arrp,s.unf,olep,s.ttlp FROM (SELECT s.admno,concat(s.surname,
		' ',s.onames) As names,c.class,concat(c.class,'-',c.stream) As cls,c.curr_year,c.feegrp,c.lvl,c.miscbf,c.unifrm,if(isnull(sqa),0,sqa) as qap,if(isnull(id),0,id) as idp,
		if(isnull(rem),0,rem) as remp,if(isnull(sht),0,sht) as htp,if(isnull(sgrad),0,sgrad) as gradp,if(isnull(trip),0,trip) as tripp,if(isnull(un),0,un) as unf,if(isnull(arr),0,arr) as 
		arrp,if(isnull(ole),0,ole) as olep,if(isnull(bc),0,bc) as bcp,if(isnull(ttl),0,ttl) as ttlp,if(isnull(amtpaid),0,amtpaid) as amtp FROM stud s Inner Join class c USING (admno,
		curr_year) LEFT JOIN (SELECT payeesno,year(pytdate) as yr,sum(qa) as sqa,sum(idcard) as id,sum(remedial) as rem,sum(ht) as sht, sum(grad) as sgrad,sum(acatrip) as trip,sum(uni) as 
		un,sum(arrears) as arr,sum(olevy) as ole,sum(bankcharges) as bc,sum(amt-arrears-uni) as amtpaid,sum(amt+bankcharges) as ttl FROM acc_miscfeepyts GROUP BY payeesno, year(pytdate),
		markdel HAVING (markdel=0 and payeesno LIKE '$admno'))m On (c.admno=m.payeesno and c.curr_year=m.yr) WHERE (c.admno LIKE '$admno'))s Inner Join Acc_feeoutline f USING (curr_year,
		lvl,feegrp)");
		//Retrieve data
		if (mysqli_num_rows($rsMisc)==1) $misc=mysqli_fetch_array($rsMisc,MYSQLI_NUM); mysqli_free_result($rsMisc);
		$rsDet=mysqli_query($conn,"SELECT scnm,scadd FROM ss");
		if (mysqli_num_rows($rsDet)>0){
			$curdate=date('d-m-Y');
			list($scnm,$scadd)=mysqli_fetch_row($rsDet);
		} mysqli_free_result($rsDet);	$candel=0;
		$rsDet=mysqli_query($conn,"SELECT feedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
		list($candel)=mysqli_fetch_row($rsDet); mysqli_free_result($rsDet);
	}
	
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<link rel="shortcut icon" href="img/phone.ico"/>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../date/tcal.css" />
	<script type="text/javascript" src="tpl/miscfeerecedit.js"></script>
	<script type="text/javascript" src="../date/tcal.js"></script>
</head>
<body background="img/bg3.gif" onload="document.feerecs.CboPytFrm.focus();">
	 <?php 
	 	print "<form method=\"post\" action=\"miscfeerecedit.php\" name=\"feerecs\" onsubmit=\"return SaveFeeRecord(this); document.getElementById('CmdSave').disabled=true;
		document.getElementById('CmdSave').value='Please Wait ..';\"><table cellpadding=\"1\" cellspacing=\"0\" align=\"center\" 
		 style=\"border:1px dotted green;border-collapse:collapse;\"><tr><td>";	
		print "<table border=\"0\" cellspacing=\"3\" cellpadding=\"1\" align=\"center\"><tr><td style=\"font-weight:bold;font-size:12px;letter-spacing:3px;word-spacing:4px;\" colspan=\"6\">
		OFFICIAL RECEIPT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".date("D d-M-Y")."</td></tr><tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td align=\"right\"><b>Receipt No.</b></td><td><input type=\"text\" name=\"TxtRecNo\" size=\"12\" maxlength=\"5\" value=\"$recno\" readonly></td><td align=\"right\">
		Admission No.</td><td><Input name=\"TxtAdmNo\" id=\"TxtAdmNo\" size=\"7\" type=\"text\" readonly value=\"$admno\"></td><td align=\"right\">Fees Received On</td><td><input 
		type=\"text\" size=\"15\" name=\"DTPDate\" class=\"tcal\" value=\"".date('d-m-Y',strtotime($date))."\"></td></tr>";
		print "<tr><td align=\"right\">Received From</td><td colspan=\"5\" align=\"left\" style=\"font-weight:normal;font-size:12px; letter-spacing:4px;word-spacing:6px;\" 
		bgcolor=\"#eeeeee\">$misc[1] - Class $misc[2]</td></tr><tr><td align=\"right\">Fee Paid By</td><td><SELECT name=\"CboPaidBy\" size=\"1\"><Option ".(strcasecmp($paidby,"guardian")==0?
		"selected":"").">Guardian</option><Option ".(strcasecmp($paidby,"bursary")==0?"selected":"").">Bursary</option><Option ".(strcasecmp($paidby,"well wisher")==0?"selected":"").">Well 
		Wisher</option></SELECT></td><td align=\"right\">Bursary No.</td><td><input type=\"text\" name=\"TxtBursNo\" value=\"$bursno\" size=\"7\" maxlength=\"4\" readonly></td><td 
		colspan=\"2\">Bursary Balance to be Distributed <input type=\"text\" name=\"TxtBursBal\" size=\"8\" disabled value=\"0.00\" style=\"text-align:right;\"></td></tr>";
		print "<tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td align=\"right\">Fees Received In</td><td><SELECT name=\"CboPytFrm\" id=\"CboPytFrm\" size=\"1\" onchange=\"checkPyt(this)\"><option ".(strcasecmp($pytfrm,"cash")==0?
		"selected":"").">Cash</option><option ".(strcasecmp($pytfrm,"cheque")==0?"selected":"").">Cheque</option><option ".(strcasecmp($pytfrm,"direct banking")==0?"selected":"").">Direct 
		Banking</option><option ".(strcasecmp($pytfrm,"kind")==0?"selected":"").">Kind</option><option ".(strcasecmp($pytfrm,"m-fees")==0?"selected":"").">M-Fees</option><option ".
		(strcasecmp($pytfrm,"money order")==0?"selected":"").">Money Order</option></SELECT></td><td align=\"right\">Trans/ Cheque No.</td><td><input name=\"TxtCheNo\" id=\"TxtCheNo\" 
		size=\"15\" maxlength=\"15\" readonly value=\"$cheno\"></td><td align=\"right\">Cheque's Banker</td><td><SELECT name=\"CboBank\" id=\"CboBank\" size=\"1\" disabled><option ".
		(strlen($bank)==0?"selected":"").">None</option><option ".(strcasecmp($bank,"kcb")==0?"selected":"").">KCB</option><option ".(strcasecmp($bank,"barclays")==0?"selected":"").">
		Barclays</option><option ".(strcasecmp($bank,"cfc stanbic")==0?"selected":"").">CFC Stanbic</option><option ".(strcasecmp($bank,"cooperative")==0?"selected":"").">Cooperative
		</option><option ".(strcasecmp($bank,"equity")==0?"selected":"").">Equity</option><option ".(strcasecmp($bank,"family")==0?"selected":"").">Family</option><option ".
		(strcasecmp($bank,"gulf bank")==0?"selected":"").">Gulf Bank</option><option ".(strcasecmp($bank,"national")==0?"selected":"").">National</option><option ".(strcasecmp($bank,
		"nic")==0?"selected":"").">NIC</option><option ".(strcasecmp($bank,"posta")==0?"selected":"").">Posta</option><option ".(strcasecmp($bank,"standard chartered")==0?"selected":"").">
		Standard Chartered</option><option ".(strcasecmp($bank,"dtb")==0?"selected":"").">DTB</option><option ".(strcasecmp($bank,"bank of africa")==0?"selected":"").">Bank of Africa
		</option></SELECT></td></tr>";
		print "<tr><td align=\"right\">Description of Fee in Kind</td><td colspan=\"5\" align=\"left\"><input name=\"TxtKind\" id=\"TxtKind\" type=\"text\" size=\"100\" maxlength=\"50\" 
		readonly value=\"$kind\"></td></tr><tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td align=\"right\">Misc A/C Fee</td><td><input type=\"text\" name=\"TxtMiscFee\" id=\"TxtMiscFee\" size=\"13\" maxlength=\"10\" value=\"".number_format($amt,2)."\" 
		style=\"text-align:right;\" onKeyUp=\"checkInput(this)\" onchange=\"ttlFees()\" onblur=\"checkMiscBal()\"></td><td align=\"right\">Bank Charges</td><td><INPUT type=\"text\" 
		name=\"TxtBC\" id=\"TxtBC\" size=\"14\" maxlength=\"11\" style=\"text-align:right;\" value=\"".number_format($bc,2)."\" onkeyup=\"checkInput(this)\" onChange=\"ttlFees()\" readonly
		></td><td bgcolor=\"#eeeeee\" align=\"right\" colspan=\"2\"><b>Total Amount Received</b> <input type=\"text\" name=\"TxtTtlFee\" id=\"TxtTtlFee\" size=\"13\" value=\"".
		number_format(($amt+$bc),2)."\" disabled style=\"text-align:right;\"></td></tr><tr><td colspan=\"6\"><hr></td></tr>";
		print "<tr><td colspan=\"6\"><br>";
		print "<table border=\"1\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\"><tr><th></th><th>Votehead</th><th>Expected</th><th>Sum Paid</th><th>Current Balance</th><th>Amount 
		Paid</th><th>Edited Amount</th></tr>";
		print "<tr><td>1.</td><td>ID Card</td><td align=\"center\"><input name=\"TxtExpID\" type=\"text\" size=\"13\" style=\"text-align:right;border:0px;\" disabled value=\"".
		number_format($misc[5],2)."\" id=\"TxtExp0\"></td><td align=\"center\"><input name=\"TxtSumID\" type=\"text\" size=\"13\" style=\"text-align:right;border:0px;\" disabled value=\"".
		number_format($misc[21],2)."\" id=\"TxtSum0\"></td><td align=\"center\"><input name=\"TxtBalID\" type=\"text\" size=\"13\" style=\"text-align:right;\" value=\"".
		number_format($misc[13],2)."\" id=\"TxtBal0\" disabled></td><td align=\"center\"><input name=\"TxtCurID\" type=\"text\" size=\"13\" style=\"text-align:right;\" value=\"".
		number_format($id,2)."\" id=\"TxtCur0\" disabled></td><td align=\"center\"><input name=\"TxtValID\" type=\"text\" size=\"13\" style=\"text-align:right;\" value=\"".
		number_format($id,2)."\" id=\"TxtVal0\" onChange=\"misComputeVote()\" onkeyup=\"checkInput(this)\"></td></tr>";
		print "<tr><td>2.</td><td>Quality Assurance</td><td align=\"center\"><input name=\"TxtExpQA\" type=\"text\" size=\"13\" id=\"TxtExp1\" style=\"text-align:right;border:0px;\" 
		disabled value=\"".number_format($misc[6],2)."\"></td><td align=\"center\"><input name=\"TxtSumQA\" type=\"text\" size=\"13\" id=\"TxtSum1\" style=\"text-align:right;border:0px;\" 
		disabled value=\"".number_format($misc[22],2)."\"></td><td align=\"center\"><input name=\"TxtBalQA\" type=\"text\" size=\"13\" id=\"TxtBal1\" style=\"text-align:right;\" 
		value=\"".number_format($misc[14],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurQA\" type=\"text\" size=\"13\" id=\"TxtCur1\" style=\"text-align:right;\" value=\"".
		number_format($qa,2)."\" disabled></td><td align=\"center\"><input name=\"TxtValQA\" type=\"text\" size=\"13\" id=\"TxtVal1\" style=\"text-align:right;\" value=\"".number_format($qa,
		2)."\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td>3.</td><td>Remedial Studies</td><td align=\"center\"><input name=\"TxtExpRem\" type=\"text\" size=\"13\" id=\"TxtExp2\" style=\"text-align:right;border:0px;\" 
		disabled value=\"".number_format($misc[7],2)."\"></td><td align=\"center\"><input name=\"TxtSumRem\" type=\"text\" size=\"13\" id=\"TxtSum2\" style=\"text-align:right;border:0px;\" 
		disabled value=\"".number_format($misc[23],2)."\"></td><td align=\"center\"><input name=\"TxtBalRem\" type=\"text\" size=\"13\" id=\"TxtBal2\" onkeyup=\"checkInput(this)\" 
		style=\"text-align:right;\" value=\"".number_format($misc[15],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurRem\" type=\"text\" size=\"13\" id=\"TxtCur2\" 
		style=\"text-align:right;\" value=\"".number_format($rem,2)."\" disabled></td><td align=\"center\"><input name=\"TxtValRem\" type=\"text\" size=\"13\" id=\"TxtVal2\" 
		style=\"text-align:right;\" value=\"".number_format($rem,2)."\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td>4.</td><td>Holiday Tuition</td><td align=\"center\"><input name=\"TxtExpHT\" type=\"text\" size=\"13\" id=\"TxtExp3\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[8],2)."\"></td><td align=\"center\"><input name=\"TxtSumHT\" type=\"text\" size=\"13\" id=\"TxtSum3\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[24],2)."\"></td><td align=\"center\"><input name=\"TxtBalHT\" type=\"text\" size=\"13\" id=\"TxtBal3\" disabled style=\"text-align:right;\" value=\"".
		number_format($misc[16],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurHT\" type=\"text\" size=\"13\" id=\"TxtCur3\" style=\"text-align:right;\" value=\"".
		number_format($ht,2)."\" disabled></td><td align=\"center\"><input name=\"TxtValHT\" type=\"text\" size=\"13\" id=\"TxtVal3\" style=\"text-align:right;\" value=\"".number_format($ht,
		2)."\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td>5.</td><td>Graduation Fee</td><td align=\"center\"><input name=\"TxtExpGrad\" type=\"text\" size=\"13\" id=\"TxtExp4\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[9],2)."\"></td><td align=\"center\"><input name=\"TxtSumGrad\" type=\"text\" size=\"13\" id=\"TxtSum4\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[25],2)."\"></td><td align=\"center\"><input name=\"TxtBalGrad\" type=\"text\" size=\"13\" id=\"TxtBal4\" disabled style=\"text-align:right;\" value=\"".
		number_format($misc[17],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurGrad\" type=\"text\" size=\"13\" id=\"TxtCur4\" disabled style=\"text-align:right;\" value=\"".
		number_format($gra,2)."\"></td><td align=\"center\"><input name=\"TxtValGrad\" type=\"text\" size=\"13\" id=\"TxtVal4\" style=\"text-align:right;\" value=\"".number_format($gra,2).
		"\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td>6.</td><td>Academic Trip</td><td align=\"center\"><input name=\"TxtExpTrip\" type=\"text\" size=\"13\" id=\"TxtExp5\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[10],2)."\"></td><td align=\"center\"><input name=\"TxtSumTrip\" type=\"text\" size=\"13\" id=\"TxtSum5\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[26],2)."\"></td><td align=\"center\"><input name=\"TxtBalTrip\" type=\"text\" size=\"13\" id=\"TxtBal5\" disabled style=\"text-align:right;\" value=\"".
		number_format($misc[18],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurTrip\" type=\"text\" size=\"13\" id=\"TxtCur5\" style=\"text-align:right;\" disabled value=\"".
		number_format($aca,2)."\"></td><td align=\"center\"><input name=\"TxtValTrip\" type=\"text\" size=\"13\" id=\"TxtVal5\" style=\"text-align:right;\" value=\"".number_format($aca,2).
		"\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td>7.</td><td>Uniform</td><td align=\"center\"><input name=\"TxtExpUni\" type=\"text\" size=\"13\" id=\"TxtExp7\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format(($misc[4]+$misc[28]),2)."\"></td><td align=\"center\"><input name=\"TxtSumUni\" type=\"text\" size=\"13\" id=\"TxtSum7\" style=\"text-align:right;
		border:0px;\" disabled value=\"".number_format($misc[28],2)."\"></td><td align=\"center\"><input name=\"TxtBalUni\" type=\"text\" size=\"13\" id=\"TxtBal7\" disabled 
		style=\"text-align:right;\" value=\"".number_format($misc[4],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurUni\" type=\"text\" size=\"13\" id=\"TxtCur7\" 
		style=\"text-align:right;\" value=\"".number_format($uni,2)."\" disabled></td><td align=\"center\"><input name=\"TxtValUni\" type=\"text\" size=\"13\" id=\"TxtVal7\" 
		style=\"text-align:right;\" value=\"".number_format($uni,2)."\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td>8.</td><td>Misc. Arrears</td><td align=\"center\"><input name=\"TxtExpArr\" type=\"text\" size=\"13\" id=\"TxtExp8\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format(($misc[3]+$misc[27]),2)."\"></td><td align=\"center\"><input name=\"TxtSumArr\" type=\"text\" size=\"13\" id=\"TxtSum8\" style=\"text-align:right;
		border:0px;\" disabled value=\"".number_format($misc[23],2)."\"></td><td align=\"center\"><input name=\"TxtBalArr\" type=\"text\" size=\"13\" id=\"TxtBal8\" disabled 
		style=\"text-align:right;\" value=\"".number_format($misc[3],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurArr\" type=\"text\" size=\"13\" id=\"TxtCur8\" 
		style=\"text-align:right;\" value=\"".number_format($arr,2)."\" disabled></td><td align=\"center\"><input name=\"TxtValArr\" type=\"text\" size=\"13\" id=\"TxtVal8\" 
		style=\"text-align:right;\" value=\"".number_format($arr,2)."\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td>9.</td><td>Other Levies</td><td align=\"center\"><input name=\"TxtExpOle\" type=\"text\" size=\"13\" id=\"TxtExp6\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[11],2)."\"></td><td align=\"center\"><input name=\"TxtSumOle\" type=\"text\" size=\"13\" id=\"TxtSum6\" style=\"text-align:right;border:0px;\" disabled 
		value=\"".number_format($misc[29],2)."\"></td><td align=\"center\"><input name=\"TxtBalOle\" type=\"text\" size=\"13\" id=\"TxtBal6\" disabled style=\"text-align:right;\" value=\"".
		number_format($misc[19],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCurOle\" type=\"text\" size=\"13\" id=\"TxtCur6\" style=\"text-align:right;\" disabled value=\"".
		number_format($ole,2)."\"></td><td align=\"center\"><input name=\"TxtValOle\" type=\"text\" size=\"13\" id=\"TxtVal6\" style=\"text-align:right;\" value=\"".number_format($ole,2).
		"\" onkeyup=\"checkInput(this)\" onChange=\"misComputeVote()\"></td></tr>";
		print "<tr><td colspan=\"2\"><b>Total Amount (Kshs.)</b></td><td align=\"center\"><input name=\"TxtExp\" type=\"text\" size=\"10\" id=\"TxtExp\" style=\"text-align:right;border:0px;
		font-weight:bold;\" disabled value=\"".number_format($misc[12],2)."\"></td><td align=\"center\"><input name=\"TxtSum\" type=\"text\" size=\"10\" id=\"TxtSum\" 
		style=\"text-align:right;border:0px;font-weight:bold;\" disabled value=\"".number_format($misc[30],2)."\"></td><td align=\"center\"><input name=\"TxtBal\" type=\"text\" size=\"10\" 
		id=\"TxtBal\" style=\"text-align:right;border:0px;font-weight:bold;\" value=\"".number_format($misc[20],2)."\" disabled></td><td align=\"center\"><input name=\"TxtCur\" type=\"text\" 
		size=\"10\" id=\"TxtCur\" style=\"text-align:right;border:0px;font-weight:bold;\" disabled value=\"".number_format(($amt+$bc),2)."\"></td><td align=\"center\"><input 
		name=\"TxtVal\" type=\"text\" size=\"10\" id=\"TxtVal\" style=\"text-align:right;border:0px;font-weight:bold;\" value=\"".number_format(($amt+$bc),2)."\" readonly></td></tr>";
		print "<tr><td colspan=\"7\" align=\"center\">Balance To Be Distributed: <input type=\"text\" name=\"TxtVoteBal\" id=\"TxtVoteBal\" size=\"13\" value=\"0.00\" 
		style=\"text-align:right;border:0px;font-weight:bold;color:#AA0000;\" readonly></td></tr></table></td></tr></table></td></tr>";
		print"<tr><td align=\"right\" valign=\"top\" style=\"color:#AA0000;font-weight:bold;\">Total Fees Amount (Words) <TEXTAREA name=\"TxtWords\" id=\"TxtWords\" cols=\"65\" rows=\"3\" 
		style=\"border:0px;font-weight:bold;color:#AA0000;\" readonly value=\"0.00\">".NumToWord(preg_replace("/\,/","",number_format(($amt+$bc),2)))."</textarea></td></tr>";
		print "<tr><td><center><br><button type=\"submit\" name=\"CmdSave\" id=\"CmdSave\">Save Fee Record</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type=\"submit\" name=\"CmdDel\" id=\"CmdDel\" onclick=\"return areSure()\" ".($candel==0?"disabled":"").">Delete Record</button>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"feecollection.php\" target=\"det\"><button 
		type=\"button\" name=\"close\">Cancel/ Close</button></center></td></tr></table>";
	?>
	</form>
</body>
</html>
<?php
	mysqli_close($conn);
?>