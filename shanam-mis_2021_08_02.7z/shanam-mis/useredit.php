<?php
	session_start();
	if (!(isset($_SEESION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if(isset($_POST['CmdClose'])){
		header("location:users.php?action=0-0");
	}elseif(isset($_POST['CmdSave'])){
	 	$idno=isset($_POST['CboUser'])?$_POST['CboUser']:''; 			$ln=isset($_POST['TxtUsername'])?$_POST['TxtUsername']:''; 
		$sec=isset($_POST['CboPriv'])?$_POST['CboPriv']:'1';			$title=isset($_POST['CboTitle'])?$_POST['CboTitle']:'Member'; 
		$expdate=date("Y-m-d",strtotime("+2days"));						$orig=isset($_POST['TxtOrig'])?$_POST['TxtOrig']:'';   	
		$addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
		if (($idno=='') || ($ln=='') || ($orig=='')){
			print "Ensure you have selected user, entered login name and password before saving";
		}else{
			mysqli_query($conn,"UPDATE login SET username='$ln',section='$sec',expirydate='$expdate',idno='$idno',priviledge='$title',addedby='$addby' 
			WHERE username LIKE '$orig'") or die(mysqli_error($conn)." User details not updated. Click <a href=\"users.php?action=0-0\">Here</a> to try again.");
			$i=mysqli_affected_rows($conn);
			if ($i==1){
				mysqli_query($conn,"UPDATE gen_priv SET uname='$ln' WHERE uname LIKE '$orig'");
				mysqli_query($conn,"UPDATE acc_priv SET uname='$ln' WHERE uname LIKE '$orig'");
			}
			header("location:users.php?action=1-$i");
		}
	}else{
		$s=$_REQUEST['action'];   $s=isset($s)?$s:'0';
        $rsUser=mysqli_query($conn,"SELECT username,priviledge,idno,section FROM login WHERE username LIKE '$s'");
        list($ln,$priv,$idno,$sec)=mysqli_fetch_row($rsUser); mysqli_free_result($rsUser);
        $ln=isset($ln)?$ln:'';  $priv=isset($priv)?$priv:'';  $idno=isset($idno)?$idno:'';  $sec=isset($sec)?$sec:'Accounts';
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>System Users</title>
		<script type="text/javascript" src="tpl/useredit.js"></script>
		<STYLE type="text/css">
			table{border:3px solid green;border-collapse:collapse; border:outset 3px;font-size:12px;}
			td,th{letter-spacing:1.5px;word-spacing:2px;border-right:hidden;border-left:hidden;border-top:hidden;border-bottom:hidden;}
		</style>
    </head>
<body background="img/bg3.gif">
	<?php
        print "<form method=\"post\" action=\"Useredit.php\" onsubmit=\"return validateData(this);\"><input type=\"hidden\" name=\"TxtOrig\" value=\"$ln\"><table 
		border=\"0\" cellpadding=\"2\" cellspacing=\"2\" align=\"center\"><tr><th colspan=\"3\"><h2>AUTHETIC SYSTEM USER MANAGEMENT</h2></th></tr><tr><td 
		align=\"right\">Choose Staff Member</td><td><SELECT name=\"CboUser\" size=\"1\">";
    	$rsUser=mysqli_query($conn,"SELECT idno,concat(surname,' ',onames,' (',designation,')') as st FROM stf WHERE (markdel=0 and present=1) ORDER BY surname,onames Asc");
        while ($dat=mysqli_fetch_row($rsUser)) print "<Option value=\"$dat[0]\" ".(strcasecmp($idno,$dat[0])==0?"Selected":"").">$dat[1]</option>";
        mysqli_free_result($rsUser);
        print "</SELECT></td><td rowspan=\"2\" valign=\"middle\"><button name=\"CmdSave\">Save User<br>Details</button></td></tr>";
        print "<tr><td align=\"right\">Login User Name (4 - 12 Characters)</td><td><input type=\"text\" name=\"TxtUsername\" value=\"$ln\" size=\"15\" 
		maxlength=\"12\"></td></tr><tr><td align=\"right\">User Password (4 - 12 Characters)</td><td><input type=\"password\" name=\"TxtPassword\" size=\"15\" 
		maxlength=\"12\" value=\"0000000000000\" disabled></td><td rowspan=\"3\" valign=\"middle\"><button name=\"CmdClose\">Close<br>Form</button></td></tr>";
        print "<tr><td align=\"right\">User Section</td><td><SELECT name=\"CboPriv\" size=\"1\"><Option value=\"0\" ".(strcasecmp($sec,"0")==0?"selected":"").">
		0 - Admin</option><Option value=\"1\" ".(strcasecmp($sec,"1")==0?"selected":"").">1 - Accounts</option><Option value=\"2\"  ".(strcasecmp($sec,"2")==0?
		"selected":"").">2 - Exams</option><Option value=\"3\"  ".(strcasecmp($sec,"3")==0?"selected":"").">3 - Stores</option><Option value=\"4\" ".
		(strcasecmp($sec,"4")==0?"selected":"").">4 - Discipline</option><Option value=\"5\" ".(strcasecmp($sec,"5")==0?"selected":"").">5 - Guiding And Counselling
		</option><Option value=\"6\" ".(strcasecmp($sec,"6")==0?"selected":"").">6 - Library Services</option></SELECT></td></tr>";
		print "<tr><td align=\"right\">User's Title</td><td><SELECT name=\"CboTitle\" size=\"1\"><option ".(strcasecmp($priv,"Accounts Clerk")==0?"Selected":"").">Accounts Clerk</option>
		<option ".(strcasecmp($priv,"Bursar")==0?"Selected":"").">Bursar</option><option ".(strcasecmp($priv,"Class teacher")==0?"Selected":"").">Class Teacher</option><option ".
		(strcasecmp($priv,"Deputy Principal")==0?"Selected":"").">Deputy Principal</option><option ".(strcasecmp($priv,"Director")==0?"Selected":"").">Director</option><option ".
		(strcasecmp($priv,"principal")==0?"Selected":"").">Principal</option><option ".(strcasecmp($priv,"Senior Teacher")==0?"Selected":"").">Senior Teacher</option><option ".
		(strcasecmp($priv,"Librarian")==0?"Selected":"").">Librarian</option><option ".(strcasecmp($priv,"Store keeper")==0?"Selected":"").">Store Keeper</option>
		<option ".(strcasecmp($priv,"hod")==0?"Selected":"").">HOD</option><option ".(strcasecmp($priv,"member")==0?"Selected":"").">Member</option><option ".
		(strcasecmp($priv,"Secretary")==0?"Selected":"").">Secretary</option></select></td></tr></table>";
        mysqli_close($conn);		
	?>
</body>
</html>