<?php
	include_once('shanam.php');
	if(isset($_POST['btnSave'])){
        $tkn=isset($_POST['txtTkn'])?sanitize($_POST['txtTkn']):0;					$recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0;
        $date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('d-m-Y');	$date=preg_split('/\-/',$date);	$date=$date[2].'-'.$date[1].'-'.$date[0];
        $ac=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0;						$voteno=isset($_POST['cboVotes'])?sanitize($_POST['cboVotes']):0;
        $mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'EFT';			$modeno=isset($_POST['txtModeNo'])?sanitize($_POST['txtModeNo']):null;
        $rmks=isset($_POST['txtRmks'])?strtoupper(sanitize($_POST['txtRmks'])):null;
        $amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0; 	$modeno=strlen($modeno)>0?$modeno:null;
        $bank=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;				$amt=preg_replace('/[^0-9\.]/','',$amt);
        if($_SESSION['tkn']!=$tkn || $ac==0 || $voteno==0 || $bank==0 || (strcasecmp($mode,'cheque')==0 && strlen($modeno)==0) || $amt<1 || strlen($rmks)<11){
                echo 'FSE Receipt Grant has errors. Can not be saved as entered. Click <a href="fseothergrants.php">HERE</a> to go back'; unset($_SESSION['tkn']); exit(0);
        }else{
            $sql="INSERT INTO acc_fseincome(recno,noofstud,recon,batchno,acc,acsno,amt,mode,modeno,rmks,commt,addedby) VALUES (0,1,'$date',null,$ac,$bank,$amt,'$mode',".
            var_export($modeno,true).",".var_export($rmks,true).",4,'".$_SESSION['username']." (".$_SESSION['priviledge'].")')";
            if(mysqli_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fsefees.php">HERE</a> to go back')){
                $rs=mysqli_query($conn,"SELECT last_insert_id()"); list($recno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
                $sql="INSERT INTO acc_fsevotes (recno,acc,voteno,amt) VALUES ('$recno','$ac','$voteno','$amt');";
                $sql.="INSERT INTO acc_banking (sno,transdate,bank_type,acsno,amt,rmks,transtype,transno,addedby) VALUES(0,'$date',0,$bank,$amt,'FSE Grant Income',0,$recno,
								'".$_SESSION['username']." (".$_SESSION['priviledge']."');";
                mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fseothergrants.php">HERE</a> to go back'); $i=0;
                do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $act[1]=($i>0?1:0); $act[0]=1;
            }else{$act[0]=0;$act[1]=0;} unset($_SESSION['tkn']);
        }
	}else{$act=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0';	$act=preg_split('/\-/',$act);}
	mysqli_multi_query($conn,"SELECT gofeeview,gofeeedit,gofeeadd FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT a.sno,concat(b.abbr,' - A/C ',a.accno) as acc FROM acc_accounts a Inner Join acc_banks b
	ON (a.bankno=b.sno) WHERE accacc IN (SELECT * FROM (SELECT acno from acc_voteacs WHERE stud_assoc=0 ORDER BY acno ASC LIMIT 0,1)e); SELECT acno,descr from acc_voteacs WHERE stud_assoc=0 ORDER BY acno ASC; SELECT v.sno,
	v.descr FROM acc_votes v WHERE other_inco=1 and acc IN (SELECT * FROM (SELECT acno from acc_voteacs WHERE	govt_assoc=1 ORDER BY	acno ASC LIMIT 0,1)e);") or	die(mysqli_error($conn).". Click <a href=\"fsegrants.php\">HERE
	</a> to go back.");
	$i=$viu=$edit=$add=0; $optAC=$optBanks=$optVotes='';
	do{
      if($rs=mysqli_store_result($conn)){
          if($i==0){if(mysqli_num_rows($rs)>0) list($viu,$edit,$add)=mysqli_fetch_row($rs);
          }elseif($i==1){if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $optBanks.="<option value=\"$d[0]\">$d[1]</option>";
          }elseif($i==2){if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $optAC.="<option value=\"$d[0]\">$d[1]</option>";
          }else{if(mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)) $optVotes.="<option value=\"$d[0]\">$d[1]</option>";
          }mysqli_free_result($rs);
      }$i++;
	}while(mysqli_next_result($conn));	$_SESSION['tkn']=$tkn=uniqid();
	if($viu==0) header("location:vague.php");
	$sdate=isset($_POST['dtpStart'])?sanitize($_POST['dtpStart']):(date("Y")."-01-01"); $sdate=preg_split('/\-/',$sdate); 	$sdate=$sdate[2].'-'.$sdate[1].'-'.$sdate[0];
	$edate=isset($_POST['dtpEnd'])?sanitize($_POST['dtpEnd']):date("Y-m-d");			$edate=preg_split('/\-/',$edate); 	$edate=$edate[2].'-'.$edate[1].'-'.$edate[0];
	headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css"/><link href="tpl/css/modalfrm.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="/date/tcal.css"/><link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css"/>',$act[0],$act[1],2);
?>
<div class="head" style="text-align:center;"><form method="post" action="fseothergrants.php"><a href="fsegrants.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20"
	align="left"></a>&nbsp; FSE Grants Received Between&nbsp;<input name="dtpStart" class="tcal" type="text" value="<?php echo $sdate; ?>" readonly size="9">&nbsp;&nbsp;And &nbsp;<input
	name="dtpEnd" class="tcal" type="text" value="<?php echo $edate; ?>" readonly size="9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" accesskey="s" name="Show">View FSE Grants
	</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" accesskey="r" name="Show" <?php echo ($add==0?"disabled":"");?> onclick="receiveFSE()">Receive FSE Grants</button></a></form>
</div><div class="container" style="background-color:#e6e6e6;border-radius:20px;max-width:950px;padding:5px;margin:5px auto 5px auto;">
<?php
  print "<h6 style=\"letter-spacing:2px;word-spacing:3px;text-align:center;font-size:12pt;color:#000;text-decoration:underline overline double #000\">OTHER FSE GRANTS
	RECEIVED BETWEEN ".strtoupper(date("D d M, Y", strtotime($sdate))." and ".date("D d M, Y",strtotime($edate)))."</h6>";
	$fee=mysqli_query($conn,"SELECT f.recno,f.recon,f.acc,concat(a.abbr, ' (',v.descr,')') as acname,f.mode,f.modeno,concat(b.abbr,' A/C No.', ac.accno) as bank,f.rmks,f.amt FROM
	acc_fseincome f	INNER JOIN acc_fsevotes fv USING (recno,acc) Inner Join acc_votes v ON (fv.voteno=v.sno and fv.Acc=v.acc) INNER JOIN acc_accounts ac On (f.acsno=ac.sno) Inner Join
	acc_banks b On	(ac.bankno=b.sno) Inner Join acc_voteacs a On (f.acc=a.acno) WHERE f.markdel=0 AND f.commt=4 and (f.recon BETWEEN '".date('Y-m-d',strtotime($sdate))."' and
	'".date('Y-m-d',strtotime($edate))."') Order By recno Asc;");
	print "<table class=\"table table-striped table-hover table-bordered table-sm\"><thead class=\"thead-dark\"><tr><th>Receipt</th><th>Received On</th><th>Votehead A/C</th><th>Mode</th>
	<th>Mode No.</th><th>Bank A/C Credited</th><th>Narration of the Grant</th><th>Amount</th><th colspan=\"2\">Receipt</th></tr></thead><tbody>";
	$i=0; $ttl=0; $nor=mysqli_num_rows($fee);
	if ($nor>0):
		while (list($rec,$dat,$acc,$acname,$mode,$modeno,$bank,$rmk,$amt)=mysqli_fetch_row($fee)):
			$days=(strtotime(date('Y-m-d'))-strtotime($dat))/86400;
			print "<tr></tr><td>$rec</td><td>".date("D d M, Y",strtotime($dat))."</td><td>$acname</td><td>$mode</td><td>$modeno</td><td>$bank</td><td>$rmk</td><td align=\"right\">".
			number_format($amt,2)."</td><td align=\"center\">".($days<14?"<a onclick=\"return canEdit($edit)\" href=\"fsegrantedit.php?rec=$rec-$acc-".uniqid()."\"><img
			src=\"../gen_img/edit.ico\" width=18 height=16 title=\"Edit Receipt\"></a>":"")."</td><td align=\"center\"><a href=\"rpts/fsereceipt.php?rec=$rec-$acc\" target=\"_BLANK\">
			<img src=\"../gen_img/print.ico\" width=18 height=16 title=\"Print Receipt\"></a></td></tr>";		$ttl+=$amt;  $i++;
		endwhile;
	else:
		print "<tr><td colspan=\"10\><br>There are no other FSE grants received between ".date("D d M, Y", strtotime($sdate))." and ".date("D d M, Y",strtotime($edate))."<br>.</td></tr>";
	endif; mysqli_free_result($fee);
	print "</tbody><tfoot><tr><th colspan=\"6\">$nor Other FSE Grant(s)</th><th align=\"right\">Subtotals (Kshs.)</th><th align=\"right\">".number_format($ttl,2)."</th>";
?><th colspan="2"></th></tr></tfoot></table></div>
<div id="FSEIncome" class="modal">
	<div class="imgcontainer"><span onclick="document.getElementById('FSEIncome').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
	<div class="container divlrborder" style="font-size:12pt;background-color:#bbe1fa;padding:5px;max-width:700px;"><form name="frmNewIncome" method="post" action="fseothergrants.php"
		onsubmit="return validateData(this)"><INPUT name="txtTkn"	type="hidden" size=4 value="<?php echo $tkn;?>" id="txtTkn">
		<div class="form-row"><div class="col-md-12 divheadings">OTHER FSE GRANTS RECEIPT MANAGER</div></div>
		<div class="form-row"><div class="col-md-6"><label for="txtRecNo">Receipt No. *</label><input type="text" name="txtRecNo" id="txtRecNo" readonly value="" placeholder="Auto"
			class="modalinput modalinputdisabled"></div><div
			class="col-md-6"><label for="dtpDate">Received On *</label><input type="text" name="dtpDate" id="dtpDate" readonly value="<?php echo date('d-m-Y',strtotime($edate));?>"
			class="tcal modalinput modalinputdisabled"></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="cboAC">Votehead A/C Credited *</label><SELECT name="cboAC" id="cboAC" onchange="loadVotehead(this)" size=1 class="modalinput"><?php
			echo $optAC;?></SELECT></div>
			<div class="col-md-6"><label for="cboVotes">Votehead Credited *</label><span id="spVotes"><SELECT name="cboVotes" id="cboVotes" size=1 class="modalinput"><?php echo $optVotes; ?>
			</SELECT></span></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="cboMode">Grant Received In *</label><SELECT name="cboMode" id="cboMode" size="1" class="modalinput"><option value="EFT" selected>Electronic Fund
				Transfer</option><option value="CHEQUE">Cheque</option></SELECT></div><div class="col-md-6"><label for="txtModeNo">Transaction/ Cheque No.</label><input type="text"
					class="modalinput" name="txtModeNo" id="txtModeNo" readonly value=""></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtRmks">Narration about the Grant *</label><textarea name="txtRmks" id="txtRmks" rows=3 placeholder="FUNDS TO BUILD CLASSROOMS AND LABORATORY"
			class="modalinput"></textarea></div>
		</div><div class="form-row">
			<div class="col-md-6"><label for="cboBank">Bank A/C Credited *</label><span id="spBankAC"><SELECT name="cboBank" id="cboBank" size=1 class="modalinput"><?php echo $optBanks;?>
			</SELECT></span></div>
			<div class="col-md-6"><label for="txtAmt">Amount Received *</label><input type="text" name="txtAmt" id="txtAmt" value="0.00" maxlength=13 class="modalinput numbersinput"
				onkeyup="checkData(this)" onblur="distributeVotes(this)"></div>
		</div><hr style="border:0;border-top:1px dashed #fff;height:0px;">
		<div class="form-row">
			<div class="col-md-6"><button type="submit" class="btn btn-primary btn-block btn-md" name="btnSave">Save Changes</button></div><div class="col-md-6" style="text-align:right;"><button
				type="button"	onclick="document.getElementById('FSEIncome').style.display='none'" class="btn btn-info btn-md">Close</button></div>
		</div><div class="form-row"><div class="col-md-12"><span id="spDelete"></span></div></div>
	</div></form>
</div></div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/fseothergrants.js"></script>
<?php mysqli_close($conn); footer(); ?>
