<?php
    include_once('shanam.php'); include_once('tpl/printing.tpl');
    class objArrears{
        private $yr,$cls,$arr;
        public function __construct($y,$c,$ar){$this->yr=$y; $this->cls=$c; $this->arr=$ar;} public function valCls(){return $this->cls;} public function valYr(){return $this->yr;}
        public function valArr(){return $this->arr;}
    }if(isset($_POST['btnSaveFee'])){
        $token=isset($_POST['txtToken'])?sanitize($_POST['txtToken']):'0-0-0-0';  $bursno=isset($_POST['txtBursNo'])?sanitize($_POST['txtBursNo']):null; $admno=isset($_POST['txtAdmNo'])?sanitize($_POST['txtAdmNo']):null;
        $date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('d-m-Y'); $paidby=isset($_POST['cboPaidBy'])?sanitize($_POST['cboPaidBy']):"Parent";$bursbal=isset($_POST['txtBursBal'])?sanitize($_POST['txtBursBal']):0;
        $pytfrm=isset($_POST['txtBursBal'])?sanitize($_POST['cboPytFrm']):null;   $cheno=isset($_POST['txtBursBal'])?strtoupper(sanitize($_POST['txtCheNo'])):null;$amt=isset($_POST['txtFee_0'])?sanitize($_POST['txtFee_0']):0;
        $bankno=isset($_POST['txtBursBal'])?sanitize($_POST['cboBank']):null;     $bc=isset($_POST['txtBC'])?sanitize($_POST['txtBC']):0;            $nov=isset($_POST['txtNoV'])?sanitize($_POST['txtNoV']):0;
        $idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):null;          $telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):null;$kind=isset($_POST['txtKind'])?strtoupper(sanitize($_POST['txtKind'])):null;
        $parent=isset($_POST['txtParent'])?strtoupper(sanitize($_POST['txtParent'])):null;    $addr=isset($_POST['txtAddress'])?strtoupper(sanitize($_POST['txtAddress'])):null;
        $addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')'; $recno=isset($_POST['txtAddress'])?sanitize($_POST['txtRecNo']):0;
        $tkn=preg_split('/\-/',$token); //[0] 0-New 1-Edit, [1] Token,[2] RecSNo [3] 0 - Alumni 1 Feecollection
        if(strlen($bursno)==0){$bursno=NULL;}   if(strlen($admno)==0){$admno=0;}  if(strlen($bursbal)==0){$bursbal=0;}  if(strlen($pytfrm)==0){$pytfrm='DIRECT BANKING';}   if(strlen($cheno)==0){$cheno=null;}
        if(strlen($bankno)==0 || $bankno==0){$bankno=null;}   if($amt===NULL){$amt=0;}else{$amt=preg_replace('/[^0-9\.]/','',$amt);}  if($bc===NULL){$bc=0;}else{$bc=preg_replace('/[^0-9\.]/','',$bc);}
        if($nov===NULL || $nov==false){$nov=0;} if($idno===NULL || $idno===false){$idno=null;}  if($telno===NULL || $telno===false){$telno=null;}  if($kind===NULL || $kind===false){$kind=null; } else $kind=addslashes($kind);
        if($parent===NULL || $parent===false){$parent=null;}  if($addr===NULL || $addr===false){$addr=null;}   $date=explode('-',$date);  $date="$date[2]-$date[1]-$date[0]";  if($recno===NULL || $recno==false){$recno=0;}
        if ($amt<1 || $admno<1 || ((strcasecmp($pytfrm,"Cash")!=0 && strcasecmp($pytfrm,"Kind")!=0) && strlen($cheno)==0) || (strcasecmp($pytfrm,"Kind")==0  && strlen($kind)<10 && strlen($idno)<7 && strlen($parent)<8
        && strlen($telno)<9) || ((strcasecmp($pytfrm,"cheque")==0 || strcasecmp($pytfrm,"direct banking")==0) && (is_null($bankno) || is_null($cheno))) || (strcasecmp($pytfrm,"mfees")==0 && is_null($cheno)) ||
        ($_SESSION['form_token']!=$tkn[1])){
            print "Sorry, the alumni arrears recovery record had errors. The reciept was not sucessfully saved. <br>Click <a href=\"alumni.php\">HERE</a> to try again";
            unset($_SESSION['form_token']);  exit(0);
        }else{
          unset($_SESSION['form_token']);
          if($tkn[0]==0){ $voteno=0; //New record
              $sql="INSERT INTO acc_incofee(sno, admno, pytdate, paidby, pytfrm, cheno, bursno, bankno, kinddescr, addedby) VALUES(0,'$admno','$date','$paidby','$pytfrm',".var_export($cheno,true).
              ",".var_export($bursno,true).",".var_export($bankno,true).",".var_export($kind,true).",'$addby')";
              if (mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"alumni.php\">HERE</a> to try again.")){$sno=mysqli_insert_id($conn); $ttlamt=0;
                  $sql="INSERT INTO acc_incorecno0 (recno,sno,acc,bc,amt,arrears) VALUES (0,$sno,1,$bc,$amt,$amt);";
                  if(mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"alumni.php\">HERE</a> to try again.")){$recno=mysqli_insert_id($conn); $sql='';
                      for($a=0;$a<$nov;$a++){ $vamt=isset($_POST["txtAmt_$a"])?sanitize($_POST["txtAmt_$a"]):0;   //:0;     $vamt=preg_replace('/[^0-9\.]/','',$vamt);
                        if ($vamt>0){$v=isset($_POST["txtYr_$a"])?sanitize($_POST["txtYr_$a"]):'0-0';     $v=explode('-',$v);
                          $sql.="INSERT INTO acc_incovotes(recno,acc,voteno,amt,markdel) VALUES ($recno,1,$v[1],$vamt,0);UPDATE class SET alumniarrears=alumniarrears-$vamt WHERE admno LIKE '$admno' and curr_year LIKE
                          '$v[0]'; INSERT INTO acc_arrrefclr(clrno,recno,arr_year,ac,clron,admno,amt,transtype) VALUES (0,$recno,$v[0],1,'$date','$admno',$vamt,0);";
                        }
                      }if (strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"alumni.php\">HERE </a> to go back."); while(mysqli_next_result($conn)){}}
                  }if(strlen($kind)>0 && $amt>0){//Fee payment in kind
                    mysqli_multi_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno';SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '1';"); $i=$payno=$vote=0;
                    do{if($rs=mysqli_store_result($conn)){if($i==0){$no=mysqli_num_rows($rs); if ($no>0) list($payno)=mysqli_fetch_row($rs);}else{$no=mysqli_num_rows($rs);
                      if ($no>0) list($vono)=mysqli_fetch_row($rs);}  mysqli_free_result($rs);
                    }$i++;
                    }while(mysqli_next_result($conn)); $vono++;
                    if($payno==0){//paye details are not in the system
                        if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES(0,'$date','$parent','$idno',".var_export($addr,true)."'$telno','$addby')")){
                            $payno=mysqli_insert_id($conn);
                        }
                    }mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,pytfrm,acc,caamt,rmks,expno,addedby,recsno) values ($vono,curdate(),'Cash',1,$amt,'BEING PAYMENT FOR $kind',$payno,'$addby',$sno); INSERT
                    INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,1,$voteno,$amt);") or die(mysqli_error($conn));
                  }
              } header("Location:rpts/receipt.php?recno=$sno-3-0-$vono-".uniqid());
          }else{//Editing
              $orig=isset($_POST['txtAddress'])?sanitize($_POST['txtOrig']):'0-0-0'; $orig=explode('-',$orig); //[0] Amount, [1] pytfrm,[2] 0-feecollection, 1 alumni
              $orig[0]=preg_replace('[^0-9\.]','',$orig[0]);       $voteno=0;
              $sql="UPDATE acc_incofee SET admno='$admno', pytdate='$date', paidby='$paidby', pytfrm='$pytfrm', cheno=".var_export($cheno,true).", bursno=".var_export($bursno,true).",
              bankno=".var_export($bankno,true).", kinddescr=".var_export($kind,true)." WHERE sno LIKE '$tkn[2]';";
              $sql.="UPDATE acc_incorecno0 SET bc=$bc,amt=$amt,arrears=$amt WHERE recno LIKE '$recno';";
              if($amt!=$orig[0]){ //If there is change in arrears amount
                  for($a=0;$a<$nov;$a++){
                      $vamt=isset($_POST['txtAmt_'.$a])?sanitize($_POST['txtAmt_'.$a]):0;     $vamt=preg_replace('/[^0-9\.]/','',$vamt);
                      $vorig=isset($_POST['txtCurr_'.$a])?sanitize($_POST['txtCurr_'.$a]):0;   $vorig=preg_replace('/[^0-9\.]/','',$vorig);
                      if ($vamt>0){$v=isset($_POST["txtAmt_$a"])?sanitize($_POST["txtYr_$a"]):0;      $v=explode('-',$v);
                          $sql.="UPDATE acc_incovotes SET amt=$vamt WHERE recno LIKE '$recno' and acc=1 and voteno=$v[1]; UPDATE class SET alumniarrears=alumniarrears-($vamt-$vorig)
                          WHERE admno LIKE '$admno' and curr_year LIKE '$v[0]'; UPDATE acc_arrrefclr SET amt=$vamt WHERE recno=$recno and arr_year=$v[0] and ac=1 and transtype=0;";
                      }
                  }
              }if (strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"".($orig[2]==0?"feecollection.php":"alumni.php")."\">HERE </a> to go back.");
                  $noc=0;  do{$noc+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn));
              }  $sql='';
              //Fee in Kind
              if($noc>0 && strcasecmp($pytfrm,'kind')==0){
                  if(strcasecmp($orig[1],'kind')==0){// origrinally fee in kind
                      $sql.="UPDATE acc_exppayee SET regdate='$date',payee='$parent',idno='$idno',address=".var_export($addr,true).",telno='$telno' WHERE payno IN (SELECT expno FROM acc_exp
                      WHERE recsno LIKE '$tkn[2]');";
                      $sql.="UPDATE acc_exp SET pytdate='$date',caamt=$amt,rmks='BEING PAYMENT FOR $kind' WHERE recsno LIKE '$tkn[2]'; UPDATE acc_pytvotes SET amt=$amt WHERE voteno=$voteno and "
                      ."(vono,acc) IN (SELECT vono,acc FROM acc_exp WHERE recsno LIKE '$tkn[2]');";
                  }else{ //origrinally not fee in kind
                      mysqli_multi_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno';SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '1';");
                      $i=$payno=$vote=0;
                      do{
                          if($rs=mysqli_store_result($conn)){
                            if($i==0){$no=mysqli_num_rows($rs); if ($no>0) list($payno)=mysqli_fetch_row($rs);}else{$no=mysqli_num_rows($rs); if ($no>0) list($vono)=mysqli_fetch_row($rs);}  mysqli_free_result($rs);
                          }$i++;
                      }while(mysqli_next_result($conn)); $vono++;
                      if($payno==0){//paye details are not in the system
                          if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES(0,'$date','$parent','$idno',".var_export($addr,true).",'$telno','$addby')")){
                            $payno=mysqli_insert_id($conn);
                          }
                      }mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,pytfrm,acc,caamt,rmks,expno,addedby,recsno) values ($vono,curdate(),'Cash',1,$amt,'BEING PAYMENT FOR $kind',$payno,'$addby',$tkn[2]);
                      INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,1,$voteno,$amt);") or die(mysqli_error($conn)."Click <a href=\"".($orig[2]==0?"feecollection.php":"alumni.php")."\">HERE </a> to go back.");
                  }
              }elseif($noc>0 && strcasecmp($orig[1],'kind')==0 && strcasecmp($pytfrm,'kind')!=0){$sql.="DELETE FROM acc_exp WHERE recsno LIKE '$tkn[2]';";}// originally fee in kind but now changed
              if (strlen($sql)>0) mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"".($orig[2]==0?"feecollection":"alumni").".php\">HERE</a> to go back.");
              $noc=$noc>0?1:0;    header("location:".($orig[2]==0?"feecollection":"alumni").".php?action=1-$noc");
          }
        }
    }elseif(isset($_POST['btnDel'])){
        $token=isset($_POST['txtToken'])?sanitize($_POST['txtToken']):'0-0-0';  $tkn=preg_split('/\-/',$token); //[0] 0-New 1-Edit, [1] Token,[2] RecSNo [3] 0 - Alumni 1 Feecollection
        $recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):0;        if($recno===NULL || $recno==false){$recno=0;}
        $rmks=isset($_POST['txtRmks'])?strtoupper(sanitize($_POST['txtRmks'])):null;        if($rmks===NULL || $rmkso==false){$rmks='';} $rmks=strtoupper($rmks);
        $pytfrm=isset($_POST['cboPytFrm'])?sanitize($_POST['cboPytFrm']):'Direct Banking';  if($pytfrm===NULL || $pytfrm===false){$pytfrm='DIRECT BANKING';} $sql='';
        if(strlen($rmks)>25){ // only delete when reason is valid
            $sql.="UPDATE acc_incofee SET markdel=1,delreason='$rmks' WHERE sno LIKE '$tkn[2]'; UPDATE acc_incorecno0 SET markdel=1 WHERE recno LIKE '$recno';";
            for($a=0;$a<$nov;$a++){
                $vamt=isset($_POST['txtAmt_'.$a])?sanitize($_POST['txtAmt_'.$a]):0;     $vamt=preg_replace('/[^0-9\.]/','',$vamt);
                if ($vamt>0){ $v=isset($_POST['txtYr_'.$a])?sanitize($_POST['txtYr_'.$a]):0;      $v=explode('-',$v);       $voteno=$v[1];
                    $sql.="UPDATE acc_incovotes SET markdel=1 WHERE recno LIKE '$recno' and acc=1 and voteno=$voteno; UPDATE class SET alumniarrears=alumniarrears+$vamt WHERE admno LIKE "
                    . "'$admno' and curr_year LIKE '$v[0]'; UPDATE acc_arrrefclr SET markdel=1,changermks='$rmks' WHERE recno=$recno and arr_year=$v[0] and ac=1 and transtype=0;";
                }
            }if(strcasecmp($pytfrm,'kind')==0) $sql.="DELETE FROM acc_exp WHERE recsno LIKE '$tkn[2]';";
        }if(strlen($sql)>0){
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"".($orig[2]==0?"feecollection":"alumni").".php\">HERE</a> to go back.");
            $noc=0; do{$noc+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn));
            $noc=$noc>0?1:0;    header("location:".($orig[2]==0?"feecollection":"alumni").".php?action=2-$noc");
        }
    }else{
        $info=isset($_REQUEST['admno'])?sanitize($_REQUEST['admno']): "0-0"; 	$info=explode('-',$info); //[0] 0-New, 1-editing, [1] admno,[2] Rec S/N and [3]-0 Fee Collection 1 Alumni
        $_SESSION['form_token']=$form_token=uniqid();
        mysqli_multi_query($conn,"SELECT sno FROM acc_votes WHERE abbr LIKE 'arrears' and acc=1; SELECT c.curr_year, concat(cn.clsname,' ', c.stream) as frm, c.alumniarrears FROM class c Inner "
        . "Join classnames cn USING (clsno) WHERE c.admno LIKE '$info[1]' and c.markdel=0 ORDER BY c.curr_year Asc; SELECT concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',"
        . "c.stream, c.curr_year) As cls FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) WHERE s.admno LIKE '$info[1]'; SELECT f.recno,i.admno,"
        . "i.pytdate,i.paidby,i.pytfrm,i.cheno,i.bursno,i.bankno,i.kinddescr,e.idno,e.payee,e.address,e.telno,f.bc,f.amt FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) LEFT "
        . "JOIN (SELECT e.recsno,p.payno,p.payee,p.idno,p.address,p.telno FROM acc_exppayee p Inner Join acc_exp e ON (p.payno=e.expno) WHERE e.markdel=0 and e.recsno LIKE '$info[2]')e ON "
        . "(i.sno=e.recsno) WHERE i.sno LIKE '$info[2]' and i.markdel=0;") or die(mysqli_error($conn).". Click <a href=\"alumni.php\">HERE<a> to try again.");
        $vote=$i=$ttl=$nov=0; $name=$frm='';
        do{
            if($rs=mysqli_store_result($conn)){
                if ($i==0){if(mysqli_num_rows($rs)>0) list($vote)=mysqli_fetch_row($rs);
                }elseif($i==1){$nov=mysqli_num_rows($rs); while($d=mysqli_fetch_row($rs)){$balances[]=new objArrears($d[0],$d[1],$d[2]); $ttl+=$d[2];}
                }elseif($i==2){ list($name,$frm)=mysqli_fetch_row($rs);
                }else{if(mysqli_num_rows($rs)>0){list($recno,$admno,$pytdate,$paidby,$pytfrm,$cheno,$bursno,$bankno,$kinddescr,$idno,$payee,$address,$telno,$bc,$amt)=mysqli_fetch_row($rs);
                  } else {$recno="Auto"; $admno=$info[1]; $pytdate=date('Y-m-d'); $paidby="parent"; $pytfrm="DIRECT BANKING"; $cheno=$bursno=$kinddescr=$idno=$address=$telno=$payee=""; $bankno=$bc=$amt=0;}
                }mysqli_free_result($rs);
            }$i++;
        }while(mysqli_next_result($conn)); $amtWords=NumToWord($amt+$bc);
    }headings('<link href="/date/tcal.css" rel="stylesheet" type="text/css"/><link rel="stylesheet" type="text/css" href="tpl/css/inputsettings.css"/>',0,0,2);
?><div style="border:1px dashed #fff;border-radius:15px;padding:5px;margin:auto;width:fit-content;font-size:10pt;background-color:#ecf4f3;" class="container">
<form method="POST" action="alumniarrclearance.php" name="feerecs" onsubmit="return SaveFeeRecord(this);"> <input type="hidden" name="txtNoV" id="txtNoV" size=2 value="<?php print $nov;?>">
<h3 style="font-weight:bold;font-size:13pt;letter-spacing:2px;word-spacing:3px;color:#fff;background:#000;text-align:center;">ADM. NO.<?php print $info[1]." <u>".$name.
"</u> ALUMNI OF GRADE/FORM ".$frm;?></h3>
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#fee" role="tab" aria-controls="fee" aria-selected="true" style="color:#04f;font-weight:bold;">RECEIPT DETAILS</a></li>
    <li class="nav-item"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#votes" role="tab" aria-controls="votes" aria-selected="false"  style="color:#04f;font-weight:bold;">ARREARS DISTRIBUTION</a></li>
</ul>
<div class="tab-content" id="myTabContent">
    <div class="tab-pane fade show active" id="fee" role="tabpanel" aria-labelledby="home-tab">
        <input type="hidden" name="txtToken" id="txtToken" value="<?php echo "$info[0]-$form_token-$info[2]";?>">
        <div class="form-row"><div class="col-md-7" style="background-color:#e6e6e6;border-radius:10px;margin-right:2px;">
            <div class="form-row"><div class="col-md-12" style="text-align:right;"><b>Today: <?php print date("D d F, Y"); ?></b><hr/></div></div>
            <div class="form-row">
                <div class="col-md-4"><label for="txtRecNo">Receipt No. *</label><input type="text" name="txtRecNo" size="12" maxlength="5" value="<?php echo $recno;?>" readonly class="modalinput"></div>
                <div class="col-md-4"><label for="txtAdmNo">Admission No. *</label><Input name="txtAdmNo" id="txtAdmNo" size=7 type="text" readonly value="<?php echo $admno;?>" class="modalinput"></div>
                <div class="col-md-4"><label for="dtpDate">Fees Received On. *</label><input type="text" size="15" name="dtpDate" readonly value="<?php echo date('d-m-Y',
                strtotime($pytdate)); ?>" id="dtpDate" class="tcal modalinput"></div>
            </div><br>
            <div class="form-row">
                <?php $bursbal=0;
                    if($info[0]==1){
                      $rs=mysqli_query($conn,"SELECT (b.amt-if(isnull(f.ttl),0,f.ttl)) as bal FROM acc_burs b LEFT JOIN (SELECT f.bursno,sum(if(isnull(f1.amt),0,(f1.amt+f1.bc))+if(isnull(f2.amt),0,(f2.amt+f2.bc))) as
                      ttl FROM acc_incofee f Left Join acc_incorecno0 f1 USING (sno) left Join acc_incorecno1 f2 USING (sno) GROUP BY f.bursno,f.markdel having f.markdel=0 and f.bursno LIKE '$bursno')f USING (bursno)
                      GROUP BY b.pytfrm,b.cheno,b.bankno,b.bursno,b.markdel HAVING b.bursno LIKE '$bursno' and b.markdel=0;");
                      if(mysqli_num_rows($rs)>0){list($bursbal)=mysqli_fetch_row($rs);} mysqli_free_result($rs);
                    }
                ?>
                <div class="col-md-4"><label for="cboPaidBy">Fee Paid By *</label><SELECT name="cboPaidBy" id="cboPaidBy" size="1" class="modalinput"><Option <?php echo (strcasecmp($paidby,"parent")==0?
                "Selected":""); ?>>Parent</option><Option <?php echo (strcasecmp($paidby,"bursary")==0?"Selected":""); ?>>Bursary</option><Option <?php echo (strcasecmp($paidby,"guardian")==0?
                "Selected":""); ?>>Guardian</option><Option<?php echo (strcasecmp($paidby,"well wisher")==0?"Selected":""); ?>>Well Wisher</option></SELECT></div>
                <div class="col-md-3"><label for="txtBursNo">Bursary No.</label><input type="text" name="txtBursNo" id="txtBursNo" value="<?php echo $bursno; ?>" onchange="loadBursaryBal(this)"
                size=7 maxlength=4 onkeyup="checkInput(1,this)" class="modalinput"></div>
                <div class="col-md-5" style="background:#ccc;"><label for="txtBursBal">Bursary Balance (KShs.)</label><input type="text" name="txtBursBal" id="txtBursBal" readonly
                value="<?php echo number_format($bursbal,2);?>" class="modalinput numbersinput modalinputdisabled"></div>
            </div>
            <div class="form-row">
                <div class="col-md-4"><label for="cboPytFrm">Mode of Payment *</label><SELECT name="cboPytFrm" id="cboPytFrm" size=1 onchange="checkPyt(this)" class="modalinput"><option value="CASH"
                <?php echo (strcasecmp($pytfrm,"cash")==0?"Selected":""); ?>>Cash</option><option value="CHEQUE" <?php echo (strcasecmp($pytfrm,"cheque")==0?"Selected":""); ?>>Cheque</option>
                <option value="DIRECT BANKING" <?php echo (strcasecmp($pytfrm,"direct banking")==0?"Selected":""); ?>>Direct Banking</option><option value="KIND"
                <?php echo (strcasecmp($pytfrm,"kind")==0?"Selected":""); ?>>Kind</option><option value="MFEES" <?php echo (strcasecmp($pytfrm,"mfees")==0?"Selected":""); ?>>
                M-Fees</option><option value="MONEY ORDER" <?php echo (strcasecmp($pytfrm,"money order")==0?"Selected":""); ?>>Money Order</option></SELECT></div>
                <div class="col-md-3"><label for="txtCheNo">Trans/Cheque No.</label><input name="txtCheNo" id="txtCheNo" size=15 maxlength=15 class="modalinput" value="<?php
                echo $cheno;?>" onkeyup="validateTransNo(this)" onchange="verifyDuplicateTransNo(this)"></div>
                <div class="col-md-5"><label for="cboBank">Banker(For Cheque/Money Order)</label><SELECT name="cboBank" id="cboBank" size=1 readonly class="modalinput"><option value="0"
                <?php echo ($bankno==0?"Selected":""); ?>>None</option>
                <?php $rs=mysqli_query($conn,"SELECT sno, descr FROM acc_banks WHERE markdel=0 ORDER BY descr Asc");
                while ($d=mysqli_fetch_row($rs)){print "<option value=\"$d[0]\" ".($bankno===$d[0]?"Selected":"").">$d[1]</option>";} mysqli_free_result($rs);
                ?></SELECT></div>
            </div>
            <div class="form-row">
                <div class="col-md-12"><DIV id="spKind" style="background:#f0ece3;<?php echo (strcasecmp($pytfrm,'kind')!=0?"display:none;":"");?>"><div class="form-row"><div class="col-md-12"
                class="divsubheadings">DESCRIPTION OF FEES RECEIVED IN KIND</div></div><div class="form-row"><div
                class="col-md-4"><label for="txtIDNo"><b>ID No.</b></label><input type="text" name="txtIDNo" class="modalinput" id="txtIDNo" maxlength="10" <?php echo "value=\"$idno\" ".
                (strcasecmp($pytfrm,'kind')==0?"":"readonly"); ?> placeholder="ID No." onkeyup="checkInput(1,this)" onchange="showKindDet(this)"></div>
                <div class="col-md-8"><label for="txtParent"><b>Parent/Guardian Names</b></label><input type="text" name="txtParent" id="txtParent" maxlength="40" class="modalinput"
                <?php echo "value=\"$payee\" ".(strcasecmp($pytfrm,'kind')==0?"":"readonly"); ?> placeholder="Names of Guardian/ Parent"></div></div>
                <div class="form-row"><div class="col-md-4"><label for="txtTelNo"><b>Tel No.</b></label><input type="text" name="txtTelNo" id="txtTelNo" maxlength=13 class="modalinput"
                <?php echo "value=\"$telno\" ".(strcasecmp($pytfrm,'kind')==0?"":"readonly"); ?> placeholder="+2547"></div><div class="col-md-8"><label for="txtAddress"><b>Postal Address</b>
                </label><input type="text" name="txtAddress" id="txtAddress" maxlength=75 <?php echo "value=\"$address\" ".(strcasecmp($pytfrm,'kind')==0?"":"readonly"); ?> class="modalinput"
                placeholder="P.O Box"></div></div>
                <div class="form-row"><div class="col-md-12"><label for="txtKind"><b>Narration of Fee Paid in Kind</b></label><textarea name="txtKind" id="txtKind" type="text" rows=2
                placeholder="2 90KG BAGS OF MAIZE @4,000" maxlength="150"  class="modalinput"><?php echo $kinddescr;?></textarea></div></div></DIV></div>
            </div><BR>
            <div class="form-row">
                <div class="col-md-4"><label>Arrears Received</label><input type="text" name="txtFee_0" id="txtFee_0" maxlength=11 class="modalinput numbersinput" onkeyup="ttlFee()"
                value="<?php echo number_format($amt,2); ?>" onblur="calcVotes(<?php echo $nov;?>)"></div><div class="col-md-4"><label for="txtBC">Bank Charges</label><INPUT type="text"
                name="txtBC" id="txtBC" maxlength="5"  class="modalinput numbersinput" value="<?php echo number_format($bc,2); ?>" onkeyup="ttlFee()" readonly></div>
                <div class="col-md-4" style="background-color:#ccc;"><label for="txtTtlFee">Total Amt Received</label><input type="hidden" name="txtOrig" id="txtOrig" value="<?php
                echo "$amt-$pytfrm-$info[3]";?>"><input type="text" name="txtTtlFee" id="txtTtlFee" value="<?php echo number_format(($amt+$bc),2);?>" readonly  style="font-weight:bold;"
                class="modalinput numbersinput modalinputdisabled"></div>
            </div><br>
            <div class="form-row">
                <div class="col-md-12"><TEXTAREA name="txtWords" id="txtWords" rows=2 class="modalinput" style="border:0px;font-weight:bold;color:#f0f;" readonly><?php
                echo $amtWords;?></textarea></div>
            </div>
            <div class="form-row" style="letter-spacing:1px;word-spacing:2px;background-color:#555;color:#fff;border-radius:0px 0px 15px 15px;padding:5px;">
                <div class="col-md-12"><label for="txtVoteBal_0">Arrears Yet to be Distributed to Respective Years</label><input type="text" name="txtVoteBal" id="txtVoteBal" value="0.00"
                class="modalinput numbersinput modalinputdisabled" readonly></div>
            </div>
        </div><div class="col-md-4" style="background-color:#f6f6f6;border-radius:10px;">
            <div class="form-row" style="border-radius:5px 5px 15px 15px;padding:5px;background:#eee;"><div class="col-md-7"><b>FINANCIAL YEAR</b></div><div class="col-md-5" style="text-align:right;font-weight:bold;">
            ARREARS B/F</div></div><HR style="border:0px;border-top:1px dotted #0ff;height:0px;">
            <?php
                $table='<div class="form-row" style="border-radius:5px 5px 15px 15px;padding:5px;"><div class="col-md-10"><div class="form-row"><div class="col-md-4"><b>FINANCIAL YEAR</b></div><div
                class="col-md-3" style="font-weight:bold;text-align:right;">ARREARS B/F</div><div class="col-md-2" style="font-weight:bold;text-align:right;">CURRENT AMT</div><div class="col-md-3"
                style="font-weight:bold;text-align:right;">AMOUNT CLEARED</div></div><HR style=\"border:0px;border-top:1px dotted #0ff;\">';          $a=$nr=0;
                if($info[0]==1){$rs=mysqli_query($conn,"SELECT arr_year,amt FROM acc_arrrefclr WHERE markdel=0 and recno LIKE '$recno' ORDER BY arr_year ASC;");   $nr=mysqli_num_rows($rs); }
                foreach($balances as $bal){$vamt=0;
                    if($info[0]==1 && $nr>0){mysqli_data_seek($rs,0); $found=false; $index=0;
                        while($index<$nr && $found==false){list($yr,$b)=mysqli_fetch_row($rs); if($yr==($bal->valYr())){$found=true; $vamt=$b;} $index++; }
                    }$table.="<div class=\"form-row\"><div class=\"col-md-4\">".$bal->valCls()." ".$bal->valYr()."<input type=\"hidden\" name=\"txtYr_$a\" id=\"txtYr_$a\" value=\"".$bal->valYr()."-$vote\"></div><div
                    class=\"col-md-3\"><input type=\"text\" name=\"txtArr_$a\" id=\"txtArr_$a\" readonly class=\"modalinput numbersinput modalinputdisabled\" value=\"".number_format($bal->valArr(),2)."\"></div><div
                    class=\"col-md-2\"><input type=\"text\" name=\"txtCurr_$a\" id=\"txtCurr_$a\" readonly value=\"".number_format($vamt,2)."\" class=\"modalinput numbersinput modalinputdisabled\" onkeyup=\"checkInput(0,this)\"
                    onchange=\"calcTotal($a,$nov)\"></div><div class=\"col-md-3\"><input type=\"text\" name=\"txtAmt_$a\" id=\"txtAmt_$a\" value=\"".number_format($vamt,2)."\" class=\"modalinput numbersinput\"
                    onkeyup=\"checkInput(0,this)\" onchange=\"calcTotal($a,$nov)\"></div></div><HR style=\"border:0px;border-top:1px dotted #0ff;\">";
                    print "<div class=\"form-row\"><div class=\"col-md-7\">".$bal->valCls()." ".$bal->valYr()."</div><div class=\"col-md-5\" style=\"text-align:right;\">".number_format($bal->valArr(),2)."</div></div><hr
                    style=\"border:0px;border-top:1px dotted #0ff;\">"; $a++;
                } if($info[0]==1){mysqli_free_result($rs);}
                print "<div class=\"form-row\"><div class=\"col-md-7\"><B>TOTAL ARREARS B/F</B></div><div class=\"col-md-5\" style=\"text-align:right;background:#eee;font-weight:bold;\">".
                number_format($ttl,2)."</div></div>";
                $table.="<div class=\"form-row\"><div class=\"col-md-4\"><b>TOTAL AMOUNT</b></div><div class=\"col-md-3\"><input type=\"text\" name=\"txtTtlArr\" readonly id=\"txtTtlArr\" class=\"modalinput numbersinput "
                . "modalinputdisabled\" value=\"".number_format($bal->valArr(),2)."\"></div><div class=\"col-md-2\"><input type=\"text\" name=\"txtTtlCurr\" readonly id=\"txtTtlCurr\" value=\"".
                number_format($amt,2)."\" class=\"modalinput numbersinput modalinputdisabled\"></div><div class=\"col-md-3\"><input type=\"text\" name=\"txtTtlAmt\" readonly id=\"txtTtlAmt\" value=\"".
                number_format($amt,2)."\" class=\"modalinput numbersinput modalinputdisabled\"></div></div><div class=\"col-md-2\"></div></div>";
            ?>
          </div>
        </div>
    </DIV><div class="tab-pane fade" id="votes" role="votes" aria-labelledby="profile-tab"><?php  print $table;  ?> </div>
</DIV><hr><div class="form-row"><div class="col-md-6" style="text-align:center;"><button type="submit" name="btnSaveFee" id="CmdSave" class="btn btn-primary btn-md btn-block"><b>Save Fee Record</b>
    </button></div><div class="col-md-6" style="text-align:right;"><a href="alumni.php?action=0-0"><button type="button" name="btnClose" class="btn btn-md btn-info">Close/ Cancel</button></a></div>
</div><br><div class="form-row" style="border-radius:0 0 15px 15px;color:#f40000;font-size:11pt;background-color:#e6e6e6;border-color:#fff;<?php echo ($info[0]==1?"":"display:none;") ?>">
    <div class="col-md-9" style=""><label for="txtDelReason">Reason for deleting</label><textarea name="txtDelReason" id="txtDelReason" rows="3" maxlength="150" class="modalinput"
    style="letter-spacing:3px;word-spacing:5px;" onkeyup="activateDel(this)" placeholder="Reason for deleting arrears recovery record"></textarea></div>
    <div class="col-md-3" style="padding:30px 5px;"><button disabled name="btnDel" id="btnDel" type="submit" class="btn btn-danger btn-md">Delete Arrears Receipt</button></div>
</div></form></div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/alumnifeerec.js"></script>
<?php mysqli_close($conn); footer();?>
