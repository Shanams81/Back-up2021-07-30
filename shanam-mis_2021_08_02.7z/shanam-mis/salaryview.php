<?php
    include_once('shanam.php');
    $salno=isset($_REQUEST['salno'])?trim($_REQUEST['salno']):0;
    mysqli_multi_query($conn,"SELECT s.sal_month,s.sal_year,concat(ac.abbr,' (',v.descr,') -',b.abbr,' Bank (A/C No.',a.accno,')') as vote,s.processedon,ac.acno FROM acc_salaries s Inner Join
    acc_accounts a On (s.acsno=a.sno) Inner Join acc_banks b ON (a.bankno=b.sno) Inner Join acc_voteacs ac On (a.accacc=ac.acno) Inner Join acc_votes v On (s.voteno=v.sno) WHERE s.salno
    LIKE '$salno'; SELECT schtype FROM ss;  SELECT staff FROM grps WHERE staff is not null and staff not like '' Order By staff ASC; SELECT e.vono,p.payno,p.payee FROM acc_exp e Inner "
    . "Join acc_exppayee p On (e.expno=p.payno) WHERE e.salno LIKE '$salno' and e.markdel=0 ORDER BY p.payno ASC;"); 	$schtype=$i=0;   $optstf=$optvo='';
    do{
        if($rs=mysqli_store_result($conn)){
          if($i==0) list($mon,$yr,$salso,$pron,$acc)=mysqli_fetch_row($rs);
          elseif($i==1) list($schtype)=mysqli_fetch_row($rs);
          elseif($i==2) {while ($s=mysqli_fetch_row($rs)) $optstf.="<option value=\"$s[0]\">$s[0]</option>";}
          else{while($s=mysqli_fetch_row($rs)) $optvo.="<option value=\"$s[0]-$s[1]\">".strtoupper($s[1]==6?"Rent Recoveries":($s[1]==7?"Elime Sacco":($s[1]==8?"KDS SAcco":$s[2])))."</option>";}
          mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    headings('<link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link href="tpl/css/spinner.css" rel="stylesheet" type="text/css"/>',0,0,1);
    $h='<u>'.$mon.'-'.$yr.' Staff Salary Processed On '.date("D d M, Y",strtotime($pron)).'Debited on '.$salso.'</u>';
?>
<div class="container" style="margin:auto;max-width:700px;background:#eee;border-radius:20px;padding:0 0 10px 0;">
  <div class="form-row"><div class="col-md-12" style="padding:6px;text-align:center;"><h5 style="text-align:center;color:#00f;"><img onclick="window.open('payroll.php','_self')"
    src="/gen_img/ani_back.gif" width="45" height="20" align="left">&nbsp;<?php echo strtoupper($h); ?></h5></div>
  </div><div class="form-row"><div class="col-md-12">
    <div class="container" style="background-color:#fff;margin:auto;width:fit-content;border-radius:10px 10px 0 0;padding:0px 15px 5px 15px;">
      <div class="form-row">
        <div class="col-md-6" style="background:#000;color:#fff;border-radius:10px 10px 0px 0px;font-size:11pt;">SALARY PAYPOINTS</div>
        <div class="col-md-6" style="background:#000;color:#fff;font-size:11pt;border-radius:10px 10px 0px 0px;">SALARY DEDUCTIONS</div>
      </div><br>
      <?php
        $rs=mysqli_query($conn,"SELECT DISTINCT left(paypoint,length(paypoint)-locate('-',reverse(paypoint))) as bank FROM acc_salpyt WHERE salno LIKE '$salno'");
        if (mysqli_num_rows($rs)>0):
            $i=0;   print "<div class=\"form-row\"><div class=\"col-md-6\">";
            while (list($bn)=mysqli_fetch_row($rs)){
                print "<button type=\"button\" name=\"btnPP$i\" id=\"btnPP$i\" onclick=\"window.open('rpts/payrollpp.php?salno=$salno-$bn','_self')\" class=\"btn btn-block btn-md
                btn-primary\">$bn</button></br>"; $i++;
            } mysqli_free_result($rs);
            print "</div><div class=\"col-md-6\"><button onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-nssf','_self')\" type=\"button\" name=\"btnNSSF\" id=\"btnNSSF\"
            class=\"btn btn-block btn-sm btn-primary\">N . S . S . F</button><button onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-nhif','_self')\" type=\"button\"
            name=\"btnNHIF\" id=\"btnNHIF\" class=\"btn btn-block btn-sm btn-primary\">N . H . I . F</button><button type=\"button\" name=\"btnPAYE\" id=\"btnPAYE\"
            class=\"btn btn-block btn-sm btn-primary\" onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-tax','_self')\">PAYE Tax</button><button type=\"button\" name=\"btnUnion\"
            id=\"btnUnion\" class=\"btn btn-block btn-sm btn-primary\" onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-union','_self')\">".($schtype==0?"Elimu SACCO":
            "Workers' Union")."</button><button class=\"btn btn-block btn-sm btn-primary\" onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-advance','_self')\" type=\"button\"
            name=\"btnAdv\" id=\"btnAdv\">Salary Advance</button><button class=\"btn btn-block btn-sm btn-primary\" type=\"button\" name=\"btnSACCO\" id=\"btnSACCO\"
            onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-sacco','_self')\">".($schtype==0?"KDS SACCO":"SACCO")."</button><button class=\"btn btn-block btn-sm btn-primary\"
            onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-helb','_self')\" type=\"button\" name=\"btnHELB\" class=\"btn btn-block btn-sm btn-primary\" id=\"btnHELB\">
            H . E . L . B</button><button class=\"btn btn-block btn-sm btn-primary\" onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-welfare','_self')\"type=\"button\"
            name=\"btnWelf\" id=\"btnWelf\">Welfare</button><button class=\"btn btn-block btn-sm btn-primary\"  type=\"button\" name=\"btnOle\" id=\"btnOle\"
            onclick=\"window.open('rpts/payrolldedrpts.php?salno=$salno-ole','_self')\">".($schtype==0?"Rent Recoveries":"Other Deductions")."</button></div></div>";
            print "<hr><form name=\"frm\" action=\"#\" method=\"post\"><div class=\"form-row\"><div class=\"col-md-3\"><input type=\"hidden\" name=\"txtSalNo\"  ID=\"txtSalNo\"
            value=\"$salno\"><label for=\"cboTypeRpt\">View</label><SELECT name=\"cboTypeRpt\" id=\"cboTypeRpt\" size=1><option value=\"1\" selected>Payroll</option><option value=\"2\">
            Payslips</option></select></div><div class=\"col-md-5\"><label for=\"cboStfGrp\">For</label><SELECT name=\"cboStfGrp\" id=\"cboStfGrp\" size=\"1\"><option value=\"%\"
            selected>All Staff</option>$optstf</SELECT></div><div class=\"col-md-4\"><button onclick=\"disableCmd(0,$acc)\" type=\"button\" name=\"btnView\" class=\"btn btn-block btn-sm
            btn-primary\">$mon-$yr REPORT</button></div></div><hr>";
            print "<div class=\"form-row\"><div class=\"col-md-8\"><label for=\"cboTypeRpt\">View <SELECT name=\"cboPV\" id=\"cboPV\" size=1>$optvo</select></label></div><div
            class=\"col-md-4\"><button onclick=\"disableCmd(1,$acc)\" class=\"btn btn-block btn-sm btn-primary\" type=\"button\" name=\"btnView1\"> $mon-$yr PV</button></form></div></div>";
        else:
            print "<div class=\"form-row\"><div class=\"col-md-12\" style=\"padding:6px;text-align:center;\"><br>$mon-$yr salary has not been processed<br></div></div>";
        endif;
      ?>
    </div></div></div><div class="form-row"><div class="col-md-12" style="text-align:right;padding:0 20px 0 0;"><button type="button" name="btnClose"
    onclick="window.open('payroll.php','_self')" class="btn btn-info btn-md disabled">Close</button></div></div>
</div>
<div id="busyWait" class="modal"  onclick="document.querySelector('#busyWait').style.display='none'"><div class="loader"></div></div>
<script type="text/javascript" src="tpl/js/salaryview.js"></script>
<?php footer(); mysqli_close($conn);?>
