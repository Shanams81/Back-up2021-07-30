<?php
	if (isset($_POST['cmdSave'])){
		include_once('../conn/pri_sch_connect.inc');
		$no=isset($_POST['txtNo'])?strip_tags($_POST['txtNo']):8;
		$nhif=isset($_POST["txtNHIF_$no"])?$_POST["txtNHIF_$no"]:'0'; 	
		$lb=isset($_POST["txtLB_$no"])?strip_tags($_POST["txtLB_$no"]):0;
		$ub=isset($_POST["txtUB_$no"])?strip_tags($_POST["txtUB_$no"]):0;
		$rate=isset($_POST["txtAmt_$no"])?strip_tags($_POST["txtAmt_$no"]):0;
		$lb=preg_replace('/[^0-9^\.]/','',$lb); $ub=preg_replace('/[^0-9^\.]/','',$ub);	$rate=preg_replace('/[^0-9^\.]/','',$rate);
		if ($lb>0 && $ub>0 && $rate>0){
			mysqli_query($conn,"UPDATE acc_nhifcalc SET lowerbound='$lb',upperbound='$ub',amount='$rate' WHERE nhifno LIKE '$nhif'") or die(mysqli_error($conn).". Click <a 
			href=\"nhifbrackets.php\">Here</a> to try again.");
			$i=mysqli_affected_rows($conn);
		}else $i=0;
		mysqli_close($conn);
	} else $i=0;
	header("location:nhifbrackets.php?action=1-$i");
?>