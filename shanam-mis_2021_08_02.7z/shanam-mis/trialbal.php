<?php
		include_once('shanam.php');		include_once('tpl/funcs.tpl');	$monnum=isset($_POST['cboMonth'])?sanitize($_POST['cboMonth']):date('m');	$ac=isset($_POST['cboAc'])?sanitize($_POST['cboAc']):1;
		headings('<link rel="stylesheet" href="tpl/css/headers.css"/>',0,0,2); $fm=date('m');
		mysqli_multi_query($conn,"SELECT finyr,scnm,concat(scadd,' Tel No. ',telno) as addr FROM ss; SELECT acno, descr FROM acc_voteacs WHERE markdel=0; SELECT sum(a.bankbalbf) as bf,sum(a.bankbalbf+if(isnull(b.bal),0,
		b.bal)) as cbal FROM acc_accounts ac Inner Join acc_acbalbf a On (ac.sno=a.acsno) Left Join (SELECT acsno,sum(if(bank_type=0,amt,0)-if(bank_type=1,amt,0)) as bal FROM acc_banking Group By markdel,acsno HAVING
		markdel=0)b ON (ac.sno=b.acsno) GROUP BY ac.accacc HAVING ac.accacc=$ac; SELECT a.cashbalbf,(a.cashbalbf+if(isnull(b.amt),0,b.amt)) as cbal FROM acc_votebalbf a Left Join (SELECT acc,(sum(if(cftype=0,amt,0))-
		sum(if(cftype=1,amt,0))) as amt FROM acc_cashflow GROUP BY acc,markdel HAVING markdel=0 and acc=$ac)b USING (acc) WHERE acc=$ac;"); $cashbf=$bankbf=$curcash=$curbank=$i=0; $optac=$acnm='';
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0)list($finyr,$scnm,$scadd)=mysqli_fetch_row($rs); elseif($i==1){while($d=mysqli_fetch_row($rs)){$optac.="<option value=\"$d[0]\" ".($d[0]==$ac?"selected":"").">$d[1]</option>";if($ac==$d[0]) $acnm=$d[1];}}
				elseif($i==2)list($bankbf,$curbank)=mysqli_fetch_row($rs); else list($cashbf,$curcash)=mysqli_fetch_row($rs);
				mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn)); $sdate="$finyr-$monnum-".date('t',strtotime($finyr.'-'.$monnum.'-01')); $h=$acnm." Trial Balance As On ".date('jS F-Y',strtotime($sdate));
?><div class="head"><form method="post" action="trialbal.php">View <select name="cboAc" size="1"><?php echo $optac;?></select> Trial Balance Of <SELECT name="cboMonth" size="1">
	<?php for($i=1;$i<13;$i++) echo "<option value=\"".($i<10?("0".$i):$i)."\" ".($i==$monnum?"selected":"").">".date('F',mktime(0,0,0,$i,10))." - $finyr</option>";	?> </SELECT>	&nbsp;<button type="submit" accesskey="s"
	name="btnShow">Show Trial Balance</button></form>
</div><div class="container" id="print_content" style="background-color:#f6f6f6"><table class="table table-borderless table-sm table-hover"><tr><th rowspan="3"><img src="/gen_img/logo.jpg" width="60" height="60"></th>
	<th colspan="2"><?php echo $scnm;?></th></tr><tr><th colspan="2"><?php echo $scadd;?></th></tr><tr><th><?php echo strtoupper($h);?></th><th width="200" style="font-size:8pt;">Printed On <?php echo date('D d M, Y');?>
	</th></tr><tr><td colspan="3"><table class="table table-hover table-striped table-sm table-bordered" border="1"><thead class="thead-dark"><tr><th colspan="2">Voteheads</th><th>Ledger Folio<br>No.</th><th>Approximated
	Amt <br> (Kshs.)</th><th>Debit (Dr)<br>(Kshs.)</th><th>Credit (Cr)<br> (Kshs.)</th><th>Balance <br> (Kshs.)</th></tr></tr>
	<tr><td colspan="2"><u><b>Balance B/F</b></u></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td style=\"border-right:hidden;"></td><td style="border-left:hidden;">Cash</td><td></td><td></td><td></td><td
	align="right"><?php echo number_format($cashbf,2);?></td><td></td></tr><tr><td style="border-right:hidden;"></td><td style="border-left:hidden;">Bank</td><td></td><td></td><td></td><td align="right">
	<?php echo number_format($bankbf,2);?></td><td></td></tr><tr><td colspan="2"><u><b><?php echo $acnm;?></b></u></td><td></td><td></td><td></td><td></td><td></td></tr>
	<?php
	$rs=mysqli_query($conn,"SELECT v.lfn,v.expdescr,e.curest,if(isnull(p.exp),0,p.exp) as cost, if(isnull(i.inco),0,i.inco) as income FROM acc_fyestimates e INNER JOIN acc_votes v ON (e.voteno=v.sno) LEFT JOIN (SELECT
	voteno,acc,sum(amt)	as inco FROM (SELECT voteno,acc,amt FROM ".($ac<3?"acc_incovotes":"acc_fsevotes")." WHERE pytdate BETWEEN '$finyr-01-01' and '$sdate' and markdel=0 and acc=$ac)i GROUP BY acc,voteno)i USING
	(voteno,acc) LEFT JOIN (SELECT voteno,acc,sum(amt) as exp FROM (SELECT voteno,acc,amt FROM acc_pytvotes WHERE pytdate BETWEEN '$finyr-01-01' and '$sdate' and markdel=0 and acc=$ac)p GROUP BY acc,voteno)p USING
	(voteno,acc) WHERE e.finyr=$finyr and v.acc=$ac Order By v.lfn,e.voteno ASC"); $ttl=[0,0,0,0];
	while($data=mysqli_fetch_row($rs)){print "<tr><td style=\"border-right:hidden;\"></td><td style=\"border-left:hidden;\">$data[1]</td><td align=\"center\">$data[0]</td><td align=\"right\">".number_format($data[2],2).
		"</td><td align=\"right\">".number_format($data[3],2)."</td><td align=\"right\">".number_format($data[4],2)."</td><td align=\"right\">".number_format(($data[4]-$data[3]),2)."</td></tr>";
		$ttl[0]+=$data[2]; $ttl[1]+=$data[3]; $ttl[2]+=$data[3]; $ttl[3]+=$data[4];
	}
	//Totals
	print "<tr><td colspan=\"2\"><u><b>Balance C/F</b></u></td><td></td><td></td><td></td><td></td><td></td></tr>";
	print "<tr><td style=\"border-right:hidden;\"></td><td style=\"border-left:hidden;\">Cash</td><td align=\"center\"></td><td></td><td></td><td align=\"right\">".
	number_format($curcash,2)."</td><td></td></tr>";
	print "<tr><td style=\"border-right:hidden;\"></td><td style=\"border-left:hidden;\">Bank</td><td align=\"center\"></td><td></td><td></td><td align=\"right\">".
	number_format($curbank,2)."</td><td></td></tr>";
	print "<tr><td style=\"border-right:hidden;\">&nbsp;&nbsp;&nbsp;</td><td colspan=\"2\" align=\"right\" style=\"border-left:hidden;\"><b>Total (Kshs.)</b></td>";
	foreach($ttl as $amt) print "<td align=\"right\">".number_format($amt,2)."</td>";	print "</tr></table></td></tr></table></div><br><br><a href=\"javascript:Clickheretoprint()\"><b>Click Here to Print</b></a>";
	mysqli_close($conn); footer();
?><script type="text/javascript" src="tpl/js/printthis.js"></script>
