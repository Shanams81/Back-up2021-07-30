<?php
    include_once('shanam.php');
    $action=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0';	 $action=preg_split("/\-/",$action);
    $rs=mysqli_query($conn,"SELECT finyr FROM ss"); list($yr)=mysqli_fetch_row($rs); $yr=strlen($yr)==0?date('Y'):$yr; mysqli_free_result($rs);
    $rs=mysqli_query($conn,"SELECT feeview,arrrefedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
    $edi=0; $viu=0;	if (mysqli_num_rows($rs)>0) list($viu,$edi)=mysqli_fetch_row($rs);	mysqli_free_result($rs);
    $fr=isset($_POST['cboForm']) ? strip_tags($_POST['cboForm']): "%";		$st=isset($_POST['cboStream']) ? strip_tags($_POST['cboStream']): "%";
    $find=isset($_POST['TxtFind']) ? strip_tags($_POST['TxtFind']): "%";	$search=isset($_POST['search']) ? $_POST['search'] : "stud_names";
    headings('<link href="tpl/css/hightlight.css" rel="stylesheet" type="text/css" /><link href="tpl/accprint.css" rel="stylesheet" type="text/css" media="print" />
    <link href="tpl/css/headers.css" rel="stylesheet" type="text/css" />',0,0,2);
?><div class="head">
<form method="post" action="arrearsbf.php"><a href="pupil_manager.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;&nbsp;
<label for="form">Show Grade/Form</label>&nbsp;&nbsp;<select name="cboForm" size="1" id="form">
<?php
    $rsStr=mysqli_query($conn,"SELECT clsno,clsname FROM classnames ORDER BY clsno ASC") or die(mysqli_error($conn).' Error in database connection');
    if (mysqli_num_rows($rsStr)>0) while (list($clsno,$class)=mysqli_fetch_row($rsStr)){if ($fr==$clsno) $clsname=$class; print "<option value=\"$clsno\" ".($fr==$cslno?"selected":"").
    ">$class</option>";	}	mysqli_free_result($rsStr);
    print "</select> - <select name=\"cboStream\" size=\"1\" id=\"stream\"><option selected value=\"%\">All</option>";
    $rsStr=mysqli_query($conn,"SELECT strm FROM grps WHERE strm is not null or strm not like ''") or die(mysqli_error($conn).' Error in database connection');
    if (mysqli_num_rows($rsStr)>0) while (list($strm)=mysqli_fetch_row($rsStr)) print "<option>$strm</option>";
    mysqli_free_result($rsStr);
    print "</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type=\"submit\" name=\"Stud\" ".(($viu==1)?"":"disabled").">Show Report</button></form></div><div style=\"max-height:600px;
    margin:auto;border:1px dotted #fff;border-radius:10px;padding:6px;width:fit-content;background-color:#eee;\">";
    if (isset($_POST['Stud'])){
        $h="";
        if (strcasecmp($fr,"%")!=0) $h.="Grade/ Form ".$clsname;
        if (strcasecmp($st,'%')!=0) $h.=" ".$st;
        $h.=" Fee Arrears B/F";
    }else{
        $h= "All students' Arrears";
    }
    print "<span style=\"background:inherit;border:0.5px dotted green;border-radius:10px;color:#00f;padding:6px;display:block;width:100%;font-size:12px;\"><form name=\"frmFind\"
    action=\"stf.php\" method=\"post\">Find Student By &nbsp;<input type=\"radio\" name=\"radFind\" id=\"radAdmNo\" value=\"admno\" onclick=\"clrText()\">Adm. No.&nbsp;<input type=\"radio\"
    name=\"radFind\" id=\"radNEMISNo\" value=\"nemisno\" onclick=\"clrText()\">NEMIS No.&nbsp; <input type=\"radio\" name=\"radFind\" id=\"radName\" value=\"st_names\" checked
    onclick=\"clrText()\">Names &nbsp; &nbsp; <input type=\"text\" maxlength=\"17\" size=\"30\" name=\"txtFind\" id=\"txtFind\" value=\"\" onkeyup=\"myFunction()\" placeholder=\"Type/ Enter
    what to Find\" style=\"border:0px;border-bottom:1px solid blue;color:#00d;\"></form></span><div style=\"overflow-y:scroll;max-height:500px;\" id=\"print_content\"><h5 style=\"text-align:center\">".
    strtoupper($h)." AS ON ".strtoupper(date("D d-M-Y"))."</h5>";  $find=strlen(trim($find))>1 ? $find : "%";
    if (strcasecmp("%",$find)==0){
        $sql="SELECT s.admno,s.nemisno,concat(s.surname,' ',s.onames) as stud_names,s.admdate,s.telno,concat(n.clsname,' ',sf.stream) as frm,a.arr FROM stud s Inner Join class sf USING (admno,
        curr_year) Inner Join classnames n USING (clsno) Inner Join (SELECT admno,sum(bbf+miscbf) as arr FROM class Group By admno)a On (s.admno=a.admno) WHERE s.curr_year=$yr and s.type=0
        and s.present=1 And sf.clsno LIKE '$fr' and sf.stream LIKE '$st' Order By s.admno ASC";
    }else{
        if (strcasecmp($search,"admno")==0) $sql="SELECT s.admno,s.nemisno,concat(s.surname,' ',s.onames) as stud_names,s.admdate,s.telno,concat(n.clsname,' ',sf.stream) as frm,a.arr FROM
        stud s Inner Join class sf USING (admno,curr_year) Inner Join classnames n USING (clsno) Inner Join (SELECT admno,sum(bbf+miscbf) as arr FROM class Group By admno)a On (s.admno=a.admno)
        WHERE s.curr_year=$yr and s.Markdel=0 and s.type=0 and s.present=1 And s.admno LIKE '$find' Order By s.admno ASC";
        else $sql="SELECT s.admno,s.nemisno,concat(s.surname,' ',s.onames) as stud_names,s.admdate,s.telno,concat(n.clsname,' ',sf.stream) as frm,a.arr FROM stud s Inner Join class sf USING
        (admno,curr_year) Inner Join classnames n USING (clsno) Inner Join (SELECT admno,sum(bbf+miscbf) as arr FROM class Group By admno)a On (s.admno=a.admno) WHERE s.curr_year=$yr and
        s.Markdel=0 and s.type=0 and s.present=1 And (s.surname LIKE '%$find%' Or s.onames LIKE '%$find%') Order By s.admno ASC";
    }
    $rsStud=mysqli_query($conn,$sql);
    print "<table class=\"table table-striped table-hover table-bordered table-sm\" id=\"myTable\" style=\"font-size:0.7rem;\"><thead class=\"thead-dark\"><tr><th>Adm. No.</th><th>NEMIS No.</th><th>Names</th><th>"
    . "Grade/Form</th><th>Tel. No.</th><th>Admitted On</th><th>Arrears B/F</th><th>Edit</th></tr></thead><tbody>";	$tarr=0;
    if (mysqli_num_rows($rsStud)>0):
        while (list($admno,$nemis,$names,$date,$tel,$cls,$arr)=mysqli_fetch_row($rsStud)):
            print "<tr><td>$admno</td><td>$nemis</td><td>$names</td><td>$cls</td><td>$tel</td><td>".date("D, d-F-Y",strtotime($date))."</td><td align=\"right\"><b>".number_format($arr,2).
            "</b></td><td align=\"center\"><a onclick=\"return canedit($edi);\" href=\"studarrears.php?action=$admno-$yr-1\">Edit</a></td></tr>";
            $tarr+=$arr;
        endwhile;
    else:
        print "<tr><td colspan=\"8\"><br />The are no students with arrears b/f</td></tr>";
    endif;
    print "</tbody></table></div><div class=\"row\" style=\"background-color:#555;color:#fff;margin:0\"><div class=\"col-md-5\" style=\"font-weight:bold\" id=\"spTotal\">".mysqli_num_rows($rsStud)." Fee Arrear(s)' Records
        </div><div class=\"col-md-3\" style=\"font-weight:bold;text-align:right;\">Subtotals (Kshs.)</div><div class=\"col-md-3\" style=\"font-weight:bold;text-align:right;\" id=\"divAmt\">".number_format($tarr,2)."</div>"
        . "</div></div>";
    mysqli_free_result($rsStud);
    print "<center><a href=\"#\" onclick=\"Clickheretoprint()\"><img src=\"../gen_img/print.ico\" Align=\"center\" Height=\"30\" width=\"35\" alt=\"Top\"></a></center><br>
    <script type=\"text/javascript\" src=\"tpl/js/stud-find.js\"></script><script type=\"text/javascript\" src=\"tpl/printthis.js\"></script>";
    mysqli_close($conn); footer();
?>
