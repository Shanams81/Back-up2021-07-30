<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	$action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
	$rs=mysqli_query($conn,"SELECT fin_yr FROM ss"); list($yr)=mysqli_fetch_row($rs); $yr=strlen($yr)==0?date('Y'):$yr; mysqli_free_result($rs);
	$rs=mysqli_query($conn,"SELECT uniadd,uniview FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'"); 
	$canadd=0; $canedit=0;	$fee=0; $candel=0; $canviu=0;
	//Uniform add and edit priviledges
	if(mysqli_num_rows($rs)==1) list($canadd,$canviu)=mysqli_fetch_row($rs); 	mysqli_free_result($rs);
	//fee arrears edit priviledges
	$rs=mysqli_query($conn,"SELECT feeedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	if(mysqli_num_rows($rs)==1) list($fee)=mysqli_fetch_row($rs); 	mysqli_free_result($rs);
	//feedbacks
	$start=isset($_POST["txtSDate"])?$_POST["txtSDate"]:date('Y-m-d');				$end=isset($_POST["txtEDate"])?$_POST["txtEDate"]:date('Y-m-d'); 
	$fr=isset($_REQUEST['CboForm']) ? strip_tags($_REQUEST['CboForm']): "%";		$st=isset($_REQUEST['CboStream']) ? strip_tags($_REQUEST['CboStream']): "%";
	$adno=isset($_REQUEST['TxtAdmNo']) ? strip_tags($_REQUEST['TxtAdmNo']): "%";	$findby=isset($_REQUEST['findby']) ? $_REQUEST['findby'] : "stud_names";
	$status=isset($_POST['cboStatus'])?$_POST['cboStatus']:"1";						if ($canviu==0) header("Location:vague.php");
?>
<html>
<head>
	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<link rel="stylesheet" type="text/css" href="../date/tcal.css" />
	<script type="text/javascript" src="../date/tcal.js"></script>
</head>
<body background="img/bg3.gif" <?php print "onload=\"actiondone($action[0],$action[1])\"";?>>
	<form method="post" action="extraunifrm.php"><SELECT name="cboStatus" size="1"><option value="0">Unpaid</option><option value="1" selected>Unissued</option><option value="2">Issued
	</option></select> Extrauniform Ordered Between <Input type="text" name="txtSDate" size="10" class="tcal"> and <Input type="text" name="txtEDate" size="10" class="tcal"><label 
	for="form"> in Form</label>&nbsp;&nbsp;<select name="CboForm" size="1" id="form"><option value="%">All</Option><option selected>One</Option><option>Two</Option><option>Three</Option>
	<option>Four</Option></select>&nbsp;&nbsp;<label for="stream">Stream</label>&nbsp;&nbsp;<select name="CboStream" size="1" id ="stream"><option selected value="%">All</option>
	<?php 
		$rsStr=mysqli_query($conn,"SELECT strm FROM grps WHERE strm is not null") or die(mysqli_error($conn).' Error in database connection'); 
		if (mysqli_num_rows($rsStr)>0) while (list($strm)=mysqli_fetch_row($rsStr)) print "<option>$strm</option>";
		mysqli_free_result($rsStr);
		print "</select>&nbsp;&nbsp;&nbsp;Or Find By:&nbsp;&nbsp;<input type=\"radio\" name=\"findby\" value=\"admno\">Adm. No.&nbsp;&nbsp;<input type=\"radio\" name=\"findby\" 
		value=\"stud_names\" checked>Names&nbsp;&nbsp;<input type=\"text\" maxlength=\"17\" size=\"20\" name=\"TxtAdmNo\" id=\"adno\" value=\"%\">&nbsp;&nbsp;&nbsp;&nbsp;<button 
		type=\"submit\" name=\"cmdExtraUni\">Extra Uniforms Ordered</button>&nbsp;&nbsp;&nbsp;<button type=\"submit\" name=\"cmdUniFee\">Payment for Extra Uniforms</button></form><hr>";
		if (isset($_POST['cmdExtraUni'])){
		 	$h=($status==0?"Unpaid":($status==1?"unissued":"issued"));
		 	if (strcmp($fr,"%")==0 && strcmp($st,"%")==0) $h.= " Extra uniforms ordered"; elseif (strcmp($fr,"%")!=0 && strcmp($st,"%")==0) $h.= " form $fr Extra uniforms ordered"; 
		 	elseif (strcmp($fr,"%")==0 && strcmp($st,"%")!=0) $h.= " Extra uniforms of students in $st stream ordered "; else $h.=" Form $fr - $st Extra uniforms ordered";
		 	$h.=" between ".date('D d M, Y',strtotime($start))." and ".date('D d M, Y',strtotime($start));
		}elseif (isset($_POST['cmdUniFee'])){
			if (strcmp($fr,"%")==0 && strcmp($st,"%")==0) $h.= "Extra uniforms Fees"; elseif (strcmp($fr,"%")!=0 && strcmp($st,"%")==0) $h.= " form $fr Extra uniforms fees"; 
		 	elseif (strcmp($fr,"%")==0 && strcmp($st,"%")!=0) $h.= " Extra uniforms of students in $st stream fees "; else $h.=" Form $fr - $st Extra uniforms fees";
		 	$h.=" received between ".date('D d M, Y',strtotime($start))." and ".date('D d M, Y',strtotime($start));
		}else
			$h= "Student Manager - User Manuals (Please Read)";
		print "<h3>".strtoupper($h)."</h3>";
	?>
</body>
</html>
<?php
if (isset($_POST['cmdExtraUni'])):
	$adno=strlen(trim($adno))>0 ? $adno : "%";
	$start=preg_split('/\-/',$start);	$end=preg_split('/\-/',$end);
	if (strcasecmp($adno,"%")==0){
	 	$sql="SELECT pd.purchno,s.`admno`,concat(s.surname,' ',s.onames) as `snames`, concat(sf.`form`,'-',sf.`stream`) As frm,sum(u.amt*pd.qty) as ttl FROM stud s Left Join form sf USING 
		(admno,curr_year) Inner Join (SELECT purchno, admno, status from acc_unifrmpurchase WHERE (purchasedon between '$start[2]-$start[1]-$start[0]' and '$end[2]-$end[1]-$end[0]') and 
		status='$status' and markdel=0)up On (s.admno=up.admno) INNER JOIN acc_unipurchdetails pd  ON (pd.purchno=up.purchno) INNER JOIN acc_uniforms u ON (pd.unifrmno=u.unifrmno) GROUP 
		BY pd.purchno,s.`admno`,s.surname,s.onames,sf.`form`,sf.`stream`,pd.markdel HAVING pd.markdel=0";
	}else{
		if (strcasecmp($findby,"stud_names")==0):
			$adno=mysqli_real_escape_string($conn,$adno);
			$sql="SELECT pd.purchno,s.`admno`,concat(s.surname,' ',s.onames) as `snames`, concat(sf.`form`,'-',sf.`stream`) As frm,sum(u.amt*pd.qty) as ttl FROM stud s Left Join form sf 
			USING (admno,curr_year) Inner Join (SELECT purchno, admno, status FROM acc_unifrmpurchase WHERE status='$status' and markdel=0)up On (s.admno=up.admno) INNER JOIN 
			acc_unipurchdetails pd  ON (pd.purchno=up.purchno) INNER JOIN acc_uniforms u ON (pd.unifrmno=u.unifrmno) GROUP BY pd.purchno,s.`admno`,s.surname,s.onames,sf.`form`,sf.`stream`,
			pd.markdel HAVING ((s.surname LIKE '%$adno%' or s.onames LIKE '%$adno%') and pd.markdel=0)";
		else:
			$sql="SELECT pd.purchno,s.`admno`,concat(s.surname,' ',s.onames) as `snames`, concat(sf.`form`,'-',sf.`stream`) As frm,sum(u.amt*pd.qty) as ttl FROM stud s Left Join form sf 
			USING (admno,curr_year) Inner Join (SELECT purchno, admno, status from acc_unifrmpurchase WHERE status='$status' and markdel=0)up On (s.admno=up.admno) INNER JOIN 
			acc_unipurchdetails pd  ON (pd.purchno=up.purchno) INNER JOIN acc_uniforms u ON (pd.unifrmno=u.unifrmno) GROUP BY pd.purchno,s.`admno`,s.surname,s.onames,sf.`form`,sf.`stream`,
			pd.markdel HAVING s.admno LIKE '$adno' and pd.markdel=0";
		endif;
	} $rsStud=mysqli_query($conn,$sql);
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\><tr bgcolor=\"#eeeeee\"><th>Purchase No.</th><th>Adm. No.</th><th>Names</th><th>Form</th><th>Order Amount</th><th>View 
	Order</th></tr>";
	$total=0; $i=0;
	if (mysqli_num_rows($rsStud)>0):
		while ($rsS=mysqli_fetch_array($rsStud,MYSQLI_NUM)):
			if ($i%2==0) print "<tr>"; else	print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">"; 
			$a=0;	
			foreach($rsS as $sr){
				if ($a!=4):
					if ($a==0) $purchno=$sr;
					print "<td>".strtoupper($sr)."</td>";
				else:
					print "<td align=\"right\">".number_format($sr,2)."</td>"; $total+=$sr;
				endif;
				$a++;
			}
			print "<td align=\"center\"><a href=\"viewunifrm.php?purchno=$purchno\">View</a></td></tr>";
			$i++;
		endwhile;	
	endif;
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"3\" align=\"left\" class=\"b\">".(mysqli_num_rows($rsStud))." Student(s)' Records</td><td align=\"right\"><b>Subtotal Kshs.</b></td><td 
	align=\"right\">".number_format($total,2)."</td><td></td></tr></table>";
	mysqli_free_result($rsStud);
	print "Report Generated on ".date("l F d, Y");
elseif (isset($_POST['cmdUniFee'])):
	$start=preg_split('/\-/',$start);	$end=preg_split('/\-/',$end);
	$rsV=mysqli_query($conn,"SELECT fieldname FROM acc_votes WHERE abbr LIKE 'uniform'"); if (mysqli_num_rows($rsV)==1) list($fn)=mysqli_fetch_row($rsV);	mysqli_free_result($rsV);
	$rsUni=mysqli_query($conn,"SELECT f.recieptno,u.purchno,f.pytdate,f.admno,concat(s.surname,' ',s.onames) as names,concat(sf.form,'-',sf.stream) as frm,f.paytform,f.cmono,f.$fn FROM 
	acc_unifrmpurchase u INNER JOIN acc_feerec f On (u.purchno=f.admno) Inner JOIN stud s on (u.admno=s.admno) Inner JOIN form sf On (s.admno=sf.admno and s.curr_year=sf.curr_year) WHERE 
	(f.pytdate between '$start[2]-$start[1]-$start[0]' and '$end[2]-$end[1]-$end[0]') and f.markdel=0");
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\><tr bgcolor=\"#eeeeee\"><th>Receipt No.</th><th>Purchase No.</th><th>Recieved On</th><th>Adm. No.</th><th>Names</th>
	<th>Form</th><th>Received In</th><th>Trans/Cheque No.</th><th>Amount</th><th>Printable Receipt</th></tr>";
	$total=0; $i=0;
	if (mysqli_num_rows($rsUni)>0):
		while ($rsS=mysqli_fetch_array($rsUni,MYSQLI_NUM)):
			if ($i%2==0) print "<tr>"; else	print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">"; 
			$a=0;	
			foreach($rsS as $sr){
				if ($a!=2 && $a!=8):
					if ($a==0) $purchno=$sr;
					print "<td>".strtoupper($sr)."</td>";
				elseif ($a==2):
					print "<td align=\"right\">".date("D d M, Y",strtotime($sr))."</td>";
				else:
					print "<td align=\"right\">".number_format($sr,2)."</td>"; $total+=$sr;
				endif;
				$a++;
			}
			print "<td align=\"center\"><a href=\"unifrmreciept.php?purchno=$purchno\">View</a></td></tr>";
			$i++;
		endwhile;	
	endif;
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"6\" align=\"left\" class=\"b\">".(mysqli_num_rows($rsUni))." Student(s)' Records</td><td align=\"right\" colspan=\"2\"><b>Subtotal Kshs.
	</b></td><td align=\"right\">".number_format($total,2)."</td><td></td></tr></table>";
	mysqli_free_result($rsUni);
	print "Report Generated on ".date("l F d, Y");
else:
	print "<ol type=\"1\"><li>To <b><u>view students' in  a given form</u></b> in this financial year,<ol type=\"a\"><li>Select Form whose students' are to be 
	viewed, <li>Select the Stream whose students are to be viewed, and<li>Click <b>Show Students</b> button.</ol>";
	print "<li>To  <b><u>find a given student</u></b>,<ol type=\"a\"><li>Select whether to find the student by student's names or admission number,<li>Enter the 
	student's first name or admission number and <li>Click <b>Show Students</b> button.</ol>";
	print "<li>To view <b><u>extra uniform purchases by a student</u></b>,<ol type=\"a\"><li>Follow procedure 1 or 2 above to find the student whose extra uniform purchases are to be 
	viewed<li>In <b>Extra Uniform Actions</b>, View Purchases column click <font color=\"#0000dd\"><u>View</u></font></ol>";
	print "<li>To make <b><u>New Extra Uniform Order</u></b>, <ol type=\"a\"><li>Follow procedure 1 or 2 above to find the student who wants extra uniform <li>In <b>Extra Uniform 
	Actions</b>, Make New Order column click <font color=\"#0000dd\"><u>Order</u></font></ol></ol>";
endif;
mysqli_close($conn);
?>