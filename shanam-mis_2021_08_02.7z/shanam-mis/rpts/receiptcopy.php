<?php
    include_once('shanam.php');
    include_once('../tpl/printing.tpl');
    $recno=$_REQUEST['recno']; $recno=preg_split("/\-/",$recno); //$recno[0] receipt serial no., [1]-where from, [2] 0 Original 1 Duplicate reciept,[3] Voucher No. for fee inkind
    class Accounts{private $acc,$name;
        public function __construct($a,$n){$this->acc=$a; $this->name=$n;} public function valAcc(){return $this->acc;}  public function valName(){return $this->name;}
    }headings('<link href="extra/printsettings.css" rel="stylesheet" media="print"/><style media="print">th.hideborder,td.hideborder{border:0;padding:0;}th.showborder,td.showborder{border:1px solid #000;padding:1px;}
    .showhead{background-color:#777;color:#fff;font-weight:bold;text-align:center;letter-spacing:3px;word-spacing:5px;}table{border:0}</style>',0,4);
    //First 0 - Print dialog on load, second 0 - from where
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr,receipt,receipttype,finyr FROM ss; SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1 and markdel=0; SELECT count(f1.recno) as main,
    count(f2.recno) as misc,sum(if(isnull(f1.amt),0,(f1.amt+f1.bc))) as fee,sum(if(isnull(f2.amt),0,(f2.amt+f2.bc))) as mfee,sum(if(isnull(f1.bc),0,f1.bc)) as bc,sum(if(isnull(f2.bc),0,f2.bc)) as mbc FROM acc_incofee i
    Left Join acc_incorecno0 f1 USING (sno) Left Join acc_incorecno1 f2 USING (sno) GROUP BY i.sno HAVING i.sno LIKE '$recno[0]';SELECT abbr FROM terms Inner Join ss USING (finyr) ORDER BY tno ASC;");
    $ac1=$ac2=false; $i=$famt=$mfamt=$bc=$mbc=0;
    do{
        if($rs=mysqli_store_result($conn)){ //recSize [0] A4 Paper, [1] A5 Paper, recType[0] - 2in1, [1] - Single
          if ($i==0) list($scnm,$scadd,$recsize,$rectype,$fy)=mysqli_fetch_row($rs); elseif($i==1){$noacs=mysqli_num_rows($rs); while($d=mysqli_fetch_row($rs)) $accounts[]=new Accounts($d[0],$d[1]);
          }elseif($i==2){while ($d=mysqli_fetch_row($rs)){$ac1=($d[0]>0?true:false);  $ac2=($d[1]>0?true:false); $famt=$d[2]; $mfamt=$d[3]; $bc=$d[4]; $mbc=$d[5];}
        }else{while(list($trm)=mysqli_fetch_row($rs)) $terms[]=$trm;}mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
    $rpt='<table class="table table-sm table-borderless"><tr><td rowspan=3 class="hideborder" style="border-bottom:2px solid #00d !important" width="75"><img src="/gen_img/logo.jpg" width=70 height=70 vspace=1 hspace=1>
    </td><td style="font-weight:bold;font-size:0.9rem;" colspan=2 class="hideborder">'.$scnm.'</td></tr><tr><td style="font-weight:bold;font-size:0.9rem;" colspan=2 class="hideborder">'.$scadd.'</td></tr><tr><td
    class="hideborder" style="border-bottom:2px solid #00d !important;font-weight:bold;font-size:0.9rem;letter-spacing:1px;word-spacing:2px;">OFFICIAL RECEIPT</td><td align="right" class="hideborder"
    style="border-bottom:2px solid #00d !important;">Printed On '.date("D d M,Y").'</td></tr>'; $amtfee=0;
    if ($ac1 && $ac2) $sql="SELECT r.recno,m.recno as mrec,r.acc,f.admno,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby,month(f.pytdate) as mon,f.sno,s.curr_year FROM acc_incofee f Inner Join acc_incorecno0 r
    USING (sno) Inner Join acc_incorecno1 m USING (sno) Inner Join stud s On (f.admno=s.admno) WHERE f.sno LIKE '$recno[0]'"; //Receipt details
    elseif ($ac1 && !$ac2) $sql="SELECT r.recno,0 as mrec,r.acc,f.admno,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby,month(f.pytdate) as mon,f.sno,s.curr_year FROM acc_incofee f Inner Join acc_incorecno0 r
    USING (sno) Inner Join stud s On (f.admno=s.admno)  WHERE f.sno LIKE '$recno[0]'"; //Receipt details
    else $sql="SELECT 0 as rno, r.recno,r.acc,f.admno,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby,month(f.pytdate) as mon,f.sno,s.curr_year FROM acc_incofee f Inner Join acc_incorecno1 r  USING (sno) Inner
    Join stud s On (f.admno=s.admno) WHERE r.sno LIKE '$recno[0]'"; //reciept details
    $rsRec=mysqli_query($conn,$sql);	list($rec,$mrec,$acc,$admno,$date,$paidby,$pytfrm,$cheno,$amt,$bc,$un,$mon,$sno,$acyr)=mysqli_fetch_row($rsRec); mysqli_free_result($rsRec);
    $cheno=strlen($cheno)==0?"__________":$cheno;  if ($mon<5) $term="One"; elseif ($mon<9) $term="Two"; else $term="Three"; if($ac1){$mbc=0;}else{$mbc=$bc;$bc=0;}
    $rec=($rec>0?$rec:$mrec);
    //Details of student and respective balance
    if($acyr===$fy){
        $sql="SELECT s.admno,s.stud_names,s.cls,if(((s.t1f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))<=0,0,((s.t1f+ar.arbf+
        if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0))-if(isnull(f.fee),0,f.fee))) as t1bal, if((s.t2f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee)-if((s.t1f-
        if(isnull(f.fee),0,f.fee))<=0,0,(s.t1f-if(isnull(f.fee),0,f.fee))))) as t2bal,if((s.t3f-if(isnull(f.fee),0,f.fee))<=0,0,(s.t3f-if(isnull(f.fee),0,f.fee)-if((s.t2f-if(isnull(f.fee),0,
        f.fee))<=0,0,(s.t2f-if(isnull(f.fee),0,f.fee))))) as t3bal,(s.t3f+ar.arbf+if(ar.acspemed=1,ar.med,0)+if(ar.acunifrm=1,ar.uni,0)-if(isnull(f.fee),0,f.fee)) as ybal,";
        if($noacs==1)$sql.="0 as mt1bal,0 as mt2bal,0 as mt3bal,0 as mybal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,s.curr_year,
        sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc=1,cf.T2,0)) as t2f,sum(if(v.acc=1,cf.T3,0)) as t3f FROM  stud s INNER JOIN class c USING (admno, curr_year) INNER JOIN classnames cn USING (clsno)
        INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY s.admno,s.surname,s.onames,s.Curr_Year,cn.clsname,
        c.stream,a.stud_assoc,s.present,s.markdel HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$admno')s INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.spemed) as med,
        sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM
        `acc_votesassigned`)x GROUP BY admno, markdel HAVING markdel=0 and admno LIKE '$admno')ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-
        v.spemed-v.prep-v.unifrm)) as fee FROM acc_incofee f left Join acc_incorecno0 v USING (sno) ";
        else $sql.="if(((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee))<=0,0,((s.mt1f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-
        if(isnull(f.mfee),0,f.mfee))) as mt1bal,if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-if(isnull(f.mfee),0,f.mfee)-if((s.mt1f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt1f-
        if(isnull(f.mfee),0,f.mfee))))) as mt2bal,if((s.mt3f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt3f-if(isnull(f.mfee),0,f.mfee)-if((s.mt2f-if(isnull(f.mfee),0,f.mfee))<=0,0,(s.mt2f-
        if(isnull(f.mfee),0,f.mfee))))) as mt3bal,((s.mt3f+ar.marbf+if(ar.acspemed!=1,ar.med,0)+if(ar.acunifrm!=1,ar.uni,0))-if(isnull(f.mfee),0,f.mfee)) as mybal FROM (SELECT s.admno,
        concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,s.curr_year,sum(if(v.acc=1,cf.T1,0)) as t1f,sum(if(v.acc!=1,cf.T1,0)) as mt1f,sum(if(v.acc=1,
        cf.T2,0)) as t2f,sum(if(v.acc!=1,cf.T2,0)) as mt2f,sum(if(v.acc=1,cf.T3,0)) as t3f,sum(if(v.acc!=1,cf.T3,0)) as mt3f FROM  stud s INNER JOIN class c USING (admno, curr_year) INNER
        JOIN classnames cn USING (clsno) INNER JOIN clsfee cf USING (admno,curr_year) INNER JOIN acc_votes v On (cf.voteno=v.sno) Inner Join acc_voteacs a on (a.acNo=v.acc) GROUP BY
        s.admno,s.surname,s.onames,s.Curr_Year,cn.clsname,c.stream,a.stud_assoc,s.present,s.markdel HAVING s.present=1 and s.markdel=0 and a.stud_assoc=1 and s.admno LIKE '$admno')s
        INNER JOIN (SELECT c.admno,sum(c.bbf) as arbf,sum(c.miscbf) as marbf,sum(c.spemed) as med,sum(c.unifrm) as uni,x.acspemed,x.acunifrm FROM class c,(SELECT sum(case when
        name='spemed' then acc else 0 end) as acspemed, sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM `acc_votesassigned`)x GROUP BY admno, markdel HAVING markdel=0
        and admno LIKE '$admno')ar ON (s.admno=ar.admno) LEFT JOIN (SELECT f.admno,if(isnull(sum(v.amt)),0,sum(v.amt-v.refunds-v.arrears-v.spemed-v.prep-v.unifrm)) as fee,
        if(isnull(sum(m.amt)),0,sum(m.amt-m.arrears-m.spemed-m.unifrm)) as mfee FROM acc_incofee f left Join acc_incorecno0 v USING (sno) Left Join acc_incorecno1 m USING (sno) ";
        $sql.="GROUP BY f.admno,f.markdel HAVING f.markdel=0 and f.admno LIKE '$admno')f on (s.admno=f.admno)";
        //alumni details
    }else $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream, ' ',s.curr_year) As cls,0 as t1b,0 as t2b,cf.arr as t3b,cf.arr as bal,0 as mt1b,
    0 as mt2b,0 as mt3b,0 as mbal FROM  stud s INNER JOIN class c USING (admno, curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN (SELECT admno,sum(alumniarrears) as arr FROM class
    GROUP BY admno, markdel HAVING markdel=0 and admno LIKE '$admno')cf USING (admno) WHERE s.admno LIKE '$admno'";
    $rsBal=mysqli_query($conn,$sql); list($stadmno,$stnames,$stcls,$t1,$t2,$t3,$bal,$mt1,$mt2,$mt3,$mbal)=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);
    //Display data
    $rpt.='<tr><td class="hideborder" colspan="2"><b>Receipt No. <u>'.$rec.'</u></b></td><td class="hideborder" style="text-align:right;">Received On '.date("D d-M-Y",strtotime($date)).'</td></tr><tr><td
    class="hideborder" colspan="3">Received From &nbsp;&nbsp;<span style="font-weight:bold;font-size:12pt;letter-spacing:4px;word-spacing:6px;bgcolor="#eee">'.$stnames.'</span></td></tr><tr><td class="hideborder"
    colspan="3">Admission No. '.$stadmno.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Class:</b> '.strtoupper($stcls).'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Received In '.$pytfrm.'</td></tr>';
    $rpt.='<tr><td class="hideborder" colspan="3">Trans/ Cheque No. '.$cheno.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fees Paid By '.$paidby.' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Term &nbsp; '.$term.'</td></tr><tr><td colspan=3 class="hideborder"><Img src="/gen_img/'.($recno[2]==0?'washout.jpg" width=300':'duplicate.jpg" width=400').' height=300
    style="position:absolute;opacity:0.2;pointer-events:none;"><table align="center" class="table table-sm table-borderless"><tr>';
    //footer of student receipt
    if($acyr===$fy) $foot='<tr><td colspan=3 class="showborder"><b>'.$terms[0].' </b>&nbsp;<u>'.number_format(($t1+$mt1),2).'</u>&nbsp;&nbsp;&nbsp;<b>'.$terms[1].' </b>&nbsp;<u>'.
    number_format(($t2+$mt2),2).'</u>&nbsp;&nbsp;&nbsp;<b>'.$terms[2].' </b>&nbsp;<u>'.number_format(($t3+$mt3),2).'</u>&nbsp;&nbsp;&nbsp;<b>Total Bal. </b>&nbsp;<u>'.
    number_format(($bal+$mbal),2).'</u></td></tr>';
    //footer of alumni receipt
    else $foot='<tr><td colspan=3 class="showborder"><b>Balance of Arrears B/F (KShs.)</b>&nbsp;&nbsp;&nbsp;<u>'.number_format(($bal+$mbal),2).'</u></td></tr>';
    $foot.='<tr><td colspan="3" class="hideborder"><br><br>Served By <u><b>'.$un.'</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign________________</td></tr><tr><td colspan="3" style="color:#aaa;
    font-size:7px;border-top:2px solid #666 !important" class="hideborder"><center>The receipt is invalid without official stamp. Designed By: Shanams Digital Solutions +254736732168</center></td></tr></table>';$vote='';
    if ($rectype==0){$i=1;//2in1 reciepts
        foreach($accounts as $acc){
            $vote.='<td class="hideborder"><table class="table table-sm table-bordered" align="center" style="font-size:12px;"><tr style="letter-spacing:1px;word-spacing:2px;"><th
            colspan=2 class="showborder">'.strtoupper($acc->valName()).' VOTEHEADS DISTRIBUTION</th></tr><tr><th class="showborder">BEING PAYMENT FOR</th><th class="showborder">AMOUNT
            </th></tr>';
            $rs=mysqli_query($conn,"SELECT ucase(v.descr), if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Inner Join (SELECT f.voteno,f.amt FROM acc_incovotes f Inner Join ".($i==1?"acc_incorecno0":"acc_incorecno0").
            " v USING (recno) WHERE v.sno LIKE '$sno' and f.markdel=0 and f.acc='".$acc->valAcc()."')f ON (v.sno=f.voteno) WHERE v.acc='".$acc->valAcc()."' ORDER BY v.sno ASC"); $ttl=0;
            while(list($v,$f)=mysqli_fetch_row($rs)){ $vote.='<tr><td class="showborder">'.$v.'</td><td style="text-align:right;" class="showborder">'.number_format($f,2).'</td></tr>'; $ttl+=$f;} $ttl+=($i==0?$bc:$mbc);
            $vote.='<tr><td class="showborder">BANK CHARGES</td><td style="text-align:right;" class="showborder">'.number_format(($i==0?$bc:$mbc),2).'</td></tr><tr><th class="showborder">
            TOTAL A/C AMOUNT</th><th style="text-align:right;" class="showborder">'.number_format($ttl,2).'</th></tr></table></td>'.($i==1?'</td><td class="hideborder">--</td>':'</td>'); $i++;
        } $ttl=($famt+$mfamt);
        $rpt.=$vote.'</tr></table></td></tr><tr><td colspan=3 class="hideborder">Total Fees Received Kshs.&nbsp;&nbsp;'.number_format($ttl,2).'<span style="font-weight:bold;text-decoration:underline solid #00f;"> ('.
        NumToWord($ttl).')</span></td></tr><tr><td colspan=3 class="showborder" style="text-align:center;background:#ddd;font-weight:bold;letter-spacing:6px;word-spacing:8px;">FEES BALANCE ANALYSIS</td></tr>'.$foot;
        //<div class="container page landscape-parent"><div class="form-row landscape">   <div class="container page"><div class="content">
        echo '<table class="table table-bordered table-sm" style="width:fit-content;width:500px;"><tr><td class="showborder">'.$rpt.'</td></tr></table>'; //</div></div>
    }else{  $i=0; $another=$rpt1=$rpt2='';
        foreach($accounts as $acc){
            $ttl=0; $v='<td><table border="1" CLASS="table table-sm table-bordered" style="width:100%;font-size:0.9rem;"><tr><td colspan=2 class="n"><b>'.strtoupper($acc->valName()).'VOTEHEAD DISTRIBUTION </td></tr>
            <tr><td class="n"><b>BEING PAYMENT FOR</b></td><td class="n"><b>AMOUNT (KSHS.)</b></td></tr>';
            $rs=mysqli_query($conn,"SELECT ucase(v.descr),if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Inner Join (SELECT f.voteno,f.amt FROM acc_incovotes f Inner Join ".($i==0?"acc_incorecno0":"acc_incorecno1").
            " v USING (recno) WHERE v.sno LIKE '$sno' and f.markdel=0 and f.acc='".$acc->valAcc()."')f ON (v.sno=f.voteno) WHERE v.acc='".$acc->valAcc()."' ORDER BY v.sno ASC");
            if ($i==0){$vote.=$v;  while(list($v,$f)=mysqli_fetch_row($rs)){$vote.='<tr><td class="n">'.$v.'</td><td style="text-align:right;" class="n">'.number_format($f,2).'</td></tr>'; $ttl+=$f;} $ttl+=$bc;
            }else{$another.=$v;    while(list($v,$f)=mysqli_fetch_row($rs)){$another.='<tr><td class="n">'.$v.'</td><td style="text-align:right;" class="n">'.number_format($f,2).'</td></tr>'; $ttl+=$f;} $ttl+=$mbc;
            }$v='<tr><td class="n">BANK CHARGES</td><td style="text-align:right;" class="n"><b>'.number_format(($i==0?$bc:$mbc),2).'</b></td></tr><tr><td class="n"><b>TOTAL A/C AMOUNT</b>
            </td><td style="text-align:right;" class="n"><b>'.number_format($ttl,2).'</b></td></tr></table></td></tr>';
            if ($i==0) $vote.=$v.'</table></td></tr><tr><td colspan=3 class="hideborder" style="background:#eee;font-weight:bold;text-align:center;">Kshs.&nbsp;'.number_format($famt,2).'<span style="font-weight:bold;
            text-decoration:underline blue solid;"> ('.NumToWord($famt).')</span></td></tr><tr><td colspan="3" style="text-align:center;border-top:1px solid #000;border-bottom:1px solid #000;background:#ddd;
            font-weight:bold;letter-spacing:6px;word-spacing:8px;">FEES BALANCE ANALYSIS</td></tr>';
            else $another.=$v.'</table></td></tr><tr><td colspan="3" style="background:#eee;word-spacing:2px;letter-spacing:1px;font-weight:bold;text-align:center;">Total Fees Received Kshs.&nbsp;&nbsp;&nbsp;'.
            number_format($mfamt,2).'<span style="font-weight:bold;text-decoration:underline blue solid;">('.NumToWord($mfamt).')</span></td></tr><tr><td colspan="3" style="text-align:center;background:#ddd;
            font-weight:bold;letter-spacing:6px;word-spacing:8px;border-top:1px;border-bottom:1px;">FEES BALANCE ANALYSIS</td></tr>';  $i++;
        }$rpt1=$rpt.$vote.$foot;	$rpt2=$rpt.$another.$foot;
        echo '<table class="table table-bordered table-sm" style="table-layout:fixed;width:600px;"><tr><td class="showborder">';
        if($ac1 && $ac2) echo $rpt1.'</td></tr><tr style="page-break-inside:avoid;"><td class="showborder">'.$rpt2; elseif ($ac1 && !$ac2) echo $rpt1; else echo $rpt2;
        echo '</td></tr></table>';//</div></div>
    }if ($recno[3]>0){//PV for fees in kind
        echo '<div id="invoice"><div class="invoice overflow-auto"><div style="min-width:600px"><header><div class="row"><div class="col"
        style="max-width:70px;"><img width="60" height="60"src="../../gen_img/logo.jpg" vspace="1" hspace="1" data-holder-rendered="true"/></div><div class="col company-details"><h6
        class="name">'.$scnm.'</h6><div><h6>'.strtoupper($scadd).'</h6></div><div><b>SCHOOL FUND PAYMENT VOUCHER</b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On
        &nbsp;'.date("D d-M-Y").' </span></div></div></div></header>';
        mysqli_multi_query($conn,"SELECT e.vono,p.payee,p.telno,p.address,p.idno,e.pytdate,a.abbr,e.caamt,e.chamt,e.rmks FROM acc_exp e Inner Join acc_exppayee p on e.expno=p.payno Inner
        Join acc_voteacs a On (e.acc=a.acno) WHERE e.acc=1 and e.vono LIKE '$recno[3]' and e.markdel=0; SELECT v.descr,month(e.pytdate) as m,p.amt FROM acc_exp e Inner Join acc_pytvotes p
        USING (vono,acc) Inner Join acc_votes v on (p.voteno=v.sno) WHERE e.vono LIKE '$recno[3]' and e.acc=1;"); $i=0;
        do{
            if($rs=mysqli_store_result($conn)){
                if($i==0){
                    list($vono,$payee,$tel,$addr,$idno,$date,$acc,$caamt,$chamt,$rmks)=mysqli_fetch_row($rs);
                    echo "<main><div class=\"row contacts\"><div class=\"col invoice-to\"><div class=\"text-gray-light\" style=\"font-weight:bold;\">VOUCHER NO. $vono <span
                    style=\"float:right;width:250px;\"><input type=\"text\" name=\"txtDate\" style=\"text-align:right;\" value=\"Paid On: ".date("D d F, Y",strtotime($date))."\"
                    class=\"gen\"></span></div><br><p class=\"to\">Payee's Names: <b style=\"text-decoration:underline double #999;letter-spacing:6px;word-spacing:9px;\">".$payee.
                    "</b></p><br>";
                    echo "<div style=\"text-align:center;\"><span style=\"float:left;\">ID/Passport No. ".(strlen($idno)>0?$idno:"_________________")."</span>Telephone No. ".
                    (strlen($tel)>0?$tel:"_____________")."<span style=\"float:right;\">LPO No. _______________</span></div><br><div class=\"address\">Postal Address: <span
                    style=\"font-weight:normal;letter-spacing:4px;word-spacing:6px;\">$addr</span></div></div></div>";
                    echo "<table border=\"1\" class=\"table table-sm table-bordered\"><thead class=\"thead-dark\"><tr><th rowspan=2>Date</th><th rowspan=2>Payment Particulars</th><th
                    colspan=2>Amount Paid (Kshs.)</th></tr><tr><th>Cash</th><th>Cheque</th></tr></thead><tbody><tr><td valign=\"top\" align=\"right\">".date("d-M-Y",strtotime($date)).
                    "</td><td><textarea style=\"border:0;\" cols=\"65\" rows=\"4\">$rmks</textarea></td><td valign=\"top\" style=\"text-align:right;\">".number_format($caamt,2).
                    "</td><td valign=\"top\" style=\"text-align:right;\">".number_format($chamt,2)."</td></tr><tr><td style=\"text-align:right;\" colspan=2><b>Total Amount Paid (Kshs.)
                    </b></td><td style=\"text-align:right;\" colspan=2><b>".number_format(($caamt+$chamt),2)."</b></td></tr></table><br>";
                    echo "<div>Amount In Words: ".NumToWord(preg_replace("/[^0-9\.]/","",number_format(($caamt+$chamt),2)))."</div><div style=\"text-align:center;\"><span
                    style=\"float:left;\">Paid by: <b><u>Cash</u></b></span>Cheque No. __________'<span style=\"float:right;\">Paid On ". date("l, d F, Y",strtotime($date))."</span></div><br>";
                    echo "<table border=\"1\" class=\"table-condensed\"><thead><tr><th>#</th><th>Votehead Description</th><th>Detail</th><th>C/R</th><th>Amount (Kshs)</th></tr></thead><tbody>";
                }else{ $a=1;
                    while(list($v,$m,$am)=mysqli_fetch_row($rs)){
                        echo "<tr><td class=\"n\">$a</td><td class=\"n\">$v</td><td class=\"n\"></td><td align=\"center\" class=\"n\">$m</td><td style=\"text-align:right;\" class=\"n\">".
                        number_format($am,2)."</td></tr>"; $a++;
                    }while($a<5){echo "<tr><td class=\"n\">$a</td><td class=\"n\"></td><td class=\"n\"></td><td align=\"center\" class=\"n\"></td><td class=\"n\"></td></tr>"; $a++;}
                }mysqli_free_result($rs);
            }$i++;
        }while(mysqli_next_result($conn));
        echo "</tbody><tfoot><tr><td colspan=\"3\" align=\"right\"><b>Total Amount Costed (Kshs.)</b></td><td colspan=\"2\" align=\"right\"><b>".number_format(($caamt+$chamt), 2)."</b></td>
        </tr></tfoot></table>";
        echo "<div class=\"notices\"><div><b>SIGNING:</b></div><div>Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV><br><br>";
        echo "<div>Payee Names _________________________________&nbsp;ID No. _______________ &nbsp;Sign _________________&nbsp;&nbsp;Date ___________</div><br><br>";
        echo "<div>Authorized By ____________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Principal</div></DIV></main>";
        echo "<footer>The payment voucher is computer generated and is invalid without required signatures. Designed By: Shanams Digital Solutions +254736732168 .</footer></div><div>
        </div></div>";
    }
?>
<?php mysqli_close($conn); footer(0); ?>
