<?php
    include_once('shanam.php'); include_once('../tpl/printing.tpl');
    $vono=isset($_REQUEST['r'])?sanitize($_REQUEST['r']):'0~0~0~0'; $vono=explode("~",$vono); //[0] 1-petty,2-comt,%-all, [1]- start date [2] end date,[3] Account Costed
    headings('<style>.r{text-align:right !important;}td,th{border:1px solid #00d !important}</style>',1,2);
    if($vono[0]==1){//Pettycash payments
      $sql="SELECT e.vono,e.pytdate,p.idno,p.payee,p.telno,e.pytfrm,e.cheno,if(length(e.rmks)>50,left(e.rmks,50),e.rmks) as rmks,e.caamt,e.chamt,(e.chamt+e.caamt) as ttl FROM acc_exppayee p Inner Join acc_exp e
      ON (p.payno=e.expno) WHERE (e.pytdate BETWEEN '$vono[1]' and '$vono[2]') and e.acc LIKE '$vono[3]' and e.commt!=1 ORDER BY e.pytdate,e.vono ASC";
    }elseif($vono[0]==2){
      $sql="SELECT e.vono,e.pytdate,p.idno,p.name,p.telno,e.pytfrm,e.cheno,if(length(e.rmks)>50,left(e.rmks,50),e.rmks) as rmks,e.caamt,e.chamt,(e.chamt+e.caamt) as ttl FROM acc_creditors p Inner Join acc_exp e ON
      (p.cred_no=e.expno) WHERE (e.pytdate BETWEEN '$vono[1]' and '$vono[2]') and e.acc LIKE '$vono[3]' and e.commt=1 ORDER BY e.pytdate,e.vono ASC";
    }else{
      $sql="SELECT e.vono,e.pytdate,p.idno,p.payee,p.telno,e.pytfrm,e.cheno,if(length(e.rmks)>50,left(e.rmks,50),e.rmks) as rmks,e.caamt,e.chamt,(e.chamt+e.caamt) as ttl FROM acc_exppayee p Inner Join acc_exp e ON
      (p.payno=e.expno) WHERE (e.pytdate BETWEEN '$vono[1]' and '$vono[2]') and e.acc LIKE '$vono[3]' and e.commt!=1 UNION SELECT e.vono,e.pytdate,p.idno,p.name,p.telno,e.pytfrm,e.cheno,if(length(e.rmks)>50,
      left(e.rmks,50),e.rmks) as rmks,e.caamt,e.chamt,(e.chamt+e.caamt) as ttl FROM  acc_creditors p Inner Join acc_exp e ON (p.cred_no=e.expno) WHERE (e.pytdate BETWEEN '$vono[1]' and '$vono[2]') and e.acc LIKE
      '$vono[3]' and e.commt=1 ORDER BY pytdate,vono ASC";
    } mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr FROM ss; SELECT abbr FROM acc_voteacs WHERE acno LIKE '$vono[3]'; $sql;"); $nop=$cash=$cheque=$ttl=$i=0;$acname="ALL ACCOUNTS";$table='';
    do{if($rs=mysqli_store_result($conn)){
        if($i==0){if(mysqli_num_rows($rs)==1) list($scnm,$scadd)=mysqli_fetch_row($rs);}elseif($i==1){if(mysqli_num_rows($rs)==1) list($acname)=mysqli_fetch_row($rs);
        }else{$nop=mysqli_num_rows($rs); $c=1;
          if ($nop>0){ while($da=mysqli_fetch_row($rs)){$table.="<tr><td>$c</td><td>$da[0]</td><td class=\"r\">".date('D d M, Y',strtotime($da[1]))."</td><td>$da[2]</td><td>$da[3]</td><td>$da[4]</td><td>$da[5]
            </td><td>$da[6]</td><td>$da[7]</td><td class=\"r\">".number_format($da[8],2)."</td><td class=\"r\">".number_format($da[9],2)."</td><td class=\"r\">".number_format($da[10],2)."</td></tr>";
             $cheque+=$da[9]; $ttl+=$da[10]; $c++;}
          }else $table.='<tr><td colspan="11">NO PAYMENT RECORDS ARE AVAILABLE</td></tr>';mysqli_free_result($rs);
        }
      }$i++;
    }while(mysqli_next_result($conn)); $table.="</tbody><tfoot><tr><th colspan=\"5\">$nop Payment Records</th><th class=\"r\" colspan=\"4\">TOTALS</th><th class=\"r\">".number_format($cash,2)."</th><th class=\"r\">".
    number_format($cheque,2)."</th><th class=\"r\">".number_format($ttl,2)."</th></tr></tfoot>";
?>
<div id="invoice"><div class="invoice overflow-auto"><div style="min-width:600px">
  <header><div class="row"><div class="col" style="max-width:70px;"><img width="60" height="60" src="/gen_img/logo.jpg" vspace="1" hspace="1" data-holder-rendered="true"/></div>
    <div class="col company-details"><h6 class="name"><?php echo $scnm;?></h6><div><h6><?php echo strtoupper($scadd);?></h6></div><div><b><?php echo $acname;?> PAYMENTS</b><span style="font-size:9pt;float:right;
    font-weight:normal;">Printed On&nbsp;<?php echo date("D d-M-Y");?></span></div></div></div>
  </header><main>
    <table style="font-size:9pt"><thead><tr><th rowspan="2">#</th><th rowspan="2">VOUCHER</th><th rowspan="2">PAID ON</th><th colspan="3">DETAILS OF PAYEE/ CREDITOR</th><th colspan="3">
    DETAILS OF THE PAYMENT</th><th colspan="3">AMOUNT PAID (KSHS.)</th></tr><tr><th>ID. NO.</th><th>NAMES</th><th>TEL NO.</th><th>MODE</th><th>CHEQUE NO.</th><th>NARRATION</th><th>CASH</th><th>CHEQUE</th><th>TOTAL
    </th></tr></thead><tbody><?php echo $table;?></table><br><br>
    <div class="notices">Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;Date ______________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV>
  </main>
</div></div></div>
<?php  mysqli_close($conn); footer(0); ?>
