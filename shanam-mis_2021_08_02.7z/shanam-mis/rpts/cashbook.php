<?php
    include_once('shanam.php'); include_once('../tpl/printing.tpl');
    $rec=isset($_REQUEST['r'])?sanitize($_REQUEST['r']):'0~0~0'; $rec=explode("~",$rec); //[0] 1-Account, [1]- start date [2] end date
    class Incomes{
      private $date,$commt,$cash,$bank; public function __construct($d,$co,$c,$b){$this->date=$d; $this->cash=$c; $this->bank=$b; $this->commt=$co;} public function valDate(){return $this->date;}
      public function valCash(){return $this->cash;} public function valBank(){return $this->bank;} public function valCommt(){return $this->commt;}
    } headings('<style>.r{text-align:right !important;}td,th{border:1px solid #00d !important}tr{break-inside:avoid}</style>',1,2);
    mysqli_multi_query($conn,"SELECT v.sno,v.abbr FROM acc_votes v WHERE v.acc LIKE '$rec[0]' and markdel=0 ORDER BY v.sno ASC; SELECT descr FROM acc_voteacs WHERE acno LIKE '$rec[0]'; SELECT finyr,scnm,concat(scadd,
    ', Tel No. ',telno) as addr FROM ss;"); $vo=$f=$cols=''; $i=$novotes=0;
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0) while($row=mysqli_fetch_row($rs)){ $f.= ",SUM(IF(v.voteno='$row[0]',v.amt, 0)) as `$row[1]` "; $cols.='<th class="s">'.$row[1].'</th>'; $ttlinco[]=0; $ttlexp[]=0; $novotes++;}
        elseif($i==1) list($acname)=mysqli_fetch_row($rs); else list($finyr,$scnm,$scadd)=mysqli_fetch_row($rs); mysqli_free_result($rs);
      }$i++;
    }while(mysqli_next_result($conn)); array_push($ttlinco,0,0,0); array_push($ttlexp,0,0,0);
    if($rec[0]<3){// Main & Misc A/c
      $sql="SELECT pytdate,if(f.commt=0,'Fees from Students',if(f.commt=1,'Inter Account Borrowing',if(f.commt=2,'Other Incomes','Salary Recoveries'))) as frm,sum(Cash) As Cas,sum(bank) As Ban FROM (SELECT f.pytdate,
      f.commt,sum(If((f.pytfrm LIKE 'cash' Or f.pytfrm LIKE 'money order' Or f.pytfrm LIKE 'kind'),(i.amt-i.transfer),0)) As cash,sum(if((f.pytfrm LIKE 'Cheque' Or f.pytfrm LIKE 'direct banking' Or f.pytfrm LIKE
      'm-fees'),(i.amt-i.transfer),0)) As Bank FROM acc_incofee f Inner Join ".($rec[0]==1?"acc_incorecno0":"acc_incorecno1")." i USING (sno) GROUP BY i.acc,f.markdel,f.pytdate,f.commt HAVING (f.pytdate Between
      '$rec[1]' and '$rec[2]') and markdel=0 and i.acc LIKE '$rec[0]')f GROUP BY f.pytdate,f.commt  ORDER BY f.pytdate,f.commt Asc;";
      $sql.="SELECT i.pytdate,if(i.commt=0,'Fees from Students',if(i.commt=1,'Inter Account Borrowing',if(i.commt=2,'Other Incomes','Salary Recoveries'))) as frm $f FROM acc_incofee i Inner Join ".($rec[0]==1?
      "acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY i.pytdate,f.acc,i.commt,i.markdel HAVING (i.pytdate BETWEEN '$rec[1]' and '$rec[2]') and f.acc LIKE
      '$rec[0]' and i.markdel=0 ORDER BY i.pytdate,i.commt ASC;";
    }else{// FSE Accounts
      $sql="SELECT recon,commt,sum(Cash) As Cas,sum(bank) As Ban FROM (SELECT f.recon,f.commt,sum(If(f.mode LIKE 'cash',f.amt,0)) As cash, sum(if(f.mode Not LIKE 'cash',f.amt,0)) As Bank FROM acc_fseincome f GROUP
      BY f.acc,f.markdel,f.recon,f.commt HAVING (f.recon Between '$rec[1]' and '$rec[2]') and markdel=0 and f.acc LIKE '$rec[0]')f GROUP BY f.recon,f.commt  ORDER BY f.recon,f.commt Asc;";
      $sql.="SELECT f.recon,if(f.commt=0,'FSE Funds',if(f.commt=1,'Inter Account Borrowing',if(f.commt=2,'FSE Arrears',if(f.commt=3,'Salary Recoveries','Other Incomes')))) as frm $f FROM acc_fseincome f Inner Join
      acc_fsevotes v USING (recno,acc) GROUP BY f.pytdate,f.commt,f.markdel HAVING (f.pytdate BETWEEN '$rec[1]' AND '$rec[2]') AND i.acc LIKE '$rec[0]' ORDER BY  f.pytdate,f.commt ASC";
    }$sql.="SELECT e.pytdate,p.payee,e.vono,e.cheno,e.caamt,e.chamt,(e.caamt+e.chamt) as ttl $f FROM acc_exp e Inner Join acc_exppayee p ON (e.expno=p.payno) Inner JOIN acc_pytvotes v USING (acc,vono) GROUP BY
    e.pytdate,p.payee,e.vono,e.cheno,e.caamt,e.chamt,e.acc,e.vono,e.expno,e.commt,e.markdel HAVING e.acc LIKE '$rec[0]' and (e.pytdate BETWEEN '$rec[1]' AND '$rec[2]') and e.markdel=0 and e.commt!=1 UNION SELECT
    e.pytdate,c.name,e.vono,e.cheno,e.caamt,e.chamt,(e.caamt+e.chamt) as ttl $f FROM acc_exp e Inner Join acc_creditors c ON (e.expno=c.cred_no) Inner JOIN acc_pytvotes v USING (acc,vono) GROUP BY e.pytdate,c.name,
    e.vono,e.cheno,e.caamt,e.chamt,e.acc,e.vono,e.expno,e.commt,e.markdel HAVING e.acc LIKE '$rec[0]' and (e.pytdate BETWEEN '$rec[1]' AND '$rec[2]') and e.markdel=0 and e.commt='1' ORDER BY pytdate,vono ASC;";
    mysqli_multi_query($conn,$sql) or die(mysqli_error($conn). ". Click <a href=\"../cashbook.php\">HERE</a> to go back."); $tableinco=$tableexp=''; $i=0;
    do{
      if($rs=mysqli_store_result($conn)){
        if($i==0){while($d=mysqli_fetch_row($rs)) $incomes[]=new Incomes($d[0],$d[1],$d[2],$d[3]);
        }elseif($i==1){ if(mysqli_num_rows($rs)>0){ $ic=0;
          while($d=mysqli_fetch_row($rs)){$tableinco.="<tr>"; $c=0;
            foreach($d as $val){if($c==0){$tableinco.="<td class=\"r\">".date('D d M,Y',strtotime($val))."</td>";}elseif($c==1){$tableinco.="<td>$val</td><td class=\"r\">".number_format(floatval($incomes[$ic]->valCash()),
              2)."</td><td class=\"r\">".number_format(floatval($incomes[$ic]->valBank()),2)."</td><td class=\"r\">".number_format((floatval($incomes[$ic]->valCash())+floatval($incomes[$ic]->valBank())),2)."</td>";
              $ttlinco[0]+=floatval($incomes[$ic]->valCash());       $ttlinco[1]+=floatval($incomes[$ic]->valBank());  $ttlinco[2]+=floatval($incomes[$ic]->valCash())+floatval($incomes[$ic]->valBank());
              } else{$tableinco.="<td class=\"r\">".number_format(floatval($val),2)."</td>"; $ttlinco[$c+1]+=floatval($val);} $c++;
            }$tableinco.="</tr>"; $ic++;}
          }else{$tableinco.="<tr><td colspan=\"".($novotes+5)."\">No fees receipts were made between ".date("D d-M-Y",strtotime($rec[1]))." And ".date("D d-M-Y",strtotime($rec[2]))."</td></tr>";}
          $tableinco.="</tbody><tfoot><tr><th colspan=\"2\" class=\"r\">Income Subtotals (Kshs.)</th>";
          foreach($ttlinco as $val) $tableinco.="<td class=\"r\">".number_format(floatval($val),2)."</td>"; $tableinco.="</tr></tfoot>";
        }else{$c=0; $nr=mysqli_num_rows($rs); if($nr>0){
          while($d=mysqli_fetch_row($rs)){$tableexp.="<tr>"; $c=0;
            foreach($d as $val){if($c==0){$tableexp.="<td class=\"r\">".date('D d M,Y',strtotime($val))."</td>";}elseif($c<4){$tableexp.="<td>$val</td>";}else{$tableexp.="<td class=\"r\">".number_format(floatval($val),2).
              "</td>";$ttlexp[$c-4]+=floatval($val); } $c++;
            }$tableexp.="</tr>";}
          }else{$tableexp.="<tr><td colspan=\"".($novotes+7)."\">No Payments Were Made Between ".date("D d-M-Y",strtotime($rec[1]))." And ".date("D d-M-Y",strtotime($rec[2]))."</td></tr>";}
          $tableexp.="</tbody><tfoot><tr><th colspan=\"2\" class=\"r\">$nr Payment Records</th><th colspan=\"2\" class=\"r\">Payment Subtotals (Kshs.)</th>";
          foreach($ttlexp as $val) $tableexp.="<td class=\"r\">".number_format(floatval($val),2)."</td>"; $tableexp.="</tr></tfoot>";
        }mysqli_free_result($rs);
      } $i++;
    }while(mysqli_next_result($conn));
?>
<div id="invoice"><div class="invoice overflow-auto"><div style="min-width:600px">
  <header><div class="row"><div class="col" style="max-width:70px;"><img width="60" height="60" src="/gen_img/logo.jpg" vspace="1" hspace="1" data-holder-rendered="true"/></div>
    <div class="col company-details"><h6 class="name"><?php echo $scnm;?></h6><div><h6><?php echo strtoupper($scadd);?></h6></div><div><b><?php echo $acname;?> CASHBOOK</b><span style="font-size:9pt;float:right;
    font-weight:normal;">Printed On&nbsp;<?php echo date("D d-M-Y");?></span></div></div></div>
  </header><main>
    <H3>INCOME</H3>
    <table style="font-size:9pt"><thead><tr><th>DATE</th><th>RECEIVED FROM</th><th>CASH</th><th>BANK</th><th>TOTAL</th><?php echo $cols;?></tr></thead><tbody><?php echo $tableinco;?></table><br>
    <H3>PAYMENTS</H3>
    <table style="font-size:9pt"><thead><tr><th>DATE</th><th>TO WHOM PAID</th><th>PV NO.</th><th>CHEQUE NO.</th><th>CASH</th><th>BANK</th><th>TOTAL</th><?php echo $cols;?></tr></thead><tbody><?php echo $tableexp;?></table>
    <br><br>
    <div class="notices">Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;Date ______________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV>
  </main>
</div></div></div>
<?php  mysqli_close($conn); footer(0); ?>
