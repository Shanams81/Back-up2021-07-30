<?php
	include_once('shanam.php');
	$salno=isset($_REQUEST['salno'])?trim($_REQUEST['salno']):0; 		$salno=preg_split('/\-/',$salno);
	mysqli_multi_query($conn,"SELECT sal_month,sal_year FROM acc_salaries WHERE salno LIKE '$salno[0]';SELECT scnm,scadd,principal,nssfno,nhifno,emppin,schtype FROM ss;");  $i=0;
	do{
		if($rsSal=mysqli_store_result($conn)){
			if ($i==0) list($mon,$yr)=mysqli_fetch_row($rsSal);
			else $sch=mysqli_fetch_row($rsSal);
			mysqli_free_result($rsSal);
		} $i++;
	}while(mysqli_next_result($conn));
	headings('',0,0); //First0 - Print dialog on load, second 0 - from where
	$cols=1; $sqlcheq="SELECT cheno FROM acc_exp WHERE salno LIKE '$salno[0]' and "; $code='';//number of columns with amount fields
	if (strcasecmp("nssf",$salno[1])==0) {
		$dedname="N . S . S . F"; $code=$sch[3]; $dedno="s.idno,sd.nssfno";
		$sql="(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1) as gsal,(sp.nssffee1+sp.empnssf) as std, sp.nssfvol1, (sp.nssfvol1+
		sp.nssffee1+sp.empnssf) as amt";
		$sqlcheq.="expno LIKE '2'"; $cols=4;
	}elseif (strcasecmp("nhif",$salno[1])==0) {
		$dedname="N . H . I . F";  $code=$sch[4]; $dedno="s.idno,sd.nhifno";
		$sql="(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1) as gsal,sp.nhiffee1 as amt";
		$sqlcheq.="expno LIKE '3'"; $cols=2;
	}elseif (strcasecmp("tax",$salno[1])==0) {
		$dedname="P . A . Y . E";  $code=$sch[5]; $dedno="s.idno, s.pin";
		$sql="sp.empnssf, (sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1) as gsal, sp.paye1, sp.mpr1, (sp.paye1-sp.mpr1) as amt";
		$sqlcheq.="expno LIKE '4'"; $cols=5;
	}elseif (strcasecmp("union",$salno[1])==0) {$dedname=$sch[6]==0?"ELIMU SACCO":"UNION DUES"; $dedno="s.idno,sd.unionno";	$sql="sp.union1 as amt";	$sqlcheq.="expno LIKE '7'";
	}elseif (strcasecmp("advance",$salno[1])==0) {$dedname="Salary Advance";$dedno="sd.idno,s.pin";	$sql="sp.advance as amt";	$sqlcheq.="expno LIKE '1'";
	}elseif (strcasecmp("sacco",$salno[1])==0) {$dedname=$sch[6]==0?"K.D.S SACCO":"SACCO"; $dedno="s.idno,sd.saccono";	$sql="sp.sacco1 as amt";	$sqlcheq.="expno LIKE '8'";
	}elseif (strcasecmp("helb",$salno[1])==0) {$dedname="H . E . L . B"; $dedno="s.idno,s.pin";$sql="sp.helb1 as amt";	$sqlcheq.="expno LIKE '9'";
	}elseif (strcasecmp("welfare",$salno[1])==0) {$dedname="Workers's Welfare"; $dedno="s.idno,sd.welfareno";	$sql="sp.welfare1 as amt";	$sqlcheq.="expno LIKE '5'";
	}else {$dedname=$sch[6]==0?"RENT":"OTHER DEDUCTIONS"; $dedno="s.idno,s.pin";	$sql="sp.otherlevies1 as amt";	$sqlcheq.="expno LIKE '6'";}
	print "<a href=\"../salaryview.php?salno=$salno[0]\"><img src=\"/gen_img/ani_back.gif\" hspace=\"1\" width=\"45\" height=\"20\" align=\"left\"></a><div id=\"print_content\">";
	$sql=$sqlcheq."; SELECT (@row_num:=@row_num+1) As Nos, s.* FROM (SELECT DISTINCT $dedno,sd.payrollno,concat(s.surname,' ',s.onames) as nam,s.dob,$sql FROM stf s Inner Join acc_saldef
	sd USING (idno) Inner Join acc_salpyt sp ON (sd.payrollno=sp.payrollno) Inner Join acc_salaries sa On sp.salno=sa.salno WHERE (sa.salno LIKE '$salno[0]') ORDER BY s.surname,s.onames)s,
	(SELECT	@row_num :=0)x WHERE amt>0;";
	mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"../salaryview.php?salno=$salno[0]\">HERE</a> to go back");
	print "<table class=\"h\" align=\"center\"><tr><th class=\"h\" rowspan=3><img src=\"/gen_img/logo.jpg\" height=50 width=40></th><th class=\"h\" colspan=2 style=\"text-align:left;\">"
  . "$sch[0]</th></tr><tr><th class=\"h\" style=\"text-align:left;\" colspan=2>$sch[1]</th></tr><tr><th class=\"h\" style=\"text-align:left;\">".strtoupper($dedname)." MONTHLY REMMITENCE
	</th><th class=\"h\" style=\"text-align:right;\">Printed On ".date("D d M, Y")."</th></tr><tr><td colspan=3 class=\"h\"><hr><h5 style=\"font-size:12pt;\">EMPLOYER'S ".
	strtoupper($dedname)." CODE: <u>$code</u><br>MONTH OF REMMITANCE: $mon - $yr</h4>";
	$i=0; do{
		if($rsSalPay=mysqli_store_result($conn)){
			if($i===0){
				list($cheno)=mysqli_fetch_row($rsSalPay);
				print "<p style=\"font-size:12pt;letter-spacing:2px;word-spacing:3px;\">You are hereby informed that the attached Cheque No.	".(strlen($cheno)>2?"<b><u>$cheno</b></u>":"_______").
				" is  staff <br>monthly remmittence for the month of $mon $yr.</p></td></tr><tr><td colspan=3 class=\"h\"><table cellspacing=\"0\" border=\"1\"	align=\"center\"><tr align=\"middle\"
				style=\"letter-spacing:2px;word-spacing:4px;background-color:#eee;\"><th rowspan=\"2\">S/N</th><th colspan=\"5\">STAFF MEMBERS' DETAILS</th><th
				colspan=\"$cols\">".($cols>1?"SALARY AMOUNT AND DEDUCTIONS":"DEDUCTION")."</th></tr><tr><th>ID. No.</th><th>".((strcasecmp("tax",$salno[1])==0 || strcasecmp("advance",$salno[1])==0 ||
				strcasecmp("helb",$salno[1])==0 || strcasecmp("ole",$salno[1])==0)?"PIN No.":($dedname." No."))."</th><th>P/F No.</th><th>Names</th><th>Date of Birth</th>";
				if (strcasecmp("nssf",$salno[1])==0) print "<th>Gross Salary</th><th>Standard</th><th>Voluntary</th>";
				elseif (strcasecmp("nhif",$salno[1])==0) print "<th>Gross Salary</th>";
				elseif (strcasecmp("tax",$salno[1])==0) print"<th>Employer NSSF<br>Contribution</th><th>Gross Salary</th><th>Payable<br>PAYE</th><th>M.P.R</th>";
				print "<th>Amount<br>Remitted</th></tr>";
			}else{
				if (strcasecmp("welfare",$salno[1])==0 || strcasecmp("advance",$salno[1])==0 || strcasecmp("helb",$salno[1])==0 || strcasecmp("ole",$salno[1])==0 ||
				strcasecmp("union",$salno[1])==0 || strcasecmp("sacco",$salno[1])==0) $tamt[0]=0;
				elseif (strcasecmp("nhif",$salno[1])==0) $tamt=[0,0];
				elseif (strcasecmp("nssf",$salno[1])==0) $tamt=[0,0,0,0];
				else $tamt=[0,0,0,0,0];	$i=0; $noded=mysqli_num_rows($rsSalPay);
				if ($noded>0){
					if (strcasecmp("welfare",$salno[1])==0 || strcasecmp("advance",$salno[1])==0 || strcasecmp("helb",$salno[1])==0 || strcasecmp("ole",$salno[1])==0 ||
					strcasecmp("union",$salno[1])==0 || strcasecmp("sacco",$salno[1])==0){
						while (list($sn,$id,$dno,$pr,$na,$dob,$net)=mysqli_fetch_row($rsSalPay)):
							if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
							print "<td>$sn</td><td>$id</td><td>$dno</td><td>$pr</td><td>$na</td><td>".date("d M, Y",strtotime($dob))."</td><td align=\"right\">".
							number_format($net,2)."</td></tr>";
							$tamt[0]+=$net;  $i++;
						endwhile;
					}elseif (strcasecmp("nssf",$salno[1])==0){
						while (list($sn,$id,$dno,$pr,$na,$dob,$gs,$std,$vol,$amt)=mysqli_fetch_row($rsSalPay)):
							if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
							print "<td>$sn</td><td>$id</td><td>$dno</td><td>$pr</td><td>$na</td><td>".date("d M, Y",strtotime($dob))."</td><td align=\"right\">".
							number_format($gs,2)."</td><td align=\"right\">".number_format($std,2)."</td><td align=\"right\">".number_format($vol,2)."</td><td
							align=\"right\">".number_format($amt,2)."</td></tr>";
							$tamt[0]+=$gs;  $tamt[1]+=$std;  $tamt[2]+=$vol;  $tamt[3]+=$amt;  $i++;
						endwhile;
					}elseif (strcasecmp("nhif",$salno[1])==0){
						while (list($sn,$id,$dno,$pr,$na,$dob,$gs,$amt)=mysqli_fetch_row($rsSalPay)):
							if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
							print "<td>$sn</td><td>$id</td><td>$dno</td><td>$pr</td><td>$na</td><td>".date("d M, Y",strtotime($dob))."</td><td align=\"right\">".
							number_format($gs,2)."</td><td align=\"right\">".number_format($amt,2)."</td></tr>";
							$tamt[0]+=$gs;  $tamt[1]+=$amt;  $i++;
						endwhile;
					}else{
						while (list($sn,$id,$dno,$pr,$na,$dob,$nss,$gs,$paye,$mpr,$amt)=mysqli_fetch_row($rsSalPay)):
							if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
							print "<td>$sn</td><td>$id</td><td>$dno</td><td>$pr</td><td>$na</td><td>".date("d M, Y",strtotime($dob))."</td><td align=\"right\">".
							number_format($nss,2)."</td><td align=\"right\">".number_format($gs,2)."</td><td align=\"right\">".number_format($paye,2)."</td><td
							align=\"right\">".number_format($mpr,2)."</td><td align=\"right\">".number_format($amt,2)."</td></tr>";
							$tamt[0]+=$nss;  $tamt[1]+=$gs;  $tamt[2]+=$paye;  $tamt[3]+=$mpr;  $tamt[4]+=$amt;  $i++;
						endwhile;
					}
				}else{

					print "<tr><td colspan=\"".($cols+6)."\">The are no $dedname remittences for the month of $mon - $yr</td></tr>";
				}
			} mysqli_free_result($rsSalPay);
		}$i++;
	}while(mysqli_next_result($conn));
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\" class=\"b\">$noded Staff Members</td><td align=\"right\" colspan=\"2\">
	<b>Total Amount (Kshs.)</b></td>";
	foreach($tamt as $amt) print "<td align=\"right\"><b>".number_format($amt,2)."</b></td>";
	print "</tr></table></td></tr><tr><td colspan=3 class=\"h\" style=\"font-size:12pt;letter-spacing:2px;word-spacing:3px;\"><br>Thank You.<br>Yours Faithfully,<br><br><br><br><b>$sch[2]<br>"
        . "PRINCIPAL/ SECRETARY BOM/PA</b><tr></table>";
	print "</div><div align=\"center\"><br><img onclick=\"Clickheretoprint()\" src=\"/gen_img/print.ico\" height=\"30\" width=\"30\" title=\"Print\">".($noded>0?"&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"../xls/xlsdedrpts.php?salno=$salno[0]-$salno[1]\" target=\"_self\">EXPORT TO MS EXCEL</a>"
  . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"../salaryview.php?salno=$salno[0]\">Close</a>":"")."</div><br>";
	mysqli_close($conn);
?>
<script type="text/javascript" src="../tpl/printthis.js"></script>
</body></html>
