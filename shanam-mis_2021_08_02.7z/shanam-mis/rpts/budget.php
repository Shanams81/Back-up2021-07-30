<?php
    include_once('shanam.php');
    class Voteheads{
        private $vno,$vname,$amt;
        public function __construct($no,$nam, $am){$this->vno=$no; $this->vname=$nam;   $this->amt=$am;}       public function valVNo(){return $this->vno;}
        public function valVName(){return $this->vname;}    public function valAmt(){return $this->amt;}
    }
    $vono=$_REQUEST['action']; $vono=preg_split("/\-/",$vono); //$vono[0] 0-Budget 1-Draft Budget, $vono[1] Account No., vono[2] Votehead No.
    headings('<style>@page{@bottom-right{content:"Page " counter(page) " of " counter(pages);}</style>',1,5); //1 - Print dialog on load, 5 - do not close after printing
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr,finyr FROM ss; SELECT descr FROM acc_voteacs WHERE acno LIKE '$vono[1]'; SELECT b.voteno,v.descr,
    if(isnull(sum(bi.prevqty)),0,sum(bi.prevqty*bi.prevup)) as prev, if(isnull(sum(bi.qty)),0,sum(bi.qty*bi.up)) as amt FROM acc_budgetdraft b Inner Join acc_votes v On (b.voteno=v.sno)
    LEFT JOIN acc_budgitemsdraft bi On (b.budgno=bi.budgno) GROUP BY b.budgno,v.descr,b.acc,b.voteno,b.markdel HAVING (b.markdel=0 AND b.acc LIKE '$vono[1]' AND b.voteno LIKE '$vono[2]')
    ORDER BY b.voteno Asc;");
    $i=$pttl=$cttl=0; $account=$voteshow=''; $voteheads=[];
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){if (mysqli_num_rows($rs)>0) list($scnm,$scadd,$finyr)=mysqli_fetch_row($rs);
            }elseif($i==1){if (mysqli_num_rows($rs)>0) list($account)=mysqli_fetch_row($rs);
            }else{$a=1;
                if (mysqli_num_rows($rs)>0) while(list($vo,$vname,$pamt,$amt)=mysqli_fetch_row($rs)){
                    $voteshow.="<tr><td>$a</td><td>$vname</td><td align=\"right\" class=\"qty\">".number_format($pamt,2)."</td><td align=\"right\" class=\"qty\">".number_format($amt,2)."</td></tr>"; $a++;
                    $voteheads[]=new Voteheads($vo,$vname,$amt); $pttl+=$pamt;  $cttl+=$amt;
                }
            }mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));  $title=($vono[0]==0?"FY$finyr BUDGET ESTIMATES":"FY".($finyr+1)." DRAFT BUDGET ESTIMATES");
    //Display data
    echo "<div id=\"invoice\"><div class=\"invoice overflow-auto\"><div style=\"min-width:580px\"><header><div class=\"row\"><div class=\"col\" style=\"max-width:70px;\"><img width=\"60\"
    height=\"60\"src=\"../../gen_img/logo.jpg\" vspace=\"1\" hspace=\"1\" data-holder-rendered=\"true\"/></div><div class=\"col company-details\"><h6 class=\"name\">$scnm</h6><div><h6>".
    strtoupper($scadd)."</h6></div><div><b>$title</b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On&nbsp;".date("D d-M-Y")."</span></div></div></div><hr></header>";
    echo "<main><div class=\"row contacts\" style=\"page-break-after:always;\"><div class=\"col invoice-to\"><H6>SUMMARY OF THE BUDGET PER VOTEHEAD</H6>"
    . "<table class=\"table table-striped table-bordered table-sm\" style=\"width:fit-content;\"><thead><tr><th>#</th><th>VOTEHEAD</th><th>FY".($vono[0]==0?($finyr-1):$finyr)." ACTUALS</th>
    <th>FY".($vono[0]==0?$finyr:($finyr+1))." ESTIMATE</th></tr></thead><tbody>$voteshow</tbody><tfoot><tr><th colspan=\"2\" class=\"total\">TOTAL AMOUNT</th><th class=\"total\">".
    number_format($pttl,2)."</th><th class=\"total\">".number_format($cttl,2)."</th></tr></tfoot></table></div></div>";
    foreach($voteheads as $vh){
        echo "<div style=\"page-break-after:always;\"><h6>".$vh->valVName()." BUDGET ESTIMATES FOR FY".($vono[0]==0?$finyr:($finyr+1))." - GRANDTOTAL (KSHS.) ".number_format($vh->valAmt(),2)."</h6><table border=1 "
        . "class=\"table table-sm table-bordered\"><thead class=\"thead-dark\"><tr><th colspan=\"3\">ITEM DESCRIPTION</th><th colspan=\"3\">FY".($vono[0]==0?($finyr-1):$finyr)." ESTIMATES</th><th colspan=\"3\">FY".
        ($vono[0]==0?$finyr:($finyr+1))." ESTIMATE</th></tr><tr><th>#</th><th>Budget Item Description</th><th>Units</th><th>Quantity</th><th>Unit Cost</th><th>Amount</th><th>Quantity</th><th>Unit Cost</th><th>Amount"
        . "</th></tr></thead><tbody>";
        $sql="SELECT i.itemname,i.Units,b.prevqty,b.prevup,(b.prevqty*b.prevup) as pamt,b.Qty,b.Up,(b.qty*b.up) AS TtlAmt FROM acc_budget bu Inner Join acc_budgitems b USING (budgno)
        Inner Join items i On (b.itmcode=i.itmcode) WHERE (b.markdel=0 AND bu.acc LIKE '$vono[1]' AND bu.voteno LIKE '".$vh->valVNo()."') ORDER BY itemname ASC;";
        $rs=mysqli_query($conn,$sql); //echo $sql;
        if (mysqli_num_rows($rs)>0){ $i=1;
            while ((list($itm,$uni,$pqty,$pup,$pamt,$qty,$up,$amt)=mysqli_fetch_row($rs))){
                echo "<tr><td>$i</td><td>$itm</td><td>$uni</td><td align=\"right\" class=\"qty\">".number_format($pqty,2)."</td><td align=\"right\" class=\"qty\">".number_format($pup,2)."</td><td align=\"right\" "
                . "class=\"qty\">".number_format($pamt,2)."</td><td align=\"right\" class=\"qty\">".number_format($qty,2)."</td><td align=\"right\" class=\"qty\">".number_format($up,2)."</td><td align=\"right\" "
                . "class=\"total\">".number_format($pamt,2)."</td></tr>";
                $i++;
            }
        }else{echo "<tr><td colspan=\"9\">The are no budget items for this votehead</td></tr>";}mysqli_free_result($rs);
        echo "</table></div>";
    }echo "<div class=\"notices\"><div><b>APPROVALS:</b></div><div class=\"notices\">Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV><br><br>";
    echo "<div class=\"notices\">Approved By ____________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Principal</div></DIV></main>";
    echo "<div></div></div>";
    mysqli_close($conn); footer(0);
?>
