<?php
  include_once('shanam.php');
  include_once('../tpl/printing.tpl');
  $recno=$_REQUEST['recno']; $recno=preg_split("/\-/",$recno); //$recno[0] receipt no., [1] 0 Original 1 Duplicate reciept,[2]-A/C Credited,[3] A/C Debited [4] Voucher No.
  headings('<link href="extra/printsettings.css" rel="stylesheet" media="print"/><style>th.hideborder,td.hideborder{border:0;}th.showborder,td.showborder{border:1px solid #000;}
  .showhead{background-color:#777;color:#fff;font-weight:bold;text-align:center;letter-spacing:3px;word-spacing:5px;}table{border:0}</style>',0,2); //First0 - Print dialog on load, second 0 - from where
  mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr,receipt,finyr FROM ss; SELECT abbr FROM acc_voteacs WHERE acno LIKE '$recno[2]';
  SELECT descr FROM acc_voteacs WHERE acno LIKE '$recno[3]';");  $i=0; $accr=$acdr='';
  do{
      if($rs=mysqli_store_result($conn)){
        if ($i==0) list($scnm,$scadd,$recsize,$fy)=mysqli_fetch_row($rs); //recSize [0] A4 Paper, [1] A5 Paper, recType[0] - 2in1, [1] - Single
        elseif($i==1) list($accr)=mysqli_fetch_row($rs);
        else list($acdr)=mysqli_fetch_row($rs);
      } mysqli_free_result($rs); $i++;
  }while(mysqli_next_result($conn));
  if($recno[0]!=0){
    $rpt='<table class="table table-borderless table-sm"><tr><th rowspan=3 class="hideborder" style="border-bottom:1px solid #999;"><img src="/gen_img/logo.jpg" width=70 height=70
    vspace=1 hspace=1></th><th class="hideborder" colspan=2>'.$scnm.'</th></tr><tr><th class="hideborder" colspan=2>'.$scadd.'</th></tr><tr><th style="border-bottom:1px solid #999;"
    class="hideborder">'.$accr.' RECEIPT</th><th class="hideborder" style="border-bottom:1px solid #999;font-size:0.6rem;">Printed On '.date("D d M,Y").'</th></tr>';
    $amtfee=0;
    if ($recno[2]==1) $sql="SELECT r.recno,f.interb_no,f.pytdate,f.pytfrm,f.cheno,r.amt,i.rmks,f.addedby FROM acc_incofee f Inner Join acc_incorecno0 r USING (sno) Inner Join acc_interacborrow i
    USING (interb_no) WHERE r.recno LIKE '$recno[0]'";
    elseif ($recno[2]==2) $sql="SELECT r.recno,f.interb_no,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,i.rmks,f.addedby FROM acc_incofee f Inner Join acc_incorecno1 r USING (sno) Inner Join
    acc_interacborrow i USING (interb_no) WHERE r.recno LIKE '$recno[0]'";
    else $sql="SELECT f.recno,f.interb_no,f.recon,f.mode,f.modeno,f.amt,i.rmks,f.addedby FROM acc_fseincome f Inner Join acc_interacborrow i USING (interb_no) WHERE f.recno LIKE '$recno[0]'";
    $rsRec=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"interacborrow.php\">HERE</a> to go back.");
    list($rec,$interno,$date,$pytfrm,$cheno,$amt,$rmks,$adb)=mysqli_fetch_row($rsRec); mysqli_free_result($rsRec);
    //Details of student and respective balance
    $rpt.='<tr><td class="hideborder"><b>Receipt No.</b></td><td class="hideborder">'.$rec.'</td><td class="hideborder" style="text-align:right;">Received On '.date("D d-M-Y",strtotime($date)).
    '</td></tr><tr><td class="hideborder">Transferred From</td><td class="hideborder" colspan=2 style="font-weight:bold;font-size:12pt;letter-spacing:4px;word-spacing:6px;">'.$acdr.'</td></tr>
    <tr><td class="hideborder">Transfered in</td><td colspan="2" class="hideborder">'.$pytfrm.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Transaction/ Cheque No. </b> '.strtoupper($cheno).'</td></tr>';
    $rpt.='<tr><td class="hideborder">Narration</td><td colspan="2" class="hideborder">'.strtoupper($rmks).'</td></tr><tr><td colspan="3" class="hideborder"><Img src="/gen_img/'.($recno[2]==0?
    'washout.jpg" width=300':'duplicate.jpg" width=400').' height=300 style="position:absolute;opacity:0.4;pointer-events:none;"><br>';
    $foot='<tr><td colspan="3" class="hideborder">Served By <u><b>'.$adb.'</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sign________________</td></tr><tr><td colspan=3
    class="hideborder" style=\"color:#aaaaaa;font-size:7px;\"><hr><center>The receipt is invalid without official stamp. Designed By: Shanams Digital Solutions +254736732168</center></td>
    </tr></table>';
    $vote='<table align="center" border=1 style="font-size:12px;float:center;"><tr><th class="showborder">BEING PAYMENT FOR</th><th class="showborder">AMOUNT</th></tr>';
    $sql="SELECT ucase(v.descr),if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Left Join (SELECT voteno,amt FROM ".($recno[2]<3?"acc_incovotes":"acc_fsevotes")." WHERE recno LIKE
    '$recno[0]' and markdel=0 and acc='$recno[2]')f ON (v.sno=f.voteno) WHERE v.pyt_defined=1 and v.acc='$recno[2]' ORDER BY v.sno ASC";
    $rs=mysqli_query($conn,$sql); $ttl=0;
    while(list($v,$f)=mysqli_fetch_row($rs)){$vote.='<tr><td class="showborder">'.$v.'</td><td class="showborder" style="text-align:right;" class="n">'.number_format($f,2).'</td></tr>';
      $ttl+=$f;}
    $vote.='<tr><th class="showborder"><b>TOTAL AMOUNT TRANSFERRED</b></th><th class="showborder" style="text-align:right;"><b>'.number_format($ttl,2).'</b></th></tr></table></td></tr>';
    $rpt.=$vote.'</td><tr><tr><td colspan=3 class="hideborder" style="background:#eee;word-spacing:2px;letter-spacing:1px;font-weight:bold;text-align:center;"><hr>In Words <span
    style="max-width:600px;font-weight:bold;text-decoration:underline blue solid;">'.NumToWord($ttl.'.00').'</span><hr></td></tr>'.$foot;
    if ($recsize==0) echo '<div class="container page landscape-parent" onclick="window.open(\'interacborrow.php\',\'_self\')"><div class="form-row landscape"><table class="table table-bordered
    table-sm"><tr><td width="450" class="showborder">'.$rpt.'</td><td width="450" class="showborder">'.$rpt.'</td></tr></table></div></div>'; //A4 Report
    else echo '<div class="container page"><div class="form-row content"><table class="table table-bordered table-sm"><tr><td width="450" class="showborder">'.$rpt.'</td></tr></table></div>
    </div><p style="break-after:page;">.</p>';
  }//PV for fees in kind
  if($recno[4]!=0){
    echo '<div id="invoice"><div class="invoice overflow-auto"><div style="min-width:600px"><header><div class="row"><div class="col"
    style="max-width:70px;"><img width="60" height="60"src="../../gen_img/logo.jpg" vspace="1" hspace="1" data-holder-rendered="true"/></div><div class="col company-details"><h6
    class="name">'.$scnm.'</h6><div><h6>'.strtoupper($scadd).'</h6></div><div><b>SCHOOL FUND PAYMENT VOUCHER</b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On
    &nbsp;'.date("D d-M-Y").' </span></div></div></div></header>';
    mysqli_multi_query($conn,"SELECT e.vono,p.payee,p.telno,p.address,p.idno,e.pytdate,e.pytfrm,e.cheno,a.abbr,e.caamt,e.chamt,e.rmks FROM acc_exp e Inner Join acc_exppayee p on
    e.expno=p.payno Inner Join acc_voteacs a On (e.acc=a.acno) WHERE e.acc='$recno[3]' and e.vono LIKE '$recno[4]' and e.markdel=0; SELECT v.descr,month(e.pytdate) as m,p.amt FROM
    acc_exp e Inner Join acc_pytvotes p USING (vono,acc) Inner Join acc_votes v on (p.voteno=v.sno) WHERE e.vono LIKE '$recno[4]' and e.acc='$recno[3]';"); $i=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){
                list($vono,$payee,$tel,$addr,$idno,$date,$mode,$modeno,$acc,$caamt,$chamt,$rmks)=mysqli_fetch_row($rs);
                echo "<main><div class=\"row contacts\"><div class=\"col invoice-to\"><div class=\"text-gray-light\" style=\"font-weight:bold;\">VOUCHER NO. $vono <span
                style=\"float:right;width:250px;\"><input type=\"text\" name=\"txtDate\" style=\"border:0;text-align:right\" value=\"Paid On: ".date("D d F, Y",strtotime($date))."\"
                size=\"25\"></span></div><br><p class=\"to\">Payee's Names: <b style=\"text-decoration:underline double #999;letter-spacing:3px;word-spacing:5px;\">".$payee."</b></p><br>";
                echo "<div style=\"text-align:center;\"><span style=\"float:left;\">ID/Passport No. ".(strlen($idno)>0?$idno:"_________________")."</span>Telephone No. ".
                (strlen($tel)>0?$tel:"_____________")."<span style=\"float:right;\">LPO No. _______________</span></div><br><div class=\"address\">Postal Address: <span
                style=\"font-weight:normal;letter-spacing:4px;word-spacing:6px;\">$addr</span></div></div></div>";
                echo "<table class=\"table table-sm table-bordered\"><tr><th rowspan=2>Date</th><th rowspan=2>Payment Particulars</th><th colspan=2>Amount Paid (Kshs.)</th>
                </tr><tr><th>Cash</th><th>Cheque</th></tr><tr><td valign=\"top\" align=\"right\">".date("d-M-Y",strtotime($date))."</td><td><textarea style=\"border:0;\" cols=\"65\" rows=\"4\">
                $rmks</textarea></td><td valign=\"top\" style=\"text-align:right;\">".number_format($caamt,2)."</td><td valign=\"top\" style=\"text-align:right;\">".number_format($chamt,2)."</td>
                </tr><tr><td style=\"text-align:right;\" colspan=2><b>Total Amount Paid (Kshs.)</b></td><td style=\"text-align:right;\" colspan=2><b>".number_format(($caamt+$chamt),2)."</b></td>
                </tr></table><br>";
                echo "<div>Amount In Words: ".NumToWord(preg_replace("/[^0-9\.]/","",number_format(($caamt+$chamt),2)))."</div><div style=\"text-align:center;\"><span style=\"float:left;\">
                Paid by: <b><u>$mode</u></b></span>Cheque No. <u>$modeno</u><span style=\"float:right;\">Paid On ". date("l, d F, Y",strtotime($date))."</span></div><br>";
                echo "<table class=\"table table-sm table-bordered\"><tr><th>#</th><th>Votehead Description</th><th>Detail</th><th>C/R</th><th align=\"right\">Amount (Kshs)</th></tr>";
            }else{ $a=1;
                while(list($v,$m,$am)=mysqli_fetch_row($rs)){
                    echo "<tr><td>$a</td><td>$v</td><td></td><td align=\"center\">$m</td><td style=\"text-align:right;\">".number_format($am,2)."</td></tr>"; $a++;
                }while($a<5){echo "<tr><td>$a</td><td></td><td></td><td align=\"center\"></td><td></td></tr>"; $a++;}
            }mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    echo "<tr><td colspan=\"3\" align=\"right\"><b>Total Amount Costed (Kshs.)</b></td><td colspan=\"2\" align=\"right\"><b>".number_format(($caamt+$chamt), 2)."</b></td>
    </tr></table>";
    echo "<div class=\"notices\"><div><b>SIGNING:</b></div><div>Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV><br><br>";
    echo "<div>Payee Names _________________________________&nbsp;ID No. _______________ &nbsp;Sign _________________&nbsp;&nbsp;Date ___________</div><br><br>";
    echo "<div>Authorized By ____________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Principal</div></DIV></main>";
    echo "<footer>The payment voucher is computer generated and is invalid without required signatures. Designed By: Shanams Digital Solutions +254736732168 .</footer></div><div>
    </div></div>";
  }  mysqli_close($conn); footer(0);
?>
