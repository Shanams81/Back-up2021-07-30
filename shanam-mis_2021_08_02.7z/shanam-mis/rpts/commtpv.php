<?php
  include_once('shanam.php');
  include_once('../tpl/printing.tpl');
  $vono=sanitize($_REQUEST['action']); $vono=preg_split("/\-/",$vono); //$vono[0] voucherno no, $vono[1] (2- From CREDITORS pyts,8-Commt pyts), vono[2] Expno, $vono[3] Acc No
  headings('',0,$vono[1]); //First0 - Print dialog on load, second 0 - from where
  mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr,schtype FROM ss; SELECT e.vono,e.pytdate,p.name,p.telno,p.paddress,p.idno,e.pytfrm,e.cheno,e.rmks,e.caamt,
  e.chamt,(e.chamt+e.caamt) as ttl,a.descr FROM acc_creditors p Inner Join acc_exp e ON (p.cred_no=e.expno) Inner Join acc_voteacs a ON (e.acc=a.acno) WHERE e.vono LIKE '$vono[0]' and
  e.expno LIKE '$vono[2]' and e.acc LIKE '$vono[3]' and e.commt=1; SELECT v.descr,month(p.pytdate) as mon, p.amt FROM acc_votes v Inner Join acc_pytvotes p ON (v.sno=p.voteno) WHERE
  p.markdel=0 and p.vono LIKE '$vono[0]' and p.acc LIKE '$vono[3]';");  $schtype=$i=0; $voteshow='';
  do{
    if($rs=mysqli_store_result($conn)){
      if($i==0){if (mysqli_num_rows($rs)>0) list($scnm,$scadd)=mysqli_fetch_row($rs);
      }elseif($i==1){if (mysqli_num_rows($rs)>0) list($vn,$pd,$payee,$tel,$add,$id,$pf,$ch,$rmks,$cash,$cheq,$ttl,$acc)=mysqli_fetch_row($rs);
      }else{$a=1; if (mysqli_num_rows($rs)>0) while(list($vo,$mon,$vamt)=mysqli_fetch_row($rs)){$voteshow.="<tr><td>$a</td><td>$vo</td><td></td><td align=\"center\">$mon</td><td "
        . "align=\"right\">".number_format($vamt,2)."</td></tr>"; $a++;
      } for($c=$a;$c<5;$c++) $voteshow.="<tr><td>$c</td><td></td><td></td><td></td><td></td></tr>";} mysqli_free_result($rs);
    }$i++;
  } while(mysqli_next_result($conn));
  //Display data
  echo "<div id=\"invoice\"><div class=\"invoice overflow-auto\"><div style=\"min-width:600px\"><header><div class=\"row\"><div class=\"col\" style=\"max-width:70px;\"><img width=\"60\"
  height=\"60\"src=\"../../gen_img/logo.jpg\" vspace=\"1\" hspace=\"1\" data-holder-rendered=\"true\"/></div><div class=\"col company-details\"><h6 class=\"name\">$scnm</h6><div><h6>".
  strtoupper($scadd)."</h6></div><div><b>$acc PAYMENT VOUCHER</b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On&nbsp;".date("D d-M-Y")."</span></div></div>
  </div></header>";
  echo "<main><div class=\"row contacts\"><div class=\"col invoice-to\"><div class=\"text-gray-light\" style=\"font-weight:bold;\">VOUCHER NO. $vn <input type=\"text\" name=\"txtDate\"
  style=\"text-align:right;float:right;\" value=\"Paid On: ".date("D d M, Y",strtotime($pd))."\" class=\"gen\"></div><br><p class=\"to\">Payee's Names: <b
  style=\"text-decoration:underline double #999;letter-spacing:6px;word-spacing:9px;\">".$payee."</b></p><br>";
  echo "<div style=\"text-align:center;\"><span style=\"float:left;\">ID/Passport No. ".(strlen($id)>0?$id:"_________________")."</span>Telephone No. ".(strlen($tel)>0?$tel:
  "_____________")."<span style=\"float:right;\">LPO No. ____________</span></div><br><div class=\"address\">Postal Address: <span style=\"font-weight:normal;letter-spacing:4px;
  word-spacing:6px;\">$add</span></div></div></div>";
  echo "<table border=\"1\" class=\"table\"><thead><tr><th rowspan=\"2\">Date</th><th rowspan=\"2\">Payment Particulars</th><th colspan=\"2\">Amount Paid (Kshs.)</th></tr><tr><th>Cash
  </th><th>Cheque</th></tr></thead><tbody><tr><td valign=\"top\" align=\"right\"><input name=\"txtDate\" value=\"".date("D d M, Y",strtotime($pd))."\" class=\"gen\"></td><td><textarea
  name=\"txtRmks\" rows=\"4\" cols=\"60\" class=\"gen\" style=\"letter-spacing:2px;word-spacing:3px;\">".strtoupper($rmks).".</textarea></td><td
  valign=\"top\" align=\"right\">".number_format($cash,2)."</td><td valign=\"top\" align=\"right\">".number_format($cheq,2)."</td></tr></tbody><tfoot><tr><td colspan=\"2\"
  align=\"right\"><b>Total Amount Paid (Kshs.)</b></td><td align=\"right\" colspan=\"2\"><b>".number_format($ttl,2)."</b></td></tr></tfoot></table>";
  echo "<div>Amount In Words: <span style=\"letter-spacing:2px;word-spacing:3px;\">".NumToWord(preg_replace("/[^0-9\.]/","",number_format($ttl,2)))."</span></div><div "
  . "style=\"text-align:center;\"><span style=\"float:left;\">Paid by: <b><u>$pf</u></b></span>Cheque No. ".(strlen($ch)>0?$ch:'____________')."<span style=\"float:right;\">Paid On ".
  date("l, d F, Y",strtotime($pd))."</span></div><br>";
  echo "<table border=\"1\" class=\"table\"><thead><tr><th>#</th><th>Votehead Description</th><th>Detail</th><th>C/R</th><th>Amount (Kshs)</th></tr></thead><tbody>$voteshow"
  . "</tbody><tfoot><tr><td colspan=\"3\" align=\"right\"><b>Total Amount Costed (Kshs.)</b></td><td colspan=\"2\" align=\"right\"><b>".number_format($ttl, 2)."</b></td></tr></tfoot>
  </table>";
  echo "<div class=\"notices\"><div><b>SIGNING:</b></div><div class=\"notices\">Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;Date ______________________________<br>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV><br><br>";
  echo "<div class=\"notices\">Payee Names ______________________________________&nbsp;&nbsp;Sign _________________&nbsp;&nbsp;ID No. _______________ &nbsp; Date ___________</div>"
  . "<br><br>";
  echo "<div class=\"notices\">Authorized By ____________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Principal</div></DIV></main>";
  echo "<footer>The payment voucher is computer generated and is invalid without required signatures. Designed By: Shanams Digital Solutions +254736732168 .</footer></div><div></div>
  </div>";
  /*if($vono[1]!=2) echo '<div style="text-align:center;"><img onclick="printRpt(\'invoice\')" src="/gen_img/print.ico" height=20 width=30 title="Print PV"></div><script>
  function printRpt(rpt){var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25";
  	var content_value = document.getElementById(rpt).innerHTML,docprint=window.open("","",disp_setting); docprint.document.open();
  	docprint.document.write(\'<html><head><link rel="stylesheet" type="text/css" href="/shanam-mis/rpts/extra/print.css"/><title>Printing</title></head><body onLoad="self.print()"">\'+
    content_value+\'</body></html>\');docprint.document.close(); 	docprint.focus();
  }</script>';*/
  mysqli_close($conn); footer(0); //footer($vono[1]==2?0:1);
?>
