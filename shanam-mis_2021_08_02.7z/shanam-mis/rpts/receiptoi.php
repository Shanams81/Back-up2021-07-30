<?php
	include_once('shanam.php');	include_once('../tpl/printing.tpl');
	$recno=$_REQUEST['recno']; $recno=preg_split("/\-/",$recno); //$recno[0] receipt serial no., [1]-Acc, [2] Voucher No. [3] - 0 Original 1 Duplicate reciept
	headings('<link href="extra/printsettings.css" rel="stylesheet" media="print"/><style>th.hideborder,td.hideborder{border:0;}th.showborder,td.showborder{border:1px solid #000;}
	.showhead{background-color:#777;color:#fff;font-weight:bold;text-align:center;letter-spacing:3px;word-spacing:5px;}table{border:0}.r{text-align:right;}</style>',0,9);
	mysqli_multi_query($conn,"SELECT scnm,scadd,receipt FROM ss; SELECT abbr FROM acc_voteacs WHERE acno LIKE '$recno[1]';");
	$i=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if ($i==0) list($scnm,$scadd,$recsize)=mysqli_fetch_row($rs);
			else list($acname)=mysqli_fetch_row($rs); mysqli_free_result($rs);
		} $i++;
	}while(mysqli_next_result($conn));
	$rpt='<table border=0 cellspacing=0 cellpadding=2 width="550\"><tr><td rowspan=3 class="hideborder" style="border-bottom:2px solid #00d !important"><img src="/gen_img/logo.jpg" width=70 height=50 vspace=1 hspace=1>
	</td><td class="hideborder" style="font-weight:bold;font-size:14px;letter-spacing:2px;word-spacing:3px;" colspan=2>'.$scnm.'</td></tr><tr><td style="font-weight:bold;font-size:10px;" colspan=2 class="hideborder">'.
	$scadd.'</td></tr><tr><td class="hideborder" style="border-bottom:2px solid #00d !important;font-weight:bold;font-size:10px;letter-spacing:1px;word-spacing:2px;">'.$acname.' - OFFICIAL RECEIPT</td><td class="hideborder"
	style="border-bottom:2px solid #00d !important">Printed On'.date("D d M,Y").'</td></tr>';
	$rsRec=mysqli_query($conn,"SELECT r.recno,a.idno,a.alt_names,a.telno,a.product,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby,a.rmks,a.hiredate FROM acc_alterincome a
	Inner Join acc_incofee f ON (a.code=f.admno) Inner Join ".($recno[1]==1?"acc_incorecno0":"acc_incorecno1")." r USING (sno) WHERE f.sno LIKE '$recno[0]'");
	//Receipt details
	list($rec,$idno,$names,$telno,$prod,$date,$paidby,$pytfrm,$cheno,$amt,$bc,$un,$hrmks,$hdate)=mysqli_fetch_row($rsRec); 	mysqli_free_result($rsRec);
	$cheno=strlen($cheno)==0?"__________":$cheno;
	//Display data
	$rpt.='<tr><td class="hideborder"><b>Receipt No.</b></td><td class="hideborder">'.$rec.'</td><td class="hideborder r">Received On '.date("D d-M-Y",strtotime($date)).'</td></tr><tr><td class="hideborder">Received From
	</td><td colspan=2 class="hideborder"	style="font-weight:normal;font-size:12px;letter-spacing:4px;word-spacing:6px;" bgcolor="#eeeeee">'.$names.'</td></tr><tr><td class="hideborder">ID No.</td><td colspan="2"
	class="hideborder">'.$idno.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Tel. No. :</b> '.$telno.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Received In '.$pytfrm.'</td></tr>';
	$rpt.='<tr><td class="hideborder">Trans/ Cheque No.</td><td colspan=2 class="hideborder">'.$cheno.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fees Paid By '.$paidby.' &nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Income From&nbsp; '.$prod.'</td></tr><tr><td colspan=3 class="hideborder"><Img src="/gen_img/'.($recno[3]==0?'washout.jpg" width=300':
	'duplicate.jpg" width=400').' height=300 style="position:absolute;opacity:0.3;pointer-events:none;"><br>';
	//footer of receipt
	$foot='<tr><td colspan=3 class="hideborder">Amount in Words<br> <span style="border:0.5px dotted #ddd;display:block;font-weight:bold;width:450px;height:50px;">'.NumToWord($amt+$bc).'</span>.<br><b>
	Narration About Income</b>&nbsp;&nbsp;<span style="border:0.5px dotted #999;height:50px;width:450px;display:block;">'.(strcasecmp($prod,'HIRE SERVICES')==0?'HIRED ON '.date('D d F,
	Y',strtotime($hdate)).'<br>':'').$hrmks.'</span></td></tr>';
	$foot.='<tr><td colspan=3 class="hideborder"><br><br></td></tr><tr><td colspan=3 class="hideborder" style="border-bottom:2px solid #00d !important;">Served By <u><b>'.$un.'</b></u>&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign________________</td></tr><tr><td colspan=3 class="hideborder" style=\"color:#ddd;font-size:7px;\"><center>The receipt is invalid without official
	stamp. Designed By: Shanam\'s Digital Solutions +254736732168</center></td></tr></table>';
	$vote='<table width="100%"><tr><th class="showborder showhead">BEING PAYMENT FOR</th><th class="showborder showhead">AMOUNT</th></tr>';
	$rs=mysqli_query($conn,"SELECT ucase(v.descr),if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v INNER Join (SELECT f.voteno,f.amt FROM acc_incovotes f Inner Join ".($recno[1]==1?"acc_incorecno0":
        "acc_incorecno0")." v USING (recno) WHERE v.sno LIKE '$recno[0]' and f.markdel=0 and f.acc='$recno[1]')f ON (v.sno=f.voteno) WHERE v.other_inco=1 and v.acc='$recno[1]' ORDER BY v.sno ASC");
	$ttl=0;
	while(list($v,$f)=mysqli_fetch_row($rs)){$vote.='<tr><td class="showborder" style="letter-spacing:3px;word-spacing:5px;">'.$v.'</td><td  class="showborder r">'.number_format($f,2).
	'</td></tr>'; $ttl+=$f;}
	$vote.='<tr><td class="showborder" style="letter-spacing:3px;word-spacing:5px;">BANK CHARGES</td><td class="showborder r">'.number_format($bc,2).'</td></tr><tr><td class="showborder showhead"><b>TOTAL AMOUNT</b></td>
	<td class="showhead showborder r"><b>'.number_format(($ttl+$bc),2).'</b></td></tr></table></td></tr>';
	$rpt1=$rpt.$vote.$foot;
	if ($recsize==0 && $recno[3]==0){echo '<div class="container page landscape-parent"><div class="form-row landscape"><table class="table table-sm table-bordered"><tr><td style="vertical-align:top;"
		class="showborder" width="370">'.$rpt1.'</td><td style="vertical-align:top;" class="showborder"  width="370">'.$rpt1.'</td></tr></table></div></div>'; //A4 Report
	}else echo $rpt1;
	if ($recno[2]>0){//PV for fees in kind
		echo '<p style="break-after:page;">.</p><div id="invoice"><div class="invoice overflow-auto"><div style="min-width:600px"><header><div class="row"><div class="col"
		style="max-width:70px;"><img width="60" height="60"src="../../gen_img/logo.jpg" vspace="1" hspace="1" data-holder-rendered="true"/></div><div class="col company-details"><h6
		class="name">'.$scnm.'</h6><div><h6>'.strtoupper($scadd).'</h6></div><div><b>'.$acname.' PAYMENT VOUCHER</b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On
		&nbsp;'.date("D d-M-Y").' </span></div></div></div></header>';
		mysqli_multi_query($conn,"SELECT e.vono,p.payee,p.telno,p.address,p.idno,e.pytdate,a.abbr,e.cheno,e.caamt,e.chamt,e.rmks FROM acc_exp e Inner Join acc_exppayee p on e.expno=p.payno Inner
		Join acc_voteacs a On (e.acc=a.acno) WHERE e.acc=1 and e.vono LIKE '$recno[3]' and e.markdel=0; SELECT v.descr,month(e.pytdate) as m,p.amt FROM acc_exp e Inner Join acc_pytvotes p
		USING (vono,acc) Inner Join acc_votes v on (p.voteno=v.sno) WHERE e.vono LIKE '$recno[3]' and e.acc=1;"); $i=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){
					list($vono,$payee,$tel,$addr,$idno,$date,$acc,$cheno,$caamt,$chamt,$rmks)=mysqli_fetch_row($rs);
					echo "<main><div class=\"row contacts\"><div class=\"col invoice-to\"><div class=\"text-gray-light\" style=\"font-weight:bold;\">VOUCHER NO. $vono <span
					style=\"float:right;width:250px;\"><input type=\"text\" name=\"txtDate\" style=\"text-align:right;\" value=\"Paid On: ".date("D d F, Y",strtotime($date))."\"
					class=\"gen\"></span></div><br><p class=\"to\">Payee's Names: <b style=\"text-decoration:underline double #999;letter-spacing:6px;word-spacing:9px;\">".$payee.
					"</b></p><br>";
					echo "<div style=\"text-align:center;\"><span style=\"float:left;\">ID/Passport No. ".(strlen($idno)>0?$idno:"_________________")."</span>Telephone No. ".
					(strlen($tel)>0?$tel:"_____________")."<span style=\"float:right;\">LPO No. _______________</span></div><br><div class=\"address\">Postal Address: <span
					style=\"font-weight:normal;letter-spacing:4px;word-spacing:6px;\">$addr</span></div></div></div>";
					echo "<table border=\"1\" class=\"table table-sm table-bordered\"><thead><tr><th rowspan=2>Date</th><th rowspan=2>Payment Particulars</th><th
					colspan=2>Amount Paid (Kshs.)</th></tr><tr><th>Cash</th><th>Cheque</th></tr></thead><tbody><tr><td valign=\"top\" align=\"right\">".date("d-M-Y",strtotime($date)).
					"</td><td><textarea style=\"border:0;\" cols=\"65\" rows=\"4\">$rmks</textarea></td><td valign=\"top\" style=\"text-align:right;\">".number_format($caamt,2).
					"</td><td valign=\"top\" style=\"text-align:right;\">".number_format($chamt,2)."</td></tr><tr><td style=\"text-align:right;\" colspan=2><b>Total Amount Paid (Kshs.)
					</b></td><td style=\"text-align:right;\" colspan=2><b>".number_format(($caamt+$chamt),2)."</b></td></tr></table><br>";
					echo "<div>Amount In Words: ".NumToWord(preg_replace("/[^0-9\.]/","",number_format(($caamt+$chamt),2)))."</div><div style=\"text-align:center;\"><span style=\"float:left;\">Paid by: <b><u>Cash</u>
					</b></span>Cheque No. ".(strlen($cheno)>0?$cheno:"_________________")."<span style=\"float:right;\">Paid On ". date("l, d F, Y",strtotime($date))."</span></div><br>";
					echo "<table border=\"1\" class=\"table-sm\"><thead><tr><th>#</th><th>Votehead Description</th><th>Detail</th><th>C/R</th><th>Amount (Kshs)</th></tr></thead><tbody>";
				}else{ $a=1;
					while(list($v,$m,$am)=mysqli_fetch_row($rs)){
						echo "<tr><td class=\"n\">$a</td><td class=\"n\">$v</td><td class=\"n\"></td><td align=\"center\" class=\"n\">$m</td><td align=\"right\" class=\"n\">".
						number_format($am,2)."</td></tr>"; $a++;
					}while($a<5){echo "<tr><td class=\"n\">$a</td><td class=\"n\"></td><td class=\"n\"></td><td align=\"center\" class=\"n\"></td><td class=\"n\"></td></tr>"; $a++;}
				}mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn));
		echo "</tbody><tfoot><tr><td colspan=\"3\" align=\"right\"><b>Total Amount Costed (Kshs.)</b></td><td colspan=\"2\" align=\"right\"><b>".number_format(($caamt+$chamt), 2)."</b></td>
		</tr></tfoot></table>";
		echo "<div class=\"notices\"><div><b>SIGNING:</b></div><div>Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV><br><br>";
		echo "<div>Payee Names _________________________________&nbsp;ID No. _______________ &nbsp;Sign _________________&nbsp;&nbsp;Date ___________</div><br><br>";
		echo "<div>Authorized By ____________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Principal</div></DIV></main>";
		echo "<footer>The payment voucher is computer generated and is invalid without required signatures. Designed By: Shanams Digital Solutions +254736732168 .</footer></div><div>
		</div></div>";
	}mysqli_close($conn); footer(0);
?>
