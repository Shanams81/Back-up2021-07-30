<?php
    include_once('shanam.php');
    include_once('../tpl/printing.tpl');
    $recno=$_REQUEST['recno']; $recno=preg_split("/\-/",$recno); //$recno[0] receipt serial no., [1]- 0 Original 1 Duplicate reciept,[2] Receipt A/C
    headings('<link href="extra/printsettings.css" rel="stylesheet" media="print"/><style>th.hideborder,td.hideborder{border:0;}th.showborder,td.showborder{border:1px solid #000;}
    .showhead{background-color:#777;color:#fff;font-weight:bold;text-align:center;letter-spacing:3px;word-spacing:5px;}</style>',0,2); //First0 - Print dialog on load, second 0 - from where
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', Tel No. ',telno) as addr,receipt,receipttype,finyr FROM ss; SELECT descr FROM acc_voteacs WHERE acno=$recno[2];");
    $i=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if ($i==0) list($scnm,$scadd,$recsize,$rectype,$fy)=mysqli_fetch_row($rs); //recSize [0] A4 Paper, [1] A5 Paper, recType[0] - 2in1, [1] - Single
            else list($accname)=mysqli_fetch_row($rs); mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
    $rpt='<table class="table table-borderless table-sm" border="0"><tr><th rowspan=3 class="hideborder" style="border-bottom:1px solid #999;"><img src="/gen_img/logo.jpg" width=70
    height=70 vspace=1 hspace=1></th><th colspan=2 class="hideborder" style="font-size:0.8rem;">'.$scnm.'</th></tr><tr><th colspan=2 class="hideborder" style="font-size:0.8rem;">'.
    $scadd.'</th></tr><tr><th class="hideborder" style="border-bottom:1px solid #999; font-size:0.8rem;">'.$accname.' - RECEIPT</th><th class="hideborder" style="border-bottom:1px solid #999;
    text-align:right;font-size:0.6rem;">Printed On '.date("D d M,Y").'</td></tr>';
    $amtfee=0;
    if ($recno[2]==1) $sql="SELECT r.recno,f.admno,f.pytdate,f.paidby,f.pytfrm,f.cheno,r.amt,r.bc,f.addedby FROM acc_incofee f Inner Join acc_incorecno0 r USING (sno) WHERE
    f.sno LIKE '$recno[0]' and r.acc=$recno[2]"; //Receipt details
    else $sql="SELECT recno,interb_no,recon,'Self' as paidby,mode,modeno,amt,0 as bc,addedby FROM acc_fseincome WHERE recno LIKE '$recno[0]'"; //reciept details
    $rsRec=mysqli_query($conn,$sql);	list($rec,$tno,$date,$paidby,$pytfrm,$cheno,$amt,$bc,$un)=mysqli_fetch_row($rsRec); mysqli_free_result($rsRec);
    $cheno=strlen($cheno)==0?"__________":$cheno;
    //Details of student and respective balance
    $rsBal=mysqli_query($conn,"SELECT concat(t.houseno,' <u>',t.housetype,'</u>') as hn,s.idno,concat(s.surname,' ',s.onames) as st_names,r.arr, ((if(year(t.entrydate)=y.finyr,
    (month(curdate())-month(t.entrydate)+1),month(curdate()))*r.rent)-if(isnull(p.rp),0,p.rp)) as rent FROM stf s Inner Join acc_tenants t USING (idno) Inner Join (SELECT t.tno,
    a.arr,(rent+rentfurn+rentwater+rentelect) as rent FROM acc_tenantrent t Inner Join (SELECT tno,sum(arrears) as arr FROM `acc_tenantrent` group by tno,markdel having markdel=0)a
    USING (tno))r USING (tno) LEFT JOIN (SELECT admno,sum(rent) as rp FROM (SELECT i.admno,sum(f.amt-f.arrears) as rent FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno)
    GROUP BY i.admno,f.MarkDel HAVING f.markdel=0	and i.admno LIKE '$tno' UNION SELECT interb_no as admno,sum(amt-arrears) as rent FROM `acc_fseincome` GROUP BY markdel,interb_no HAVING
    markdel=0 and interb_no LIKE	'$tno')f GROUP	BY admno)p ON (t.tno=p.admno), (SELECT finyr FROM ss)y WHERE t.markdel=0 and t.tno LIKE '$tno' and t.markdel=0");
    list($hno,$idno,$stnames,$arr,$rent)=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);
    //Display data
    $rpt.='<tr><td class="hideborder" colspan=2><b>Receipt No.</b>'.$rec.'</td><td class="hideborder" style="text-align:right;">Received On '.date("D d-M-Y",strtotime($date)).'</td></tr>
    <tr><td class="hideborder" colspan=3>Received From <span style="font-weight:bold;font-size:12pt;letter-spacing:2px;word-spacing:3px;">'.$stnames.'</span></td></tr><tr><td
    class="hideborder">ID No.</td><td class="hideborder" colspan="2">'.$idno.'&nbsp;&nbsp;&nbsp;&nbsp;<b>Received In</b> '.$pytfrm.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    Trans/ Cheque No. '.$cheno.'</td></tr>';
    $rpt.='<tr><td class="hideborder" colspan=3>Rent for House No. '.strtoupper($hno).'&nbsp;&nbsp;&nbsp;Tenant No. '.$tno.'</td></tr><tr><td class="hideborder" colspan=3></td></tr><tr>
    <td class="hideborder" colspan=3><Img src="/gen_img/'.
    ($recno[1]==0?'washout.jpg" width=300':'duplicate.jpg" width=400').' height=300 style="position:absolute;opacity:0.2;pointer-events:none;">';
    //votehead allocation
    $rpt.='<table class="table table-bordered table-sm"><tr><th class="showborder showhead">BEING PAYMENT FOR</th><th class="showborder showhead">AMOUNT (KSHS.)</th></tr>';
    if($recno[2]==1) $sql="SELECT ucase(v.descr),if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Left Join (SELECT f.voteno,f.amt FROM acc_incovotes f Inner Join acc_incorecno0 v
    USING (recno) WHERE v.sno LIKE '$recno[0]' and f.markdel=0 and f.acc='$recno[2]')f ON (v.sno=f.voteno) WHERE (v.pyt_defined=1 or v.abbr LIKE 'arrears') and v.acc='$recno[2]' ORDER BY
    v.sno ASC";
    else $sql="SELECT ucase(v.descr),if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Left Join (SELECT voteno,amt FROM acc_fsevotes WHERE recno LIKE '$recno[0]' and markdel=0 and
    acc='$recno[2]')f ON (v.sno=f.voteno) WHERE (v.fs_Defined=1 or v.abbr like 'rent') and v.acc='$recno[1]' ORDER BY v.sno ASC";
    $rs=mysqli_query($conn,$sql); $ttl=0;
    while(list($v,$f)=mysqli_fetch_row($rs)){$rpt.='<tr><td class="showborder">'.$v.'</td><td style="text-align:right;" class="showborder">'.number_format($f,2).'</td></tr>'; $ttl+=$f;}
    $ttl+=$bc;
    $rpt.='<tr><td class="showborder">BANK CHARGES</td><td style="text-align:right;" class="showborder">'.number_format($bc,2).'</td></tr><tr><td class="showborder showhead">TOTAL A/C
    AMOUNT</td><td class="showborder showhead" style="text-align:right;">'.number_format($ttl,2).'</td></tr></table></td></tr>';
    $rpt.='<tr><td class="hideborder" colspan=3 style="word-spacing:2px;letter-spacing:1px;font-weight:bold;text-align:center;">Total Fees Received Kshs.&nbsp;&nbsp;&nbsp;'.
    number_format($ttl,2).'<span style="font-weight:bold;text-decoration:underline blue solid;"> ('.NumToWord(strpos($ttl,'.')===false?($ttl.'.00'):$ttl).')</span></td></tr>
    <tr><td class="showborder showhead" colspan=3>RENT BALANCE ANALYSIS</td></tr>';
    //footer of student receipt
    $rpt.='<tr><td colspan=3 class="showborder"><b>Rent Arrears </b>&nbsp;&nbsp;<u>'.number_format($arr,2).'</u>&nbsp;&nbsp;&nbsp;&nbsp;<b>Rent Bal</b>
    &nbsp;&nbsp;<u>'.number_format($rent,2).'</u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Total Bal.</b>&nbsp;&nbsp;&nbsp;<u>'.number_format(($arr+$rent),2).'</u></td></tr>';
    $rpt.='<tr><td class="hideborder" colspan="3"><hr><br>Served By <u><b>'.$un.'</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign________________</td>
    </tr><tr><td class="hideborder" colspan=3 style=\"color:#aaaaaa;font-size:0.6rem;\"><hr><br><center>The receipt is invalid without official stamp. Designed By: Shanams Digital
    Solutions +254736732168</center></td></tr></table>';
    if ($recsize==0){echo '<div class="container page landscape-parent" onclick="window.open(\'tenants.php\',\'_self\')"><div class="form-row landscape"><table class="table table-bordered
    table-sm"><tr><td width="450" class="showborder">'.$rpt.'</td><td width="450" class="showborder">'.$rpt.'</td></tr></table></div></div>'; //A4 Report
    }else{echo '<div class="container page"><div class="form-row content"><div class="col-md-6">'.$rpt.'</div></div></div>';}
    mysqli_close($conn); footer(0); ?>
