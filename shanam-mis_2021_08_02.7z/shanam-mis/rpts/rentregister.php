<?php
    include_once('shanam.php');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=explode('~',$data);	//[0]-Tenant No.,[1] Find by either Tno or IDno and [2] random
    class Tenants{
      private $idno,$names,$mon,$monname,$yr,$house,$arr,$rent,$furn,$water,$elect,$trent,$tno;
      public function __construct($id,$nam,$mn,$mona,$y,$ho,$ar,$ren,$fu,$wa,$el,$ttl,$tn){
        $this->idno=$id; $this->names=$nam;$this->mon=$mn;$this->yr=$y;$this->house=$ho;$this->arr=$ar;$this->rent=$ren;$this->furn=$fu;
        $this->water=$wa;$this->elect=$el; $this->trent=$ttl; $this->tno=$tn; $this->monname=$mona;
      }public function valIDNo(){return $this->idno;} public function valName(){return $this->names;}   public function valMonth(){return $this->mon;}
      public function valYr(){return $this->yr;}      public function valHouse(){return $this->house;}  public function valArr(){return $this->arr;}
      public function valRent(){return $this->rent;}  public function valFurn(){return $this->furn;}    public function valWater(){return $this->water;}
      public function valElect(){return $this->elect;}public function valTtlRent(){return $this->trent;}public function valTNo(){return $this->tno;}
      public function valMonName(){return $this->monname;}
    }headings('',1,5); $months=["January","February","March","April","May","June","July","August","September","October","November","December"];
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,' TEL NO. ',telno) as addr,finyr FROM ss;SELECT s.idno,concat(s.surname,' ',s.onames,' (',s.designation,')') as st_names,
    month(t.entrydate) as mon,monthname(t.entrydate) as mname,year(t.entrydate) as yr,t.housetype,(r.arrears+if(isnull(f.arr),0,f.arr)+if(isnull(g.arr),0,g.arr)) as arr,r.rent,
    r.rentfurn,r.rentwater,r.rentelect,(r.rent+r.rentfurn+r.rentwater+r.rentelect) as totalrent,t.tno FROM acc_tenants t Inner Join stf s USING (idno) INNER JOIN acc_tenantrent r
    USING (tno) LEFT JOIN (SELECT interb_no,sum(arrears) as arr FROM acc_fseincome GROUP BY markdel,interb_no HAVING interb_no LIKE 'T%' and markdel=0)f On (t.tno=f.interb_no) LEFT JOIN
    (SELECT f.admno,sum(i.arrears) as arr FROM acc_incofee f Inner JOIN acc_incorecno0 i USING (sno) GROUP BY f.admno,i.markdel HAVING f.admno LIKE 'T%' and i.markdel=0)g ON
    t.tno=g.admno WHERE ".(strcasecmp($data[1],'tno')==0?"t.tno":"s.idno")." LIKE '$data[0]' and t.markdel=0;"); $schtype=$i=0; $head='';
    do{
        if ($rs=mysqli_store_result($conn)){
          if ($i==0){
            list($scnm,$scadd,$finyr)=mysqli_fetch_row($rs);
            $head.="<div class=\"invoice overflow-auto\" style=\"border-bottom:2px dashed #000;\"><div style=\"min-width:600px;\"><header style=\"border-bottom:1px
            solid #000;\"><div class=\"form-row\"><div class=\"col\" style=\"max-width:70px;\"><img width=\"60\" height=\"60\" src=\"/gen_img/logo.jpg\" vspace=\"1\" hspace=\"1\"
            data-holder-rendered=\"true\"/></div><div class=\"col company-details\"><h6 class=\"name\">$scnm</h6><div><h6>".strtoupper($scadd)."</h6></div><div><b>TENANTS' RENT STATEMENT
            </b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On&nbsp;".date("D d-M-Y")."</span></div></div></div></header>";
          }else{
            While($det=mysqli_fetch_row($rs)) $tenants[]=new Tenants($det[0],$det[1],$det[2],$det[3],$det[4],$det[5],$det[6],$det[7],$det[8],$det[9],$det[10],$det[11],$det[12]);
          }mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    foreach($tenants as $ten){
      echo $head."<main><div class=\"form-row contacts\"><div class=\"col invoice-to\" style=\"font-weight:bold;\">ID NO. ".$ten->valIDNo()." <b><u>".$ten->valName()."</u></b>
      House No. ".$ten->valTNo()." <u><b>".$ten->valHouse()."</b></u><br>Rented in ".$ten->valMonName()." - ".$ten->valYr()." House Rent Arrears B/F (Kshs.) ".
      (number_format($ten->valArr(),2))."</div>";
      echo '<table class="table table-borderless"><tr><td><table class="table table-striped table-bordered table-sm smallfont"><thead class="thead-dark"><tr><th colspan="6">
      DETAILS OF RENT EXPECTED</th></tr><tr><th>Month</th><th>Rent</th><th>Water Bill</th><th>Electricity</th><th>Furniture</th><th>Total</th></tr></thead><tbody>';
      $start=($finyr>$ten->valYr()?1:$ten->valMonth()); $mon=date('m'); $trent=[0,0,0,0,0];
      for($i=$start;$i<=$mon;$i++){
        echo '<tr><td>'.$months[$i-1].' - '.$finyr.'</td><td class="unit">'.number_format($ten->valRent(),2).'</td><td class="unit">'.number_format($ten->valWater(),2).'</td>
        <td class="unit">'.number_format($ten->valElect(),2).'</td><td class="unit">'.number_format($ten->valFurn(),2).'</td><td class="total">'.number_format($ten->valTtlRent(),2).
        '</td></tr>'; $trent[0]+=$ten->valRent(); $trent[1]+=$ten->valWater(); $trent[2]+=$ten->valElect(); $trent[3]+=$ten->valFurn(); $trent[4]+=$ten->valTtlRent();
      } echo '</tbody><tfoot class="thead-light"><tr><td class="unit">'.($i-1).' Month(s)</td>'; foreach($trent as $ramt) echo '<td class="total">'.number_format($ramt,2).'</td>';
      $trent[4]+=$ten->valArr(); echo '</tr></tfoot></table></td>';
      echo '<td><table class="table table-bordered table-striped table-hover table-sm smallfont"><thead class="thead-dark"><tr><th colspan="6">DETAILS OF RENT PAYMENT</th></tr><tr>
      <th>RECEIPT</th><th>RECEIVED ON</th><th>ACCOUNT</th><th>MODE</th><th>MODE NO.</th><th>AMOUNT</th></tr></thead><tbody>';
			$rs=mysqli_query($conn,"SELECT * FROM (SELECT f.recno,f.recon,a.abbr,f.mode,f.modeno,(f.arrears+f.amt) as ttl FROM acc_fseincome f Inner Join acc_tenants t ON
      (f.interb_no=t.tno) INNER JOIN acc_voteacs a ON f.acc=a.acno WHERE f.markdel=0 and t.tno LIKE '".$ten->valTNo()."' UNION SELECT i.recno,i.recon,a.abbr,f.pytfrm as mode,f.cheno
      as modeno,(i.arrears+i.amt) as ttl FROM acc_incofee f Inner JOIN acc_incorecno0 i USING (sno) INNER JOIN acc_tenants t ON (f.admno=t.tno) INNER JOIN acc_voteacs a
      ON i.acc=a.acno WHERE f.markdel=0 and t.tno LIKE '".$ten->valTNo()."')s ORDER BY recno DESC;"); $rpaid=0; $nor=mysqli_num_rows($rs);
			while (list($recno,$date,$acc,$mode,$modeno,$ttl)=mysqli_fetch_row($rs)){
				echo "<tr><td>$recno</td><td>".date('d-M-Y',strtotime($date))."</td><td>$acc</td><td>$mode</td><td>$modeno</td><td class=\"total\">".number_format(floatval($ttl),2)."</td></tr>";
        $rpaid+=floatval($ttl);
			}mysqli_free_result($rs);
			echo '</tbody><tfoot class="thead-light"><tr><th colspan="3" class="unit">'.$nor.' RENT INCOME RECIEPT(S)</th><th colspan="2" align="right">SUBTOTALS (KSHS.)</th><th
      class="total">'.number_format($rpaid,2).'</th></tr></tfoot></table></td></tr></table>';
      echo '<div class="form-row"><div class="col"><b>TOTAL RENT BILL AS ON '.strtoupper(date('D d M, Y')).' OF KSHS. '.number_format($trent[4],2).', PAID KSHS. '.
      number_format($rpaid,2).', HAS OUTSTANDING BILL OF KSHS. '.number_format(($trent[4]-$rpaid),2).' .</b></div></div></div></div>';
      echo '<div class="col invoice-to">Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;Date ______________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV></div></main><br>';
    } mysqli_close($conn);     footer(1);
?>
