<?php
	include_once('shanam.php');
	include_once('../tpl/printing.tpl');
	$batch=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):"0-0"; $batch=preg_split('/\-/',$batch);//[0] Receipt No. [1] Account
	headings('<style>table.hide,td.hide,th.hide{border:0.1px dotted #fff;font-size:9pt;border-collapse:collapse;padding:4px} table.pay,td.pay,th.pay{border:1px dashed green;
  font-weight:normal;font-size:9pt;border-collapse:collapse;text-align:left;}table.gen,td.gen,th.gen{border:1px solid blue;border-collapse:collapse;font-size:10pt;text-align:left;}
  </style>',1,5);
  $sql="SELECT scnm,scadd FROM ss; SELECT descr from acc_voteacs WHERE acno LIKE '$batch[1]'; SELECT i.recno,i.recon,i.mode,i.modeno,v.descr,i.amt FROM acc_fseincome i Inner Join
	acc_fsevotes f USING (recno,acc) INNER Join acc_votes v On (f.voteno=v.sno and f.acc=v.acc)	WHERE i.recno LIKE '$batch[0]' and i.acc LIKE '$batch[1]';";
  mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).'. Click <a href="fsefees.php">HERE</a> to go back.'); $amt=$i=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){
				$scnm=$scadd=''; if (mysqli_num_rows($rs)>0) list($scnm,$scadd)=mysqli_fetch_row($rs);
				echo '<table class="hide"><tr><td rowspan="4" style="vertical-align:middle;width:90px;text-align:left;padding:1px;" class="hide"><img src="/gen_img/logo.jpg" width=60 height=60></td><th
			  class="hide" colspan="3" style="font-size:11pt;word-spacing:2px;letter-spacing:1px;text-align:left;font-weight:bold;padding:1px;" width="400">MINISTRY OF EDUCATION</td></tr><tr><td
				class="hide" colspan="3" style="font-size:11pt;text-align:left;font-weight:bold;padding:1px;" width="400">'.$scnm.'</th></tr><tr><th class="hide" colspan="3" style="font-size:10pt;
				text-align:left;padding:1px;" width="400">'.$scadd.'</th></tr>';
			}elseif($i==1){
				$accvot=''; if (mysqli_num_rows($rs)>0) list($accvot)=mysqli_fetch_row($rs);
				echo '<tr><th class="hide" colspan="2"><b>'.$accvot.' RECEIPT</b></th><th class="hide" align="right"><b style="font-size:8pt;">Printed On: '.date('D d M, Y').'</b></th></tr><tr><td
				class="hide" colspan="4" style="max-height:5px;"><hr></td></tr>';
			}else{
				if (mysqli_num_rows($rs)>0){
					list($recno,$date,$mode,$modeno,$vote,$amt)=mysqli_fetch_row($rs);
					echo '<tr><td class="hide">Receipt No.</td><td class="hide">'.$recno.'</td><td class="hide" align="right" colspan="2">Received On '.date("D d-M-Y",strtotime($date)).'</td>
				  </tr><tr><td class="hide" nowrap>Received From</td><td class="hide" colspan="3" style="letter-spacing:3px;word-spacing:5px;font-weight:bold;" nowrap>MINISTRY OF EDUCATION - FSE
				  GRANT</td></tr><tr><td class="hide">Received From</td><td class="hide"><b>MoE - GoK</b></td><td class="hide"> Received in <b>'.$mode.'</b></td><td class="hide">Cheque No:'.
					$modeno.'</td></tr>';
					echo '<tr><td	colspan="4"><hr><table class="gen" Width="100%"><tr><td class="gen"><b>VOTE HEAD ALLOCATED</b></td><td class="gen" style="text-align:right;"><b>AMOUNT</b></td></tr>';
					echo '<tr><td class="gen">'.$vote.'</td><td class="gen" style="text-align:right;">'.number_format($amt,2).'</td></tr><tr><td class="gen">.</td><td class="gen"></td></tr><tr><td
					class="gen">.</td><td class="gen"></td></tr><tr><td class="gen"><b>TOTAL VOTEHEAD AMOUNT</b></td><td class="gen"  style="text-align:right;"><b>'.number_format($amt,2).'</b></td>
					</tr></table></td></tr>';
				}
			}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	echo '<tr><td class="hide" colspan="4" width="440"><hr><b style="letter-spacing:3px;word-sapcing:4px;font-weight:bold;">In Words <u>'.NumToWord($amt).'<hr></td></tr>';
  echo '<tr><td class="hide" colspan="4">.<br><br>With Thanks ___________________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Bursar/ Accounts Clerk</td></tr></table>';
  mysqli_close($conn); footer(0);
?>
