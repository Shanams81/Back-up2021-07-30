 var salno=0;
 $('#printInvoice').click(function(){
    Popup($('.invoice')[0].outerHTML);  function Popup(data){ window.print(); return true; }
});function printWindow(){CheckWindowState();    window.print();}
function CheckWindowState(){if(document.readyState=="complete"){}else{setTimeout("CheckWindowState()", 5000);}
}function closeWindow(ob){
	switch(ob){
    case 0: window.location='../salaryview.php?salno='+salno; break; case 1: window.location = '../pettypyts.php'; break; case 2: window.location='../creditors.php'; break; case 3: window.location='../imprests.php'; break;
    case 4: window.location='../studfee.php'; break;  case 5: window.location = '../fseothergrants.php'; break;  case 6: window.location='../alumni.php'; break;     case 7: window.location = '../interacborrow.php'; break;
    case 8: window.location='../creditorcommtpyts.php'; break; case 9: window.location='../otherincomes.php'; break; default: window.location = '../studfee.php'; break;
  }
}function printRpt(rpt){
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes,width=650, height=600, left=100, top=25",content_value = $("#rpt").innerHTML,docprint=window.open("","",disp_setting);
	docprint.document.open(); docprint.document.write('<html><head><title>Printing</title></head><body onLoad="self.print()"">'+content_value+'</body></html>'); docprint.document.close();	docprint.focus();
}
