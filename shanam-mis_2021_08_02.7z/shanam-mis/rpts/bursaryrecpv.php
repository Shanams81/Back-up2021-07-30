<?php
	include_once('shanam.php');	include_once('../tpl/printing.tpl');
	$recno=sanitize($_REQUEST['recno']); $recno=preg_split("/\-/",$recno); //$recno[0] Bursary no., [1] 0 Original 1 Duplicate reciept
	headings('<link href="extra/printsettings.css" rel="stylesheet" media="print"/><style>th.hideborder,td.hideborder{border:0;}th.showborder,td.showborder{border:1px solid #000;}
	.showhead{background-color:#777;color:#fff;font-weight:bold;text-align:center;letter-spacing:3px;word-spacing:5px;}table{border:0}.r{text-align:right;}</style>',0,2);
	mysqli_multi_query($conn,"SELECT scnm,concat(scadd,', TEL NO. ',telno) as sc,receipt,receiptType FROM ss; SELECT f.recno,b.bursno,b.sourcename,b.pytfrm,b.cheno,b.pytdate,b.addr,
  b.bankcharge,b.amt,b.addedby FROM (SELECT concat('Burs-',bursno) as admno,bursno,pytfrm,cheno,pytdate,concat('P.O Box ',po,' ',pocode,' ',city) as addr,bankcharge,amt,addedby,
  sourcename FROM acc_burs)b Inner Join acc_incofee i USING (admno) Inner Join acc_incorecno0 f USING (sno) WHERE b.bursno Like '$recno[0]';SELECT abbr FROM acc_voteacs WHERE acno=1;");
  $i=0; $acnm='';
  do{
      if($rs=mysqli_store_result($conn)){
          if ($i==0) list($scnm,$scadd,$recsize)=mysqli_fetch_row($rs); //recSize [0] A4 Paper, [1] A5 Paper
          elseif($i==1) list($rec,$ptyno,$name,$pytfrm,$cheno,$pytdate,$add,$bc,$amt,$adb)=mysqli_fetch_row($rs);
          else list($acnm)=mysqli_fetch_row($rs); mysqli_free_result($rs);
      } $i++;
  }while(mysqli_next_result($conn));
  $rpt='<table border=0 cellspacing=0 cellpadding=2 width="650"><tr><td rowspan=3 class="hideborder" style="border-bottom:2px solid #00d !important"><img src="/gen_img/logo.jpg" width=70 height=50 vspace=1 hspace=1>
	</td><td class="hideborder" style="font-weight:bold;font-size:14px;letter-spacing:2px;word-spacing:3px;" colspan=2>'.$scnm.'</td></tr><tr><td style="font-weight:bold;font-size:10px;" colspan=2 class="hideborder">'.
	$scadd.'</td></tr><tr><td class="hideborder" style="border-bottom:2px solid #00d !important;font-weight:bold;letter-spacing:1px;word-spacing:2px;">'.$acnm.' RECEIPT</td><td class="hideborder r"
	style="border-bottom:2px solid #00d !important;font-size:9pt">Printed On'.date("D d M,Y").'</td></tr>';
  $cheno=strlen($cheno)==0?"__________":$cheno;
  //Display data
  $rpt.='<tr><td class="hideborder" colspan="2"><b>Receipt No.</b> '.$rec.'</td><td class="hideborder r">Received On '.date("D d-M-Y",strtotime($pytdate)).'</td></tr><tr><td class="hideborder" colspan="3">
	Received From: <span style="font-weight:normal;font-size:12px;letter-spacing:4px;word-spacing:6px;">'.$name.'</span></td></tr><tr><td class="hideborder" colspan="3">Postal Address '.$add.'</td></tr><tr><td
	class="hideborder" colspan="3">Bursary No. '.$recno[0].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Received In:</b> '.$pytfrm.
	'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Trans/Cheque No. '.$cheno.'</td></tr>';
  $rpt.='<tr><td colspan=3 class="hideborder"><Img src="/gen_img/washout.jpg" width=300 height=300 style="position:absolute;left:30px;opacity:0.2;pointer-events:none;"><table width="100%"><tr><th
	class="showborder showhead">BEING PAYMENT FOR</th><th class="showborder showhead">AMOUNT</th></tr>';
  //footer of receipt
  $foot='<tr><td colspan=3 class="hideborder"><br><br></td></tr><tr><td colspan=3 class="hideborder" style="border-bottom:2px solid #00d !important;">Received By <u><b>'.$adb.'</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign ______________________</td></tr><tr><td colspan=3 style=\"color:#aaa;font-size:7px;\" class="hideborder"><center>The receipt is invalid without official stamp.
	Designed By: Shanams Digital Solutions +254736732168</center></td></tr></table>';
  $rs=mysqli_query($conn,"SELECT ucase(v.descr),if(isnull(f.amt),0,f.amt) as vamt FROM acc_votes v Inner Join acc_voteacs a on (v.acc=a.acno) Left Join (SELECT voteno,amt FROM acc_incovotes WHERE recno=$rec and acc
	LIKE '1')f ON (v.sno=f.voteno) WHERE a.stud_assoc=1 and v.acc=1 and (v.abbr LIKE 'bursary' Or v.fs_defined=1) ORDER BY v.sno ASC LIMIT 0,8");
  while(list($v,$f)=mysqli_fetch_row($rs)) $rpt.='<tr><td class="showborder">'.$v.'</td><td class="showborder r">'.number_format($f,2).'</td></tr>'; mysqli_free_result($rs);
  $rpt.='<tr><td class="showborder">BANK CHARGES</td><td class="showborder r"><b>'.number_format($bc,2).'</b></td></tr><tr><td class="showborder showhead"><b>TOTAL AMOUNT</b></td><td
  class="showborder r showhead"><b>'.number_format(($amt+$bc),2).'</b></td></tr></table></td></tr>';
  $rpt.='</td></tr><tr><td colspan="3" style="background:#eee;word-spacing:2px;letter-spacing:1px;font-weight:bold;" class="hideborder">Amount in Words: <span style="display:block;max-width:600px;
  font-weight:bold;text-decoration:underline blue solid;">'.NumToWord($amt+$bc).'</span></td></tr>';
  $rpt.=$foot;
  //A4 Report
  /*if ($recsize==0) echo '<div class="container page landscape-parent"><div class="landscape"><table class="table table-sm table-bordered"><tr><td style="vertical-align:top;"
	width="370" class="showborder">'.$rpt.'</td><td style="vertical-align:top;" class="showborder"  width="370">'.$rpt.'</td></tr>';
  else echo '<div class="container page"><div class="content"><table class="table table-sm table-bordered"><tr><td style="vertical-align:top;"  class="showborder" width="370">'.$rpt.'</td></tr>'; //A5 receipt
	echo '</table></div></div>';*/ echo $rpt;
  //PV for bursary clearance
  echo '<p style="break-after:page;">.</p><div id="invoice"><div class="invoice overflow-auto"><div style="min-width:600px"><header><div class="row"><div class="col" style="max-width:70px;"><img width="60" height="60"
	src="/gen_img/logo.jpg" vspace="1" hspace="1" data-holder-rendered="true"/></div><div class="col company-details"><h6 class="name">'.$scnm.'</h6><div><h6>'.strtoupper($scadd).'</h6></div>';
  $sql="SELECT e.vono,p.payee,p.telno,p.address,p.idno,e.pytdate,a.abbr,e.caamt,e.chamt,e.rmks FROM acc_exp e Inner Join acc_exppayee p on e.expno=p.payno Inner Join acc_voteacs a On
  (e.acc=a.acno) WHERE e.acc=1 and p.idno LIKE 'Burs-$recno[0]' and e.markdel=0; SELECT v.descr,month(e.pytdate) as m,p.amt FROM acc_exppayee ep Inner Join acc_exp e On
  (ep.payno=e.expno) Inner Join acc_pytvotes p USING (vono,acc) Inner Join acc_votes v on (p.voteno=v.sno) WHERE ep.idno LIKE 'Burs-$recno[0]' and e.acc=1;";
  mysqli_multi_query($conn,$sql); $i=0;
  do{
      if($rs=mysqli_store_result($conn)){
          if($i==0){
              list($vono,$payee,$tel,$addr,$idno,$date,$acc,$caamt,$chamt,$rmks)=mysqli_fetch_row($rs);
              echo "<div><b>$acc PAYMENT VOUCHER</b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On &nbsp;".date("D d-M-Y")." </span></div></div></div></header>";
							echo "<main><div class=\"row contacts\"><div class=\"col invoice-to\"><div class=\"text-gray-light\" style=\"font-weight:bold;\">VOUCHER NO. $vono <span style=\"float:right;width:250px;\"><input
							type=\"text\" name=\"txtDate\" style=\"text-align:right;\" value=\"Paid On: ".date("D d F, Y",strtotime($date))."\" class=\"gen\"></span></div><br><p class=\"to\">Payee's Names: <b
							style=\"text-decoration:underline double #999;letter-spacing:6px;word-spacing:9px;\">".$payee."</b></p><br>";
							echo "<div style=\"text-align:center;\"><span style=\"float:left;\">ID/Passport No. ".(strlen($idno)>0?$idno:"_________________")."</span>Telephone No. ".(strlen($tel)>0?$tel:"_____________")."<span
							style=\"float:right;\">LPO No. _______________</span></div><br><div class=\"address\">Postal Address: <span	style=\"font-weight:normal;letter-spacing:4px;word-spacing:6px;\">$addr</span></div></div></div>";
							echo "<table border=\"1\" class=\"table table-sm table-bordered\"><thead><tr><th rowspan=2>Date</th><th rowspan=2>Payment Particulars</th><th colspan=2>Amount Paid (Kshs.)</th></tr>
							<tr><th>Cash</th><th>Cheque</th></tr></thead><tbody><tr><td valign=\"top\" align=\"right\">".date("d-M-Y",strtotime($date))."</td><td><textarea style=\"border:0;\" cols=\"65\" rows=\"4\">$rmks</textarea>
							</td><td valign=\"top\" style=\"text-align:right;\">".number_format($caamt,2)."</td><td valign=\"top\" style=\"text-align:right;\">".number_format($chamt,2)."</td></tr><tr><td style=\"text-align:right;\"
							colspan=2><b>Total Amount Paid (Kshs.)</b></td><td style=\"text-align:right;\" colspan=2><b>".number_format(($caamt+$chamt),2)."</b></td></tr></table><br>";
							echo "<div>Amount In Words: ".NumToWord(preg_replace("/[^0-9\.]/","",number_format(($caamt+$chamt),2)))."</div><div style=\"text-align:center;\"><span style=\"float:left;\">Paid by: <b><u>Cash</u>
							</b></span>Cheque No. ".(strlen($cheno)>0?$cheno:"_________________")."<span style=\"float:right;\">Paid On ". date("l, d F, Y",strtotime($date))."</span></div><br>";
							echo "<table border=\"1\" class=\"table-condensed\"><thead><tr><th>#</th><th>Votehead Description</th><th>Detail</th><th>C/R</th><th>Amount (Kshs)</th></tr></thead><tbody>";
          }else{ $a=1;
              while(list($v,$m,$am)=mysqli_fetch_row($rs)){
                  echo "<tr><td class=\"n\">$a</td><td class=\"n\">$v</td><td class=\"n\"></td><td align=\"center\" class=\"n\">$m</td><td align=\"right\" class=\"n\">".
                  number_format($am,2)."</td></tr>"; $a++;
              }while($a<5){echo "<tr><td class=\"n\">$a</td><td class=\"n\"></td><td class=\"n\"></td><td align=\"center\" class=\"n\"></td><td class=\"n\"></td></tr>"; $a++;}
          }mysqli_free_result($rs);
      }$i++;
  }while(mysqli_next_result($conn));
  echo "<tr><td colspan=3 style=\"text-align:right;\" class=\"n\"><b>Total Amount Costed (Kshs.)</b></td><td colspan=2 style=\"text-align:right;\" class=\"n\"><b>".
  number_format(($caamt+$chamt),2)."</b></td></tr></table>";
	echo "<div class=\"notices\"><div><b>SIGNING:</b></div><div>Prepared By ____________________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV><br><br>";
	echo "<div>Payee Names _________________________________&nbsp;ID No. _______________ &nbsp;Sign _________________&nbsp;&nbsp;Date ___________</div><br><br>";
	echo "<div>Authorized By ____________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Principal</div></DIV></main>";
	echo "<footer>The payment voucher is computer generated and is invalid without required signatures. Designed By: Shanams Digital Solutions +254736732168 .</footer></div><div>
	</div></div>";
	mysqli_close($conn); footer(0); ?>
