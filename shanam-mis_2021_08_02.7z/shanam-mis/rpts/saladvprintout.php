<?php
	include_once('shanam.php'); include_once('../tpl/printing.tpl');
	$adv=isset($_REQUEST['adv'])?strip_tags($_REQUEST['adv']):"0-0";	$adv=preg_split("/\-/",$adv); //adv[0] advance number,[1] 1-iSSUEING 2-pRINTING ONLY [2] -ACCOUNT AND [3] VOUCHER NO.
	//Query balances
	mysqli_multi_query($conn,"SELECT s.idno,concat(s.surname,' ',s.onames) as st_names,sd.payrollno,a.advno,a.adv_date,a.amt,a.authorisedby,a.rmks,concat(a.duration,' Month(s)') as per,
	a.amtperduration FROM stf s Inner Join acc_saldef sd USING (idno) Inner Join acc_adv a On (sd.payrollno=a.payrollno) WHERE a.advno LIKE '$adv[0]'; SELECT scnm,scadd,mission,
	motto FROM ss;"); $i=0; $sql='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i===0){
				$nor=mysqli_num_rows($rs);	if (($nor==1) && ($adv[1]==0)) $sql="UPDATE acc_adv SET issued=1 WHERE advno LIKE '$adv[0]'";
				list($idno,$nam,$payno,$advno,$date,$amt,$auth,$rmks,$dur,$amtper)=mysqli_fetch_row($rs);
			}else{if (mysqli_num_rows($rs)>0) list($scnm,$scadd,$mis,$mot)=mysqli_fetch_row($rs); } mysqli_free_result($rs);
		} $i++;
	}while(mysqli_next_result($conn));	if(strlen($sql)>0)mysqli_query($conn,$sql);
	if($adv[1]==1){//New Issuing, register pv
		mysqli_multi_query($conn,"SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '$adv[2]'; SELECT payno FROM acc_exppayee e Inner Join acc_saldef s USING (idno) Inner Join acc_adv a USING (payrollno)
		WHERE a.advno LIKE '$adv[0]';"); $i=$payno=$vono=0;
		do{
			if($rs=mysqli_store_result($conn)){if($i==0){list($vono)=mysqli_fetch_row($rs);}else{if(mysqli_num_rows($rs)>0)list($payno)=mysqli_fetch_row($rs);} mysqli_free_result($rs);}$i++;
		}while(mysqli_next_result($conn));  $vono++;
		if($payno==0){if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES(0,'$ron',".var_export($name,true).",'Burs-$bno','P.O Box $po - $code, $town',null,
		'".$_SESSION['username']." (".$_SESSION['priviledge'].")')")){$payno=mysqli_insert_id($conn);}}
		mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,addedby) values ($vono,'$ron',1,".($burs[1]==0?"'Cheque',
		'$modeno',0,$amt":"'Cash',null,$amt,0").",'BEING PAYMENT TO CLEAR BURSARY NO. $bno',$payno,'".$_SESSION['username']." (".$_SESSION['priviledge'].")');
		INSERT INTO acc_pytvotes(vono,acc,voteno,pytdate,amt) VALUES ($vono,1,$burs[2],'$ron',$amt);") or die(mysqli_error($conn));      while(mysqli_next_result($conn)){;}
	}
	headings('',0,0); //First0 - Print dialog on load, second 0 - from where
?><div id="print_content"><table class="table table-borderless"><tr><td rowspan="3" valign="middle" width="90"><img src="/gen_img/logo.jpg" width="70" height="80" vspace="1"
hspace="1"></td><td style="font-weight:bold;letter-spacing:2px;word-spacing:3px;"><?php echo $scnm;?></td></tr><tr><td style="font-weight:bold;"><?php echo $scadd;?></td></tr><tr><td
style="font-weight:bold;font-size:12px;letter-spacing:1px;word-spacing:2px;">SALARY ADVANCE AGREEMENT <span style="float:right;">Printed On: <?php echo date("D d-M-Y");?></span>
</td></tr><tr><td colspan="2"><hr></td></tr>
<?php
	echo '<tr><td colspan="2">Advance No. <u>'.$advno.'</u><span style="float:right;">Approved On: <u>'.date("D d,F Y").'</u></span></td></tr><tr>
	<td colspan="2"><br></td></tr>';
	echo '<tr><td colspan="2">I, <u>'.$nam.'</u>, ID No. <u>'.$idno.'</u> Payroll No. <u>'.$payno.'</u> acknowledge to have received the sum of Kshs. '.number_format($amt,2).' ('.
	NumToWord(preg_replace("/\,/","",number_format($amt,2))).') as a salary advance on <u>'.date("D d,F Y",strtotime($date)).'</u></td></tr><tr><td colspan="2"><br></td></tr>';
	echo '<tr><td colspan="2">In addition, I hereby accept that the salary advance shall be recovered in '.$dur.' at Kshs. '.number_format($amtper,2).' per month as approved by the '.
	$auth.'.</td></tr><tr><td colspan="2"><br></td></tr><tr><td colspan="2">Reason for taking advance '.$rmks.'</td></tr>';
	mysqli_close($conn);
?><tr><td colspan="2"><br></td></tr><tr><td colspan="2">Signature_________________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ID No ______________________
&nbsp; Date___________</td></tr><tr><td colspan="2" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b style="font-size:9pt;">Salary Advance Recipient</b></td></tr><tr><td colspan="2"><br></td></tr><tr><td
colspan="2">Approved By ______________________</td></tr>
<tr><td colspan="2" valign="top">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b
style="font-size:9pt;">The Principal/ Secretary BoM</b></td></tr></table></div><div style="text-align:center;"><img onclick="Clickheretoprint()" src="/gen_img/print.ico"
height="50" width="50" title="Print"><span style="float:right;"><button class="btn btn-info btn-md" type="button" onclick="window.open('../saladv.php','_self')">Close</button></div>
<script type="text/javascript" src="../tpl/printthis.js"></script>
</body></html>
