<?php
	include_once('shanam.php');
	$salno=isset($_REQUEST['salno'])?trim($_REQUEST['salno']):'0-0'; 		$salno=preg_split('/\-/',$salno);
	mysqli_multi_query($conn,"SELECT sal_month,sal_year FROM acc_salaries WHERE salno LIKE '$salno[0]';SELECT scnm,scadd,principal FROM ss;");  $i=0;
	do{
            if($rsSal=mysqli_store_result($conn)){
                if ($i==0) list($mon,$yr)=mysqli_fetch_row($rsSal);
                else $sch=mysqli_fetch_row($rsSal);
                mysqli_free_result($rsSal);
            } $i++;
	}while(mysqli_next_result($conn));
	headings('',0,0);
  print "<a href=\"../salaryview.php?salno=$salno[0]\"><img src=\"/gen_img/ani_back.gif\" hspace=1 width=45 height=20 align=\"left\"></a> <div id=\"print_content\">";
  $rsSalPay=mysqli_query($conn,"SELECT (@rowno:=@rowno+1)as nos,s.* FROM (SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,sd.ACCOUNTNO,substring(sp.paypoint,
  (locate('-',sp.paypoint)+1)) as bb,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1+sp.empnssf)-(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-
  sp.mpr1)+sp.welfare1+sp.otherlevies1+sp.union1+sp.empnssf+sp.sacco1+sp.nssfvol1+sp.helb1)) AS NetSalary FROM stf s INNER JOIN acc_saldef sd USING (idno) INNER JOIN acc_salpyt sp
  On (sd.payrollno=sp.payrollno) INNER JOIN acc_salaries sa ON (sp.salno=sa.SalNo) WHERE (sp.markdel=0 and sp.salno LIKE '$salno[0]' AND sp.paypoint LIKE '$salno[1]%') ORDER BY
  s.SurName,s.onames ASC)s,(SELECT @rowno:=0)X");
  print "<table class=\"h\" align=\"center\"><tr><th class=\"h\" rowspan=3><img src=\"/gen_img/logo.jpg\" height=50 width=40></th><th class=\"h\" colspan=2 style=\"text-align:left;\">$sch[0]
  </th></tr><tr><th class=\"h\" style=\"text-align:left;\" colspan=2>$sch[1]</th></tr><tr><th class=\"h\" style=\"text-align:left;\">".strtoupper($mon." ".$yr)." STAFF SALARY</th><th
  class=\"h\" style=\"text-align:right;\">Printed On ".date("D d M, Y")."</th></tr><tr><th style=\"text-align:left;font-size:12pt;\" colspan=3 class=\"h\"><hr>The Manager,<br>$salno[1] BANK.
  <br><br><p style=\"font-weight:normal;font-size:12pt;letter-spacing:1px;word-spacing:2px;\">I kindly request you credit accounts listed below with the respective amount shown. Attached find
  <br>Cheque No. ______________ showing the total amount of salary for the employees listed.</p></th></tr><tr><td colspan=3 class=\"h\"><table border=1 cellspacing=0><tr align=\"middle\"
  style=\"background-color:#eee;\"><th rowspan=\"2\">S/N</th><th colspan=\"3\">STAFF MEMBERS' DETAILS</th><th colspan=\"2\">BANK DETAILS</th><th rowspan=\"2\">AMOUNT</th></tr><tr><th>ID. No.
  </th><th>PF No.</th><th>Names</th><th>A/C No.</th><th>Branch</th></tr>";
  $tamt=0;	$i=0;
  if (mysqli_num_rows($rsSalPay)>0):
      while (list($nos,$id,$pr,$na,$ac,$bb,$net)=mysqli_fetch_row($rsSalPay)):
          if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
          print "<td>$nos</td><td>$id</td><td>$pr</td><td>$na</td><td>$ac</td><td>$bb</td><td align=\"right\">".number_format($net,2)."</td></tr>";
          $tamt+=$net;  $i++;
      endwhile;
  endif;
  print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\" class=\"b\">".mysqli_num_rows($rsSalPay)." Staff Members</td><td align=\"right\" colspan=\"2\">
  <b>Total Amount (Kshs.)</b></td><td align=\"right\"><b>".number_format($tamt,2)."</b></td></tr></table></td></tr><tr><td colspan=3 class=\"h\" style=\"font-size:12pt;letter-spacing:2px;
  word-spacing:3px;\"><br>Thank You.<br>Yours Faithfully,<br><br><br><br><b>$sch[2]<br>Principal/ Secretary BoM</b><tr></table>";	mysqli_free_result($rsSalPay);
  print "</div><div align=\"center\"><br><img src=\"/gen_img/print.ico\" height=\"30\" width=\"30\" onclick=\"Clickheretoprint()\" title=\"Print\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"../xls/xlspaypoints.php?salno=$salno[0]-$salno[1]\" target=\"_self\">EXPORT TO MS EXCEL</a> &nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"../salaryview.php?salno=$salno[0]\"> CLOSE </a></div><br>";
  mysqli_close($conn);
?>
<script type="text/javascript" src="../tpl/printthis.js"></script>
</body></html>
