<?php
    include_once('shanam.php');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\~/',$data);	//[0]-Account,[1]- Starting date  [2] Ending date and 3 random
    $from=explode('-',$data[1]);    $to=explode('-',$data[2]);    $from="$from[2]-$from[1]-$from[0]";    $to="$to[2]-$to[1]-$to[0]";
    headings('',1,5);
    if (strcasecmp($data[0],'%')==0) $sql="SELECT * FROM (SELECT f.recno,f.recon as pytdate,s.idno,concat(s.surname,' ',s.onames) as names,a.abbr,f.mode,f.modeno,f.arrears,f.amt,
    (f.arrears+f.amt) as ttl,f.acc FROM acc_fseincome f Inner Join acc_tenants t ON (f.inter_no=t.tno) Inner Join stf s ON (t.idno=s.idno) INNER JOIN acc_voteacs a ON f.acc=a.acno WHERE
    f.markdel=0 and (f.recon BETWEEN '$from' and '$to') UNION SELECT i.recno,f.pytdate,s.idno,concat(s.surname,' ',s.onames) as names,a.abbr,f.pytfrm as mode,f.cheno as modeno,i.arrears,
    i.amt,(i.arrears+i.amt) as ttl,i.acc FROM acc_incofee f Inner JOIN acc_incorecno0 i USING (sno) INNER JOIN acc_tenants t ON (f.admno=t.tno) INNER JOIN stf s ON (t.idno=s.idno) INNER JOIN
    acc_voteacs a ON i.acc=a.acno WHERE f.markdel=0 and (f.pytdate BETWEEN '$from' and '$to'))s ORDER BY recno ASC;";
    elseif ($data[0]==1) $sql="SELECT i.recno,f.pytdate,s.idno,concat(s.surname,' ',s.onames) as names,a.abbr,f.pytfrm as mode,f.cheno as modeno,i.arrears,i.amt,(i.arrears+i.amt) as ttl,
    i.acc FROM acc_incofee f Inner JOIN acc_incorecno0 i USING (sno) INNER JOIN acc_tenants t ON (f.admno=t.tno) INNER JOIN stf s ON (t.idno=s.idno) INNER JOIN acc_voteacs a ON i.acc=a.acno
    WHERE f.markdel=0 and (f.pytdate BETWEEN '$from' and '$to') ORDER BY i.recno ASC;";
    else $sql="SELECT f.recno,f.recon,s.idno,concat(s.surname,' ',s.onames) as names,a.abbr,f.mode,f.modeno,f.arrears,f.amt,(f.arrears+f.amt) as ttl,f.acc FROM acc_fseincome f Inner Join
    acc_tenants t ON (f.inter_no=t.tno) Inner Join stf s ON (t.idno=s.idno) INNER JOIN acc_voteacs a ON f.acc=a.acno WHERE f.markdel=0 and (f.recon BETWEEN '$from' and '$to') ORDER BY
    f.recno ASC;";
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,' TEL NO. ',telno) as addr FROM ss;SELECT abbr FROM acc_voteacs WHERE acno LIKE '$data[0]'; SELECT feeedit FROM acc_priv WHERE
    uname LIKE '".$_SESSION['username']."'; $sql"); $schtype=$i=0;
    $acname='RENT RECEIPTS BETWEEN '.date('D d M, Y',strtotime($from)).' and '.date('D d M, Y',strtotime($to));
    do{
        if ($rs=mysqli_store_result($conn)){
            if ($i===0){
                list($scnm,$scadd)=mysqli_fetch_row($rs);
                echo "<div id=\"invoice\"><div class=\"invoice overflow-auto\"><div style=\"min-width:600px\"><header><div class=\"row\"><div class=\"col\" style=\"max-width:70px;\">
                <img width=\"60\" height=\"60\"src=\"../../gen_img/logo.jpg\" vspace=\"1\" hspace=\"1\" data-holder-rendered=\"true\"/></div><div class=\"col company-details\"><h6
                class=\"name\">$scnm</h6><div><h6>".strtoupper($scadd)."</h6></div>";
                if (strcasecmp($data[0],'%')==0) echo "<div><b>".strtoupper($acname);
            }elseif ($i===1){
                if(strcasecmp($data[0],'%')!=0){list($acn)=mysqli_fetch_row($rs);  $acname=$acn.' - '.$acname; echo "<div><b>".strtoupper($acname);}
                echo "</b><span style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On&nbsp;".date("D d-M-Y")."</span></div></div></div></header>";
            }elseif ($i===2){
              $edi=0; if(mysqli_num_rows($rs)>0) list($edi)=mysqli_fetch_row($rs);
            }else{
                echo '<table id="myTable" class="table table-sm table-hover table-bordered table-striped"><thead class="thead-dark"><tr><th>RECEIPT</th><th>RECEIVED ON</th><th>ID NO.
                </th><th>NAMES</th><th>ACCOUNT</th><th>MODE</th><th>MODE NO.</th><th>ARREARS</th><th>RENT</th><th>TOTAL</th></tr></thead><tbody>';
                $i=mysqli_num_rows($rs);	$gttl=[0,0,0];
    						if ($i>0){
    							while (list($recno,$date,$idno,$names,$acc,$mode,$modeno,$arr,$rent,$ttl,$acno)=mysqli_fetch_row($rs)){
                    $nod=(strtotime(date('Y-m-d'))-strtotime($date))/86400;
    								print "<tr><td align=\"center\">".($nod<3?"<a onclick=\"canEdit($edi)\" href=\"tenantrentreceive.php?tno=1-0-$recno-$acno\">$recno</a>":"$recno")."</td><td class=\"qty\">".
                    date('D d M, Y',strtotime($date))."</td><td align=\"center\">$idno</td><td>$names</td><td>$acc</td><td>$mode</td><td>$modeno</td><td class=\"qty\">".
                    number_format(floatval($arr),2)."</td><td class=\"qty\">".number_format(floatval($rent),2)."</td><td class=\"total\">".number_format((floatval($ttl)),2)."</td></tr>";
                    $gttl[0]+=$arr;	$gttl[1]+=$rent; 	$gttl[2]+=$ttl;
    							}
    						}else print "<tr><td colspan=\"12\">Sorry, No rent was recieved within this period in $acn.</td></tr>";
    						print "<tbody><tfoot class=\"thead-light\"><tr><td colspan=\"4\">$i Tenant Record(s)</td><td colspan=\"3\" align=\"right\"><b>Total (Kshs.)</b></td>";
    						foreach ($gttl as $val) print "<td	class=\"total\">".number_format($val,2)."</td>"; 		print "</tr></tfoot></table>";
            }mysqli_free_result($rs);
        }$i++;
    }while (mysqli_next_result($conn));
    echo "<div class=\"notices\" style=\"margin-top:30px;border-left:3px solid #f66;text-align:left;\"><div><b>APPROVALS:</b></div><div>Prepared By ____________________________________
    &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV>";
    echo "<div style=\"margin-top:20px;\">Approved By ____________________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PRINCIPAL</DIV><br><br>";
	   mysqli_close($conn);
     footer(1);
?>
