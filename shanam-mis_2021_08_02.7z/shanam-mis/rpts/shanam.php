<?php //Start off work
  session_start();
  if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../../index.php"); else include_once('../../conn/pri_sch_connect.inc');
  function headings($txt,$opt,$ch){ //opt 0 - print and close,1 print and continue viewing, $ch -0 Salary 1- Expenses 2  Commt 3-Imprest clear, 4 fees & income,5 - others
    echo '<!DOCTYPE html><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>Accounts MIS</title><meta name="viewport" c
    ontent="width=device-width, initial-scale=1, shrink-to-fit=yes"><link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" type="text/css" href="/shanam-mis/rpts/extra/print.css"/><link rel="shortcut icon" href="/gen_img/phone.ico"/>';
    echo $txt.'</head><body onload="printWindow()"'.($opt==0?' onclick="closeWindow('.$ch.')"':'').'>';
  }function footer($a){
    echo '<script src="/bootstrap/jquery/jquery-min.js"></script><script src="/bootstrap/js/bootstrap.min.js"></script>';
    if($a==0) echo '<script type="text/javascript" src="extra/print.js"></script>';//for print once loaded
    echo '</body></html>';
  }
?>
