<?php
    include_once('shanam.php');
    $data=strtoupper(strip_tags(trim($_REQUEST['q']))); $data=preg_split('/\~/',$data);	//[0]-1-Orders,2-Uniforms,[1]- Starting date  [2] Ending date and 3 random
    $from=preg_split('/\-/',$data[1]);    $to=preg_split('/\-/',$data[2]);    $from="$from[2]-$from[1]-$from[0]";    $to="$to[2]-$to[1]-$to[0]";
    headings('',1,5);
    if ($data[0]==1) $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as nam, concat(cn.clsname,' ',c.stream) as cls,up.purchno,up.purchasedon,u.price FROM stud s Inner Join
    class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) Inner Join unifrmpurchase up On (s.admno=up.admno) Inner Join (SELECT pd.purchno,sum(u.amt*pd.qty) as
    price FROM unipurchdetails pd Inner Join uniforms u USING (unifrmno) GROUP BY pd.purchno,pd.markdel HAVING pd.markdel=0)u On (up.purchno=u.purchno) WHERE up.markdel=0 and
    (up.purchasedon BETWEEN '$from' AND '$to') Order By purchno ASC;";
    elseif ($data[0]==2) $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as nam, concat(cn.clsname,' ',c.stream) as cls, f.recno, f.pytdate, f.pytfrm,f.cheno, f.amt FROM stud s Inner Join
    class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) Inner Join (SELECT f.recno,i.admno,i.pytdate,i.pytfrm,i.cheno,f.unifrm as amt FROM `acc_incofee` i Inner Join acc_incorecno0 f
    USING (SNo) WHERE i.markdel=0 and f.unifrm>0 UNION SELECT f.recno,i.admno,i.pytdate,i.pytfrm,i.cheno,f.unifrm as amt FROM `acc_incofee` i Inner Join acc_incorecno1 f USING (SNo) WHERE f.markdel=0 and
    f.unifrm>0)f USING (admno) WHERE f.pytdate BETWEEN '$from' and '$to' ORDER BY f.recno ASC;";
    elseif ($data[0]==3) $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,(f.uni+if(isnull(b.amtclr),0,b.amtclr)) as ttl, if(isnull(b.amtclr),0,b.amtclr) as paid,
    f.uni as bal FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno)  INNER JOIN (SELECT admno,sum(unifrm) as uni FROM class GROUP BY admno,markdel HAVING markdel=0)f
    USING (admno) LEFT JOIN (SELECT admno,sum(amt) as amtclr FROM acc_hospunibillclr GROUP BY MarkDel,admno,transtype HAVING transtype=1 and MarkDel=0)b USING (admno) WHERE f.uni>0 ORDER BY admno ASC";
    else $sql="SELECT u.unifrmno,u.uname,u.unitsale,u.amt,if(isnull(sum(p.unifrmno)),0,sum(p.unifrmno)) as sales FROM uniforms u LEFT JOIN unipurchdetails p USING (unifrmno) GROUP BY
    u.unifrmno,u.uname,u.unitsale,u.amt,u.markdel HAVING u.markdel=0 ORDER BY uname ASC;";
    mysqli_multi_query($conn,"SELECT scnm,concat(scadd,' TEL NO. ',telno) as addr FROM ss; $sql"); $schtype=$i=0; $optStf='';
    do{
        if ($rs=mysqli_store_result($conn)){
            if ($i==0){
                list($scnm,$scadd)=mysqli_fetch_row($rs);
                echo "<div id=\"invoice\"><div class=\"invoice overflow-auto\"><div style=\"min-width:600px\"><header><div class=\"row\"><div class=\"col\" style=\"max-width:70px;\">
                <img width=\"60\" height=\"60\"src=\"../../gen_img/logo.jpg\" vspace=\"1\" hspace=\"1\" data-holder-rendered=\"true\"/></div><div class=\"col company-details\"><h6
                class=\"name\">$scnm</h6><div><h6>".strtoupper($scadd)."</h6></div><div><b>".strtoupper(($data[0]==1 || $data[0]==2)?(($data[0]==1?"uniforms purchased":"uniform fee recoveries")." between ".
                date('D d M, Y',strtotime($from)). " and ".date('D d M, Y',strtotime($from))):($data[0]==3?"debtors of extra uniform purchases as on ".date('D d M, Y'):"LIST OF uniforms"))."</b><span "
                . "style=\"font-size:9pt;float:right;font-weight:normal;\">Printed On&nbsp;".date("D d-M-Y")."</span></div></div></div></header>";
            }else{
                echo '<table class="table table-striped table-bordered table-sm"><thead><tr style="letter-spacing:4px;word-spacing:6px;">';
                if($data[0]==1){
                    echo'<th colspan="5">DETAILS OF THE STUDENT</th><th colspan="5">DETAILS OF UNIFORM PURCHASED</th><th rowspan="2">TOTAL<BR>BILL</th></tr><tr><th>#</th><th>DATE</th><th>ADM.NO.
                    </th><th>NAMES</th><th>GRADE/FORM</th><th>DESCRIPTION</th><th>UNITS</th><th>UNIT PRICE</th><th>QTY</th><th>AMOUNT</th></tr></thead><tbody>';
                    $a=1; $ttl=0;
                    while($stud=mysqli_fetch_row($rs)){
                      $rsUni=mysqli_query($conn,"SELECT u.uname,u.unitsale,u.amt,pd.qty,(u.amt*pd.qty) as ttl FROM uniforms u Inner Join unipurchdetails pd USING (unifrmno) Inner Join
                      unifrmpurchase up On (pd.purchno=up.purchno) WHERE up.purchno LIKE '$stud[3]' and up.markdel=0 and pd.markdel=0;");  $nou=mysqli_num_rows($rsUni);
                      echo "<tr><td rowspan=\"$nou\" valign=\"top\">$a</td><td rowspan=\"$nou\" valign=\"top\">".date('D d M, Y',strtotime($stud[4]))."</td><td rowspan=\"$nou\" valign=\"top\">
                      $stud[0]</td><td rowspan=\"$nou\" valign=\"top\">$stud[1]</td><td rowspan=\"$nou\" valign=\"top\">$stud[2]</td>"; $start=0;
                      while($uni=mysqli_fetch_row($rsUni)){
                        echo ($start==0?"":"<tr>")."<td>$uni[0]</td><td>$uni[1]</td><td class=\"unit\">".number_format($uni[2],2)."</td><td class=\"qty\">$uni[3]</td><td class=\"total\">".
                        number_format($uni[4],2)."</td>";
                        echo ($start==0?"<td rowspan=\"$nou\" class=\"total\" valign=\"top\">".number_format($stud[5],2)."</td></tr>":"</tr>");
                        $start++;
                      }  $a++; $ttl+=$stud[5]; mysqli_free_result($rsUni);
                    }echo '</tbody><tfoot><tr><th colspan="10" class="unit" style="letter-spacing:4px;word-spacing:6px;">TOTAL OF UNIFORM PURCHASES IN SPECIFIED PERIOD</th><th class="total">'.
                    number_format($ttl,2).'</th></tr></tfoot></table>';
                }elseif($data[0]==2){
                    echo'<th colspan="5">DETAILS OF THE RECEIPT</th><th colspan="3">DETAILS OF STUDENT</th><th rowspan="2">AMOUNT<BR>RECOVERED</th></tr><tr><th>#</th><th>RECIEPT</th><th>DATE
                    </th><th>MODE</th><th>MODE NO.</th><th>ADM. NO.</th><th>NAMES</th><th>GRADE/FORM</th></tr></thead><tbody>';
                    $a=1; $ttl=0;
                    while($uni=mysqli_fetch_row($rs)){
                        echo "<tr><td>$a</td><td>$uni[3]</td><td class=\"qty\">".date("D d M, Y", strtotime($uni[4]))."</td><td>$uni[5]</td><td>$uni[6]</td><td>$uni[0]</td><td>$uni[1]</td><td>$uni[2]</td>"
                        . "<td class=\"total\">".number_format($uni[7],2)."</td></tr>";
                        $a++; $ttl+=$uni[7];
                    } echo '</tbody><tfoot><tr><th colspan="8" class="unit" style="letter-spacing:4px;word-spacing:6px;">TOTAL OF UNIFORM PURCHASES IN SPECIFIED PERIOD</th><th class="total">'.
                    number_format($ttl,2).'</th></tr></tfoot></table>';
                }elseif($data[0]==3){
                    echo'<th>#</th><th>ADM. NO.</th><th>NAMES OF DEBTOR</th><th>GRADE/ FORM</th><th>UNIFORM BILL</th><th>AMOUNT RECOVERED</th><th>BALANCE</th></tr></thead><tbody>';
                    $a=1; $ttl=[0,0,0];
                    while($uni=mysqli_fetch_row($rs)){
                        echo "<tr><td>$a</td><td>$uni[0]</td><td>$uni[1]</td><td>$uni[2]</td><td class=\"total\">".number_format($uni[3],2)."</td><td class=\"total\">".number_format($uni[4],2)."</td><td "
                        . "class=\"total\">".number_format($uni[5],2)."</td></tr>";
                        $a++; $ttl[0]+=$uni[3]; $ttl[1]+=$uni[4];   $ttl[2]+=$uni[5];
                    } echo '</tbody><tfoot><tr><th colspan="4" class="unit" style="letter-spacing:4px;word-spacing:6px;">TOTAL AMOUNTS (KSHS.)</th><th class="total">'.number_format($ttl[0],2).'</th><th '
                        . 'class="total">'.number_format($ttl[1],2).'</th><th class="total">'.number_format($ttl[2],2).'</th></tr></tfoot></table>';
                }else{
                    echo'<th>#</th><th>NAME</th><th>UNITS</th><th>UNIT PRICE</th><th>UNITS SOLD</th><th>AMOUNT</th></tr></thead><tbody>';  $a=1;
                    while($uni=mysqli_fetch_row($rs)){
                        echo "<tr><td>$a</td><td>$uni[1]</td><td>$uni[2]</td><td class=\"qty\">".number_format($uni[3],2)."</td><td class=\"qty\">".number_format($uni[4],2)."</td><td class=\"qty\">".
                        number_format(($uni[4]*$uni[3]),2)."</td></tr>"; $a++;
                    } echo '</tbody></table>';
                }
            }mysqli_free_result($rs);
        }$i++;
    }while (mysqli_next_result($conn));
    echo "<div class=\"notices\" style=\"margin-top:30px;border-left:3px solid #f66;text-align:left;\"><div><b>APPROVALS:</b></div><div>Prepared By ____________________________________
    &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;Bursar/ Accounts Clerk</DIV>";
    echo "<div style=\"margin-top:20px;\">Approved By ____________________________________ &nbsp;&nbsp;&nbsp;&nbsp;Date ______________________________<br>&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PRINCIPAL</DIV><br><br>";
	   mysqli_close($conn);
     footer(1);
?>
