<?php
    include_once('shanam.php');
    $rsP=mysqli_query($conn,"SELECT budgview, budgadd, budgedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
    $itmviu=$itmadd=$itmedit=0;     $action=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0-0';	$action=preg_split("/\-/",$action);
    if(mysqli_num_rows($rsP)==1) list($itmviu,$itmadd,$itmedit)=mysqli_fetch_row($rsP);	mysqli_free_result($rsP);
    if($itmviu==0) header("Location:vague.php");
    if (isset($_POST['btnSave'])){
        $itmno=isset($_POST['txtItemNo'])?sanitize($_POST['txtItemNo']):'0';                            $acno=isset($_POST['txtInfo1'])?sanitize($_POST['txtInfo1']):'0';
        $categ=isset($_POST['cboCateg'])?strtoupper(sanitize($_POST['cboCateg'])):'CONSUMABLE';		$itmde=isset($_POST['cboDept'])?sanitize($_POST['cboDept']):0;
        $item=isset($_POST['txtItem'])?mysqli_real_escape_string($conn,strtoupper(strtoupper(sanitize($_POST['txtItem'])))):"";
        $units=isset($_POST['cboUnits'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['cboUnits']))):'PIECES';
        $max=isset($_POST['txtMax'])?sanitize($_POST['txtMax']):0;					$max=preg_replace("/[^0-9^\.]/","",$max);
        $min=isset($_POST['txtMin'])?sanitize($_POST['txtMin']):0;					$min=preg_replace("/[^0-9^\.]/","",$min);
        $up=isset($_POST['txtUP'])?sanitize($_POST['txtUP']):0; 				  	$up=preg_replace("/[^0-9^\.]/","",$up);
        $un=$_SESSION['username']." (".$_SESSION['priviledge'].")";                                     $regdon=date("Y-m-d");
        $sqlvotes='';   $itmde=($itmde==0?null:$itmde);
        for($i=0;$i<$acno;$i++){
          $votes=isset($_POST['cboVotes_'.$i])?sanitize($_POST['cboVotes_'.$i]):'0-0'; 			$votes=preg_split('/\-/',$votes); //[0] A/C No. [1] VOTEHEAD
          if($votes[0]>0) $sqlvotes.="INSERT INTO itemvote(itmcode,ac,voteno) VALUES ($itmno,$votes[0],$votes[1]);";
        }
        if ((strlen($itmno)==0 || strlen($item)<5 || strlen($categ)<5 || $up<1 || $max<5 || $min<0) || strlen($sqlvotes)==0){
            print "<h4 style=\"color:#f00;text-align:center;letter-spacing:2px;word-spacing:4px;\">You must enter valid item code, name, category, user department, Unit price, Maximum stock
            level and minimum stock level before saving</h4>";
        }else{
            mysqli_query($conn,"INSERT INTO items(itmcode,itemname,categ,deptno,units,maxstock,minstock,currstock,unitprice,addedon,addedby) VALUES ('$itmno','$item','$categ',".var_export($itmde,true).",
            '$units',$max,$min,$min,$up,'$regdon','$un')") or die(mysqli_error($conn). " Item Description not added. Click <a href=\"goods.php?action=0-0\">here</a>to go try again.");
            $action[1]=mysqli_affected_rows($conn);
            if ($action[1]==1) mysqli_multi_query($conn,$sqlvotes) or die(mysqli_error($conn)."Item Voteheads not added. Click <a href=\"goods.php?action=0-0\">here</a>to go try again.");
            $action[0]=1; while(mysqli_next_result($conn)){}
        }
    }
    class Accounts{
        private $acc, $descr;
        function __construct($a,$d){$this->acc=$a;	$this->descr=$d;}
        public function valAcNo(){return $this->acc;}	public function valAcName(){return $this->descr;}
    }
    $categ=isset($_POST['cboSCateg'])?trim(strip_tags($_POST['cboSCateg'])):"%";
    $depno=isset($_POST['cboSDept'])?trim(strip_tags($_POST['cboSDept'])):"%";
    headings('<link rel="stylesheet" type="text/css" href="tpl/css/headers.css"/><link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet"
    href="tpl/css/inputsettings.css" type="text/css"/>',$action[0],$action[1],2);
?><div class="head"><form name="FrmGoods" method="post" action="goods.php"><a href="goodsbudg.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp; View &nbsp;&nbsp;
<SELECT name="cboSCateg" id="cboSCateg" size="1" style="width:fit-content;height:25px;"><option value="%">All</option>
<?php
    mysqli_multi_query($conn,"SELECT categ FROM grps WHERE categ IS NOT NULL or categ Not LIKE ''; SELECT deptno,deptname FROM depts WHERE markdel=0; SELECT acno,abbr FROM acc_voteacs WHERE
    markdel=0 ORDER BY acno ASC; SELECT max(itmcode) as mx FROM items;"); $i=$noacs=$mx=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){
                while (list($cat)=mysqli_fetch_row($rs)) print "<option value=\"$cat\">$cat</option>";
                print "</SELECT>&nbsp;&nbsp; Items/Services Used in&nbsp;&nbsp;</label><SELECT name=\"cboSDept\" id=\"cboSDept\" size=\"1\" style=\"width:fit-content;height:25px;\">
                <option value=\"%\">All</option>";
            }elseif($i==1){
                while (list($dno,$dep)=mysqli_fetch_row($rs)) print "<option value=\"$dno\">$dep</option>";
            }elseif($i==2){
                while($data=mysqli_fetch_row($rs)){
                    $accounts[]=new Accounts($data[0],$data[1]); 	$noacs++;
                }
            }else{
              if (mysqli_num_rows($rs)>0) list($mx)=mysqli_fetch_row($rs); $itmcode=$mx+1;
            }mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
?></SELECT>&nbsp; department(s) &nbsp;&nbsp;<button name="CmdView" type="submit" <?php echo ($itmviu==0?"\"disabled\"":"");?> class="btn btn-md btn-warning">View
Items</button>&nbsp;&nbsp;&nbsp;<button name="CmdAdd" type="button" <?php echo ($itmadd==0?"\"disabled\"":""); ?> onclick="document.getElementById('divAddGoods').style.display='block'"
class="btn btn-md btn-warning">Add New Item/Service</button></form></div>
<div class="container" style="background-color:#e6e6e6;margin:5px auto;width:fit-content;">
  <div class="form-row"><div class="col-md-12" style="letter-spacing: 3px;word-spacing:4px; font-weight:bold;margin:5px 0;">LIST OF DEFINED ITEMS AND SERVICES </div></div>
  <div class="form-row"><div class="col-md-12" style="overflow-y:scroll;max-height:700px;"><table class="table table-bordered table-hover table-sm table-striped"><thead
  class="thead-dark"><tr><th rowspan="2">#</th><th colspan="3">DESCRIPTION OF ITEMS/SERVICES</th><th colspan="4">STOCK LEVEL CONTROLS</th><th colspan="<?php echo $noacs;?>">
  VOTEHEAD COSTED</th><th rowspan="2">ADMIN<br>ACTION</th></tr><tr><th>NAME OF ITEM/SERVICE</th><th>CATEGORY</th><th>USER DEPARTMENT</th><th>UNITS</th><th>MAX</th><th>MIN</th>
  <th>UNIT PRICE</th>
  <?php
    $votes=$convotes=$fvotes="";
    foreach($accounts as $acc){
        print "<th>".$acc->valAcName()."</th>"; $acno=$acc->valAcNo();
        $votes.=",if(i.ac like '$acno' , v.descr,null) as ac$acno";
        $convotes.=",group_concat(ac$acno) as g$acno"; $fvotes.=",it.g$acno";
    }print "</tr></thead><tbody>";
    $sql="SELECT i.itmcode,i.itemname,i.categ,if(isnull(d.deptname),'GENERAL USE',d.deptname) as dn,i.units,i.maxstock,i.minstock,i.unitprice $fvotes FROM items i Left Join (SELECT
    itmcode $convotes FROM (SELECT i.itmcode $votes FROM `itemvote` i Inner Join acc_votes v On (i.voteno=v.sno))i Group By itmcode)it USING (itmcode) LEFT JOIN depts d ON
    (i.deptno=d.deptno) WHERE (i.markdel=0 AND i.categ LIKE '$categ' AND (i.deptno LIKE '$depno' or isnull(i.deptno))) ORDER BY i.itemname ASC";
    $rsItem=mysqli_query($conn,$sql) or die(mysqli_error($conn));	$norec=mysqli_num_rows($rsItem);
    if ($norec>0){ $a=1;
        while ($data=mysqli_fetch_row($rsItem)){
            print "<tr><td>$a</td>"; $i=0;
            foreach($data as $da){
              if($i>4 && $i<8) print "<td align=\"right\">".number_format($da,2)."</td>";
              else{if($i==0)$itmno=$da; else print "<td>$da</td>";}  $i++;
            }print "<td align=\"center\"><a onclick=\"return canedit($itmedit)\" href=\"goodsadd.php?action=$itmno\">Edit</a></td></tr>";
            $a++;
        }
    }else{
        $i=9+$noacs;
        print "<tr><td colspan=\"$i\" style=\"color:#555;font-weight:bold;\"><br>No items or services not defined<br></td></tr>";
    }
    ?></table></div>
  </div>
</div>
<div id="divAddGoods" class="modal"><div class="divmodalmain"><form action="goods.php" Method="Post" name="frmGoodsEdit" onsubmit="return validateFormOnSubmit1(this)">
  <input type="hidden" name='txtInfo1' id='txtInfo1' value="<?php echo $noacs; ?>">
	<div class="imgcontainer"><span onclick="document.getElementById('divAddGoods').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span>
	<h4 style="text-decoration:underline overline double #fff;word-spacing:5px;letter-spacing:3px;">ADDING NEW ITEM/SERVICE DESCRIPTION</h4></div>
  <div class="form-row"><div class="col-md-12 divsubheading">ITEM/ SERVICE DEFINITION INTERFACE</div>
</div><div class="form-row">
    <div class="col-md-3"><label for="txtItemNo">Item Code</label><Input name="txtItemNo" id="txtItemNo" type="text" value="<?php echo $itmcode;?>" maxlength="6" readonly
      onkeyup="checkInput(this)" class="modalinput"></div>
    <div class="col-md-4"><label for="cboCateg">Category of the Item</label><SELECT name="cboCateg" id="cboCateg" size="1" class="modalinput">
      <?php
          mysqli_multi_query($conn,"SELECT categ FROM grps WHERE categ IS NOT NULL or categ Not LIKE '' ORDER BY categ ASC; SELECT deptno,deptname FROM depts WHERE markdel=0;
          SELECT sno,acc,descr FROM acc_votes WHERE markdel=0 and pyt_defined=1 and sno>5;");
          $i=0; $optVotes='';
          do{
            if($rs=mysqli_store_result($conn)){
              if($i==0){
                if (mysqli_num_rows($rs)>0) while (list($cat)=mysqli_fetch_row($rs)) print "<option ".(strcasecmp($cat,$itmca)==0?"selected":"").">$cat</option>";
                print "</SELECT></div><div class=\"col-md-5\"><label for=\"cboDept\">User Department</label><SELECT name=\"cboDept\" id=\"cboDept\" size=\"1\" class=\"modalinput\">
                <option value=\"0\">General Use</option>";
              } elseif($i==1){
                if (mysqli_num_rows($rs)>0) while (list($dno,$dep)=mysqli_fetch_row($rs)) print "<option value=\"$dno\">$dep</option>";
              ?>
              </SELECT></div>
              </div><div class="form-row">
                <div class="col-md-12"><label for="txtName">Name of the Item</label><input type="text" name="txtItem" class="modalinput" id="txtItem" maxlength="29" value=""></div>
              </div><div class="form-row">
                <div class="col-md-12 divsubheading">STOCK LIMITS &AMP; PRICE OF THE ITEM/SERVICE</div>
              </div><div class="form-row">
                <div class="col-md-3"><label for="cboUnits">Units of Measure</label><SELECT name="cboUnits" id="cboUnits" size="1" class="modalinput"><option value="Pieces">Pieces
                </option><option value="crates">Crates</option><option value="Dozen">Dozen</option><option value="Grams">Grams</option><option value="Hours">Hours</option><option
                value="Days">Days</option><option value="Months">Months</option><option value="Kg">Kg</option><option value="Litres">Litres</option><option value="Metres">Metres
                </option><option value="Packets">Packets</option><option value="Pairs">Pairs</option><option value="Persons">Persons</option><option value="Sets">Sets</option>
                <option value="Reams">Reams</option><option value="Tonnes">Tonnes</option><option value="Bag">Bag</option><option value="Bales">Bales</option></select></div>
                <div class="col-md-3"><label for="txtMax">Max. Stock Level</label><Input name="txtMax" id="txtMax" type="text" value="10" maxlength="7"  class="modalinput numbersinput"
                onkeyup="checkInput(this)"></div>
                <div class="col-md-3"><label for="txtMax">Min. Stock Level</label><Input name="txtMin" class="modalinput numbersinput" id="txtMin" type="text" value="5" maxlength="7"
                  onkeyup="checkInput(this)"></div>
                <div class="col-md-3"><label for="txtMax">Unit Price</label><Input name="txtUP" id="txtUP" type="text" value="1" maxlength="7" class="modalinput numbersinput"
                  onkeyup="checkInput(this)"></div>
              </div><br><div class="form-row">
                <div class="col-md-12 divsubheading">VOTEHEADS ON WHICH THE ITEM CAN BE COSTED</div>
              </div><div class=\"form-row\">
            <?php
            }else{
                $index=0;
                foreach($accounts as $acc){
                    mysqli_data_seek($rs,0); print "<div class=\"col-md-4\"><label for=\"cboVotes_$index\" class=\"lblvotes\">".
                    $acc->valAcName()."</label><SELECT name=\"cboVotes_$index\" id=\"cboVotes_$index\" size=\"1\" class=\"modalinput\"><option value=\"0-0\">None</option>";
                    while($data=mysqli_fetch_row($rs)){
                        if($data[1]==$acc->valAcNo()) print "<option value=\"$data[1]-$data[0]\">$data[2]</option>";
                    }print "</select></div>"; $index++;
                }
            }mysqli_free_result($rs);
          }$i++;
        }while(mysqli_next_result($conn));
    ?>
</div><hr><DIV class="form-row">
      <div class="col-md-5"><button type="submit" name="btnSave" id="btnSave" class="btn btn-primary btn-block btn-lg">Save Item/Service</button></div>
      <div class="col-md-4"></div><div class="col-md-3"><button type="button" name="btnclose" id="btnclose" class="btn btn-info btn-block btn-lg"
        onclick="document.getElementById('divAddGoods').style.display='none'">Close</button></div>
</div></form></div></div></div><script type=\"text/javascript\" src=\"tpl/priv.js\"></script><script type="text/javascript" src="tpl/js/goodsadd.js"></script>
<?php mysqli_close($conn); footer(); ?>
<script type="text/javascript">
    $(document).ready(function(){//for sorting the units of sale
       var opt=$("#cboUnits option").sort(function(a,b){return a.value.toUpperCase().localeCompare(b.value.toUpperCase())});
       $("#cboUnits").append(opt);
    });
</script>
