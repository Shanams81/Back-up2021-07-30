<?php
    include_once('shanam.php');
    mysqli_multi_query($conn,"SELECT budgview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT finyr FROM ss");	$budgv=$i=0; $finyr=date('Y');
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){if (mysqli_num_rows($rs)>0) list($budgv)=mysqli_fetch_row($rs);
            }else{if(mysqli_num_rows($rs)>0) list($finyr)=mysqli_fetch_row($rs);}
        }$i++;
    }	while(mysqli_next_result($conn));
    headings('',0,0,0);
?>
<table class="table table-responsive table-borderless mytable" style="width:fit-content;color:#fff;"><thead class="thead-dark">
    <tr><td style="text-align:center;word-spacing:5px;letter-spacing:3px;"	colspan="2"><p>GOODS/ ITEMS AND BUDGET MANAGEMENT INTERFACE.<br> Log In Time: <?php echo $_SESSION['logintime'];?>
    </p></td>
    </tr></thead><tbody>
    <tr><td width="50%" align="center"><a onclick="return canvi(<?php echo $budgv;?>)" href="fyestimates.php"><img src="/gen_img/pledge.jpg" id="img1" width="100" height="90"
        onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>FY<?php echo $finyr;?> Estimates</td><td width="50%" align="center"><a onclick="return canvi(<?php echo $budgv;?>)"
        href="goods.php"><img src="/gen_img/goods.jpg" id="img2" width="100"	height="90" onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Goods and Services</td>
    </tr><tr><td width="50%" align="center"><a href="budg.php" onclick="return canvi(<?php echo $budgv;?>)"><img src="/gen_img/budg.jpg" id="img3" width="100" height="90"
        onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br><?php echo $finyr;?> Budget</td><td width="50%" align="center"><a href="budgdraft.php"
        onclick="return canvi(<?php echo $budgv;?>)"><img src="/gen_img/budg1.jpg" id="img4" width="100"	height="90" onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>
        <?php echo ($finyr+1);?> Draft Budget</td>
    </tr></tbody><tfoot class="thead-dark">
    <tr><td colspan="2" style="text-align:center;word-spacing:5px;letter-spacing:3px;text-align:center;"><p>Shanam's Digital Solutions - Bridging Digital Divide</p></td>
    </tr></tfoot>
</table><script type="text/javascript" src="tpl/menu.js"></script>
<?php
	mysqli_close($conn); footer();
?>
