<?php
  	include_once('../conn/pri_sch_connect.inc'); 
	$id=sanitize($_REQUEST['del']);
	// sending query
	mysqli_query($conn,"UPDATE depts SET markdel=1 WHERE deptno = '$id'")or die(mysqli_error($conn)." Record not deleted. Click <a href=\"depts.php\">here</a> to go back.");  	
	$i=mysqli_affected_rows($conn);
	mysqli_close($conn);
	header("Location:depts.php?action=2-$i");
?>