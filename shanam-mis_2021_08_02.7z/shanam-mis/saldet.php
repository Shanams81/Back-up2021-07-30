<?php
    include_once('shanam.php');
    mysqli_multi_query($conn,"SELECT salview,saladd,saledit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT schtype FROM ss;");
    $salviu=$saladd=$saledi=$scht=$i=0;
    do{
       if($rs=mysqli_store_result($conn)){
          if($i==0){ if(mysqli_num_rows($rs)==1) list($salviu,$saladd,$saledi)=mysqli_fetch_row($rs);
          }else { if(mysqli_num_rows($rs)==1) list($sscht)=mysqli_fetch_row($rs);
          }mysqli_free_result($rs);
       }$i++;
    }while (mysqli_next_result($conn));
    if($salviu==0) header("location:vague.php");	$sg=isset($_POST['CboSG'])?sanitize($_POST['CboSG']):"%"; $type=isset($_POST['cboType'])?sanitize($_POST['cboType']):1;
    $act=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0';	$act=preg_split('/\-/',$act);
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css" /><link href="tpl/css/modalfrm.css" rel="stylesheet" type="text/css" />',$act[0],$act[1],2);
?><div class="head">
<form method="post" action="saldet.php"><a href="stf_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;&nbsp;Show <SELECT name="cboType"
id="cboType" size="1"><option value="1">Current</option><option value="0">Old</option></select> Salary Definition of <select name="CboSG" size="1" id="sg"><option value="%">All</option>
<?php
        $rsP=mysqli_query($conn,"SELECT staff FROM grps WHERE staff is not null");
        if (mysqli_num_rows($rsP)>0) while (list($p)=mysqli_fetch_row($rsP)) print "<option>".$p."</option>"; 	mysqli_free_result($rsP);
?></select> Staff Members &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" name="SalaryDefn">View Salary Definitions</button>
</form></div>
<h5 style="font-weight:bold;letter-spacing:4px;word-spacing:7px;font-size:13pt;text-align:center;color:#fff;">SALARY DEFINITION FOR CURRENT MEMBERS OF STAFF</h5>
<div class="container" style="border:1px groove #fff;border-radius:15px 15px 0 0 ;padding:0 5px;margin:5px auto;width:fit-content;background-color:#e6e6e6;"><div class="form-row">
<div class="col-md-12" style="background:#fafafa;border-radius:10px;padding:6px;font-size:0.9rem;"><form name="frmFind" action="stf.php" method="post">Search for Staff
By <input type="radio" name="radFind" id="radIDNo" value="idno" onclick="clrText()">ID No. &nbsp; <input type="radio" name="radFind" id="radPFNo" onclick="clrText()"
value="payrollno">Payroll No.&nbsp; <input type="radio" name="radFind" id="radName" onclick="clrText()" value="name" checked>Names &nbsp; <input type="text" maxlength="15"
size="30" name="txtFind" value="" style="border:0px;border-bottom:1px solid blue;color:#00d;" placeholder="Type/Enter What to Find" onkeyup="myFunction(0)" id="txtFind"></form>
</div></div>
<div class="form-row"><div class="col-md-12" style="max-height:580px;overflow-y:scroll;padding:5px;width:fit-content;"><table class="table table-striped table-hover table-sm
table-bordered" id="myTable"><thead class="thead-dark"><tr><th colspan="8">Staff Member's Details</th><th colspan="5">Salary Amounts</th><th colspan="3">Admin Actions
</th></tr><tr><th>PF No.</th><th>ID. No.</th><th>Names</th><th>Designation</th><th>NSSF No.</th><th>NHIF No.</th><th>Pay Source</th><th>Pay Point</th><th>Basic Sal</th><th>
Allowances</th><th>Gross Sal</th><th>Deductions</th><th>Net Sal</th><th>View</th><th>Edit</th><th>Define</th></tr></thead><tbody>
<?php
if (isset($_POST['SalaryDefn'])):
	$stfg=trim($sg)=="%" ? "all":$sg;
	$h= $stfg.($type==1?" Current":" Old")." Member's Salary Defnition"; print "<center><h2>".strtoupper($h)."</h2></center>";
	if ($type==1) $sql="SELECT sd.`payrollno`,s.`idno`,concat(s.surname,' ',s.onames) as nam,s.designation,sd.nssfno,sd.nhifno,concat(sd.bankname,'-',sd.bankbranch) As paypoint,
	sd.bsal,(sd.houseallow+sd.medicalallow+sd.travellallow+sd.empnssf) as allow,(sd.bsal+sd.travellallow+sd.medicalallow+sd.houseallow+sd.empnssf) As GSal,(sd.nssffee+(sd.paye-sd.mpr)+
	sd.otherlevies+sd.empnssf+sd.nhiffee+sd.unionfee+sd.saccofee+sd.welfare) AS TDed,((sd.bsal+sd.travellallow+sd.medicalallow+sd.houseallow+sd.empnssf)-(sd.nssffee+(sd.paye-sd.mpr)+
	sd.empnssf+sd.otherlevies+sd.nhiffee+sd.unionfee+sd.saccofee+sd.welfare)) AS NetSalary,if(isnull(ac.abbr),'Any A/C',ac.abbr) as ac FROM stf s LEFT JOIN acc_saldef sd ON s.idno=sd.idno
	Left Join acc_voteacs ac ON (sd.acc=ac.acno) WHERE (s.markdel=0 and s.present=1 and s.staffgrp LIKE '$sg') ORDER BY s.surname,s.onames ASC";
	else $sql="SELECT sd.`payrollno`,s.`idno`,concat(s.surname,' ',s.onames) as nam,s.designation,sd.nssfno,sd.nhifno,concat(sd.bankname,'-',sd.bankbranch) As paypoint,
	sd.bsal,(sd.houseallow+sd.medicalallow+sd.travellallow+sd.empnssf) as allow,(sd.bsal+sd.travellallow+sd.medicalallow+sd.houseallow+sd.empnssf) As GSal,(sd.nssffee+(sd.paye-sd.mpr)+
	sd.otherlevies+sd.empnssf+sd.nhiffee+sd.unionfee+sd.saccofee+sd.welfare) AS TDed,((sd.bsal+sd.travellallow+sd.medicalallow+sd.houseallow+sd.empnssf)-(sd.nssffee+(sd.paye-sd.mpr)+
	sd.empnssf+sd.otherlevies+sd.nhiffee+sd.unionfee+sd.saccofee+sd.welfare)) AS NetSalary,if(isnull(ac.abbr),'Any A/C',ac.abbr) as ac FROM stf s INNER JOIN acc_saldef sd ON s.idno=sd.idno
	Left Join acc_voteacs ac ON (sd.acc=ac.acno) WHERE (s.markdel=1 or s.present=0) and s.staffgrp LIKE '$sg' ORDER BY s.surname,s.onames ASC";
else:
	$sql="SELECT sd.`payrollno`,s.`idno`,concat(s.surname,' ',s.onames) as nam,s.designation,sd.nssfno,sd.nhifno,concat(sd.bankname,'-',sd.bankbranch) As paypoint,sd.bsal,
	(sd.houseallow+sd.medicalallow+sd.travellallow+sd.empnssf) as allow,(sd.bsal+sd.travellallow+sd.medicalallow+sd.houseallow+sd.empnssf) As GSal,(sd.nssffee+(sd.paye-sd.mpr)+
	sd.otherlevies+sd.empnssf+sd.nhiffee+sd.unionfee+sd.saccofee+sd.welfare) AS TDed,((sd.bsal+sd.travellallow+sd.medicalallow+sd.houseallow+sd.empnssf)-(sd.nssffee+(sd.paye-sd.mpr)+
	sd.empnssf+sd.otherlevies+sd.nhiffee+sd.unionfee+sd.saccofee+sd.welfare)) AS NetSalary,if(isnull(ac.abbr),'Any A/C',ac.abbr) as ac FROM stf s LEFT JOIN acc_saldef sd ON s.idno=sd.idno
	Left Join acc_voteacs ac ON (sd.acc=ac.acno) WHERE (s.markdel=0 and s.present=1 and sd.markdel=0) ORDER BY s.surname,s.onames ASC";
endif;  $rsSalDef=mysqli_query($conn,$sql);
$tbs=0; $tall=0; $tgs=0; $tded=0; $tnet=0; $i=1;
$nosal=mysqli_num_rows($rsSalDef);
if ($nosal>0){
    while (list($pr,$id,$na,$des,$nsn,$nhn,$pp,$bs,$all,$gs,$ded,$net,$ac)=mysqli_fetch_row($rsSalDef)):
        print "<tr><td align=\"center\">$pr</td><td>$id</td><td>$na</td><td>$des</td><td>$nsn</td><td>$nhn</td><td>$ac</td><td>$pp</td><td align=\"right\">".number_format($bs,2)."</td><td
        align=\"right\">".number_format($all,2)."</td><td align=\"right\">".number_format($gs,2)."</td><td align=\"right\">".number_format($ded,2)."</td><td align=\"right\">".
        number_format($net,2)."</td><td align=\"center\">";
        if ($type==1){
            if (strlen($pr)>0) print "<a onclick=\"viewSalDef($salviu,'$pr')\" href=\"#\">View</a></td><td align=\"center\"><a onclick=\"return canadd($saledi)\" href=\"saldef.php?idno=$id-1\">"
            ."Edit</a></td><td align=\"center\">-</td>";
            else print "-</td><td align=\"center\">-</td><td align=\"center\"><a onclick=\"return canadd($saladd)\" href=\"saldef.php?idno=$id-0\">Define</a></td>";
        }else print "</td><td></td>"; print "</tr>";
        $tbs+=$bs; $tall+=$all; $tgs+=$gs; $tded+=$ded; $tnet+=$net; $i++;
    endwhile;
}else{
	print "<tr><td colspan=\"15\">No staff member is registered in the system</td></tr>";
}
print "</tbody><tfoot class=\"thead-dark\"><tr bgcolor=\"#D4AAFF\"><td colspan=\"8\" align=\"right\" class=\"b\">Salary Subtotals (Kshs.)</td><td align=\"right\">".number_format($tbs,2)."</td><td align=\"right\">".
number_format($tall,2)."</td><td align=\"right\" class=\"b\">".number_format($tgs,2)."</td><td align=\"right\" class=\"b\">".number_format($tded,2)."</td><td align=\"right\"
class=\"b\">".number_format($tnet,2)."</td><td colspan=\"3\"></td></tr></tfoot></table></div></div>";
?><center><span style="background:#eaa;border-bottom:2px groove #ddd;font-weight:bold;" id="spTotal"><?php echo $nosal;?> Staff Members.</span>&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Report Generated on <?php echo date("l F d, Y"); ?></div>
<div id="divSalDef" class="modal"><div class="imgcontainer"><span onclick="document.getElementById('divSalDef').style.display='none'" class="close" title="Close Modal"
style="color:#fff;">&times;</span></div><br/><div id="divSal"></div><div class="container" style="text-align:right;"><button type="button" class="cancelbtn"
onclick="document.getElementById('divSalDef').style.display='none'">Cancel</button></div></div>
<script type="text/javascript" src="tpl/js/saldef-find.js"></script>
<script type="text/javascript" src="tpl/priv.js"></script>
<?php mysqli_close($conn); footer(); ?>
