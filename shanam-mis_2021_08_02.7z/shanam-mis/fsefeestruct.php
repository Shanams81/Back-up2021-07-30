<?php
    include_once('shanam.php');
    mysqli_multi_query($conn,"SELECT struadd,struedit,struview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT finyr FROM ss;");
    $stad=$sted=$stvi=0; $i=0; $finyr=date('Y');
    do{
        if($rs=mysqli_Store_result($conn)){
            if($i==0){if (mysqli_num_rows($rs)==1) list($stad,$sted,$stvi)=mysqli_fetch_row($rs);}
            else list($finyr)=mysqli_fetch_row($rs); mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    $s[0]=0; $s[1]=0;
    if(isset($_POST['btnRefresh'])){
        mysqli_query($conn,"INSERT IGNORE INTO acc_feestruct (yr,lvlno,voteno) SELECT $finyr,1,v.sno FROM acc_votes v Inner Join acc_voteacs a ON (v.acc=a.acno) WHERE v.fs_defined=1 and
        v.markdel=0 and a.govt_assoc=1 and a.fee_assoc=0;") or die(mysqli_error($conn));
    }elseif(isset($_POST['btnSaveFS'])){//saving other accounts
        $nac=isset($_POST['txtData'])?sanitize($_POST['txtData']):'0-0-0'; $nac=preg_split('/\-/',$nac); //[0]-Year, [1]-A/C, and [2]-NoVotes
        $sql='';
        for($i=0;$i<$nac[2];$i++){
            $votno=isset($_POST['txtV_'.$i])?sanitize($_POST['txtV_'.$i]):0; 	$t1=isset($_POST['txtT1_'.$i])?sanitize($_POST['txtT1_'.$i]):0;
            $t2=isset($_POST['txtT2_'.$i])?sanitize($_POST['txtT2_'.$i]):0;     $t3=isset($_POST['txtT3_'.$i])?sanitize($_POST['txtT3_'.$i]):0;
            $t1=preg_replace('/[^0-9^\.]/','',$t1);    $t2=preg_replace('/[^0-9^\.]/','',$t2);  $t3=preg_replace('/[^0-9^\.]/','',$t3);   $t3+=$t2+$t1;    $t2+=$t1;
            $sql.="UPDATE acc_feestruct SET t1=$t1, t2=$t2, t3=$t3 WHERE yr LIKE '$nac[0]' and voteno LIKE '$votno';";
        }if(strlen($sql)>0){
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)." Click <a href=\"fsefeestruct.php\">HERE</a> to try again.");
            $i=0; do{$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $s[0]=1; $s[1]=$i;
        }
    }
    if($stvi==0){header("location:vague.php");	exit(0);}
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css"/><link href="tpl/css/inputsettings.css" rel="stylesheet" type="text/css"/>',$s[0],$s[1],2);
?><form method="post" action="fsefeestruct.php" ><div class="head" style="text-align:center;"><a href="fsegrants.php"><img src="img/ani_back.gif" hspace=1 width=45 height=20 align="left">
</a><b>ARE THERE NEW VOTEHEADS ADDED?</b> <button type="SUBMIT" name="btnRefresh" id="btnRefresh" <?php echo ($stad==0?"disabled":"");?>>Refresh FSE Voteheads</button></div>
<div class="container" style="margin:auto;padding:0 5px 0 5px;width:fit-content;background-color:#dedede;border:1px dotted #eee;border-radius:10px;"><h4 style="font-weight:strong;
letter-spacing:4px;word-spacing:7px;background-color:#000;color:#fff;text-align:center;border-radius:10px 10px 0 0;">FEE STRUCTURE DEFINITION</h4><div class="col-md-12">
<?php
    echo '<table class="table table-striped table-hover table-bordered" style="font-size:0.8rem;"><thead class="thead-dark"><tr><th>FSE A/C</th><th>TERM I</th><th>TERM II</th><th>TERM III
    </th><th>TOTAL FEE</th><th colspan="2">ADMIN ACTION</th></tr></thead><tbody>';
    $rsV=mysqli_query($conn, "SELECT a.descr,v.acc,sum(f.t1) as term1,sum(f.t2-f.t1) as term2,sum(f.t3-f.t2) as term3,sum(t3) as ttl FROM acc_feestruct f inner join acc_votes v on
    (f.voteno=v.sno) Inner Join acc_voteacs a ON (v.acc=a.acno) GROUP BY a.descr,v.acc,v.markdel,a.govt_assoc,a.fee_assoc HAVING v.markdel=0 and a.govt_assoc=1 and a.fee_assoc=1 Order By
    v.acc Asc"); 	$ttlAmt=array(0,0,0,0);
    while (list($accname,$acc,$t1,$t2,$t3,$ttl)=mysqli_fetch_row($rsV)):
        echo '<tr><td style="letter-spacing:4px;word-spacing:6px;">'.$accname.'</td><td style="text-align:right;">'.number_format($t1,2).'</td><td style="text-align:right;">'.
        number_format($t2,2).'</td><td style="text-align:right;">'.number_format($t3,2).'</td><td style="text-align:right;">'.number_format($ttl,2).'</td><td style="text-align:center;"><a '
        . 'href="#" onclick="showFS(0,'.$acc.')">View</a></td><td style="text-align:center;"><a href="#" onclick="return canedit('.$sted.','.$acc.')">Edit</a></td></tr>';
        $ttlAmt[0]+=$t1; $ttlAmt[1]+=$t2; $ttlAmt[2]+=$t3; $ttlAmt[3]+=$ttl;
    endwhile; mysqli_free_result($rsV);
    echo '</tbody><tfoot class="thead-dark"><tr><td style="font-weight:bold;text-align:right;"><b>TERM\'S TOTALS</b></td>';
    foreach ($ttlAmt as $amt) echo '<td style="text-align:right;font-weight:bold;">'.number_format($amt,2).'</td>';
    echo '<td colspan="2"></td></tr></tfoot></table>';
    echo '</div><div class="col-md-12" style="margin:5px auto 5px auto;border:1px dotted #00a;border-radius:8px;background-color:#e6e6e6;color:#000;font-size:9pt;padding:2px;" id="divFeeStruct">'
    . 'Fee Structure Details</div></div></div><script type="text/javascript" src="tpl/js/fsefeestruct.js"></script><script type="text/javascript" src="tpl/printthis.js"></script>';
     mysqli_close($conn);    footer();
?>
