<?php
    session_start();
    include_once('../conn/pri_sch_connect.inc');
    $act=isset($_REQUEST['action'])?$_REQUEST['action']:'1-2-Jan-2000'; $act=preg_split("/\-/",$act);
    if (($act[0]==0)){
        $rsSal=mysqli_query($conn,"SELECT payrollno,bsal,houseallow,medicalallow,travellallow,nssffee,nhiffee,otherlevies,empnssf,paye,mpr,unionfee,saccofee,
        welfare,concat(bankname,' - ',bankbranch) as bank FROM acc_saldef WHERE payrollno LIKE '$act[1]' ORDER BY payrollno Asc") or die(mysqli_error($conn).". 
        Click <a href=\"payrollcreator.php\">here</a> to try again"); $nostf=mysqli_num_rows($rsSal);
        if ($nostf>0){
            $addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')'; 	$date=date('Y-m-d');
            while (list($payno,$bsal,$hou,$med,$trav,$nss,$nhi,$ole,$empn,$paye,$mpr,$uni,$sac,$wel,$bank)=mysqli_fetch_row($rsSal)){
                $rsAdv=mysqli_query($conn,"SELECT a.advno,a.amtperduration,(a.amt-if(isnull(c.amt),0,c.amt)) as bal FROM acc_adv a LEFT JOIN (SELECT advano,
                curr_year,sum(amt_clr) as amt FROM acc_advclr GROUP BY markdel,advano HAVING markdel=0)c ON a.advno=c.advano) WHERE (a.markdel=0 and a.issued=1 
                and (a.amt-if(isnull(c.amt),0,c.amt))>0 and a.payrollno LIKE '$payno') ORDER BY a.advno ASC") or die(mysqli_error($conn).". Click <a 
                href=\"payrollcreator.php\">here</a> to try again");
                $i=mysqli_num_rows($rsAdv); $advamt=0;
                $sql="";
                if ($i>0){
                    while (list($advno,$amtper,$bal)=mysqli_fetch_row($rsAdv)){
                        $adva=($amtper<$bal) ? $amtper : $bal;
                        $advamt+=$adva;
                        $sql.="INSERT INTO acc_advclr (clrno,advano,clr_date,sal_month,curr_year,amt_clr,rmks) VALUES (null,'$advno','$date','$act[2]','$act[3]',
                        '$adva','Deducted from $act[2]-$act[3] salary');";
                    }	
                    mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"payrollcreator.php\">here</a> to try again");
                    while(mysqli_next_result($conn)){;}//flush multi_queries
                }$sql="";
                $sql.="INSERT INTO acc_salpyt(payrollno,sal_month,sal_year,processedon,bsalary,housingallow1,medicalallow1,travelallow1,nssffee1,nhiffee1,
                otherlevies1,advance,empnssf,paye1,mpr1,union1,sacco1,welfare1,paypoint,addedby) VALUES ('$payno','$act[2]','$act[3]','$date','$bsal','$hou',
                '$med','$trav','$nss','$nhi','$ole','$advamt','$empn','$paye','$mpr','$uni','$sac','$wel','$bank','$addby');";
            }
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"payrollcreator.php\">here</a> to try again"); 	
            while(mysqli_next_result($conn)){;}//flush multi_queries
        }	
    }else{
            $nostf=0;
    }
    mysqli_close($conn);
    header("location:payroll.php?action=1-$nostf");
?>