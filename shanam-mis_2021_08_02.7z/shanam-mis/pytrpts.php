<?php
	include_once('shanam.php');
	headings('<link rel="stylesheet" href="/date/tcal.css" /><link rel="stylesheet"  href="tpl/css/inputsettings.css" /><link href="tpl/css/spinner.css" rel="stylesheet" /><link href="tpl/css/modalfrm.css"
  rel="stylesheet" />',0,0,2);
?>
<form method="post" action="pytrpts.php">
<div class="container" style="background-color:#eee;margin:70px auto;border-radius:10px;padding:5px;width:40%"><div class="form-row"><div class="col-md-12 divheadings">PETTY CASH & COMMITMENT PAYMENT
  REPORTS</div></div>
  <div class="form-row"><div class="col-md-9">
    <div class="form-row">
      <div class="col-md-6"><label for="cboCat">Type of Payment</label><SELECT name-"cboCat" id="cboCat" size="3" class="modalinput"><option value="%" selected>All Payments</option><option value="1">Pettycash
        Payments</option><option value="2">Commitment Payments</option></SELECT>
      </div><div class="col-md-3"><label for="txtStart">Starting From</label><input type="text" name="txtStart" id="txtStart" class="modalinput tcal" value="<?php echo date('d-m-Y',strtotime('-30days'));?>"
        readonly></div>
      <div class="col-md-3"><label for="txtEnd">Ending On</label><input type="text" name="txtEnd" id="txtEnd" class="modalinput tcal" value="<?php echo date('d-m-Y');?>" readonly></div>
    </div><div class="form-row">
      <div class="col-md-12"><label for="cboAC">Account Payment Incurred</label><select class="modalinput" name="cboAC" id="cboAC" size="3"><option value="%" selected>All Accounts</option>
        <?php $rs=mysqli_query($conn,"SELECT acno,descr FROM acc_voteacs WHERE pyt_assoc=1 ORDER BY acno ASC"); while($d=mysqli_fetch_row($rs)) echo "<option value=\"$d[0]\">$d[1]</option>"; mysqli_free_result($rs);?>
      </select></div>
    </div>
  </div><div class="col-md-3"><br>
    <div class="form-row"><div class="col-md-12"><button type="button" name="btnShow" id="btnShow" class="btn btn-lg btn-primary btn-block" onclick="showReport()">Show Payment<br>Report</button></div></div><br><br>
    <div class="form-row"><div class="col-md-12"><button type="button" name="btnClose" id="btnClose" class="btn btn-md btn-info btn-block" onclick="winClose()">Close</button></div></div>
  </div></div>
</div></form>
<div id="busyWait" class="modal"  onclick="document.querySelector('#busyWait').style.display='none'"><div class="loader"></div></div>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript">
  function showReport(){let t=document.querySelector("#cboCat").value,st=document.querySelector("#txtStart").value,en=document.querySelector("#txtEnd").value,ac=document.querySelector("#cboAC").value;
    st=st.split('-'); st=st[2]+'-'+st[1]+'-'+st[0]; en=en.split('-'); en=en[2]+'-'+en[1]+'-'+en[0];
    window.open('rpts/pytrpts.php?r='+t+'~'+st+'~'+en+'~'+ac,'_blank');  document.querySelector('#busyWait').style.display='block';
  }function winClose(){window.open('home.php','_self');}
</script>
<?php mysqli_close($conn); footer(); ?>
