<?php
    include_once('shanam.php');
    $rs=mysqli_query($conn,"SELECT gofeeview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
    $canviu=0; if(mysqli_num_rows($rs)==1) list($canviu)=mysqli_fetch_row($rs); 	mysqli_free_result($rs);
    //feedbacks
    $batch=isset($_REQUEST['cboBatch'])?strip_tags($_REQUEST['cboBatch']):"%";
    $frm=isset($_REQUEST['CboForm'])?strip_tags($_REQUEST['CboForm']):"%";
    $strm=isset($_REQUEST['CboStream'])?strip_tags($_REQUEST['CboStream']):"%";
    if ($canviu==0) header("Location:vague.php");
    headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css" />',0,0,2);
?>
<div class="head" style="text-align:center;"><form method="post" action="fseben.php"><a href="fsegrants.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20"
align="left"></a>&nbsp;Beneficiaries of <SELECT name="cboBatch" id="cboBatch" size="1">
<?php
    mysqli_multi_query($conn,"SELECT batchno,sum(amt/noofstud) as amt FROM acc_fseincome GROUP BY markdel,batchno,commt HAVING markdel=0 and batchno>0 and commt=0 ORDER BY batchno DESC;
    SELECT clsno,clsname FROM classnames ORDER BY clsno ASC; SELECT strm FROM grps WHERE strm is not null or strm not like '';") or die(mysqli_error($conn).' Error in database connection');
    $count=0;
    do{
        if($rs=mysqli_store_result($conn)){
            $i=0;
            if($count==0){
                if (mysqli_num_rows($rs)>0) while($d=mysqli_fetch_row($rs)){
                    if($i==0 && $batch=='%') $batch=$d[0];
                    print "<option value=\"$d[0]\" ".($batch==$d[0]?"selected":"").">Tranche $d[0] of Kshs. ".number_format($d[1],2)." Per Student</option>"; $i++;
                }print "</SELECT> in Class <Select name=\"CboForm\" id=\"CboForm\" size=\"1\" id=\"form\"><option value =\"%\"selected>All</Option>";
            }elseif($count==1){
                if (mysqli_num_rows($rs)>0) while (list($clsno,$class)=mysqli_fetch_row($rs)){
                    if($frm!='%' && $frm==$clsno) $clsname=$class;
                    print "<option value=\"$clsno\" ".(strcasecmp($clsno,$frm)==0?"selected":"").">$class</option>";
                }$clsname=(strlen($clsname)>0?$clsname:'All');
                print "</select> - <select name=\"cboStream\" id=\"cboStream\" size=\"1\" id=\"stream\"><option selected value=\"%\">All</option>";
            }else{
                if (mysqli_num_rows($rs)>0) while (list($d)=mysqli_fetch_row($rs)){
                    if($strm!='%' && $strm==$d) $strmname=$d;
                    print "<option value=\"$d\" ".(strcasecmp($d,$strm)==0?"selected":"").">$d</option>";
                }$strmname=(strlen($strmname)>0?$strmname:'');
            }mysqli_free_result($rs);
        }$count++;
    }while(mysqli_next_result($conn));
?></select>&nbsp; &nbsp; <button type="submit" name="cmdShow">Show Beneficiaries</button></form></div><br>
<div class="container" style="width:fit-content;"><div style="border:0.5px dashed #00f;border-radius:6px;padding:2px;background-color:#51adcf;font-size:10pt;margin:auto;">
<?php
    if($batch>0){?><form name="frmFind" method="post" action="#">Find Student By <input type="radio" name="radFind" id="radAdmNo" value="0" checked onclick="clearTxt()">Adm. No. &nbsp;
    <input type="radio" name="radFind" id="radNames" value="0" onclick="clearTxt()">Names &nbsp; <input name="txtFind" id="txtFind" type="text" size="20" maxlength="12" onkeyup="viewReceipts(this)"
    value="" placeholder="Type here what to find">
<?php
	echo (isset($_POST['cmdShow'])?'&nbsp; or &nbsp; &nbsp;&nbsp;<a href="pdf/fsebenlist.php?action='.$batch.'-'.$frm.'-'.$strm.'" target="_BLANK"><button type="button" name="cmdList">
	<img src="../gen_img/print.ico" width=18 height=16 title="Print List">Printable List</button></a>&nbsp; &nbsp;&nbsp;<a href="pdf/fsestudreceipts.php?action='.
	$batch.'-'.$frm.'-'.$strm.'-%" target="_BLANK"><button type="button" name="cmdRec" onclick="viewReceipts(this)"><img src="../gen_img/print.ico" width=18 height=16 title="FSE Receipts">FSE
	Receipts</button></a>':'').'<br><b style="text-tranform:uppercase;font-size:12pt;font-weight:bold;letter-spacing:1px;word-spacing:2px;text-decoration:underline #555 double;color:#555;
	padding:5px;">'.(strcasecmp($clsname,'all')==0?'All':'FORM '.$clsname).' '.$strmname.' BENEFICIARIES OF FSE TRANCHE '.$batch .'</b></form>';
	$rs=mysqli_query($conn,"SELECT acno,abbr from acc_voteacs WHERE govt_assoc=1 and fee_assoc=1 and markdel=0 ORDER BY acno ASC"); $sql=''; $noa=mysqli_num_rows($rs); $noa++;
	while(list($acno,$name)=mysqli_fetch_row($rs)){	$sql.="sum(if(b.acc=$acno,b.amt,0)) as ttl$acno,";	$acname[]=$name;}
	$sql="SELECT b.admno,concat(s.surname,' ',s.onames) as nms,concat(c.`clsname`,'-',sf.`stream`) As frm,$sql sum(b.amt) as ttl FROM stud s Inner Join class sf USING (admno,
	curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) Inner Join acc_fseben b USING (admno) Inner Join acc_fseincome i USING (recno) GROUP BY i.batchno,b.admno,s.surname,s.onames,
	c.clsname,sf.stream,c.clsno,s.curr_year HAVING batchno like '$batch' AND c.clsno LIKE '$frm' and sf.stream LIKE '$strm' ORDER BY b.admno ASC";
	$rsStud=mysqli_query($conn,$sql);
	print '<div style="border:0.5px dotted #fff;margin:auto;width:fit-content;border-radius:8px;background:#f6f6f6;padding:4px;max-height:580px;overflow-y:scroll;"><table id="myTable"
	 class="table table-striped table-hover table-bordered table-sm"><thead class="thead-dark"><tr><th colspan="4">STUDENTS\' DETAILS</th><th colspan="'.$noa.'">FSE FEE AMOUNT</th><th
   rowspan="2">RECEIPT</th></tr><tr><th>#</th><th>ADM.NO.</th><th>NAMES</th><th>FORM</th>';
  foreach($acname as $ac){$ttl[]=0; print '<th>'.$ac.'</th>';} print'<th>TOTAL</th></tr></tfoot><tbody>';    $ttl[]=0;	$i=0; $nos=mysqli_num_rows($rsStud);
	if ($nos>0){
            while ($rsS=mysqli_fetch_array($rsStud,MYSQLI_NUM)):
                print "<tr><td>".($i+1)."</td>";	$a=0; $admno=0;
                foreach($rsS as $sr){
                    if($a==0) $admno=$sr;
                    if ($a<3) print "<td ".($a==0?"align=\"center\"":"").">".strtoupper($sr)."</td>";
                    else{print "<td align=\"right\">".number_format($sr,2)."</td>"; $ttl[$a-3]+=$sr;}
                    $a++;
                }print "<td align=\"center\"><a href=\"pdf/fsestudreceipts.php?action=$batch-$frm-$strm-$admno\" target=\"_BLANK\"><img src=\"../gen_img/print.ico\" width=18 height=16
                title=\"Individual FSE Receipts\"> Print</a></td>"; $i++;
            endwhile;
	}else	print "<tr><td colspan=\"7\">No beneficiaries</td></tr>";	mysqli_free_result($rsStud);
	print "</tbody><tfoot><tr bgcolor=\"#eeaaaa\"><td colspan=\"3\" align=\"left\" id=\"tdNOB\"><b>$nos Beneficiaries</b></td><td align=\"right\"><b>Subtotals</b></td>";
	foreach ($ttl as $t) print "<td align=\"right\"><b>".number_format($t,2)."</b></td>";	print "<td></td></tr></tfoot></table><p style=\"color:#f0f;\">Report Generated on ".
  date("l F d, Y")."</p>";
	mysqli_close($conn);
}else print "<p style=\"font-size:14pt;font-weight:bold;\">THERE ARE NOT FSE FUNDS RECEIPT IN THE SYSTEM.</p>"; ?></div></div></div>
<script type="text/javascript">
    function viewReceipts(txt){
        var input,table,tr,td,l=0,i,nop=0,a=(document.getElementById("radAdmNo").checked?1:2);
        input=txt.value.toUpperCase();
        table=document.getElementById("myTable"); tr=table.getElementsByTagName("tr"); l=tr.length;
        for(i=2;i<(l-1);i++){
            td=tr[i].getElementsByTagName("td")[a];
            if (td){
                if(a==0){if(td.innerHTML.trim()==input){tr[i].style.display=""; nop++;}else tr[i].style.display="none";//find by adm no
                }else{if(td.innerHTML.toUpperCase().trim().indexOf(input)>-1){tr[i].style.display=""; nop++;} else tr[i].style.display="none";
                }
            }
        }document.getElementById("tdNOB").innerHTML=nop+' Beneficiaries.';
    }function clearTxt(){
        document.getElementById("txtFind").value='';
        document.getElementById("txtFind").focus();
    }
</script></body></html>
