<?php
	include_once('shanam.php');
	$action=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0'; 				$action=explode('-',$action);
	$sda=isset($_POST['txtFrom'])?sanitize($_POST['txtFrom']):"01-01-".date("Y");		$eda= isset($_POST['txtTo'])?sanitize($_POST['txtTo']):date("d-m-Y");
	$sda=explode('-',$sda); $eda=explode('-',$eda); $sda="$sda[2]-$sda[1]-$sda[0]";	$eda="$eda[2]-$eda[1]-$eda[0]";
	$acc=isset($_POST['cboAC'])?$_POST['cboAC']:1;	$mode= isset($_POST['cboMode'])?strtolower(sanitize($_POST['cboMode'])):"direct banking";
	if (isset($_POST["btnShow"])){
		$rmks=isset($_POST['cboRmks'])?sanitize($_POST['cboRmks']):1;
	}elseif (isset($_POST["btnSave"]) || isset($_POST["btnSaveCash"])){
		$act=isset($_POST['txtNo'])?sanitize($_POST['txtNo']):"0-0"; 					$act=preg_split('/\-/',$act);//[0] No. of Reciepts and [1]- Acount
		$tkn=isset($_POST['form_token'])?sanitize($_POST['form_token']):'0';	$user=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		if(isset($_POST["btnSave"])){
			$amt=isset($_POST['txtDeposit'])?strip_tags($_POST['txtDeposit']):0;		$nar=isset($_POST['txtRmks'])?strip_tags($_POST['txtRmks']):"";
			$acsno=isset($_POST['cboAccount'])?strip_tags($_POST['cboAccount']):0;	$opt=0;
		}else{
			$amt=isset($_POST['txtCash'])?strip_tags($_POST['txtCash']):0;		$nar=isset($_POST['txtNarr'])?strip_tags($_POST['txtNarr']):""; $opt=1;
		}	$amt=preg_replace("/[^0-9^\.]/","",$amt); 	$action[0]=0; $action[1]=0;
		if(($act[0]==0 && $act[1]==0) || $amt==0 || strlen($nar)<10 || $_SESSION['form_token']!=$tkn || ($opt==0 && $acsno<1)){
			print "Saving Failed. Ensure records are properly entered before saving. Click <a href=\"confirmtrans.php\">HERE</a> to go back."; exit(0);
		}else{
			unset($_SESSION['form_token']);
			if($opt==0) $sql="INSERT acc_banking(sno,transdate,bank_type,cheno,acSno,amt,rmks,transtype,transno,addedby) VALUES (0,curdate(),0,null,'$acsno','$amt','$nar',	0,null,'$user')";
			else $sql="INSERT acc_cashflow (cfno,acc,cftype,cfdate,amt,rmks,transtype,transno,addedby) VALUES (0,$act[1],0,curdate(),$amt,'$nar',0,null,'$user')";
	 		if(mysqli_query($conn,$sql) or die(mysqli_error($conn).". Transaction details not saved. Click <a href=\"confirmtrans.php\">HERE</a> to		go back")){
				$id=mysqli_insert_id($conn); $sql="";
			 	if ($id>0){
				 for ($i=1;$i<=$act[0];$i++){
						$val=isset($_POST["chkBank_$i"])?strip_tags($_POST["chkBank_$i"]):0;
						if ($val==1){$sNo=sanitize($_POST["txtSNo_$i"]); $sql.="UPDATE acc_incofee SET verdate=curdate(),verstate=1,verbanked=1,verno=$id WHERE sno LIKE '$sNo';";}
					}if (strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Income confirmation failed. Click <a href=\"confirmtrans.php\">HERE
					</a> to go back"); $action[0]=1; $action[1]=1;  while(mysqli_next_result($conn)){$action[1]+=mysqli_affected_rows($conn);}}
				}
			}else{print "Error in banking fees income";}
		}
	}
	$rs=mysqli_query($conn,"SELECT sno FROM acc_accounts"); $noac=mysqli_num_rows($rs); mysqli_free_result($rs);
	if ($noac==0){// there are bank accounts defined in the system
		print "<font style=\"color:#770;text-align:center;font-weight:bold;font-size:14pt;\">WARNING: You have not defined institute's bank accounts. Click <a href=\"accounts.php\">HERE</a>
		to define accounts.</font>"; 		exit(0);
	}else{
		$form_token=$_SESSION['form_token']=uniqid();
		mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE markdel=0 and fee_assoc=1; SELECT a.sno,concat(b.descr,' - (',a.branch,') A/C No. ',a.accNo) as ac FROM
		acc_accounts a Inner JOin acc_banks b ON (a.bankno=b.sno) WHERE accacc IN (1,2) ORDER BY b.descr Asc");				$acname=$optacc=$optbanks=''; $i=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){while($d=mysqli_fetch_row($rs)){$optacc.="<option ".($acc==$d[0]?"selected":"")." value=\"$d[0]\">$d[1]</option>";if($acc==$d[0]) $acname=$d[1];}
			}else{while($d=mysqli_fetch_row($rs)) $optbanks.="<option value=\"$d[0]\">$d[1]</option>";}mysqli_free_result($rs);
			}$i++;
		}while (mysqli_next_result($conn));
	}	headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" type="text/css" href="/date/tcal.css" /><link rel="stylesheet" type="text/css"
	href="tpl/css/modalfrm.css" /><link href="tpl/css/spinner.css" rel="stylesheet" type="text/css"/><link href="tpl/css/inputsettings.css" rel="stylesheet" type="text/css"/>',
	$action[0],$action[1],2);
?><div class="head"><form method="post" action="confirmtrans.php" name="frmFind"><a href="withdrawborrow.php"><img src="/gen_img/ani_back.gif" hspace="1" width="45" height="20"
	align="left"></a>Unconfirmed <SELECT name="cboMode" id="cboMode" Size="1"><option <?php echo strcasecmp($mode,'direct banking')==0?"selected":"";?>>Direct Banking</option><option
<?php echo strcasecmp($mode,'cash')==0?"selected":"";?>>Cash</option><option <?php echo strcasecmp($mode,'money order')==0?"selected":"";?>>Money Order</option><option <?php echo
strcasecmp($mode,'mfees')==0?"selected":"";?>>M-Fees</option><option <?php echo strcasecmp($mode,'cheque')==0?"selected":"";?>>Cheque</option></SELECT> Fees in <SELECT name="cboAC"
id=\"cboAC\" Size=\"1\"><?php echo $optacc;?></select> Received Between <input name="txtFrom" class="tcal" type="text" value="<?php echo date("d-m-Y",strtotime($sda));?>" readonly
size="8"> and <input name="txtTo" class="tcal" type="text" value="<?php echo date("d-m-Y",strtotime($eda));?>" readonly size="8">&nbsp;&nbsp;<button type="submit" accesskey="s" name="btnShow"
class="btn btn-warning btn-md">View Fees</button></form></div>
<?php
print "<br><div class=\"container\" style=\"background-color:#e6e6e6;width:fit-content;margin:0 auto;border-radius:10px;\"><div class=\"form-row\"><div class=\"col-md-12 divheadings\">
<h5>";
	$sql="SELECT * FROM (SELECT f.recno,f.sno,i.pytdate,i.admno,concat(s.surname,' ',s.onames) as names,i.pytfrm,i.cheno,(f.amt-f.transfer) as amt,i.verstate FROM acc_incofee i Inner
	Join ".($acc<2?"acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join stud s USING (admno) WHERE i.verstate=0 and i.markdel=0 and f.markdel=0 and i.commt=0 and i.pytfrm LIKE
	'$mode' and (i.pytdate between '$sda' and '$eda') UNION SELECT f.recno,f.sno,i.pytdate,s.idno asadmno,s.alt_names names,i.pytfrm,i.cheno,(f.amt-f.transfer) as amt,i.verstate FROM
	acc_incofee i Inner Join ".($acc<2?"acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join acc_alterincome s on (i.admno=s.code) WHERE i.verstate=0 and i.markdel=0 and f.markdel=0
	and i.commt=0 and i.pytfrm LIKE	'$mode' and (i.pytdate between '$sda' and '$eda') UNION SELECT f.recno,f.sno,i.pytdate,s.idno as admno,concat(s.surname,' ',s.onames) as names,i.pytfrm,
	i.cheno,(f.amt-f.transfer) as amt,i.verstate FROM acc_incofee i Inner	Join ".($acc<2?"acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join acc_tenants t ON (i.admno=t.tno) Inner
	Join stf s ON (t.idno=s.idno) WHERE i.verstate=0 and i.markdel=0 and f.markdel=0 and i.commt=0 and i.pytfrm LIKE '$mode' and (i.pytdate between '$sda' and '$eda') UNION SELECT f.recno,
	f.sno,i.pytdate,s.idno,s.alt_names,i.pytfrm,i.cheno,f.amt,i.verstate FROM acc_incofee i Inner Join ".($acc<2?"acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join
	acc_alterincome s On	(i.admno=s.code) WHERE i.verstate=0 and i.markdel=0 and f.markdel=0 and i.commt=2 and i.pytfrm LIKE '$mode' and (i.pytdate between '$sda' and '$eda'))f ORDER BY
	recno ASC LIMIT 0, 100"; 	$rs=mysqli_query($conn,$sql);	$nor=mysqli_num_rows($rs);
	?><form name="frmData" method="post" action="confirmtrans.php" onsubmit="return confirmData(<?php echo "$nor,'$mode'";?>)">
	<?php echo strtoupper("Showing $nor Unbanked $acname Fee Received in $mode between ".date("D d-M-Y",strtotime($sda))." and ".date("D d-M-Y",strtotime($eda)));?></h5></div></div>
	<div class="form-row"><div class="col-md-12" style="max-height:450px;overflow-y:scroll;"><table class="table table-bordered table-sm table-striped table-hover" style="font-size:0.8rem;">
	<thead class="thead-dark"><tr><th>S/No.</th><th>Receipt<br>No.</th><th>Received On</th><th>Adm/ID<br>No.</th><th>Received From</th><th>Mode</th><th>Mode No.</th><th>Amount</th><th>
	Banked<br><input type="checkbox" name="chkAll" id="chkAll" value="1" onclick="selectAll(<?php echo "$nor,'$mode'";?>)">All</th></tr></thead>
	<?php $i=1; 	$ttl=0;		print "<input type=\"hidden\" name=\"txtNo\" value=\"$nor-$acc\"><input type=\"hidden\" name=\"form_token\" value=\"$form_token\">";
	if ($nor>0){
		while (list($recno,$sno,$dat,$no,$names,$mod,$modeno,$amt,$st)=mysqli_fetch_row($rs)):
			print "<tr><td>$i</td><td align=\"center\"><input type=\"hidden\" name=\"txtSNo_$i\" value=\"$sno\">$recno</td><td align=\"right\">".date("D d M, Y",strtotime($dat))."</td>
			<td>$no</td><td>$names</td><td>$mod</td><td>$modeno<td align=\"right\"><input size=\"8\" type=\"text\" name=\"txtAmt_$i\"	id=\"txtAmt_$i\" readonly class=\"inputText\" value=\"".
			number_format($amt,2)."\"></td><td align=\"center\"><input type=\"checkbox\" name=\"chkBank_$i\" id=\"chkBank_$i\"	value=\"1\" ".($st==1?"checked disabled":"")."
			onclick=\"calcTtl($nor,'$mode')\"></td></tr>";	$ttl+=$amt; 	$i++;
		endwhile;
	}else	print "<tr><td colspan=\"9\"><br>No unbanked fees receipts were made between ".date("D d-M-Y",strtotime($sda))." and ".date("D d-M-Y", strtotime($eda))."</td></tr>";
	?><tr><td colspan="5"><b><?php echo $nor;?> Income Record(s)</b></td><td colspan="2" align="right"><b>Total	KShs.</b></td><td colspan="2"><input name="txtTtl" id="txtTtl"
	style="font-weight:bold;text-align:right;border:0px;background-color:#093;" readonly size="12" value="<?php echo number_format($ttl,2);?>"></td></tr></tr></table>
	</div></div>
	<div class="form-row"><div class="col-md-6">
		<div class="container" style="border:1px groove #0ff;border-radius:10px 10px 0 0;background-color:#f6f6f6;width:fit-content;margin:15px auto;font-size:0.9rem;">
			<div class="form-row"><div class="col-md-12" style="font-weight:bold;letter-spacing:4px;word-spacing:6px;color:#fff;background-color:#000;padding:6px;">BANK CONFIRMED
			RECEIPTS</div></div>
			<div class="form-row"><div class="col-md-12"><label for="cboAccount">Bank A/C to be Credited</label><SELECT name="cboAccount" id="cboAccount" size=1
			class="form-control"><?php echo $optbanks;?></SELECT></div></div>
			<div class="form-row">
				<div class="col-md-6"><label for="txtDeposit">Total Amount</label><input type="text" readonly name="txtDeposit" id="txtDeposit" class="form-control"
				style="text-align:right;border:0px;font-weight:bold;" value="0.00" ></div>
				<div class="col-md-6"><label for="txtRmks">Narration on Transaction</label><input type="text" maxlength="30" name="txtRmks" id="txtRmks" readonly class="form-control"
				value="FEE RECEIPTS"></DIV>
			</div><hr>
			<div class="form-row"><div class="col-md-12"><button type="submit" name="btnSave" class="btn btn-block btn-primary btn-md">Bank Confirmed Incomes</button></div></div>
		</div>
	</div><div class="col-md-6">
	<?php
		//cashing of cash reciepts and money orders
		if (strcasecmp($mode,"cash")==0 || strcasecmp($mode,"money order")==0){
		?>
		<div class="container" style="border:1px groove #0ff;border-radius:10px 10px 0 0;background-color:#f6f6f6;width:fit-content;margin:15px auto;font-size:0.9rem;">
			<div class="form-row"><div class="col-md-12" style="font-weight:bold;letter-spacing:4px;word-spacing:6px;color:#fff;background-color:#000;padding:6px;">CASHING CONFIRMED
				RECIEPTS</div></div>
			<div class="form-row"><div class="col-md-12"><label for="txtAcc">Votehead Account Receiving Cash</label><input type="text" name="txtAcc" id="txtAcc" value="<?php echo $acname;?>"
			class="form-control"></div></div>
			<div class="form-row">
				<div class="col-md-6"><label for="txtCash">Amount Cashed</label><input type="text" class="form-control" readonly name="txtCash" 	id="txtCash" style="text-align:right;
				border:0px;font-weight:bold;" value="0.00"></div>
				<div class="col-md-6"><label for="txtNarr">Narration on Cashing</label><input type="text" class="form-control" maxlength="30" name="txtNarr" id="txtNarr"
				readonly value="FEE RECEIPTS"></DIV>
			</DIV><hr>
			<div class="form-row"><div class="col-md-12"><button type="submit" name="btnSaveCash" class="btn btn-block btn-primary btn-md">Cash Confirmed Reciepts</button></DIV></div>
			</div></div>
		</div>
		<?php } echo "</form>";
?></div><div id="busyWait" class="modal"><div class="loader"  onclick="document.querySelector('#busyWait').style.display='none'"></div></div>
<script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/confirmtrans.js"></script>
<?php mysqli_close($conn); footer();?>
