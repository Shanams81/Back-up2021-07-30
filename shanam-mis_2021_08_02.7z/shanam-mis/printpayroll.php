<?php
	include_once('../conn/pri_sch_connect.inc');
	include_once('../mpdf/mpdf.php');
	$dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0-0";
	$dat=preg_split("/\-/",$dat);	//0 - Month, 1 - Year and 2 - Staff Group	
	$sql="SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.paypoint,sp.bsalary,sp.housingallow1,sp.medicalallow1,sp.travelallow1,sp.empnssf,
	(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.empnssf) AS GSal,sp.nssffee1,sp.nhiffee1,sp.union1,(sp.paye1-sp.mpr1) as taxes1,sp.advance,sp.sacco1,sp.welfare1,
	sp.otherlevies1,(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1) AS TtlDed,((sp.bsalary+sp.empnssf+sp.housingallow1+
	sp.medicalallow1+sp.travelallow1)-(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1)) AS NetSal FROM Stf s INNER JOIN 
	Acc_SalDef sd Using (idno) INNER JOIN Acc_SalPyt sp ON sd.payrollno=sp.payrollno Where ((sp.sal_month LIKE '$dat[0]') And (sp.sal_year LIKE '$dat[1]') and (s.staffgrp LIKE '$dat[2]') 
	and sp.markdel=0) ORDER BY sp.processedon,s.surname,s.onames ASC";
	$rsSal=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsSal); 
	$h=$dat[0].'-'.$dat[1].' Salary payroll of';
	if (strcasecmp($dat[2],"%")==0) $h.=' all members of staff'; else $h.=' '.$dat[2].' members'; $h=strtoupper($h);
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,mission,motto FROM ss"); 
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mis,$mot)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	//start pdf file
	$mpdf=new mPDF('c','A4-L','','',10,10,12,12,10,10); 
	$mpdf->useOnlyCoreFonts = true;    // false is default
	$mpdf->SetWatermarkText("$dat[0]-$dat[1] Payroll");
	$mpdf->showWatermarkText = true;
	$mpdf->watermark_font = 'DejaVuSansCondensed';
	$mpdf->watermarkTextAlpha = 0.1;
	$mpdf->SetDisplayMode('fullpage');
	$mpdf->setFooter('Page {PAGENO} of {nbpg} Pages');
	$html='<html><head><title>'.$dat[0].' - '.$dat[1].' Payroll</title><style> 
			table.hide {border:0px;collapse;font-size:12px;font-weight:bold;letter-spacing:2px;word-spacing:3px;}
			td.hide,th.hide{border:0px;}
			table.gen,td,th {border:0.5px solid blue;border-collapse:collapse;font-weight:normal;font-size:8pt;}
			</style></head><body>';
	$html.='<table cellspacing="0" width="100%" class="hide"><tr><td rowspan="3" valign="middle" width="90" align="center" class="hide"><img src="img/logo.png" width="70" height="70" 
	vspace="1" hspace="1"></td><td class="hide">'.$scnm.'</td></tr><tr><td class="hide">'.$scadd.'</td></tr><tr><td class="hide">'.$mot.'</td></tr><tr><td colspan="2" class="hide"><hr>
	<b style="font-size:12px;">'.$h.'</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Printed On:'.date("D d-M-Y").'<hr></td></tr></table>';
	$html.='<table cellpadding="1" cellspacing="0" class="gen"><tr align="middle"><th colspan="5">Staff Member\'s Details</font></th><th rowspan="2" bgcolor="#eeeeee">Basic<br>Salary</th>
	<th colspan="4">Salary Allowances</th><th rowspan="2" bgcolor="#eeeeee">Gross<br>Salary</th><th colspan="8">Deductions On Salary</th><th rowspan="2" bgcolor="#eeeeee">Total<br>Ded\'ns
	</th><th rowspan="2" bgcolor="#eeeeee">Net<br>Salary</th><th rowspan="2">Signature</th></tr><tr bgcolor="#eeeeee"><th>ID. No.</th><th>Payroll No.</th><th>Names</th><th>Designation</th>
	<th>Pay Point</th><th>Housing</th><th>Medical</th><th>Overtime</th><th>Employer NSSF</th><th>N.S.S.F</th><th>N.H.I.F</th><th>Union</th><th>PAYE</th><th>Salary<br>Advance</th><th>SACCO
	</th><th>Welfare<br>Fund</th><th>Other<br>Dedns</th></tr>';
	$tbs=0; $tho=0; $tme=0; $ttr=0; $ten=0; $tgs=0; $tns=0; $tnh=0; $tun=0; $tta=0; $tad=0; $tsac=0; $tris=0; $tod=0; $ttd=0;	$tnet=0; $i=0;
	if ($nor>0):
		while (list($id,$pr,$na,$de,$pp,$bs,$ho,$me,$tr,$en,$gs,$ns,$nh,$un,$ta,$ad,$sac,$ris,$od,$td,$net)=mysqli_fetch_row($rsSal)):
			if (($i%2)==0) $html.='<tr>'; else $html.='<tr bgcolor="#eeeeee">';
			$html.='<td>'.$id.'</td><td>'.$pr.'</td><td>'.$na.'</td><td>'.$de.'</td><td>'.$pp.'</td><td align="right"><b>'.number_format($bs,2).'</b></td><td align="right">'.
			number_format($ho,2).'</td><td align="right">'.number_format($me,2).'</td><td align="right">'.number_format($tr,2).'</td><td align="right">'.number_format($en,2).
			'</td><td align="right"><b>'.number_format($gs,2).'</b></td><td align="right">'.number_format($ns,2).'</td><td align="right">'.number_format($nh,2).'</td><td align="right">'.
			number_format($un,2).'</td><td align="right">'.number_format($ta,2).'</td><td align="right">'.number_format($ad,2).'</td><td align="right">'.number_format($sac,2).'</td><td 
			align="right">'.number_format($ris,2).'</td><td align="right">'.number_format($od,2).'</td><td align="right"><b>'.number_format($td,2).'</b></td><td align="right"><b>'.
			number_format($net,2).'</b></td><td></td></tr>';
			$tbs+=$bs; $tho+=$ho; $tme+=$me; $ttr+=$tr; $ten+=$en; $tgs+=$gs; $tns+=$ns; $tnh+=$nh;  $tun+=$un; $tta+=$ta; $tad+=$ad;  $tsac+=$sac; $tris+=$ris; $tod+=$od; $tnet+=$net; 
			$ttd+=$td; $i++;
		endwhile;
	else:
		$html.='<tr><td colspan="22">No Salary for '.$dat[0].'-'.$dat[1].'</td></tr>';
	endif;
	$html.='<tr bgcolor="#eeaaaa"><td colspan="22" align="left" class="b">'.$nor.' Staff Members\' Salary</td></tr></table><pagebreak orientation="landscape">';
	$html.='<Table class="hide" cellpadding="2" cellspacing="0"><tr><th colspan="2" style="letter-spacing:3px;word-spacing:5px;font-weight:bold;" class="hide">'.strtoupper($dat[0]).'-'.
	$dat[1].' SALARY\'S SUBTOTALS ANALYSIS</th></tr><tr><td class="hide" valign=\"top\"><table class="gen" cellpadding="0"><tr><th colspan="2"><b>BASIC SALARY &amp; ALLAOWANCES</b></th>
	</tr><tr><td>Basic Salary</td><td align="right">'.number_format($tbs,2).'</td></tr><tr><td>House Allowance</td><td align=\"right\">'.number_format($tho,2).'</td></tr><tr><td>Medical 
	Allowance</td><td align="right">'.number_format($tme,2).'</td></tr><tr><td>Overtime</td><td align="right">'.number_format($ttr,2).'</td></tr><tr><td>Employer\'s 
	NSSF Contribution</td><td align="right">'.number_format($ten,2).'</td></tr><tr><td>-</td><td>-</td></tr><tr><td><b>Total Gross Salary</b></td><td 
	align="right"><b>'.number_format(($tgs+$en),2).'</b></td></tr></table></td>';
	$html.='<td class="hide"><table class="gen" cellspacing="0"><tr><th colspan="2"><b>SALARY DEDUCTIONS</b></th></tr><tr><td>N . S . S . F</td><td 
	align="right">'.number_format($tns,2).'</td></tr><tr><td>N . H . I . F</td><td align="right">'.number_format($tnh,2).'</td></tr><tr><td>
	Union Levies</td><td align="right">'.number_format($tun,2).'</td></tr><tr><td>PAYE (Tax)</td><td align="right">'.number_format($tta,2).'
	</td></tr><tr><td>Salary Advance</td><td align="right">'.number_format($tad,2).'</td></tr><tr><td>SACCO</td><td align="right">'
	.number_format($tsac,2).'</td></tr><tr><td>Risk Fund</td><td align="right">'.number_format($tris,2).'</td></tr><tr><td>Other Deductions</td><td align="right">'
	.number_format($tod,2).'</td></tr><tr><td><b>Total Deductions</b></td><td align="right"><b>'.number_format($ttd,2).'</b></td></tr></table></td>';
	$html.='<td valign="middle" rowspan="3" align="left"  class="hide">Prepared By __________________________ On _________________<br>&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Bursar/ Acc. Clerk<br><br><br>Approved By __________________________ On 
	_________________<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Principal/ Director</td></tr><tr><td 
	align="right" class="hide" colspan="2">Total Net Salary '.number_format($tnet,2).'</td></tr></table>';
	$html.='</body></html>';
	$mpdf->WriteHTML($html);
	$mpdf->Output();
	mysqli_close($conn);
?>