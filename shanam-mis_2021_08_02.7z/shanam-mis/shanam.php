<?php //Start off work
session_start();if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
function headings($txt,$a,$b,$ch){echo '<!DOCTYPE html><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>Accounts MIS</title><meta
name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes"><link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">'.
($ch!=10?'<link rel="stylesheet" type="text/css" href="tpl/css/'.($ch==0?'mainoptions':($ch==1?'datainput':($ch==2?'hightlight':'print'))).'.css"/>':'<style>BODY
{font-family:Tahoma,Times, serif;font-size:0.8rem;text-decoration:none;font-variant:normal;background: url(../gen_img/ara.jpg) no-repeat;background-size: cover;}</style>').
'<link rel="shortcut icon"  href="/gen_img/phone.ico"/>';echo $txt.'</head><body onload="actiondone('.$a.','.$b.')">';
}function footer(){echo '<script src="/bootstrap/jquery/jquery-3.2.1.slim.min.js"></script></script><script src="/bootstrap/jquery/popper.min.js"></script>
  <script src="/bootstrap/js/bootstrap.min.js"></script><script type="text/javascript" src="tpl/js/actionmessage.js"></script></body></html>';
  /*echo '<script type="text/javascript">(function () { var ID = "tooltip", CLS_ON = "tooltip_ON", FOLLOW = true, DATA = "_tooltip", OFFSET_X =10, OFFSET_Y=10,
    showAt = function (e) {var ntop = e.pageY + OFFSET_Y, nleft = e.pageX + OFFSET_X;$("#" + ID).html($(e.target).data(DATA)).css({position: "absolute", top: ntop, left: nleft}).show();};
    $(document).on("mouseenter", "*[title]", function (e) {$(this).data(DATA, $(this).attr("title"));$(this).removeAttr("title").addClass(CLS_ON);$("<div id=\'" + ID +
    "\' style=\"background-color:#51adcf;color:#fff;margin:2px;border-radius:4px;\"/>").appendTo("body");showAt(e);});
    $(document).on("mouseleave", "." + CLS_ON, function (e) {$(this).attr("title", $(this).data(DATA)).removeClass(CLS_ON); $("#" + ID).remove();});
    if (FOLLOW) { $(document).on("mousemove", "." + CLS_ON, showAt); }}()); </script>';*/
}
?>
