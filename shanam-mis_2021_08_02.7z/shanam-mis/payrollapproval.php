<?php
    session_start();
    include_once('../conn/pri_sch_connect.inc');
    $data=strtoupper(strip_tags(trim($_REQUEST['rec']))); $data=preg_split('/\-/',$data);	//[0]-0 Confirm, 1 Approve, 2 Unapprove and [1] salary number
    if ($data[0]==0){//Confirm salary
        mysqli_query($conn,"UPDATE acc_salaries SET checkstatus=1 WHERE salno LIKE '$data[1]'");
        $recs=mysqli_affected_rows($conn); $act=1;
    }elseif ($data[0]==1){// Approve salary
        mysqli_multi_query($conn,"UPDATE acc_salaries SET approvestatus=1 WHERE salno LIKE '$data[1]'; SELECT s.salno,sum(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+"
        . "sp.responsallow1+sp.empnssf) as sal,sum(sp.empnssf+sp.nssffee1) as nssf, sum(sp.nhiffee1) as nhif, sum(sp.paye1-sp.mpr1) as paye, sum(sp.welfare1) as welf,sum(sp.otherlevies1) "
        . "as ole, sum(sp.union1) as Uni, sum(sp.sacco1) as sacco,sum(sp.helb1) as helb, sum(sp.advance) as adv, concat(s.sal_month,'-',s.sal_year) as mon,s.acsno,s.acc,s.voteno FROM "
        . "acc_salaries s Inner Join acc_salpyt sp USING (salno) GROUP BY s.SalNo,sp.markdel,s.Sal_Month,s.Sal_Year HAVING sp.Markdel=0 and s.salno LIKE '$data[1]'; SELECT max(vono) as vn "
        . "FROm acc_exp GROUP BY acc HAVING acc LIKE '$data[2]'; SELECT sno FROM acc_votes WHERE acc='$data[2]' and abbr LIKE 'nssf'; SELECT stud_assoc,govt_assoc FROM acc_voteacs WHERE "
        . "acno LIKE '$data[2]'; SELECT schtype FROM ss;"); $schtype=$studassoc=$fseassoc=$VNo=$salVote=$i=0;
        do{
           if($i==0) $recs=mysqli_affected_rows($conn);
           else{
               if($rs=mysqli_store_result($conn)){
                    if($i==1) {list($salno,$bsal,$nssf,$nhif,$paye,$welf,$ole,$union,$sacc,$helb,$adv,$mon,$acsno,$acc,$vote)=mysqli_fetch_row($rs);}
                    elseif($i==2) {if (mysqli_num_rows($rs)>0)list($VNo)=mysqli_fetch_row($rs);}
                    elseif($i==3) {if (mysqli_num_rows($rs)>0)list($salvote)=mysqli_fetch_row($rs);}
                    elseif($i==4)  {if (mysqli_num_rows($rs)>0)list($studassoc,$fseassoc)=mysqli_fetch_row($rs);}
                    else {if (mysqli_num_rows($rs)>0)list($schtype)=mysqli_fetch_row($rs);}
                    mysqli_free_result($rs);
               }
           }  $i++;
        }while(mysqli_next_result($conn));  $user=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';    $VNo++; $amt=$bsal-$adv;
        $sql="INSERT INTO acc_banking(sno,transdate,bank_type,acsno,amt,transtype,transno,rmks,addedby) VALUES (0,curdate(),1,$acsno,$bsal,2,$salno,'$mon BoM Staff Salary','$user');".
        "INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES (0,$acc,0,curdate(),'$mon BoM Staff Salary',$amt,4,$salno,'$user'), (0,$acc,1,curdate(),"
        . "'$mon BoM Staff Salary',$bsal,4,$salno,'$user'); INSERT INTO acc_exp (vono,acsno,expno,salno,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,commt,addedby) VALUES($VNo,$acsno,1,
        $salno,curdate(),$acc, 'Cash',null,$bsal,0,'$mon BoM Staff Salary',3,'$user'); INSERT INTO acc_pytvotes(vono, acc,voteno,amt,pytdate,markdel) VALUES ($VNo,$acc,$vote,$bsal,Now(),0);";
        mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". 1. Click <a href=\"payroll.php\">HERE</a> to try again.");    while(mysqli_next_result($conn)){}
        $VNo++;     $sqlinco=$sql=$table="";
        //Work with income, studassoc && fseassoc
        $amt=$nssf+$nhif+$paye+$welf+$ole+$union+$sacc+$helb+$adv;
        if ($studassoc==1){
            mysqli_query($conn,"INSERT INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,commt,verdate,verstate,verbanked) VALUES (0,'Sal-$salno',curdate(),'Salary','Cash',null,3,"
            . "curdate(),1,0);") or die(mysqli_error($conn).". 2. Click <a href=\"payroll.php\">HERE</a> to try again."); $i=$rsno=0;
            $rsno=mysqli_insert_id($conn);
            mysqli_multi_query($conn,"INSERT INTO acc_incorecno0(recno,recon,sno,acc,amt) VALUES (0,curdate(),$rsno,$acc,$amt); SELECT last_insert_id();") or die(mysqli_error($conn).". 3. Click "
            . "<a href=\"payroll.php\">HERE</a> to try again."); $i=$recno=0;
            do{
                if($i==0);
                else {
                   if($rs=mysqli_store_result($conn)){list($recno)=mysqli_fetch_row($rs); mysqli_free_result($rs);}
                }$i++;
            }while(mysqli_next_result($conn)); $table="acc_incovotes";
        }else{ //FSE ACCOUNT
            mysqli_query($conn,"INSERT INTO acc_fseincome(recno,noofstud,recon,batchno,acc,acsno,amt,commt,mode,modeno,verdate,verstate,verbanked,rmks) VALUES (0,1,curdate(),1,$acc,null,"
            . "$amt,3,'Cash',null,curdate(),1,0,'Staff Salary');") or die(mysqli_error($conn).". 4. Click <a href=\"payroll.php\">HERE</a> to try again."); $i=$recno=0;
            $rsno=mysqli_insert_id($conn); $table="acc_fsevotes";
        }$rs=mysqli_query($conn,"SELECT sno FROM acc_votes WHERE acc='$acc' and sno>=$salvote ORDER BY sno LIMIT 0,9"); $i=$incount=$expcount=0;
        $sqlinco="INSERT INTO $table(recno,acc,voteno,amt) VALUES "; $sqlexp="INSERT INTO acc_exp (vono,acsno,expno,salno,pytdate,acc,pytfrm,cheno,chamt,rmks,commt,addedby) VALUES ";
        $sqlpyt="INSERT INTO acc_pytvotes(vono,acc,voteno,amt,pytdate,markdel) VALUES ";
        while(list($sno)=mysqli_fetch_row($rs)){
            switch ($i){
                case 0: $amt=$nssf;     $expno=2;   $det='NSSF';    break;
                case 1: $amt=$nhif;     $expno=3;   $det='NHIF';    break;
                case 2: $amt=$paye;     $expno=4;   $det='PAYE tax';    break;
                case 3: $amt=$welf;     $expno=5;   $det='Welfare';    break;
                case 4: $amt=$ole;      $expno=6;   $det=($schtype==0?'Rent':'Other Deductions'); break;
                case 5: $amt=$union;    $expno=7;   $det=($schtype==0?'Elimu':'Union Dues'); break;
                case 6: $amt=$sacc;     $expno=8;   $det=($schtype==0?'KDS':'SACCO'); break;
                case 7: $amt=$helb;     $expno=9;   $det='HELB';       break;
                default: $amt=$adv;     $expno=10;  $det='ADVANCE';    break;
            }
            if($amt>0){
                if($i!=8 || ($schtype==0 && $i!=4)){
                    $sqlexp.=($expcount==0?"":",")."($VNo,$acsno,$expno,$salno,curdate(),$acc, 'Cheque','0000',$amt,'$mon $det Salary Remmittence',3,'$user')";
                    $sqlpyt.=($expcount==0?"":",")."($VNo,$acc,$sno,$amt,now(),0)"; $expcount++; $VNo++;
                }
                $sqlinco.=($incount==0?"":",")."($recno,$acc,$sno,$amt)";   $incount++;
            }$i++;
        }
        $sql="$sqlexp;$sqlpyt;$sqlinco;INSERT INTO acc_salppcheques SELECT sp.salno,(left(sp.paypoint,(locate('-',sp.paypoint)-1))) As PP,count(sp.salno) as nos,curdate(),'0000' as ch,
        sum((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1+sp.empnssf)-(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.welfare1+sp.otherlevies1+
        sp.union1+sp.empnssf+sp.sacco1+sp.nssfvol1+sp.helb1)) AS NetSalary FROM acc_salpyt sp GROUP BY sp.salno,(left(sp.paypoint,(locate('-',sp.paypoint)-1))) HAVING sp.salno LIKE
        '$salno'; $sqlinco;  UPDATE acc_salaries SET recno=$recno WHERE salno LIKE '$salno';";
        mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"payroll.php\">HERE</a> to try again.");    while(mysqli_next_result($conn)){}
        $recs=1; $act=1;
    }else{
        mysqli_multi_query($conn,"UPDATE acc_salaries SET approvestatus=0 WHERE salno LIKE '$data[1]'; SELECT acc, recno FROM acc_salaries WHERE salno LIKE '$data[1]';")  or
        die(mysqli_error($conn).". 1. Click <a href=\"payroll.php\">HERE</a> to try again.");$i=0;
        do{
          if($i==0){
              $recs=mysqli_affected_rows($conn); $act=1;
          } else{if($rs=mysqli_store_result($conn)){list($acc,$recno)=mysqli_fetch_row($rs); mysqli_free_result($rs);}} $i++;
        }while(mysqli_next_result($conn));
        if($acc==1){
            $sql="DELETE FROM acc_incovotes WHERE recno LIKE '$recno'; UPDATE acc_incofee SET markdel=1, delreason='Cancellation of salary approval' WHERE sno IN (SELECT sno FROM
            acc_incorecno0 WHERE recno LIKE '$recno'); UPDATE acc_incorecno0 SET markdel=1 WHERE recno LIKE '$recno';";
        }else{
           $sql="DELETE FROM acc_fsevotes WHERE recno LIKE '$recno'; UPDATE acc_fseincome SET markdel=1, delreason='Cancellation of salary approval' WHERE recno LIKE '$recno';";
        }$sql.="DELETE FROM acc_pytvotes WHERE acc LIKE '$acc' and vono IN (SELECT vono FROM acc_exp WHERE salno LIKE '$data[1]' and acc LIKE '$acc'); UPDATE acc_exp SET markdel=1,
        delreason='Cancellation of salary approval' WHERE salno LIKE '$data[1]' and acc LIKE '$acc'; DELETE FROM acc_salppcheques WHERE salno LIKE '$data[1]'; DELETE FROM acc_banking
        WHERE transtype=2 and transno LIKE '$data[1]'; DELETE FROM acc_cashflow WHERE transtype=4 and transno LIKE '$data[1]';";
        mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". 2. Click <a href=\"payroll.php\">HERE</a> to try again.");    while(mysqli_next_result($conn)){}
    }mysqli_close($conn); header("location:payroll.php?action=$act-$recs");
?>
