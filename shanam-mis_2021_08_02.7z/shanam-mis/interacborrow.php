<?php
	include_once('shanam.php');
	if(isset($_POST['btnBankings'])){header("location:interacborrowadd.php?action=0-0"); exit(0);}
	$rs=mysqli_query($conn,"SELECT borroadd,borroedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$add=0; $edit=0; if (mysqli_num_rows($rs)>0) list($add,$edit)=mysqli_fetch_row($rs); mysqli_free_result($rs);
	$sda=isset($_REQUEST['txtFrom'])?$_REQUEST['txtFrom']:date('Y')."-01-01";	$eda= isset($_REQUEST['txtTo'])?$_REQUEST['txtTo']:date("d-m-Y");
	$sda=preg_split('/\-/',$sda); $eda=preg_split('/\-/',$eda);		$sda="$sda[2]-$sda[1]-$sda[0]";	$eda="$eda[2]-$eda[1]-$eda[0]";
	$action=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; 	$action=preg_split('/\-/',$action);
	headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css" /><link href="tpl/css/headers.css" rel="stylesheet" type="text/css" />',$action[0],$action[1],2);
?><div class="head"><form method="post" action="interacborrow.php" name="frmFind"><a href="withdrawborrow.php"><img src="/gen_img/ani_back.gif" hspace="1" width="45" height="20"
align="left"></a>Inter Account Fund Transfers Made Between <input name="txtFrom" class="tcal" type="text" value="<?php echo date("d-m-Y",strtotime($sda));?>" readonly size="9">
and  <input name="txtTo" class="tcal" type="text" value="<?php echo date("d-m-Y",strtotime($eda));?>" readonly size="9">&nbsp;&nbsp;<button type="submit" accesskey="s"
name="Show">Show Fund Transfers</button>&nbsp;&nbsp;<button type="submit" accesskey="b" name="btnBankings" <?php echo ($add==0?"disabled":"");?>">New Inter Account Transfer
</button></form></div><br>
<div class="container" style="width:fit-content;margin:0 auto;background-color:#e6e6e6;border-radius:15px;"><div class="form-row"><div class="col-md-12">
<?php
	$h="Inter Account Fund Transfers Made Between <font color=\"#0000ff\">".date("D d-M-Y",strtotime($sda))."</font> and <font color=\"#0000ff\">".date("D d-M-Y",strtotime($eda)).
	"</font>";
	$rs=mysqli_query($conn,"SELECT i.interb_no,i.interb_date,i.recieptno,i.voucherno,i.sourceac,i.destac,i.mode,i.modeno,concat(v.abbr,' - A/C NO. ',a.accno,'<br>(',ba.abbr, ' - ',
	a.branch,')') as debtac,d.dest as destac,i.amt,i.rmks FROM acc_interacborrow i inner join acc_accounts a On (i.sourceac=a.sno) Inner JOIN acc_voteacs v ON (i.debitacno=v.acno)
	Inner Join acc_banks ba On (a.bankno=ba.sno) Inner Join (SELECT b.interb_no,concat(v.abbr,' - A/C NO. ',a.accno,'<br>(',ba.abbr, ' - ',a.branch,')') as dest FROM acc_interacborrow b
	inner join acc_accounts a On 	(b.destac=a.sno) Inner JOIN acc_voteacs v ON (b.creditacno=v.acno) Inner Join acc_banks ba On (a.bankno=ba.sno))d On (i.interb_no=d.interb_no) WHERE
	(i.interb_date BETWEEN '$sda' and '$eda') and i.markdel=0 ORDER BY i.interb_no ASC");
	$nor=mysqli_num_rows($rs);
	print "<center><h6>".strtoupper($h)."</h6></center>";
	//Show data
	print "<table class=\"table table-striped table-hover table-sm table-bordered\"><thead class=\"thead-dark\"><tr style=\"font-weight:bold;letter-spacing:2px;
	word-spacing:4px;\"><th colspan=\"6\">INTER ACCOUNT BORROWING DETAILS</th><th colspan=\"2\">DETAILS OF AFFECTED ACCOUNTS</th><th rowspan=\"2\">Amount<br>(Kshs.)</th><th
	colspan=\"2\">ADMIN ACTIONS</th></tr><tr><th>PV No.</th><th>Receipt<br>No.</th><th>Borrowed On</th><th>Mode</th><th>Mode<br>No.</th><th>Narration</th><th>Debited Account</th>
	<th>Credited Account</th><th>Print</th><th>Edit</th></tr></thead>";
	$i=1; $ttl=0;
	if ($nor>0){
		while (list($ino,$idat,$rno,$vno,$sac,$dac,$mode,$modeno,$debt,$credit,$amt,$rmks)=mysqli_fetch_row($rs)):
			print "<tr><td>$vno</td><td>$rno</td><td align=\"right\">".date("d M, Y",strtotime($idat))."</td><td>$mode</td><td>$modeno</td><td>$rmks</td><td>$debt</td><td>$credit</td>
			<td align=\"right\">".number_format($amt,2)."</td><td align=\"center\"><a href=\"rpts/interacborrowreceipt.php?recno=$rno-1-$dac-$sac-0\">Receipt</a><br><a
			href=\"rpts/interacborrowreceipt.php?recno=0-1-$dac-$sac-$vno\">Voucher</a></td><td align=\"center\"><a href=\"interacborrowedit.php?rec=$ino\" onclick=\"return canEdit($edit)\">
			Edit</a></td></tr>";	$ttl+=$amt; 	$i++;
		endwhile;
	}else{
		print "<tr><td colspan=\"11\"><br>No inter-account fund transfers were made between ".date("D d-M-Y",strtotime($sda))." and ".date("D d-M-Y", strtotime($eda))."</td>
		</tr>";
	}
	print "<tr style=\"background-color:#eaa;font-weight:bold;\"><td colspan=\"6\" align=\"left\">$nor Inter A/C Fund Transfer Record(s)</b></td><td colspan=\"2\" align=\"right\"><b>
	Total Funds Transfered in Kshs.</b></td><td align=\"right\">".number_format($ttl,2)."</td><td colspan=\"2\"></td></tr></tr></table>";
?><script type="text/javascript" src="/date/tcal.js"></script>
<?php mysqli_close($conn); footer();?>
