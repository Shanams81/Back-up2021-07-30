<?php
    if (isset($_POST['FeeStatement'])) header("location:studfee.php");
    include_once('shanam.php'); if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php");
    $action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
    mysqli_multi_query($conn,"SELECT finyr FROM ss; SELECT studadd,studdel,studedit FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT DISTINCT curr_year FROM class ORDER BY
    curr_year Desc; SELECT clsno,clsname FROM classnames ORDER BY clsno ASC; SELECT strm FROM grps WHERE strm is not null;");
    $fr=isset($_REQUEST['CboForm'])?strip_tags($_REQUEST['CboForm']):"%";     $st=isset($_REQUEST['CboStream'])?strip_tags($_REQUEST['CboStream']):"%";
    $adno=isset($_REQUEST['TxtAdmNo'])?strip_tags($_REQUEST['TxtAdmNo']):"%"; $finyr=isset($_REQUEST['CboYear'])?strip_tags($_REQUEST['CboYear']): date('Y');
    $find=isset($_REQUEST['OptFind'])?$_REQUEST['OptFind']:"stud_names";      $i=$canadd=$candel=$canedit=0; $optyr=$optcls=$optstrm='';
    do{
        if($rs=mysqli_store_result($conn)){
          if($i==0){if(mysqli_num_rows($rs)>0) list($yr)=mysqli_fetch_row($rs); else $yr=date('Y');}
          elseif($i==1) list($canadd,$candel,$canedit)=mysqli_fetch_row($rs);
          elseif($i==2){if(mysqli_num_rows($rs)>=1) while (list($ye)=mysqli_fetch_row($rs)) $optyr.="<option ".($ye==$finyr?"selected":"").">".$ye."</option>";
          }elseif($i==3){if(mysqli_num_rows($rs)>0) while (list($cln,$nam)=mysqli_fetch_row($rs)) $optcls.="<option ".(strcasecmp($fr,$cln)==0?"Selected":"")." value=\"$cln\">$nam</option>";
          }else{if (mysqli_num_rows($rs)>0) while (list($strm)=mysqli_fetch_row($rs)) $optstrm.="<option value=\"$strm\">".$strm."</option>";} mysqli_free_result($rs);
        } $i++;
    }while(mysqli_next_result($conn));
    headings('<link href="tpl/css/headers.css" rel="stylesheet" />',$action[0],$action[1],2);
?>
<div class="head"><form method="post" action="deleted_pupil.php"><a href="deletedrecords.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;
<Label for="CboY">Alumni/ Students In </label><SELECT id="CboY" name="CboYear" size="1"><?php echo $optyr;?></select>&nbsp;&nbsp;<label for="form">In Class</label>&nbsp;&nbsp;<select
name="CboForm" size="1" id="form"><?php echo $optcls;?></select> - <select name="CboStream" size="1" id ="stream"><option selected value="%">All</option><?php echo $optstrm;?></select>
&nbsp; Or Find By:&nbsp;<input type="radio" name="OptFind" value="admno">Adm. No.&nbsp;<input type="radio" name="OptFind" value="stud_names" checked>Names&nbsp; <input type="text"
maxlength="17" size="15" name="TxtAdmNo" id="adno" value="%">&nbsp;&nbsp;&nbsp;<button type="submit" name="Stud">Show Students</button></form></div>
<div class="container" style="background-color:#e6e6e6;border:0.5px groove #007;width:fit-content;margin:10px auto;border-radius:15px 15px 0 0;padding:0 5px;"><h4>LIST OF DELETED
STUDENTS</h4>
<?php $adno=strlen(trim($adno))>0 ? $adno : "%"; $yr=date('Y');
  if (strcasecmp($adno,"%")==0){ $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',sf.stream,'-',sf.curr_year) As frm,s.admdate,s.telno,sf.bbf,
    sf.miscbf,sf.spemed,s.curr_year FROM stud s Inner Join class sf USING (admno) INNER JOIN classnames cn USING (clsno) WHERE ((s.markdel=1 or s.type=1 or s.present=0)
    and sf.curr_year='$finyr' and sf.`clsno` LIKE '$fr' and sf.`stream` LIKE '$st') Order By s.surname,s.onames Asc";
  }else{
    if (strcasecmp($find,"stud_names")==0) $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',sf.stream,'-',sf.curr_year) As frm,s.admdate,s.telno,
    sf.bbf,sf.miscbf,sf.spemed,s.curr_year FROM stud s Inner Join class sf USING (admno) INNER JOIN classnames cn USING (clsno) WHERE ((s.markdel=1 or s.type=1 or s.present=0) and
    sf.curr_year LIKE '$finyr' and (s.surname LIKE '%$adno%' OR s.onames LIKE '%$adno%')) Order By s.surname,s.onames Asc";
    else $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',sf.stream,'-',sf.curr_year) As frm,s.admdate,s.telno,sf.bbf,sf.miscbf,sf.spemed,
    s.curr_year FROM stud s Inner Join class sf USING (admno) INNER JOIN classnames cn USING (clsno) WHERE ((s.markdel=1 or s.type=1 or s.present=0) and sf.curr_year LIKE '$finyr'
    and s.`admno` LIKE '$adno')";
  } $rsStud=mysqli_query($conn,$sql);
  print "<table class=\"table table-striped table-sm table-hover\"><thead class=\"thead-dark\"><tr align=\"middle\"><th colspan=\"5\">STUDENT DETAILS</th><th colspan=\"3\">FEE ARREARS
  &amp; SURCHARGED  MEDICAL</th><th colspan=\"2\">Admin Actions</th></tr><tr><th>Adm. No.</th><th>Names</th><th>Form</th><th>Admitted On</th><th>Tel. No.</th><th>Main Fee</th><th>Misc.
  Fee</th><TH>S/Medical</th><th>Restore</th><th>Re-Admit</th></tr></thead><tbody>"; $ttl=[0,0,0]; $tm=$i=0;
  if (mysqli_num_rows($rsStud)>0):
      while ($rsS=mysqli_fetch_row($rsStud)):
          print "<tr>"; $a=$stu=$alu=$pres=1;
          foreach($rsS as $sr){
              if ($a<6){if($a==1) $admno=$sr; if($i==4) print "<td>".date("D, d-F-Y",strtotime($sr))."</td>"; else print "<td>".$sr."</td>";
              }else{if($a<9){print "<td align=\"right\">".number_format($sr,2)."</td>";if($a==6) $ttl[0]+=$sr;elseif ($a==7) $ttl[1]+=$sr; else $ttl[2]+=$sr;}else $yr=$sr;}$a++;
          } print "<td align=\"center\">".(($finyr==$yr)?"<a href=\"studundel.php?admno=$admno-$finyr-1\">Restore</a>":"")."</td><td align=\"center\">".(($finyr!=$yr)?"<a
          href=\"studundel.php?admno=$admno-$finyr-2\">Re-Admit</a>":"")."</td></tr>"; $i++;
      endwhile;
  endif;
  print "</tbody><tfoot><tr bgcolor=\"#eeaaaa\"><td colspan=\"3\" align=\"left\" class=\"b\">".mysqli_num_rows($rsStud)." Student(s)' Records</td><td colspan=\"2\" align=\"right\" class=\"b\">
  Arrears Subtotals (Kshs.)</td><td align=\"right\" class=\"b\">".number_format($ttl[0],2)."</td><td align=\"right\">".number_format($ttl[1],2)."</td><td align=\"right\">".number_format($ttl[2],
  2)."</td><td colspan=\"2\"></td></tr></tfoot></table>";	mysqli_free_result($rsStud);
  print "Report Generated on ".date("l F d, Y")."</div>";
  mysqli_close($conn);    footer();
?>
