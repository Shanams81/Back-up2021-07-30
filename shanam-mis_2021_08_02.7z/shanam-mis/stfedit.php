<?php
	include_once('shanam.php');
	if ($_SERVER["REQUEST_METHOD"]==="POST"):
		$orig=isset($_POST['txtOrig'])?sanitize($_POST['txtOrig']):0; 	$idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):Null;
		$dob=$_POST['cboYr']."-".$_POST['cboMon']."-".$_POST['cboDays'];
		$surname=isset($_POST['txtSurname'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtSurname']))):'';
		$onames=isset($_POST['txtONames'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtONames']))):'';
		$gender=isset($_POST['cboGender'])?strtoupper(sanitize($_POST['cboGender'])):'FEMALE';	$empon=isset($_POST['txtEmpOn'])?sanitize($_POST['txtEmpOn']):date('d-m-Y');
		$empon=preg_split("/\-/",$empon);	$address=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):Null;
		$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):Null; 	$const=isset($_POST['cboConst'])?sanitize($_POST['cboConst']):0;
		$county=isset($_POST['cboCounty'])?sanitize($_POST['cboCounty']):0;		$ward=isset($_POST['cboWard'])?sanitize($_POST['cboWard']):0;
		$email=isset($_POST['txtEMail'])?sanitize($_POST['txtEMail']):Null;		$desig=isset($_POST['cboDesignation'])?strtoupper(sanitize($_POST['cboDesignation'])):'TEACHER';
		$stfgrp=isset($_POST['cboStfGrp'])?strtoupper(sanitize($_POST['cboStfGrp'])):'TEACHING STAFF';	$jg=isset($_POST['cboJG'])?sanitize($_POST['cboJG']):0;
		$terms=isset($_POST['cboTerms'])?strtoupper(sanitize($_POST['cboTerms'])):'PERMANENT';		$status=isset($_POST['chkStatus'])?sanitize($_POST['chkStatus']):0;
		$subloc=isset($_POST['txtSubLocation'])?strtoupper(sanitize($_POST['txtSubLocation'])):'';	$village=isset($_POST['txtVillage'])?strtoupper(sanitize($_POST['txtVillage'])):'';
		$employer=isset($_POST['cboEmployer'])?strtoupper(sanitize($_POST['cboEmployer'])):'BoG';	$un=$_SESSION['username']." (".$_SESSION['priviledge'].")"; $regdon=date("Y-m-d H:n:s");
		$illness=isset($_POST['txtIllness'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtIllness']))):null;
		$allergy=isset($_POST['txtAllergy'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAllergy']))):null;
		$pwdrmks=isset($_POST['txtPWDRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPWDRmks']))):null;
		$kra=isset($_POST['txtKRA'])?strtoupper(sanitize($_POST['txtKRA'])):null;	$pwd=isset($_POST['chkPWD'])?sanitize($_POST['chkPWD']):0;
		if(strlen($surname)<3||strlen($onames)<5||strlen($idno)<6||strlen($subloc)<4||strlen($village)<4||strlen($county)<3||strlen($const)<3||strlen($ward)<4){
			print "SERVER ERROR <font color=\"#cc0000\">Ensure staff member's ID No, names and residence fields are validly entered before saving</font><br>";
			exit(0);
		}else{
			mysqli_query($conn,"UPDATE stf SET idno=".var_export($idno,true).",surname=".var_export($surname,true).",onames=".var_export($onames,true).",address=".var_export($address,true).
			",telno=".var_export($telno,true).",email=".var_export($email,true).",countyNo='$county',ConstituencyNo='$const',wardno='$ward',designation='$desig',gender='$gender',
			staffgrp='$stfgrp',dob='$dob',pin=".var_export($pin,true).",present='$status',st_type=".var_export($terms,true).",empdate='$empon[2]-$empon[1]-$empon[0]',jg='$jg',
			markdel=".($status==1?0:1).",allergy=".var_export($allergy,true).",illness=".var_export($illness,true).",sublocation=".var_export($subloc,true).",village=".var_export($village,
			true)." WHERE idno LIKE '$orig'") or die(mysqli_error($conn)." Staff record not saved. Click <a href=\"stf.php\">Here</a> to go back.");
			$i=mysqli_affected_rows($conn);
			header("location:stf.php?action=1-$i");	exit(0);
		}
	else:
		$idn=isset($_REQUEST['idno'])?sanitize($_REQUEST['idno']):'0';
		mysqli_multi_query($conn,"SELECT idno,surname,onames,address,telno,email,Employer,countyNo,ConstituencyNo,wardno,designation,gender,staffgrp,dob,pin,present,st_type,jg,empdate,pwd,
		pwdrmks,sublocation,village,illness,allergy FROM stf WHERE idno LIKE '$idn'; SELECT staff FROM grps WHERE staff is not null ORDER BY staff ASC; SELECT code,name FROM county ORDER
		BY name ASC; SELECT code,name,codecounty FROM constituency ORDER BY codecounty,name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC; SELECT code,name,codeconst
		FROM ward ORDER BY codeconst,name ASC;");
		$optCounty=$optGrp=$optMP=$optMCA='';	$i=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0) list($idno,$surname,$onames,$add,$tel,$ema,$emp,$county,$const,$ward,$desig,$gend,$stfgrp,$dob,$krapin,$present,$type,$jg,$empdate,$pwd,$pwdrmks,$sloc,$vill,
				$illn,$alle)=mysqli_fetch_row($rs);
				elseif($i==1) while($r=mysqli_fetch_row($rs)) $optGrp.="<option ".(strcasecmp($r[0],$stfgrp)==0?"selected":"").">$r[0]</option>";
				elseif($i==2) while (list($s,$n)=mysqli_fetch_row($rs)) $optCounty.="<option ".($county==$s?"selected":"")." value=\"$s\">$n</option>";
				elseif($i==3){ $mp=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
					$mp.=($a==0?"":",")."new Consti(\"$s\",\"$n\",\"$c\")"; if($county==$c) $optMP.="<option ".($mp==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;
				}}else{ $mca=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
	   				$mca.=($a==0?"":",")."new MCA(\"$s\",\"$n\",\"$c\")"; if($const==$c) $optMCA.="<option ".($ward==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;
	  			}} 	mysqli_free_result($rs);
			} $i++;
		}while(mysqli_next_result($conn));	$dob=preg_split("/\-/",$dob);	$empdate=preg_split("/\-/",$empdate);
	endif;
	headings('<link rel="stylesheet" type="text/css" href="../date/tcal.css" />',0,0,1);
?><div class="w-50 p-3" style="background-color:#eee;margin:auto;border-radius:10px;padding:0px;"><form name="frmStf" id="frmStf" method="post" action="stfedit.php"
	onsubmit="return validateFormOnSubmit(this);"><input type="hidden" name="txtOrig" id="txtOrig" value="<?php echo $idno;?>">
<!-- Circles which indicates the steps of the form: -->
<div style="margin-top:2px;margin-bottom:2px;color:#aaf;font-size:10px;" class="form-row">
	<div class="col-md-6 mb-3" style="text-align:left;">Step <span id="spStep0" class="step active" style="color:#fff;font-weight:bold;text-align:center;">1</span></div>
	<div class="col-md-6 mb-3" style="text-align:right;">Step <span id="spStep1" class="step" style="color:#fff;font-weight:bold;text-align:center;">2</span></div>
</div>
<!-- One "tab" for each step in the form: -->
<div class="tab">
<H1>PERSONAL DETAILS FOR MEMBER OF STAFF</H1>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="txtIDNo">ID/Passport No. *</label>
      <input type="text" id="txtIDNo" placeholder="000000" value="<?php echo $idno; ?>" required name="txtIDNo" maxlength="10" onkeyup="checkData(0,this)">
    </div><div class="col-md-3 mb-3">
      <label for="cboGender">Gender *</label>
	    <select id="cboGender" name="cboGender">
	      <option value="Male" <?php echo strcasecmp($gend,'male')==0?'Selected':''; ?>>Male</option>
	      <option value="Female" <?php echo strcasecmp($gend,'female')==0?'Selected':''; ?>>Female</option>
	    </select>
    </div><div class="col-md-6 mb-3">
      <label for="cboYr">Date of Birth *</label>
      <div class="input-group">
        <SELECT name="cboYr" size="1" id="cboYr" onchange="filldays('CboDays')" style="width:20%;">
		<?php $a=(date('Y')-18); for($i=$a; $i>($a-60);$i--) print "<option ".($i==$dob[0]?"Selected":"").">$i</option>"; ?>
		</SELECT>-<SELECT name="cboMon" size="1" id="cboMon" onchange="filldays('cboDays')" style="width:45%;"><OPTION value="01" <?php echo ($dob[1]=="01"?"Selected":"");?>>January</OPTION>
		<OPTION value="02" <?php echo ($dob[1]=="02"?"Selected":"");?>>February</OPTION><OPTION value="03" <?php echo ($dob[1]=="03"?"Selected":"");?>>March</OPTION><OPTION value="04"
		<?php echo ($dob[1]=="04"?"Selected":"");?>>April</OPTION><OPTION value="05" <?php echo ($dob[1]=="05"?"Selected":"");?>>May</OPTION><OPTION value="06" <?php echo ($dob[1]=="06"?
		"Selected":"");?>>June</OPTION><OPTION value="07" <?php echo ($dob[1]=="07"?"Selected":"");?>>July</OPTION><OPTION value="08" <?php echo ($dob[1]=="08"?"Selected":"");?>>August
		</OPTION><OPTION value="09" <?php echo ($dob[1]=="09"?"Selected":"");?>>September</OPTION><OPTION value="10" <?php echo ($dob[1]==10?"Selected":"");?>>October</OPTION><OPTION
		value="11" <?php echo ($dob[1]==11?"Selected":"");?>>November</OPTION><OPTION value="12" <?php echo ($dob[1]==12?"Selected":"");?>>December</OPTION></SELECT>-<SELECT
		name="cboDays" style="width:20%;" size="1" id="cboDays">
		<?php $a=date('t',strtotime($a.'-01-01')); $b=date("d"); for($i=$a;$i>0;$i--) print "<option ".(($dob[2]==$i)?"selected":"").">$i</option>";?></SELECT>
      </div>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="txtSurname">Surname *</label>
      <input type="text" id="txtSurname" name="txtSurname" placeholder="Nama" required maxlength="12"  onkeyup="checkData(1,this)" value="<?php echo $surname;?>">
    </div><div class="col-md-9 mb-3">
      <label for="txtONames">Other Names *</label>
      <input type="text" name="txtONames" id="txtONames" placeholder="M. Shab" required maxlength="30" onkeyup="checkData(1,this)"  value="<?php echo $onames;?>">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="cboDesignation">Staff Designation *</label>
      <SELECT name="cboDesignation" id="cboDesignation" size="1" required><option <?php echo strcasecmp($desig,"Accounts Clerk")==0?"selected":"";?>>Accounts Clerk</Option><option
	  <?php echo strcasecmp($desig,"Boarding Master")==0?"selected":"";?>>Boarding Master</Option><option <?php echo strcasecmp($desig,"Boarding Mistress")==0?"selected":"";?>>Boarding
	  Mistress</Option><option <?php echo strcasecmp($desig,"Bursar")==0?"selected":"";?>>Bursar</Option><option <?php echo strcasecmp($desig,"cateress")==0?"selected":"";?>>Cateress</Option>
	  <option <?php echo strcasecmp($desig,"Caterer")==0?"selected":"";?>>Caterer</Option><option <?php echo strcasecmp($desig,"Cook")==0?"selected":"";?>>Cook</Option><option <?php
	  echo strcasecmp($desig,"Copy Typist")==0?"selected":"";?>>Copy Typist</Option><option <?php echo strcasecmp($desig,"Data Clerk")==0?"selected":"";?>>Data Clerk</Option><option <?php
	  echo strcasecmp($desig,"Deputy Principal")==0?"selected":"";?>>Deputy Principal</Option><option <?php echo strcasecmp($desig,"Director")==0?"selected":"";?>>Director</Option><option
	  <?php echo strcasecmp($desig,"Accounts Clerk")==0?"selected":"";?>>Driver</Option><option <?php echo strcasecmp($desig,"Farm Attendant")==0?"selected":"";?>>Farm Attendant</Option>
	  <option <?php echo strcasecmp($desig,"Groundsman")==0?"selected":"";?>>Groundsman</Option><option <?php echo strcasecmp($desig,"H . O . D")==0?"selected":"";?>>H . O . D</Option>
	  <option <?php echo strcasecmp($desig,"Kitchen Assistant")==0?"selected":"";?>>Kitchen Assistant</Option><option <?php echo strcasecmp($desig,"Lab Assistant")==0?"selected":"";?>>Lab
	  Assistant</Option><option <?php echo strcasecmp($desig,"Lab Technician")==0?"selected":"";?>>Lab Technician</Option><option <?php echo strcasecmp($desig,"Librarian")==0?"selected":"";
	  ?>>Librarian</Option><option <?php echo strcasecmp($desig,"Matron")==0?"selected":"";?>>Matron</Option><option <?php echo strcasecmp($desig,"Messenger")==0?"selected":"";?>>Messenger
	  </Option><option <?php echo strcasecmp($desig,"Nurse")==0?"selected":"";?>>Nurse</Option><option <?php echo strcasecmp($desig,"Principal")==0?"selected":"";?>>Principal</Option><option
	  <?php echo strcasecmp($desig,"Secretary")==0?"selected":"";?>>Secretary</Option><option <?php echo strcasecmp($desig,"Store Keeper")==0?"selected":"";?>>Store Keeper</Option><option
	  <?php echo strcasecmp($desig,"Teacher")==0?"selected":"";?>>Teacher</Option><option <?php echo strcasecmp($desig,"Watchman")==0?"selected":"";?>>Watchman</Option></SELECT>
    </div><div class="col-md-5 mb-3">
      <label for="cboStfGrp">Staff Group *</label>
      <SELECT name="cboStfGrp" id="cboStfGrp" size="1" required>
		<?php echo $optGrp; ?></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboJG">Job Group *</label>
      <SELECT name="cboJG" id="cboJG" size="1" required><option <?php echo strcasecmp($jg,"d")==0?"selected":"";?>>D</option><option <?php echo strcasecmp($jg,"e")==0?"selected":"";?>>E
	  </option><option <?php echo strcasecmp($jg,"f")==0?"selected":"";?>>F</option><option <?php echo strcasecmp($jg,"g")==0?"selected":"";?>>G</option><option <?php
	  echo strcasecmp($jg,"h")==0?"selected":"";?>>H</option><option <?php echo strcasecmp($jg,"j")==0?"selected":"";?>>J</option><option <?php echo strcasecmp($jg,"k")==0?"selected":"";?>>
	  K</option><option <?php echo strcasecmp($jg,"l")==0?"selected":"";?>>L</option><option <?php echo strcasecmp($jg,"m")==0?"selected":"";?>>M</option><option <?php echo strcasecmp($jg,
	  "n")==0?"selected":"";?>>N</option><option <?php echo strcasecmp($jg,"p")==0?"selected":"";?>>P</option><option <?php echo strcasecmp($jg,"q")==0?"selected":"";?>>Q</option><option
	  <?php echo strcasecmp($jg,"r")==0?"selected":"";?>>R</option><option <?php echo strcasecmp($jg,"s")==0?"selected":"";?>>S</option><option <?php echo strcasecmp($jg,"t")==0?"selected":
	  "";?>>T</option></Select>
    </div>
  </div>
  <div class="form-row">
  	<div class="col-md-3 mb-3" style="text-align:left;">
		<label for="chkPWD" style="font-size:10px;">Person With Disability?</label>
      	<INPUT type="checkbox" id="chkPWD" name="chkPWD" value="1" onclick="enablePWD(this)" title="Yes" <?php echo ($pwd==1?"checked":"");?>>
	</div><div class="col-md-9 mb-3">
      <label for="txtPWD">Form of Disability </label>
      <INPUT type="text" name="txtPWD" id="txtPWD" readonly value="<?php echo $pwdrmks;?>" placeholder="Person with Visual Impairment" maxlength="100" onkeyup="checkData(1,this)">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="txtEmpOn">KRA PIN NO.</label>
      <INPUT type="text" name="txtKRA" name="txtKRA" maxlength="14" value="<?php echo $krapin;?>" placeholder="A00000000Z" onkeyup="checkData(1,this)">
    </div><div class="col-md-3 mb-3">
      <label for="txtEmpOn">Employed On</label>
      <INPUT type="text" name="txtEmpOn" name="txtEmpOn" class="tcal" readonly <?php print "value=\"".date("d-m-Y",strtotime($empdate[2]."-".$empdate[1]."-".$empdate[0]))."\""; ?>>
    </div><div class="col-md-4 mb-3">
	  <label for="chkStatus">Present at Work ? *</label>
      <INPUT type="checkbox" id="chkStatus" name="chkStatus" value="1" <?php echo ($present==1?"checked":"");?> title="Yes">
	</div><div class="col-md-2 mb-3">
    </div>
   </div><div class="form-row"><div class="col-md-12 mb-3"><hr style="border:0.5px dotted blue;background-color:#5af;"/></div></div>
</div>
<!-- One "tab" for each step in the form: -->
<div class="tab">
  <H1>CONTACT ADDRESSES AND OTHER DETAILS</H1>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="txtTelNo">Mobile/ Tel. No. *</label>
      <input type="text" id="txtTelNo" name="txtTelNo" placeholder="+25470" required maxlength="14" onkeyup="checkData(0,this)" value="<?php echo $tel;?>">
    </div><div class="col-md-8 mb-3">
      <label for="txtAddress">Postal Address * </label>
      <input type="text" id="txtAddress" name="txtAddress" placeholder="P.O BOX " required value="<?php echo $add;?>" maxlength="30" required  onkeyup="checkData(1,this)">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="txtEMail">E-Mail Address</label>
      <input type="text" id="txtEMail" name="txtEMail" placeholder="someone@website.com" style="text-transform:lowercase;" maxlength="25" value="<?php echo $ema;?>">
    </div><div class="col-md-4 mb-3">
      <label for="cboTerms">Form of Employment *</label>
      <SELECT name="cboTerms" id="cboTerms" size="1" required><option <?php echo strcasecmp($type,"permanent")==0?"selected":"";?>>Permanent</option><Option <?php echo strcasecmp($type,
	  "temporary")==0?"selected":"";?>>Temporary</option><Option <?php echo strcasecmp($type,"casual")==0?"selected":"";?>>Casual</option></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboEmployer">Employer *</label>
      <SELECT name="cboEmployer" id="cboEmployer" size="1" required><option <?php echo strcasecmp($type,"permanent")==0?"selected":"";?>>BOM</option><Option>TSC</option></SELECT>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="cboCounty">Home County *</label>
      <SELECT name="cboCounty" id="cboCounty" size="1" required onChange="loadConstituency(this)"><?php echo $optCounty; ?></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboConst">Constituency *</label>
      <SELECT name="cboConst" id="cboConst" size="1" onChange="loadWards(this)" required><?php echo $optMP; ?></SELECT>
    </div><div class="col-md-4 mb-3">
      <label for="cboWard">County Ward *</label>
      <SELECT name="cboWard" id="cboWard" size="1" required><?php echo $optMCA; ?></SELECT>
    </div>
  </div>
  <div class="form-row">
	<div class="col-md-6 mb-3">
      <label for="txtSubLocation">Sub-Location *</label>
      <input type="text" id="txtSubLocation" name="txtSubLocation" placeholder="Bulimbo" required value="<?php echo $sloc; ?>" maxlength="30" onkeyup="checkData(1,this)">
    </div><div class="col-md-6 mb-3">
      <label for="txtVillage">Village/ Town</label>
      <input type="text" id="txtVillage" name="txtVillage" placeholder="Lukusi" value="<?php echo $vill; ?>" maxlength="30" onkeyup="checkData(1,this)">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="txtIllness">Historical Illness *</label>
      <textarea id="txtIllness" name="txtIllness" placeholder="Historical Illnesses" rows=3 maxlength=150 onkeyup="checkData(1,this)"><?php echo $illn; ?></textarea>
    </div>
   <div class="col-md-6 mb-3">
      <label for="txtAllergy">Historical Allergies *</label>
      <textarea id="txtAllergy" name="txtAllergy" placeholder="Historical Allergies" rows=3 maxlength=150  onkeyup="checkData(1,this)"><?php echo $alle; ?></textarea>
    </div>
  </div><div class="form-row"><div class="col-md-12 mb-3"><hr style="border:0.5px dotted blue;background-color:#5af;"/></div></div>
</DIV>
<div style="overflow:auto;">
	<div style="float:right;">
	  <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
	  <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
	  <a href="stf.php"><button type="button" id="cmdClose" style="background-color:#aaa;color:#fff;">Close/ Cancel</button></a>
	</div>
</div>
</form></div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/iebc.js"></script>
<script type="text/javascript" src="tpl/js/stfadd.js"></script>
<?php
	echo '<script type="text/javascript"> var currentTab = 0; showTab(currentTab);';
	if(isset($mp) && strlen($mp)>0){
		echo 'var mp=['.$mp.'];';
		if(strlen($mca)>0) echo 'var mca=['.$mca.'];';
	}echo '</script>';mysqli_close($conn);footer();
?>
