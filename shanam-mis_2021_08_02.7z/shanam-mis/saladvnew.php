<?php
    include_once('shanam.php');
    $act=isset($_REQUEST['act'])?$_REQUEST['act']:"0-0";                                $act=preg_split("/\-/",$act); //[0] 0-New Adv and 1-Editing,[1] - Advance No.,[2] - payrollno
    if (isset($_POST['btnSave'])){
      $act=isset($_POST['txtAct'])?sanitize($_POST['txtAct']):'0-0';  $act=preg_split("/\-/",$act); //[0]-AdvNo, [1]-A/C, [2]-VoNo, [3]-Mode,[4]-BankA/C Sno,[5] - Orig Amt
      $date=isset($_POST['dtpDate'])?strip_tags($_POST['dtpDate']):date('d-m-Y'); $date=preg_split("/\-/",$date); $acc=isset($_POST['cboACNo'])?sanitize($_POST['cboACNo']):1;
      $pfn=isset($_POST['cboStf'])?strip_tags($_POST['cboStf']):0; $dur=isset($_POST['cboDur'])?strip_tags($_POST['cboDur']):0; $modeno=isset($_POST['txtModeNo'])?sanitize($_POST['txtModeNo']):null;
      $amt=isset($_POST['txtAmt'])?strip_tags($_POST['txtAmt']):0; $amt=preg_replace('/[^0-9^\.]/','',$amt); $mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'Cash';
      $amtpd=isset($_POST['txtAmtDur'])?strip_tags($_POST['txtAmtDur']):0;        $amtpd=preg_replace('/[^0-9^\.]/','',$amtpd); $modeno=strlen($modeno)>1?$modeno:null; $date="$date[2]-$date[1]-$date[0]";
      $rmks=isset($_POST['txtRmks'])?strtoupper(strip_tags($_POST['txtRmks'])):'';	$advno=isset($_POST['txtAdvNo'])?strip_tags($_POST['txtAdvNo']):0; $advno=strlen($advno)==0?0:$advno;
      $bankac=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;   $bankac=($bankac==0 || $bankac=='')?null:$bankac; $adb=$_SESSION['username']." (".$_SESSION['priviledge'].")";
      if (strlen($pfn)>0 && $amt>=$amtpd && strlen($rmks)>9 && $dur>0 && (strcasecmp($mode,'cash')==0 || (strcasecmp($mode,'cheque')==0 && !isnull($bankac) && strlen($modeno)>1))){
        if(mysqli_query($conn,"UPDATE acc_adv SET advno=$advno,payrollno='$pfn',adv_date='$date',amt=$amt,rmks='$rmks',duration='$dur',amtperduration=$amtpd,acc=$acc,pytfrm='$mode',cheno=".var_export($modeno,true).
        ",acsno=".var_export($bankac,true)." WHERE advno LIKE '$act[0]';") or die(mysqli_error($conn)." Advance record not saved. Click <a href=\"saladv.php\">HERE</a> to try again.")){ $i=mysqli_affected_rows($conn);
          if($i>0){$sql='';
            if(strcasecmp($mode,$act[3])!=0){if(strcasecmp($mode,"cheque")==0){$sql.="INSERT acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,addedby) VALUES (0,'$date',1,$bankac,'$cheno',
              $cheque,'Salary Advance',1,$pvno,'$adb'); UPDATE acc_cashflow SET markdel=1,delreason='Salary advance changed to cheque from cash' WHERE acc LIKE '$acc' and transtype=2 and transno LIKE '$pvno';";}
              elseif(strcasecmp($mode,"cash")==0){$sql.="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES(0,$acc,1,'$date','Salary Advance',$cash,2,$pvno,'$adb'); UPDATE
              acc_banking SET markdel=1,delreason='Salary advance changed to cash from cheque' WHERE transtype=1 and transno=$pvno and acsno LIKE '$act[4]';";}
            }if(strcasecmp($mode,"cheque")==0 && ($acsno!=$act[4] || $amt!=$act[5])) $sql.="UPDATE acc_banking SET acsno='acsno',amt=$amt WHERE transtype=1 and transno=$pvno and acsno LIKE '$act[4]';";
            if(strcasecmp($mode,"cash")==0 && $amt!=$act[5])$sql.="UPDATE acc_cashflow SET amt=$amt WHERE acc LIKE '$acc' and transtype=2 and transno LIKE '$pvno';";
            if(strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)." Advance cashflow details not edited. Click <a href=\"saladv.php\">HERE</a> to try again.");while(mysqli_next_result($conn)){}}
          }
        }
      }else{$i=0; echo 'Data has errors. Salary advance record not saved. Click <a href=\"saladv.php\">HERE</a> to try again.';exit(0);} header("location:saladv.php?action=1-$i"); exit(0);
    }elseif(isset($_POST['btnDel'])){

    }else{
        if ($act[0]==1){//editing advance
          mysqli_multi_query($conn,"SELECT advdel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT payrollno,adv_date,amt,rmks,duration,amtperduration,pytfrm,cheno,acsno,acc,vono,advreqno FROM acc_adv
          WHERE advno LIKE '$act[1]'; SELECT ((bsal+travellallow+medicalallow+houseallow+empnssf)-(nssffee+(paye-mpr)+empnssf+otherlevies+nhiffee+unionfee+saccofee+welfare)) as ns FROM acc_saldef WHERE payrollno LIKE
          '$act[2]'; SELECT sum(bal) as bal FROM (SELECT a.payrollno,a.advno,(a.amt-if(isnull(c.ttl),0,c.ttl)) as bal FROM acc_adv a LEFT JOIN (SELECT advano,sum(amt_clr) as ttl FROM acc_advclr GROUP BY advano,markdel
          HAVING markdel=0)c On (a.advno=c.advano) WHERE a.markdel=0 and a.issued=1)a Inner Join acc_saldef s USING (payrollno) GROUP BY a.payrollno,s.idno HAVING a.payrollno LIKE '$act[2]'; SELECT acno,descr FROM
          acc_voteacs WHERE markdel=0 and sal_assoc=1 ORDER BY acno ASC; SELECT sd.payrollno,concat(s.surname,' ',s.onames,' (',s.designation,') ID NO. ',s.idno) as nam FROM stf s Inner Join acc_saldef sd USING (idno)
          WHERE s.markdel=0 and	s.present=1 order by s.designation,s.surname ASC; SELECT a.acsno,ac.accacc,concat(ba.abbr,'-',ac.branch,' A/C NO.',ac.accNo) as bank,(a.bankbalbf+if(isnull(b.bal),0,b.bal)) as amt FROM
          acc_acbalbf a Inner Join acc_accounts ac ON (a.acsno=ac.sNo) Inner Join acc_banks ba ON (ac.bankno=ba.sNo) Inner Join acc_voteacs va ON (ac.accacc=va.acno) Left Join (SELECT acsno,sum(if(bank_type=0,amt,0)-
          if(bank_type=1,amt,0)) as bal FROM acc_banking Group By markdel,acsno HAVING markdel=0)b USING (acsno) GROUP BY a.bankbalbf,a.acsno,ac.accacc,ba.abbr,ac.accNo,va.sal_assoc HAVING va.sal_assoc=1 ORDER BY a.acsno;
          SELECT a.acc,(a.cashbalbf+if(isnull(b.amt),0,b.amt)) as amt FROM acc_votebalbf a Inner Join acc_voteacs v On (a.acc=v.acno) Left Join (SELECT acc,(sum(if(cftype=0,amt,0))-sum(if(cftype=1,amt,0))) as amt FROM
          acc_cashflow GROUP BY acc,markdel HAVING markdel=0)b USING (acc)	GROUP BY a.acc,a.cashbalbf,v.sal_assoc HAVING v.sal_assoc=1;"); $i=$netsal=$cashb=$bankb=0; $advno=$act[1];
          $lstbankbal=$lstcashbal=$optbank=$optac=$optstf='';
          do{
            if ($rs=mysqli_store_result($conn)){
              if($i==0) list($advdel)=mysqli_fetch_row($rs);  elseif ($i==1) list($pfno,$date,$amt,$rmks,$dur,$apd,$pytfrm,$cheno,$acsno,$acc,$vono,$reqno)=mysqli_fetch_row($rs);
              elseif($i==2) list($netsal)=mysqli_fetch_row($rs);   elseif($i==3) {list($ad)=mysqli_fetch_row($rs); $netsal-=$ad;}
              elseif($i==4) while($d=mysqli_fetch_row($rs)){$optac.="<option value=\"$d[0]\" ".($d[0]==$acc?"selected":"").">$d[1]</option>"; if($d[0]==$acc) $acname=$d[1];}
              elseif($i==5) while ($dat=mysqli_fetch_row($rs)) $optstf.="<option value=\"$dat[0]\" ".(strcasecmp($dat[0],$pfno)==0?"selected":"").">$dat[1]</option>";
              elseif($i==6){$c=0; while($d=mysqli_fetch_row($rs)){$lstbankbal.=($c==0?"":",")."new BankBal($d[0],$d[1],'$d[2]',$d[3])"; $c++; if($acc==$d[1]){$optbank.="<option value=\"$d[0]\" ".
                (strcasecmp($d[0],$acsno)==0?"Selected":"").">$d[2]</option>"; $bankb=$d[3];}}
              }else{$c=0; while($d=mysqli_fetch_row($rs)){$lstcashbal.=($c==0?"":",")."new CashBal($d[0],$d[1])"; $c++; if($acc==$d[0]) $cashb=$d[1];}} mysqli_free_result($rs);
            }$i++;
          }while(mysqli_next_result($conn));
        }
    }headings('<link rel="stylesheet" href="tpl/css/inputsettings.css"/><link href="/date/tcal.css" rel="stylesheet"/><link href="tpl/css/modalfrm.css" rel="stylesheet"/>',0,0,1);
?><div class="container divmodalmain"><form method="post" action="saladvnew.php" onsubmit="return verifyData(this)">
  <input type="hidden" name="txtAct" id="txtAct" value="<?php echo "$act[1]-$acc-$vono-$pytfrm-$acsno-$amt";?>">
<div class="divheadings"><h2 style="letter-spacing:4px;word-spacing:7px;">SALARY ADVANCE EDITOR</h2></div>
<div class="form-row">
  <div class="col-md-2"><label for="txtAdvNo">Advance No.</label><input class="modalinput" type="text" name="txtAdvNo" id="txtAdvNo" placeholder="Advance No." <?php print "value=\"$advno\"";?> readonly/></div>
  <div class="col-md-5"><label for="cboACNo">Advance Issued From</label><SELECT name="cboACNo" id="cboACNo" size="1" class="modalinput" onchange="loadAC(this)" disabled><?php echo $optac; ?></SELECT></div>
  <div class="col-md-2"></div>
  <div class="col-md-3"><label for="dtpDate">Issued On</label><input class="tcal modalinput" type="text" name="dtpDate" id="dtpDate" required="required" <?php print "value=\"".date("d-m-Y",strtotime($date))."\"";?>
    readonly></div>
</div><div class="form-row">
  <div class="col-md-9"><label for="cboStf">Issued To *</label><select name="cboStf" id="cboStf" required="required" onchange="findNetSal(this)" class="modalinput"><?php echo $optstf;?></select></div>
  <div class="col-md-3"><label for="txtBal">Net Salary *</label><input readonly type="text" name="txtBal" id="txtBal" <?php print "value=\"".number_format($netsal,2)."\"";?> class="modalinput numbersinput
     modalinputdisabled"></div>
</div><div class="form-row">
  <div class="col-md-2"><label for="cboMode">Advanced In *</label><SELECT class="modalinput" size="1" name="cboMode" id="cboMode" required="required" onchange="modeChange(this)"><option value="Cash"
    <?php echo strcasecmp($pytfrm,"cash")==0?"selected":"";?>>Cash</option><option value="Cheque" <?php echo strcasecmp($pytfrm,"cheque")==0?"selected":"";?>>Cheque</option></select></div>
  <div class="col-md-4"><label for="cboACNo">Bank A/C Debited</label><SELECT name="cboBank" id="cboBank" size="1" class="modalinput" onchange="loadBankBal(this)" disabled><option value="0" selected>SELECT A/C
  </option><?php echo $optbank;?></SELECT></div>
  <div class="col-md-2"><label for="txtModeNo">Cheque No. *</label><input class="modalinput" type="text" name="txtModeNo" id="txtModeNo" placeholder="00001" value="<?php echo $cheno;?>" onkeyup="checkNumber(this)"
    readonly/></div>
  <div class="col-md-2 divsubheading" style="letter-spacing:0;word-spacing:1px;"><label for="txtCashHand">Cash at Hand</label><Input name="txtCashHand" id="txtCashHand" class="modalinput numbersinput
    modalinputdisabled"  value="<?php echo number_format($cashb,2);?>"></div>
  <div class="col-md-2 divsubheading" style="letter-spacing:0;word-spacing:1px;"><label for="txtCashBank">Cash at Bank</label><Input name="txtCashBank" id="txtCashBank" class="modalinput numbersinput
    modalinputdisabled" value="<?php echo number_format($bankb,2);?>"></div>
</div><div class="form-row">
    <div class="col-md-2"><label for="cboStf">Amount *</label><input class="modalinput" type="text" name="txtAmt" id="txtAmt" required="required" placeholder="Amount Issued" onchange="calcAmtPerDur()"
      value="<?php echo number_format($amt,2);?>" /></div>
    <div class="col-md-4"><label for="cboDur">To be Recovered in *</label><select name="cboDur" id="cboDur" required="required" onchange="calcAmtPerDur()" class="modalinput">
	     <?php for ($i=1;$i<13;$i++) print "<option value=\"$i\" ".($i==$dur?"selected":"").">".($i==1?"1 Month":"$i Months")."</option>";?></select></div>
    <div class="col-md-3"></div>
    <div class="col-md-3"><label for="cboDur">@ (Kshs. Per Month)</label><input class="modalinput numbersinput modalinputdisabled" type="text" name="txtAmtDur" id="txtAmtDur"
        <?php print "value=\"".number_format($apd,2)."\"";?>  readonly/></div>
</div><div class="form-row">
    <div class="col-md-12"><label for="cboStf">Narration about Salary Advance *</label><textarea name="txtRmks" id="txtRmks" class="modalinput" placeholder="BEING SALARY ADVANCE FOR MEDICAL PURPOSES" rows="2"
      required="required" onkeyup="checkRmks(this)"> <?php print $rmks;?> </textarea></div>
</div><br><hr><div class="form-row">
    <div class="col-md-4"><button name="btnSave" type="submit" class="btn btn-primary btn-md btn-block">Save Advance Record</button></div>
    <div class="col-md-4" style="text-align:right;"><?php if($act[0]==1) echo '<button name="btnDel" type="button" class="btn btn-info btn-md" onclick="document.getElementById(\'divSalAdvNewDel\').style.display=\'block\'">
    Delete</button>';?></button></div>
    <div class="col-md-4" style="text-align:right;"><a href="saladv.php"><button name="btnClose" type="button">Close</button></a></div>
</div></form>
</div><div id="divSalAdvNewDel" class="modal">
	<form class="modal-content animate" method="post" action="saladvnew.php" name="frmAdvDel" onsubmit="confirmDel(this)"><input type="hidden" name="txtAdv" id="txtAdv"	value="<?php echo "$advno-$acc-$vono";?>">
	<div class="imgcontainer"><span onclick="document.getElementById('divSalAdvNewDel').style.display='none'" class="close" title="Close">&times;</span></div><br/>
	<div class="container divmodalmain">
    <div class="form-row"><div class="col-md-12">SALALRY ADVANCE DELETION MANAGER</div></div>
    <div class="form-row"><div class="col-md-12"><label for="txtDelReason">Narration/ Reason for Deletion</label><textarea name="txtDelRmks" id="txtDelRmks" rows="3" class="modalinput" onkeyup="enableDel(this)"
      placeholder="ERRONEOUSLY CAPTURED THE ADVANCE"></textarea></DIV></DIV>
    <hr><div class="form-row">
      <div class="col-md-6"><button type="submit" class="btn btn-block btn-primary btn-md" name="btnDelAdv" id="btnDelAdv" disabled>Delete Salary Advance</button></div>
      <div class="col-md-6" style="text-align:right;"><button type="button" onclick="document.getElementById('divSalAdvNewDel').style.display='none'" class="btn btn-md btn-info disabled">Cancel/ Close</button></div>
    </div>
  </div></form>
</div>
<script type="text/javascript" src="tpl/js/saladv.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript">bankbal.push(<?php echo $lstbankbal;?>); cashbal.push(<?php echo $lstcashbal;?>);</script>
<?php mysqli_close($conn);  footer(); ?>
