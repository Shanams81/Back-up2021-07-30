<?php
	include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['save'])):
		$r=0; 
		$cun=isset($_REQUEST['TxtCName'])?trim(strip_tags($_REQUEST['TxtCName'])):'';
		$un=isset($_REQUEST['TxtUName'])?trim(strip_tags($_REQUEST['TxtUName'])):'';
		$cpw=isset($_REQUEST['TxtCPW'])?trim(strip_tags($_REQUEST['TxtCPW'])):'';
		$npw=isset($_REQUEST['TxtNPW'])?trim(strip_tags($_REQUEST['TxtNPW'])):'';
		$con=isset($_REQUEST['TxtConfirm'])?trim(strip_tags($_REQUEST['TxtConfirm'])):'dd';
		if ((strlen($un)<3) || (strlen($un)>12)) $r=100;
		if (strlen($cpw)<1) $r=100;
		if (strlen($npw)<4) $r=100;
		if (strlen($con)<4) $r=100;
		if (strcmp($npw,$con)!=0) $r=100;
		//if (strcmp($npw,$cpw)==0) $r=100;
		if ($r==0):
			$rs=mysqli_query($conn,"SELECT priviledge FROM login WHERE username='$cun' AND pw=md5('$cpw')");
			if (mysqli_num_rows($rs)==1):
				list($priv)=mysqli_fetch_row($rs); 	$d=strcasecmp($priv,"administrator")==0 ? 360 : strcasecmp($priv,"director")==0?180:90;
				$da=date("Y-m-d", strtotime("+$d day"));
				@mysqli_query($conn,"UPDATE login SET username='$un',pw=md5('$npw'),expirydate='$da' WHERE username='$cun' AND pw=md5('$cpw')");
				$r=mysqli_affected_rows($conn);  $da=date("D d-M-Y",strtotime($da));
			else:
				$r=0;
			endif;
			mysqli_free_result($rs);
		endif;
		if ($r==1) header("location:home.php?action=1-$da"); else header("location:home.php?action=0-0");
	endif;
?>