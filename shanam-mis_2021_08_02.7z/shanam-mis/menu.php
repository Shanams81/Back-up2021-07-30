<?php
    include_once('shanam.php');
    mysqli_multi_query($conn,"SELECT g.studview,g.stfview,g.userview,g.analysis,g.backup,g.confdel,g.privview,g.sysdata,g.setupview,g.deptview,c.feeview,c.feeadd,c.struview,
    c.salview,c.advview,c.itemview,c.pytview,c.impview,c.advreqapproval,c.reqapproval,c.reqview,c.accview,budgview,g.feetrans FROM gen_priv g INNER JOIN acc_priv c
    USING (uname) WHERE g.uname LIKE '".$_SESSION['username']."';SELECT count(reqno) as nos FROM acc_req GROUP BY approved,markdel HAVING (approved=0 and markdel=0);");
    $i=0; $reqno=$vistu=$vistf=$viuser=$anal=$bacup=$conf=$priv=$ssda=$visetup=$dept=$vifee=$addfee=$vistru=$visal=$viadv=$viitm=$vipyt=$viimp=$advapp=$reqapp=$vireq=$viacc=$vibudg=$feetrans=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0) list($vistu,$vistf,$viuser,$anal,$bacup,$conf,$priv,$ssda,$visetup,$dept,$vifee,$addfee,$vistru,$visal,$viadv,$viitm,$vipyt,$viimp,$advapp,$reqapp,$vireq,$viacc,$vibudg,
            $feetrans)=mysqli_fetch_row($rs);
            else list($noreq)=mysqli_fetch_row($rs); mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    headings('<link href="/fontawesome/css/fontawesome.css" rel="stylesheet"><link href="/fontawesome/css/brands.css" rel="stylesheet"><link href="/fontawesome/css/solid.css"
	   rel="stylesheet"><link rel="stylesheet" href="tpl/css/menu.css" type="text/css">',0,0,10);
    print "<a ".(($_SESSION['sector'])==0?"href=\"/home.php\" target=\"det\">":"href=\"home.php\" target=\"det\">")."<Img src=\"/gen_img/logo.jpg\" width=\"50\"
    height=\"50\" align=\"left\" border=\"0\"></a><b style=\"font-size:9px;color:#994444;\"><u>".$_SESSION['username']." (". $_SESSION['priviledge'].")</u><b>
    <br><b>Your password expires in ".$_SESSION['pwdays']." day(s)</b><hr></a>";
?>
<div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel-group" id="accordion">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" onclick="collapsePanels()"><span aria-hidden="true" class="fab fa-accessible-icon fab-7x
                            optmain"></span>General Functions</a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse">
                        <div class="panel-body">
                            <div class="myRow">
                                <span aria-hidden="true" class="fab fa-creative-commons-by fab-5x optmenu"></span><a target="det"
                                href=" <?php echo (($vistf==1)?"stf_manager.php?action=0-0":"#");?>">Staff, Depts and Salary Manager</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-linux optmenu fab-5x"></span><a target="det" href="<?php echo (($vistu==1)?"pupil_manager.php?action=0-0":"");?>">
                                Students, Uniform &amp; Fees Manager</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-creative-commons-nc optmenu fab-5x"></span><a target="det"
                                href="<?php echo (($vifee==1)?"fsegrants.php?action=0-0":"#");?>">FSE Fee</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-creative-commons-nc-eu fab-5x optmenu"></span><a target="det"
                                href="<?php echo (($vifee==0)?"#":"otherincomes.php?action=0-0");?>">Other Incomes</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" onclick="collapsePanels()"><span aria-hidden="true" class="fab fa-cc-amazon-pay fab-7x
							              optmain"></span>Expenditures</a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="myRow">
                                <span aria-hidden="true" class="fab fa-expeditedssl fab-5x optmenu"></span><a href="<?php echo (($vipyt==1)?"goodsbudg.php":"#");?>" target="det">
								                 Budgeting</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-gulp fab-5x optmenu"></span><a href="<?php echo (($viimp==1)?"imprest_manager.php":"#");?>" target="det">Imprests</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-cc-visa fab-5x optmenu"></span><a href="<?php echo (($vipyt==1)?"pettypyts.php?action=0-0":"#");?>" target="det">
                                  Petty	Cash</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-medapps fab-5x optmenu"></span><a href="<?php echo (($vipyt==1)?"withdrawborrow.php?action=0-0":"#");?>" target="det">
								                  Bankings &amp; Interborrowings</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-mailchimp fab-5x optmenu"></span><a href="<?php echo (($vipyt==1)?"creditors.php?action=0-":"#");?>" target="det">
                                  Creditors</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-mailchimp fab-5x optmenu"></span><a href="<?php echo (($vipyt==1)?"creditorcommtpyts.php?action=0-":"#");?>"
                                  target="det">Commitment Payments</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" onclick="collapsePanels()"><span aria-hidden="true" class="fab fa-jenkins fab-7x optmain"></span>System Users</a>
                        </h4>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="myRow">
                                <span aria-hidden="true" class="fab fa-asymmetrik fab-5x optmenu"></span><a target="det" href="<?php echo (($viuser==1)?"users.php":"#");?>">Authorized Users</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-creative-commons fab-5x optmenu"></span><a href="cpw.php" target="det">Change Password</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-creative-commons-zero fab-5x optmenu"></span><a href="guest.php" target="det">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour" onclick="collapsePanels()"><span aria-hidden="true" class="fab fa-app-store fab-7x
							               optmain"></span>Administration</a>
                        </h4>
                    </div>
                    <div id="collapseFour" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="myRow">
                                <span aria-hidden="true" class="fab fa-centos fab-5x optmenu"></span><a target="det"
                                href="<?php echo (($visetup==1)?"settings_manager.php?action=0-0":"#");?>">System Settings</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-deezer fab-5x optmenu"></span><a target="det" href="<?php echo (($priv==1)?"priv.php":"#");?>">User Priviledges</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-creative-commons-share fab-5x optmenu"></span><a target="det" href="<?php echo (($bacup==1)?"data_backup.htm":"#");?>">
								                  Data Backup</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-joomla fab-5x optmenu"></span><a target="det" href="<?php echo(($conf==1)?"deleted_pupil.php":"#");?>">
                                  Restore Student</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-joomla fab-5x optmenu"></span><a target="det" href="<?php echo(($conf==1)?"waivers.php":"#");?>">
                                  Waivers/Pardons</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-joomla fab-5x optmenu"></span><a target="det" href="<?php echo(($feetrans==1)?"transferfees.php":"#");?>">
                                  Transfer Fees</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-joomla fab-5x optmenu"></span><a target="det" href="<?php echo(($feetrans==1)?"votedistr.php":"#");?>">
                                  Votehead Distribution</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFive" onclick="collapsePanels()"><span aria-hidden="true" class="fab fa-buffer fab-7x optmain">
							               </span>Reports</a>
                        </h4>
                    </div>
                    <div id="collapseFive" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="myRow">
                                <span aria-hidden="true" class="fab fa-buysellads fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"arrears.php":"#");?>">Arrears B/F</a>
                            </div><div class="myRow">
                                <span  aria-hidden="true" class="fab fa-cloudscale fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"feereminder.php":"#");?>">Fee
                                  Balances</a>
                            </div><div class="myRow">
                                <span  aria-hidden="true" class="fab fa-blackberry fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"feeregister.php":"#");?>">Fee
								                 Registers</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-cc-apple-pay fab-5x optmenu"></span><a target="det" href="<?php echo (($vipyt==1)?"pytrpts.php":"#");?>">Payment
								                  Reports</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-cuttlefish fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"cashbook.php":"#");?>">Cash Book</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-docker fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"ledgerbook.php":"#");?>">Ledger Book</a>
                            </div><div class="myRow">
                               <span aria-hidden="true" class="fab fa-fedora fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"trialbal.php":"#");?>">Trial Balance</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseSix" onclick="collapsePanels()"><span aria-hidden="true" class="fab fa-evernote fab-7x optmain">
							               </span>Archived Data</a>
                        </h4>
                    </div>
                    <div id="collapseSix" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="myRow">
                                <span aria-hidden="true" class="fab fa-grav fab-5x optmenu"></span><a target="det" href="<?php echo (($vistu==1)?"Arch_Fee_Bal_Status.php?action=0-0":"");?>">
								                 Fees Defaulters</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="icon-video optmenu"></span><a target="det" href="<?php echo (($vistu==1)?"Archpupil.php?action=0-0":"");?>">Fees Statement</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-hubspot fab-5x optmenu"></span><a target="det" href="<?php echo (($vistru==1)?"archfeestruct.php?action=0-0":"");?>">Fee
                                Structures</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-fly fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"Archfee.php?action=0-0":"");?>">Fee
								                Collection</a>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-black-tie fab-5x optmenu"></span><a target="det" href="<?php echo (($vifee==1)?"ArchStf.php?action=0-0":"");?>">Staff
								                 &amp; Salary</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseSeven" onclick="collapsePanels()"><span aria-hidden="true" class="fab fa-canadian-maple-leaf
							               fab-7x optmain"></span>Contacts</a>
                        </h4>
                    </div>
                    <div id="collapseSeven" class="panel-collapse collapse">
                        <div class="panel-body">
                            <div class="myRow">
                                <span aria-hidden="true" class="fab fa-codiepie fab-5x optmenu"></span><a href="contact.php" target="det">Developer</a></td>
                            </div><div class="myRow">
                                <span aria-hidden="true" class="fab fa-cloudflare fab-5x optmenu"></span><?php echo (strcmp(strtolower($_SESSION['username']),'shanam')==0?"<a "
                                . "href=\"financialyearchange.php\" target=\"det\">Closeup Books</a></li>":"-");?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <p style="position:absolute;bottom:2px;color:#0000FF;font-size:9px;">Shanams Digital Solutions Ltd,<br>Tel. No. +254736732168 or +254712609945<br><a mailto="shanams81@yahoo.com"
    style="font-size:9px;">shanams81@yahoo.com</a></p>
</div>
<script type="text/javascript">
    function collapsePanels(){
        var pan=document.getElementsByClassName("panel-collapse"); var i=pan.length;
        for (var a=0; a<i; a++){
           pan[a].className="panel-collapse collapse";
        }//cPan.className="panel-collapse";
    }
</script>
<?php mysqli_close($conn); footer(); ?>
