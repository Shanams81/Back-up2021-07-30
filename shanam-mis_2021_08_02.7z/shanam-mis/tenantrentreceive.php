<?php
	declare(strict_types=1); include_once('shanam.php');
	$tNo=isset($_REQUEST['tno'])?sanitize($_REQUEST['tno']):"0-0-0-0";							$tenNo=explode('-',$tNo); //[0]0-New,1-Edit,[1]- Tenant No. [2] Recieptno S/N and [3]- A/C
	if(isset($_POST['btnSave'])){
		$sno=isset($_POST['txtRNo'])?sanitize($_POST['txtRNo']):'Auto';							$dat=isset($_POST['txtDate'])?sanitize($_POST['txtDate']):date('d-m-Y'); $date=explode('-',$dat);
		$acc=isset($_POST['cboAcc'])?sanitize($_POST['cboAcc']):1;									$voteno=isset($_POST['txtVArrRent'])?sanitize($_POST['txtVArrRent']):'0-0'; $vno=explode('-',$voteno);
		$tno=isset($_POST['txtInfo'])?sanitize($_POST['txtInfo']):'0-0-0-0-0';			$tenNo=explode('-',$tno); //[0]0-New,1-Edit,[1]- Tenant No. [2] Recieptno S/N, [3]- A/C,[4]-Mode
		$mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'CASH';					$modeno=isset($_POST['txtModeNo'])?sanitize($_POST['txtModeNo']):'';
		$bank=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;								$bank=$bank==0?null:$bank;
		$amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0;									$rentarr=isset($_POST['txtArrBal'])?sanitize($_POST['txtArrBal']):0;
		$arr=isset($_POST['txtArrears'])?sanitize($_POST['txtArrears']):0;					$rent=isset($_POST['txtRent'])?sanitize($_POST['txtRent']):0;
		$varr=isset($_POST['txtVArr'])?sanitize($_POST['txtVArr']):0;								$vrent=isset($_POST['txtVRent'])?sanitize($_POST['txtVRent']):0;
		$bc=isset($_POST['txtBC'])?sanitize($_POST['txtBC']):0;	$arr=floatval(preg_replace('/[^0-9\.]/','',$arr));	$rent=floatval(preg_replace('/[^0-9\.]/','',$rent));
		$amt=floatval(preg_replace('/[^0-9\.]/','',$amt));			$bc=floatval(preg_replace('/[^0-9\.]/','',$bc));		$addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
		$rentarr=floatval(preg_replace('/[^0-9\.]/','',$rentarr));	$vrent=intval(preg_replace('/[^0-9\.]/','',$vrent));	$varr=intval(preg_replace('/[^0-9\.]/','',$varr));
		if((strcasecmp($mode,'cash')!=0 && strlen($modeno)<2) || ((strcasecmp($mode,'cheque')==0 || strcasecmp($mode,'direct banking')==0) && is_null($bank)) || (($arr+$rent)!=$amt) ||
		$varr<1 || $vrent<1 || $amt<1 ){
			echo "Rent income record has errors to be corrected before saving. Click <a href=\"tenants.php\">HERE</a> to go back.<br>Mode-$mode, Mode No.-$modeno,Bank No.-$bank,Arrears-$arr,
			Rent - $rent, amt- $amt, Arrears Vote - $varr and Rent Votehead - $vrent"; exit(0);
		}else{
			if($tenNo[0]==0){//new Rent
				if($acc==1){//Main A/C
					if (mysqli_query($conn,"INSERT INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,commt,kinddescr,addedby) VALUES(0,'$tenNo[1]','$date[2]-$date[1]-$date[0]','Self',
						'$mode',".var_export($modeno,true).",null,".var_export($bank,true).",2,null,'$addby')") or die(mysqli_error($conn).". 1. Click <a href=\"tenants.php\">HERE</a>
						to try again.")){
							$sno=mysqli_insert_id($conn);
							if(mysqli_query($conn,"INSERT INTO acc_incorecno0 (recno,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm) VALUES (0,$sno,'1',$bc,$amt,$arr,0,0,0,0);") or
							die(mysqli_error($conn).". Click <a href=\"tenants.php\">HERE</a> to try again.")){
									$no=mysqli_insert_id($conn); $sql='INSERT INTO acc_incovotes (recno,acc,voteno,amt,markdel) VALUES ';
									if($arr>0) $sql.="($no,1,$vno[0],$arr,0)"; if($rent>0) $sql.=($arr>0?",":"")."($no,1,$vno[1],$rent,0)";
									mysqli_query($conn,$sql) or die(mysqli_error($conn).". 2. Click <a href=\"tenants.php\">HERE</a> to try again.");
							}header("location:rpts/rentreceipt.php?recno=$sno-0-$acc-".uniqid());
					}
				}else{//Operations A/C
					if (mysqli_query($conn,"INSERT INTO acc_fseincome(recno,noofstud,recon,batchno,acc,amt,arrears,commt,inter_no,mode,modeno,bankno,rmks,addedby) VALUES(0,1,'$date[2]-$date[1]-$date[0]',
						1,$acc,$amt,$arr,4,'$tenNo[1]','$mode',".var_export($modeno,true).",".var_export($bank,true).",'Rent Income','$addby')") or die(mysqli_error($conn).". 1. Click <a
						href=\"tenants.php\">HERE</a>	to try again.")){
							$sno=mysqli_insert_id($conn); $sql='INSERT INTO acc_fsevotes (recno,acc,voteno,amt,markdel) VALUES ';
							if($arr>0) $sql.="($no,1,$vno[0],$arr,0)"; if($rent>0) $sql.=($arr>0?",":"")."($no,1,$vno[1],$rent,0)";
							mysqli_query($conn,$sql) or die(mysqli_error($conn).". 2. Click <a href=\"tenants.php\">HERE</a> to try again.");
						}header("location:rpts/rentreceipt.php?recno=$sno-0-$acc-".uniqid());
					}
			}else{//editing rent
				if($acc==1){//Main A/C
					if($tenNo[3]!=1){
						mysqli_multi_query($conn,"UPDATE acc_fseincome SET markdel=1,delreason='Rent receipt changed to School Fund A/C by ".$addby."' WHERE recno=$tenNo[2] and acc=$tenNo[3];UPDATE
						acc_fsevotes SET markdel=1 WHERE recno=$tenNo[2] and acc=$tenNo[3];"); while(mysqli_next_result($conn)){}
						if (mysqli_query($conn,"INSERT INTO acc_incofee(sno,admno,pytdate,paidby,pytfrm,cheno,bursno,bankno,kinddescr,addedby) VALUES(0,'$tenNo[1]','$date[2]-$date[1]-$date[0]','Self',
						'$mode',".var_export($modeno,true).",null,".var_export($bank,true).",null,'$addby')") or die(mysqli_error($conn).". 1. Click <a href=\"tenants.php\">HERE</a> to try again.")){
								$sno=mysqli_insert_id($conn);
								if(mysqli_query($conn,"INSERT INTO acc_incorecno0 (recno,sno,acc,bc,amt,arrears,spemed,refunds,prep,unifrm) VALUES (0,$sno,'1',$bc,$amt,$arr,0,0,0,0);") or
								die(mysqli_error($conn).". Click <a href=\"tenants.php\">HERE</a> to try again.")){
										$no=mysqli_insert_id($conn); $sql='INSERT INTO acc_incovotes (recno,acc,voteno,amt,markdel) VALUES ';
										if($arr>0) $sql.="($no,1,$vno[0],$arr,0)"; if($rent>0) $sql.=($arr>0?",":"")."($no,1,$vno[1],$rent,0)";
										mysqli_query($conn,$sql) or die(mysqli_error($conn).". 2. Click <a href=\"tenants.php\">HERE</a> to try again.");
								}
						}
					}else{
						$ttl=$rent+$arr;
						mysqli_multi_query($conn,"UPDATE acc_incofee SET pytdate='$date[2]-$date[1]-$date[0]',pytfrm='$mode',cheno=".var_export($modeno,true).",bankno=".var_export($bank,true)." WHERE
						sno LIKE '$tenNo[2]'; UPDATE acc_incorecno0 SET bc=$bc,amt=$ttl,arrears=$arr WHERE sno LIKE '$tenNo[2]'; UPDATE acc_incovotes SET amt=$arr WHERE recno IN (SELECT recno FROM
						acc_incorecno0 WHERE sno LIKE '$tenNo[2]') and acc=1 and voteno=$varr;UPDATE acc_incovotes SET amt=$rent WHERE recno IN (SELECT recno FROM acc_incorecno0 WHERE sno LIKE
						'$tenNo[2]') and acc=1 and voteno=$vrent;") or die(mysqli_error($conn).". Click <a href=\"tenants.php\">HERE</a> to try again."); $i=0;
						do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=$i>0?1:0;
					}
				}else{//Editing operations account rent
					if($tenNo[3]==1){
						mysqli_multi_query($conn,"UPDATE acc_incofee SET markdel=1,delreason='Rent receipt changed to Operations A/C by ".$addby."' WHERE sno=$tenNo[2] and acc=$tenNo[3]; UPDATE
						acc_incorecno0 SET markdel=1 WHERE sno=$tenNo[2] and acc=1; UPDATE acc_incovotes SET markdel=1 WHERE recno IN (SELECT recno FROM acc_incorecno0 WHERE sno LIKE '$tenNo[2]')
						and acc=1"); while(mysqli_next_result($conn)){}
						if (mysqli_multi_query($conn,"UPDATE acc_fseincome SET recon,batchno,acc,amt,arrears,commt,inter_no,mode,modeno,bankno,rmks,addedby) VALUES(0,1,'$date[2]-$date[1]-$date[0]',
						1,$acc,$amt,$arr,3,'$tenNo[1]','$mode',".var_export($modeno,true).",".var_export($bank,true).",'Rent Income','$addby')") or die(mysqli_error($conn).". 1. Click <a
						href=\"tenants.php\">HERE</a>	to try again.")){
							$sno=mysqli_insert_id($conn); $sql='INSERT INTO acc_incovotes (recno,acc,voteno,amt,markdel) VALUES ';
							if($arr>0) $sql.="($no,1,$vno[0],$arr,0)"; if($rent>0) $sql.=($arr>0?",":"")."($no,1,$vno[1],$rent,0)";
							mysqli_query($conn,$sql) or die(mysqli_error($conn).". 2. Click <a href=\"tenants.php\">HERE</a> to try again.");
						}
					}else{
						$ttl=$rent+$arr;
						mysqli_multi_query($conn,"UPDATE acc_fseincome SET recon='$date[2]-$date[1]-$date[0]',mode='$mode',modeno=".var_export($modeno,true).",bankno=".var_export($bank,true).",
						amt=$ttl,arrears=$arr WHERE	recno LIKE '$tenNo[2]'; UPDATE acc_fsevotes SET amt=$arr WHERE recno=$tenNo[2] and acc=$tenNo[3] and voteno=$varr;UPDATE acc_fsevotes SET amt=$rent
						WHERE recno=$tenNo[2] and acc=$tenNo[3] and voteno=$vrent;") or die(mysqli_error($conn).". Click <a href=\"tenants.php\">HERE</a> to try again."); $i=0;
						do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=$i>0?1:0;
					}
				}header("location:tenants.php?action=1-$i"); exit(0);
			}
		}
	}elseif(isset($_POST['btnDelete'])){
		$tenNo=explode('-',$tno); //[0]0-New,1-Edit,[1]- Tenant No. [2] Recieptno S/N, [3]- A/C,[4]-Mode
		$rmks=isset($_POST['txtDelRmks'])?sanitize(strtoupper($_POST['txtDelRmks'])):'';
		if (strlen($rmks)>10){
			if($tenNo[3]==1) $sql="UPDATE acc_incofee SET markdel=1,delreason='Rent receipt changed to Operations A/C by ".$addby."' WHERE sno=$tenNo[2] and acc=$tenNo[3]; UPDATE
			acc_incorecno0 SET markdel=1 WHERE sno=$tenNo[2] and acc=1; UPDATE acc_incovotes SET markdel=1 WHERE recno IN (SELECT recno FROM acc_incorecno0 WHERE sno LIKE '$tenNo[2]')
			and acc=1";
			else $sql="UPDATE acc_fseincome SET markdel=1,delreason='Rent receipt changed to School Fund A/C by ".$addby."' WHERE recno=$tenNo[2] and acc=$tenNo[3];UPDATE
			acc_fsevotes SET markdel=1 WHERE recno=$tenNo[2] and acc=$tenNo[3];";
			mysqli_multi_query($conn,$sql); $i=0;	do{	$i+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn)); $i=$i>0?1:0;
		}else $i=0;
		header("location:tenants.php?action=2-$i"); exit(0);
	}headings('<link rel="stylesheet" href="../date/tcal.css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"/>',0,0,2);
	if($tenNo[0]==1){//Editing Rent income
		if($tenNo[3]==1)$sql="SELECT f.recno,i.admno,i.pytdate,i.pytfrm,i.cheno,i.bankno,f.arrears,f.bc,f.amt FROM acc_incofee i INNER JOIN acc_incorecno0 f USING (sno) WHERE f.sno LIKE
		'$tenNo[2]' and f.acc LIKE '$tenNo[3]'";
		else $sql="SELECT f.recno,f.inter_no,f.recon,f.mode,f.modeno,f.bankno,f.arrears,0 as bc,f.amt FROM acc_fseincome f WHERE f.markdel=0 and f.recno LIKE '$tenNo[2]' and f.acc LIKE
		'$tenNo[3]'";
		$rs=mysqli_query($conn,$sql); list($frec,$tenNo[1],$fdate,$fmode,$fmodeno,$fbank,$farr,$fbc,$famt)=mysqli_fetch_row($rs); mysqli_free_result($rs);
	}else{
		$frec='Auto';	$fdate=date('Y-m-d'); $fmode='Cash';	$fmodeno='';	$fbank=0;	$farr=0;	$fbc=0;	$famt=0;
	}mysqli_multi_query($conn,"SELECT t.tno,t.houseno,concat(s.surname,' ',s.onames) as st_names,r.arr, ((if(year(t.entrydate)=y.finyr,(month(curdate())-month(t.entrydate)+1),
	month(curdate()))*r.rent)-if(isnull(p.rp),0,p.rp)) as rent FROM stf s Inner Join acc_tenants t USING (idno) Inner Join (SELECT t.tno,a.arr,(rent+rentfurn+rentwater+rentelect) as
	rent FROM acc_tenantrent t Inner Join (SELECT tno,sum(arrears) as arr FROM `acc_tenantrent` group by tno, markdel having markdel=0)a USING (tno))r
	USING (tno) LEFT JOIN	(SELECT admno,sum(rent) as rp FROM (SELECT i.admno,sum(f.amt-f.arrears) as rent FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) GROUP BY i.admno,
	f.MarkDel HAVING f.markdel=0 and i.admno LIKE '$tenNo[1]' UNION SELECT inter_no as admno,sum(amt-arrears) as rent FROM `acc_fseincome` GROUP BY markdel,inter_no HAVING markdel=0
	and inter_no LIKE '$tenNo[1]')f GROUP	BY admno)p ON (t.tno=p.admno), (SELECT finyr FROM ss)y WHERE t.markdel=0 and t.tno LIKE '$tenNo[1]' and t.markdel=0; SELECT feedel FROM
	acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT v.acc,a.descr FROM acc_votes v Inner Join acc_voteacs a On (v.acc=a.acno) WHERE v.abbr LIKE 'rent' ORDER BY v.acc ASC;
	SELECT sno,acc,abbr	FROM `acc_votes` WHERE abbr in ('arrears','rent') and acc IN (SELECT acno FROM acc_votes v Inner Join acc_voteacs a On (v.acc=a.acno) WHERE v.abbr LIKE 'rent')
	ORDER BY abbr ASC;SELECT sno,descr FROM acc_banks WHERE markdel=0 ORDER BY descr Asc;") or die(mysqli_error($conn).". Click	<a href=\"tenants.php\">HERE</a> to try again.");
	$del=$i=$acc=$varr=$vrent=0; $optAcc=$lstvotes=$optBank="";
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0) list($tno,$hno,$nam,$arrears,$rentbill)=mysqli_fetch_row($rs);		elseif($i==1)list($del)=mysqli_fetch_row($rs);
			elseif($i==2) {$a=0; while ($da=mysqli_fetch_row($rs)){if($a===0) $acc=$da[0]; $optAcc.="<option ".($a==0?"Selected":"")." value=\"$da[0]\">$da[1]</option>"; $a++;}
			}elseif($i==3){$a=0; while ($d=mysqli_fetch_row($rs)){
				if($acc==$d[1]){if(strcasecmp('arrears',$d[2])==0)$varr=$d[0]; if(strcasecmp('rent',$d[2])==0)$vrent=$d[0];}
				$lstvotes.=($a==0?"":",")."new Voteheads($d[0],$d[1],'$d[2]')"; $a++;}
			}else{while($d=mysqli_fetch_row($rs)) $optBank.="<option ".($fbank==$d[0]?"selected":"")." value=\"$d[0]\">$d[1]</option>";}	mysqli_free_result($rs);
		} $i++;
	}while(mysqli_next_result($conn));
?><form action="tenantrentreceive.php" method="Post" name="frmTenantsEdit" onsubmit="return validateFormOnSubmit(this)">
	<input type="hidden" name="txtInfo" id="txtInfo" value="<?php echo "$tenNo[0]-$tenNo[1]-$tenNo[2]-$tenNo[3]-$fmode";?>">
	<div class="container divmodalmain">
		<div class="form-row">
			<div class="col-md-12 divheadings">RECEIVING RENT OF <?php echo "TENANT $tenNo[1] <u>$nam</u> HOUSE NO. $hno";?></div>
    </div><div class="form-row">
      <div class="col-md-3"><label for="txtRNo">Receipt No. *</label><input type="text" name="txtRNo" id="txtRNo" value="<?php echo $frec;?>" maxlength="3" required
				class="modalinput"></div>
			<div class="col-md-6"><label for="cboAcc">Receipt Account*</label><select name="cboAcc" id="cboAcc" size="1" class="modalinput" onchange="accChange(this)">
			<?php echo $optAcc;?></SELECT></div>
			<div class="col-md-3"><label for="txtDate">Rent Received On *</label><input type="text" name="txtDate" id="txtDate" value="<?php echo date('d-m-Y',strtotime($fdate));?>"
				maxlength="3"	required	class="tcal modalinput"></div>
		</div><div class="form-row">
      <div class="col-md-3"><label for="cboMode">Mode of Receipt *</label><select name="cboMode" id="cboMode" size="1" class="modalinput" onchange="checkMode(this)"><option value="CASH"
			<?php echo strcasecmp($fmode,'cash')==0?"selected":"";?>>Cash</option><option value="MFEES" <?php echo strcasecmp($fmode,'mfees')==0?"selected":"";?>>M - Money</option><option
			value="CHEQUE" <?php echo strcasecmp($fmode,'cheque')==0?"selected":"";?>>Cheque</option><option value="DIRECT BANKING" <?php echo strcasecmp($fmode,'cheque')==0?"selected":"";?>>
			Direct Banking</option></select></div>
      <div class="col-md-3"><label for="txtModeNo">Transaction/Cheque No. *</label><input type="text" name="txtModeNo" id="txtModeNo" class="modalinput" value="<?php echo $fmodeno;?>"
				readOnly></div>
			<div class="col-md-6"><label for="cboBank">Mode Banker</label><SELECT name="cboBank" id="cboBank" size=1 <?php echo (strcasecmp($fmode,'cash')==0 || strcasecmp($fmode,'mfees')==0)?
			"disabled":"";?> class="modalinput"><option value="0" <?php echo ($fbank==0?"selected":"").">None</option>";echo $optBank;?></SELECT></div>
    </div><div class="form-row">
      <div class="col-md-12 divheadings"><div class="form-row"><div class="col-md-4"><label for="txtArrBal">RENT ARREARS B/F</label><input type="text" class="modalinput
				modalinputdisabled" readOnly value="<?php echo number_format(floatval($arrears),2);?>" name="txtArrBal" id="txtArrBal"></div><div class="col-md-4"><label
				for="txtRentBal">MONTHLY RENT BILLS</label><input type="text" class="modalinput modalinputdisabled" readOnly value="<?php echo number_format(floatval($rentbill),2);?>"
				name="txtRentBal" id="txtRentBal"></div><div class="col-md-4"><label for="txtTtlBal">TOTAL RENT BILL</label><input type="text" class="modalinput modalinputdisabled"
				readOnly value="<?php echo number_format((floatval($arrears)+floatval($rentbill)),2);?>"	name="txtRentBal" id="txtRentBal"></div></div>
			</div>
    </div><hr><div class="form-row">
			<div class="col-md-3"><label for="txtAmt">Amount Received *</label><input type="text" name="txtAmt" id="txtAmt" maxlength="10" value="<?php echo number_format((floatval($farr)+
			floatval($famt)),2);?>" class="modalinput	numbersinput" required onkeyup="cleanAmt(this)" onblur="distrAmt(this)"><input type="hidden" name="txtOAmt" value="<?php
			echo (floatval($farr)+floatval($famt));?>"></div>
			<div class="col-md-3"><label for="txtBC">Bank Charges (For Cheques) *</label><input type="text" name="txtBC" id="txtBC" maxlength="10" value="<?php echo
			number_format(floatval($fbc),2);?>"	class="modalinput	numbersinput" required readOnly onkeyup="cleanAmt(this)" onblur="getTotal()"></div>
			<div class="col-md-3"></div>
			<div class="col-md-3"><label for="txtTtlAmt">Total Rent Amount Received</label><input type="text" name="txtTtlAmt" id="txtTtlAmt" maxlength="10" value="<?php echo
			number_format(floatval($famt)+floatval($fbc),2);?>" class="modalinput	numbersinput modalinputdisabled" readOnly></div>
		</DIV><div class="form-row">
      <div class="col-md-12 divsubheading">DISTRIBUTION OF AMOUNT RECEIVED</DIV>
		</div><div class="form-row">
			<input type="hidden" name="txtVArrRent" id="txtVArrRent" value="<?php echo "$varr-$vrent";?>"><input type="hidden" name="txtOAmt" id="txtOAmt" value="<?php echo "$farr-$famt";?>">
			<div class="col-md-3"><label for="txtArrears">Rent Arrears *</label><input type="text" name="txtArrears" id="txtArrears" maxlength="10" value="<?php echo number_format(floatval($farr),
			2)."\""; if(floatval($arrears)==0||floatval($farr)==0) echo "readOnly";?> class="modalinput	numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"><input type="hidden"
			name="txtVArr" value="<?php echo $varr;?>"></div>
			<div class="col-md-3"><label for="txtRent">Monthly Rent *</label><input type="text" name="txtRent" id="txtRent" maxlength="10" value="<?php echo number_format(floatval($famt)-
			floatval($farr),2);?>" class="modalinput numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"><input type="hidden" name="txtVRent" value="<?php echo $vrent;?>">
			</div>
			<div class="col-md-3"></div>
			<div class="col-md-3 divsubheading"><label for="txtTotal">Total Rent Distributed</label><input type="text" name="txtTotal" id="txtTotal" maxlength="10" value="<?php echo
			number_format(floatval($famt)+floatval($fbc),2);?>" class="modalinput	numbersinput modalinputdisabled" readOnly></div>
		</div><hr><div class="form-row" id="divBtns">
        <div class="col-md-5"><button type="submit" name="btnSave" class="btn btn-primary btn-md btn-block">Save Rent Details</button></div>
				<div class="col-md-4" style="text-align:right;"><?php if($tenNo[0]==1) echo "<button type=\"button\" class=\"btn btn-info btn-md\" onclick=\"showDelete($del)\" name=\"cmdDel\">
				Delete</button>";?></div>
        <div class="col-md-3" style="text-align:right;"><button type="button" class="btn btn-info btn-md" onclick="window.open('tenants.php','_self')" 	name="cmdclose">Cancel/Close
				</button></div>
    </div><hr><div class="form-row" id="divDelTenant" style="display:none;">
				<div class="col-md-12">
					<div class="form-row">
						<div class="col-md-12"><label for="txtDelReason">Reason for Deleting Tenant *</label><textarea rows=4 class="modalinput" name="txtDelRmks" id="txtDelRmks"
							onkeyup="checkRmks(this)"	placeholder="Record incorrectly received"></textarea></div>
					</div><div class="form-row">
		      	<div class="col-md-4"><button type="submit" class="btn btn-block btn-info" name="btnDelete" id="btnDelete" disabled>Delete Tenant</button></div>
						<div class="col-md-4"></div>
			      <div class="col-md-4" style="text-align:right;"><button type="button" class="btn btn-info"	name="btncloseDel" onclick="cancelDel()">Cancel Delete</button></div>
					</div>
				</div>
		</div>
	</div>
	</form>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/rent.js"></script>
<script type="text/javascript">
	<?php if(strlen($lstvotes)>5) echo "voteheads.push($lstvotes);";?>
</script>
<?php mysqli_close($conn); footer();?>
