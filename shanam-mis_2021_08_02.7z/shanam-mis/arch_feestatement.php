<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else {
		include_once('../conn/pri_sch_connect.inc');
		$admno=isset($_REQUEST['admno'])?trim(strip_tags($_REQUEST['admno'])):"0-0";
		$admno=preg_split("/\-/",$admno); //0-admission, 1-academic year
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>Fees Status</title>
		<link href="tpl/acc.css" rel="stylesheet" type="text/css"/>
		<script type="text/javascript" src="tpl/printthis.js"></script>
    </head>
<body background="img/bg3.gif">
	<?php
		if ($admno[0]>0):
			print "<div id=\"print_content\">";
			print "<h3 style=\"color:#00f;text-align:center;\">$admno[1] Academic Year Student's Fees Statement</h3>";
			$rsStud=mysqli_query($conn,"SELECT concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname, '-', sf.stream) As Frm,sf.bbf,sf.miscbf,(sf.t1trans+sf.t2trans+sf.t3trans) 
			as trans,sf.feegrp FROM Stud s Inner Join class sf USING (admno) Inner Join classnames c USING (clsno) WHERE (sf.curr_year LIKE '$admno[1]' AND sf.admno LIKE '$admno[0]')"); 
			$nst=mysqli_num_rows($rsStud);
			if ($nst!=1):
				print "Please, Enter valid admission number. The Admission No. $admno[0] does not exist in the year $admno[1]. <a href=\"archpupil.php\">Click 
				here to go back</a>.";
			else:
				list($sn,$fr,$bb,$mb,$trans,$grp)=mysqli_fetch_row($rsStud);
				$rsSchool=mysqli_query($conn,"SELECT scnm,scadd FROM SS"); list($scnm,$scadd)=mysqli_fetch_row($rsSchool); mysqli_free_result($rsSchool);
				print "<table cellspacing=\"0\" cellpadding=\"3\" align=\"center\"><tr><th rowspan=\"3\"><img src=\"img\logo.png\" width=\"50\" height=\"60\"></th>
				<th style=\"letter-spacing:2px;font-size:14px;word-spacing:4px;text-align:left;\">$scnm</th></tr><tr><th style=\"letter-spacing:2px;font-size:14px;
				word-spacing:4px;text-align:left;\">$scadd</th></tr><tr><th style=\"letter-spacing:2px;font-size:14px;word-spacing:4px;text-align:left;\">
				$admno[1] Financial Year - Fees Statement</th></tr><tr><td colspan=\"2\"><hr></td></tr>";
				print "<tr><td colspan=\"2\" style=\"letter-spacing:2px;font-size:14px;word-spacing:4px;text-align:center;\">Adm. No. $admno[0]-<b><u>$sn</u></b> 
				Form <b>$fr</b> - Fee Group <b>$grp</b></td></tr><tr><td colspan=\"2\">";
				print "<table border=\"1\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" style=\"font-size:10px;\"><tr style=\"
				letter-spacing:2px;word-spacing:3px;\" bgcolor=\"#eeeeee\"><th colspan=\"9\">MAIN ACCOUNT</th><th colspan=\"6\">MISCELLANEOUS ACCOUNT
				</th></tr>";
				$rsMFS=mysqli_query($conn,"Select (s.bbf+If(isnull(f.ar),0,f.ar)) As arr,(s.t1trans+s.t2trans+s.t3trans+If(isnull(f.tr),0,f.tr))as trans,t.maint3,(t.maint3+s.bbf+
				If(isnull(f.ar),0,f.ar)+s.t1trans+s.t2trans+s.t3trans+If(isnull(f.tr),0,f.tr)) As Ttl From class s Inner Join Arch_FeeOutline t USING (lvlno,feegrp,curr_year) Left Join 
				(SELECT yr,admno,sum(arrears+spemed) as Ar,sum(transport) as tr FROM Arch_feerec Group By markdel,admno,yr Having (markdel=0 and yr Like '$admno[1]' and admno LIKE 
				'$admno[0]'))f On (s.admno=f.admno and s.curr_year=f.yr) WHERE (s.admno LIKE '$admno[0]' and s.curr_year LIKE '$admno[1]')");
				if (mysqli_num_rows($rsMFS)>0) list($mainArr,$maintrans,$mainFee,$mainTtl)=mysqli_fetch_row($rsMFS);	mysqli_free_result($rsMFS);
				$rsMFS=mysqli_query($conn,"SELECT (s.miscbf+If(isnull(f.ar),0,f.ar)) As arr, (s.unifrm+If(isnull(f.un),0,f.un)) as uni, t.misct3,(t.misct3+s.bbf+If(isnull(f.ar),0,f.ar)+
				s.unifrm+If(isnull(f.un),0,f.un)) As Ttl From class s Inner Join Arch_feeoutline t USING (lvlno,feegrp,curr_year) Left Join (SELECT yr,payeesno,sum(arrears) as Ar,sum(uni) 
				as un FROM Arch_miscfeepyts group by yr,payeesno,markdel Having (markdel=0 and payeesno LIKE '$admno[0]' AND yr LIKE '$admno[1]'))f On (s.admno=f.payeesno and 
				s.curr_year=t.curr_year) WHERE (s.admno LIKE '$admno[0]' And s.curr_year LIKE '$admno[1]')");
				if (mysqli_num_rows($rsMFS)>0) list($miscArr,$miscFee,$miscuni,$miscTtl)=mysqli_fetch_row($rsMFS);		mysqli_free_result($rsMFS);
				print "<tr><td colspan=\"3\">Arrears B/F On:01-Jan-$admno[1]</td><td colspan=\"6\" align=\"right\">".number_format($mainArr,2)."
				</td><td colspan=\"6\" align=\"right\">".number_format($miscArr,2)."</td></tr>";
				print "<tr><td colspan=\"3\">Transport Charges</td><td colspan=\"6\" align=\"right\">".number_format($maintrans,2)."</td><td colspan=\"3\">Uniform
				</td><td colspan=\"3\" align=\"right\">".number_format($miscuni,2)."</td></tr>";
				print "<tr  bgcolor=\"#eeeeee\"><td colspan=\"3\">Year's Fee</td><td colspan=\"6\" align=\"right\">".number_format($mainFee,2)."</td><td 
				colspan=\"6\" align=\"right\">".number_format($miscFee,2)."</td></tr>";
				print "<tr><td colspan=\"3\"><b>Total Fee</b></td><td colspan=\"6\" align=\"right\"><b>".number_format($mainTtl,2)."</b></td>
				<td colspan=\"6\" align=\"right\"><b>".number_format($miscTtl,2)."</b></td></tr>";
				print "<tr bgcolor=\"#eeeeee\" style=\"letter-spacing:3px;Word-spacing:4px;\"><td colspan=\"9\" align=\"center\"><b>Main 
				A/C Fee Payment Installment</b></td><td colspan=\"6\" align= \"center\"><b>Miscellaneous A/C Fee Payment Installment
				</b></td></tr><tr><td></td><td><b>Receipt</b></td><td><b>Received On</b></td><td><b>Cheque No.</b></td><td><b>Refunds</b></td><td><b>Prepayment</b>
				</td><td><b>Transport</b></td><td><b>Fee Paid</b></td><td><b>Total</b></td><td><b>Receipt</b></td><td><b>Received On
				</b></td><td><b>Cheque No.</b></td><td><b>Uniform</b></td><td><b>Fee Paid</b></td><td><b>Total</b></td></tr>";
				$rsMain=mysqli_query($conn,"SELECT f.`recieptno`, f.`pytdate`, f.`cmono`,f.`refunds`,f.prep,f.transport,(f.`amt`-f.`refunds`-f.prep) As FeePaid,(f.amt+f.bankcharges) As Tt 
				From Arch_feerec f WHERE (f.`yr` LIKE '$admno[1]' and f.`admno` LIKE '$admno[0]' and f.markdel=0) ORDER BY f.`recieptno` ASC");
				$rsMisc=mysqli_query($conn,"SELECT recipetno,pytdate,cheno,Uni,(`amt`-uni) as Unif,(`amt`+`bankcharges`) As tt FROM `Arch_MiscFeePyts` WHERE (`yr` LIKE '$admno[1]' And 
				`payeesno` LIKE '$admno[0]' and markdel=0) ORDER BY `recipetno` ASC");
				$manr=mysqli_num_rows($rsMain); $minr=mysqli_num_rows($rsMisc);
				$mattl=array(0,0,0,0,0); $mittl=array(0,0,0);
				for ($a=0;$a<16;$a++):
					if (($a%2)==0) print "<tr bgcolor=\"#eeeeee\"><td>".($a+1).".</td>"; else print "<tr><td>".($a+1).".</td>";
					if (($a<$manr) && ($manr>0)){
						list($marec,$mada,$macn,$maref,$mapr,$matr,$mafp,$maamt)=mysqli_fetch_row($rsMain);  
						print "<td>$marec</td><td>".date("D d-M-Y",strtotime($mada))."</td><td>$macn</td><td align=\"right\">".number_format($maref,2)."</td>
						<td align=\"right\">".number_format($mapr,2)."</td><td align=\"right\">".number_format($matr,2)."</td><td align=\"right\">".
						number_format($mafp,2)."</td><td align=\"right\">".number_format($maamt,2)."</td>"; $mattl[0]+=$maref; $mattl[1]+=$mapr; $mattl[2]+=$matr;
						$mattl[3]+=$mafp;	$mattl[4]+=$maamt;
					}else {
						print "<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>";
					}
					if (($a<$minr) && ($minr>0)){
						list($marec,$mada,$macn,$maun,$mafp,$maamt)=mysqli_fetch_row($rsMisc);
						print "<td>$marec</td><td>".date("D d-M-Y",strtotime($mada))."</td><td>$macn</td><td align=\"right\">".number_format(
						$maun,2)."</td><td align=\"right\">".number_format($mafp,2)."</td><td align=\"right\">".number_format($maamt,2).
						"</td></tr>"; $mittl[0]+=$maun; $mittl[1]+=$mafp; $mittl[2]+=$maamt; 
					}else{
						print "<td></td><td></td><td></td><td></td><td></td><td></td></tr>";
					}
				endfor;
				print "<tr bgcolor=\"#999999\"><td colspan=\"3\"><b>$manr Fees Installment(s)</b></td><td><b>Subtotals</b></td>";
				foreach ($mattl as $tt) print "<td align=\"right\"><b>".number_format($tt,2)."</b></td>";
				print "<td colspan=\"2\" bgcolor=\"#999999\"><b>$minr Misc Installment(s)</b></td><td bgcolor=\"#999999\"><b>Subtotals</b></td>";
				foreach ($mittl as $tt) print "<td align=\"right\" bgcolor=\"#999999\"><b>".number_format($tt,2)."</b></td>";
				print "</tr>"; mysqli_free_result($rsMain); mysqli_free_result($rsMisc);
				$rsBal=mysqli_query($conn,"SELECT ((t.maint3-s.totalpaid)+s.arr) As TtlBal FROM (SELECT s.curr_year,s.lvlno,s.feeGrp,(s.specialmedical+s.bbf+s.t1trans+s.t2trans+
				s.t3trans) as arr,IF(isnull(f.tp),0,f.tp) As totalpaid FROM class s Left Join (SELECT yr,admno,sum(Amt-arrears-Refunds-SpeMed-prep-transport) AS TP FROM Arch_feerec f 
				GROUP BY f.admno,f.yr HAVING (f.yr LIKE '$admno[1]') AND (f.admno LIKE '$admno[0]'))f on (s.admno= f.admno and s.curr_year=f.yr) WHERE (s.admno LIKE '$admno[0]' AND 
				s.curr_year LIKE '$admno[1]'))s INNER JOIN Arch_FeeOutline t ON (S.feegrp=T.feegrp AND S.lvlno=T.lvlno AND s.curr_year=t.curr_year)"); 
				list($mainy)=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);
				$rsBal=mysqli_query($conn,"SELECT (f.misct3-s.AmtPaid+s.arr) As TtlBal FROM Arch_FeeOutline f INNER JOIN (SELECT s.curr_year,s.feeGrp,(s.Miscbf+s.unifrm) as arr,s.lvlno,
				if(isnull(m.ttlp),0,m.ttlp) AS `AmtPaid` FROM `class` `s` left join (SELECT yr,payeesno,sum(Amt-Arrears) AS TtlP FROM Arch_miscfeepyts m Group By m.yr,m.payeesno HAVING 
				(m.yr LIKE '$admno[1]' AND m.payeesno LIKE '$admno[0]'))m on (s.admno=m.PayeesNo And s.curr_year=m.yr) WHERE (s.admno LIKE '$admno[0]' And s.curr_year LIKE '$admno[1]'))s 
				ON (S.feegrp=f.feegrp AND s.lvlno=f.lvlno And s.curr_year=f.curr_year)"); 
				list($misy)=mysqli_fetch_row($rsBal); mysqli_free_result($rsBal);
				print "<tr><td colspan=\"6\"><b>Main Fee Balance of Kshs. ".number_format($mainy,2)."</b></td><td  colspan=\"5\"><b>Misc. Fee Balance of Kshs. ".number_format($misy,2).
				"</b></td><td colspan=\"4\"><b>Total Fee Balance of Kshs. ".number_format(($mainy+$misy),2)."</b></td></table></td></tr></table>";
				print "</div><table border=\"0\" cellspacing=\"2\" cellpadding=\"4\" align=\"center\"><td align=\"left\">Click <a href=\"javascript:Clickheretoprint()\"><b>Here</b></a> 
				to Print</td><td width=\"50%\" align=\"right\">Click <a href=\"archpupil.php\"><b>Here</b></a> To Go Back</td></tr></table>";
			endif;
		endif;
		mysqli_close($conn);
	?>
</body>
</html>

