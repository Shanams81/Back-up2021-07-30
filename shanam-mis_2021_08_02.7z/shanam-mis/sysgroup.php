<?php
	include_once('shanam.php');	$s[0]=$s[1]=0;
	if (isset($_POST['cmdSave'])){
	 	$rec=isset($_REQUEST['txtAction'])?sanitize($_REQUEST['txtAction']):'0-0';	$rec=preg_split("/\-/",$rec); $tknv=sanitize($_POST['txtTkn']);
		$stf=isset($_POST['txtStf'])?sanitize($_POST['txtStf']):"";$stf=strlen($stf)==0?Null:strtoupper($stf);$studgrp=isset($_POST['txtStudGrp'])?sanitize($_POST['txtStudGrp']):"";
		$studgrp=strlen($studgrp)==0?Null:strtoupper($studgrp);	$fgrp=isset($_POST['txtFGrp'])?sanitize($_POST['txtFGrp']):"";$fgrp=strlen($fgrp)==0?Null:strtoupper($fgrp);
	 	$strm=isset($_POST['txtStrm'])?sanitize($_POST['txtStrm']):""; $strm=strlen($strm)==0?Null:strtoupper($strm);	$pp=isset($_POST['txtPP'])?sanitize($_POST['txtPP']):"";
		$pp=strlen($pp)==0?Null:strtoupper($pp);$bra=isset($_POST['txtBranch'])?sanitize($_POST['txtBranch']):"";$bra=strlen($bra)==0?Null:strtoupper($bra);
	 	$cor=isset($_POST['txtCore'])?sanitize($_POST['txtCore']):"";$cor=strlen($cor)==0?Null:strtoupper($cor);$cat=isset($_POST['txtCateg'])?sanitize($_POST['txtCateg']):"";
		$cat=strlen($cat)==0?Null:strtoupper($cat);
	 	if ($tknv===$_SESSION['grpToken'] && (strlen($stf)>0 || strlen($studgrp)>0 || strlen($fgrp)>0 || strlen($strm)>0 || strlen($pp)>0 || strlen($bra)>0 ||
		strlen($cor)>0 || strlen($cat)>0)){unset($_SESSION['grpToken']);
			if ($rec[0]==0) $sql="INSERT INTO grps (grp_no,staff,strm,pp,bb,corevalue,categ,stud_grp) VALUES (0,".var_export($stf,true).",
			".var_export($strm,true).",".var_export($pp,true).",".var_export($bra,true).",".var_export($cor,true).",".var_export($cat,true).",".var_export($studgrp,true).")";
			else $sql="UPDATE grps SET staff=".var_export($stf,true).",strm=".var_export($strm,true).",pp=".var_export($pp,true).",
			bb=".var_export($bra,true).",corevalue=".var_export($cor,true).",categ=".var_export($cat,true).",stud_grp=".var_export($studgrp,true)." WHERE grp_no LIKE '$rec[1]'";
			//execute the SQL
			mysqli_query($conn,$sql) or die(mysqli_error($conn)." Record not saved. Click <a href=\"sysgroup.php?action=0-0\">here</a> to go back.");
			$s[1]=mysqli_affected_rows($conn);
		} $s[0]=1;
	}elseif(isset($_POST['btnSaveTerm'])){ $tknv=sanitize($_POST['txtTkn1']); $sql='';
		$info1=isset($_POST['txtInfo_0'])?sanitize($_POST['txtInfo_0']):'0-0'; $info1=explode('-',$info1);//[0] -tno, [1]finyr
		$t1a=isset($_POST['txtAbbr_0'])?sanitize($_POST['txtAbbr_0']):'';	$t1d=isset($_POST['txtDescr_0'])?sanitize($_POST['txtDescr_0']):'';
		$start1=isset($_POST['txtStart_0'])?sanitize($_POST['txtStart_0']):date('d-m-Y'); $start1=explode('-',$start1); $start1=$start1[2].'-'.$start1[1].'-'.$start1[0];
		$end1=isset($_POST['txtEnd_0'])?sanitize($_POST['txtEnd_0']):date('d-m-Y'); $end1=explode('-',$end1); $end1=$end1[2].'-'.$end1[1].'-'.$end1[0];
		//term ii
		$info2=isset($_POST['txtInfo_1'])?sanitize($_POST['txtInfo_1']):'0-0'; $info2=explode('-',$info2);//[0] -tno, [1]finyr
		$t2a=isset($_POST['txtAbbr_1'])?sanitize($_POST['txtAbbr_1']):'';	$t2d=isset($_POST['txtDescr_1'])?sanitize($_POST['txtDescr_1']):'';
		$start2=isset($_POST['txtStart_1'])?sanitize($_POST['txtStart_1']):date('d-m-Y'); $start2=explode('-',$start2); $start2=$start2[2].'-'.$start2[1].'-'.$start2[0];
		$end2=isset($_POST['txtEnd_1'])?sanitize($_POST['txtEnd_1']):date('d-m-Y'); $end2=explode('-',$end2); $end2=$end2[2].'-'.$end2[1].'-'.$end2[0];
		//Term III
		$info3=isset($_POST['txtInfo_2'])?sanitize($_POST['txtInfo_2']):'0-0'; $info3=explode('-',$info3);//[0] -tno, [1]finyr
		$t3a=isset($_POST['txtAbbr_2'])?sanitize($_POST['txtAbbr_2']):'';	$t3d=isset($_POST['txtDescr_2'])?sanitize($_POST['txtDescr_2']):'';
		$start3=isset($_POST['txtStart_2'])?sanitize($_POST['txtStart_2']):date('d-m-Y'); $start3=explode('-',$start3); $start3=$start3[2].'-'.$start3[1].'-'.$start3[0];
		$end3=isset($_POST['txtEnd_2'])?sanitize($_POST['txtEnd_2']):date('d-m-Y'); $end3=explode('-',$end3); $end3=$end3[2].'-'.$end3[1].'-'.$end3[0];
		if(($t1a!==$t2a && $t1a!==$t3a && $t2a!==$t3a) || ($t1d!==$t2d && $t1d!==$t3d && $t2d!==$t3d) || !(strtotime($start2)<=strtotime($end1) && strtotime($start2)>=strtotime($start1)) ||
		!(strtotime($start3)<=strtotime($end2) && strtotime($start3)>=strtotime($start2))){
			mysqli_multi_query($conn,"UPDATE terms SET abbr='$t1a',descr='$t1d',starts='$start1',ends='$end1' WHERE tno LIKE '$info1[0]' and finyr LIKE '$info1[1]'; UPDATE terms SET abbr='$t2a',
			descr='$t2d',starts='$start2',ends='$end2' WHERE tno LIKE '$info2[0]' and finyr LIKE '$info2[1]'; UPDATE terms SET abbr='$t3a',descr='$t3d',starts='$start3',ends='$end3' WHERE tno
			LIKE '$info3[0]' and finyr LIKE '$info3[1]';") or die(mysqli_error($conn).". Click <a href=\"sysgroup.php\">HERE</a> to try again.");
			do{$s[1]+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn));$s[0]=1;
		}else $s[1]=0; $s[0]=1;
	}elseif(isset($_POST['btnFGSave'])){
		$sno=isset($_POST['txtFGSNo'])?sanitize($_POST['txtFGSNo']):0; 			$stkn=isset($_POST['txtFGSTkn'])?sanitize($_POST['txtFGSTkn']):'0'; 	$act=isset($_POST['txtFGAct'])?sanitize($_POST['txtFGSAct']):'0';
		$abbr=isset($_POST['txtFGAbbr'])?strtoupper(sanitize($_POST['txtFGAbbr'])):'';	$descr=isset($_POST['txtFGDescr'])?strtoupper(sanitize($_POST['txtFGDescr'])):'';
		if(strlen($abbr)>2 && strlen($descr)>4){
			if($act==0) $sql="INSERT INTO acc_feegrps(grpno,abbr,descr,addedby) VALUES(0,'$abbr','$descr','".$_SESSION['username']."(".$_SESSION['priviledge'].")');";
			else $sql="UPDATE acc_feegrps SET abbr='$abbr',descr='$descr' WHERE grpno LIKE '$sno';"; mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"sysgroup.php\">HERE</a> to try again.");
			$s[1]=mysqli_affected_rows($conn);
		}else $s[1]=0; $s[0]=1;
	} $tkn=$_SESSION['grpToken']=uniqid();
	headings('<link rel="stylesheet" href="tpl/css/modalfrm.css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"/><link rel="stylesheet" href="/date/tcal.css" /><style>.c{text-align:center;}</style>',$s[0],$s[1],2);
	$rsDet=mysqli_query($conn,"SELECT grpedit,grpadd,grpdel FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$add=mysqli_fetch_row($rsDet); mysqli_free_result($rsDet);
?>
<div class="container" style="width:fit-content;border:1px dashed #fff;border-radius:10px;background-color:#d6d6d6;padding:10px;max-width:950px;">
	<ul class="nav nav-tabs" id="myTabs">
	    <li class="nav-item active"><a class="nav-link active" data-toggle="tab" id="grp-tab" href="#Groups">Group Setups</a></li>
			<li class="nav-item"><a class="nav-link" data-toggle="tab" id="feegrp-tab" href="#FeeGroup">Fee Groups</a></li>
	    <li class="nav-item"><a class="nav-link" data-toggle="tab" id="terms-tab" href="#Terms">Academic Terms</a></li>
	</ul>
	<div class="tab-content" id="myTabContent">
			<div id="Groups" class="tab-pane fade show active" role="tabpanel" aria-labelledby="grp-tab" style="border:0.2px dotted blue;border-radius:10px;padding:6px;max-height:700px;overflow-y:scroll;">
				<div class="form-row"><div class="col-md-12 divheadings">GROUP SETUP DETAILS</div></div>
				<div class="form-row"><div class="col-md-12"><table class="table table-striped table-hover table-bordered table-sm" style="font-size:0.9rem;" id="tblGrps"><thead class="thead-dark">
				<tr><th>#</th><th>STAFF GROUPS</th><th>STAFF GROUPS</th><th>GRADE/FORM STREAM</th><th>SALARY PAYPOINT</th><th>PAYPOINT BRANCHES</th><th>CORE VALUES</th><th>ITEMS CATEGORY</th><th>ADMIN ACTION</th></tr></thead><tbody>
				<?php $a=0;
					mysqli_multi_query($conn,"SELECT grp_no,staff,strm,pp,bb,corevalue,categ,stud_grp FROM grps Order By grp_no Asc; SELECT tno,t.finyr,abbr,descr,starts,ends FROM terms t Inner
					Join ss s USING (finyr);"); $i=0; $grps=$terms='';
					do{
						if($rs=mysqli_store_result($conn)){
							if($i==0){if (mysqli_num_rows($rs)>0){while (list($gno,$stf,$strm,$pp,$bb,$cv,$categ,$studgrp)=mysqli_fetch_row($rs)){
								print "<tr><td>".($a+1)."</td><td>$stf</td><td>$studgrp</td><td>$strm</td><td>$pp</td><td>$bb</td><td>$cv</td><td>$categ</td><td class=\"c\"><a href=\"#\" onclick=\"return canedit($add[0],$gno);\">Edit</a>
								</td></tr>";		$grps.=($a==0?"":",")."new Grps($gno,'$stf','$strm','$pp','$bb','$cv','$categ','$studgrp')";	$a++;
								}}else print "<tr><td colspan=\"10\">Sorry, No grouping  record exists at the moment</td></tr>";
							}else{$c=0; while($trm=mysqli_fetch_row($rs)){$terms.="<br><div class=\"form-row\" style=\"border-bottom:1px solid #00d\"><div class=\"col-md-6 divsubheading\">FINANCIAL YEAR'S ".($c==0?"FIRST":
								($c==1?"SECOND":"THIRD"))." TERM DETAILS</div><div class=\"col-md-6\"></div></div><div class=\"form-row\"><div class=\"col-md-3\"><label for=\"txtAbbr_$c\">Short Name</label><input type=\"text\"
								class=\"modalinput\" name=\"txtAbbr_$c\" id=\"txtAbbr_$c\" required ".($add[0]==1?"":"readonly")."	maxlength=\"19\" onkeyup=\"chkValues(this)\" value=\"$trm[2]\"><input type=\"hidden\"
								name=\"txtInfo_$c\" value=\"$trm[0]-$trm[1]\"></div><div class=\"col-md-5\"><label for=\"txtDescr_$c\">Full Name of the Term</label><input type=\"text\" onkeyup=\"chkValues(this)\" class=\"modalinput\"
								name=\"txtDescr_$c\" id=\"txtDescr_$c\" required ".($add[0]==1?"":"readonly")." maxlength=\"50\" value=\"$trm[3]\"></div><div class=\"col-md-2\"><label for=\"txtStart_$c\">Term Starts On</label><input
								type=\"text\"	class=\"modalinput tcal\" name=\"txtStart_$c\" id=\"txtStart_$c\" required ".($add[0]==1?"":"readonly")." value=\"".date('d-m-Y',strtotime($trm[4]))."\"></div><div class=\"col-md-2\"><label
								for=\"txtEnd_$c\">Term Ends On</label><input type=\"text\" class=\"modalinput tcal\" name=\"txtEnd_$c\" id=\"txtEnd_$c\" required ".($add[0]==1?"":"readonly")." value=\"".date('d-m-Y', strtotime($trm[5])).
								"\"></div></div>"; $c++;}
							}mysqli_free_result($rs);
						}$i++;
					}while(mysqli_next_result($conn));
				?></tbody></table></div></div>
			<div class="form-row"><div class="col-md-6"><button name="CmdAdd" <?php echo (($add[1]==0)?"disabled":"");?> type="button" class="btn btn-primary btn-block btn-md" onclick="showNew()">New Group Setup</button></div>
			<div class="col-md-6"></div></div>
		</div><div id="FeeGroup" class="tab-pane fade show" role="tabpanel" aria-labelledby="feegrp-tab" style="border:0.2px dotted blue;border-radius:10px;padding:6px;">
			<div class="form-row"><div class="col-md-12 divheadings">DETAILS OF NEW/CURRENT FEE GROUP</div></div>
			<form name="frmFeeGrp" method="post" action="sysgroup.php" onsubmit="return validateFeeGrp(this)"><INPUT name="txtFGTkn" type="hidden" size=4 value="<?php echo $tkn;?>" id="txtFGTkn"><INPUT name="txtFGAct"
				id="txtFGAct" value="0" type="hidden"><br>
				<div class="form-row"><div class="col-md-9">
					<div class="form-row"><div class="col-md-6"><label for="txtFGSNo">Serial No.</label><input class="modalinput" name="txtFGSNo" id="txtFGSNo" readonly placeholder="Auto" value=""></div>
						<div class="col-md-6"><label for="txtFGAbbr">Fee Group Abbreviation</label><input class="modalinput" name="txtFGAbbr" id="txtFGAbbr" readonly placeholder="General" value="" onkeyup="chkValues(this)"></div>
					</div><div class="form-row"><div class="col-md-12"><label for="txtFGDescr">Fee Group Description</label><input class="modalinput" name="txtFGDescr" id="txtFGDescr" readonly placeholder="General" value=""
						onkeyup="chkValues(this)"></div></div>
				</div><div class="col-md-3"><button type="submit" class="btn btn-primary btn-block btn-md" name="btnFGSave"	<?php echo ($add[0]==1?"":"disabled");?>>Save Fees<br>Group Details</button></div></div>
			</form><hr>
			<div class="form-row"><div class="col-md-12 divheadings">DETAILS OF EXISTING FEE GROUPS</div></div>
			<div class="form-row"><div class="col-md-12"><table class="table table-md table-hover table-striped" id="tblFG"><thead class="thead-dark"><tr><th>S/N</th><th>ABBREVIATION</th><th>DESCRIPTION</th><th>ADMIN ACTION</th>
			</tr></thead><tbody>
				<?php $rs=mysqli_query($conn,"SELECT grpno,abbr,descr FROM acc_feegrps ORDER BY grpno ASC"); $i=1;
					if(mysqli_num_rows($rs)>0){while($d=mysqli_fetch_row($rs)){echo "<tr><td>$i</td><td>$d[1]</td><td>$d[2]</td><td class=\"c\"><a href=\"#\" onclick=\"showGRP($i,$d[0],$add[0])\">Edit</a></td></tr>"; $i++;}
					}else{echo "<tr><td colspan=\"4\">Fee groups are yet to be set</td></tr>";} mysqli_free_result($rs);
				?>
			</tbody></table></div></div>
		</div><div id="Terms" class="tab-pane fade show" role="tabpanel" aria-labelledby="terms-tab" style="border:0.2px dotted blue;border-radius:10px;padding:6px;">
			<div class="form-row"><div class="col-md-12 divheadings">DETAILS OF TERMS IN THE FINANCIAL YEAR</div></div>
				<form name="frmTerms" method="post" action="sysgroup.php" onsubmit="return validateTermData(this)"><INPUT name="txtTkn1" type="hidden" size=4 value="<?php echo $tkn;?>"
					id="txtTkn1"><?php echo $terms;?><br><div class="form-row"><div class="col-md-5"><button type="submit" class="btn btn-primary btn-block btn-md" name="btnSaveTerm"
					<?php echo ($add[0]==1?"":"disabled");?>>Save Terms' Details</button></div><div class="col-md-7"></div>
				</div></form>
		</div>
	</div><hr>
	<div class="form-row"><div class="col-md-12" style="text-align:right"><button type="button" name="btnClose" onclick="window.open('settings_manager.php','_self')" class="btn btn-info
		btn-md">Close</button></div></div>
</div><div id="divGrpEdit" class="modal"><div class="container divmodalmain">
	<div class="imgcontainer"><span onclick="document.getElementById('divGrpEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span>
	</div><br/>
	<form name="frmGrpAdd" method="post" action="sysgroup.php" onsubmit="return validateData(this)"><INPUT name="txtTkn" type="hidden" size=4 value="<?php echo $tkn;?>" id="txtTkn">
	<INPUT name="txtAction" id="txtAction" type="hidden" size=4 value="<?php echo '0-0';?>">
	<div class="form-row">
		<div class="col-md-6"><label for="txtStf">Staff Group</label><input type="text" name="txtStf" id="txtStf" class="modalinput" maxlength="20" placeholder="Non Teaching Staff"
		value=""></div>
		<div class="col-md-6"><label for="txtStudGrp">Student Group</label><input	type="text" name="txtStudGrp" id="txtStudGrp" class="modalinput" maxlength="16" value=""
		placeholder="Boarder"></div>
	</div><br><div class="form-row">
		<div class="col-md-6"><label for="txtStrm">Grade/Form Stream</label><input type="text" name="txtStrm" id="txtStrm" class="modalinput" maxlength="8" value="" placeholder="Yellow"></div>
		<div class="col-md-6"><label for="txtCateg">Item Category</label><input type="text" name="txtCateg" id="txtCateg" class="modalinput" maxlength="25" value=""
		placeholder="Consumable"></div>
	</div><br><div class="form-row">
		<div class="col-md-6"><label for="txtPP">Salary Paypoint (Bank)</label><input type="text" name="txtPP" id="txtPP" class="modalinput" maxlength="15" value="" placeholder="KCB"></div>
		<div class="col-md-6"><label for="txtBranch">Paypoint Branch</label><input type="text" name="txtBranch" id="txtBranch" class="modalinput" maxlength="15" value=""
		placeholder="Mumias"></div>
	</div><br><div class="form-row">
		<div class="col-md-12"><label for="txtCore">Institution Core Value</label><input type="text" name="txtCore" id="txtCore" class="modalinput" maxlength="30" value=""
		placeholder="Transparency and Integrity"></div>
	</div><br><hr><div class="form-row">
		<div class="col-md-6"><button name="cmdSave" type="submit" class="btn btn-md btn-block btn-primary">Save Grouping Details</div>
		<div class="col-md-6" style="text-align:right;"><button name="cmdClose" type="button"  onclick="document.getElementById('divGrpEdit').style.display='none'"
		class="btn btn-md btn-info" >Cancel/ Close</button></a></div>
	</div></div>
</div>
<script type="text/javascript" src="tpl/js/grps.js"></script><script type="text/javascript" src="/date/tcal.js"></script>
<?php if(strlen($grps)>0){echo "<script type=\"text/javascript\">grps.push($grps);</script>";}	mysqli_close($conn); footer(); ?>
