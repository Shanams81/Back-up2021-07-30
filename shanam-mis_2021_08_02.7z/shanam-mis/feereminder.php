<?php
	include_once('shanam.php');
	mysqli_multi_query($conn,"SELECT feeview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT c.clsno,concat(l.lvlname,' - ',c.clsname) as frm FROM classnames c Inner Join classlvl l USING (lvlno);
	SELECT strm FROM grps WHERE strm is not	null or strm not like '';"); $i=$feevi=0; $optcls=$optstrm='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){if (mysqli_num_rows($rs)==1) list($feevi)=mysqli_fetch_row($rs);
			}elseif($i==1){while(list($clsno,$clsname)=mysqli_fetch_row($rs)) $optcls.="<option value=\"$clsno\">$clsname</option>";
			}else{while (list($strm)=mysqli_fetch_row($rs)) $optstrm.="<option>$strm</option>";}mysqli_free_result($rs);
		} $i++;
	}while(mysqli_next_result($conn));
	headings('<link rel="stylesheet" type="text/css" href="tpl/css/headers.css"/><link rel="stylesheet" type="text/css" href="/date/tcal.css"/>',0,0,2);
?><div class="head"><form method="post" action="pdf/feeremindergen.php"><a href="home.php"><Img src="img/ani_back.gif" Align="left" Height="25" width="60" hspace="5"></a> Fee Reminder of <select name="cboCls"
	id="cboCls" size="1"><option selected value="%">All</option><?php echo $optcls;?></select> - <select name="cboStream" id="cboStream" size="1"><option selected value="%">All</option><?php echo $optstrm;?></select>
	<label for="adno">&nbsp;for Adm. No.</label>&nbsp;<input type="text" maxlength="5" size="10" name="txtAdmNo" id="txtAdmNo"	value="%">&nbsp;&nbsp;As on &nbsp;&nbsp;<input value="<?php echo date('d-m-Y');?>"
	name="txtDate" id="txtDate" size="8" readonly class="tcal">&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" name="btnAnalysis" name="btnAnalysis" <?php echo (($feevi==0)?"disabled":"");?> onclick="showBalance(1)">
	Fee Balance Status</button>&nbsp;&nbsp;&nbsp;&nbsp;<button type="button"	name="btnStatus" name="btnStatus" <?php echo (($feevi==0)?"disabled":"");?> onclick="showBalance(2)">Current Term's Fee Balance</button>
	&nbsp;&nbsp;&nbsp;&nbsp;<button	type="button"	name="btnNotice" id="btnNotice" <?php echo (($feevi==0)?"disabled":"");?> onclick="showBalance(0)">Fee Balance Notices</button></form>
</div><div class="container" style="background-color:#ddd;border-radius:20px 0">
	<h3 style="text-transform:uppercase;word-spacing:5px;letter-spacing:3px;">Viewing &amp; Printing Fee Bal Reminder</h3>
	<p class="g">Fee Bal Reminder, is a document generated to remind a guardian of school balance of a given pupil and when the balance is expected to be cleared.
	To view and print Fee Bal Reminder either </p><ol type="a"><li>Select class and stream level (Select All in either class or stream level to view fee reminders
	of all pupils),<li>Type the minimum balance of the term (a rminder of any pupil with balance below this will not be generated), <li>Select the date before
	which the balance MUST be settled and <li>Click <b>Fee Bal Reminder</b> command button<br><br><b>or</b><br><br><li>To view and print individual pupil Fee Bal
	Reminder, enter admission number of the pupil and  <li>Click <b>Fee Balance Notices</b> button.</ol>
</div>
<script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript">
	function showBalance(opt){
		let frm=document.querySelector("#cboCls").value,strm=document.querySelector("#cboStream").value, admno=document.querySelector("#txtAdmNo").value;
		let bdate=document.querySelector("#txtDate").value; frm=(frm.length>0?frm:'%'); strm=(strm.length>0?strm:'%');  admno=(admno.length>0?admno:'%');
		window.open('pdf/feeremindergen.php?recno='+opt+'~'+frm+'~'+strm+'~'+admno+'~'+bdate+'~'+Math.random()*1000000,'_blank');
	}
</script>
<?php mysqli_close($conn); footer();?>
