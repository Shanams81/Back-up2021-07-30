<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) {
		header ("Location:vague.php");
	} else {
		include_once('../conn/pri_sch_connect.inc');
		$rs=mysqli_query($conn,"SELECT finyr FROM ss"); list($yr)=mysqli_fetch_row($rs); $yr=isset($yr)?$yr:date('Y'); mysqli_free_result($rs);
		//fee arrears edit priviledges
		$rs=mysqli_query($conn,"SELECT feeview FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
		if(mysqli_num_rows($rs)==1) list($fee)=mysqli_fetch_row($rs); 	mysqli_free_result($rs);
		//feedbacks
		$acayr=isset($_REQUEST['cboYear']) ? strip_tags($_REQUEST['cboYear']):( $yr-1);
		$cls=isset($_REQUEST['CboClass']) ? strip_tags($_REQUEST['CboClass']): "%";
		$st=isset($_REQUEST['CboStream']) ? strip_tags($_REQUEST['CboStream']): "%";
		$adno=isset($_REQUEST['TxtAdmNo']) ? strip_tags($_REQUEST['TxtAdmNo']): "%";	$adno=strlen(trim($adno))>0?$adno:"%";
		$findby=isset($_REQUEST['RadFind']) ? $_REQUEST['RadFind'] : "stud_names";
	}
					
?>
<html>
<head>
	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" /><link href="tpl/headers.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<script type="text/javascript" src="tpl/student.js"></script>
</head>
<body background="img/bg3.gif"><div class="head"><form method="post" action="archpupil.php">Academic Year <SELECT name="cboYear" size="1">
<?php
	$rs=mysqli_query($conn,"SELECT DISTINCT curr_year FROM class WHERE curr_year<$yr ORDER BY curr_year Desc") or die(mysqli_error($conn).' Error in 
	database connection');
	if (mysqli_num_rows($rs)>0) while (list($y)=mysqli_fetch_row($rs)) print "<option>$y</option>"; mysqli_free_result($rs);
	print "</Select> Class <select name=\"CboClass\" size=\"1\" id=\"form\"><option value=\"%\">All</Option>";
	$rsStr=mysqli_query($conn,"SELECT clsno,clsname FROM classnames ORDER BY clsno ASC") or die(mysqli_error($conn).' Error in database connection'); 
	if (mysqli_num_rows($rsStr)>0) while (list($clno,$clsname)=mysqli_fetch_row($rsStr)) print "<option value=\"$clsno\">$clsname</option>";
	mysqli_free_result($rsStr);
	print "</select>-<select name=\"CboStream\" size=\"1\" id=\"stream\"><option selected value=\"%\">All</option>";
	$rsStr=mysqli_query($conn,"SELECT strm FROM grps WHERE strm is not null or strm not like ''") or die(mysqli_error($conn).' Error in database 
	connection'); 
	if (mysqli_num_rows($rsStr)>0) while (list($strm)=mysqli_fetch_row($rsStr)) print "<option>$strm</option>";
	mysqli_free_result($rsStr); 
	print "</select> pupils&nbsp;&nbsp;<b>Or</b> Find Pupil By:&nbsp;&nbsp;<input type=\"radio\" name=\"RadFind\" value=\"admno\">Adm. No.&nbsp;&nbsp;
	<input type=\"radio\" name=\"RadFind\" value=\"stud_names\" checked>Names&nbsp;&nbsp;<input type=\"text\" maxlength=\"17\" size=\"20\" 
	name=\"TxtAdmNo\" id=\"adno\" value=\"%\">&nbsp;&nbsp;<button type=\"submit\" name=\"Stud\">Show Pupils</button>&nbsp;</form></div>";
	if (isset($_POST['Stud']))
		if((strcmp($cls,"%")==0) && (strcmp($st,"%")==0)) $h="All pupils' Details Report"; 
		elseif((strcmp($cls,"%")!=0) && (strcmp($st,"%")==0)) $h="All class $cls pupils' Details Report"; 
		elseif((strcmp($cls,"%")==0) && (strcmp($st,"%")!=0)) $h="All $st stream pupils' Details Report";
		elseif (strcmp($cls,"%")==0) $h=(strcasecmp($st,"%")==0)?"All class $cls Pupils' Details Report":"Class $cls - $st pupils'"; 
		else $h="Pupils' Search Report";
	else
		$h= "Pupil Manager - User Manuals (Please Read)";
	print "<h3>$acayr ".strtoupper($h)."</h3>";
	?>
</body>
</html>
<?php
if (isset($_POST['Stud'])):
	if (strcasecmp($adno,"%")==0){
	 	$sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname,'-',sf.stream,' ',sf.curr_year) As frm,s.dob,s.admdate,s.regdon FROM stud s Inner Join class sf 
		 USING (admno) Inner Join classnames c USING (clsno) WHERE (sf.curr_year LIKE '$acayr' and sf.`clsno` LIKE '$cls' and sf.`stream` LIKE '$st') Order By s.surname,s.onames Asc";
	}else{
		if (strcasecmp($findby,"stud_names")==0) $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname,'-',sf.stream,' ',sf.curr_year) As frm,s.dob,s.admdate,
		s.regdon FROM stud s Inner Join class sf Using (admno) Inner Join classnames c USING (clsno) WHERE ((s.surname LIKE '%$adno%' or s.onames LIKE '%$adno%') and sf.curr_year LIKE 
		'$acayr') Order By s.surname,s.onames Asc";
		else $sql="SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(c.clsname,'-',sf.stream,' ',sf.curr_year) As frm,s.dob,s.admdate,s.regdon FROM `stud` s Inner Join 
		class sf USING (admno) Inner Join classnames c USING (clsno) WHERE (s.admno LIKE '$adno' and sf.curr_year LIKE '$acayr')";
	}
	$rsStud=mysqli_query($conn,$sql);
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\><tr align=\"middle\"><th>Adm.No.</th><th>Names</th><th>Class</th><th>Date of Birth</th><th>
	Admitted On</th><th>Registered On</th><th>Fee Statement</th><th>Main Fee Register</th><th>Misc Fee Register</th></tr>";
	$tb=0; $tm=0; $tu=0; $i=0; $tra=0;
	if (mysqli_num_rows($rsStud)>0):
		while ($rsS=mysqli_fetch_array($rsStud,MYSQLI_NUM)):
			if ($i%2==0) print "<tr>"; else	print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">"; 
			$a=0;	
			foreach($rsS as $sr){
				if (($a<3)):
					if ($a==0) $admno=$sr;
					print "<td>$sr</td>";
				else:
					if($a==5) print "<td>".date("D, d-F-Y  h:m a",strtotime($sr))."</td>"; else print "<td>".date("D, d-F-Y",strtotime($sr))."</td>";
				endif;
				$a++;
			}
			print "<td align=\"center\" valign=\"middle\">".($fee!=0?"<a href=\"arch_feestatement.php?admno=$admno-$acayr\">View</a>":"-")."</td><td 
			align=\"center\" valign=\"middle\">".($fee!=0?"<a href=\"archfeeregister.php?admno=$admno-$acayr-1\">View</a>":"-")."</td><td align=\"center\">".
			($fee!=0?"<a href=\"archfeeregister.php?admno=$admno-$acayr-2\">View</a>":"-")."</td></tr>";
			$i++;
		endwhile;
	else:
		print "<tr><td colspan=\"9\">No pupils' records found</td></tr>";	
	endif;
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"9\" align=\"left\" class=\"b\"><b>".(mysqli_num_rows($rsStud))." $acayr Pupil(s)' Records</b></td></tr></table>";
	mysqli_free_result($rsStud);
	print "Report Generated on ".date("l F d, Y");
else:
	print "<ol type=\"1\"><li>To <b><u>view pupils' in  a given class</u></b> in a given academic year,<ol type=\"a\"><li>Select the academic year<li>Select class 
	whose pupils' are to be viewed, <li>Select the Stream, and<li>Click <b>Show Pupils</b> button.</ol>";
	print "<li>To <b><u>find a given pupil</u></b>,<ol type=\"a\"><li>Select the academic year<li>Select whether to find the pupil by names or admission number,
	<li>Enter the pupil's first/ last name or admission number and <li>Click <b>Show Pupils</b> button.</ol>";
	print "<li>To view <b><u>fee statement</u></b> of a pupil in a given financial year,<ol type=\"a\"><li>Find the pupil whose fee statement is to be viewed 
	<li>In <b>Fee statement</b> column click <font color=\"#0000dd\"><u>View</u></font></ol>";
	print "<li>To view <b><u>fee register</u></b> of a pupil in a given financial year,<ol type=\"a\"><li>Find the pupil whose fee register is to be viewed 
	<li>In <b>Fee Register</b> column click <font color=\"#0000dd\"><u>View</u></font></ol>";
endif;
mysqli_close($conn);
?>