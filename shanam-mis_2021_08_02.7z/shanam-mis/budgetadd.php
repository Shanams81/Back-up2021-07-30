<?php
    include_once('shanam.php');
    if (isset($_POST['CmdSave'])){
        $action=isset($_POST['txtVoAc'])?sanitize($_POST['txtVoAc']):"0-0";         $action=preg_split("/\-/",$action); 	//0 - Votehead No, 1 - account
        $budgno=isset($_POST['txtBudgNo'])?sanitize($_POST['txtBudgNo']):'0-0';     $budgno=preg_split("/\-/",$budgno);	//0-Budget No. [1] -Year [2] Unique add id
        $itmcode=isset($_POST['cboItem'])?sanitize($_POST['cboItem']):0;            $pqty=isset($_POST['txtPQty'])?sanitize($_POST['txtPQty']):0;
        $pup=isset($_POST['txtPUP'])?sanitize($_POST['txtPUP']):0;                  $qty=isset($_POST['txtQty'])?sanitize($_POST['txtQty']):0;
        $up=isset($_POST['txtUP'])?sanitize($_POST['txtUP']):0;                     $pqty=preg_replace("/[^0-9^\.]/","",$pqty);     $qty=preg_replace("/[^0-9^\.]/","",$qty);
        $pup=preg_replace("/[^0-9^\.]/","",$pup);                                   $up=preg_replace("/[^0-9^\.]/","",$up);
        if($_SESSION['newBudg']==$budgno[2]){
            unset($_SESSION['newBudg']);
            if ($itmcode==0){
                $itmname=isset($_POST['txtItem'])?sanitize($_POST['txtItem']):"";       $units=isset($_POST['cboUnits'])?strtoupper(sanitize($_POST['cboUnits'])):"PIECES";
                $max=isset($_POST['txtMax'])?sanitize($_POST['txtMax']):0;              $max=preg_replace("/[^0-9^\.]/","",$max);   $categ=isset($_POST['cboCateg'])?strtoupper(sanitize($_POST['cboCateg'])):"Consumable";
                $min=isset($_POST['txtMin'])?sanitize($_POST['txtMin']):0;              $min=preg_replace("/[^0-9^\.]/","",$min);   $dept=isset($_POST['cboDept'])?sanitize($_POST['cboDept']):0;
                $dept=($dept==0?Null:$dept);    $itmname=strtoupper($itmname);
                if(strlen($itmname)<4 || $max===0 || $min<0 || $up<1 || strlen($categ)<3){
                    print "<h6 style=\"color:#f00;font-weight:bold>EITHER THE DESCRIPTION, STOCK LEVELS OR UNIT PRICE OF THE BUDGET ITEM IS/ARE INVALID</h6>Click <a href=\"budgetadd.php?action=$action[0]-$action[1]\">"
                    . "HERE</a> to try again."; exit(0);
                }$mx=0;
                while($itmcode==0){
                    $rs=mysqli_query($conn,"SELECT max(itmcode) as mx FROM items;");    if(mysqli_num_rows($rs)>0) list($mx)=mysqli_fetch_row($rs); mysqli_free_result($rs); $mx++;
                    $sql="INSERT INTO items(itmcode,itemname,categ,deptno,units,maxstock,minstock,currstock,unitprice,addedon,addedby) VALUES ($mx,'$itmname','$categ',".var_export($dept,true).",'$units',"
                    . "$max,$min,0,$up,curdate(),'".$_SESSION['username']." (".$_SESSION['priviledge'].")');";
                    if(mysqli_query($conn,$sql) or die(mysqli_error($conn)."<br> Click <a href=\"budgetadd.php?action=$action[0]-$action[1]\">HERE</a> to try again.")){
                        $itmcode=$mx;
                        mysqli_query($conn,"INSERT INTO itemvote(itmcode,ac,voteno) VALUES ($itmcode,$action[1],$action[0]);");
                    }
                }
            }$sql="INSERT INTO acc_budgitems (sno,budgno,itmcode,prevqty,prevup,qty,up) VALUES (0,'$budgno[0]','$itmcode','$pqty','$pup','$qty','$up')";
            mysqli_query($conn,$sql) or die(mysqli_error($conn)."<br>$sql Budget Item details were not saved. Click <a href=\"budgetadd.php?action=$action[0]-$action[1]\">Here</a> to try again.");
            $i=mysqli_affected_rows($conn);
            print "<span style=\"background-color:#0a0;color:#fff;margi:0 auto;letter-spacing:1px;word-spacing:2px;font-size:12pt;\">You have sucessfully added $i budget items on the votehead.</span>";
        }
    }else{
        $action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; 	$action=preg_split("/\-/",$action); 	//0 - Votehead, 1 - account
    } mysqli_multi_query($conn,"SELECT b.budgno,a.descr,v.descr FROM acc_budget b Inner JOIN acc_votes v On (b.voteno=v.sno) INNER JOIN acc_voteacs a on (b.acc=a.acno) WHERE b.voteno LIKE '$action[0]' and "
    . "b.acc LIKE '$action[1]'; SELECT finyr FROM ss;");
    $i=0; $votename=$ac=''; $yr=date('Y'); $_SESSION['newBudg']=$addid=uniqid();
    do{
       if($rs=mysqli_store_result($conn)){
           if($i==0){list($budgno,$ac,$votename)=mysqli_fetch_row($rs);
           }else{if(mysqli_num_rows($rs)>0) list($yr)=mysqli_fetch_row($rs);
           } mysqli_free_result($rs);
       } $i++;
    }while(mysqli_next_result($conn));
    headings('<link href="tpl/css/inputsettings.css" type="text/css" rel="stylesheet"/>',0,0,2);
?><div class="container" style="background-color:#e6e6e6;border-radius:15px 15px 0 0;margin:2px auto;width:fit-content;padding:0 5px;">
    <div class="form-row"><div class="col-md-12 divheadings" style="text-align:center;border-radius:15px 15px 0 0"><?php echo strtoupper("FY$yr $ac - $votename BUDGET");?></div></div>
    <div class="form-row"><div class="col-md-12"><form method="post" action="budgetadd.php" onsubmit="return validateFormOnSubmit(this);">
        <div class="container" style="width:650px;border:1px dotted #555;border-radius:10px;padding:10px;margin:5px auto;"><input name="txtVoAc" type="hidden" value="<?php echo "$action[0]-$action[1]";?>"><input
            name="txtBudgNo" type="hidden" value="<?php echo "$budgno-$yr-$addid"; ?>">
            <div class="form-row"><div class="col-md-8">
                <?php   $noi=$i=0; $optCat=$optDept=$optItms='';
                    mysqli_multi_query($conn,"SELECT itmcode,concat(itemname,' - ',units,' @ Kshs.',unitprice) as nam FROM items WHERE itmcode IN (SELECT itmcode FROM itemvote WHERE ac LIKE '$action[1]' and "
                    . "voteno LIKE '$action[0]') and itmcode NOT IN (SELECT itmcode FROM acc_budgitems WHERE budgno LIKE '$budgno') Order By itemname ASC; SELECT categ FROM grps WHERE categ IS NOT NULL or categ "
                    . "Not LIKE '' ORDER BY categ ASC; SELECT deptno,deptname FROM depts WHERE markdel=0;");
                    do{
                        if($rs=mysqli_store_result($conn)){
                           if($i===0){
                               $noi=mysqli_num_rows($rs);
                               if ($noi>0) while (list($cod,$name)=mysqli_fetch_row($rs)) $optItms.="<option value=\"$cod\">$name</option>";
                           }elseif($i==1){
                               if (mysqli_num_rows($rs)>0) while (list($cat)=mysqli_fetch_row($rs)) $optCat.="<option value=\"$cat\" ".(strcasecmp("consumable",$cat)==0?"selected":"").">$cat</option>";
                           }else{
                               if (mysqli_num_rows($rs)>0) while (list($dno,$dname)=mysqli_fetch_row($rs)) $optDept.="<option value=\"$dno\">$dname</option>";
                           }mysqli_free_result($rs);
                        }$i++;
                    }while(mysqli_next_result($conn));
                ?>
                <div class="form-row" <?php echo ($noi==0?"style=\"display:none;\"":"");?>><div class="col-md-12"><label for="cboItem">Select Item Description *</label><SELECT name="cboItem" id="cboItem" size="1"
                    required class="modalinput" onchange="showDescr(this)"><?php echo $optItms; ?><option value="0">Define New Item</option></SELECT></div>
                </div><div class="form-row" id="divOtherDescr" style="border-top:1px solid #66f;border-bottom:1px solid #66f;display:<?php echo ($noi==0?"block":"none");?>"><div class="col-md-12">
                    <div class="form-row"><div class="col-md-12"><label for="txtName">New Item Description</label><input type="text" name="txtItem" id="txtItem" maxlength="29" class="modalinput" value=""></div>
                    </div><div class="form-row">
                        <div class="col-md-8"><label for="txtName">User Department</label><SELECT name="cboDept" id="cboDept" size="1" class="modalinput"><option value="0" selected>General Use</option>
                        <?php echo $optDept;?></SELECT></div>
                        <div class="col-md-4"><label for="cboCateg">Item Category *</label><SELECT name="cboCateg" id="cboCateg" size="1" class="modalinput"><?php echo $optCat;?></select></div>
                    </div>
                    <div class="form-row"><div class="col-md-4"><label for="cboUnits">Units of Measure</label><SELECT name="cboUnits" id="cboUnits" size="1" CLASS="modalinput" required><option value="Pieces">Pieces</option>
                        <option value="crates">Crates</option><option value="Dozen">Dozen</option><option value="Grams">Grams</option><option value="Hours">Hours</option><option value="Days">Days</option><option
                        value="Months">Months</option><option value="Kg">Kg</option><option value="Litres">Litres</option><option value="Metres">Metres</option><option value="Packets">Packets</option><option
                        value="Pairs">Pairs</option><option value="Persons">Persons</option><option value="Sets">Sets</option><option value="Reams">Reams</option><option value="Tonnes">Tonnes</option><option
                        value="Bag">Bag</option><option value="Bales">Bales</option></select></DIV>
                        <div class="col-md-4"><label for="txtMax">Max. Stock Level *</label><Input name="txtMax" id="txtMax" type="text" value="1" maxlength="10" class="modalinput numbersinput" onkeyup="checkInput(this)"
                        required="required"></div>
                        <div class="col-md-4"><label for="txtMax">Min. Stock Level *</label><Input name="txtMin" id="txtMin" type="text" value="10" maxlength="10"  class="modalinput numbersinput" onkeyup="checkInput(this)"
                        required="required"></div>
                    </div>
                    </div></div><br>
                <div class="form-row" style="margin-bottom:5px;"><div class="col-md-4"><label for="txtPQty"><?php echo ($yr-1);?> Actual Qty *</label><input type="text" name="txtPQty"
                    id="txtPQty" required maxlength="10"  value="1" onkeyup="checkInput(this)" onblur="calcAmt(0)" class="modalinput numbersinput"></div>
                    <div class="col-md-4"><label for="txtPUP"><?php echo ($yr-1);?> Actual Unit Cost</label><INPUT name="txtPUP" id="txtPUP" required class="modalinput numbersinput" maxlength="10" value="10.00"
                    onkeyup="checkInput(this)" onblur="calcAmt(0)"></div>
                    <div class="col-md-4 divsubheading"><label for="txtTtlPrev"><?php echo ($yr-1);?> ACTUAL AMT</label><input type="text" name="txtTtlPrev" id="txtTtlPrev" class="modalinput modalinputdisabled numbersinput"
                    value="10.00" readonly></div>
                </div><div class="form-row">
                    <div class="col-md-4"><label for="txtQty"><?php echo $yr;?> Quantity *</label><input type="text" name="txtQty" id="txtQty" required maxlength="10" value="1" onkeyup="checkInput(this)" onblur="claAmt(1)"
                    class="modalinput numbersinput"></div>
                    <div class="col-md-4"><label for="txtUP"><?php echo $yr;?> Unit Cost</label><INPUT name="txtUP" id="txtUP" required class="modalinput numbersinput" maxlength="10" value="10.00"
                    onkeyup="checkInput(this)" onblur="calcAmt(1)"></div>
                    <div class="col-md-4 divsubheading"><label for="txtTtlCur"><?php echo $yr;?> AMOUNT</label><input type="text" name="txtTtlCur" id="txtTtlCur" class="modalinput modalinputdisabled numbersinput"
                    value="10.00" readonly></div>
                </div>
            </div><div class="col-md-4"><br><br><br>
                <div class="form-row"><div class="col-md-12"><button type="submit" name="CmdSave" id="save" class="btn btn-primary btn-block btn-lg">Save Details</button></div></div><br>
                <br><br><div class="form-row"><div class="col-md-12"><button onclick="window.open('budg.php','_self')" type="button" name="CmdClose" class="btn btn-info btn-block btn-lg">
                Close</button>
                </div></div>
            </div></div>
        </div>
    </div></div><div class="form-row"><div class="col-md-12" style="overflow-y:scroll;max-height:300px;">
    <table class="table table-striped table-sm table-hover"><thead class="thead-dark"><tr><th rowspan="2">S/N</th><th colspan="2">ITEM DESCRIPTION</th><th colspan="3">FY<?php echo ($yr-1);?> ACTUALS</th><th
    colspan="3">FY<?php echo $yr; ?> BUDGET ESTIMATES</th><th rowspan="2">Admin<BR>Action</th></tr><tr><th>Item Description</th><th>Units</th><th>Quantity</th><th>Unit Cost</th><th>Amount</th><th>Quantity</th><th>Unit Cost
    </th><th>Amount</th></tr></thead>
    <?php
        $rsBudDet=mysqli_query($conn,"SELECT b.sno,i.itemname,i.Units,b.prevqty,b.prevup,(b.prevqty*b.prevup) as pamt,b.Qty,b.Up,(b.qty*b.up) AS TtlAmt FROM acc_budget bu Inner Join acc_budgitems b USING (budgno) Inner "
        . " Join items i On (b.itmcode=i.itmcode) WHERE (b.markdel=0 and bu.markdel=0 AND bu.voteno LIKE '$action[0]' AND bu.acc LIKE '$action[1]') ORDER BY i.itemname ASC;");
        $ttl=$a=$prevttl=$curttl=0; $i=1;
        while ((list($buno,$itm,$uni,$pqty,$pup,$pamt,$qty,$up,$amt)=mysqli_fetch_row($rsBudDet))):
            print "<td>$i</td><td>$itm</td><td>$uni</td><td align=\"right\">".number_format($pqty,2)."</td><td align=\"right\">".number_format($pup,2)."</td><td align=\"right\"><b>".
            number_format($pamt,2)."</b></td><td align=\"right\">".number_format($qty,2)."</td><td align=\"right\">".number_format($up,2)."</td><td align=\"right\"><b>".number_format($amt,2).
            "</b></td><td align=\"center\"><a href=\"budgetedit.php?action=$buno\">Edit</a></td></tr>";
            if ($a==0){
              $a++; $prevttl+=$pamt;	$curttl+=$amt;
            }
            $ttl+=$amt; $i++;
        endwhile;
        print "<tr bgcolor=\"#eeeeee\"><td colspan=\"3\" style=\"text-align:right;font-weight:bold;\">$votename's Total Budget (Kshs.)</td><td colspan=\"3\" style=\"text-align:right;
        font-weight:bold;\">".number_format($prevttl,2)."</td><td colspan=\"3\" style=\"text-align:right;font-weight:bold;\">".number_format($curttl,2)."</td><td></td></tr></table></div></div>";
    ?>
</div>
<script type="text/javascript" src="tpl/js/budgetadd.js"></script>
<script type="text/javascript"> showNewDescrOnLoad();</script>
<?php mysqli_close($conn); footer();?>
<script type="text/javascript">
    $(document).ready(function(){//for sorting the units of sale
       var opt=$("#cboUnits option").sort(function(a,b){return a.value.toUpperCase().localeCompare(b.value.toUpperCase())});
       $("#cboUnits").append(opt);
    });
</script>
