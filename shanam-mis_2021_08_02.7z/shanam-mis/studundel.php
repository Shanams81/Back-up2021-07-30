<?php
    include_once('shanam.php');
    $adm=isset($_REQUEST['admno'])?sanitize($_REQUEST['admno']):"0-1"; 	$adm=preg_split("/\-/",$adm);//[0] AdmNo, [1] Year and [2] 1-student,0 -Alumni
    if ($adm[2]==1){
      mysqli_multi_query($conn,"UPDATE stud SET markdel=0,present=1,curr_year=$adm[1] WHERE admno LIKE '".$adm[0]."'; UPDATE class SET markdel=0 WHERE admno LIKE '".$adm[0]."' and
      curr_year LIKE '$adm[1]'; SELECT concat(surname,' ',onames) as stud_names FROM stud WHERE admno LIKE '".$adm[0]."'") or die(mysqli_error($conn)." Student's form details not
      sucessfully updated. Please try again!!"); $i=$nor=0;
      do{
         if($i==0 || $i==1)$nor+=mysqli_affected_rows($conn);
         else{$rs=mysqli_store_result($conn); $nam=mysqli_fetch_row($rs);   mysqli_free_result($rs);}$i++;
      }while(mysqli_next_result($conn));
      if($nor>0){print "Congratulation!!!, Adm. No. $adm[0] $nam[0] has been restored. You can now access student record in the MIS software.<br>Click <a href=\"deleted_pupil.php\">
          Here</a> To Go Back";
      }else{print "Sorry!!!, No pupil with the admission number ".$adm[0]." has been restored into the system.<br>Click <a href=\"deleted_pupil.php\">Here</a> To Go Back";}  exit(0);
    }else{
        if (strlen($adm[0])==0 || strcasecmp($adm[0],"0")==0){
          print "Sorry, enter a valid admission number of the student to be registered in this financial year.<br>Click <a href=\"deleted_pupil.php\">Here</a> to go back";
        }else{
          $rsStud=mysqli_query($conn,"SELECT admno,concat(surname,' ',onames) as stud_names,curr_year FROM stud WHERE admno LIKE '".$adm[0]."'");
          if (mysqli_num_rows($rsStud)>0){
            list($ad,$nam,$syr)=mysqli_fetch_row($rsStud);   $sql="UPDATE stud SET markdel=0,curr_year=$adm[1],present=1 WHERE admno LIKE '".$adm[0]."'";
            if ($syr!=$yr) $sql.="UPDATE class SET bbf=alumniarrears WHERE admno LIKE '$adm[0]'; INSERT INTO class (admno,curr_year,clsno,stream,lvlno) SELECT admno,$adm[1],clsno,
            stream,lvlno FROM class WHERE admno LIKE '$adm[0]' and curr_year='$syr'"; else $sql.="UPDATE class SET markdel=0 WHERE admno LIKE '$adm[0]' and curr_year LIKE '$adm[1]'";
            mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"deleted_pupil.php\">HERE</a> to go back."); $a=0;
            do{$a+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn));
            if($a>0) print "$nam has successfully been registered in the academic year $yr. <br>Click <a href=\"deletedstud.php\">Here	</a> To Go Back";
            else print "$nam has NOT been registered in the academic year $yr. <br>Click <a href=\"deleted_pupil.php\">Here</a> To Go Back";
          }else  print "Sorry!!!, student with the admission number ".$adm[0]." has been readmitted.<br>Click <a href=\"deleted_pupil.php\">Here</a> To Go Back";
          mysqli_free_result($rsStud);
        }
    } mysqli_close($conn);
?>
