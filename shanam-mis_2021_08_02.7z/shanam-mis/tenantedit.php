<?php
	declare(strict_types=1); include_once('shanam.php');
	$tenNo=isset($_REQUEST['tno'])?sanitize($_REQUEST['tno']):"0";
	if(isset($_POST['btnSave'])){
		$tno=isset($_POST['txtTNo1'])?sanitize($_POST['txtTNo1']):'0';							$dat=isset($_POST['txtDate1'])?sanitize($_POST['txtDate1']):date('d-m-Y'); $date=preg_split('/\-/',$dat);
		$origtno=isset($_POST['txtInfo1'])?sanitize($_POST['txtInfo1']):'0';					$hno=isset($_POST['txtHNo1'])?sanitize($_POST['txtHNo1']):'0';
		$ht=isset($_POST['cboHType1'])?sanitize($_POST['cboHType1']):'Single Room';	$yr=isset($_POST['txtYr1'])?sanitize($_POST['txtYr1']):date('Y');
		$arr=isset($_POST['txtArrears1'])?sanitize($_POST['txtArrears1']):0;				$rent=isset($_POST['txtRent1'])?sanitize($_POST['txtRent1']):0;
		$furn=isset($_POST['txtFurn1'])?sanitize($_POST['txtFurn1']):0;							$water=isset($_POST['txtWater1'])?sanitize($_POST['txtWater1']):0;
		$elect=isset($_POST['txtElect1'])?sanitize($_POST['txtElect1']):0;					$arr=preg_replace('/[^0-9\.]/','',$arr);	$rent=preg_replace('/[^0-9\.]/','',$rent);
		$furn=preg_replace('/[^0-9\.]/','',$furn);	$water=preg_replace('/[^0-9\.]/','',$water);	$elect=preg_replace('/[^0-9\.]/','',$elect);
		if(strlen($tno)==6 && intval($hno)>0 && floatval($arr)>=0 && floatval($rent)>0 && floatval($furn)>=0 && floatval($water)>=0 && floatval($elect)>=0){
			mysqli_multi_query($conn,"UPDATE acc_tenants SET tno='$tno',entrydate='$date[2]-$date[1]-$date[0]',houseno='$hno',housetype='$ht' WHERE tno LIKE '$origtno'; UPDATE
			acc_tenantrent SET tno='$tno',rent=$rent,arrears=$arr,rentfurn=$furn,rentwater=$water,rentelect=$elect WHERE tno LIKE '$origtno' and yr='$yr';") or die(mysqli_error($conn).
			". Click <a href=\"tenants.php\">HERE</a> to try again."); $i=mysqli_affected_rows($conn); mysqli_next_result($conn); $i+=mysqli_affected_rows($conn); $i=($i>0?1:0);
			$action[1]=$i; 
		}else $action[1]=$i; $action[0]=1;
		header("location:tenants.php?action=$action[0]-$action[1]");
	}	headings('<link rel="stylesheet" href="../date/tcal.css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"/>',0,0,2);
	mysqli_multi_query($conn,"SELECT t.tno,t.houseno,s.idno,concat(s.surname,' ',s.onames,' (',s.designation,')') as st_names,t.entrydate,t.housetype,r.yr,r.arrears, r.rent,r.rentfurn,
	r.rentwater,r.rentelect	FROM stf s Inner Join acc_tenants t USING (idno) Inner Join acc_tenantrent r USING (tno) WHERE t.markdel=0 and t.tno LIKE '$tenNo'; SELECT feedel FROM acc_priv
	WHERE uname LIKE '".$_SESSION['username']."';") or die(mysqli_error($conn).". Click	<a href=\"tenants.php\">HERE</a> to try again.");	$optStf=''; $d=$del=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($d==0)list($tno,$hno,$idno,$nam,$date,$houset,$yr,$arr,$rent,$furn,$water,$elect)=mysqli_fetch_row($rs);
			else list($del)=mysqli_fetch_row($rs); mysqli_free_result($rs);
		}$d++;
	}while(mysqli_next_result($conn));
?><form action="tenantedit.php" method="Post" name="frmTenantsEdit" onsubmit="return validateFormOnSubmit(this)">
	<input type="hidden" name="txtInfo1" id="txtInfo1" value="<?php echo $tenNo;?>">
	<div class="container divmodalmain">
		<div class="form-row">
			<div class="col-md-12 divheadings">EDITING <?php echo "ID NO. $idno $nam";?>'S RENT DETAILS</div>
    </div><div class="form-row">
      <div class="col-md-3"><label for="txtTNo1">Tenant No. *</label><input type="text" name="txtTNo1" id="txtTNo1" value="<?php echo $tenNo;?>" maxlength="3" required
				class="modalinput"></div>
			<div class="col-md-6"></div>
			<div class="col-md-3"><label for="txtDate1">Rented On *</label><input type="text" name="txtDate1" id="txtDate1" value="<?php echo date('d-m-Y',strtotime($date));?>" maxlength="3"
				required	class="tcal modalinput"></div>
		</div><div class="form-row">
      <div class="col-md-3"><label for="txtHNo">House No. *</label><input type="text" name="txtHNo1" id="txtHNo1" maxlength="5" value="<?php echo $hno; ?>" class="modalinput" required
				onkeyup="cleanAmt(this)"></div>
      <div class="col-md-6"><label for="cboHType1">Type of House Rented *</label><SELECT name="cboHType1" id="cboHType1" size="1" class="modalinput"><option <?php
			echo strcasecmp('single room',$houset)==0?"selected":""; ?>>Single Room</option><option <?php echo strcasecmp('single bedroom',$houset)==0?"selected":""; ?>>Single Bedroom</option>
			<option <?php echo strcasecmp('double bedroom',$houset)==0?"selected":""; ?>>Double Bedroom</option><option <?php echo strcasecmp('3 bedroomed house',$houset)==0?"selected":""; ?>>
			3 Bedroomed House</option><option<?php echo strcasecmp('malsion/ bungalow',$houset)==0?"selected":""; ?>>Malsion/ Bungalow</option></SELECT></div>
			<div class="col-md-3"></div>
    </div><div class="form-row">
      <div class="col-md-12 divheadings">DEFINITION OF RENT AMOUNT <input name="txtYr1" id="txtYr1" type="hidden" value="<?php echo $yr; ?>"></div>
    </div><div class="form-row">
			<div class="col-md-3"><label for="txtArrears1">Rent Arrears *</label><input type="text" name="txtArrears1" id="txtArrears1" maxlength="10" value="<?php echo number_format(floatval($arr),
			2);?>" class="modalinput	numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
			<div class="col-md-3"><label for="txtRent1">Monthly Rent *</label><input type="text" name="txtRent1" id="txtRent1" maxlength="10" value="<?php echo number_format(floatval($rent),2);?>"
				class="modalinput numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
			<div class="col-md-3"><label for="txtFurn1">Furniture Rent *</label><input type="text" name="txtFurn1" id="txtFurn1" maxlength="10" value="<?php echo number_format(floatval($furn),2);?>"
				class="modalinput	numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
			<div class="col-md-3"><label for="txtWater1">Water Bill *</label><input type="text" name="txtWater1" id="txtWater1" maxlength="10" value="<?php echo number_format(floatval($water),2);?>"
				class="modalinput	numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
			<div class="col-md-3"><label for="txtElect1">Electricity Bill *</label><input type="text" name="txtElect1" id="txtElect1" maxlength="10" value="<?php echo number_format(floatval($elect),
				2);?>"	class="modalinput	numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
			<div class="col-md-3"></div><div class="col-md-3"></div>
			<div class="col-md-3 divheadings"><label for="txtTotalBill">TOTAL RENT BILL *</label><input type="text" name="txtTotalBill" id="txtTotalBill" maxlength="10" value="<?php echo
				number_format(floatval($arr)+floatval($rent)+floatval($furn)+floatval($water)+floatval($elect),2);?>" class="modalinput numbersinput modalinputdisabled" readonly></div>
		</div><hr><div class="form-row" id="divBtns">
        <div class="col-md-5"><button type="submit" name="btnSave" class="btn btn-primary btn-md btn-block">Save Tenant Details</button></div>
				<div class="col-md-4" style="text-align:right;"><button type="button" class="btn btn-info btn-md" onclick="showDelete(<?php echo $del;?>)" name="cmdDel">Delete</button></div>
        <div class="col-md-3" style="text-align:right;"><button type="button" class="btn btn-info btn-md" onclick="window.open('tenants.php','_self')" 	name="cmdclose">Cancel/Close
				</button></div>
    </div><hr><div class="form-row" id="divDelTenant" style="display:none;">
				<div class="col-md-12">
					<div class="form-row">
						<div class="col-md-12"><label for="txtDelReason">Reason for Deleting Tenant *</label><textarea rows=4 class="modalinput" name="txtDelRmks" id="txtDelRmks"
							onkeyup="checkRmks(this)"	placeholder="Tenant has retired/ transferred"></textarea></div>
					</div><div class="form-row">
		      	<div class="col-md-4"><button type="submit" class="btn btn-block btn-info" name="btnDelete" id="btnDelete" disabled>Delete Tenant</button></div>
						<div class="col-md-4"></div>
			      <div class="col-md-4" style="text-align:right;"><button type="button" class="btn btn-info"	name="btncloseDel" onclick="cancelDel()">Cancel Delete</button></div>
					</div>
				</div>
		</div>
	</div>
	</form>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/tenants.js"></script>
<?php mysqli_close($conn); footer();?>
