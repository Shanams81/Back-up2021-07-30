<?php
  include_once('shanam.php');
  mysqli_multi_query($conn,"SELECT feeview,feeadd,feeedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';SELECT finyr FROM ss;"); $i=0;
	do{if($rs=mysqli_store_result($conn)){	if($i==0) list($viu,$add,$edit)=mysqli_fetch_row($rs);	else list($yr)=mysqli_fetch_row($rs);	mysqli_free_result($rs);}$i++;
}while(mysqli_next_result($conn)); headings('',0,0,2);
?><div class="container" style="width:fit-content;border:1px dashed #fff;border-radius:10px;background-color:#d6d6d6;max-width:950px;"><div class="form-row"><div
  class="col-md-12" style="border:0.5px dotted green;"><form name="frmRF" action="inquirebal.php" method="post"><a href="pupil_manager.php"><img src="../gen_img/ani_back.gif" hspace="1"
  width="45" height="20" align="left"></a>&nbsp;Find Student By <input type="radio" value="admno" checked name="radFind" id="radAdm" onclick="clrText()">Adm. No. &nbsp;&nbsp;<input
  type="radio" value="names" name="radFind" id="radName" onclick="clrText()">Names &nbsp;&nbsp;<input type="radio" value="form" name="radFind" id="radForm" onclick="clrText()">Form &nbsp;
  <input name="txtFind" id="txtFind" type="text" size="12" onkeyup="findStudents(this)"  placeholder="Find Student" title="Type what to find"
  style="background-image:url('../gen_img/search.png');background-position:1px;background-size:25px;background-repeat:no-repeat;width:200px;box-sizing:border-box;font-size:12px;
  padding:2px 4px 2px 30px; border:1px solid #ddd;margin-bottom:12px;"></form></div></div>
<div class="form-row"><div class="col-md-12" style="border:0.5px groove #007;border-radius:20px;max-height:170px;max-width:750px;overflow-y:scroll;"><table id="myTable" class="table
  table-sm table-hover table-striped"><thead class="thead-dark"><tr><th>Adm. No.</td><th>Students Name</th><th>Form</th><th>Arrears</th><th>SurMedical</th><th>Uniform</th><th>Statement
  </th></tr></tfoot><tbody>
<?php
  $rs=mysqli_query($conn,"SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,ar.bf,ar.med,ar.uni FROM stud s INNER JOIN class c
	USING (admno,curr_year) INNER JOIN classnames cn USING (clsno) INNER JOIN (SELECT c.admno,sum(c.bbf+c.miscbf) as bf,sum(c.spemed) as med,sum(c.unifrm) as uni FROM
	class c GROUP BY admno,markdel HAVING markdel=0)ar USING (admno) WHERE s.markdel=0 and s.present=1"); $nostud=mysqli_num_rows($rs);
    if ($nostud>0) while ($data=mysqli_fetch_row($rs)){	$i=0; $admno="";	print "<tr>";
  		foreach($data as $dat){if($i==0) $admno=$dat; if($i<3) print "<td>$dat</td>"; else print "<td align=\"right\">".number_format($dat,2)."</td>";	$i++;}
  		print "<td align=\"center\">".($viu==1?"<a onclick=\"showReceipt($admno,$yr)\" href=\"#\">View</a>":"")."</td></tr>";
  	} mysqli_free_result($rs);
?> </tbody></table></div></div><div class="form-row"><div class="col-md-12" id="spNoStud" style="font-weight:bold;border-bottom:1px solid #00f"><?php echo $nostud;?> Students</div></div>
<div class="form-row"><div class="col-md-12" style=\"border:1px dotted #00a;border-radius:8px;text-align:center;padding:5px;" id="divState">Student Fee Statement will appear here</div>
</div></div><script type="text/javascript" src="tpl/js/recfees.js"></script><script type="text/javascript" src="tpl/js/printthis.js"></script>
<?php mysqli_close($conn); footer();?>
