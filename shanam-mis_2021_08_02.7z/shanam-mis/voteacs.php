<?php
    include_once('shanam.php');
    $sno=isset($_REQUEST['sno'])?strip_tags($_REQUEST['sno']):'0-0'; 	$sno=preg_split('/\-/',$sno); $act="0-0";
    $rs=mysqli_query($conn,"SELECT voteview,voteedit,voteadd,votedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'"); $view=0; $edit=0; $add=0; $del=0;
    if (mysqli_num_rows($rs)>0) list($view,$edit,$add,$del)=mysqli_fetch_row($rs);	mysqli_free_result($rs);
    if($view==0) header("location:vague.php");
    class Accounts{
        private $acno,$abb,$des,$stdas,$salas,$impas,$pytas,$fse,$fs,$withd;
        public function __construct($acn,$ab,$de,$st,$sa,$im,$pa,$g,$fe,$wd){$this->acno=$acn; $this->abb=$ab; $this->des=$de; $this->stdas=$st; $this->salas=$sa; $this->impas=$im;
        $this->pytas=$pa;   $this->fse=$g;   $this->fs=$fe; $this->withd=$wd;} public function valFS(){return $this->fs;} public function valWithdraw(){return $this->withd;}
        public function valAcNo(){return $this->acno;}		public function valAbbr(){return $this->abb;}	public function valDes(){return $this->des;}
        public function valStud(){return $this->stdas;}		public function valSal(){return $this->salas;}	public function valImp(){return $this->impas;}
        public function valPyt(){return $this->pytas;}		public function valFSE(){return $this->fse;}    public function __destruct(){} //release memory
    }
    if (isset($_POST['cmdSave'])|| isset($_POST['btnSaveEdit0'])){
        if(isset($_POST['cmdSave'])){
            $sno=isset($_POST['txtNo'])?sanitize($_POST['txtNo']):0;            $tkn=isset($_POST['txtTkn'])?sanitize($_POST['txtTkn']):0;
            $abbr=isset($_POST['txtAbbr'])?mysqli_real_escape_string($conn,strtoupper(strtoupper(sanitize($_POST['txtAbbr'])))):"";
            $name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(strtoupper(sanitize($_POST['txtName'])))):"";
            $stud=isset($_POST['chkStud'])?sanitize($_POST['chkStud']):0;	$sal=isset($_POST['chkSal'])?sanitize($_POST['chkSal']):0;
            $fs=isset($_POST['chkFeeStruct'])?sanitize($_POST['chkFeeStruct']):0; $wd=isset($_POST['chkWithdraw'])?sanitize($_POST['chkWithdraw']):0;
            $imp=isset($_POST['chkImp'])?sanitize($_POST['chkImp']):0; 	$pyt=isset($_POST['chkPyt'])?sanitize($_POST['chkPyt']):0;  $fse=isset($_POST['chkFSE'])?sanitize($_POST['chkFSE']):0;
        }else{
            $sno=isset($_POST['txtNo1'])?sanitize($_POST['txtNo1']):0;	        $origno=isset($_POST['txtOrigNo1'])?sanitize($_POST['txtOrigNo1']):0;
            $abbr=isset($_POST['txtAbbr1'])?mysqli_real_escape_string($conn,strtoupper(strtoupper(sanitize($_POST['txtAbbr1'])))):"";
            $name=isset($_POST['txtName1'])?mysqli_real_escape_string($conn,strtoupper(strtoupper(sanitize($_POST['txtName1'])))):"";
            $stud=isset($_POST['chkStud1'])?sanitize($_POST['chkStud1']):0;	$sal=isset($_POST['chkSal1'])?sanitize($_POST['chkSal1']):0;
            $fs=isset($_POST['chkFeeStruct1'])?sanitize($_POST['chkFeeStruct1']):0;     $fse=isset($_POST['chkFSE1'])?sanitize($_POST['chkFSE1']):0;
            $imp=isset($_POST['chkImp1'])?sanitize($_POST['chkImp1']):0; $pyt=isset($_POST['chkPyt1'])?sanitize($_POST['chkPyt1']):0;
            $tkn=isset($_POST['txtTkn1'])?sanitize($_POST['txtTkn1']):0; $wd=isset($_POST['chkWithdraw1'])?sanitize($_POST['chkWithdraw1']):0;
        }
        if ($_SESSION['voteACTkn']!==$tkn || strlen($name)<8 || strlen($abbr)<3 || $sno==0){
            print "<h4 style=\"color:#f00;text-align:center;letter-spacing:2px;word-spacing:4px;\">You must enter valid votehead account details before saving.</h4>";
            $act="1-0";
        }else{
            if(isset($_POST['cmdSave'])) $sql="INSERT INTO acc_voteacs(acno,abbr,descr,stud_assoc,sal_assoc,imp_assoc,pyt_assoc,govt_assoc,fee_assoc,wd) VALUES ($sno,
            ".var_export($abbr,true).",".var_export($name,true).",". "$stud,$imp,$sal,$pyt,$fse,$fs,$wd)";
            else $sql="UPDATE acc_voteacs SET acno=$sno,abbr=".var_export($abbr,true).",descr=".var_export($name,true).",stud_assoc=$stud,sal_assoc=$sal,imp_assoc=$imp,fee_assoc=$fs,
            pyt_assoc=$pyt,govt_assoc=$fse,wd=$wd WHERE acno LIKE '$origno'";
            mysqli_query($conn,$sql) or die(mysqli_error($conn). ". New votehead account detail were not saved. Click <a href=\"voteacs.php\">here</a> to go try again.");
            $act="1-".mysqli_affected_rows($conn);
        }unset($_SESSION['voteACTkn']);
    }elseif($sno[0]==1){//delete
        mysqli_query($conn,"UPDATE acc_voteacs SET markdel=1 WHERE acno LIKE '$sno[1]'");	$act="2-".mysqli_affected_rows($conn);
    }
    mysqli_multi_query($conn,"SELECT acno,abbr,descr,stud_assoc,sal_assoc,imp_assoc,pyt_assoc,govt_assoc,fee_assoc,wd FROM acc_voteacs WHERE markdel=0 ORDER BY acno ASC;
    SELECT max(acno) as acno FROM acc_voteacs;");		$i=0; 	$act=preg_split('/\-/',$act);  $tkn=$_SESSION['voteACTkn']=uniqid();
    do{
        if ($rs=mysqli_store_result($conn)){
            if($i==0){$nv=mysqli_num_rows($rs); if ($nv>0) while($d=mysqli_fetch_row($rs)) $accounts[]=new Accounts($d[0],$d[1],$d[2],$d[3],$d[4],$d[5],$d[6],$d[7],$d[8],$d[9]);}
            else{if(mysqli_num_rows($rs)>0) list($nvotno)=mysqli_fetch_row($rs); else $nvotno=0; $nvotno++;}
        }$i++;
    }while(mysqli_next_result($conn));
    headings('<link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet" href="tpl/css/inputsettings.css" type="text/css"/>',$act[0],$act[1],2);
?>
 <div class="container" style="margin:auto;border:0px;top:150px;padding:5px;max-width:900px;">
    <div class="form-row"><div class="col-md-12"><FORM action="voteacs.php" name="Adding" Method="POST" onsubmit="return validateFormOnSubmit(this)">
      <div class="container" style="margin:0 auto;border:0px;background-color:#eee;border-radius:10px;padding:5px;max-width:700px;">
        <div class="form-row"><div class="col-md-12" style="background:#444;color:#fff;word-spacing:4px;letter-spacing:2px;font-weight:bold;text-align:center;">
        VOTEHEAD ACCOUNTS DEFINITION INTERFACE <input type="hidden" name="txtNo" value="<?php echo $nvotno; ?>"></div>
      </div><div class="form-row"><input type="hidden" name="txtTkn" value="<?php echo $tkn; ?>">
        <div class="col-md-8">
            <div class="form-row">
                <div class="col-md-12"><label for="txtAbbr">Account Abbreviation *</label><Input name="txtAbbr" id="txtAbbr" type="text" value="" required placeholder="Abbreviation"
                maxlength=14 required class="modalinput"></div>
            </div><div class="form-row">
                <div class="col-md-12"><label for="txtName">Account Full Name *</label><Input name="txtName" id="txtName" type="text" value="" required maxlength=50
                placeholder="Full Name"  class="modalinput"></div>
            </div><div class="form-row">Type of Account
                <div class="col-md-12 form-inline"><input type="checkbox" name="chkStud" id="chkStud" value=1 class="form-control">Student A/C &nbsp;&nbsp;&nbsp;<input type="checkbox"
                name="chkSal" id="chkSal" value=1 class="form-control">Salary A/C &nbsp;&nbsp;&nbsp;<input type="checkbox" name="chkImp" id="chkImp" value=1 class="form-control">Imprest A/C
                &nbsp;&nbsp;&nbsp;<input type="checkbox" name="chkPyt" id="chkPyt" value=1 class="form-control">Payments A/C  &nbsp;&nbsp;&nbsp;<input type="checkbox" name="chkFSE"
                 id="chkFSE" value=1 class="form-control">FSE A/C &nbsp;&nbsp;&nbsp;<input type="checkbox" name="chkFeeStruct" id="chkFS" value=1 class="form-control">Fees A/C&nbsp;&nbsp;
                 &nbsp;<input type="checkbox" name="chkWithdraw" id="chkWithdraw" value=1 class="form-control">Withdrawal A/C</div>
            </div>
        </div><div class="col-md-4"><br>
            <div class="form-row"><div class="col-md-12"><button type="submit" name="cmdSave" <?php echo ($add==0?"disabled":"");?> class="btn btn-primary btn-md btn-block">
            Save A/C Details</button></div></div><br>
            <div class="form-row"><div class="col-md-12"><button name="cmdCancel" type="reset"  class="btn btn-info btn-md btn-block">Cancel</button></div></div><br><br>
            <div class="form-row"><div class="col-md-12" style="text-align:right;"><a href="settings_manager.php"><button name="cmdClose" type="button"  class="btn btn-info btn-md">
              Close</button></a></div></div>
        </div>
    </div></div></form></div>
    </div><div class="form-row"><div class="col-md-12" style="background-color:#000;color:#fff;word-spacing:6px;letter-spacing:4px;font-size:10pt;font-weight:bold;
    text-align:center;">LIST  OF VOTE HEAD ACCOUNTS</div></div>
    <div class="form-row"><div class="col-md-12" style="background-color:#d9d9d9;padding:3px;border-radius:10px;">
        <table class="table table-striped table-bordered table-hover table-sm"><thead class="thead-dark"><tr><th>ABBREVIATION</th><th>FULL NAME</th><th>STUDENT A/C</th><th>SALARY A/C
        </th><th>IMPREST A/C</th><th>EXPENSE A/C</th><th>FSE A/C</th><th>FEES A/C</th><th>WITHDRAWAL A/C</th><th>ACTION</th></tr></thead><tbody>
        <?php
            if (isset($accounts)){
                foreach($accounts as $acc) print "<tr><td>".$acc->valAbbr()."</td><td>".$acc->valDes()."</td><td align=\"center\">".($acc->valStud()==1?"&#x2611; Yes":"&#x274c; No").
                "</td><td align=\"center\">".($acc->valSal()==1?"&#x2611; Yes":"&#x274c; No")."</td><td align=\"center\">".($acc->valImp()==1?"&#x2611; Yes":"&#x274c; No")."</td><td
                align=\"center\">".($acc->valPyt()==1?"&#x2611; Yes":"&#x274c; No")."</td><td align=\"center\">".($acc->valFSE()==1?"&#x2611; Yes":"&#x274c; No")."</td><td
                align=\"center\">".($acc->valFS()==1?"&#x2611; Yes":"&#x274c; No")."</td><td align=\"center\">".($acc->valWithdraw()==1?"&#x2611; Yes":"&#x274c; No")."</td><td
                align=\"center\">".($edit==1?"<span onclick=\"showModal(".($acc->valAcNo()).",$del)\" class=\"spedit\">&#x270d;</span>":"-")."</td></tr>";
            } print "</tbody><tfoot class=\"thead-light\"><tr><td colspan=\"13\">$nv Registered Account(s)</td></tr></tfoot></table>";
        ?>
    </div></div>
 </div>
<div id="accountEdit" class="modal">
    <FORM action="voteacs.php" name="FrmAdding" Method="POST" onsubmit="return validateFormOnSubmit1(this)">
    <div class="imgcontainer"><span onclick="document.getElementById('accountEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span></div><br/>
    <div class="container divmodalmain"><input type="hidden" name="txtTkn1" value="<?php echo $tkn; ?>">
        <div class="form-row" style="margin:auto;top:150px;font-size:11pt;border:0px;padding:10px;border-collapse:collapse;color:#000;" class="h"><div class="col-md-12" style="color:#fff;
        background-color:#333;word-spacing:4px;letter-spacing:2px;font-size:13pt;font-weight:bold;text-align:center;">VOTEHEAD ACCOUNT EDITOR</div></div><input name="txtOrigNo1"
        id="txtOrigNo1" type="hidden" value="">
        <div class="form-row">
            <div class="col-md-6"><label for="txtNo1">Serial No. *</label><Input name="txtNo1" id="txtNo1" type="text" value="" readonly class="modalinput" maxlength="5"></div>
            <div class="col-md-6"><label for="txtAbbr1">Account Abbreviation *</label><Input name="txtAbbr1" id="txtAbbr1" type="text" value="" required maxlength="14"
            class="modalinput"></div>
        </div>
        <div class="form-row">
            <div class="col-md-12"><label for="txtName1">Account Full Name *</label><Input name="txtName1" id="txtName1" type="text" value="" required maxlength="50" class="modalinput"></div>
        </div>
        <div class="form-row">
            <div class="col-md-12"><label for="chkStud1">Type of Account *</label>
            <div><label class="checkbox-inline"><input type="checkbox" name="chkStud1" id="chkStud1" value=1>Student A/C</label>&nbsp;&nbsp;&nbsp;<label class="checkbox-inline"><input
            type="checkbox" name="chkSal1" id="chkSal1" value=1>Salary A/C</label>&nbsp;&nbsp;&nbsp;<label class="checkbox-inline"><input type="checkbox" name="chkImp1" id="chkImp1" value=1>
            Imprest A/C</label>&nbsp;&nbsp;&nbsp;<label class="checkbox-inline"><input type="checkbox" name="chkPyt1" id="chkPyt1" value=1>Expenditure A/C</label>&nbsp;&nbsp;&nbsp;<label
            class="checkbox-inline"><input type="checkbox" name="chkFSE1" id="chkFSE1" value=1>FSE A/C</label>&nbsp;&nbsp;&nbsp;<label class="checkbox-inline"><input type="checkbox"
            name="chkFeeStruct1"  id="chkFS1" value=1>Fees A/C</label><br><label class="checkbox-inline" for="chkWithdraw1"><input type="checkbox" name="chkWithdraw1" id="chkWithdraw1"
            value=1 class="form-control">Withdrawal A/C</label></div>
          </div>
        </div><br>
        <div class="form-row">
            <div class="col-md-6"><button type="submit" class="btn btn-primary btn-block btn-md" name="btnSaveEdit0">Save Changes</button></div><div class="col-md-3" id="btnDelete"
            style="text-align:center;"></div>
            <div class="col-md-3" style="text-align:right;"><button type="button" onclick="document.getElementById('accountEdit').style.display='none'"  class="btn btn-info btn-md">
            Close/ Cancel</button></div>
        </div>
    </div>
    </form>
</div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/voteacs.js"></script>
<script type="text/javascript">
<?php
    if (isset($accounts)){
        $arr=""; $i=0;
        foreach($accounts as $acc){
            $arr.=($i==0?"":",")."new Accounts(".($acc->valAcNo()).",\"".($acc->valAbbr())."\",\"".($acc->valDes())."\",".($acc->valStud()).",".($acc->valSal()).",".($acc->valImp()).",".
             ($acc->valPyt()).",".($acc->valFSE()).",".($acc->valFS()).",".($acc->valWithdraw()).")";
            $i++;
        }if (strlen($arr)>0) print "accounts.push($arr);";
    }print "</script>"; mysqli_close($conn); footer();
?>
