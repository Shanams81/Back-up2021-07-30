<?php
	session_start();
	if (!isset($_SESSION['username']) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if(isset($_POST['CmdClose'])){
		header("location:users.php?action=0-0");
	}elseif(isset($_POST['CmdSave'])){
	   	$idno=isset($_POST['CboUser'])?$_POST['CboUser']:''; 				$ln=isset($_POST['TxtUsername'])?$_POST['TxtUsername']:''; 
		$pw=isset($_POST['TxtPassword'])?$_POST['TxtPassword']:'000000';	$sec=isset($_POST['CboPriv'])?$_POST['CboPriv']:'1';
		$title=isset($_POST['CboTitle'])?$_POST['CboTitle']:'Member'; 		$expdate=date("Y-m-d",strtotime("+2days"));
		$addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
		if (($idno=='') || ($ln=='') || ($pw=='')){
			print "Ensure you have selected user, entered login name and password before saving";
		}else{
			mysqli_query($conn,"INSERT INTO login (username,pw,section,expirydate,idno,priviledge,addedby) VALUES ('$ln',md5('$pw'),'$sec','$expdate','$idno',
			'$title','$addby')") or die(mysqli_error($conn)." User details not saved. Click <a href=\"useradd.php\">Here</a> to try again.");
			$i=mysqli_affected_rows($conn);
			if ($i==1){
				mysqli_query($conn,"INSERT INTO gen_priv(uname) Values('$ln')");
				mysqli_query($conn,"INSERT INTO acc_priv(uname) Values('$ln')");
			}
			header("location:users.php?action=1-$i");
		}
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>System Users</title>
		<script type="text/javascript" src="tpl/useredit.js"></script>
		<STYLE type="text/css">
			table{border:3px solid green;border-collapse:collapse; border:outset 3px;font-size:12px;}
			td,th{letter-spacing:1.5px;word-spacing:2px;border-right:hidden;border-left:hidden;border-top:hidden;border-bottom:hidden;}
		</style>
    </head>
<body background="img/bg3.gif">
	<?php
        print "<form method=\"post\" action=\"UserAdd.php\" onsubmit=\"return validateData(this);\"><table border=\"0\" cellpadding=\"2\" cellspacing=\"2\" 
		align=\"center\"><tr><th colspan=\"3\"><h2>AUTHETIC SYSTEM USER MANAGEMENT</h2></th></tr><tr><td align=\"right\">Choose Staff Member</td><td>
		<SELECT name=\"CboUser\" size=\"1\">";
    	$rsUser=mysqli_query($conn,"SELECT idno,concat(surname,' ',onames,' (',designation,')') as st FROM stf WHERE ((idno Not In (SELECT idno FROM login WHERE idno is not 
		null)) and markdel=0 and type=0) ORDER BY surname,onames Asc");
        while ($dat=mysqli_fetch_row($rsUser)) print "<Option value=\"$dat[0]\">$dat[1]</option>";  mysqli_free_result($rsUser);
        print "</SELECT></td><td rowspan=\"2\" valign=\"middle\"><button name=\"CmdSave\">Save User<br>Details</button></td></tr>";
        print "<tr><td align=\"right\">Login User Name (4 - 12 Characters)</td><td><input type=\"text\" name=\"TxtUsername\" value=\"\" size=\"15\" maxlength=\"12\">
		</td></tr><tr><td align=\"right\">User Password (4 - 12 Characters)</td><td><input type=\"password\" name=\"TxtPassword\" size=\"15\" maxlength=\"12\"></td>
		<td rowspan=\"3\" valign=\"middle\"><button name=\"CmdClose\">Close<br>Form</button></td></tr>";
        print "<tr><td align=\"right\">User Section</td><td><SELECT name=\"CboPriv\" size=\"1\"><Option value=\"0\">0 - Admin</option><Option value=\"1\" selected>
		1 - Accounts</option><Option value=\"2\">2 - Exams</option><Option value=\"3\">3 - Stores</option><Option value=\"4\">4 - Discipline</option><Option 
		value=\"5\">5 - Guiding And Counselling</option><Option value=\"6\">6 - Library Services</option></SELECT></td></tr><tr><td align=\"right\">User's Title</td><td><SELECT 
		name=\"CboTitle\" size=\"1\"><option>Accounts Clerk</option><option>Bursar</option><option>Class Teacher</option><option>Deputy Principal</option><option>Director</option><option>
		HOD</option><option>Librarian</option><option>Principal</option><option>Secretary</option><option>Senior Teacher</option><option>Store Keeper</option><option>Member</option></select>
		</td></tr></table>";
        mysqli_close($conn);		
	?>
</body>
</html>