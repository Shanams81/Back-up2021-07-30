<?php
	declare(strict_types=1); include_once('shanam.php');
	$action=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0";	$action=preg_split("/\-/",$action);
	if(isset($_POST['btnSave'])){
		$tno=isset($_POST['txtTNo1'])?sanitize($_POST['txtTNo1']):'0';							$dat=isset($_POST['txtDate1'])?sanitize($_POST['txtDate1']):date('d-m-Y'); $date=preg_split('/\-/',$dat);
		$stf=isset($_POST['cboStf1'])?sanitize($_POST['cboStf1']):'0';							$hno=isset($_POST['txtHNo1'])?sanitize($_POST['txtHNo1']):'0';
		$ht=isset($_POST['cboHType1'])?sanitize($_POST['cboHType1']):'Single Room';	$yr=isset($_POST['txtYr1'])?sanitize($_POST['txtYr1']):date('Y');
		$arr=isset($_POST['txtArrears1'])?sanitize($_POST['txtArrears1']):0;				$rent=isset($_POST['txtRent1'])?sanitize($_POST['txtRent1']):0;
		$furn=isset($_POST['txtFurn1'])?sanitize($_POST['txtFurn1']):0;							$water=isset($_POST['txtWater1'])?sanitize($_POST['txtWater1']):0;
		$elect=isset($_POST['txtElect1'])?sanitize($_POST['txtElect1']):0;					$arr=preg_replace('/[^0-9\.]/','',$arr);	$rent=preg_replace('/[^0-9\.]/','',$rent);
		$furn=preg_replace('/[^0-9\.]/','',$furn);	$water=preg_replace('/[^0-9\.]/','',$water);	$elect=preg_replace('/[^0-9\.]/','',$elect);
		if(strlen($tno)==6 && strlen($stf)>4 && intval($hno)>0 && floatval($arr)>=0 && floatval($rent)>0 && floatval($furn)>=0 && floatval($water)>=0 && floatval($elect)>=0){
			if(mysqli_query($conn,"INSERT INTO acc_tenants(tno,idno,entrydate,houseno,housetype,regdon,addedby,MarkDel) VALUES ('$tno','$stf','$date[2]-$date[1]-$date[0]','$hno','$ht',curdate(),'".$_SESSION["username"]." (".
				$_SESSION["priviledge"].")',0)") or die(mysqli_error($conn).". Click <a href=\"tenants.php\">HERE</a> to try again.")){
				mysqli_query($conn,"INSERT INTO acc_tenantrent(tno,yr,rent,arrears,rentfurn,rentwater,rentelect) VALUES ('$tno','$yr',$rent,$arr,$furn,$water,$elect)") or die(mysqli_error($conn).". Click <a href=\"tenants.php\">
				HERE</a> to try again.");			$action[0]=1;	$action[1]=1;
			}else{print "<br>Rent details not saved due to errors in data. Click <a href=\"tenants.php\">HERE</a> to try again."; exit(0);}
		}else{print "<br>Rent details not saved due to errors in data. Click <a href=\"tenants.php\">HERE</a> to try again."; exit(0);}
	}
	mysqli_multi_query($conn,"SELECT feeview,feeadd,feeedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT tno FROM acc_tenants ORDER BY tno DESC LIMIT 0,1;
	SELECT finyr FROM ss; SELECT sno FROM `acc_votes` WHERE abbr LIKE 'rent' ORDER BY abbr ASC;");
	$viu=$add=$edi=$i=$rentno=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){ if (mysqli_num_rows($rs)>0) list($viu,$add,$edi)=mysqli_fetch_row($rs);
			}elseif($i==1){$tenNo='T00000'; if (mysqli_num_rows($rs)>0) list($tenNo)=mysqli_fetch_row($rs);	$tno=intval(substr($tenNo,1))+1; $tenNo=strval($tno);
				switch (strlen($tenNo)){case 1:$tenNo='T0000'.$tenNo;break;case 2:$tenNo='T000'.$tenNo; break;case 3:$tenNo='T00'.$tenNo; break;
				case 4:$tenNo='T0'.$tenNo; break; default:$tenNo='T'.$tenNo; break;}
			}elseif($i==2){ list($finyr)=mysqli_fetch_row($rs);}else{$rentno=mysqli_num_rows($rs);}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	if($rentno==0){//If rent votehead has not been defined
		echo "<h3 style=\"color:#f00;\">RENT VOTEHEAD HAS NOT BEEN DEFINED!!!. Click <a href=\"votes.php\">HERE</a> to define it.</h3>"; exit(0);
	}	headings('<link rel="stylesheet" href="../date/tcal.css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"/><link rel="stylesheet" href="tpl/css/modalfrm.css"/>',
	$action[0],$action[1],2);
?><br><div class="container divlrborder" style="background-color:#e6e6e6;">
<h2 style="font-size:12pt;color:#fff;background-color:#000;letter-spacing:6px;word-spacing:8px;text-align:center;">TENANTS MANAGEMENT INTERFACE</h2>
<ul class="nav nav-tabs" id="myTabs">
		<li class="nav-item active"><a class="nav-link active" data-toggle="tab" id="tenant-tab" href="#tenants">TENANTS</a></li>
		<li class="nav-item"><a class="nav-link" data-toggle="tab" id="rent-tab" href="#rent">RENT RECEIPT</a></li>
		<li class="nav-item"><a class="nav-link" data-toggle="tab" id="register-tab" href="#register">RENT REGISTER</a></li>
</ul>
<div class="tab-content divmain" id="myTabContent">
	<div id="tenants" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tenant-tab">
		<div class="form-row"><div class="col-md-12 divlrborder divsubheading"><form name="frmFind" action="#" method="post">
		Find Tenants By&nbsp;<input type="radio" name="radFind" id="radIDNo" value="idno" onclick="clrText()">ID No.&nbsp; <input type="radio" name="radFind" id="radName"
		value="names" checked onclick="clrText()">Names &nbsp; <input type="radio" name="radFind" id="radHouseNo"	value="houseno" onclick="clrText()">House No. &nbsp;&nbsp; <input type="text"
		maxlength="17" size="30" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Type/ Enter what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;">
		&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-primary btn-md" type="button" name="btnNew" onclick="document.querySelector('#divNewTenant').style.display='block'" style="float:right;">
		Add New Tenant</button>
		</form></div></div>
		<div class="form-row"><div class="col-md-12"><h5>LIST OF REGISTERED TENANTS</h5></div></div>
		<div class="form-row"><div class="col-md-12" style="max-height:350px;overflow-y:scroll;" id="divTenants">
			<table id="myTable" class="table table-sm table-hover table-bordered table-striped"><thead class="thead-dark"><tr><th colspan="5">DETAILS OF TENANT</th><th colspan="3">DETAILS OF RENT
			BILL</th><th colspan="3">ADMIN ACTION</th></tr><tr><th>HOUSE<br>NO.</th><th>ID. NO.</th><th>NAME OF TENANT</th><th>RENTED ON</th><th>TYPE OF HOUSE</th><th>ARREARS</th><th>RENT</th><th>
			TOTAL</th><th colspan="2">RENT DETAILS</th><th>RENT</th></tr></thead><tbody>
			<?php
				mysqli_multi_query($conn,"SELECT a.acno,a.abbr FROM acc_voteacs a Inner Join acc_votes v ON (a.acno=v.acc) WHERE v.abbr LIKE 'rent'; SELECT idno,concat(s.surname,' ',s.onames,' (',
				s.designation,')') as st_names FROM stf s WHERE markdel=0 and present=1 and idno NOT IN (SELECT idno FROM acc_tenants WHERE markdel=0); SELECT t.tno,t.houseno,s.idno,concat(s.surname,
				' ',s.onames) as st_names,t.entrydate,t.housetype,r.arrears, (r.rent+r.rentfurn+r.rentwater+r.rentelect) as rent FROM stf s Inner Join acc_tenants t USING (idno) Inner Join
				acc_tenantrent r USING (tno) WHERE t.markdel=0 ORDER BY t.houseno ASC;") or die(mysqli_error($conn).". Click	<a href=\"tenants.php\">HERE</a> to try again.");
				$optStf=''; $d=0; $optac='<option value="%">All</option>';
				do{
					if($rs=mysqli_store_result($conn)){
						if($d===0) while($da=mysqli_fetch_row($rs)) $optac.='<option value="'.$da[0].'">'.$da[1].'</option>';
						elseif($d===1) while($da=mysqli_fetch_row($rs)) $optStf.='<option value="'.$da[0].'">'.$da[1].'</option>';
						else{
							$i=mysqli_num_rows($rs);	$ttl=[0,0,0,0,0];
							if ($i>0){
								while (list($tno,$hno,$idno,$nam,$date,$houset,$arr,$rent)=mysqli_fetch_row($rs)){
									print "<tr><td align=\"center\">$hno</td><td align=\"center\">$idno</td><td>$nam</td><td align=\"right\">".date('D d M, Y',strtotime($date))."</td><td valign=\"top\">
									$houset</td><td align=\"right\">".number_format(floatval($arr),2)."</td><td align=\"right\">".number_format(floatval($rent),2)."</td><td align=\"right\">".
									number_format((floatval($arr)+floatval($rent)),2)."</td><td align=\"center\"><a href=\"#\" onclick=\"rentRegister(1,'$tno')\" title=\"View Rent Register\">View Register</a>
									</td><td	align=\"center\"><a	onclick=\"return canEdit($edi)\" href=\"tenantedit.php?tno=$tno\">Edit</a></td><td align=\"center\"><a  onclick=\"return canAdd($add)\"
									href=\"tenantrentreceive.php?tno=0-$tno-0-0\">Receive Rent</a></td></tr>";	$ttl[0]+=$arr;	$ttl[1]+=$rent; 	$ttl[2]+=$arr+$rent;
								}
							}else{print "<tr><td colspan=\"12\">Sorry, No tenants exists.</td></tr>";	}
							print "<tbody><tfoot class=\"thead-light\"><tr><td colspan=\"3\">$i Tenant Record(s)</td><td colspan=\"2\" align=\"right\"><b>Total (Kshs.)</b></td>";
							foreach ($ttl as $val) print "<td	style=\"font-weight:bold;text-align:right;\">".number_format($val,2)."</td>";
							print "<td colspan=\"2\"></td></tr></tfoot></table>";
						}mysqli_free_result($rs);
					}$d++;
				}while(mysqli_next_result($conn));
			?></div></div>
		<div class="form-row"><div class="col-md-12" id="divRentRegIndiv" style="max-height:350px;overflow-y:scroll;">
				<!-- ------------------------------------------INDIVIDUAL TENANT'S REGISTER APPEARS HERE---------------------------------------------------- -->
		</div></div>
		<div class="form-row">
			<div class="col-md-12" style="text-align:center;margin:1px;"><a href="#" onclick="printSpecific('divRentRegIndiv')" style="float:right;display:none;" id="printIReg"><img height=25
			src="/gen_img/print.ico" width=25 alt="Print Report">Print Register</a></div>
		</div>
	</div><div id="rent" class="tab-pane fade show" role="tabpanel" aria-labelledby="rent-tab">
		<div class="form-row">
			<div class="col-md-12 divlrborder divsubheading"><form name="frmFindRent" action="#" method="post">View Rent Recieved In <SELECT name="cboAC" id="cboAC" size="1"><?php echo $optac;?></SELECT>
				A/C Between &nbsp;<input type="TEXT" name="txtFrom" id="txtFrom" value="<?php echo date('d-m-Y',strtotime('-30days'));?>" class="tcal" size="9"> And <input type="TEXT" name="txtTo"
				id="txtTo" value="<?php echo date('d-m-Y');?>" class="tcal"size="9"> <button class="btn btn-primary btn-md" type="button" name="btnNew" onclick="showRentPaid()">Show Rent Paid
				</button></form>
			</div>
		</div><hr><div class="form-row"><div class="col-md-12" style="max-height:500px;overflow-y:scroll;" id="divRentPaid">
			<h5>RENT RECEIVED BETWEEN <?php echo strtoupper(date('D d M, Y',strtotime('-30days'))).' AND '.strtoupper(date('D d M, Y'));?></h5>
			<table class="table table-bordered table-striped table-hover table-sm"><thead class="thead-dark"><tr><th>RECEIPT</th><th>RECEIVED ON</th><th>ID NO.</th><th>NAMES</th><th>ACCOUNT</th>
				<th>MODE</th><th>MODE NO.</th><th>ARREARS</th><th>RENT</th><th>TOTAL</th><th colspan="2">ADMIN ACTION</th></tr></thead><tbody>
				<?php $rs=mysqli_query($conn,"SELECT * FROM (SELECT f.recno,f.recon as pytdate,s.idno,concat(s.surname,' ',s.onames) as names,a.abbr,f.mode,f.modeno,f.arrears,f.amt,(f.arrears+f.amt)
				as ttl,f.acc,f.recno as sno FROM acc_fseincome f Inner Join acc_tenants t ON (f.interb_no=t.tno) Inner Join stf s ON (t.idno=s.idno) INNER JOIN acc_voteacs a ON f.acc=a.acno WHERE
				f.markdel=0	and (f.recon BETWEEN '".date('Y-m-d',strtotime('-30days'))."' and curdate()) UNION SELECT i.recno,f.pytdate,s.idno,concat(s.surname,' ',s.onames) as names,a.abbr,f.pytfrm
				as mode,f.cheno as modeno,i.arrears,i.amt,(i.arrears+i.amt) as ttl,i.acc,f.sno FROM acc_incofee f Inner JOIN acc_incorecno0 i USING (sno) INNER JOIN acc_tenants t ON (f.admno=t.tno) INNER
				JOIN stf s ON (t.idno=s.idno) INNER JOIN acc_voteacs a ON i.acc=a.acno WHERE f.markdel=0 and (f.pytdate BETWEEN '".date('Y-m-d',strtotime('-30days'))."' and curdate()))s ORDER
				BY recno DESC;"); $tarr=$trent=$tttl=0; $nor=mysqli_num_rows($rs);
				while (list($recno,$date,$idno,$names,$acc,$mode,$modeno,$arr,$rent,$ttl,$acno,$sno)=mysqli_fetch_row($rs)){
					$nod=(strtotime(date('Y-m-d'))-strtotime($date))/86400;
					echo "<tr><td>$recno</td><td>".date('d-M-Y',strtotime($date))."</td><td>$idno</td><td>$names</td><td>$acc</td><td>$mode</td><td>$modeno</td><td align=\"right\">".
					number_format(floatval($arr),2)."</td><td align=\"right\">".number_format(floatval($rent),2)."</td><td align=\"right\">".number_format(floatval($ttl),2)."</td><td
					align=\"center\"><a target=\"_blank\" href=\"rpts/rentreceipt.php?recno=$sno-1-$acno-".uniqid()."\"><img src=\"/gen_img/print.ico\" height=\"15\" width=\"15\">Print</a></td><td
					align=\"center\">".($nod<3?"<a onclick=\"canEdit($edi)\" href=\"tenantrentreceive.php?tno=1-0-$sno-$acno\">Edit</a>":"")."</td></tr>"; $tarr+=floatval($arr);
					$trent+=floatval($rent);	$tttl+=floatval($ttl);
				}mysqli_free_result($rs);
				?></tbody><tfoot class="thead-light"><tr><th colspan="3"><?php echo $nor;?> RENT INCOME RECIEPT(S)</th><th colspan="4"  align="right">SUBTOTALS (KSHS.)</th><?php echo "<th
				align=\"right\">".number_format($tarr,2)."</th><th align=\"right\">".number_format($trent,2)."</th><th align=\"right\">".number_format($tttl,2)."</th>";?><th></th></tr></tfoot>
			</table>
		</div></div><hr>
		<div class="form-row">
			<div class="col-md-12" style="text-align:right;margin:1px;"><a href="#" onclick="printSpecific('divRentPaid')" style="float:right;display:none;" id="printH"><img height=25
			src="/gen_img/print.ico" width=25 alt="Print Report">Print Report</a></div>
		</div>
	</div><div id="register" class="tab-pane fade show" role="tabpanel" aria-labelledby="register-tab">
		<div class="form-row"><div class="col-md-12 divlrborder divsubheading"><form name="frmRegFind" action="#" method="post">
			Find Tenant Register By&nbsp;<input type="radio" name="radRegFind" id="radRegIDNo" value="idno" onclick="clrText()">National ID No.&nbsp; &nbsp; <input type="radio" name="radRegFind"
			id="radRegHouseNo"	value="houseno" onclick="clrText()">House No. &nbsp;&nbsp; <input type="text"	maxlength="17" size="30" name="txtRegFind" id="txtRegFind" value=""
			placeholder="Type/ Enter what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;">&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-primary btn-md" type="button"
			name="btnRegFind" onclick="rentRegister(0,'tno')">Show Register</button></form></div>
		</div><div class="form-row"><div class="col-md-12" id="divRentReg" style="max-height:550px;overflow-y:scroll;">
			<!-- -----------------------------------------------RENT REGISTER WILL BE LOADED HERE----------------------- -->
			RENT REGISTER WILL BE DISPLAYED HERE
		</div></div><div class="form-row">
			<div class="col-md-12"  style="text-align:right;margin:1px;"><a href="#" onclick="printSpecific('divRentReg')" style="float:right;display:none;" id="printAll"><img height=25
			src="/gen_img/print.ico" width=25 alt="Print Report">Print Report</a></div>
		</div>
	</div><div class="form-row"><div class="col-md-12"><hr><button type="button" name="btnClose" onclick="window.open('stf_manager.php','_self')" style="float:right" class="btn btn-info
		btn-md">Close</button></div>
	</div>
</div>
<div id="divNewTenant" class="modal">
	<form action="tenants.php" Method="Post" name="frmTenantsEdit" onsubmit="return validateFormOnSubmit(this)"><input type="hidden" name='txtInfo1' id='txtInfo1' value="">
	<div class="imgcontainer"><span onclick="document.getElementById('divNewTenant').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span>
	<h4 style="color:#fff;text-decoration:underline overline double #fff;word-spacing:5px;letter-spacing:3px;">NEW TENANT'S DETAILS</h4></div>
	<div class="container divmodalmain">
      <div class="form-row">
        <div class="col-md-3"><label for="txtTNo1">Tenant No. *</label><input type="text" name="txtTNo1" id="txtTNo1" value="<?php echo $tenNo;?>" maxlength="3" required
					class="modalinput"></div><div class="col-md-6"></div>
				<div class="col-md-3"><label for="txtDate1">Rented On *</label><input type="text" name="txtDate1" id="txtDate1" value="<?php echo date('d-m-Y');?>" maxlength="3" required
					class="tcal modalinput"></div>
			</div><div class="form-row">
        <div class="col-md-12"><label for="cboStf1">Name of  the Tenant *</label><Select name="cboStf1" id="cboStf1" size="1" class="modalinput" required><option value="" selected>
					None</option><?php echo $optStf; ?></select></div>
      </div><div class="form-row">
        <div class="col-md-3"><label for="txtHNo">House No. *</label><input type="text" name="txtHNo1" id="txtHNo1" maxlength="5" value="" class="modalinput" required
					onkeyup="cleanAmt(this)"></div>
        <div class="col-md-6"><label for="cboHType1">Type of House Rented *</label><SELECT name="cboHType1" id="cboHType1" size="1" class="modalinput"><option>Single Room</option>
					<option selected>Single Bedroom</option><option>Double Bedroom</option><option>3 Bedroomed House</option><option>Malsion/ Bungalow</option></SELECT></div>
				<div class="col-md-3"></div>
      </div><div class="form-row">
        <div class="col-md-12 divheadings">DEFINITION OF RENT AMOUNT <input name="txtYr1" id="txtYr1" type="hidden" value="<?php echo $finyr; ?>"></div>
      </div><div class="form-row">
				<div class="col-md-3"><label for="txtArrears1">Rent Arrears *</label><input type="text" name="txtArrears1" id="txtArrears1" maxlength="10" value="0.00" class="modalinput
					numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
				<div class="col-md-3"><label for="txtRent1">Monthly Rent *</label><input type="text" name="txtRent1" id="txtRent1" maxlength="10" value="0.00" class="modalinput
					numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
				<div class="col-md-3"><label for="txtFurn1">Furniture Rent *</label><input type="text" name="txtFurn1" id="txtFurn1" maxlength="10" value="0.00" class="modalinput
					numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
				<div class="col-md-3"><label for="txtWater1">Water Bill *</label><input type="text" name="txtWater1" id="txtWater1" maxlength="10" value="0.00" class="modalinput
					numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
				<div class="col-md-3"><label for="txtElect1">Electricity Bill *</label><input type="text" name="txtElect1" id="txtElect1" maxlength="10" value="0.00" class="modalinput
					numbersinput" required onkeyup="cleanAmt(this)" onblur="calcTotal(this)"></div>
					<div class="col-md-3"></div><div class="col-md-3"></div>
					<div class="col-md-3 divheadings"><label for="txtTotalBill">TOTAL RENT BILL *</label><input type="text" name="txtTotalBill" id="txtTotalBill" maxlength="10" value="0.00"
						class="modalinput numbersinput modalinputdisabled" readonly></div>
			</div><hr><div class="form-row">
          <div class="col-md-5"><button type="submit" name="btnSave" class="btn btn-primary btn-md btn-block">Save Tenant Details</button></div><div class="col-md-4"></div>
          <div class="col-md-3" style="text-align:right;"><button type="button" class="btn btn-info btn-md" onclick="document.getElementById('divNewTenant').style.display='none'"
					name="cmdclose">Cancel/Close</button></div>
      </div>
	</div></form>
</div>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/tenants.js"></script>
<?php mysqli_close($conn); footer();?>
