<?php
	declare(strict_types=1);
	include_once('shanam.php');
	//current financial year
	$rs=mysqli_query($conn,"SELECT finyr FROM ss"); 	list($cuyr)=mysqli_fetch_row($rs); 	mysqli_free_result($rs);
	if (isset($_POST['cmdSave_1'])){
	 	$r=1;	$date=isset($_POST['txtDate_1'])?sanitize($_POST['txtDate_1']):date("d-m-Y");		$dt=preg_split("/\-/",$date);  		$date="$dt[2]-$dt[1]-$dt[0]";	$nr=0;
		$lpono=isset($_POST['txtLPONo_1'])?sanitize($_POST['txtLPONo_1']):0;				$lpono=strlen($lpono)>0?$lpono:null;
		$invno=isset($_POST['txtInvNo_1'])?sanitize($_POST['txtInvNo_1']):0;				$invno=(strlen($invno)>0 || $invno!=0)?$invno:null;
		$yr=isset($_POST['txtYr_1'])?sanitize($_POST['txtYr_1']):date('Y'); 				$credno=isset($_POST['txtCredNo_1'])?sanitize($_POST['txtCredNo_1']):0;
		$type=isset($_POST['txtType_1'])?sanitize($_POST['txtType_1']):1;						$recno=isset($_POST['txtInfo_1'])?sanitize($_POST['txtInfo_1']):0;
		$un=$_SESSION['username']." (".$_SESSION['priviledge'].")"; 								$ac=isset($_POST['cboAC_1'])?sanitize($_POST['cboAC_1']):0;
		$amt=isset($_POST['txtAmount_1'])?sanitize($_POST['txtAmount_1']):0;				$vono=isset($_POST['cboVote_1'])?sanitize($_POST['cboVote_1']):0;
		$origamt=isset($_POST['txtAmtOrig_1'])?sanitize($_POST['txtAmtOrig_1']):0;	$amt=preg_replace('/[^0-9^\.]/',"",$amt);	$origamt=preg_replace('/[^0-9^\.]/',"",$origamt);
		$rmks=isset($_POST['txtRmks_1'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtRmks_1'])))):"";
		if (strlen($rmks)>7 && $vono>0 && $ac>0 && $amt>0 && strlen($credno)>0 && strlen($invno)>0){
		 	if ($type==1){//adding new commitment
			 	$sql="INSERT INTO acc_creditorsdet(detno,cred_no,inv_date,inv_no,lpono,yr,acc,voteno,amt,estimatedamt,rmks,addedby) VALUES (0,$credno,'$date',".var_export($invno,true).
				",".var_export($lpono,true).",'$yr','$ac','$vono',$amt,$amt,'$rmks','$un')";
			}else{ //Editing commitment details
				$origamt-=$amt;
				$sql="UPDATE acc_creditorsdet SET cred_no=$credno,inv_date='$date',inv_no=".var_export($invno,true).",lpono=".var_export($lpono,true).",yr='$yr',acc='$ac',
				voteno='$vono',amt=$amt,estimatedamt=estimatedamt-$origamt,rmks=".var_export($rmks,true).",yr='$yr' WHERE detno LIKE '$recno'";
			}
			mysqli_query($conn,$sql) or die(mysqli_error($conn)." Creditor's record not successfully saved.<br>Click <a href=\"creditorsummary.php?recno=$credno-0-0\">
			HERE</a> to try again.");
			$nr=mysqli_affected_rows($conn);
		}else{
			print "<font color=\"#990000\">The commitment record is incomplete. It has not been saved.<br>Click <a href=\"creditorsummary.php?recno=$credno-0-0\">HERE</A> to try
			again.</font>"; exit(0);
		}
	}elseif (isset($_POST['cmdSave'])){
	 	$r=1;
		$regdate=isset($_POST['txtDate'])?sanitize($_POST['txtDate']):date("d-m-Y");			$regdate=preg_split("/\-/",$regdate);
		$act=sanitize($_POST['txtDat']); $act=preg_split('/\-/',$act); //act[0] 0 - New Record, 1 - creditors number
		$credno=isset($_POST['txtCredNo'])?sanitize($_POST['txtCredNo']):'Auto';	$supid=isset($_POST['txtSupCode'])?sanitize($_POST['txtSupCode']):"";
		$name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName']))):"";		$supid=strlen($supid)==0?null:$supid;
		$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):"";		$telno=strlen($telno)==0?null:$telno;		$un=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		$paddress=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):""; 	$paddress=strlen($paddress)==0?null:$paddress;
		$credno=strcasecmp($credno,"Auto")==0?0:$credno;							$yr=isset($_POST['txtYr'])?strtoupper($_POST['txtYr']):"";
		$idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):""; 						$idno=strlen($idno)==0?null:$idno;
		if (strlen($name)>7 && strlen($telno)>9 && $yr<=$cuyr){
		 	if ($act[0]==0) $sql="INSERT INTO acc_creditors (cred_no,supid,yr,idno,name,telno,paddress,regdate,addedby) VALUES ($credno,".var_export($supid,true).",'$yr',
			".var_export($idno,true).",'$name',".var_export($telno,true).",".var_export($paddress,true).",'$regdate[2]-$regdate[1]-$regdate[0]','$un')";
			else $sql="UPDATE acc_creditors SET supid=".var_export($supid,true).", yr='$yr',idno=".var_export($idno,true).", name='$name',telno=".var_export($telno,true).
			", paddress=".var_export($paddress,true).",regdate='$regdate[2]-$regdate[1]-$regdate[0]' WHERE cred_no LIKE '$act[1]'";
			mysqli_query($conn,$sql) or die(mysqli_error($conn)." Creditor's record not successfully saved. Click <a href=\"creditorsummary.php?recno=$act[1]-0-0\">here</a> to try again.");
			$nr=mysqli_affected_rows($conn);
			if ($credno==0 && $act[0]==0){
				$rs=mysqli_query($conn,"SELECT LAST_INSERT_ID()"); list($credno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
			}
		}else{
			print "<font color=\"#990000\">The creditor record is incomplete. It has not been saved.<br>Click <a href=\"creditorsummary.php?recno=$credno-0-0\">HERE</A> to try
			again.</font>"; $nr=0; exit(0);
		}
	}elseif(isset($_POST['cmdDelCommt'])){
		$r=2;
		$tno=isset($_POST['txtInfo_1'])?sanitize($_POST['txtInfo_1']):"0"; $credno=isset($_POST['txtCredNo_1'])?sanitize($_POST['txtCredNo_1']):'0';
		$rmks=isset($_POST['txtDelRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtDelRmks']))):"No Remarks";
		if (strlen($rmks)>15){
		 	mysqli_query($conn,"UPDATE acc_creditorsdet SET delreason='$rmks',markdel=1 WHERE detno=$tno") or die(mysqli_error($conn).". Record not deleted.<br>Click <a
			 href=\"creditorsummary.php?recno=$credno-0-0\">HERE</a> to try again");
			$nr=mysqli_affected_rows($conn);
		}else{
			print "The narration \"<b><u>$rmks</u></b>\" on delete is too short. <br>Click <a href=\"creditorsummary.php?recno=$credno-0-0\">HERE</a> to try again";
			exit(0);
		}
	}elseif(isset($_POST['cmdDelCred'])){
		$r=2;
		$tno=isset($_POST['txtData_1'])?sanitize($_POST['txtData_1']):"0-0"; $tno=preg_split('/\-/',$tno); //[0]- creditor no.,[1]- No. of commitment redords
		$rmks=isset($_POST['txtRmks_1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtRmks_1']))):"No record";
		if (strlen($rmks)>19 && $tno[1]==0){
		 	mysqli_query($conn,"UPDATE acc_creditors SET delreason='$rmks',markdel=1 WHERE cred_no=$tno[0]") or die(mysqli_error($conn).". Record not deleted.<br>Click <a
			 href=\"creditorsummary.php?recno=$tno-0-0\">HERE</a> to try again");
			$nr=mysqli_affected_rows($conn);
			if ($nr>0){//delete also payments
			 	mysqli_multi_query($conn,"UPDATE acc_exp SET markdel=1 WHERE expno LIKE '$tno[0]' and commt=1; UPDATE acc_pytvote SET markdel=1 WHERE voucherno IN (SELECT voucherno
					FROM acc_exp WHERE expno LIKE '$tno[0]' and commt=1);"); while(mysqli_next_result($conn)){}
			}
		}else{
			print "<b>Note:</b>The creditor record has not been deleted because of either<br>1. The narration \"<b><u>$rmks</u></b>\" on delete is too short. or <br>2. The creditor has
			$tno[1] commitments to be settled.<br>Click <a href=\"creditorsummary.php?recno=$tno[0]-0-0\">HERE</a> to try again";
			exit(0);
		}$credno=$tno[0];
	}mysqli_close($conn);
	header("location:creditorsummary.php?recno=$credno-$r-$nr");
?>
