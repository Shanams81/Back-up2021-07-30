<?php
	include_once('shanam.php');
	$action=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0";	$action=preg_split("/\-/",$action);
	$rsPriv=mysqli_query($conn,"SELECT Impview,impissue,impdel,impclr FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");
	$viu=0; $issue=0; $revo=0; $clear=0;	if (mysqli_num_rows($rsPriv)>0) list($viu,$issue,$revo,$clear)=mysqli_fetch_row($rsPriv); mysqli_free_result($rsPriv);
	$sdate= isset($_REQUEST['date3']) ? $_REQUEST['date3'] : date('d-m-Y',strtotime(date('Y').'-01-01'));
	$edate= isset($_REQUEST['date4']) ? $_REQUEST['date4'] : date("d-m-Y");	$state=isset($_POST['cboState'])?strip_tags($_POST['cboState']):1;
	headings('<link href="tpl/css/headers.css" rel="stylesheet" type="text/css"/><link rel="stylesheet" type="text/css" href="../date/tcal.css"/>',$action[0],$action[1],2);
?>
<div class="head"><form method="post" action="imprests.php"><a href="imprest_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;
<label for="CboState">View </label><SELECT name="cboState" id="cboState" size="1"><Option value="0" <?php echo ($state==0?"selected":"");?>>Unissued</option><Option value="1"
<?php echo ($state==1?"selected":"");?>>Unsurrendered</option><Option value="2" <?php echo ($state==2?"selected":"");?>">Surrendered</option></Select>&nbsp;Imprests <label
for="date3">made between &nbsp;</label><input name="date3" class="tcal" type="text" value="<?php echo $sdate;?>" readonly size="10"><label for="date4">&nbsp;and&nbsp;</label>
<input name="date4" class="tcal" type="text" value="<?php echo $edate;?>" readonly size="10"> &nbsp;&nbsp;<button type="submit" accesskey="s" name="btnShow" class="btn btn-md
btn-warning">View Imprests</button></form></div>
<div class="container" style="background-color:#eee;border-radius:10px 10px 0 0;width:fit-content;">
<?php
	$sql="SELECT r.impno,r.acc,s.idno,concat(s.surname,' ',s.onames) as st_names,r.cudate,r.approvedby,r.amt,r.rmks,r.reqno FROM acc_imp r Inner Join stf s Using (idno) WHERE ";
	if (isset($_POST['btnShow'])){
	 	$h="Report on ";	$h.=($state==0)?"Unissued ":($state==1?"Unsurrendered ":"Surrendered ");
		$h.=" Imprests' of between ".date('D d F, Y',strtotime($sdate))." and ".date('D d F, Y',strtotime($edate));
		$sdate=preg_split("/\-/",$sdate);	$edate=preg_split("/\-/",$edate);
		$sql.="(r.status LIKE	'$state' and (r.cudate BETWEEN '$sdate[2]-$sdate[1]-$sdate[0]' and '$edate[2]-$edate[1]-$edate[0]'))";
	} else {
		$h="All Unsurrendered Imprests"; $state=1;
		$sql.="r.status=1";
	}$sql.=" ORDER BY r.impno ASC";
?>
<div class="form-row"><div class="col-md-12" style="border:0.5px dotted green;border-radius:10px 10px 10px 10px;padding:6px;"><form name="frmFind" action="#" method="post">
Find Imprests By&nbsp;<input type="radio" name="radFind" id="radIDNo" value="idno" onclick="clrText()">Holder's ID No.&nbsp; <input type="radio" name="radFind" id="radName"
value="names" checked onclick="clrText()">Names &nbsp; <input type="radio" name="radFind" id="radImpNo"	value="pfno" onclick="clrText()">Imprest No. &nbsp;&nbsp; <input type="text"
maxlength="17" size="30" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Type/ Enter what to Find" style="border:0px;border-bottom:1px solid blue;color:#00d;">
</form></div></div>
<div class="form-row"><div class="col-md-12" style="max-height:600px;overflow-y:scroll" id="divImprests"><?php print "<h5>".strtoupper($h)."</h5>";?>
	<table id="myTable" class="table table-sm table-hover table-bordered table-striped"><thead class="thead-dark"><tr><th colspan="7">IMPREST DETAILS</th><th colspan="4">Administrative
	Actions</th></tr><tr><th>Imprest<br>No.</th><th>ID. No.</th><th>Imprest Holder</th><th>Approved On</th><th>Approved By</th><th>Amount</th><th>Reason for the Imprest</th><th>Imprest
	<br>Voucher</th><th>Issue</th><th>Cancel<br>Imprest</th><th>Surrender</th></tr></thead><tbody>
<?php
	$rsReq=mysqli_query($conn,$sql); 	$i=mysqli_num_rows($rsReq);	$ttl=0;
	if ($i>0){
		while (list($impno,$acc,$idno,$nam,$date,$app,$amt,$rmks,$reqno)=mysqli_fetch_row($rsReq)){
			print "<tr><td align=\"center\">$impno</td><td align=\"center\">$idno</td><td>$nam</td><td align=\"right\">".date('D d M, Y',strtotime($date))."</td><td valign=\"top\">$app
			</td><td align=\"right\">".number_format($amt,2)."</td><td>$rmks</td>";
			if ($state==0) print "<td align=\"center\"></td><td align=\"center\"><a onclick=\"return canIssue($issue)\" href=\"imp_processor.php?impno=$impno-0\">Issue</a></td><td
			align=\"center\"><a  onclick=\"return canRevoke($revo)\" href=\"imp_processor.php?impno=$impno-1\">Cancel</a></td><td align=\"center\"></td></tr>";
			elseif ($state==1) print "<td align=\"center\"><a onclick=\"return canIssue($issue)\" href=\"pdf/imp_printout.php?impno=$impno\">View</a></td><td align=\"center\"></td><td
			align=\"center\"></td><td align=\"center\"><a onclick=\"return canClear($clear)\" href=\"imp_clear.php?impno=$impno-$acc\">Surrender</a></td></tr>";
			else print "<td align=\"center\"><a onclick=\"return canView($viu)\" href=\"pdf/imp_printout.php?impno=$impno\">View</a></td><td align=\"center\"></td><td align=\"center\"></td><td
			align=\"center\"></td></tr>";
			$ttl+=$amt;
		}
	}else{
		print "<tr><td colspan=\"11\">Sorry, No requisitions exists for the selected criteria</td></tr>";
	}mysqli_free_result($rsReq);
	print "<tbody><tfoot class=\"thead-light\" id=\"trTtls\"><tr><td colspan=\"3\"><span id=\"spNoImp\" style=\"font-weight:bold\">$i Imprest Item(s)</span></td><td colspan=\"2\"
	align=\"right\"><b>Total (Kshs.)</b></td><td	align=\"right\"><span id=\"spTotal\" style=\"font-weight:bold\">".number_format($ttl,2)."</span></td><td colspan=\"5\"></td></tr>
	</tfoot></table>";
?></div></div><div class="form-row"><div class="col-md-12" style="text-align:right;"><img onclick="printSpecific()" src="/gen_img/print.ico" height=20 width=30 title="Print List">
</div></div></div>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/imprest-find.js"></script>
<?php mysqli_close($conn); footer();?>
