<?php
    include_once('../conn/mysqli_connect.inc.tpl');
    $loginname=isset($_REQUEST['action'])?$_REQUEST['action']:'0x0x0x';
    mysqli_query($conn,"DELETE FROM login WHERE username LIKE '$loginname'") or die(mysqli_error($conn). " $loginname - ". " Record not deleted. click <a href=\"useredit.php?action=0-0\">HERE</a>
    to go back and try again!!!");
    $i=mysqli_affected_rows($conn);
    header("location:users.php?action=2-$i");
?>