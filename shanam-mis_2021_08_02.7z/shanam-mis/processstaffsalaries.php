<?php
    session_start();
    include_once('../conn/pri_sch_connect.inc');
    $data=isset($_REQUEST['salno'])?strtoupper(strip_tags(trim($_REQUEST['salno']))):'1-1-1';  $mess=0; $nsd=0;
    $data=preg_split('/\-/',$data);	//[0]-0 process all,1 Editing,2 adding new earner,[1]- salary no. [2] Payroll No.
    if (isset($_POST['btnSave'])){
        $d=isset($_POST['txtInfo'])?strip_tags($_POST['txtInfo']):'1-1-1'; 		$data=preg_split('/\-/',$d); $advsql=isset($_POST['txtAdvSql'])?strip_tags($_POST['txtAdvSql']):'0'; 
        $pfno=isset($_POST['txtPFNo'])?strip_tags($_POST['txtPFNo']):0;			$pp=isset($_POST['txtPP'])?strtoupper(strip_tags($_POST['txtPP'])):0;	
        $bsal=isset($_POST['txtBSal'])?strip_tags($_POST['txtBSal']):0; 		$bsal=preg_replace('/[^0-9^\.]/','',$bsal);
        $house=isset($_POST['txtHouse'])?strip_tags($_POST['txtHouse']):0; 		$house=preg_replace('/[^0-9^\.]/','',$house);
        $med=isset($_POST['txtMed'])?strip_tags($_POST['txtMed']):0; 			$med=preg_replace('/[^0-9^\.]/','',$med);
        $com=isset($_POST['txtCommute'])?strip_tags($_POST['txtCommute']):0; 	$com=preg_replace('/[^0-9^\.]/','',$com);
        $resp=isset($_POST['txtResp'])?strip_tags($_POST['txtResp']):0; 		$resp=preg_replace('/[^0-9^\.]/','',$resp);
        $enss=isset($_POST['txtEmpNSSF'])?strip_tags($_POST['txtEmpNSSF']):0; 	$enss=preg_replace('/[^0-9^\.]/','',$enss);
        $nssf=isset($_POST['txtNSSF'])?strip_tags($_POST['txtNSSF']):0; 		$nssf=preg_replace('/[^0-9^\.]/','',$nssf);
        $nssfv=isset($_POST['txtVolNSSF'])?strip_tags($_POST['txtVolNSSF']):0; 	$nssfv=preg_replace('/[^0-9^\.]/','',$nssfv);
        $nhif=isset($_POST['txtNHIF'])?strip_tags($_POST['txtNHIF']):0; 		$nhif=preg_replace('/[^0-9^\.]/','',$nhif);
        $sac=isset($_POST['txtSACCO'])?strip_tags($_POST['txtSACCO']):0; 		$sac=preg_replace('/[^0-9^\.]/','',$sac);
        $welf=isset($_POST['txtWelfare'])?strip_tags($_POST['txtWelfare']):0; 	$welf=preg_replace('/[^0-9^\.]/','',$welf);
        $helb=isset($_POST['txtHELB'])?strip_tags($_POST['txtHELB']):0; 		$helb=preg_replace('/[^0-9^\.]/','',$helb);
        $paye=isset($_POST['txtPAYE'])?strip_tags($_POST['txtPAYE']):0; 		$paye=preg_replace('/[^0-9^\.]/','',$paye);
        $mpr=isset($_POST['txtMPR'])?strip_tags($_POST['txtMPR']):0; 			$mpr=preg_replace('/[^0-9^\.]/','',$mpr);
        $uni=isset($_POST['txtUnion'])?strip_tags($_POST['txtUnion']):0; 		$uni=preg_replace('/[^0-9^\.]/','',$uni);
        $adv=isset($_POST['txtAdv'])?strip_tags($_POST['txtAdv']):0; 			$adv=preg_replace('/[^0-9^\.]/','',$adv);
        $ole=isset($_POST['txtOle'])?strip_tags($_POST['txtOle']):0; 			$ole=preg_replace('/[^0-9^\.]/','',$ole);
        if ($bsal>0 && $house>-1 && $med>-1 && $com>-1 && $resp>-1 && $enss>-1 && $nssf>-1 && $nssfv>-1 && $nhif>-1 && $sac>-1 && $welf>-1 && $helb>-1 && $paye>-1 && $mpr>-1 && $adv>-1 && 
        $ole>-1 && $uni>-1 && strlen($pp)>0 && strlen($pfno)>0){
            if($data[0]==1){
                mysqli_query($conn,"UPDATE acc_salpyt SET payrollno='$pfno',salno='$data[1]',bsalary='$bsal',housingallow1='$house',medicalallow1='$med',travelallow1='$com',
                responsallow1='$resp',empnssf='$enss',nssffee1='$nssf',nssfvol1='$nssfv',nhiffee1='$nhif',paye1='$paye',mpr1='$mpr',otherlevies1='$ole',union1='$uni',sacco1='$sac',
                welfare1='$welf',advance='$adv',paypoint='$pp' WHERE payrollno LIKE '$data[2]' and salno LIKE '$data[1]'"); $i=mysqli_affected_rows($conn);
            }else{
                mysqli_query($conn,"INSERT INTO acc_salpyt (payrollno,salno,bsalary,housingallow1,medicalallow1,travelallow1,responsallow1,empnssf,nssffee1,nssfvol1,nhiffee1,paye1,mpr1,
                otherlevies1,union1,sacco1,welfare1,helb1,advance,paypoint) VALUES ('$pfno','$data[1]',$bsal,$house,$med,$com,$resp,$enss,$nssf,$nssfv,$nhif,$paye,$mpr,$ole,$uni,$sac,
                $welf,$helb,$adv,'$pp')"); $i=mysqli_affected_rows($conn);
                if (strcasecmp($advsql,'0')!=0 && $i>0 && $adv>0) mysqli_query($conn,$advsql);//update if advance was recovered
            }

            if ($data[0]==1){header("location:payroll.php?action=1-$i"); exit(0);} else $mess=$i;
        }
    }
    mysqli_multi_query($conn,"SELECT concat(sal_month,' - ',sal_year) as mon,sal_month,sal_year,acc FROM acc_salaries WHERE salno LIKE '$data[1]'; SELECT schtype FROM ss;"); $schtype=$i=0;
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){if(mysqli_num_rows($rs)>0) list($month,$salmon,$salyr,$acc)=mysqli_fetch_row($rs); else exit(0);}
            else{list($schtype)=mysqli_fetch_row($rs);}
            mysqli_free_result($rs);
        }$i++;
    }while(mysqli_next_result($conn));
    if ($data[0]==0){ //process all staff salary and exit
        mysqli_query($conn,"INSERT INTO acc_salpyt (payrollno,salno,bsalary,housingallow1,medicalallow1,travelallow1,responsallow1,empnssf,nssffee1,nssfvol1,nhiffee1,paye1,mpr1,
        otherlevies1,union1,sacco1,welfare1,helb1,paypoint) SELECT payrollno,$data[1],bsal,houseallow,medicalallow,travellallow,responsallow,empnssf,nssffee,nssfvol,nhiffee,paye,mpr,
        otherlevies,unionfee,saccofee,welfare,helb,concat(bankname,' - ',bankbranch) as bank FROM acc_saldef d INNER JOIN stf s USING (idno) WHERE s.markdel=0 and d.markdel=0 and (d.acc is 
        null Or d.acc='$acc') and s.present=1 and d.payrollno NOT IN (SELECT * FROM (SELECT payrollno FROM acc_salpyt WHERE salno IN (SELECT salno FROM acc_salaries WHERE sal_month LIKE 
        '$salmon' and sal_year LIKE '$salyr'))x)") or die(mysqli_error($conn));
        $nos=mysqli_affected_rows($conn);
        if ($nos>0){
            //work on salary advances
            $rs=mysqli_query($conn,"SELECT a.advno,a.payrollno,if((a.amt-IF(isnull(c.clr),0,c.clr))>a.amtperduration,a.amtperduration,(a.amt-IF(isnull(c.clr),0,c.clr))) AS Bal FROM 
            Acc_Adv a LEFT JOIN (SELECT advano,sum(amt_clr) as clr FROM Acc_AdvClr GROUP BY advano,markdel HAVING markdel=0)c ON a.advno=c.advano WHERE a.markdel=0 and (a.amt-
            IF(isnull(c.clr),0,c.clr))>0 ORDER BY a.payrollno ASC"); 
            $noa=mysqli_num_rows($rs); $sqladv=''; $sqlpf=''; 
            if ($noa>0){ 
                $i=0; $sqladv="INSERT INTO acc_advclr(clrno,advano,clr_date,amt_clr,rmks,salno) VALUES "; 
                while ($adv=mysqli_fetch_row($rs)){
                    $sqladv.=($i>0?",":"")."(0,$adv[0],curdate(),$adv[2],'Recovered from salary',$data[1])";
                    $sqlpf.="UPDATE acc_salpyt SET advance=advance+$adv[2] WHERE salno LIKE '$data[1]' and payrollno LIKE '$adv[1]';";
                    $i++;
                }
                if (strlen($sqladv)>0) mysqli_query($conn,$sqladv) or die(mysqli_error($conn));
                if (strlen($sqlpf)>0){mysqli_multi_query($conn,$sqlpf); while(mysqli_next_result($conn)){;}}
            }
            //work on salary loans
        }	
        header("location:payroll.php?action=1-$nos"); exit(0);
    }elseif($data[0]==1){//prepare for editing of salary
        $rsSal=mysqli_query($conn,"SELECT sp.payrollno,s.idno,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.paypoint,sp.bsalary,sp.housingallow1,sp.medicalallow1,
        sp.travelallow1,responsallow1,sp.empnssf,sp.nssffee1,sp.nssfvol1,sp.nhiffee1,sp.advance,sp.paye1,sp.mpr1,sp.otherlevies1,sp.union1,sp.sacco1,sp.welfare1,sp.helb1 FROM Stf s INNER 
        JOIN acc_saldef USING (idno) Inner Join Acc_SalPyt sp USING (payrollno) Where sp.salno LIKE '$data[1]' and sp.payrollno LIKE '$data[2]'");
        list($pfno,$idno,$name,$des,$pp,$bsal,$ha,$ma,$ta,$ra,$emns,$ns,$nsv,$nh,$adv,$tax,$mpr,$ole,$uni,$sac,$wel,$hel)=mysqli_fetch_row($rsSal); mysqli_free_result($rsSal);
    }else{//Prepare to add new salary earner
        $rsSal=mysqli_query($conn,"SELECT sd.payrollno,s.idno,concat(s.surname,' ',s.onames) as st_names,s.designation,concat(sd.bankname,' - ',sd.bankbranch) as bank,sd.bsal,
        sd.houseallow,sd.medicalallow,sd.travellallow,sd.responsallow,sd.empnssf,sd.nssffee,sd.nssfvol,sd.nhiffee,sd.paye,sd.mpr,sd.otherlevies,sd.unionfee,sd.saccofee,sd.welfare,sd.helb 
        FROM Stf s INNER JOIN acc_saldef sd USING (idno) WHERE s.markdel=0 and s.present=1 and sd.payrollno NOT IN (SELECT payrollno FROM acc_salpyt WHERE salno LIKE '$data[1]') and "
        . "sd.markdel=0 and (sd.acc is null or sd.acc IN (SELECT acc FROM acc_salaries WHERE salno LIKE '$data[1]'))");
        $pfno='';$idno='';$name='';$des=''; $pp=''; $bsal=0; $ha=0; $ma=0; $ta=0; $ra=0; $emns=0; $ns=0; $nsv=0; $nh=0; $adv=0; $tax=0; $mpr=0; $ole=0; $uni=0; $sac=0; $wel=0; $hel=0;
        $nsd=mysqli_num_rows($rsSal);
    } $i=$mess>0?1:0;//check whether update of salary was successful
?>
<html><head><title>Salary Processor</title>
<style>table,td{border:0px;padding:3px;font-size:11pt;}input, select, textarea{font-family:tahoma;font-size:10pt;border:0px;border-bottom:2px solid blue;border-radius:4px;
text-transform:uppercase;background:inherit;}button{font-weight:bold;border:1px groove #ddd;border-radius:15px;min-width:130px;min-height:50px;}input.number{text-align:right;}
</style></head>
<body background="img/bg3.gif" <?php print "onload=\"actiondone($i,$mess)\""; ?>><form name="frmSalProcess" action="processstaffsalaries.php" method="post"><input type="hidden" 
name="txtInfo" id="txtInfo" size="5" <?php echo "value=\"$data[0]-$data[1]-$data[2]\""; ?>><input type="hidden" name="txtAdvSql" id="txtAdvSql" value="">
<table align="center"><tr><td colspan=5 style="background:#000;color:#fff;font-weight:bold;font-size:14pt;letter-spacing:3px;word-spacing:6px;"><?php echo strtoupper($month);?> STAFF 
SALARY PROCESSOR</td></tr><tr><td align="right">Payroll No.</td><td colspan=4><?php if($data[0]<2){ echo '<input name="txtPFNo" id="txtPFNo" type="text" size="5" value="'.$pfno.'" '.($data[0]==1?
'readonly':'').' onchange="showAmount(this,0)" required style="background:#fff;"> &nbsp;<input type="text" size="60" id="txtName" disabled value="ID No. '.$idno.' '.$name.' ('.$des.')" 
style="font-size:10px;font-weight:bold;color:#00F;" required>';} else{ echo '<SELECT name="cboStaff" id="cboStaff" size="1" onblur="showAmount(this,1)" style="width:100%">';
if(mysqli_num_rows($rsSal)>0){while ($d=mysqli_fetch_row($rsSal)) echo '<option value="'.$d[0].'">'.$d[0].' - '.$d[2].' ('.$d[3].')</option>'; mysqli_data_seek($rsSal,0);
}else echo '<option value="0" selected>No Other Member of Staff Exists</option>';
echo '</select><input name="txtPFNo" id="txtPFNo" type="hidden" size="5" value=""><input type="hidden" size="60" id="txtName">';}?></td></tr>
<tr><td align="right">Salary Paypoint</td><td colspan=3><input name="txtPP" id="txtPP" type="text" size="45" <?php echo 'value="'.$pp.'"';?> required></td><td rowspan=13 valign="middle">
<br><br><br><br><br><br><br><button name="btnSave" id="btnSave" type="submit" <?php print ($data[0]==1?"":"disabled");?>>Effect Salary<br>Payment</button><br><br><br><br><br><br><br><br>
<a href="payroll.php"><button type="button" name="btnClose">Cancel/Close</button></a></td></tr>
<tr><td colspan="2" style="background:#444;color:#fff;font-weight:bold">BASIC SALARY &AMP; ALLOWANCES</td><td colspan="2" style="background:#444;color:#fff;font-weight:bold">SALARY 
DEDUCTIONS</td></tr>
<tr><td align="right">Basic Salary</td><td style="border-right:0.5px;"><input name="txtBSal" id="txtBSal" type="text" class="number" size="7" <?php echo 'value="'.number_format($bsal,2).
'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td><td style="border-left:0.5px;" align="right">N . S . S . F</td><td><input name="txtNSSF" id="txtNSSF" type="text" 
class="number" size="7" <?php echo 'value="'.number_format($ns,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td align="right">House</td><td style="border-right:0.5px;"><input name="txtHouse" id="txtHouse" type="text" class="number" size="7" <?php echo 'value="'.number_format($ha,2).
'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td><td style="border-left:0.5px;" align="right">Voluntary NSSF</td><td><input name="txtVolNSSF" id="txtVolNSSF" 
type="text" class="number" size="7" <?php echo 'value="'.number_format($nsv,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td align="right">Medical</td><td style="border-right:0.5px;"><input name="txtMed" id="txtMed" type="text" class="number" size="7" <?php echo 'value="'.number_format($ma,2).
'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td><td style="border-left:0.5px;" align="right">N . H . I . F</td><td><input name="txtNHIF" id="txtNHIF" type="text" 
class="number" size="7" <?php echo 'value="'.number_format($nh,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td align="right">Commuter</td><td style="border-right:0.5px;"><input name="txtCommute" id="txtCommute" type="text" class="number" size="7" <?php echo 'value="'.number_format($ta,2).
'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td><td style="border-left:0.5px;" align="right"><?php echo ($schtype==0?'K . D . S':'S . A . C . C . O');?></td><td><input 
name="txtSACCO" id="txtSACCO" type="text" class="number" size="7" <?php echo 'value="'.number_format($sac,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td align="right">Responsibility/Duty</td><td style="border-right:0.5px;"><input name="txtResp" id="txtResp" type="text" class="number" size="7" <?php echo 'value="'.number_format($ra,
2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td><td style="border-left:0.5px;" align="right">Workers Welfare</td><td><input name="txtWelfare" id="txtWelfare" 
type="text" class="number" size="7" <?php echo 'value="'.number_format($wel,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td align="right">Employer NSSF</td><td style="border-right:0.5px;"><input name="txtEmpNSSF" id="txtEmpNSSF" type="text" class="number" size="7" <?php echo 'value="'.
number_format($emns,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td><td style="border-left:0.5px;" align="right">HELB Recovery</td><td><input name="txtHELB" 
id="txtHELB" type="text" class="number" size="7" <?php echo 'value="'.number_format($hel,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td align="right" colspan=2 rowspan=5 style="border-right:0.5px;"></td><td style="border-left:0.5px;" align="right">Payable PAYE</td><td><input name="txtPAYE" id="txtPAYE" type="text" 
class="number" size="7" <?php echo 'value="'.number_format($tax,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td style="border-left:0.5px;" align="right">Monthly PAYE Relief</td><td><input name="txtMPR" id="txtMPR" type="text" class="number" size="7" <?php echo 'value="'.number_format($mpr,2).
'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td style="border-left:0.5px;" align="right"><?php echo ($schtype==0?'ELIMU':'Workers Union');?></td><td><input name="txtUnion" id="txtUnion" type="text" class="number" size="7" <?php echo 'value="'.number_format($uni,
2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td style="border-left:0.5px;" align="right">Salary Advance</td><td><input name="txtAdv" id="txtAdv" type="text" class="number" size="7" <?php echo 'readonly value="'.
number_format($adv,2).'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr><td style="border-left:0.5px;" align="right"><?php echo ($schtype==0?'Rent':'Other Recoveries');?></td><td><input name="txtOle" id="txtOle" type="text" class="number" size="7" <?php echo 'value="'.number_format($ole,2).
'"';?> onkeyup="checkInput(this)" onchange="computeNet()" required></td></tr>
<tr bgcolor="#dddddd"><td align="right"><b>GROSS SALARY</b></td><td style="border-right:0.5px;"><input name="txtGSal" id="txtGSal" type="text" class="number" size="7" <?php echo 'value="'.
number_format(($bsal+$ha+$ma+$ta+$ra+$emns),2).'"';?> readonly></td><td style="border-left:0.5px;" align="right"><b>NET SALARY</b></td><td><input name="txtNET" id="txtNET" type="text" 
class="number" size="7" <?php echo 'value="'.number_format((($bsal+$ha+$ma+$ta+$ra+$emns)-($emns+$ns+$nsv+$nh+$adv+($tax-$mpr)+$ole+$uni+$sac+$wel+$hel)),2).'"';?> readonly>
</td></tr></table></form>
<script type="text/javascript" src="tpl/actionmessage.js"></script>
<script type="text/javascript" src="tpl/js/processstaffsalaries.js"></script>
<script type="text/javascript">
    <?php $list=""; $index=0;
        if (isset($rsSal) && $nsd>0)while ($da=mysqli_fetch_row($rsSal)){ 
            $list.=($index==0?"":",")."new SalDef('$da[0]','$da[1]','$da[2]','$da[3]','$da[4]',$da[5],$da[6],$da[7],$da[8],$da[9],$da[10],$da[11],$da[12],$da[13],$da[14],$da[15],".
             "$da[16],$da[17],$da[18],$da[19],$da[20])";
            $index++;
        }if (strlen($list)>0) print "saldef.push($list);"; mysqli_free_result($rsSal);
    ?>
</script>

</body></html>