<?php
  require_once('shanam.php');
  $btn=''; $i=6; $rs=mysqli_query($conn,"SELECT DISTINCT yr FROM acc.arch_feerec;");
  while($y=mysqli_fetch_row($rs)){
    $btn.="<div class=\"col-md-6\" style=\"margin:5px;\"><button name=\"btn$i\" id=\"btn_$i\" class=\"btn btn-block btn-md btn-primary\" type=\"button\" onclick=\"loadData($i,$y[0])\" disabled>TRANSFER FY$y[0] DATA</button></div>";
    $i++;
  } mysqli_free_result($rs); mysqli_close($conn); headings('<link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link href="tpl/css/spinner.css" rel="stylesheet" type="text/css"/>',0,0,2);
?>
<div class="container" style="background-color:#e6e6e6;width:fit-content;margin:25px auto;border:0;border-radius:10px;">
  <div class="form-row"><div class="col-md-12" style="background-color:#51adcf;color:#b83b5e;font-weight:bold;letter-spacing:4px;word-spacing:6px;text-align:center;">DATA TRANSITION TO NEW INTERFACE</div></div>
  <div class="form-row">
    <div class="col-md-5"><form class="" action="" method="">
      <div class="form-row">
        <div class="col-md-6" style="margin:5px;"><button type="button" name="btn0" id="btn_0" class="btn btn-block btn-md btn-primary" onclick="loadData(0,0)" disabled>STEP 1</button></div>
        <div class="col-md-6" style="margin:5px;"><button type="button" name="btn1" id="btn_1" class="btn btn-block btn-md btn-primary" onclick="loadData(1,0)" disabled>STEP 2</button></div>
        <div class="col-md-6" style="margin:5px;"><button type="button" name="btn2" id="btn_2" class="btn btn-block btn-md btn-primary" onclick="loadData(2,0)" disabled>STEP 3</button></div>
        <div class="col-md-6" style="margin:5px;"><button type="button" name="btn2" id="btn_3" class="btn btn-block btn-md btn-primary" onclick="loadData(3,0)" disabled>STEP 4</button></div>
        <div class="col-md-6" style="margin:5px;"><button type="button" name="btn2" id="btn_4" class="btn btn-block btn-md btn-primary" onclick="loadData(4,0)" disabled>STEP 5</button></div>
        <div class="col-md-6" style="margin:5px;"><button type="button" name="btn2" id="btn_5" class="btn btn-block btn-md btn-primary" onclick="loadData(5,0)" disabled>STEP 6</button></div>
        <?php echo $btn;?>
      </div></form>
    </div><div class="col-md-7" id="divShow" style="background-color:#000;color:#fff;overflow-y:scroll;border:1px Solid #fff;border-radius:10px 0;max-height:600px;">
      Results of transfer appear here!!!
    </div>
  </div>
</div>
<div id="busyWait" class="modal"><div class="loader"></div></div>
<script type="text/javascript">
  document.querySelector("#btn_0").disabled=false;
  function loadData(opt,yr){
    var nocache=Math.random()*10000,i=0,btn=document.querySelectorAll("button"),found=false; //stop caching
    document.querySelector('#busyWait').style.display='block';
    btn.forEach(function(val,index){val.disabled=true;});
		if (window.XMLHttpRequest){xmlhttp=new XMLHttpRequest();}else{xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
    xmlhttp.onreadystatechange=function(){if(this.readyState==4 && this.status==200){document.querySelector("#divShow").innerHTML=this.responseText; document.querySelector('#busyWait').style.display='none';}};
    xmlhttp.open('GET','ajax/transit.php?action='+opt+'-'+yr+'-'+nocache,true);xmlhttp.send(); opt++;  while(!found && i<btn.length){if(opt==i){found=true;document.querySelector("#btn_"+opt).disabled=false;}i++;}
  }
</script>
<?php footer();?>
