<?php
	include_once('shanam.php');
	$admno=isset($_REQUEST['rec']) ? $_REQUEST['rec']:"0-0-0-0-0";
	$admno=preg_split("/\-/",$admno); //[0] adm no, [1]=1 for new 2 editing,[2] year, [3] Where to go to,[4] class
	$rsYr=mysqli_query($conn,"SELECT finyr FROM ss"); list($finyr)=mysqli_fetch_row($rsYr); $finyr=isset($finyr)?$finyr:date("Y"); mysqli_free_result($rsYr);
	if (isset($_POST['cmdSave'])){
		$act=isset($_POST['txtAction'])?sanitize($_POST['txtAction']):'0-0'; 	$act=preg_split('/\-/',$act);	$frm=isset($_POST['cboFrm'])?sanitize($_POST['cboFrm']):1;  
		$str=isset($_POST['cboStream'])?sanitize($_POST['cboStream']):'North';	$lvl=isset($_POST['cboLevel'])?sanitize($_POST['cboLevel']):1;  
		$parr=isset($_POST['txtPArr'])?sanitize($_POST['txtPArr']):0;			$arr=isset($_POST['txtArr'])?sanitize($_POST['txtArr']):0;
		$mparr=isset($_POST['txtPMArr'])?sanitize($_POST['txtPMArr']):0;		$marr=isset($_POST['txtMArr'])?sanitize($_POST['txtMArr']):0;
		$pref=isset($_POST['txtPRef'])?sanitize($_POST['txtPRef']):0;			$ref=isset($_POST['txtRef'])?sanitize($_POST['txtRef']):0;
		$yr=isset($_POST['cboAcYr'])?sanitize($_POST['cboAcYr']):(date('Y')-1); $pref=preg_replace('/[^0-9^\.]/',"",$pref);	$ref=preg_replace('/[^0-9^\.]/',"",$ref);
		$parr=preg_replace('/[^0-9^\.]/',"",$parr);	$arr=preg_replace('/[^0-9^\.]/',"",$arr);	$mparr=preg_replace('/[^0-9^\.]/',"",$mparr);	
		$marr=preg_replace('/[^0-9^\.]/',"",$marr);	$doneon=date('Y-m-d');		$rmks=isset($_POST['txtRmks'])?strtoupper(sanitize($_POST['txtRmks'])):0;
		if ($act[1]==1){//SQL for new record
		 	$sql="INSERT INTO class (admno,clsno,lvlno,stream,curr_year,bbf,miscbf,refunds) VALUES ('$act[0]','$frm','$lvl','$str','$act[2]',$arr,$marr,$ref)"; //Continuing students
		}else{//SQL for updating exisiting record
			$sql="UPDATE class SET bbf=$arr,miscbf=$marr,refunds=$ref WHERE admno LIKE '$act[0]' and curr_year LIKE '$act[2]'"; //Continuing student
		} 
		mysqli_query($conn,$sql) or die(mysqli_error($conn)." Record not saved. Click <a href=\"studarrears.php?action=$act[0]-$act[2]-$act[3]\">Here</a> to try again!!");
		$i=mysqli_affected_rows($conn); 
		if ($i==1 && $act[1]==2){
		 	$sql="";
			if ($parr!=$arr) $sql.="INSERT INTO acc_arrrefchange(sno,admno,arr_yr,doneon,oldarr,newarr,ac,type,rmks,addedby) VALUE (0,$act[0],$act[2],'$doneon',$parr,$arr,1,0,'$rmks',
			'".$_SESSION['username']." (".$_SESSION['priviledge'].")');";
			if ($mparr!=$marr) $sql.="INSERT INTO acc_arrrefchange(sno,admno,arr_yr,doneon,oldarr,newarr,ac,type,rmks,addedby) VALUE (0,$act[0],$act[2],'$doneon',$mparr,$marr,4,0,
			'Misc Account - $rmks','".$_SESSION['username']." (".$_SESSION['priviledge'].")');";
			if ($pref!=$ref) $sql.="INSERT INTO acc_arrrefchange(sno,admno,arr_yr,doneon,oldarr,newarr,ac,type,rmks,addedby) VALUE (0,$act[0],$act[2],'$doneon',$pref,$ref,1,1,'$rmks',
			'".$_SESSION['username']." (".$_SESSION['priviledge'].")');";
			if (strlen($sql)>0)mysqli_multi_query($conn,$sql);	while(mysqli_next_result($conn)){}
		} header("location:studarrears.php?action=$act[0]-$act[2]"); exit(0);
	}mysqli_multi_query($conn,"SELECT lvlno,lvlname FROM classlvl ORDER BY lvlno; SELECT clsno,clsname,lvlno FROM classnames ORDER BY clsno;"); $i=0; $optLvl=$optCls='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i=0){
				while($d=mysqli_fetch_row($rs)){$optLvl.='<option value="'.$d[0].'">'.$d[1].'</option>';}	
			}else{
				while($d=mysqli_fetch_row($rs)){$optCls.='<option value="'.$d[0].'">'.$d[1].'</option>';}	
			}mysqli_free_result($rs);
		}$i++;	
	}while(mysqli_next_result($conn));
	headings('<link rel="stylesheet" type="text/css" href="tpl/datainput.css"/><script type="text/javascript" src="tpl/js/studarrearseditor.js"></script>',0,0,1);
?><br><div class="container" style="border:1px dashed #ff3;border-radius:10px;background-color:#ffe;padding:10px;max-width:700px;margin:auto;">
<?php
 	print "<form method=\"post\" action=\"studarrearseditor.php\" onsubmit=\"return ValidateInput(this,$admno[1]);\">";
	if ($admno[1]==2){
		$sql="SELECT concat(s.surname,' ',s.onames) as stud_names,s.curr_year,if(isnull(sf.clsno),'1',sf.clsno) as frm,if(isnull(sf.stream),'',sf.stream) as strm,if(isnull(sf.lvlno),'1',
		sf.lvlno) as lvl,if(isnull(sf.bbf),0,sf.bbf) as bf,if(isnull(sf.miscbf),0,sf.miscbf) as mbf,if(isnull(sf.alumniref),0,sf.alumniref) as ref,sf.curr_year FROM 
		stud s LEFT JOIN class sf USING (admno) WHERE s.admno LIKE '$admno[0]' and sf.curr_year LIKE '$admno[2]';";
	 	$rsSt=mysqli_query($conn,$sql);
		list($studnames,$yr,$frm,$strm,$lvl,$bbf,$mbbf,$ref,$yr)=mysqli_fetch_row($rsSt); mysqli_free_result($rsSt);
	}else{
		$rsSt=mysqli_query($conn,"SELECT concat(s.surname,' ',s.onames) as stud_names,c.lvlno,s.curr_year FROM stud s Inner Join class c USING (admno,curr_year) WHERE s.admno LIKE 
		'$admno[0]'");	list($studnames,$lvl,$yr)=mysqli_fetch_row($rsSt); mysqli_free_result($rsSt);
		$frm=$admno[3];	$strm=""; $grp="";	$bbf=0;	$mbbf=0; $ref=0; $yr--;
	}
?>
<div class="form-row">
	<div class="col-md-12" style="background:#999;color:#fff;"><input type="hidden" value="<?php echo "$admno[0]-$admno[1]-$admno[2]-$admno[3]";?>" name="txtAction"><h5>ADM. NO. <?php 
	echo "$admno[0] <b><u>".strtoupper($studnames)."</u></b> FY$admno[2]";?> FEE ARREARS EDITING</h5></div>
</div>
<div class="form-row">
	<div class="col-md-3"><label for="cboLevel">Level *</level><SELECT name="cboLevel" id="cboLevel" size="4" onchange="loadClasses(this)" required <?php echo ($admno[1]==1?"":"disabled");?>>
	<?php
		mysqli_multi_query($conn,"SELECT lvlno,lvlname FROM classlvl WHERE lvlno<=$lvl ORDER BY lvlno; SELECT clsno,clsname FROM classnames WHERE lvlno LIKE '$lvl' ORDER BY clsno; 
		SELECT strm FROM grps WHERE strm is not null;") or die(mysqli_error($conn).' Error in database connection'); $i=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){
					if (mysqli_num_rows($rs)>0) while (list($lvlno,$lvlname)=mysqli_fetch_row($rs)) echo "<option value=\"$lvlno\" ".($lvlno==$lvl?"selected":"").">$lvlname</option>";	
					echo '</SELECT></div>';
				}elseif($i==1){
					print'<div class="col-md-3"><label for="cboFrm">Grade/ Form *</level><span id="clsNames"><SELECT name="cboFrm" id="cboFrm" size="4" required '.($admno[1]==1?"":
					"disabled").'>';
					if (mysqli_num_rows($rs)>0) while (list($cls,$clsname)=mysqli_fetch_row($rs)) echo "<option value=\"$cls\" ".($frm==$cls?"selected":"").">$clsname
					</option>";		echo '</SELECT></span></div>';
				}else{
					echo '<div class="col-md-3"><label for="cboStream">Stream *</level><SELECT name="cboStream" id="cboStream" size="4" required '.($admno[1]==1?"":"disabled").'>';
					if (mysqli_num_rows($rs)>0) while (list($str)=mysqli_fetch_row($rs)) echo "<option ".(strcasecmp($strm,$str)==0?"selected":"").">$str</option>";
					echo "</SELECT></div>";
				}mysqli_free_result($rs);	
			}$i++;	
		}while(mysqli_next_result($conn));
		print '<div class="col-md-3"><label for="cboAcYr">Academic Year</label><SELECT name="cboAcYr" id="cboAcYr" size="4" required '.($admno[1]==1?"":"disabled").'><option selected>'.
		$admno[2].'</option></SELECT>';
	?></div>
</div><br>
<div class="form-row">
	<div class="col-md-3"></div><div class="col-md-3" style="border-radius:10px 10px 0px 0px;background:#999;color:#fff;">MAIN A/C ARREARS</div><div class="col-md-3" 
	style="border-radius:10px 10px 0px 0px;background:#999;color:#fff;">MISC A/C ARREARS</div><div class="col-md-3" style="border-radius:10px 10px 0px 0px;background:#999;color:#fff;">
	REFUNDABLE AMOUNT</div>
</div><div class="form-row">
	<div class="col-md-3"  style="text-align:right;font-weight:bold;">Current Amount</div><div class="col-md-3"><input type="text" name="txtPArr" id="txtPArr" maxlength="10" readonly 
	style="text-align:right;background:#ddd;font-weight:bold;" value="<?php echo number_format($bbf,2);?>"></div><div class="col-md-3"><input type="text" name="txtPMArr" id="txtPMArr" 
	maxlength="10" readonly style="text-align:right;background:#ddd;font-weight:bold;" value="<?php echo number_format($mbbf,2);?>"></div><div class="col-md-3"><input type="text" 
	name="txtPRef" id="txtPRef" maxlength="10" readonly style="text-align:right;background:#ddd;font-weight:bold;" value="<?php echo number_format($ref,2);?>"></div>
</div><br><div class="form-row">
	<div class="col-md-3" style="text-align:right;font-weight:bold;">New Amount</div><div class="col-md-3"><input name="txtArr" id="txtArr" type="text" maxlength="10" 
	style="text-align:right;" value="<?php echo number_format($bbf,2); ?>" onkeyup="checkNumber(this)"></div><div class="col-md-3"><input type="text" name="txtMArr" id="txtMArr" 
	maxlength="10" style="text-align:right;" value="<?php echo number_format($mbbf,2); ?>"></div><div class="col-md-3"><input type="text" name="txtRef" id="txtRef" maxlength="10" 
	readonly style="text-align:right;" value="<?php echo number_format($ref,2);?>"></div>
</div><br><div class="form-row">
	<div class="col-md-12"><lable for="txtRmks">Narration/ Reason for this Change *</label><Textarea name="txtRmks" id="txtRmks" rows="3" maxlength="150" style="text-transform:uppercase;"></textarea>
	</div>
</div><br><div class="form-row">
	<div class="col-md-6"><button type="submit" accesskey="s" name="cmdSave" id="cmdSave" style="height:40px;"><u>S</u>ave Fee Arrears Record</button></div>
	<div class="col-md-6" style="text-align:right;"><a href="studarrears.php?action=<?php echo "$admno[0]-$admno[2]-$admno[3]";?>"><button type="button" name="cmdClose" style="height:40px;">Cancel/ Close
	</button></div>
</div></form></div>
<?php mysqli_close($conn); footer(); ?>