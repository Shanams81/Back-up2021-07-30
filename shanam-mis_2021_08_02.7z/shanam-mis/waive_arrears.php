<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	$action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
	$rs=mysqli_query($conn,"SELECT finyr FROM ss"); if (mysqli_num_rows($rs)>0) list($finyr)=mysqli_fetch_row($rs); else $finyr=date('Y'); mysqli_free_result($rs);
	$rs=mysqli_query($conn,"SELECT arr_waive_view,arr_waive FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'"); 	$canviu=0; $canwaive=0;
	if(mysqli_num_rows($rs)==1) list($canviu,$canwaive)=mysqli_fetch_row($rs); 	mysqli_free_result($rs);
	$yr=isset($_POST['cboFinYr']) ? strip_tags($_POST['cboFinYr']): "%"; $yr=strcasecmp($yr,"all")==0?"%":$yr;
	$frm=isset($_POST['cboForm']) ? strip_tags($_POST['cboForm']): "%";
	$strm=isset($_POST['cboStream']) ? strip_tags($_POST['cboStream']): "%";
	$findby=isset($_POST['radFind']) ? $_POST['radFind'] : "stud_names";
	$find=isset($_POST['txtFind']) ? $_POST['txtFind'] : "%";					
?>
<html>
<head>
	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<script type="text/javascript" src="tpl/actionmessage.js"></script>
</head>
<body background="../gen_img/bg3.gif" <?php print "onload=\"actiondone($action[0],$action[1])\"";?>>
	<?php
		print "<center><form method=\"post\" action=\"waive_arrears.php\"><a href=\"waivers.php\"><img src=\"../gen_img/ani_back.gif\" hspace=\"1\" width=\"45\" 
		height=\"20\" align=\"left\"></a>&nbsp;	Financial Year <SELECT name=\"cboFinYr\" Size=\"1\"><option value=\"%\" selected>All</option>";
		$rs=mysqli_query($conn,"SELECT min(curr_year) as minyr FROM form"); $maxyr=date('Y'); 
		if (mysqli_num_rows($rs)>0) list($minyr)=mysqli_fetch_row($rs); else $minyr=$maxyr; mysqli_free_result($rs);
		for ($i=$maxyr;$i>=$minyr;$i--) print "<option>$i</option>";
		print "</SELECT> <label for=\"form\">Form</label>&nbsp;&nbsp;<SELECT name=\"cboForm\" size=\"1\" id=\"form\"><option value=\"%\" selected>All</Option><option>Four</Option>
		<option>Three</Option><option>Two</Option><option>One</option></SELECT> - <SELECT name=\"cboStream\" size=\"1\" id =\"stream\"><option 
		selected value=\"%\">All</option>";	 
		$rsStr=mysqli_query($conn,"SELECT strm FROM grps WHERE strm is not null") or die(mysqli_error($conn).' Error in database connection'); 
		if (mysqli_num_rows($rsStr)>0) while (list($str)=mysqli_fetch_row($rsStr)) print "<option>$str</option>";
		mysqli_free_result($rsStr);
		print "</select>&nbsp;&nbsp;&nbsp;Or Find By:&nbsp;&nbsp;<input type=\"radio\" name=\"radFind\" value=\"admno\">Adm. No.&nbsp;&nbsp;<input type=\"radio\" 
		name=\"radFind\" value=\"stud_names\" checked>Student Name &nbsp;&nbsp;<input type=\"text\" maxlength=\"17\" size=\"20\" name=\"txtFind\" id=\"adno\" 
		value=\"%\">&nbsp;&nbsp;&nbsp;<button type=\"submit\" name=\"cmdArrears\"><b>Show Arrears B/F</b></button> &nbsp; &nbsp; <button type=\"submit\" name=\"cmdWaive\"> 
		<b><i>Show Arrears Waived</i></b></button></form></center><hr>";
		if (isset($_POST['cmdArrears']) || isset($_POST['cmdWaive'])):
			if (strcasecmp("%",$yr)==0 && strcasecmp("%",$frm)==0 && strcasecmp("%",$strm)==0) $h="All ";
			elseif (strcasecmp("%",$yr)!=0 && strcasecmp("%",$frm)==0 && strcasecmp("%",$strm)==0) $h="All ".$yr;
			elseif (strcasecmp("%",$yr)==0 && strcasecmp("%",$frm)!=0 && strcasecmp("%",$strm)==0) $h="All Form ".$frm;
			elseif (strcasecmp("%",$yr)==0 && strcasecmp("%",$frm)==0 && strcasecmp("%",$strm)!=0) $h="All ".$strm." stream ";
			elseif (strcasecmp("%",$yr)!=0 && strcasecmp("%",$frm)!=0 && strcasecmp("%",$strm)==0) $h="All ".$yr." form ".$frm;
			elseif (strcasecmp("%",$yr)!=0 && strcasecmp("%",$frm)==0 && strcasecmp("%",$strm)!=0) $h="All ".$yr." ".$strm." stream ";
			elseif (strcasecmp("%",$yr)==0 && strcasecmp("%",$frm)!=0 && strcasecmp("%",$strm)!=0) $h="All form ".$frm."-".$strm;
			else $h= $yr." Form ".$frm." ".$strm;
			if (isset($_POST['cmdArrears'])) $h.=" Fees"; else $h.=" Waived";
			$h.=" Arrears as on ".date('D d M, Y');
		else:
			$h= "Fee Arrears C/F - User Manuals (Please Read)";
		endif;
		print "<h3 style=\"text-align:center;letter-spacing:2px;word-spacing:3px;\">".strtoupper($h)."</h3>";
	?>
</body>
</html>
<?php
if (isset($_POST['cmdArrears'])):
	$find=strlen(trim($find))>0?$find:"%";	
	if (strcasecmp($find,"%")==0){
	 	$sql="SELECT a.admno, concat(a.surname,' ',a.onames) as `stud_names`,concat(sf.form, '-',sf.stream) as frm,a.curr_year,if(y.finyr=a.curr_year,(r.bf+r.mbf+
		IF(f.ttl Is Null,0,f.ttl)+if(isnull(w.wamt),0,w.wamt)),(r.alarr+IF(f.ttl Is Null,0,f.ttl)+if(isnull(w.wamt),0,w.wamt))) As ArrBF, IF(f.ttl Is Null,0,f.ttl) As 
		AmtPaid, if(y.finyr=a.curr_year,(r.bf+r.mbf),r.alarr) As bal, if(isnull(w.wamt),0,w.wamt) as waive,if(a.cleared=1,'Yes','No') as clr FROM stud a Inner Join 
		form sf Using (admno,curr_year) INNER JOIN (SELECT admno,sum(bbf) as bf,sum(miscbf) as mbf, sum(alumniarrears) as alarr FROM form GROUP BY admno,markdel HAVING 
		markdel=0)r ON (a.admno=r.admno) LEFT JOIN (SELECT admno, sum(amt_waived) as wamt from arrears_waive group by markdel,admno having markdel=0)w ON 
		(a.admno=w.admno) LEFT JOIN (SELECT admno,sum(arrears) as ttl FROM `acc_feerec` GROUP BY markdel,admno HAVING markdel=0)f ON (a.admno=f.admno), (SELECT finyr 
		FROM ss)y WHERE (a.markdel=0 and sf.curr_year LIKE '$yr' and sf.form LIKE '$frm' and sf.stream LIKE '$strm') ORDER BY a.surname,a.onames Asc";
	}else{
		if (strcasecmp($findby,"stud_names")==0):
			$find=mysqli_real_escape_string($conn,$find);
			$sql="SELECT a.admno, concat(a.surname,' ',a.onames) as `stud_names`,concat(sf.form, '-',sf.stream) as frm,a.curr_year,if(y.finyr=a.curr_year,(r.bf+r.mbf+
			IF(f.ttl Is Null,0,f.ttl)+if(isnull(w.wamt),0,w.wamt)),(r.alarr+IF(f.ttl Is Null,0,f.ttl)+if(isnull(w.wamt),0,w.wamt))) As ArrBF, IF(f.ttl Is Null,0,f.ttl) As 
			AmtPaid, if(y.finyr=a.curr_year,(r.bf+r.mbf),r.alarr) As bal, if(isnull(w.wamt),0,w.wamt) as waive,if(a.cleared=1,'Yes','No') as clr FROM stud a Inner Join 
			form sf Using (admno,curr_year) INNER JOIN (SELECT admno,sum(bbf) as bf,sum(miscbf) as mbf, sum(alumniarrears) as alarr FROM form GROUP BY admno,markdel HAVING 
			markdel=0)r ON (a.admno=r.admno) LEFT JOIN (SELECT admno, sum(amt_waived) as wamt from arrears_waive group by markdel,admno having markdel=0)w ON 
			(a.admno=w.admno) LEFT JOIN (SELECT admno,sum(arrears) as ttl FROM `acc_feerec` GROUP BY markdel,admno HAVING markdel=0)f ON (a.admno=f.admno), (SELECT finyr 
			FROM ss)y  WHERE (a.`markdel`=0 and (a.surname LIKE '%$find%' and a.onames LIKE '%$find%') and sf.curr_year LIKE '$yr') ORDER BY a.`surname`,a.`onames` Asc";
		else:
			$sql="SELECT a.admno, concat(a.surname,' ',a.onames) as `stud_names`,concat(sf.form, '-',sf.stream) as frm,a.curr_year,if(y.finyr=a.curr_year,(r.bf+r.mbf+
			IF(f.ttl Is Null,0,f.ttl)+if(isnull(w.wamt),0,w.wamt)),(r.alarr+IF(f.ttl Is Null,0,f.ttl)+if(isnull(w.wamt),0,w.wamt))) As ArrBF, IF(f.ttl Is Null,0,f.ttl) As 
			AmtPaid, if(y.finyr=a.curr_year,(r.bf+r.mbf),r.alarr) As bal, if(isnull(w.wamt),0,w.wamt) as waive,if(a.cleared=1,'Yes','No') as clr FROM stud a Inner Join 
			form sf Using (admno,curr_year) INNER JOIN (SELECT admno,sum(bbf) as bf,sum(miscbf) as mbf, sum(alumniarrears) as alarr FROM form GROUP BY admno,markdel HAVING 
			markdel=0)r ON (a.admno=r.admno) LEFT JOIN (SELECT admno, sum(amt_waived) as wamt from arrears_waive group by markdel,admno having markdel=0)w ON 
			(a.admno=w.admno) LEFT JOIN (SELECT admno,sum(arrears) as ttl FROM `acc_feerec` GROUP BY markdel,admno HAVING markdel=0)f ON (a.admno=f.admno), (SELECT finyr 
			FROM ss)y WHERE (a.`markdel`=0 and a.admno LIKE '$find' and sf.curr_year LIKE '$yr') ORDER BY a.`surname`,a.`onames` Asc";
		endif;
	}
	$rsStud=mysqli_query($conn,$sql);
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\" align=\"center\"><tr align=\"middle\"><th colspan=\"3\">Students'/Alumni's Details</th><th 
	colspan=\"4\">Arrears  B/F Details</th><th rowspan=\"2\">Cleared</th><th rowspan=\"2\">Administrative<br>Action</th><tr bgcolor=\"#eeeeee\"><th>Adm. No.</th><th>
	Names</th><th>Form</th><th>Arrears B/F</th><th>Amt Waived</th><th>Arrears Paid</th><th>Balance</th></tr>";
	$ttl=array(0,0,0,0); $i=0;
	if (mysqli_num_rows($rsStud)>0):
		while (list($admno,$name,$form,$dyr,$arr,$paid,$bal,$waive,$clrd)=mysqli_fetch_row($rsStud)):
			if ($arr>0){
				if ($i%2==0) print "<tr>"; else	print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">"; 
			print "<td>$admno</td><td>".strtoupper($name)."</td><td>$form $dyr</td><td align=\"right\">".number_format($arr,2)."</td><td align=\"right\">".
			number_format($waive,2)."</td><td align=\"right\">".number_format($paid,2)."</td><td align=\"right\">".number_format($bal,2)."</td><td align=\"center\">
			$clrd</td>";
			print "<td align=\"center\" valign=\"middle\">".(($canwaive==1 && $bal>0)?"<a href=\"Waive_Curr_Arrears.php?admno=$admno-$dyr-1\">Waive Arrears</a>":" - ").
			"</td></tr>";
			$ttl[0]+=$arr;	$ttl[1]+=$waive;	$ttl[2]+=$paid;	$ttl[3]+=$bal;
			}	$i++;
		endwhile;	
	endif;
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"2\" align=\"left\" class=\"b\">".(mysqli_num_rows($rsStud))." Arrears' Records</td><td align=\"right\" class=\"b\">
	Subtotals (Kshs.)</td><td align=\"right\" class=\"b\">".number_format($ttl[0],2)."</td><td align=\"right\" class=\"b\">".number_format($ttl[1],2)."</td>
	<td align=\"right\" class=\"b\">".number_format($ttl[2],2)."</td><td align=\"right\" class=\"b\">".number_format($ttl[3],2)."</td><td colspan=\"2\"></td></tr>
	</table>";
	mysqli_free_result($rsStud);
	print "<center>Report Generated on ".date("l F d, Y")."</center>";
elseif (isset($_POST['cmdWaive'])):
	$find=strlen(trim($find))>0 ? $find :"%";
	if (strcasecmp($find,"%")==0){
	 	$sql="SELECT w.waivedon,a.admno,concat(a.surname,' ',a.onames) as stud_names,concat(sf.form,'-', sf.stream) as frm,w.curr_year,w.arr_waived,w.misc_waived,
		w.amt_waived,w.rmks,a.type FROM stud a Inner Join form sf USING (admno) INNER JOIN arrears_waive w On (sf.admno=w.admno and sf.curr_year=w.curr_year) 
		WHERE (sf.form LIKE '$frm' and sf.stream LIKE '$strm' and w.curr_year LIKE '$yr' and w.markdel=0) ORDER BY w.waivedon,a.`surname`, a.`onames` Asc";
	}else{
		if (strcasecmp($findby,"stud_names")==0):
			$find=mysqli_real_escape_string($conn,$find);
			$sql="SELECT w.waivedon,a.admno,concat(a.surname,' ',a.onames) as stud_names,concat(sf.form,'-', sf.stream) as frm,w.curr_year,w.arr_waived,w.misc_waived,
			w.amt_waived,w.rmks,a.type FROM stud a Inner Join form sf USING (admno) INNER JOIN arrears_waive w On (sf.admno=w.admno and sf.curr_year=w.curr_year) 
			WHERE (a.surname LIKE '%$find%' and a.onames LIKE '%$find%' and w.curr_year LIKE '$yr' and w.markdel=0) ORDER BY a.`surname`,a.`onames` Asc";
		else:
			$sql="SELECT w.waivedon,a.admno,concat(a.surname,' ',a.onames) as stud_names,concat(sf.form,'-', sf.stream) as frm,w.curr_year,w.arr_waived,w.misc_waived,
			w.amt_waived,w.rmks,a.type FROM stud a Inner Join form sf USING (admno) INNER JOIN arrears_waive w On (sf.admno=w.admno and sf.curr_year=w.curr_year) 
			WHERE a.admno LIKE '$find' and w.curr_year LIKE '$yr' and w.markdel=0 ORDER BY a.`surname`,a.`onames` Asc";
		endif;
	}$rsStud=mysqli_query($conn,$sql);
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\" align=\"center\"><tr bgcolor=\"#eeeeee\"><th rowspan=\"2\">S/N</th><th rowspan=\"2\">Waived On</th><th 
	colspan=\"3\">Student/Alumni's Details</th><th colspan=\"4\">Amount of Arrears Waived</th><th rowspan=\"2\">Reason for the waive</th><th rowspan=\"2\">Administrative
	<br>Actions</th><tr bgcolor=\"#eeeeee\"><th>Adm. No.</th><th>Names</th><th>Form</th><th>Arrears of</th><th>Misc A/C</th><th>Main A/C</th><th>Total</th></tr>";
	$mainw=0; $miscw=0; $ttlwaive=0; $i=0; $now=mysqli_num_rows($rsStud);
	if ($now>0){
		while (list($wvon,$wvad,$wvna,$wvfr,$wvyr,$warr,$wmarr,$wttl,$wrmk,$wvtp)=mysqli_fetch_row($rsStud)){
			if($i%2==1) print "<tr bgcolor=\"#eeeeee\">"; else print "<tr>"; $i++;
			print "<td>$i.</td><td align=\"right\">".date('D d M, Y',strtotime($wvon))."</td><td>$wvad</td><td>$wvna</td><td>$wvfr</td><td align=\"center\">$wvyr</td><td align=\"right\">".
			number_format($wmarr,2)."</td><td align=\"right\">".number_format($warr,2)."</td><td align=\"right\">".number_format($wttl,2)."</td><td>$wrmk</td><td 
			align=\"center\">".(($canwaive==1)?"<a href=\"Waive_Arrears_Edit.php?admno=$wvad-$wvyr-$wvtp\">Edit Record</a>":" - ")."</td></tr>";
			$mainw+=$warr;	$miscw+=$wmarr;	$ttlwaive+=$wttl;
		}
	}else print "<tr><td colspan=\"11\">No waive records are available</tr>";
	print "<tr><td colspan=\"3\" style=\"font-weight:bold;\">$now Arrears Waive Record(s)</td><td colspan=\"3\" align=\"right\">Subtotals (Kshs.)</td><td align=\"right\">
	".number_format($miscw,2)."</td><td align=\"right\">".number_format($mainw,2)."</td><td align=\"right\">".number_format($ttlwaive,2)."</td><td colspan=\"2\"></td></tr>
	</table>";
	print "<center>Report Generated on ".date("l F d, Y")."</center>";
else:
	print "<ol type=\"1\"><li>To view <b><u>Fee Arrears Carried Forward (C/F)</u></b>,<ol type=\"a\"><li>Select the financial year whose statement is to be viewed,
	<li>Select the Form and Stream whose arrears are to be viewed or <li>To find a specific student/Alumni: Select to search by either Admission number or names 
	and Enter the detail in the textbox and <li>Click <b>Show Arrears C/F </b> button.</ol>";
	print "<li>To view <b><u>Waived Arrears</u></b>,<ol type=\"a\"<li>Select the financial year whose statement is to be viewed,
	<li>Select the Form and Stream whose waived arrears are to be viewed or <li>To find a specific student/Alumni: Select to search by either Admission number or 
	names and Enter the detail in the textbox and <li>Click <b>Show Waived Arrears</b> button.</ol></ol>";
endif;
mysqli_close($conn);
?>