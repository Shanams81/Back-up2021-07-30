<!DOCTYPE html>
<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	if (isset($_POST["btnSave"])){
		$act=isset($_POST['txtNo'])?strip_tags($_POST['txtNo']):"0-0"; 			$act=preg_split('/\-/',$act);
		$sNo=isset($_POST['cboAccount'])?strip_tags($_POST['cboAccount']):0;	$amt=isset($_POST['txtDeposit'])?strip_tags($_POST['txtDeposit']):0;
		$nar=isset($_POST['txtRmks'])?strip_tags($_POST['txtRmks']):"";			$amt=preg_replace("/[^0-9^\.]/","",$amt); 	$action[0]=0; $action[0]=0;
		if(($act[0]==0 && $act[1]==0) || $amt==0 || strlen($nar)<10 || $sNo==0){
			print "Saving Failed. Ensure records are properly entered before saving. Click <a href=\"confirmtrans.php\">HERE</a> to go back."; exit(0);
		}elseif (($_SESSION['form_token']==$_POST['form_token'])){
	 		mysqli_query($conn,"INSERT acc_banking(transano,transdate,bank_type,cheno,acSno,amt,rmks,addedby) VALUES (0,'".date("Y-m-d")."',0,null,'$sNo','$amt','$nar',
			'".$_SESSION['username']." (".$_SESSION['priviledge'].")')") or die(mysqli_error($conn)." Banking details not saved. Click <a href=\"confirmtrans.php\">
			HERE</a> to go back");	 $i=mysqli_affected_rows($conn);
		 	if ($i>0){
			 	$rs=mysqli_query($conn,"SELECT last_insert_id()"); list($id)=mysqli_fetch_row($rs); mysqli_free_result($rs); $sql=""; $norecs=0; 
			 	if ($id>0){
				 for ($i=1;$i<=$act[0];$i++){
						$val=isset($_POST["chkBank_$i"])?strip_tags($_POST["chkBank_$i"]):0;
						if ($val==1){
							$recNo=strip_tags($_POST["txtRec_$i"]); 
							$sql.="UPDATE ".($act[1]==1?"acc_feerec":(($act==2||$act==3)?"acc_oacrec":"acc_miscfeepyts"))." SET verDate='".date("Y-m-d")."',
							verstate=1,verbanked=1 WHERE ".(($act[1]==1||$act==2||$act==3)?"recieptno":"recipetno")." LIKE '$recNo';";
							$norecs++;
						}
					}if (strlen($sql)>0){mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Income confirmation failed. Click <a href=\"confirmtrans.php\">HERE
					</a> to go back"); $action[0]=1; $action[1]=1;  while(mysqli_next_result($conn)){$action[1]+=mysqli_affected_rows($conn);}}
				}
			}else{print "Error in banking fees income";}	$sda="01-01-".date('Y'); $eda=date('d-m-Y');
		}unset($_SESSION['form_token']);
	}else{
		$rec=isset($_REQUEST['rec'])?$_REQUEST['rec']:0;
		$rsBank=mysqli_query($conn,"SELECT b.transdate,if(b.bank_type=0,'Deposit','Withdrawal') as btype,concat(a.acctype,' Account -',a.bank,' (',a.branch,') A/C No. ',a.accNo) 
		as ac,b.amt,b.rmks FROM acc_banking b Inner Join acc_accounts a On (b.acsno=a.sno) WHERE b.transano LIKE '$rec'");
		list($date,$type,$ac,$amt,$rmks)=mysqli_fetch_row($rsBank);
	}
?>
<html>
	<head>
		<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="../date/tcal.css" />
		<script type="text/javascript" src="../date/tcal.js"></script>
		<script type="text/javascript" src="tpl/confirmTrans.js"></script>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Fees Banking</title>
		<script type="text/javascript" src="tpl\actionmessage.js"></script>
    </head>
<body background="../gen_img/bg3.gif" <?php print "onload=\"actiondone($action[0],$action[1])\"";?>>
<form method="post" action="confirmtrans.php" name="frmFind">
<?php 
	$h=($state==0?"Unbanked ":"Banked ").$acName." Account FSE income Between <font color=\"#0000ff\">".date("D d-M-Y",strtotime($sda))."</font> and <font color=\"#0000ff\">".
	date("D d-M-Y",strtotime($eda))."</font>in $mode.";
	$sql="SELECT f.recieptno,f.dateofpayt,f.batchno,if(f.rmks like 'fse fees','MoE FSE Fund',f.rmks) as names,f.mode,f.modeno,f.ttlamt,f.verstate FROM 
	acc_oacrec f Inner Join acc_fsevote v on (f.recieptno=v.recno and f.ac=v.ac) WHERE f.markdel=0 and f.verstate=$state and f.commt in('0','2','4') and f.mode 
	LIKE '$mode' and (f.dateofpayt between '$sdate[2]-$sdate[1]-$sdate[0]' and '$edate[2]-$edate[1]-$edate[0]') order by f.recieptno asc limit 0,100";
	$rs=mysqli_query($conn,$sql);	$nor=mysqli_num_rows($rs);
	print "<center><h3>".strtoupper($h)."</h3></center>";	
	//Show data 
	print "<form name=\"frmData\" method=\"post\" action=\"confirmtrans.php\"style=\"font-size:9pt;\" onsubmit=\"return confirmData($nor)\"><table 
	cellpadding=\"1\" cellspacing=\"0\" align=\"center\" border=\"1\" style=\"font-size:9pt;\"><tr><th>S/No.</th><th>Receipt No.</th><th>Received On</th><th>".
	($rmks==0?"Adm.No.":($rmks==1?"ID. No.":"Tranche No."))."</th><th>Received From</th><th>Mode</th><th>Mode No.</th><th>Amount</th><th>Banked<br><input 
	type=\"checkbox\" name=\"chkAll\" id=\"chkAll\" value=\"1\" onclick=\"selectAll(".($nor>100?100:$nor).")\" ".($state==0?"":"disabled").">All</th></tr>";
	$i=1; $ttl=0;	$nor=$nor>100?100:$nor;		print "<input type=\"hidden\" name=\"txtNo\" value=\"$nor-$acc-$rmks\">";
	if ($nor>0){
		while ((list($recno,$dat,$no,$names,$mode,$modeno,$amt,$st)=mysqli_fetch_row($rs)) && ($i<=$nor)):
			print "<tr><td>$i</td><td><input type=\"text\" size=\"7\" name=\"txtRec_$i\" name=\"txtRec_$i\" readonly style=\"border:0px;text-align:center;opacity:0.6;\" 
			value=\"$recno\"></td><td align=\"right\">".date("D d M, Y",strtotime($dat))."</td><td>$no</td><td>$names</td><td>$mode</td><td>$modeno<td 
			align=\"right\"><input size=\"10\" 
			type=\"text\" name=\"txtAmt_$i\" id=\"txtAmt_$i\" readonly style=\"border:0px;text-align:right;opacity:0.6;\" value=\"".number_format($amt,2)."\"></td><td 
			align=\"center\"><input type=\"checkbox\" name=\"chkBank_$i\" id=\"chkBank_$i\" value=\"1\" ".($st==1?"checked disabled":"")." ".($state==0?"":
			"disabled")." onclick=\"calcTtl($i,$nor)\"></td></tr>";	$ttl+=$amt; 	$i++;
		endwhile;
		if ($nor>100) print "SHOWING FIRST 100 OF $nor FEE RECORDS";
	}else{
		$sda="$sdate[2]-$sdate[1]-$sdate[0]";	$eda="$edate[2]-$edate[1]-$edate[0]";
		print "<tr><td colspan=\"9\"><br>No unbanked fees receipts were made between ".date("D d-M-Y",strtotime($sda))." and ".date("D d-M-Y", strtotime($eda))."</td>
		</tr>";
	}
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\"><b>$nor Income Record(s) for Banking</b></td><td colspan=\"3\" align=\"right\"><b>Total 
	Kshs.</b></td><td align=\"left\" colspan=\"2\"><input name=\"txtTtl\" id=\"txtTtl\" style=\"font-weight:bold;text-align:right;border:0px;background-color:#093;\" readonly 
	size=\"12\" value=\"".number_format($ttl,2)."\"></td></tr></tr></table><br><br>";
	print "</form>";
	mysqli_close($conn);
?>
</body></html>