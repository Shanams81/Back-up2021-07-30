<?php
	declare(strict_types=1); 	include_once('shanam.php');
	if (isset($_POST['btnSave'])){
		$tno=isset($_POST['txtData'])?sanitize($_POST['txtData']):"0-0-0"; 	$tno=explode('-',$tno); //[0]=0 new 1 editing,[1]=trans no, [2]-delete ability
		$sdate=isset($_POST['txtDate']) ?sanitize($_POST['txtDate']):date("d-m-Y"); $sdate=explode("-",$sdate); $sdate="$sdate[2]-$sdate[1]-$sdate[0]";
		$acsno=isset($_POST['cboAC'])?intval(sanitize($_POST['cboAC'])):0;		$type=isset($_POST['cboType'])?intval(sanitize($_POST['cboType'])):1; $r=0;
		$cheno=isset($_POST['txtCheNo'])?sanitize($_POST['txtCheNo']):'';			$rmks=isset($_POST['txtRmks'])?strtoupper(sanitize($_POST['txtRmks'])):"";
		$origamt=isset($_POST['txtOrigAmt'])?sanitize($_POST['txtOrigAmt']):0;$origamt=floatval(preg_replace('/[^0-9\.]/','',$origamt));
		$amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0;			$amt=floatval(preg_replace('/[^0-9\.]/','',$amt));	$ac=isset($_POST['txtAC'])?intval(sanitize($_POST['txtAC'])):0;
		$bal=isset($_POST['txtBal'])?sanitize($_POST['txtBal']):0;			$bal=floatval(preg_replace('/[^0-9\.]/','',$bal)); $adby=$_SESSION['username']." (".$_SESSION['priviledge'].")";
		//echo "Amount=$amt, Balance=$bal, Remarks=\"$rmks\", Bank A/C=$acsno,CHeque No=$cheno, Type od Transaction=$type";
		if ($amt>1000 && ($origamt+$amt)<$bal && strlen($rmks)>10 && $acsno>0 && ((strlen($cheno)>2 && $type==1) || $type==0)) {
		 	if ($tno[0]==0)	$sql="INSERT INTO acc_banking (sno,transdate,acsno,bank_type,cheno,rmks,transtype,amt,addedby) VALUES (0,'$sdate','$acsno','$type','$cheno','$rmks',7,'$amt',
			'$adby');"; //New transaction
			else $sql="UPDATE acc_banking SET transdate='$sdate',acsno='$acsno',bank_type='$type',cheno='$cheno',transtype=7,rmks='$rmks',amt='$amt' WHERE sno=$tno[1]";//Editing
			if(mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"withdrawals.php\">HERE</a> to go back.")){
				$r=mysqli_affected_rows($conn); $sno=mysqli_insert_id($conn); $sql="";
				if($r>0 && $tno[0]==0) $sql="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES(0,$ac,0,'$sdate','Bank Withdrawal',$amt,1,$sno,'$adby')";
				elseif($r>0 && $tno[0]==1) $sql="UPDATE acc_cashflow acc=$ac,cftype=0,cfdate='$sdate',rmks='Bank Withdrawal',amt=$amt WHERE transtype=1 and transno=$tno[1]";
				if(strlen($sql)>0) mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"withdrawals.php\">HERE</a> to go back.");
			}
		} header("location:withdrawals.php?action=1-$r"); exit(0);
	}elseif(isset($_POST['btnDel'])){
		$tno=isset($_POST['txtData'])?sanitize($_POST['txtData']):"0-0-0";	$tno=preg_split('/\-/',$tno); //[0]=0 new 1 editing,[1]=trans no, [2]-delete ability
		$rmks=isset($_POST['txtDelRmks'])?sanitize($_POST['txtDelRmks']):'';
		if(strlen($rmks)>10){mysqli_multi_query($conn,"UPDATE acc_banking SET delreason='$rmks',markdel=1 WHERE sno=$tno[1];UPDATE acc_cashflow SET delreason='$rmks',markdel=1 WHERE
			transtype=1 and transno=$tno[1];"); $r=mysqli_affected_rows($conn); while(mysqli_next_result($conn)){}
		}else $r=0;	header("location:withdrawals.php?action=2-$r");
	}$tno=isset($_REQUEST['tno'])?strip_tags($_REQUEST['tno']):"0-0-0"; $tno=preg_split('/\-/',$tno); //[0]=0 new 1 editing,[1]=trans no, [2]-delete ability
	$date=date("Y-m-d");	$type=1;	$ac=0;	$rmks='';	$amt="0.00"; $cheno=$acname='';
	if($tno[0]==1){ //opened for editing
		$rs=mysqli_query($conn,"SELECT transdate,bank_type,cheno,acsno,amt,rmks FROM acc_banking WHERE sno LIKE '$tno[1]'");
		list($date,$type,$cheno,$ac,$amt,$rmks)=mysqli_fetch_row($rs); mysqli_free_result($rs);
	}$rs=mysqli_query($conn,"SELECT a.sno,concat(k.descr,' - A/C NO. ',a.accno) as bank,a.accacc,if(isnull(b.bal),0,b.bal)	as amt,v.abbr FROM acc_accounts a Inner Join acc_banks k ON
	(a.bankno=k.sno) Left Join (SELECT acsno,sum(if(bank_type=0,amt,0)-if(bank_type=1,amt,0)) as bal FROM `acc_banking` Group By markdel,acsno HAVING markdel=0)b ON (a.sno=b.acsno)
	Inner Join acc_voteacs v On (a.accacc=v.acno)	WHERE a.markdel=0 and v.wd=1 Order By a.sno");
	$optbankacs=$lstBal=''; $c=$bal=0;
	while($d=mysqli_fetch_row($rs)){$lstBal.=($c==0?"":",")."new AccBal($d[0],$d[2],$d[3],'$d[4]')"; $optbankacs.="<option value=\"$d[0]\" ".($ac==$d[0]?"selected":"").">$d[1]</option>";
	if($ac==$d[0]){$bal=$d[3]; $acname='<br>CREDITING CASH AT HAND OF <BR>'.$d[4];}$c++;} mysqli_free_result($rs);
	headings('<link rel="stylesheet" href="/date/tcal.css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"/>',0,0,2);
?>
<div class="container" id="print_content" style="width:630px;margin:50px auto;background-color:#e6e6e6;border-radius:10px 10px 0 0;">
	<form method="post" action="banking.php" onsubmit="return validateInput(this)">
	<div class="form-row"><div class="col-md-12 divheadings">CASH AT BANK WITHDRAWAL EDITOR<input name="txtData" type="hidden" value="<?php echo "$tno[0]-$tno[1]-$tno[2]";?>"></div></div>
	<div class="form-row">
		<div class="col-md-4"><label for="txtTransNo">Transction No.</label><input type="text" name="txtTransNo" id="txtTransNo" readonly class="modalinput" value="<?php echo $tno[0]==1?
		$tno[1]:"";?>"></div><div class="col-md-5" id="divACName" style="text-align:center;color:#00f;"><?php echo $acname;?></div>
		<div class="col-md-3"><label for="txtDate">Transacted On</label><input type="text" class="tcal modalinput" readonly value="<?php echo date("d-m-Y",strtotime($date));?>" name="txtDate"
			id="txtDate"></div>
	</div><div class="form-row">
		<div class="col-md-9"><label for="cboAc">Bank A/C</label><select size="1" name="cboAC" id="cboAC" class="modalinput" onchange="showBal(this)"><option value="0" selected>
			Choose ACCOUNT</option><?php echo $optbankacs;?></select><input type="hidden" name="txtAC" id="txtAC" value="" size="2"></div>
		<div class="col-md-3"><label for="cboType">Type of Transaction</label><SELECT size="1" name="cboType" id="cboType" class="modalinput"><option value="1"
			<?php echo ($type==1?"selected":"");?>>Withdrawal</option><option value="0" <?php echo ($type==0?"selected":"");?>>Deposits</option></SELECT></div>
	</div><div class="form-row">
		<div class="col-md-4"><label for="txtCheNo">Cheque/Trans No.</label><input type="text" name="txtCheNo" id="txtCheNo" class="modalinput" required value="<?php echo $cheno;?>"></div>
		<div class="col-md-5"><label for="txtBal">Current Bank A/C Balance</label><input type="Text" name="txtBal" id="txtBal" class="modalinput modalinputdisabled" maxlength="12" readonly
			onkeyup="checkInput(this)" value="<?php echo number_format(floatval($bal),2);?>" style="color:#00f;text-align:center;" required></div>
		<div class="col-md-3"><label for="txtAmt">Amount Transacted</label><input type="hidden"	name="txtOrigAmt" id="txtOrigAmt"	value="<?php echo number_format(floatval($amt),2);?>"><input
			type="Text"	name="txtAmt" id="txtAmt"	maxlength="12" class="modalinput numbersinput" onkeyup="checkInput(this)" onblur="checkAmt(this,<?php echo $tno[0];?>)" <?php echo $tno[0]!=1?
			'readonly':'';?>	value="<?php echo number_format(floatval($amt),2);?>"></div>
	</div><div class="form-row">
		<div class="col-md-12"><label for="txtRmks">Remarks on the Transaction</label><textarea name="txtRmks" id="txtRmks" rows="3" placeholder="To Support Day-to-day running of the institute"
			class="modalinput" required maxlength="150"><?php echo $rmks;?></textarea></div>
	</div><hr><div class="form-row" id="divBtn">
		<div class="col-md-4"><button type="submit" accesskey="s" name="btnSave" class="btn btn-primary btn-block btn-md"><u>S</u>ave Transaction</button></div>
		<div class="col-md-4" style="text-align:right;"><?php echo ($tno[0]==1?"<button type=\"button\" accesskey=\"d\" name=\"cmdDel\" id=\"cmdDel\" ".($tno[2]==0?"disabled":"")."
			class=\"btn btn-warning btn-md\" onclick=\"showDel()\">Delete Transaction</button>":"");?></div>
		<div class="col-md-4" style="text-align:right;"><button type="button" accesskey="c" name="cancel" onclick="window.open('withdrawals.php?action=0-0','_self')"
			class="btn btn-warning btn-info">Cancel/Close</button></div>
	</div><hr><div class="form-row" id="divDel" style="visibility:hidden">
		<div class="col-md-9"><label for="txtDelRmks">Reason for Deleting Withdrawal Transaction</label><textarea name="txtDelRmks" id="txtDelRmks" rows="3" maxlength="150"	class="modalinput"
			placeholder="Double-entry of the withdrawal transaction"	class="modalinput" onkeyup="enableDel(this)"></textarea></div>
		<div class="col-md-3"><div class="form-row">
			<div class="col-md-12"><button type="submit" name="btnDel" id="btnDel" disabled class="btn btn-info btn-block btn-md">Delete Transaction</button><br></div>
			<div class="col-md-12" style="text-align:right"><button type="button" name="btnDel" id="btnDel" class="btn btn-primary btn-md" onclick="closeDel()">Cancel</button></div>
		</div></div>
	</div>
</div>
<script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/banking.js"></script>
<script type="text/javascript"> accbal.push(<?php echo $lstBal;?>); </script>
<?php mysqli_close($conn); footer();?>
