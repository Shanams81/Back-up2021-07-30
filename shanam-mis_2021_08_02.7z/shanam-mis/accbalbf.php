<?php
	declare(strict_types=1); 	include_once('shanam.php');
	$rs=mysqli_multi_query($conn,"SELECT finyr FROM ss;SELECT accedit FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");$i=$acedit=0;
	do{
		if($rs=mysqli_store_result($conn)){if($i==0) list($finyr)=mysqli_fetch_row($rs); else list($acedit)=mysqli_fetch_row($rs); mysqli_free_result($rs);}$i++;
	}while (mysqli_next_result($conn));
	$action=isset($_REQUEST['action'])?sanitize($_REQUEST['action']):'0-0'; $action=explode('-',$action);
	if(isset($_POST['btnSave1'])){
		$acsno=isset($_POST['txtInfo1'])?sanitize($_POST['txtInfo1']):0;	$bal=isset($_POST['txtNewBal1'])?sanitize($_POST['txtNewBal1']):0; $bal=preg_replace('/[^0-9\.\-]/','',$bal);
		mysqli_query($conn,"UPDATE acc_acbalbf SET bankbalbf=$bal WHERE acsno='$acsno'"); $action[1]=mysqli_affected_rows($conn); $action[0]=1;
	}elseif(isset($_POST['btnSave2'])){
		$acno=isset($_POST['txtInfo2'])?sanitize($_POST['txtInfo2']):0;	$bal=isset($_POST['txtNewBal2'])?sanitize($_POST['txtNewBal2']):0; 	$bal=preg_replace('/[^0-9\.\-]/','',$bal);
		mysqli_query($conn,"UPDATE acc_votebalbf SET cashbalbf=$bal WHERE acc='$acno'"); $action[1]=mysqli_affected_rows($conn); $action[0]=1;
	}headings('<link href="tpl/css/inputsettings.css" rel="stylesheet" type="text/css"/><link rel="stylesheet" href="tpl/css/modalfrm.css" /><link rel="stylesheet" href="tpl/css/cashflow.css">',$action[0],$action[1],2);
?><div class="container divlrborder" style="top:20px;position:relative;background-color:#e6e6e6;border-radius:15px;"><form method="post" name="frmBalBF" action="#">
	<div class="form-row">
		<div class="col-md-6 divheadings">CASH AT HAND	BALANCES B/F ON 01-JAN-<?php echo $finyr;?></div><div class="col-md-6 divheadings">CASH AT BANK BALANCES B/F ON	01-JAN-<?php echo $finyr;?></div>
	</DIV><div class="form-row"><div class="col-md-6" style="border:1px solid #999;border-radius:10"><div class="form-row"><div class="col-md-1 divsubheading">#</div><div class="col-md-6 divsubheading">Votehead Account
	</div><div class="col-md-3 divsubheading">Balance</div><div class="col-md-2 divsubheading">Action</div></div>
<?php
	mysqli_multi_query($conn,"SELECT a.sno,concat(b.abbr,' A/C NO. ',a.accno,' (',v.abbr,')') as ac, ab.bankbalbf FROM acc_acbalbf ab Inner Join acc_accounts a ON (ab.acsno=a.sno) Inner Join acc_banks b ON (a.bankno=b.sno)
	Inner Join acc_voteacs v ON (a.accacc=v.acno) WHERE ab.finyr like '$finyr' and v.markdel=0 order by b.abbr,a.sno ASC; SELECT a.acc,v.descr,a.cashbalbf FROM acc_votebalbf a Inner Join acc_voteacs v ON (a.acc=v.acno)
	WHERE a.finyr like '$finyr' and v.markdel=0 ORDER BY a.acc ASC; SELECT concat(v.abbr,' - ',k.abbr,' - A/C NO. ',a.accno) as bank,if(isnull(b.bal),0,b.bal)	as amt FROM acc_accounts a Inner Join acc_banks k ON
	(a.bankno=k.sno) Left Join (SELECT acsno,sum(if(bank_type=0,amt,0)-if(bank_type=1,amt,0)) as bal FROM `acc_banking` Group By markdel,acsno HAVING markdel=0)b ON	(a.sno=b.acsno) Inner Join acc_voteacs v On
	(a.accacc=v.acno)	WHERE a.markdel=0 Order By a.sno; SELECT v.descr,(a.cashbalbf+if(isnull(b.amt),0,b.amt)) as amt FROM acc_votebalbf a	Inner Join acc_voteacs v ON (a.acc=v.acno) Left Join (SELECT acc,
	(sum(if(cftype=0,amt,0))-sum(if(cftype=1,amt,0))) as amt FROM `acc_cashflow` GROUP BY acc,markdel HAVING markdel=0)b	USING (acc) GROUP BY a.acc,v.descr,a.cashbalbf,v.markdel HAVING v.markdel=0 ORDER BY a.acc ASC;");
	$i=$ttl=$ttlc=$cttl=$bttl=0;	$optbankbf=$optcash=$optbank='';
 	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){$c=0; while (list($acno,$acname,$bal)=mysqli_fetch_row($rs)){
		 	 	$optbankbf.="<div class=\"form-row\"><div class=\"col-md-1\">".($c+1)."<input name=\"txtACSNo_$c\" id=\"txtACSNo_$c\" type=\"hidden\" value=\"$acno\"></div><div class=\"col-md-6\"
				id=\"divACName_$c\">$acname</div><div class=\"col-md-3\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtBal_$c\" id=\"txtBal_$c\" readonly
				value=\"".number_format(floatval($bal),2)."\"></div><div class=\"col-md-2\"	style=\"text-align:center;\">".($acedit==1?"<a href=\"#\" onclick=\"editBankBal($c)\" title=\"Edit\"
				class=\"anchorclr\">&#x270d;</a>":"")."</div></div>"; $ttl+=floatval($bal); $c++;}
			}elseif($i==1){$c=0; while (list($acno,$acname,$bal)=mysqli_fetch_row($rs)){
		 	 	print "<div class=\"form-row\"><div class=\"col-md-1\">".($c+1)."<input name=\"txtACSNo1_$c\" id=\"txtACSNo1_$c\" type=\"hidden\" value=\"$acno\"></div><div
				class=\"col-md-6\"	id=\"divACName1_$c\">$acname</div><div class=\"col-md-3\"><input type=\"text\" class=\"modalinput numbersinput\" maxlength=\"13\" name=\"txtBal1_$c\"
				id=\"txtBal1_$c\" readonly value=\"".number_format(floatval($bal),2)."\"></div><div class=\"col-md-2\" style=\"text-align:center;\">".($acedit==1?"<a href=\"#\"
				onclick=\"editACBal($c)\"	title=\"Edit\"	class=\"anchorclr\">&#x270d;</a>":"")."</div></div>";	 $ttlc+=floatval($bal); $c++;}
			}elseif ($i==2){$c=1; while($d=mysqli_fetch_row($rs)){$optbank.="<div class=\"form-row rline\"><div class=\"col-md-1\">$c</div><div class=\"col-md-7\">$d[0]</div><div
				class=\"col-md-4 aright\">".number_format(floatval($d[1]),2)."</div></DIV>"; $bttl+=floatval($d[1]); $c++;}
			}else{$c=1; while($d=mysqli_fetch_row($rs)){$optcash.="<div class=\"form-row rline\"><div class=\"col-md-1\">$c</div><div class=\"col-md-7\">$d[0]</div><div class=\"col-md-4
				aright\">".number_format(floatval($d[1]),2)."</div></DIV>"; $cttl+=floatval($d[1]); $c++;}
			}mysqli_free_result($rs);
		} $i++;
	}while(mysqli_next_result($conn));
?><div class="form-row" style="float:bottom"><div class="col-md-7 aright stitle">TOTAL CASH AT HAND B/F</div><div class="col-md-3 aright stitle"><?php	echo number_format($ttlc,2);?></div><div class="col-md-2 stitle"></div></div>
</div><div class="col-md-6" style="border:1px solid #999;border-radius:10">
	<div class="form-row"><div class="col-md-1 divsubheading">#</div><div class="col-md-6 divsubheading">Bank Account</div><div class="col-md-3 divsubheading">Balance</div><div class="col-md-2 divsubheading">Action</div>
</div><?php echo $optbankbf;?><div class="form-row"><div class="col-md-7 aright stitle">TOTAL CASH AT BANK B/F</div><div class="col-md-3 aright stitle"><?php	echo number_format($ttl,2);?></div>
	<div class="col-md-2 stitle"></div></div></div>
</div></form><br><hr>
<div class="form-row"><div class="col-md-12 title">CASH BALANCES AS ON <?php echo strtoupper(date("D d M, Y")." AT ".date("H:i:s")); ?></DIV></DIV>
<div class="form-row"><div class="col-md-6 maindiv"><!-- Cash at Hand Balance -->
	<div class="form-row"><div class="col-md-12 stitle">CASH AT HAND</div></div>
	<div class="form-row rline"><div class="col-md-1 rhead">#</div><div class="col-md-7 rhead">VOTEHEAD ACCOUNT</div><div class="col-md-4 aright rhead">BALANCE</div></DIV>
	<?php echo $optcash;?><div class="form-row"><div class="col-md-8 aright stitle">TOTAL CASH AT HAND</div><div class="col-md-4 aright stitle"><?php	echo number_format($cttl,2);?>
	</div></div>
</div><div class="col-md-6 maindiv"><!-- Cash at Bank Balance -->
	<div class="form-row"><div class="col-md-12 stitle">CASH AT BANK</div></div>
	<div class="form-row rline"><div class="col-md-1 rhead">#</div><div class="col-md-7 rhead">BANK ACCOUNT</div><div class="col-md-4 aright rhead">BALANCE</div></DIV>
	<?php echo $optbank;?><div class="form-row"><div class="col-md-8 aright stitle">TOTAL CASH AT BANK</div><div class="col-md-4 aright stitle"><?php	echo number_format($bttl,2);?>
	</div></div>
</div></div><hr>
<div class="form-row"><div class="col-md-12" style="text-align:right;"><button type="button" name="btnClose" onclick="window.open('withdrawborrow.php','_self')"
class="btn btn-info btn-md">Close</button></div></div>
</div>
<div id="divBankBalEdit" class="modal">
	<form action="accbalbf.php" Method="Post" name="frmBankBalEdit" onsubmit="return validateFormOnSubmit(this)"><input type="hidden" name='txtInfo1' id='txtInfo1' value="">
	<div class="imgcontainer"><span onclick="document.getElementById('divBankBalEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span>
	<h4 style="color:#fff;text-decoration:underline overline double #fff;word-spacing:5px;letter-spacing:3px;">BANK BALANCE B/F EDITOR</h4></div>
	<div class="container divmodalmain divlrborder">
		<div class="form-row"><div class="col-md-12 divheadings" id="divbankacname1">KCB</div></div>
		<div class="form-row"><div	class="col-md-6"><label for="txtCurrBal1">Current A/C Balance</label><input type="text" class="modalinput numbersinput modalinputdisabled" maxlength="13"
			name="txtCurrBal1" id="txtCurrBal1" value="0.00" readonly></div>
			<div	class="col-md-6"><label for="txtNewBal1">New A/C Balance</label><input type="text" class="modalinput numbersinput" maxlength="13" name="txtNewBal1" id="txtNewBal1"
				value="0.00" onkeyup="checkNumber(this)" onblur="fmtNumber(this)"></div>
		</div><hr><div class="form-row">
			<div class="col-md-5"><button type="submit" name="btnSave1" class="btn btn-primary btn-md btn-block">Save Bal Details</button></div><div class="col-md-4"></div>
			<div class="col-md-3" style="text-align:right;"><button type="button" class="btn btn-info btn-md" onclick="document.getElementById('divBankBalEdit').style.display='none'"
			name="cmdclose">Cancel/Close</button></div>
		</div>
	</div></form>
</div><div id="divCashBalEdit" class="container modal">
	<form action="accbalbf.php" Method="Post" name="frmAccBalEdit" onsubmit="return validateFormOnSubmit2(this)"><input type="hidden" name='txtInfo2' id='txtInfo2' value="">
	<div class="imgcontainer"><span onclick="document.getElementById('divCashBalEdit').style.display='none'" class="close" title="Close Modal" style="color:#fff;">&times;</span>
	<h4 style="color:#fff;text-decoration:underline overline double #fff;word-spacing:5px;letter-spacing:3px;">BANK BALANCE B/F EDITOR</h4></div>
	<div class="container divmodalmain divlrborder">
		<div class="form-row"><div class="col-md-12 divheadings" id="divacname2">SCH FUND</div></div>
		<div class="form-row"><div	class="col-md-6"><label for="txtCurrBal2">Current Votehead A/C Balance</label><input type="text" class="modalinput numbersinput modalinputdisabled"
			maxlength="13" name="txtCurrBal2" id="txtCurrBal2" value="0.00" readonly></div>
			<div	class="col-md-6"><label for="txtNewBal2">New Votehead A/C Balance</label><input type="text" class="modalinput numbersinput" maxlength="13" name="txtNewBal2" id="txtNewBal2"
				value="0.00" onkeyup="checkNumber(this)" onblur="fmtNumber(this)"></div>
		</div><hr><div class="form-row">
			<div class="col-md-5"><button type="submit" name="btnSave2" class="btn btn-primary btn-md btn-block">Save Bal Details</button></div><div class="col-md-4"></div>
			<div class="col-md-3" style="text-align:right;"><button type="button" class="btn btn-info btn-md" onclick="document.getElementById('divCashBalEdit').style.display='none'"
			name="cmdclose2">Cancel/Close</button></div>
		</div>
	</div></form>
</div>
<script src="tpl/js/accbalbf.js" type="text/javascript"></script>
<?php mysqli_close($conn); footer();?>
