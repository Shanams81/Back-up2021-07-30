<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else	include_once('../conn/pri_sch_connect.inc');
	include_once('tpl/printing.tpl');
	$recno=$_REQUEST['recno']; $recno=preg_split("/\-/",$recno); //[0] main a/c reciept no.,[1]-0 misc a/c receipt no, [2] 0- both 1-main 2-misc ,[3] Year
?>
<html>
<head>
	<link rel="shortcut icon" href="img/phone.ico"/>
	<link href="tpl/accprint.css" rel="stylesheet" type="text/css" media="print"/>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Student Manager</title>
	<script type="text/javascript">
        function PrintWindow()
        {                      
           CheckWindowState();
		   window.print();    
        }
        function CheckWindowState()
        {            
            if(document.readyState=="complete")
            { //window.close();  
			}else {            
                setTimeout("CheckWindowState()", 5000);
            }
        }       
        PrintWindow();
		function clickedButton() {
         	window.location = 'archfee.php';
        }
    </script>
</head>
<body onclick="clickedButton()">
<?php
	$rsDet=mysqli_query($conn,"SELECT scnm,scadd FROM ss");
	if (mysqli_num_rows($rsDet)>0) list($scnm,$scadd)=mysqli_fetch_row($rsDet);
	mysqli_free_result($rsDet);
	print "<div id=\"print_content\"><table cellpadding=\"2\" cellspacing=\"0\" align=\"left\" style=\"border:1px dotted green;border-collapse:collapse;color:#000000;font-size:12px;\">
	<tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" width=\"100%\"><tr><td rowspan=\"3\"><img src=\"img/logo.png\" width=\"70\" height=\"50\" vspace=\"1\" hspace=\"1\">
	</td><td style=\"font-weight:bold;font-size:14px;letter-spacing:2px;word-spacing:3px;\" colspan=\"2\">$scnm</td></tr><tr><td style=\"font-weight:bold;font-size:8px;\" 
	colspan=\"2\">$scadd</td></tr><tr><td style=\"font-weight:bold;font-size:10px;letter-spacing:1px;word-spacing:2px;\" colspan=\"2\">OFFICIAL RECEIPT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;Printed On&nbsp;".date("D d-M-Y")."</td></tr><tr><td colspan=\"3\"><hr></td></tr>";
	if ($recno[2]==0){//both main and misc account fees
		 //reciept details
	 	$rsRec=mysqli_query($conn,"SELECT f.recieptno,f.admno,concat(s.surname,' ',s.onames) as sname,concat(cn.clsname,' ',c.stream) as frm,f.pytdate,f.paidby,f.paytform,f.cmono,f.amt,
		 f.bankcharges,f.tuition,f.boarding,f.activity,f.ltt,f.rmi,f.ewc,f.exam,f.admincosts,f.lib,(f.medical+f.spemed) as med,f.adm,f.pemolu,f.arrears,f.transport,f.refunds,f.prep,
		 f.olevy,f.addedby,month(f.pytdate) as mon FROM stud s Inner Join class c USING (admno) Inner Join classnames cn Using (clsno) Inner Join arch_feerec f On (s.admno=f.admno) WHERE 
		 f.recieptno LIKE '$recno[0]' and f.yr LIKE '$recno[3]' and c.curr_year LIKE '$recno[3]'");
	 	list($reno,$admno,$stnames,$stcls,$date,$paidby,$pytfrm,$cheno,$amt,$bc,$tui,$boa,$act,$ltt,$rmi,$ewc,$exa,$admco,$lib,$med,$adm,$pem,$arr,$trans,$ref,$prep,$ole,$un,$mon)=
		mysqli_fetch_row($rsRec); 
		mysqli_free_result($rsRec); $cheno=strlen($cheno)==0?"__________":$cheno;  if ($mon<5) $term="One"; elseif ($mon<9) $term="Two"; else $term="Three";
		//misc fee
		$rsMisc=mysqli_query($conn,"SELECT bankcharges,(amt+bankcharges) as ttl,qa,idcard,remedial,uni,grad,acatrip,arrears,olevy FROM arch_miscfeepyts WHERE recipetno LIKE '$recno[1]' 
		and yr LIKE '$recno[3]'"); list($misbc,$misamt,$misqa,$misid,$misht,$misuni,$misgrad,$mistrip,$misarr,$misole)=mysqli_fetch_row($rsMisc);
		//Display data
		print "<tr><td><b>Receipt No.</b></td><td colspan=\"2\">$reno &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Received On ".date("D d-M-Y",
		strtotime($date))."</td></tr>";
		print "<tr><td>Received From</td><td colspan=\"2\" align=\"left\" style=\"font-weight:normal;font-size:12px; letter-spacing:4px;word-spacing:6px;\" bgcolor=\"#eeeeee\">$stnames
		</td></tr><tr><td>Admission No.</td><td colspan=\"2\">$admno &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Class:</b> ".strtoupper($stcls)."&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;Received In $pytfrm</td></tr><tr><td>Trans/Cheque No.</td><td colspan=\"2\">$cheno&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		Fees Paid By $paidby &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Term&nbsp;&nbsp;$term</td></tr><tr><td colspan=\"3\"></td></tr><tr><td colspan=\"3\">
		<Img src=\"img/duplicate.png\" width=\"400\" height=\"300\" style=\"position:fixed;opacity:0.3;pointer-events:none;\">";
		//votehead allocation
		print "<table border=\"1\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" style=\"font-size:9px;\"><tr style=\"letter-spacing:1px;word-spacing:2px;\"><th colspan=\"2\">
		MAIN ACCOUNT SCHOOL FEES</th><th rowspan=\"20\" bgcolor=\"#555555\">-</th><th colspan=\"2\">MISCELLANEOUS ACCOUNT FEES</th></tr><tr><th>Votehead</th><th>Amount Paid</th><th>
		Votehead</th><th>Amount Paid</th></tr>";
		print "<tr><td>Tuition</td><td align=\"right\">".number_format($tui,2)."</td><td>ID Card</td><td align=\"right\">".number_format($misid,2)."</td></tr>";
		print "<tr><td>Boarding &amp; Meals</td><td align=\"right\">".number_format($boa,2)."</td><td>Quality Assurance</td><td align=\"right\">".number_format($misqa,2)."</td></tr>";
		print "<tr><td>Activity</td><td align=\"right\">".number_format($act,2)."</td><td>Holiday Tuition</td><td align=\"right\">".number_format($misht,2)."</td></tr>";
		print "<tr><td>L . T &amp; T</td><td align=\"right\">".number_format($ltt,2)."</td><td>Graduation Fee</td><td align=\"right\">".number_format($misgrad,2)."</td></tr>";
		print "<tr><td>R . M . I</td><td align=\"right\">".number_format($rmi,2)."</td><td>Academic Trip</td><td align=\"right\">".number_format($mistrip,2)."</td></tr>";
		print "<tr><td>E . W . C</td><td align=\"right\">".number_format($ewc,2)."</td><td>Uniform</td><td align=\"right\">".number_format($misarr,2)."</td></tr>";
		print "<tr><td>Examination/ CATs</td><td align=\"right\">".number_format($exa,2)."</td><td>Misc. Arrears</td><td align=\"right\">".number_format($misuni,2)."</td></tr>";
		print "<tr><td>Administrative Costs</td><td align=\"right\">".number_format($admco,2)."</td><td>Bank Charges</td><td align=\"right\">".number_format($misbc,2)."</td></tr>";
		print "<tr><td>Library Fee</td><td align=\"right\">".number_format($lib,2)."</td><td>Other Levies</td><td align=\"right\">".number_format($misole,2)."</td></tr>";
		print "<tr><td>Medical</td><td align=\"right\">".number_format($med,2)."</td><td rowspan=\"8\"></td><td  rowspan=\"8\"></td></tr>";
		print "<tr><td>Transport</td><td align=\"right\">".number_format($trans,2)."</td></tr>";
		print "<tr><td>Personal Emolument</td><td align=\"right\">".number_format($pem,2)."</td></tr>";
		print "<tr><td>Fee Arrears</td><td align=\"right\">".number_format($arr,2)."</td></tr>";
		print "<tr><td>Refunds</td><td align=\"right\">".number_format($ref,2)."</td></tr>";
		print "<tr><td>Prepayments</td><td align=\"right\">".number_format($prep,2)."</td></tr>";
		print "<tr><td>Bank Charges</td><td align=\"right\">".number_format($bc,2)."</td></tr>";
		print "<tr><td>Other Levies</td><td align=\"right\">".number_format($ole,2)."</td></tr>";
		print "<tr><td><b>Total Amount</b></td><td align=\"right\"><b>".number_format($amt,2)."</b></td><td><b>Total Amount</b></td><td align=\"right\"><b>".number_format($misamt,2)."</b>
		</td></tr>";	
		$FEES=$misamt+$amt;
	}elseif ($recno[2]==1){//main Account receipt only
		 //reciept details
	 	$rsRec=mysqli_query($conn,"SELECT f.recieptno,f.admno,concat(s.surname,' ',s.onames) as sname,concat(cn.clsname,' ',c.stream) as frm,f.pytdate,f.paidby,f.paytform,f.cmono,f.amt,
		 f.bankcharges,f.tuition,f.boarding,f.activity,f.ltt,f.rmi,f.ewc,f.exam,f.admincosts,f.lib,(f.medical+f.spemed) as med,f.adm,f.pemolu,f.arrears,f.transport,f.refunds,f.prep,
		 f.olevy,f.addedby,month(f.pytdate) as mon FROM stud s Inner Join class c USING (admno) Inner Join classnames cn Using (clsno) Inner Join arch_feerec f On (s.admno=f.admno) WHERE 
		 f.recieptno LIKE '$recno[0]' and f.yr LIKE '$recno[3]' and c.curr_year LIKE '$recno[3]'");
	 	list($reno,$admno,$stnames,$stcls,$date,$paidby,$pytfrm,$cheno,$amt,$bc,$tui,$boa,$act,$ltt,$rmi,$ewc,$exa,$admco,$lib,$med,$adm,$pem,$arr,$trans,$ref,$prep,$ole,$un,$mon)=
		mysqli_fetch_row($rsRec); 
		mysqli_free_result($rsRec); $cheno=strlen($cheno)==0?"____":$cheno; if ($mon<5) $term="One"; elseif ($mon<9) $term="Two"; else $term="Three";
		//Display data
		print "<tr><td><b>Receipt No.</b></td><td colspan=\"2\">$reno &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Received On ".date("D d-M-Y",
		strtotime($date))."</td></tr>";
		print "<tr><td>Received From</td><td colspan=\"2\" align=\"left\" style=\"font-weight:normal;font-size:12px; letter-spacing:4px;word-spacing:6px;\" bgcolor=\"#eeeeee\">$stnames
		</td></tr><tr><td>Admission No.</td><td colspan=\"2\">$admno &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Class:</b> ".strtoupper($stcls)."&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;Received In $pytfrm</td></tr><tr><td>Trans/Cheque No.</td><td colspan=\"2\">$cheno&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		Fees Paid By $paidby &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Term&nbsp;&nbsp;$term</td></tr><tr><td colspan=\"3\"></td></tr><tr><td colspan=\"3\">
		<Img ".($recno[3]==0?"src=\"img/washout.png\" ":($recno[3]==1?"src=\"img/duplicate.png\" ":"src=\"img/deleted.png\""))." width=\"400\" height=\"300\" style=\"position:fixed;
		opacity:0.3;pointer-events:none;\">";
		//votehead allocation
		print "<table border=\"1\" cellspacing=\"0\" cellpadding=\"1\" width=\"100%\" style=\"font-size:9px;\"><tr style=\"letter-spacing:1px;word-spacing:2px;\"><th colspan=\"2\">MAIN 
		ACCOUNT SCHOOL FEES</th><th rowspan=\"20\" bgcolor=\"#555555\">--</th><th colspan=\"2\">MISCELLANEOUS ACCOUNT FEES</th></tr><tr><th>Votehead</th><th>Amount Paid</th><th>Votehead
		</th><th>Amount Paid</th></tr>";
		print "<tr><td>Tuition</td><td align=\"right\">".number_format($tui,2)."</td><td>ID Card</td><td></td></tr>";
		print "<tr><td>Boarding &amp; Meals</td><td align=\"right\">".number_format($boa,2)."</td><td>Quality Assurance</td><td></td></tr>";
		print "<tr><td>Activity</td><td align=\"right\">".number_format($act,2)."</td><td>Holiday Tuition</td><td></td></tr>";
		print "<tr><td>L . T &amp; T</td><td align=\"right\">".number_format($ltt,2)."</td><td>Graduatio Fee</td><td></td></tr>";
		print "<tr><td>R . M . I</td><td align=\"right\">".number_format($rmi,2)."</td><td>Academic Trip</td><td></td></tr>";
		print "<tr><td>E . W . C</td><td align=\"right\">".number_format($ewc,2)."</td><td>Uniform</td><td></td></tr>";
		print "<tr><td>Examination/ CATs</td><td align=\"right\">".number_format($exa,2)."</td><td>Misc. Arrears</td><td></td></tr>";
		print "<tr><td>Administrative Costs</td><td align=\"right\">".number_format($admco,2)."</td><td>Bank Charges</td><td></td></tr>";
		print "<tr><td>Library Fee</td><td align=\"right\">".number_format($lib,2)."</td><td>Other Levies</td><td></td></tr>";
		print "<tr><td>Medical</td><td align=\"right\">".number_format($med,2)."</td><td rowspan=\"8\"></td><td  rowspan=\"8\"></td></tr>";
		print "<tr><td>Transport</td><td align=\"right\">".number_format($trans,2)."</td></tr>";
		print "<tr><td>Personal Emolument</td><td align=\"right\">".number_format($pem,2)."</td></tr>";
		print "<tr><td>Fee Arrears</td><td align=\"right\">".number_format($arr,2)."</td></tr>";
		print "<tr><td>Refunds</td><td align=\"right\">".number_format($ref,2)."</td></tr>";
		print "<tr><td>Prepayments</td><td align=\"right\">".number_format($prep,2)."</td></tr>";
		print "<tr><td>Bank Charges</td><td align=\"right\">".number_format($bc,2)."</td></tr>";
		print "<tr><td>Other Levies</td><td align=\"right\">".number_format($ole,2)."</td></tr>";
		print "<tr><td><b>Total Amount</b></td><td align=\"right\"><b>".number_format($amt,2)."</b></td><td><b>Total Amount</b></td><td></td></tr>";
		$FEES=$amt;
	}else{//misc account reciept only
		//reciept details
	 	$rsMisc=mysqli_query($conn,"SELECT m.recipetno,m.payeesno,concat(s.surname,' ',s.onames) as sname,concat(cn.clsname,' ',c.stream) as frm,m.pytdate,m.paidby,m.pytfrm,m.cheno,(m.amt+
		m.bankcharges) as tamt,m.bankcharges,m.qa,m.idcard,m.remedial,m.uni,m.grad,m.acatrip,m.arrears,m.olevy,month(m.pytdate) as mon,m.addedby FROM stud s Inner Join class c USING 
		(admno) Inner Join classnames cn Using (clsno) Inner Join arch_miscfeepyts m WHERE m.recipetno LIKE '$recno[1]' and m.yr LIKE '$recno[3]' and c.curr_year LIKE '$recno[3]'");
		list($reno,$admno,$stnames,$stcls,$date,$paidby,$pytfrm,$cheno,$misamt,$misbc,$misqa,$misid,$misht,$misuni,$misgrad,$mistrip,$misarr,$misole,$mon,$un)=mysqli_fetch_row($rsMisc); 	
		mysqli_free_result($rsMisc); 	$cheno=strlen($cheno)==0?"____":$cheno; 	if ($mon<5) $term="One"; elseif ($mon<9) $term="Two"; else $term="Three";
		//Display data
		print "<tr><td><b>Receipt No.</b></td><td colspan=\"2\">$reno &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Received On ".date("D d-M-Y",
		strtotime($date))."</td></tr>";
		print "<tr><td>Received From</td><td colspan=\"2\" align=\"left\" style=\"font-weight:normal;font-size:12px; letter-spacing:4px;word-spacing:6px;\" bgcolor=\"#eeeeee\">$stnames
		</td></tr><tr><td>Admission No.</td><td colspan=\"2\">$admno &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Class:</b> ".strtoupper($stcls)."&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;Received In $pytfrm</td></tr><tr><td>Trans/Cheque No.</td><td colspan=\"2\">$cheno&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		Fees Paid By $paidby &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Term&nbsp;&nbsp;$term</td></tr><tr><td colspan=\"3\"></td></tr><tr><td colspan=\"3\">
		<Img ".($recno[3]==0?"src=\"img/washout.png\" ":($recno[3]==1?"src=\"img/duplicate.png\" ":"src=\"img/deleted.png\""))." width=\"400\" height=\"300\" style=\"position:fixed;
		opacity:0.3;pointer-events:none;\">";
		//votehead allocation
		print "<table border=\"1\" cellspacing=\"0\" cellpadding=\"1\" width=\"100%\" style=\"font-size:9px;\"><tr style=\"letter-spacing:1px;word-spacing:2px;\"><th colspan=\"2\">MAIN 
		ACCOUNT SCHOOL FEES</th><th rowspan=\"20\" bgcolor=\"#555555\">--</th><th colspan=\"2\">MISCELLANEOUS ACCOUNT FEES</th></tr><tr><th>Votehead</th><th>Amount Paid</th><th>Votehead
		</th><th>Amount Paid</th></tr>";
		print "<tr><td>Tuition</td><td></td><td>ID Card</td><td align=\"right\">".number_format($misid,2)."</td></tr>";
		print "<tr><td>Boarding &amp; Meals</td><td></td><td>Quality Assurance</td><td align=\"right\">".number_format($misqa,2)."</td></tr>";
		print "<tr><td>Activity</td><td></td><td>Holiday Tuition</td><td align=\"right\">".number_format($misht,2)."</td></tr>";
		print "<tr><td>L . T &amp; T</td><td></td><td>Graduation Fee</td><td align=\"right\">".number_format($misgrad,2)."</td></tr>";
		print "<tr><td>R . M . I</td><td></td><td>Academic Trip</td><td align=\"right\">".number_format($mistrip,2)."</td></tr>";
		print "<tr><td>E . W . C</td><td></td><td>Uniform</td><td align=\"right\">".number_format($misuni,2)."</td></tr>";
		print "<tr><td>Examination/ CATs</td><td></td><td>Misc. Arrears</td><td align=\"right\">".number_format($misarr,2)."</td></tr>";
		print "<tr><td>Administrative Costs</td><td></td><td>Bank Charges</td><td align=\"right\">".number_format($misbc,2)."</td></tr>";
		print "<tr><td>Library Fee</td><td></td><td>Other Levies</td><td align=\"right\">".number_format($misole,2)."</td></tr>";
		print "<tr><td>Medical</td><td></td><td rowspan=\"8\"></td><td  rowspan=\"8\"></td></tr>";
		print "<tr><td>Transport</td><td></td></tr>";
		print "<tr><td>Personal Emolument</td><td></td></tr>";
		print "<tr><td>Fee Arrears</td><td></td></tr>";
		print "<tr><td>Refunds</td><td></td></tr>";
		print "<tr><td>Prepayments</td><td></td></tr>";
		print "<tr><td>Bank Charges</td><td></td></tr>";
		print "<tr><td>Other Levies</td><td></td></tr>";$FEES=$misamt+$misbc;
		print "<tr><td><b>Total Amount</b></td><td></td><td><b>Total Amount</b></td><td align=\"right\"><b>".number_format($FEES,2)."</b></td></tr>";	
	}
	print "<tr><td colspan=\"5\" style=\"background:#eeeeee;word-spacing:2.5px;letter-spacing:1.5px;font-weight:bold;text-align:center;\">Total Fees Amount Received (Kshs.)</b>&nbsp;
	&nbsp;&nbsp;<b>".number_format($FEES,2)."</b></td></tr></table>";
	print "<tr><td colspan=\"3\"><hr></td></tr><tr><td colspan=\"3\"><b>Amount In Words:</b><u>".NumToWord(preg_replace("/\,/","",number_format($FEES,2)))."</u></td></tr>";
	print "<tr><td colspan=\"3\"><hr><br></td></tr><tr><td colspan=\"3\">Received &amp; Served By <u><b>$un</b></u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;Sign________________</td></tr><tr><td colspan=\"3\"><hr></td></tr><tr><td colspan=\"3\" style=\"color:#aaaaaa;font-size:7px;\"><center>The receipt is invalid without official 
	stamp. Fees once paid is neither refunded nor transferable. <br>Designed By: Shanams Digital Solutions +254736732168</center></td></tr></table></td></tr></table></div>";
	mysqli_close($conn);
?>
</body>
</html>