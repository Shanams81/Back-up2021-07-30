<?php
    include_once('shanam.php');
    $det=isset($_REQUEST['action'])?$_REQUEST['action']:"2-0-0"; $det=preg_split('/\-/',$det); $i=0;
    mysqli_multi_query($conn,"SELECT deptadd,deptdel FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'; SELECT concat(s.surname,' ',s.onames,' - (',s.designation,')') as nam "
    . "FROM stf s WHERE s.idno LIKE '$det[2]'; SELECT deptno,deptname FROM depts WHERE markdel=0 ORDER BY deptname Asc;"); 	$add=$del=0; $opt='';
    do{
        if($rs=mysqli_store_result($conn)){
            if($i==0){if (mysqli_num_rows($rs)==1) list($add,$del)=mysqli_fetch_row($rs);}
            elseif($i==1){if (mysqli_num_rows($rs)==1) list($nam)=mysqli_fetch_row($rs);}
            else{if (mysqli_num_rows($rs)>0) while ($dat=mysqli_fetch_row($rs)) $opt.="<option ".($det[1]==$dat[0]?"selected":"")." value=\"$dat[0]\">$dat[1]</option>";}
            mysqli_free_result($rs);   
        }$i++;
    }while(mysqli_next_result($conn));
    if ($det[0]==1){
        $rsDept=mysqli_query($conn,"SELECT deptno,title,section FROM stf_depts WHERE (stfno LIKE '$det[2]' AND deptno LIKE '$det[1]')");
        $deptdata=mysqli_fetch_row($rsDept);		mysqli_free_result($rsDept);
    }else{$deptdata=[0,'Member',''];}
    if (isset($_POST['CmdSave'])){
        $data=isset($_POST['txtInfo'])?sanitize($_POST['txtInfo']):'2-0-0';     $data=preg_split('/\-/',$data);
        $idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):'00';        $deptno=isset($_POST['cboDept'])?sanitize($_POST['cboDept']):0;	
        $title=isset($_POST['cboTitle'])?strip_tags($_POST['cboTitle']):'';	$section=isset($_POST['txtSection'])?sanitize($_POST['txtSection']):'';	
        $section=strlen($section)==0?Null:$section;
        if(strlen($idno)>3 || $deptno==0 || strlen($title)>2 || strlen($section)>3){
            if ($data[0]==0){ 
                    mysqli_query($conn,"INSERT INTO stf_depts (stfno,deptno,title,section) VALUES('$idno','$deptno','$title','$section')") or die(mysqli_error($conn).
                     " Click <a href=\"staff_depts.php?act=0-0\">here</a> to go back");
                    $act=1;
            }elseif ($data[0]==1){
                    mysqli_query($conn,"UPDATE stf_depts SET deptno='$deptno',title='$title',section='$section' WHERE (stfno LIKE '$data[2]' AND deptno LIKE '$data[1]')") 
                     or die(mysqli_error($conn)." Click <a href=\"staff_depts.php?act=0-0\">here</a> to go back");
                    $act=1;
            } $norec=mysqli_affected_rows($conn); 	$act=isset($act)?$act:0;
            header("location:staff_depts.php?act=$act-$norec");
        }
    }elseif(isset($_POST['CmdDelete'])){
        $data=isset($_POST['txtIdNo'])?sanitize($_POST['txtIdNo']):'2-0-0'; 	$data=preg_split('/\-/',$data);
        mysqli_query($conn,"DELETE FROM stf_depts WHERE (stfno LIKE '$data[2]' AND deptno LIKE '$data[1]')") or die(mysqli_error($conn)." Click <a 
        href=\"staff_depts.php?act=0-0\">here</a> to go back");
        $act=2;  $norec=mysqli_affected_rows($conn); 	$act=isset($act)?$act:0;
        header("location:staff_depts.php?act=$act-$norec");
    }headings('',0,0,1);
?><br><br><br>
<form method="post" action="dept_staffing.php" onsubmit="return checkData(this)"><div class="container" style="margin:auto;border:0px;border-radius:10px;padding:5px;background-color:#eee;
max-width:600px;">
<div class="form-row"><input type="hidden" name="txtInfo" value="<?php echo "$det[0]-$det[1]-$det[2]";?>">
    <div class="col-md-12 mb-3" style="font-size:12pt;font-weight:bold;background-color:#000;color:#fff;letter-spacing:2px;word-spacing:3px;text-align:center;"><?php echo "$nam'S <br><b ".
    ($det[0]==1?"style=\"color:#f00;\">EDIT":"style=\"color:#00f;\">NEW")." DEPARTMENT.</b>";?>
    </div>
</div><div class="form-row">
    <div class="col-md-5 mb-3"><label for="txtIDNo">Staff Member ID No. *</label><input class="form-control" type="text" name="txtIDNo" id="txtIDNo" value="<?php echo $det[2];?>" readonly></div>
    <div class="col-md-7 mb-3"><label for="cboDept">Member of *</label><select class="form-control" name="cboDept" id="cboDept" size="1" required onchange="confirmDept(this)"><option 
    <?php echo ($det[1]==0?"selected":"");?> value="0">All</option><?php echo $opt;?></select></div>
</div>
<div class="form-row">
    <div class="col-md-5 mb-3"><label for="cboTitle">Title in the Department *</label><SELECT name="cboTitle" id="cboTitle" size="1" class="form-control" required>
    <option <?php echo (strcasecmp("hod",$deptdata[1])==0?"selected":"");?> value="HOD">HOD</option><option <?php echo (strcasecmp("hos",$deptdata[1])==0?"selected":"");?> value="HOS">HOS
    </option><option <?php echo (strcasecmp("supervisor",$deptdata[1])==0?"selected":"");?> value="SUPERVISOR">Supervisor</option><option <?php echo (strcasecmp("member",$deptdata[1])==0?
    "selected":"");?> value="MEMBER">Member</option></Select></div>
    <div class="col-md-7 mb-3"><label for="cboTitle">Section/Sub Department *</label><Input type="text" name="txtSection" id="txtSection" class="form-control" maxlength="16" onkeyup="verSec(this)"
    value="<?php echo $deptdata[2];?>" required></div>
</div>
<div class="form-row">
    <div class="col-md-6 mb-3"><button name="CmdSave" type="submit">Save Member Details</button></div>
    <div class="col-md-3 mb-3"> <?php echo (((($det[0]==1) && ($del==1)))?"<button name=\"CmdDelete\" type=\"submit\"><img src=\"../gen_img/del.ico\" height=\"20\" width=\"20\" title=\"Delete "
    . "Department\">Delete</button>":"");?></div>
    <div class="col-md-3 mb-3" style="text-align:right;"><a href="staff_depts.php?act=0-0"><button name="CmdClose" type="button">Close</button></div>
</div></div></form><script type="text/javascript" src="tpl/js/deptstf.js"></script>
<?php
    mysqli_close($conn); footer();
?>
