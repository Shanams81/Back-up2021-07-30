<?php
	include_once('shanam.php');
	$rs=mysqli_query($conn,"SELECT voteview,voteedit,voteadd FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'"); $view=0; $edit=0; $add=0; $act="0-0";
	if (mysqli_num_rows($rs)>0) list($view,$edit,$add)=mysqli_fetch_row($rs);	mysqli_free_result($rs);
	if($view==0) header("location:vague.php");
	class Accounts{
		private $sno,$abb,$acc,$acname,$vno,$vname,$hvno,$hvname,$prot;
		public function __construct($s,$ab,$ac,$acn,$vn,$vna,$hv,$hva,$pr){
		 	$this->sno=$s; $this->abb=$ab; $this->acc=$ac; $this->vno=$vn; $this->hvno=$hv; $this->prot=$pr; $this->acname=$acn; $this->vname=$vna; $this->hvname=$hva;
		}public function valSNo(){return $this->sno;}		public function valAbbr(){return $this->abb;}		public function valAcc(){return $this->acc;}
		public function valAcName(){return $this->acname;} 	public function valVName(){return $this->vname;}	public function valHVName(){return $this->hvname;}
		public function valVoNo(){return $this->vno;}		public function valHVoNo(){return $this->hvno;}	public function valProt(){return $this->prot;}
		public function __destruct(){} //release memory
	}
	if (isset($_POST['btnSave'])):
		$sno=isset($_POST['txtOpt'])?sanitize($_POST['txtOpt']):'0-0';			$sno=preg_split('/\-/',$sno);
		$name=isset($_POST['txtAbbr'])?mysqli_real_escape_string($conn,strtoupper(strtoupper(sanitize($_POST['txtAbbr'])))):"";
		$acc=isset($_POST['cboAC'])?strtoupper(sanitize($_POST['cboAC'])):"";	$vot=isset($_POST['cboVote'])?sanitize($_POST['cboVote']):0;
		$hvot=isset($_POST['cboCVote'])?sanitize($_POST['cboCVote']):"";		$prot=isset($_POST['chkProtected'])?sanitize($_POST['chkProtected']):0;
		if (strlen($name)<3 || $acc<1 || $vot==0){
			print "<h4 style=\"color:#f00;text-align:center;letter-spacing:2px;word-spacing:4px;\">You must enter valid votehead details before saving.</h4>";
			$act="1-0";
		}else{
		 	if ($sno[0]==0) $sql="INSERT INTO acc_votesassigned(sno,name,acc,voteno,hvoteno,protected) VALUES (0,".var_export($name,true).",$acc,$vot,".(strlen($hvot)==0?"Null":$hvot).",
			$prot)";
		 	else $sql="UPDATE acc_votesassigned SET name=".var_export($name,true).",acc=$acc,voteno=$vot,hvoteno=".(strlen($hvot)==0?"Null":$hvot).",protected=$prot WHERE sno LIKE '$sno[1]'";
			mysqli_query($conn,$sql) or die(mysqli_error($conn). ". New votehead account detail were not saved. Click <a href=\"specialvotes.php\">here</a> to go try again.");
			$act="1-".mysqli_affected_rows($conn);
		}
	endif;
	$rs=mysqli_query($conn,"SELECT va.sno,va.name,va.acc,a.abbr,va.voteno,v.abbr as vote,va.hvoteno,h.hvote,va.protected FROM acc_votesassigned va Inner Join acc_voteacs a On
	(va.acc=a.acno) Inner Join acc_votes v On (va.voteno=v.sno) Left Join (SELECT va.sno,v.abbr as hvote FROM acc_votesassigned va Inner Join acc_votes v On (va.hvoteno=v.sno))h ON
	(va.sno=h.sno) WHERE va.markdel=0 ORDER BY va.sno ASC");		$nv=0; 	$act=preg_split('/\-/',$act);
	while($d=mysqli_fetch_row($rs)){$nv++; $accounts[]=new Accounts($d[0],$d[1],$d[2],$d[3],$d[4],$d[5],$d[6],$d[7],$d[8]);} mysqli_free_result($rs);
	headings('<link href="tpl/css/inputsettings.css" rel="stylesheet">',$act[0],$act[1],2);
?><div class="container divgen"><div class="form-row"><div class="col-md-12 divheadings">SPECIAL VOTEHEAD DEFINITION INTERFACE</div></div>
<div class="form-row"><div class="col-md-12"><FORM action="specialvotes.php" name="Adding" Method="POST" onsubmit="return validateData(this)">
	<div class="container divlrborder" style="margin:5px auto"><input type="hidden"	name="txtOpt" id="txtOpt" value="0-0">
		<div class="form-row"><div class="col-md-9">
			<div class="form-row"><div class="col-md-12"><label for="txtAbbr">Name of Votehead As Used in the System *</label><Input name="txtAbbr" id="txtAbbr" type="text" value=""
				maxlength=14 class="modalinput"	required placeholder="Abbreviation" maxlength="14" onkeyup="checkInput(this)"></div>
			</div><div class="form-row">
				<div class="col-md-12"><label for="cboAC">Votehead Account Affected *</label><SELECT name="cboAC" id="cboAC" size="1" class="modalinput" required
					onchange="loadVotes(this)"><option selected value=0></option>";
					<?php
						$rs=mysqli_query($conn,"SELECT acno,descr FROM acc_voteacs WHERE markdel=0 and stud_assoc=1"); while($d=mysqli_fetch_row($rs)) print "<option value=$d[0]>$d[1]</option>";
						mysqli_free_result($rs);
					?></select></div>
			</div><div class="form-row">
				<div class="col-md-12"><label for="cboVote">Votehead Where Income is Received *</label><SELECT name="cboVote" id="cboVote" size="1" class="modalinput" required><option
					value="">None</option></SELECT></div>
			</div><div class="form-row">
				<div class="col-md-12"><label for="cboCVote">Cumulative Votehead For Above Votehead </label><SELECT name="cboCVote" id="cboCVote" size="1" class="modalinput"><option
					value="">None</option></SELECT></div>
				</div><div class="form-row">
					<div class="col-md-12"><label for="chkProtected">Type of Votehead</label><input type="checkbox" name="chkProtected" id="chkProtected" value=1>Votehead is Protected
						from Editing</div>
				</div>
			</div><div class="col-md-3">
				<div class="form-row"><div class="col-md-12"><br><br><button type="submit" name="btnSave" id="btnSave" disabled class="btn btn-primary btn-lg btn-block">Save A/C<br>
					Details</button></div>
				</div><div class="form-row">
					<div class="col-md-12"><br><br><button name="cmdCancel" type="reset" class="btn btn-info btn-md btn-block disabled">Cancel</button></div>
				</div><div class="form-row">
					<div class="col-md-12"><br><br><button name="cmdClose" type="button" class="btn btn-info btn-md btn-block disabled" onclick="window.open('settings_manager.php','_self')">
						Close</button></div>
					</div>
			</div>
		</div>
	</div>
</div></div><div class="form-row"><div class="col-md-12">
<table class="table table-sm table-striped table-hover"><thead class="thead-dark"><tr><td colspan="6" style="word-spacing:6px;letter-spacing:4px;font-size:12pt;font-weight:bold;
text-align:center;">LIST OF SPECIAL	VOTEHEADS</td></tr><tr><th align="right">SPECIAL VOTE</th><th>ACCOUNT</th><th>INCOME VOTE</th><th>CUMULATIVE VOTE</th><th>PROTECTED</th><th>
ADMIN ACTION</th></tr></thead><tbody>
<?php
	if (isset($accounts)){
		foreach($accounts as $acc) print "<tr><td class=\"n\">".$acc->valAbbr()."</td><td class=\"n\">".$acc->valAcName()."</td><td class=\"n\">".($acc->valVName())."</td><td class=\"n\">
		".($acc->valHVName())."</td><td class=\"n\" align=\"center\">".($acc->valProt()==1?"&#x2611; Yes":"&#x274c; No")."</td><td align=\"center\" class=\"n\">".(($acc->valProt()==0 &&
		$edit==1)?"<a onclick=\"canEdit(".($acc->valSNo()).",$edit)\" href=\"#\">Edit</a>":"-")."</td></tr>";
	}
?>
</tbody><tfoot class="thead-light"><tr><td colspan="10"><?php echo $nv; ?> Registered Special Votehead(s)</td></tr></tfoot></table>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/specialvotes.js"></script>
<script type="text/javascript">
<?php
	if (isset($accounts)){
	 	$arr=""; $i=0;
		foreach($accounts as $acc){
		 	$arr.=($i==0?"":",")."new Accounts(".($acc->valSNo()).",\"".($acc->valAbbr())."\",".($acc->valAcc()).",".($acc->valVoNo()).",".($acc->valHVoNo()>0?$acc->valHVoNo():0).",".
			($acc->valProt()).")";
			$i++;
		} if (strlen($arr)>0) print "accounts.push($arr);";
	}
	$rs=mysqli_query($conn,"SELECT v.sno,v.descr,v.acc FROM acc_votes v Inner Join acc_voteacs a ON (v.acc=a.acno) WHERE v.markdel=0 and a.stud_assoc=1"); $i=0; $arr='';
	while ($d=mysqli_fetch_row($rs)){$arr.=($i==0?"":",")."new Votes($d[0],\"$d[1]\",$d[2])"; $i++;} mysqli_free_result($rs);
	if (strlen($arr)>0) print "votes.push($arr);";
	mysqli_close($conn);
?>
</script>
</body></html>
