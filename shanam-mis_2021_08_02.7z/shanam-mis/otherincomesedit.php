<!DOCTYPE html>
<?php
    include_once('shanam.php');
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_POST['btnSave'])){
            $token=sanitize($_POST['txtTkn']);	 	$code=isset($_POST['txtCode'])?sanitize($_POST['txtCode']):''; 	$recno=isset($_POST['txtRecNo'])?sanitize($_POST['txtRecNo']):''; 
            $idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):0;   $date=isset($_POST['dtpRecOn'])?sanitize($_POST['dtpRecOn']):date('Y-m-d');
            $name=isset($_POST['txtName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtName']))):null; 	$token=preg_split('/\-/',$token);		
            $telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):null;  $acc=isset($_POST['cboAC'])?sanitize($_POST['cboAC']):0; 
            $address=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):null; 	
            $mode=isset($_POST['cboMode'])?strtoupper(sanitize($_POST['cboMode'])):'DIRECT BANKING'; $vote=isset($_POST['cboVote'])?sanitize($_POST['cboVote']):0;
            $modeno=isset($_POST['txtCheNo'])?strtoupper(sanitize($_POST['txtCheNo'])):null; $bankno=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;
            $prod=isset($_POST['cboProduct'])?sanitize($_POST['cboProduct']):'';  	$bankno=($bankno>0?$bankno:null);	 $date=preg_split('/\-/',$date);
            $amt=isset($_POST['txtAmt'])?sanitize($_POST['txtAmt']):0;				$bc=isset($_POST['txtBC'])?sanitize($_POST['txtBC']):0;	
            $amt=preg_replace('/[^0-9\.]/','',$amt); $bc=preg_replace('/[^0-9\.]/','',$bc);	$modeno=strlen($modeno)>0?$modeno:null;	
            $addby=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';		$hireon=isset($_POST['dtpHiredOn'])?strtoupper(sanitize($_POST['dtpHiredOn'])):date('d-m-Y'); 
            $kind=isset($_POST['txtKind'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtKind']))):null; 	$kind=strlen($kind)>0?$kind:null;
            $rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtRmks']))):null; $rmks=strlen($rmks)>0?$rmks:null;
            $hireon=preg_split('/\-/',$hireon);		$date="$date[2]-$date[1]-$date[0]";		$hireon="$hireon[2]-$hireon[1]-$hireon[0]"; 
            $origmode=isset($_POST['cboOrigMode'])?strtoupper(sanitize($_POST['cboOrigMode'])):'DIRECT BANKING';
            if (($amt<=0) || ((strcasecmp($mode,"Cash")!=0 && strcasecmp($mode,"Kind")!=0) && strlen($modeno)==0) || (strcasecmp($mode,"Kind")==0  && strlen($kind)<10 && strlen($name)<8 
            && strlen($telno)<9) || ((strcasecmp($mode,"cheque")==0 || strcasecmp($mode,"direct banking")==0) && (is_null($bankno) || is_null($modeno))) || (strcasecmp($mode,"mfees")==0
            && is_null($modeno)) || ($_SESSION['form_token']!=$token[0]) || is_null($rmks) || strlen($rmks)<10 || $acc<1 || $vote<1 && strlen($code)<5){
                print "Sorry, the alternative income record had errors. The reciept was not sucessfully saved. Click <a href=\"otherincomes.php\">here</a> to try again";
                unset($_SESSION['form_token']); exit(0);
            }else{
                unset($_SESSION['form_token']);	$norecs=0;
                $sql="UPDATE acc_alterincome SET alt_names=".var_export($name,true).",telno='$telno',idno=".var_export($idno,true).",paddress=".var_export($address,true).",product='$prod',
                hiredate='$hireon',rmks=".var_export($rmks,true).", acc=$acc,voteno=$vote WHERE code LIKE '$code';";
                $sql.="UPDATE acc_incofee SET pytdate='$date',pytfrm='$mode',cheno=".var_export($modeno,true).",bankno=".var_export($bankno,true).",kinddescr=".var_export($kind,true)." WHERE 
                sno LIKE '$token[2]';";
                $sql.="UPDATE ".($acc==1?"acc_IncoRecNo0":"acc_IncoRecNo1")." SET acc='$acc',bc=$bc,amt=$amt WHERE recno LIKE '$recno';";
                $sql.="UPDATE acc_incovotes SET acc='$acc',voteno='$vote',amt=$amt WHERE recno LIKE '$recno' and acc LIKE '$token[1]' and voteno LIKE '$token[3]';";
                mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"otherincomes.php\">HERE</a> to try again.");
                while(mysqli_next_result($conn)){$norecs+=mysqli_affected_rows($conn);}  $norecs=($norecs>0?1:0);
                if(strcasecmp($mode,"KIND")==0 && strcasecmp($origmode,"KIND")==0 && $norecs>0){//originally and still fees in kind
                        $sql="UPDATE acc_exppayee SET payee='$name',idno='$idno',address=".var_export($addr,true).",telno='$telno' WHERE payno IN (SELECT expno FROM acc_exp WHERE recsno LIKE 
                        '$token[1]'); UPDATE acc_exp SET acc='$acc',caamt=$amt,rmks='NEING PAYMENT TO CLEAR FEES INKIND - $kind' WHERE recsno LIKE '$token[1]'; UPDATE acc_pytvotes SET 
                        acc='$acc',voteno='$vote',amt=$amt WHERE acc LIKE '$token[2]' and voteno LIKE '$token[3]' and vono IN (SELECT vono FROM exp WHERE recsno LIKE '$token[1]');";
                        mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"otherincomes.php\">HERE</a> to try again.");
                        while(mysqli_next_result($conn)){} 
                }if(strcasecmp($mode,"KIND")!=0 && strcasecmp($origmode,"KIND")==0 && $norecs>0){//originally fee in kind but now not
                        $sql="UPDATE acc_exp SET markdel=1,delreason='Alternative income Receipt No. $recno Changed from Fees InKind to $mode' WHERE recsno LIKE '$token[1]'; UPDATE acc_pytvotes 
                        SET markdel=1 WHERE acc LIKE '$token[2]' and voteno LIKE '$token[3]' and vono IN (SELECT vono FROM exp WHERE recsno LIKE '$token[1]');";
                        mysqli_multi_query($conn,$sql) or die(mysqli_error($conn)."Click <a href=\"otherincomes.php\">HERE</a> to try again.");
                        while(mysqli_next_result($conn)){} 
                }elseif(strcasecmp($mode,"KIND")==0 && strcasecmp($origmode,"KIND")!=0 && $norecs>0){//originally not fee in kind but now it is
                        mysqli_multi_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno'; SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc LIKE '1';"); 
                        $i=0; $payno=0; $vote=0;
                        do{
                                if($rs=mysqli_store_result($conn)){
                                        if($i==0){$no=mysqli_num_rows($rs); if ($no>0) list($payno)=mysqli_fetch_row($rs);
                                        }else{$no=mysqli_num_rows($rs); if ($no>0) list($vono)=mysqli_fetch_row($rs);
                                        }mysqli_free_result($rs);
                                }$i++;
                        }while(mysqli_next_result($conn)); $vono++;
                        if($payno==0){//paye details are not in the system
                                if (mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES(0,'$date','$name','$idno',".var_export($addr,true).",
                                '$telno','$addby')")){
                                        $rs=mysqli_query($conn,"SELECT last_insert_id()"); list($payno)=mysqli_fetch_row($rs);  mysqli_free_result($rs);
                                }
                        }mysqli_multi_query($conn,"INSERT INTO acc_exp(vono,pytdate,pytfrm,acc,caamt,rmks,expno,addedby,recsno) values ($vono,'$date','Cash',$acc,$amt,'BEING PAYMENT 
                        FOR $kind',$payno,'$addby',$token[1]); INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,$acc,$vote,$amt);") or die(mysqli_error($conn));
                        while(mysqli_next_result($conn)){} 
                } header("Location:otherincomes.php?action=1-$norecs"); exit(0);
            }
        }elseif(isset($_POST['btnDel'])){
            $tkn=isset($_POST['txtTkn1'])?sanitize($_POST['txtTkn1']):'0-0-0-0-0-0-0';	$tkn=preg_split('/\-/',$tkn);//[0]Token [1]Rec No.[2]Acc [3]Serial No [4]Vote [5]Mode [6]Code
            $rmks=isset($_POST['txtReason'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtReason']))):null; $rmks=strlen($rmks)>0?$rmks:null;
            if($_SESSION['form_token']!=$tkn[0] || is_null($rmks) || strlen($rmks)<10){
                print "Sorry, cancellation of the alternative income record is not successful. Click <a href=\"otherincomes.php\">here</a> to go back.";
                unset($_SESSION['form_token']); exit(0);
            }else{
                $sql="UPDATE acc_alterincome SET markdel=1 WHERE code LIKE '$tkn[6]'; UPDATE acc_incofee SET markdel=1,delreason=".var_export($rmks,true)." WHERE sno LIKE '$tkn[3]'; 
                UPDATE ".($tkn[2]==1?"acc_IncoRecNo0":"acc_IncoRecNo1")." SET markdel=1 WHERE recno LIKE '$tkn[1]'; UPDATE acc_incovotes SET markdel=1 WHERE recno LIKE '$tkn[1]' and 
                acc LIKE '$tkn[2]' and voteno LIKE '$tkn[4]';";
                if(strcasecmp($tkn[5],'KIND')==0) $sql.="UPDATE acc_exp SET markdel=1,delreason=".var_export($rmks,true)." WHERE recsno LIKE '$tkn[3]'; UPDATE acc_pytvotes SET markdel=1 
                WHERE acc LIKE '$tkn[2]' and voteno LIKE '$tkn[4]' and vono IN (SELECT vono FROM acc_exp WHERE recsno LIKE '$tkn[3]');";
                mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Not successfully deleted. Click <a href=\"otherincomes.php\">HERE</a> to go back.");
                $i=0; while(mysqli_next_result($conn)){$i+=mysqli_affected_rows($conn);} $i=($i>0?1:0);
                header("Location:otherincomes.php?action=2-$i"); exit(0);
            }
        }	
    }else{
        $act=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):'0-0'; 	$act=preg_split('/\-/',$act); //[0] Account [1] Receipt Serial No.
        mysqli_multi_query($conn,"SELECT a.code,a.alt_names,a.telno,a.idno,a.paddress,a.product,a.hiredate,a.rmks,a.voteno,i.recno,f.pytdate,f.paidby,f.pytfrm,f.cheno,f.bankno,
        f.kinddescr,i.bc,i.amt FROM acc_incofee f Inner Join ".($act[0]==1?"acc_incorecno0":"acc_incorecno1")." i USING (sno) Inner Join acc_alterincome a On (f.admno=a.code) 
        WHERE f.sno LIKE '$act[1]'; SELECT feedel FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."';"); $i=$del=0;
        do{
            if($rs=mysqli_store_result($conn)){
                if ($i==0) list($code,$name,$tel,$idno,$addr,$prod,$hdate,$hrmks,$vote,$recno,$pdate,$pby,$pf,$che,$bank,$kind,$bc,$amt)=mysqli_fetch_row($rs); 
                else list($del)=mysqli_fetch_row($rs);
                mysqli_free_result($rs);	
            }$i++;
        }while(mysqli_next_result($conn));	$bank=is_null($bank)?0:$bank;	$cuyr=date('Y'); $tkn=uniqid();  	$_SESSION['form_token']=$tkn;
    }headings('<link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link href="../date/tcal.css" rel="stylesheet" type="text/css"/><link rel="stylesheet" '
            . 'href="tpl/css/inputsettings.css" type="text/css"/>',0,0,1);
?><div class="container divmain">
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" onsubmit="return validateData(this)" name="frmEdit"><INPUT name="txtTkn" type="hidden" size=4 value="<?php 
echo "$tkn-$act[0]-$act[1]-$vote";?>" id="txtTkn">
    <div class="form-row"><div class="col-md-12 divheadings">OTHER INCOMES EDITOR</div></div>
    <div class="form-row">
        <div class="col-md-4"><label for="txtCode">Source Code</label><input type="text" name="txtCode" id="txtCode" required readonly value="<?php echo $code;?>"></div>
        <div class="col-md-4"><label for="txtRecNo">Receipt No.</label><input type="text" name="txtRecNo" id="txtRecNo" readonly value="<?php echo $recno;?>" placeholder="<?php echo $recno;?>"></div>
        <div class="col-md-4"><label for="dtpRecOn">Received On</label><input type="text" name="dtpRecOn" id="dtpRecOn" class="tcal" required readonly value="<?php echo date('d-m-Y',strtotime($pdate));?>"></div>
    </div>
    <div class="form-row"><div class="col-md-12 divheadings">DETAILS OF THE SOURCE OF INCOME</div></div>
    <div class="form-row">
        <div class="col-md-4"><label for="txtIDNo">ID No. </label><input type="text" name="txtIDNo" id="txtIDNo" maxlength=10 onkeyup="checkInput(0,this)" onchange="showDetails(this)" value="<?php echo $idno;?>">
        </div><div class="col-md-4">----</div>
        <div class="col-md-4"><label for="txtTelNo">Tel. No.</label><input type="text" name="txtTelNo" id="txtTelNo" required maxlength=13 value="<?php echo $tel;?>" placeholder="+254700000000" 
        onkeyup="checkInput(0,this)"></div>
    </div><div class="form-row">
        <div class="col-md-12"><label for="txtName">Income Received From *</label><input type="text" name="txtName" id="txtName" required maxlength=30 size=37 style="text-transform:uppercase;" 
	placeholder="Names of Income Source" onkeyup="checkInput(2,this)" value="<?php echo $name;?>"></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="txtAddress">Postal Address *</label><input type="text" name="txtAddress" id="txtAddress" maxlength=35 size=70 style="text-transform:uppercase;" 
	placeholder="P.O Box 111-50406, Funyula" value="<?php echo $addr;?>"></div>
    </div><div class="form-row"><div class="col-md-12 divheadings">DETAILS OF VOTEHEAD &amp; INCOME AMOUNT</div></div>
    <div class="form-row">
        <div class="col-md-6"><label for="cboAC">Account Receiving Income *</label><SELECT name="cboAC" id="cboAC" onchange="showVotes(this)" size=1>
	<?php	
            mysqli_multi_query($conn,"SELECT acno,abbr FROM acc_voteacs WHERE stud_assoc=1; SELECT sno,acc,descr FROM acc_votes WHERE other_inco=1 and acc IN (SELECT acno FROM 
            acc_voteacs WHERE stud_assoc=1); SELECT sno,descr FROM acc_banks WHERE markdel=0 ORDER BY descr ASC;"); $i=0;
            do{
                if($rs=mysqli_store_result($conn)){
                    if($i==0) while($d=mysqli_fetch_row($rs)) echo "<option value=\"$d[0]\" ".($act[0]==$d[0]?"selected":"").">$d[1]</option>";
                    elseif($i==1){ $a=0; $optVote='';  $votes='';
                        while($d=mysqli_fetch_row($rs)){if($d[1]==$act[0]) $optVote.="<option value=\"$d[0]\"  ".($vote==$d[0]?"selected":"").">$d[2]</option>"; 
                        $votes.=($a==0?"":",")."new Votes($d[0],$d[1],'$d[2]')"; $a++;}
                    }else{$optBank=''; while($d=mysqli_fetch_row($rs)) $optBank.="<option value=\"$d[0]\"  ".($bank==$d[0]?"selected":"").">$d[1]</option>";} 
                    mysqli_free_result($rs);
                }$i++;
            }while(mysqli_next_result($conn));
	?></select></div>
        <div class="col-md-6"><label for="cboVote">Votehead *</label><SELECT name="cboVote" id="cboVote" size=1><?php echo $optVote;?></SELECT></div>
    </div><div class="form-row">
        <div class="col-md-6"><label for="cboProduct">Being Income From *</label><SELECT name="cboProduct" id="cboProduct" Size=1 onchange="showHireDetails(this)"><option value="GENERAL" <?php echo 
	strcasecmp($prod,"GENERAL")==0?"selected":"";?>>General Income</option><option value="HIRE SERVICES" <?php echo strcasecmp($prod,"HIRE SERVICES")==0?"selected":"";?>>Hire Services
	</option><option value="SCHOOL FARM" <?php echo strcasecmp($prod,"SCHOOL FARM")==0?"selected":"";?>>School Farm</option><option value="ASSET DISPORSAL" <?php echo strcasecmp($prod,
	"ASSET DISPORSAL")==0?"selected":"";?>>Asset Disporsal</option><option value="PROPERTY REPLACEMENT" <?php echo strcasecmp($prod,"PROPERTY REPLACEMENT")==0?"selected":"";?>>Property 
	Replacement</option><option value="FUND RAISING" <?php echo strcasecmp($prod,"FUND RAISING")==0?"selected":"";?>>Fund Raising</option><option value="DONATION" <?php echo 
	strcasecmp($prod,"DONATION")==0?"selected":"";?>>Donations</option></SELECT></div>
        <div class="col-md-6"><label for="txtRmks">Narration on Income </label><textarea name="txtRmks" id="txtRmks" rows=2 maxlength=75 required class="modalinput"
        placeholder="HIRED SCHOOL BUS TO KISUMU FOR A WEDDING."><?php echo strtoupper($hrmks);?></textarea></div>
    </div><div class="form-row">
        <div class="col-md-6"><label for="cboMode">Mode of Income *</label><SELECT name="cboMode" id="cboMode" size=1 onchange="actPytFrm(this)"><option value="CASH" <?php echo strcasecmp($pf,"CASH")==0?"selected":"";?>>
	Cash</option><option value="KIND" <?php echo strcasecmp($pf,"KIND")==0?"selected":"";?>>Kind</option><option value="CHEQUE" <?php echo strcasecmp($pf,"CHEQUE")==0?"selected":"";?>>
	Cheque</option><option value="DIRECT BANKING" <?php echo strcasecmp($pf,"DIRECT BANKING")==0?"selected":"";?>>Direct Banking</option><option value="MONEY ORDER" <?php 
	echo strcasecmp($pf,"MONEY ORDER")==0?"selected":"";?>>Money Order</option><option value="MFEES" <?php echo strcasecmp($pf,"MFEES")==0?"selected":"";?>>M-Fees</option></SELECT></div>
	<div class="col-md-6"><label for="txtCheNo">Trans/ Cheque No.</label><input type="text" name="txtCheNo" id="txtCheNo" readonly value="<?php echo $che;?>" maxlength=15></div>
        <div class="col-md-6"><label for="cboBank">Banker (if Cheque/ Bankslip)</label><SELECT name="cboBank" id="cboBank" size=1 <?php echo $bank==0?"disabled":"";?>><option value=0 <?php 
        echo $bank==0?"selected":""?>>None</option><?php echo $optBank;?></SELECT></div>
    </div><div class="form-row">
        <div class="col-md-12" id="spKind" <?php echo strcasecmp($pf,"KIND")!=0?"style=\"display:none;\"":"";?>><label for="cboMode">Kind Description (If paid in Kind) *</label><textarea name="txtKind" 
	id="txtKind" cols=70 rows=2 maxlength=145 style="text-transform:uppercase;" placeholder="2 90KG BAGS OF MAIZE"><?php echo $kind;?></textarea></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="txtAmt">Amount Received *</label><input type="text" name="txtAmt" id="txtAmt" value="<?php echo number_format($amt,2);?>" style="text-align:right;" 
	onkeyup="checkInput(1,this)" onchange="calcTtl()"></div>
        <div class="col-md-4"><label for="txtBC">Bank Charges </label><input type="text" name="txtBC" id="txtBC" readonly value="<?php echo number_format($bc,2);?>" style="text-align:right;" 
	 onkeyup="checkInput(1,this)" onchange="calcTtl()"></div>
        <div class="col-md-4 divsubheading"><label for="txtTtl">Total Amount Received *</label><input type="text" name="txtTtl" id="txtTtl" disabled value="<?php echo number_format(($bc+$amt),2);?>" 
        style="text-align:right;color:#000;font-weight:bold;" size=8></div>
    </div><div class="form-row" id="spHire" <?php echo (strcasecmp($prod,"HIRE SERVICES")!=0?"style=\"display:none;\"":"");?>>
        <div class="col-md-12">
            <div class="form-row"><div class="col-md-12 divheadings">DATE WHEN ASSET OR FACILITY HIRED IS/WAS TO USED</DIV></DIV>
            <div class="form-row">
                <div class="col-md-4"><label for="dtpHiredOn">Hired On *</label><input type="text" name="dtpHiredOn" id="dtpHiredOn" readonly class="tcal" value="<?php echo date('d-m-Y',
                strtotime((is_null($hrmks)?'+2 days':$hdate)));?>"></div>
                <div class="col-md-8"></div>
            </div>
        </div>
    </div><hr><div class="form-row">
        <div class="col-md-4"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSave">Save Changes</button></div>
        <div class="col-md-4" style="text-align:right;"><button type="button" class="btn btn-info btn-md" <?php echo $del==0?"disabled":"";?> onclick="showDelete(<?php echo $del;?>)">Delete Income</button></div>
        <div class="col-md-4" style="text-align:right;"><a href="otherincomes.php"><button type="button" class="btn btn-info btn-md">Close/ Cancel</button></a></div>
    </div>
</div>
<div id="otherIncomeDel" class="modal">
	<div class="imgcontainer"><span onclick="document.getElementById('otherIncomeDel').style.display='none'" class="close" title="Close" style="color:#fff;">&times;</span></div><br/>
	<div class="container divmodalmain">
            <div class="form-row"><div class="col-md-12"><form name="frmDel" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" onsubmit="return confirmDel(<?php echo $del;?>)">
                <table align="center" class="h" style="font-size:12pt;"><tr><td style="background-color:#444;color:#fff;font-weight:bold;letter-spacing:2px;word-spacing:4px;text-align:center;">DELETE 
                <?php echo "$pf RECEIPT NO. $recno FROM $prod <br> BY $name";?><hr></td></tr><INPUT name="txtTkn1" id="txtTkn1" type="hidden" value="<?php echo "$tkn-$recno-$act[0]-$act[1]-$vote-$pf-
                $code";?>" id="txtTkn">
                <tr><td class="h">Reason for Cancellation of Income *<br><textarea name="txtReason" id="txtReason" cols=80 rows=3 maxlength=150 placeholder="ERRONEOUSLY CAPTURED"  
                style="text-transform:uppercase;"></textarea><hr><br>.</td></tr></table>
                </div>
            </div><div class="form-row">
                <div class="col-md-6" style="text-align:center;"><button name="btnDel" type="submit" class="btn btn-warning btn-lg">Cancel Income Record</button></div>
                <div class="col-md-6" style="text-align:right;"><button type="button" onclick="document.getElementById('otherIncomeDel').style.display='none'" class="btn btn-info btn-lg">Close</button></div>
            </div>
	</div></form>
</div>
<script type="text/javascript" src="../date/tcal.js"></script><script type="text/javascript" src="tpl/js/otherincomes.js"></script>
<?php 
    if(isset($votes)){echo '<script type="text/javascript">votes.push('.$votes.');</script>';}
    mysqli_close($conn); footer();
?>