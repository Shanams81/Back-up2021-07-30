<?php
	session_start();
	if (!(isset($_SEESION['username']) || ($_SESSION['username'] != ''))) {
		header ("Location:../index.php");
	} else {
		include_once('../conn/mysqli_connect.inc.tpl');
		$action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
		$rsStf=mysqli_query($conn,"SELECT loanwaive FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'"); $waiv=0;
		if(mysqli_num_rows($rsStf)==1) list($waiv)=mysqli_fetch_row($rsStf);	mysqli_free_result($rsStf);
		if($waiv==0) header("location:vague.php");
		$idno=isset($_REQUEST['txtIDNo']) ? strip_tags($_REQUEST['txtIDNo']):"%"; $idno=strlen($idno)==0?"%":$idno;
	}
?>
<html>
<head>
	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Salary Manager</title>
	<script type="text/javascript" src="tpl/actionmessage.js"></script>
</head>
<body background="../gen_img/bg3.gif" <?php print "onload=\"actiondone($action[0],$action[1])\"";?>>
	<center><form method="post" action="waive_Subloan.php">
		<a href="waivers.php"><img src="../gen_img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp; Find Member of Staff of ID No.</label>&nbsp;<input type="text" 
		maxlength="10" size="11" name="txtIDNo" id="idno" value="%"> &nbsp;&nbsp;<button type="submit" name="cmdShow">Subloan Defaulter</button> &nbsp;&nbsp;<button type="submit" 
		name="cmdShowWaive">Waived Subloans</button>
	</form></center>
	<hr><h3>
	<?php
		if (isset($_POST['cmdShow'])) $h="Subloan Defaulters"; elseif (isset($_POST['cmdShowWaive'])) $h="Waived Subloans"; else $h= "Subloan Waivers - User Manuals";
		print "<h2 style=\"word-spacing:3px;letter-spacing:2px;text-align:center;\">".strtoupper($h)."</h2>";
	?></h3>
	<hr>
</body>
</html>
<?php
if (isset($_POST['cmdShow'])):
	$rsAdvDef=mysqli_query($conn,"SELECT a.loanno,s.tscno,s.idno,concat(s.surname,' ',s.onames) as st_names,a.adv_date,concat(a.mons,' Month(s)') as dur,a.amt,a.amtpermon,
	IF(isnull(sum(c.amt_clr)),0,Sum(c.amt_clr)) AS AmtClrd,(a.amt-IF(isnull(sum(c.amt_clr)),0,Sum(c.amt_clr))) AS Bal,a.rmks FROM stf s INNER JOIN (Acc_subloan a LEFT JOIN Acc_subloanClr c USING 
	(loanno)) ON s.idno=a.idno GROUP BY s.idno,s.tscno,s.surname,s.onames,a.adv_date,a.loanno,a.amtpermon,a.amt,a.rmks,a.mons HAVING (((a.amt-IF(isnull(Sum(c.amt_clr)),0,Sum(c.amt_clr)))>0) and 
	(s.idno LIKE '$idno')) Order By a.loanno Asc");
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\" align=\"center\"><tr align=\"middle\"><th rowspan=\"2\">Loan<br>No.</th><th colspan=\"3\">Staff Member's Details</th>
	<th colspan=\"2\">Loan Details</th><th colspan=\"4\">Subloan Amount</th><th rowspan=\"2\" bgcolor=\"#eeeeee\">Reason for the Subloan</th><th rowspan=\"2\">Admin<br>Action</th></tr><tr 
	bgcolor=\"#eeeeee\"><th>ID. No.</th><th>Names</th><th>TSC No.</th><th>Issued On</th><th>Recovered In<th>Amount</th><th>Deduction/Month</th><th>Cleared</th><th>Balance</th></tr>";
	$ttl=array(0,0,0,0); $i=0;
	if (mysqli_num_rows($rsAdvDef)>0):
		while ($res=mysqli_fetch_array($rsAdvDef,MYSQLI_NUM)):
			if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
			$ai=0;
			foreach($res as $rse){
				if (($ai<4) || ($ai==10) || ($ai==5)):
					if ($ai==0) $lono=$rse;
					print "<td>".$rse."</td>";
				elseif ($ai==4):
					$rse=date("D, d-F-Y",strtotime($rse));
					print "<td>".$rse."</td>";
				else:
					$rse=(float)$rse;
					$ttl[($ai-6)]+=$rse;
					print "<td align=\"right\">".number_format($rse,2)."</td>";
				endif;	
				$ai++;
			}
			print "<td align=\"center\"><a href=\"Waive_SubloanEdit.php?id=0-$lono-%\">Waive</a></td></tr>"; $i++;
		endwhile;
	else:
		print "<tr><td colspan=\"13\">.<br>There are no subsistence loans issued to TSC members of staff<br>.</td></tr>";
	endif;
	print "<tr bgcolor=\"#eeaaaa\"><td colspan=\"4\" align=\"left\" class=\"b\">".mysqli_num_rows($rsAdvDef)." Subloan Defaulters</td><td align=\"right\" class=\"b\" colspan=\"2\">
	Subloan Subtotals (Kshs.)</td>";
	foreach($ttl as $t) print "<td align=\"right\" class=\"b\">".number_format($t,2)."</td>";
	print "<td align=\"middle\" colspan=\"2\"></td></tr></table><br><center>Report Generated on ".date("l F d, Y")."</center>";
	mysqli_free_result($rsAdvDef);
elseif (isset($_POST['cmdShowWaive'])):
	$rsWaiv=mysqli_query($conn,"SELECT a.loanno,s.idno,concat(s.surname,' ',s.onames) as st_names,a.adv_date,concat(a.mons,' Month(s)') as dur,a.amt,w.waiveno,w.waivedon,w.amt_waived,
	w.rmks FROM stf s INNER JOIN Acc_subloan a USING (idno) Inner Join acc_subloanwaive w On (a.loanno=w.loanno) WHERE w.markdel=0 and s.idno LIKE '$idno' ORDER BY a.loanno ASC");
	print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\" align=\"center\"><tr align=\"middle\" style=\"word-spacing:4px;letter-spacing:2px;\"><th colspan=\"6\">SUBLOAN 
	DETAILS</th><th colspan=\"3\">SUBLOAN WAIVE DETAILS</th><th rowspan=\"2\">Admin<br>Action</th></tr><tr bgcolor=\"#eeeeee\"><th>Loan No.</th><th>ID. No.</th><th>Names</th><th>Issued On
	</th><th>Recovered In<th>Amount</th><th>Waived On</th><th>Waive Remarks</th><th>Amount</th></tr>";
	$i=0; $tadamt=0; $twamt=0; $nr=mysqli_num_rows($rsWaiv);
	if ($nr>0){
		while (list($lono,$id,$nam,$addate,$dur,$adamt,$wano,$waon,$wamt,$rmk)=mysqli_fetch_row($rsWaiv)){
			if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
			print "<td>$lono</td><td>$id</td><td>$nam</td><td align=\"right\">".date("D d M, Y",strtotime($addate))."</td><td>$dur</td><td align=\"right\">".number_format($adamt,2).
			"</td><td align=\"right\">".date("D d M, Y",strtotime($waon))."</td><td>$rmk</td><td align=\"right\">".number_format($wamt,2)."</td><td align=\"center\"><a 
			href=\"Waive_SubloanEdit.php?id=1-$lono-$wano\">Edit</a></td></tr>";
			$i++; $tadamt+=$adamt;	$twamt+=$wamt;
		}
	}else print "<tr><td colspan=\"10\">.<br>There are no subsistence loan waivers/ pardons registered in the system<br>.</td></tr>";
	print "<tr><td colspan=\"3\">$nr Subloan Waiver(s)</td><td colspan=\"2\" align=\"right\">Total Amount</td><td align=\"right\">".number_format($tadamt,2)."</td><td colspan=2><td 
	align=\"right\">".number_format($twamt,2)."</td><td></td></tr></table><br><center>Report Generated on ".date("l F d, Y")."</center>";
	mysqli_free_result($rsWaiv);
else:
	print "<b><u>Viewing Issued Salary Advances</u></b><ol type=\"a\"><li>Select the <b>Month</b> whose advances is to be viewed,<li>Or select <b>All</b> to view 
	all year's salary advances. Leave, or<li>Enter ID. No. to view respective individual member's salary advances.<li>Click <b>Salary Advance</b> button.</ol>";
endif;
mysqli_close($conn);
?>