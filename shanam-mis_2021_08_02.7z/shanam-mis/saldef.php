<?php
    include_once('shanam.php');
    if (isset($_POST['CmdSave'])){
        $idn=isset($_POST['TxtIdNo'])?sanitize($_POST['TxtIdNo']):'0-0';                            $idn=preg_split("/\-/",$idn);
        $payno=isset($_POST['TxtPayrollNo'])?sanitize($_POST['TxtPayrollNo']):'001';                $bank=isset($_POST['CboBank'])?strtoupper(sanitize($_POST['CboBank'])):0;
        $branch=isset($_POST['CboBankBranch'])?strtoupper(sanitize($_POST['CboBankBranch'])):'';    $source=isset($_POST['cboSource'])?sanitize($_POST['cboSource']):0;
        $acno=isset($_POST['TxtACNo'])?sanitize($_POST['TxtACNo']):Null;                            $bsal=isset($_POST['TxtBasicSal'])?sanitize($_POST['TxtBasicSal']):0;
        $nssfno=isset($_POST['TxtNSSFNO'])?sanitize($_POST['TxtNSSFNO']):Null;		$nhifno=isset($_POST['TxtNHIFNO'])?strtoupper(sanitize($_POST['TxtNHIFNO'])):'R00001';
        $house=isset($_POST['TxtHouse'])?sanitize($_POST['TxtHouse']):0; 		$med=isset($_POST['TxtMedical'])?sanitize($_POST['TxtMedical']):0;
        $overt=isset($_POST['TxtCommuter'])?sanitize($_POST['TxtCommuter']):0;		$empnssf=isset($_POST['TxtEmpNSSF'])?sanitize($_POST['TxtEmpNSSF']):0;
        $nssf=isset($_POST['TxtNSSF'])?sanitize($_POST['TxtNSSF']):0;			$nhif=isset($_POST['TxtNHIF'])?sanitize($_POST['TxtNHIF']):0;
        $paye=isset($_POST['TxtPaye'])?sanitize($_POST['TxtPaye']):0;			$union=isset($_POST['TxtUnion'])?sanitize($_POST['TxtUnion']):0;
        $sac=isset($_POST['TxtSACCO'])?sanitize($_POST['TxtSACCO']):0;			$wel=isset($_POST['TxtWelfare'])?sanitize($_POST['TxtWelfare']):0;
        $ole=isset($_POST['TxtOle'])?sanitize($_POST['TxtOle']):0;			$mpr=isset($_POST['TxtMPR'])?sanitize($_POST['TxtMPR']):0;
        $resp=isset($_POST['TxtResponse'])?sanitize($_POST['TxtResponse']):0;		$un=$_SESSION['username']." (".$_SESSION['priviledge'].")"; $regdon=date("Y-m-d H:n:s");
        $bsal=preg_replace("/[^0-9^\.]/","",$bsal);	$house=preg_replace("/[^0-9^\.]/","",$house);		$med=preg_replace("/[^0-9^\.]/","",$med);
        $overt=preg_replace("/[^0-9^\.]/","",$overt);	$empnssf=preg_replace("/[^0-9^\.]/","",$empnssf); 	$nssf=preg_replace("/[^0-9^\.]/","",$nssf);
        $nhif=preg_replace("/[^0-9^\.]/","",$nhif);	$paye=preg_replace("/[^0-9^\.]/","",$paye);		$union=preg_replace("/[^0-9^\.]/","",$union);
        $ole=preg_replace("/[^0-9^\.]/","",$ole);	$mpr=preg_replace("/[^0-9^\.]/","",$mpr);		$sac=preg_replace("/[^0-9^\.]/","",$sac);
        $wel=preg_replace("/[^0-9^\.]/","",$wel);	$resp=preg_replace("/[^0-9^\.]/","",$resp);             $source=($source==0?"Null":$source);
        $netsal=($bsal+$house+$med+$overt+$resp)-($nssf+$nhif+$paye-$mpr+$union+$ole+$sac+$wel);
        if((strlen($payno)==0) ||(strlen($idn[0])==0)||($netsal<100)|| strlen($branch)<4){
            print "SERVER ERROR <font color=\"#cc0000\">Ensure staff member's Payroll No. and basic salary fields are validly entered before saving</font>.<br>Click <a
            href=\"saldet.php\">Here</a> to go back.<br>";	exit(0);
        }elseif($idn[1]==0){
            $sql="INSERT INTO acc_saldef (payrollno,idno,bankname,bankbranch,accountno,nssfno,nhifno,bsal,houseallow,medicalallow,travellallow,empnssf,responsallow,nssffee,nhiffee,paye,mpr,unionfee,saccofee,welfare,
            otherlevies,addedby,acc) VALUES (".var_export($payno,true).",".var_export($idn[0],true).",".var_export($bank,true).",".var_export($branch,true).",".var_export($acno,true).",".var_export($nssfno,true).",".
            var_export($nhifno,true).",".var_export($bsal,true).",".var_export($house,true).",".var_export($med,true).",".var_export($overt,true).",".var_export($empnssf,true).",".var_export($resp,true).",".
            var_export($nssf,true).",".var_export($nhif,true).",".var_export($paye,true).",".var_export($mpr,true).",".var_export($union,true).",".var_export($sac,true).",".var_export($wel,true).",".var_export($ole,true).
            ",".var_export($un,true).",".var_export($source,true).")";
        }else{
            $sql="UPDATE acc_saldef SET payrollno=".var_export($payno,true).",bankname=".var_export($bank,true).",bankbranch=".var_export($branch,true).",accountno=".var_export($acno,true).",nssfno=".var_export($nssfno,
            true).",nhifno=".var_export($nhifno,true).",bsal=".var_export($bsal,true).",houseallow=".var_export($house,true).",medicalallow=".var_export($med,true).",travellallow=".var_export($overt,true).",
            responsallow=".var_export($resp,true).",empnssf=".var_export($empnssf,true).",nssffee=".var_export($nssf,true).",nhiffee=".var_export($nhif,true).",paye=".var_export($paye,true).",unionfee=".var_export($union,
            true).",saccofee=".var_export($sac,true).",welfare=".var_export($wel,true).",otherlevies=".var_export($ole,true).",mpr=".var_export($mpr,true).",acc=".var_export($source,true)." WHERE idno LIKE '$idn[0]'";
        }
        mysqli_query($conn,$sql) or die(mysqli_error($conn)." Staff salary definition record not saved. Click <a href=\"saldet.php\">Here</a> to go back."); $i=mysqli_affected_rows($conn);
        header("location:saldet.php?action=1-$i");
    }elseif (isset($_POST['CmdDel'])){
        $idn=strlen(trim($_POST['TxtIdNo']))>0?trim(strip_tags($_POST['TxtIdNo'])):'0-0'; $idn=preg_split("/\-/",$idn);
        mysqli_query($conn,"UPDATE acc_saldef SET markdel=1 WHERE idno LIKE '$idn[0]'")or die(mysqli_error($conn).". Salary definition record not deleted. Click <a href=\"saldet.php\">Here</a> to go back and try again.");
    }else{
        $idn=isset($_REQUEST['idno'])?$_REQUEST['idno']:'0-0'; $idn=preg_split("/\-/",$idn);
        $payno=$bank=$branch=$acno=$nssfno=$nhifno=''; $bsal=$house=$med=$comm=$empnssf=$nssf=$nhif=$sac=$wel=$paye=$union=$mpr=$ole=$response=$acso=$scht=$i=0;
        if ($idn[1]==1){
            $rsSD=mysqli_query($conn,"SELECT payrollno,bankname,bankbranch,accountno,nssfno,nhifno,bsal,houseallow,medicalallow,empnssf,travellallow,responsallow,nssffee,nhiffee,paye,
             mpr,unionfee,saccofee,welfare,otherlevies,if(isnull(acc),0,acc) as so FROM acc_saldef WHERE idno LIKE '$idn[0]' and markdel=0");
            list($payno,$bank,$branch,$acno,$nssfno,$nhifno,$bsal,$house,$med,$empnssf,$comm,$response,$nssf,$nhif,$paye,$mpr,$union,$sac,$wel,$ole,$acso)=mysqli_fetch_row($rsSD);
            mysqli_free_result($rsSD);
        }mysqli_multi_query($conn,"SELECT concat(s.surname,' ',s.onames,' (',designation,')') as nam FROM stf s WHERE idno LIKE '$idn[0]'; SELECT schtype FROM ss;");
        do{
            if($rs=mysqli_store_result($conn)){
                if($i==0){if (mysqli_num_rows($rs)==1) list($nam)=mysqli_fetch_row($rs); }
                else{if (mysqli_num_rows($rs)==1) list($scht)=mysqli_fetch_row($rs); }
                mysqli_free_result($rs);
            }$i++;
        }while(mysqli_next_result($conn));
    }
    headings('<link rel="stylesheet" type="text/css" href="tpl/css/saldef.css" />',0,0,1);
?>
<form method="post" action="saldef.php" onsubmit="return validateFormOnSubmit(this);">
<div class="container" style="background-color:#eee;margin:auto;border-radius:10px;padding:5px;max-width:650px;">
<div class="form-row">
    <div class="col-md-12 mb-3" style="background:#000;color:#fff;margin:auto;border-radius:10px 10px 0px 0px;word-spacing:2px;letter-spacing:1px;font-weight:bold;text-align:center;"><input
    type="hidden" value="<?php echo "$idn[0]-$idn[1]";?>" name="TxtIdNo">ID No. <?php echo "$idn[0] <u>$nam'S";?></u><br>SALARY DEFINITION</div>
</div>
<div class="form-row">
    <div class="col-md-3 mb-3"><label for="txtPFNo">Payroll No. *</label><input type="text" name="TxtPayrollNo" id="txtPFNo" maxlength="4" value="<?php echo $payno;?>"
    onchange="checkInput(this)" required>
    </div><div class="col-md-3">
      	<label for="CboBank">Pay - Point *</label><Select name="CboBank" id="CboBank" size="1" required>
      	<?php
            mysqli_multi_query($conn,"SELECT pp FROM grps WHERE (pp IS NOT NULL OR pp NOT LIKE '') ORDER BY pp ASC; SELECT bb FROM grps WHERE (bb IS NOT NULL OR bb NOT LIKE '') ORDER
            BY bb ASC; SELECT acno,abbr FROM acc_voteacs WHERE sal_assoc=1 ORDER BY acno ASC;"); $optBank=$optBranch=$optSource=""; $a=0;
            do{
                if($rs1=mysqli_store_result($conn)){
                    if ($a==0){if (mysqli_num_rows($rs1)>0) while (list($pp)=mysqli_fetch_row($rs1)) $optBank.="<option ".(strcasecmp($bank,$pp)==0?"Selected":"").">$pp</option>";
                    }elseif($a==1){if (mysqli_num_rows($rs1)>0) while (list($bb)=mysqli_fetch_row($rs1)) $optBranch.="<option ".(strcasecmp($branch,$bb)==0?"Selected":"").">$bb</option>";
                    }else{ if (mysqli_num_rows($rs1)>0) while (list($sn,$name)=mysqli_fetch_row($rs1)) $optSource.="<option value=\"$sn\" ".($sn==$acso?"Selected":"").">$name</option>";}
                    mysqli_free_result($rs1);
                } $a++;
            }while(mysqli_next_result($conn));	print $optBank;
        ?></Select>
    </div><div class="col-md-3"><label for="CboBank">Paypoint Branch *</label><Select name="CboBankBranch" id="CboBankBranch" size="1" required><?php echo $optBranch;?></SELECT></div>
    <div class="col-md-3 mb-3"><label for="cboSource">Earns Salary from *</label><SELECT name="cboSource" id="cboSource" size="1" required><option value="0" <?php echo ($acso==0?"Selected":"");?>>
	All Accounts</option><?php echo $optSource;?></SELECT></div>
</div>
<div class="form-row">
    <div class="col-md-6 mb-3"><label for="TxtAcNo">Account No.</label><input type="text" name="TxtACNo" id="TxtACNo" maxlength="18" value="<?php echo $acno;?>"
    onkeyup="checkInput(this)" style="letter-spacing:4px;"></div>
    <div class="col-md-3 mb-3"><label for="TxtNSSFNO">N.S.S.F No.</label><input name="TxtNSSFNO" id="TxtNSSFNO" type="text" maxlength="15" value="<?php echo $nssfno;?>"></div>
    <div class="col-md-3 mb-3"><label for="TxtNSSFNO">N.H.I.F No.</label><input name="TxtNHIFNO" id="TxtNHIFNO" type="text" maxlength="11" value="<?php echo $nhifno; ?>"
    style="text-transform:uppercase;"></div>
</div>
<div class="form-row"><div class="col-md-12 mb-3" style="background-color:#555;color:#fff;word-spacing:2px;letter-spacing:1px;font-weight:bold;text-align:center;">SALARY ALLOWANCES</div></div>
<div class="form-row input-group-sm">
    <div class="col-md-3 mb-3"><label for="TxtBasicSal">Basic Salary *</label><input type="text" name="TxtBasicSal" id="TxtBasicSal" maxlength="9" value="<?php echo number_format($bsal,2); ?>"
    style="text-align:right;" onkeyup="checkInput(this)" onBlur="computeGS(0)"></div>
    <div class="col-md-3 mb-3"><label for="TxtHouse">Housing *</label><input type="text" name="TxtHouse" id="TxtHouse" maxlength="8" value="<?php echo number_format($house,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onBlur="computeGS(0)"></div>
    <div class="col-md-3 mb-3"><label for="TxtMedical">Medical *</label><input type="text" name="TxtMedical" id="TxtMedical" maxlength="8" value="<?php echo number_format($med,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeGS(0)"></div>
    <div class="col-md-3 mb-3"><label for="TxtCommuter">Commuter *</label><input type="text" name="TxtCommuter" id="TxtCommuter" maxlength="8" value="<?php echo number_format($comm,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeGS(0)"></div>
</div><div class="form-row">
    <div class="col-md-3 mb-3"><label for="TxtResponse">Responsibility *</label><input type="text" id="TxtResponse" name="TxtResponse" maxlength="8" onkeyup="checkInput(this)"
    onChange="computeGS(0)" value="<?php echo number_format($response,2);?>" style="text-align:right;"></div>
    <div class="col-md-3 mb-3"><label for="TxtEmpNSSF">Employer NSSF *</label><input type="text" name="TxtEmpNSSF" id="TxtEmpNSSF" maxlength="8" value="<?php echo number_format($empnssf,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeGS(1)"></div>
    <div class="col-md-6 mb-3" style="background-color:#fdc;"><b>Gross Salary</b> <input name="TxtGSal" id="TxtGSal" type="text" value="<?php echo number_format(($bsal+$med+$house+$comm+
    $empnssf),2);?>" style="text-align:right;font-weight:bold;" disabled></div>
</div><div class="form-row"><div class="col-md-12 mb-3" style="background-color:#555;color:#fff;word-spacing:4px;letter-spacing:3px;font-weight:bold;text-align:center;">SALARY DEDUCTIONS</div></div>
<div class="form-row">
    <div class="col-md-3 mb-3"><label for="TxtNSSF">N.S.S.F Fee *</label><input type="text" name="TxtNSSF" id="TxtNSSF" maxlength="8" value="<?php echo number_format($nssf,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeDed()"></div>
    <div class="col-md-3 mb-3"><label for="TxtNHIF">N.H.I.F Fee *</label><input type="text" id="TxtNHIF" name="TxtNHIF" maxlength="8" value="<?php echo number_format($nhif,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeDed()"></div>
    <div class="col-md-3 mb-3"><label for="TxtUnion">Elimu SACCO *</label><input type="text" name="TxtUnion" id="TxtUnion" maxlength="8" value="<?php echo number_format($union,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeDed()"></div>
    <div class="col-md-3 mb-3"><label for="TxtSACCO">K . D . S *</label><input type="text" id="TxtSACCO" name="TxtSACCO" maxlength="8" value="<?php echo number_format($sac,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeDed()"></div>
</div><div class="form-row">
    <div class="col-md-3 mb-3"><label for="TxtPaye">Payable PAYE *</label><input type="text" name="TxtPaye" id="TxtPaye" maxlength="8" value="<?php echo number_format($paye,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeDed()"></div>
    <div class="col-md-3 mb-3"><label for="TxtMPR">PAYE Relief *</label><INPUT type="text" name="TxtMPR" id="TxtMPR" maxlength="8" value="<?php echo number_format($mpr,2);?>"
    onkeyup="checkInput(this)" onChange="computeDed()" style="text-align:right;"></div>
    <div class="col-md-6 mb-3" style="background-color:#dddddd;font-weight:bold;"><label for="TxtPayeAuto">PAYE Auto *</label><input type="text" name="TxtPayeAuto" id="TxtPayeAuto"
    disabled value="<?php echo number_format(($paye-$mpr),2);?>" style="text-align:right;background-color:#dddddd;"  data-toggle="PAYE Amount"></div>
</div><div class="form-row">
    <div class="col-md-3 mb-3"><label for="TxtWelfare">Welfare *</label><input type="text" id="TxtWelfare" name="TxtWelfare" maxlength="8" value="<?php echo number_format($wel,2);?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeDed()"></div>
    <div class="col-md-3 mb-3"><label for="TxtOle">Rent *</label><input type="text" name="TxtOle" id="TxtOle" maxlength="8" value="<?php echo number_format($ole,2); ?>"
    style="text-align:right;" onkeyup="checkInput(this)" onChange="computeDed()"></div>
    <div class="col-md-6 mb-3" style="background-color:#fdc;"><b>Total Deduction</b><input type="text" name="TxtDed" id="TxtDed" maxlength="8" value="<?php echo number_format(($ole+($paye-
    $mpr)+$union+$nssf+$empnssf+$nhif+$sac+$wel),2);?>" style="text-align:right;font-weight:bold;" disabled data-toggle="tooltip" title="Total Deductions" data-placement="bottom"></div>
</div>
<div class="form-row">
    <div class="col-md-12 mb-3" style="background-color:#ccc;text-align:right;"><input type="text" disabled value="<?php echo number_format(($bsal+$med+$house+$comm)-($ole+($paye-
    $mpr)+$union+$nssf+$nhif+$sac+$wel),2);?>" name="TxtNetSal" id="TxtNetSal" style="text-align:center;font-weight:bold;background-color:#ccc;" disabled data-toggle="tooltip" title="NET SALARY"
    data-placement="bottom"></div>
</div>
<div class="form-row">
    <div class="col-md-4 mb-3" style="text-align:center;"><button type="submit" name="CmdSave" id="save" class="btn-default">Save Details</button></div><div class="col-md-8 mb-3" style="text-align:right;">
	<?php if ($idn[1]==0) print ""; else print "<button type=\"submit\" name=\"CmdDel\" id=\"save\">Delete Details</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; ?>
	<a href="saldet.php"><button type="button" name="CmdClose">Close Staff</button></a></div
</div>
</div></form>
<script type="text/javascript" src="tpl/js/payenhifrates.js"></script><script type="text/javascript" src="tpl/js/saldef.js"></script><?php footer();?>
<script type="text/javascript">
var paye=[],nhif=[];
$(document).ready(function(){$('[data-toggle="tooltip"]').tooltip();});
<?php
    mysqli_multi_query($conn,"SELECT upperbound,rate FROM acc_payecalc order by payeno ASC; SELECT upperbound,amount FROM acc_nhifcalc ORDER BY nhifno ASC; SELECT mpr,
    nssfrate FROM ss;"); $p=""; $n="";
    $i=0; do{
        if($rs=mysqli_store_result($conn)){
            $start=0;
            if ($i==0) while($data=mysqli_fetch_row($rs)){$p.=($start==0?"":",")."new payeRate($data[0],$data[1])"; $start++;}
            elseif ($i==1) while($data=mysqli_fetch_row($rs)){$n.=($start==0?"":",")."new nhifRate($data[0],$data[1])";$start++;}
            else {$data=mysqli_fetch_row($rs); print "var mpr=$data[0],nssfRate=$data[1];";}
        }$i++;	mysqli_free_result($rs);
    }while (mysqli_next_result($conn)); print "paye.push($p); nhif.push($n);";
    print "</script>"; mysqli_close($conn);
?>
