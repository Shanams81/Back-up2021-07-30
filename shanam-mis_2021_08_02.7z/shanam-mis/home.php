<?php
	include_once('shanam.php'); //phpinfo();
	$act=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0'; $act=preg_split("/\-/",$act);
	headings('<link rel="stylesheet" href="tpl/css/photoalbum.css" type="text/css"/><style>label{background-color:#aaa;border:1px solid #99e;border-radius:12px 0px;padding:3px;color:#fff;
	font-weight:bold;min-width:100px;}IMG{width:630px;height:420px;}p,li{font-size:11pt;color:#fff;font-weight:bold;letter-spacing:3px; word-spacing:4px;}</style>',$act[0],$act[1],10);
	$rsDet=mysqli_query($conn,"SELECT sysdate,scnm,scadd,principal,nssfno,nhifno,emppin,motto,mission,vision FROM ss") or die(mysqli_error($conn).' Connection to database failed. Server
	connection error.');
	if (mysqli_num_rows($rsDet)>0):
		$data=mysqli_fetch_array($rsDet,MYSQLI_ASSOC);
		$sysdate=date('l j - F - Y',strtotime($data['sysdate']));
		$scnm=$data['scnm'];		$scadd=$data['scadd'];			$princ=$data['principal'];		$nssf=$data['nssfno'];
		$nhif=$data['nhifno'];		$pin=$data['emppin'];			$da=$data['sysdate'];			$motto=$data['motto'];			$mission=$data['mission'];	$vision=$data['vision'];
	else:
		$sysdate=date('l j - F - Y');		$scnm='School Name Not Set';	$scadd='';				$princ='';				$nssf='';
		$nhif='';		$pin='';			$da=date("Y-M-d");				$motto='';				$mission='';	$vision='';
	endif;
	mysqli_free_result($rsDet);
?>
<div class="container">
    <h3>GENERAL INFORMATION ABOUT THE INSTITUTION</h3>
    <div class="row">
        <div class="col-md-5" style="background:inherit;border-radius:10px;padding:10px;">
            <div class="row">
                <div class="col-md-12"><label for="pName">Name of the Institution</label><p id="pName" class="pout"><?php echo $scnm;?></p>
                    <label for="pMotto">Motto:</label><p id="pMotto" class="pout"><?php echo $motto;?></p>
                    <label for="pMission">Mission:</label><p id="pMission" class="pout"><?php echo $mission;?></p>
                    <label for="pVision">Vision:</label><p id="pVision" class="pout"><?php echo $vision;?></p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6"><label for="pValues">Core Value of th Institution:</label><ul type="square" id="pValues"><?php
                    $rs=mysqli_query($conn,"SELECT corevalue FROM grps WHERE corevalue is not null order by corevalue asc");
                    if (mysqli_num_rows($rs)>0) while(list($cv)=mysqli_fetch_row($rs)) echo "<li>$cv</li>"; else echo "<li>Has no values!!!!!</li>"; ?></ul>
                </div><div class="col-md-6"><label for="pNSSF">NSSF Employer Code:</label><p id="pNSSF" class="pout"><?php echo $nssf;?></p></div>
            </div>
            <div class="row">
                <div class="col-md-6"><label for="pNHIF">NHIF Employer Code:</label><p id="pNHIF" class="pout"><?php echo $nhif;?></p></div>
                <div class="col-md-6"><label for="pKRA">KRA PIN No. :</label><p id="pKRA" class="pout"><?php echo $pin;?></p></div>
            </div>
            <div class="row"><div class="col-md-12"><label for="pMotto">Director/Headteacher/ Principal:</label><p id="pMotto" class="pout"><?php echo $princ;?></p></div></div>
        </div>
        <div class="col-md-7" style="background:inherit;border-radius:10px;padding:10px;">
            <label for="slider">Photo Album</label>
            <div id="slider"><div id="mask">
            <ul>
                <li id="first" class="firstanimation"><a href="#"><img class="album" src="../gen_img/slide/school1.jpg" alt="Overview"/></a><div class="tooltip"><h1>School</h1></div></li>
                <li id="second" class="secondanimation"><a href="#"><img class="album" src="../gen_img/slide/school6.jpg" alt="Class"/></a><div class="tooltip"><h1>School</h1></div></li>
                <li id="third" class="thirdanimation"><a href="#"><img class="album" src="../gen_img/slide/school3.jpg" alt="Lesson"/></a><div class="tooltip"><h1>School</h1></div></li>
                <li id="fourth" class="fourthanimation"><a href="#"><img class="album" src="../gen_img/slide/school4.jpg" alt="Admin"/></a><div class="tooltip"><h1>School</h1></div></li>
                <li id="fifth" class="fifthanimation"><a href="#"><img class="album" src="../gen_img/slide/school5.jpg" alt="Pass"/></a><div class="tooltip"><h1>School</h1></div></li>
            </ul>
            </div><div class="progress-bar"></div></div>
        </div>
    </DIV>
</div></DIV>
<p style="color:#FFF;text-align:left;background-color:#777;font-style:normal;font-size:13px;position:absolute;bottom:5px;letter-spacing:2px;word-spacing:3px;">The server is to be
comprehensively maintained before <b color="#b00"><?php print date("D, d-M-Y",strtotime($da))."</b>. &copy; 2013 - ".date("Y");?>. Contact Details: +254736732168 or shanams81@yahoo.com</p>
<?php
    mysqli_close($conn);    footer();
?>
