<?php
  include_once('shanam.php');
  $rsDet=mysqli_query($conn,"SELECT setupedit,setupadd,setupdel,setupview FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'"); $add=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	if (!isset($add) || $add[3]==0){header("location:vague.php"); exit(0);}
    $groupno=isset($_REQUEST['sno'])?sanitize($_REQUEST['sno']):"";
    if(isset($_POST['btnSave0']) || isset($_POST['btnSaveEdit0'])){
  		if(isset($_POST['btnSave0'])){
  		 	$cno=isset($_POST['txtLSNo'])?sanitize($_POST['txtLSNo']):0;  $cno=intval((strlen($cno)==0||strcasecmp($cno,'auto')==0)?0:$cno);
        $name=isset($_POST['txtLName'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtLName']))):""; $abbr=isset($_POST['txtLAbbr'])?strtoupper(sanitize($_POST['txtLAbbr'])):'';
  			if(strlen($name)>3 && strlen($abbr)>0 && $cno>0) $sql="INSERT INTO classlvl(lvlno,lvlabbr,lvlname) VALUES ($cno,'$abbr',".var_export($name,true).")"; else $sql="";
  		}else{
  			$ocno=isset($_POST['txtOLSNo1'])?sanitize($_POST['txtOLSNo1']):0;  	$cno=isset($_POST['txtLSNo1'])?sanitize($_POST['txtLSNo1']):0;
  			$name=isset($_POST['txtLName1'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtLName1']))):""; $abbr=isset($_POST['txtLAbbr1'])?strtoupper(sanitize($_POST['txtLAbbr1'])):'';
  			if(strlen($name)>3 && $cno>0 && strlen($abbr)>0) $sql="UPDATE classlvl SET lvlno=$cno,lvlname=".var_export($name,true).",lvlabbr='$abbr' WHERE lvlno LIKE '$ocno'"; else $sql="";
  		}if (strlen($sql)>10){mysqli_query($conn,$sql) or die(mysqli_error($conn)." Record not saved. Click <a href=\"classes.php?action=0-0\">here</a> to go back.");  $s[1]=mysqli_affected_rows($conn);
      } else{$s[1]=0;}     $s[0]=1;
	}elseif(isset($_POST['btnSave1']) || isset($_POST['btnSaveEdit1'])){
      if (isset($_POST['btnSave1'])){
  			$no=isset($_POST['txtCSNo'])?sanitize($_POST['txtCSNo']):0; $no=strlen($no)==0?0:$no; $lvl=isset($_POST['cboCLvl'])?sanitize($_POST['cboCLvl']):""; $lvl=strlen($lvl)==0?0:$lvl;
        $name=isset($_POST['txtCName'])?strtoupper(sanitize($_POST['txtCName'])):""; $abbr=isset($_POST['txtCAbbr'])?strtoupper(sanitize($_POST['txtCAbbr'])):"";
        if(strlen($name)>5 && strlen($abbr)>0) $sql="INSERT INTO classnames(clsno,clsname,clsabbr,lvlno) VALUES (0,".var_export($name,true).",'$abbr',$lvl)"; else $sql="";
  		}else{
        $osno=isset($_POST['txtOCSNo1'])?strtoupper(trim(strip_tags($_POST['txtOCSNo1']))):0; $no=isset($_POST['txtCSNo1'])?trim(strip_tags($_POST['txtCSNo1'])):0;  $no=strlen($no)==0?0:$no;
        $lvl=isset($_POST['cboCLvl1'])?trim(strip_tags($_POST['cboCLvl1'])):""; $lvl=strlen($lvl)==0?0:$lvl;  $name=isset($_POST['txtCName1'])?strtoupper(trim(strip_tags($_POST['txtCName1']))):"";
        $abbr=isset($_POST['txtCAbbr1'])?strtoupper(sanitize($_POST['txtCAbbr1'])):"";
        if ($no>0 && $lvl>0 && strlen($name)>2 && strlen($abbr)>0)  $sql="UPDATE classnames SET clsno='$no',clsname='$name',lvlno='$lvl',clsabbr='$abbr' WHERE clsno LIKE '$osno'"; else $sql="";
      }if (strlen($sql)>0){mysqli_query($conn,$sql) or die(mysqli_error($conn)." Record not saved. Click <a href=\"classes.php?action=0-0\">here</a> to go back.");  $s[1]=mysqli_affected_rows($conn);}
      else{$s[1]=0;} $s[0]=1;
  }else{$s=[0,0];}
  class ClsLvl{
      private $lvlNo,$lvlNa,$lvlabbr; public function __construct($n,$na,$ab){$this->lvlNo=$n;  $this->lvlNa=$na; $this->lvlabbr=$ab;}
      public function valNo(){return $this->lvlNo;}       public function valName(){return $this->lvlNa;}   public function valAbbr(){return $this->lvlabbr;}
  }class ClsNames{
      private $clsNo,$clsNa,$clsabbr,$lvlNo,$lvlNa;       public function __construct($cno,$cna,$abb,$lno,$lna){$this->clsNo=$cno;$this->clsNa=$cna; $this->lvlNo=$lno; $this->lvlNa=$lna; $this->clsabbr=$abb;}
      public function valNo(){return $this->clsNo;}       public function valName(){return $this->clsNa;}    	public function valLvlNo(){return $this->lvlNo;}
      public function valLvlName(){return $this->lvlNa;}  public function valAbbr(){return $this->clsabbr;}
  }  //Getting class levels
  mysqli_multi_query($conn,"SELECT lvlno,lvlname,lvlabbr FROM classlvl order by lvlno asc; SELECT c.clsno,c.clsname,c.clsabbr,l.lvlno,l.lvlname FROM classnames c Inner Join classlvl l USING (lvlno) ORDER BY
  c.clsno asc"); $i=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){if (mysqli_num_rows($rs)>0) while ($data=mysqli_fetch_row($rs)) $clslvl[]=new ClsLvl($data[0],$data[1],$data[2]);}
			else {if (mysqli_num_rows($rs)>0) while ($data=mysqli_fetch_row($rs)) $cls[]=new ClsNames($data[0],$data[1],$data[2],$data[3],$data[4]);}	mysqli_free_result($rs);
		}$i++;
	}while (mysqli_next_result($conn));
 headings('<link rel="stylesheet" href="tpl/css/modalfrm.css" type="text/css"/><link rel="stylesheet" href="tpl/css/inputsettings.css" type="text/css"/>',$s[0],$s[1],2);
?><div class="container divmain">
  	<h2 style="font-size:12pt;color:#fff;background-color:#000;letter-spacing:6px;word-spacing:8px;text-align:center;">GRADES/FORMS MANAGEMENT INTERFACE</h2>
  	<ul class="nav nav-tabs" id="myTabs">
  	    <li class="nav-item active"><a class="nav-link active" data-toggle="tab" id="grade-tab" href="#Grades">GRADES/ FORMS</a></li>
  	    <li class="nav-item"><a class="nav-link" data-toggle="tab" id="level-tab" href="#Levels">LEVELS</a></li>
  	</ul>
  	<div class="tab-content divmain" id="myTabContent">
  	   <div id="Grades" class="tab-pane fade show active" role="tabpanel" aria-labelledby="grade-tab">
         <div class="form-row">
        	<div class="col-md-6 divlrborder" id="clslvlFrm">
            <div class="container"><form action="classes.php" method="get" name="frmCls" id="frmCls">
              <div class="form-row"><div class="col-md-12" style="background-color:#555;color:#fff;font-weight:bold;letter-spacing:4px;word-spacing:6px;">NEW CLASS DETAILS</div></div>
              <div class="form-row">
                <div class="col-md-5"><label for="txtCSNo">Serial No. *</label><input type="text" maxlength="2" name="txtCSNo" id="txtCSNo" placeholder="1" value="" class="modalinput"></div>
                <div class="col-md-7"><label for="cboLvl">Class Level *</label><SELECT name="cboCLvl"  id="cboCLvl" size="1" class="modalinput">
                <?php if (isset($clslvl)) foreach($clslvl as $d) print "<option value=\"".($d->valNo())."\">".($d->valName())."</option>"; ?></select></div>
              </div><div class="form-row">
                <div class="col-md-12"><label for="txtCAbbr">Class/Form Short Name*</label><input type="text" maxlength="5" name="txtCAbbr" id="txtCAbbr" required placeholder="S - I" class="modalinput"></div>
              </div><div class="form-row">
                <div class="col-md-12"><label for="txtCName">Class/Form Full Name*</label><input type="text" maxlength="30" name="txtCName" id="txtCName" required placeholder="Sec - One" class="modalinput"></div>
              </div><hr><div class="form-row">
                <div class="col-md-8"><button type="button" name="btnSave1" id="btnSave1" class="btn btn-primary btn-md btn-block" onclick="saveAndShow(<?php print $add[1];?>,1)">Save Grade/Form</button></div>
                <div class="col-md-4" style="text-align:right"><button type="reset" name="btnClr1" class="btn btn-info btn-md">Cancel</button></div>
              </div></form>
          </div></div>
          <div class="col-md-6 divlrborder" id="clsShow">
              <table class="table table-bordered table-hover table-striped table-sm"><thead class="thead-dark"><tr><th colspan="9" style="font-size:12pt;font-weight:bold;
              letter-spacing:4px;word-spacing:6px;">LIST OF CLASSES</th></tr><tr><th>S/No.</th><th>Short Name</th><th>Full Name</th><th>Level</th><th>Action</th></tr></thead><tbody>
              <?php	if (isset($cls)){$i=1; foreach($cls as $d){	print "<tr><td>$i</td><td>".($d->valAbbr())."</td><td>".($d->valName())."</td><td align=\"center\">".($d->valLvlName())."</td><td>".($add[0]==1?"<span
                onclick=\"showModal(2,".($d->valNo()).")\" Title=\"Edit\" class=\"spedit\">&#x270d;</span>":"")."</td><tr>"; $i++;}}
              ?></tbody></table>
          </div>
      </div>
    </div>
    <div id="Levels" class="tab-pane fade show" role="tabpanel" aria-labelledby="level-tab">
      <div class="form-row">
        <div class="col-md-6 divlrborder" id="clslvlFrm">
          <div class="container"><form action="classes.php" method="get" name="frmLvl" id="frmLvl">
            <div class="form-row"><div class="col-md-12" style="background-color:#555;color:#fff;font-size:12pt;font-weight:bold;letter-spacing:4px;word-spacing:6px;">NEW CLASS LEVEL DETAILS</div>
            </div><div class="form-row">
              <div class="col-md-5"><label for="txtLSNo">Serial No. *</label><input type="text" maxlength="2" name="txtLSNo" id="txtLSNo" readonly value="Auto" class="modalinput"></div>
              <div class="col-md-7"><label for="txtLAbbr">Level's Short Name *</label><input type="text" maxlength="5" name="txtLAbbr" id="txtLAbbr" required placeholder="SEC" value="" class="modalinput"></div>
            </div><div class="form-row">
              <div class="col-md-12"><label for="txtLName">Level's Full Name *</label><input type="text" maxlength="30" name="txtLName" id="txtLName" required placeholder="SECONDARY" value="" class="modalinput"></div>
            </div><hr><br/><div class="form-row">
              <div class="col-md-8"><button type="button" name="btnSave0" class="btn btn-primary btn-md btn-block" onclick="saveAndShow(<?php print $add[1];?>,0)">Save New Level</button></div>
              <div class="col-md-4" style="text-align:right"><button type="reset" name="btnReset" class="btn btn-info info-md">Cancel</button></div>
            </div></form>
          </div>
      </div><div class="col-md-6 divlrborder" id="lvlShow">
          <table class="table table-bordered table-hover table-striped table-sm"><thead class="thead-dark"><tr><th class="show" colspan="6" style="font-size:12pt;font-weight:bold;
          letter-spacing:4px;word-spacing:6px;">LIST OF CLASS LEVELS</th></tr><tr><th class="show">S/No.</th><th class="show">Short Name</th><th class="show">Full Name</th><th class="show">Action</th></tr></thead><tbody>
          <?php if (isset($clslvl)){$i=1; foreach($clslvl as $d){ print "<tr><td class=\"show\">$i</td><td class=\"show\">".($d->valAbbr())."</td><td class=\"show\">".($d->valName())."</td><td class=\"show\"
            align=\"center\">".($add[0]==1?"<span onclick=\"showModal(1,".($d->valNo()).")\" Title=\"Edit\" class=\"spedit\">&#x270d;</span>":"")."</td></tr>";	$i++;}}
          ?></tbody></table>
      </div>
    </div></div>
  </div><div class="form-row"><div class="col-md-12" style="text-align:right"><button type="button" name="btnClose" onclick="window.open('settings_manager.php','_self')" class="btn btn-md btn-info">Close</button></div>
</div></div>
<div id="clsLvlEdit" class="modal">
	<div class="imgcontainer"><span onclick="document.getElementById('clsLvlEdit').style.display='none'" class="close" title="Close">&times;</span>
  </div><br/><div class="container divmodalmain"><form action="classes.php" method="POST" name="frmModal" onsubmit="return onSubmitConfirm1(this);"><input type="hidden" size="5" name="txtOLSNo1" id="txtOLSNo1" value="">
      <div class="form-row"><div class="col-md-12" style="background-color:#321;color:#fff;font-weight:bold;letter-spacing:3px;word-spacing:5px;margin-top:0px;border-radius:10px 10px 0 0;">EDIT CLASS LEVEL</div></div>
      <div class="form-row">
        <div class="col-md-5"><label for="txtLSNo1">Serial No. *</label><input type="text" maxlength="2" name="txtLSNo1" id="txtLSNo1" required onkeyup="checkNumber(this)" class="modalinput" placeholder="1"></div>
        <div class="col-md-7"><label for="txtLSNo1">Level's Short Name *</label><input type="text" maxlength="5" name="txtLAbbr1" id="txtLAbbr1" required Value="" class="modalinput" placeholder="SEC"></div>
	    </div><div class="form-row">
          <div class="col-md-12"><label for="txtLName1">Name of the Level *</label><input type="text" maxlength="30" name="txtLName1" id="txtLName1" required class="modalinput" value="" placeholder="Name"></div>
      </div><hr><div class="form-row">
          <div class="col-md-6"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSaveEdit0">Save Changes</button></div>
	        <div class="col-md-6" style="text-align:right"><button type="button" onclick="document.getElementById('clsLvlEdit').style.display='none'" class="btn btn-md btn-info">
          Cancel</button></div>
      </div></form>
  	</div>
</div>
<div id="clsEdit" class="modal">
	<div class="imgcontainer">
    <span onclick="document.getElementById('clsEdit').style.display='none'" class="close" title="Close">&times;</span>
  </div><br/>
	<div class="container divmodalmain"><form action="classes.php" method="POST" name="frmModal" onsubmit="return onSubmitConfirm2(this);">
      <div class="form-row"><div class="col-md-12" style="background-color:#321;color:#fff;font-weight:bold;letter-spacing:3px;word-spacing:5px;">EDIT CLASS DETAILS</div></div>
      <div class="form-row"><input type="hidden" name="txtOCSNo1" id="txtOCSNo1" class="modInput" value="">
        <div class="col-md-5"><label for="txtCSNo1">Serial No. *</label><input type="text" maxlength="2" name="txtCSNo1" id="txtCSNo1" required onkeyup="checkNumber(this)" class="modalinput"></div>
        <div class="col-md-7"><label for="cboCLvl1">Class Level *</label><SELECT Name="cboCLvl1" id="cboCLvl1" size="1" class="modalinput">
          <?php if (isset($clslvl)) foreach($clslvl as $d) print "<option value=\"".($d->valNo())."\">".($d->valName())."</option>";?></SELECT></div>
      </div><div class="form-row">
        <div class="col-md-5"><label for="txtCName1">Short Name *</label><input type="text" class="modalinput" maxlength="30" name="txtCAbbr1" id="txtCAbbr1" required placeholder="G1"></div>
        <div class="col-md-7"><label for="txtCName1">Full Class/Form Name *</label><input type="text" class="modalinput" maxlength="30" name="txtCName1" id="txtCName1" required placeholder="Grade - One"></div>
      </div><br><hr/><div class="form-row">
        <div class="col-md-6"><button type="submit" class="btn btn-primary btn-md btn-block" name="btnSaveEdit1">Save Changes</button></div>
        <div class="col-md-3" id="btnDelete1" style="text-align:center"></div>
        <div class="col-md-3" style="text-align:right"><button type="button" onclick="document.getElementById('clsEdit').style.display='none'" class="btn btn-md btn-info">Cancel</button></div>
       </div></form>
	</div>
</div>
<script type="text/javascript" src="tpl/js/classes.js"></script><script type="text/javascript">
<?php
	$arrlvl=''; $arrcls='';
  if (isset($clslvl)){$i=0; foreach($clslvl as $d){$arrlvl.=($i==0?"":",")."new Lvls(".($d->valNo()).",'".($d->valAbbr())."','".($d->valName())."')"; $i++;}}
  if (strlen($arrlvl)>0) print "clslvl.push($arrlvl);";
	if (isset($cls)){ $i=0; foreach($cls as $d){$arrcls.=($i==0?"":",")."new Classes(".($d->valNo()).",'".($d->valAbbr())."','".($d->valName())."',".($d->valLvlNo()).")"; $i++;}}
  if (strlen($arrcls)>0) print "cls.push($arrcls);";
	print '</script>';
	footer();mysqli_close($conn);
?>
