<?php
	session_start();
	include_once('tpl/funcs.tpl');
	if (!(isset($_SEESION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php");else	include_once('../conn/mysqli_connect.inc.tpl');
	if (isset($_POST['CmdSave'])){
		$action=strip_tags($_POST['TxtAction']); $action=preg_split("/\-/",$action); ////$action[1] for financial year. $action[0] is admission number of student.
		$arr=isset($_POST['txtNewArr'])?strip_tags($_POST['txtNewArr']):0;	 		$ref=isset($_POST['txtNewRef'])?strip_tags($_POST['txtNewRef']):0;
		$oldarr=isset($_POST['txtOldArr'])?strip_tags($_POST['txtOldArr']):0;	 	$oldref=isset($_POST['txtOldRef'])?strip_tags($_POST['txtOldRef']):0;
		$rmks=isset($_POST['txtRmks'])?strtoupper(strip_tags($_POST['txtRmks'])):"";	 		$oldref=preg_replace('/[^0-9^\.]/','',$oldref);
		$arr=preg_replace('/[^0-9^\.]/','',$arr); 	$ref=preg_replace('/[^0-9^\.]/','',$ref); 	$oldarr=preg_replace('/[^0-9^\.]/','',$oldarr); 	 
		if (($arr!=$oldarr || $ref!=$oldref) && strlen($rmks)>15) {
		 	mysqli_query($conn,"UPDATE form SET alumniarrears=$arr,alumniref=$ref WHERE admno LIKE '$action[0]' And curr_year='$action[1]'") or die(mysqli_error($conn).
			" Record not saved. Click <a href=\"alumniedit.php?admno=$action[0]\">Here</a> to try again!!!!");
			if (mysqli_affected_rows($conn)>0) mysqli_query($conn,"INSERT INTO acc_arrrefchanges(sno,admno,yr,oldarr,newarr,oldref,newref,rmks,doneon,addedby) values (0,
			$action[0],$action[1],$oldarr,$arr,$oldref,$ref,'$ref','".date('Y-m-d')."','".$_SESSION['username']." (".$_SESSION['priviledge'].")"."')") or 
			die(mysqli_error($conn));
			header("location:alumniedit.php?admno=$action[0]");
		}else {
		 	print "<p style=\"color:red;font-size:12pt;font-weight:bold;\">Sorry, Ensure that correct new refund and arrears amount, and remarks/narration of the change 
			is corectly typed before saving!!!!!.</p>";
			$admno[0]=$action[0];	$admno[1]=$action[1];
		}
	}else{
	 	$admno=isset($_REQUEST['rec'])?$_REQUEST['rec']:"0-0";
		$admno=preg_split("/\-/",$admno); //$admno[1] for financial year. $admno[0] is admission number of student.
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>Student Editor</title>
		<script type="text/javascript" src="tpl/alumni_arr_ref_amt.js"></script>
    </head>
<body background="../gen_img/bg3.gif">
	<form method="post" action="alumni_arr_ref_amt.php" onsubmit="return ValidateInput(this);">
		<?php
			$rsSt=mysqli_query($conn,"SELECT concat(s.surname,' ',s.onames) as stud_names,concat(sf.form,'-',sf.stream) as frm,sf.form,sf.stud_group,sf.alumniarrears,
			sf.alumniref FROM stud s Inner Join form sf Using (admno) WHERE sf.admno LIKE '$admno[0]' and sf.curr_year LIKE $admno[1]"); 
			list($studnames,$frm,$form,$sfg,$arr,$ref)=mysqli_fetch_row($rsSt); mysqli_free_result($rsSt);
			print "<input type=\"hidden\" value=\"$admno[0]-$admno[1]\" name=\"TxtAction\">";// Admission number, financial year and onclose where to go
			print "<br><br><br><table cellpadding=\"6\" cellspacing=\"2\" align=\"center\" style=\"left:150px;top:150px;border:1px;align:center;border-style:groove;
			border-collapse:collapse;\"><tr><td colspan=\"2\" style=\"background-color:#000;color:#fff;text-align:center;font-weight:bold;word-spacing:4px;
			letter-spacing:2px;\">ALUMNI ARREARS &amp; REFUNDABLE AMOUNT C/F</td></tr><tr><th colspan=\"2\" style=\"color:#555;background-color:#eee;
			Letter-spacing:2px;word-spacing:3px;\">Adm. No. $admno[0] <u>($studnames)</u> <br>Form $frm $admno[1] &nbsp;&nbsp;&nbsp;&nbsp;Fee Group: $sfg</th></tr><tr><td 
			colspan=\"2\">";
			print "<table border=0 cellspacing=\"1\" cellpadding=\"2\" align=\"center\"><tr><td align=\"right\" rowspan=\"2\" valign=\"bottom\">Current Amount</td><td 
			style=\"background-color:#555;color:#fff;letter-spacing:3px;\">ARREARS</td><td style=\"background-color:#555;color:#fff;letter-spacing:3px;\">REFUNDS</td>
			</tr><tr><td><Input name=\"txtOldArr\"  id=\"txtOldArr\" type=\"Text\" readonly value=\"".number_format($arr,2)."\" size=\"12\" maxlength=\"10\" 
			style=\"text-align:right;border:0px;\"></td><td><Input name=\"txtOldRef\" readonly id=\"txtOldRef\" type=\"text\" value=\"".number_format($ref,2)."\" 
			size=\"12\" maxlength=\"10\" style=\"text-align:right;border:0px;\"></td></tr>";
			print "<tr><td align=\"right\">New Amount</td><td><Input name=\"txtNewArr\"  id=\"txtNewArr\" type=\"Text\" value=\"".number_format($arr,2)."\" size=\"12\" 
			onkeyup=\"checkInput(this)\" onblur=\"addCommas(this)\" maxlength=\"10\" style=\"text-align:right;color:#00F;\"></td><td><Input name=\"txtNewRef\" 
			id=\"txtNewRef\" type=\"text\" value=\"".number_format($ref,2)."\" size=\"12\" maxlength=\"10\" onkeyup=\"checkInput(this)\" onblur=\"addCommas(this)\" 
			style=\"text-align:right;color:#00F;\"></td></tr>";
			print"<tr><td align=\"right\" valign=\"top\">Reason for Editing</td><td align=\"right\" colspan=\"2\"><textarea cols=\"40\" rows=\"4\" maxlength=\"150\" 
			name=\"txtRmks\" id=\"txtRmks\" style=\"text-transform:uppercase;\"></textarea></td></tr></table></td></tr>";
			print "<tr bgcolor=\"#eeeeee\"><td align=\"center\"><button type=\"submit\" accesskey=\"s\" name=\"CmdSave\"><u>S</u>ave Record</button></td><td 
			align=\"center\"><a href=\"alumniedit.php?admno=$admno[0]\"><button type=\"button\" accesskey=\"c\" name=\"CmdClose\">Cancel/Close</button></a></td>
			</tr></table>";
			mysqli_close($conn);
		?>
	</form>
</body>
</html>