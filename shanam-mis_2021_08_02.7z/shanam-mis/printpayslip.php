<?php
	include_once('../conn/pri_sch_connect.inc');
	include_once('../mpdf/mpdf.php');
	$dat=isset($_REQUEST['action'])?strip_tags($_REQUEST['action']):"0-0-%-%";
	$dat=preg_split("/\-/",$dat);	//0 - Month, 1 - Year, 2 - Staff Group and 3 payroll number	
	$sql="SELECT s.idno,sd.payrollno,s.pin,s.jg,date_add(dob,Interval 60 year) as dor,concat(s.surname,' ',s.onames) as st_names,s.designation,sp.paypoint,sp.bsalary,sp.housingallow1,
	sp.medicalallow1,sp.travelallow1,sp.empnssf,(sp.bsalary+sp.empnssf+sp.housingallow1+sp.medicalallow1+sp.travelallow1) AS GSal,(sp.nssffee1+sp.empnssf) as nssf,sp.nhiffee1,sp.union1,
	sp.mpr1,(sp.paye1-sp.mpr1) as taxes1,sp.advance,sp.sacco1,sp.welfare1,sp.otherlevies1,(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+sp.otherlevies1+sp.union1+
	sp.sacco1+sp.welfare1) AS TtlDed,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.empnssf+sp.travelallow1)-(sp.nssffee1+sp.empnssf+sp.nhiffee1+sp.advance+(sp.paye1-sp.mpr1)+
	sp.otherlevies1+sp.union1+sp.sacco1+sp.welfare1)) AS NetSal FROM Stf s INNER JOIN Acc_SalDef sd Using (idno) INNER JOIN Acc_SalPyt sp ON sd.payrollno=sp.payrollno WHERE (sp.sal_month 
	LIKE '$dat[0]' And sp.sal_year LIKE '$dat[1]' and s.staffgrp LIKE '$dat[2]' and sp.payrollno LIKE '$dat[3]' and sp.markdel=0) ORDER BY sp.processedon,s.surname,s.onames ASC";
	$rsSal=mysqli_query($conn,$sql); $nor=mysqli_num_rows($rsSal);
	//Get School name, address, motto and mission
	$rsSch=mysqli_query($conn,"SELECT scnm,scadd,mission,motto FROM ss"); 
	if (mysqli_num_rows($rsSch)>0) list($scnm,$scadd,$mis,$mot)=mysqli_fetch_row($rsSch); mysqli_free_result($rsSch);
	//start pdf file
	if (strcasecmp($dat[3],"%")==0) $mpdf=new mPDF('c','A4','','',10,10,12,12,10,10); else $mpdf=new mPDF('c','A5','','',10,10,12,12,10,10); 
	$mpdf->useOnlyCoreFonts = true;    // false is default
	$mpdf->SetWatermarkText("$dat[0]-$dat[1] Payslip");
	$mpdf->showWatermarkText = true;
	$mpdf->watermark_font = 'DejaVuSansCondensed';
	$mpdf->watermarkTextAlpha = 0.1;
	$mpdf->SetDisplayMode('fullpage');
	$mpdf->setFooter('Page {PAGENO} of {nbpg} Pages');
	$html='<html><head><title>'.$dat[0].' - '.$dat[1].' Payroll</title><style> 
			table.hide {border:0px;font-size:10px;font-weight:bold;} td.hide,th.hide{border:0px;}
			table.pay,td.pay{border:0px;font-weight:normal;font-size:9px;}	
			table.gen,td,th {border:1.5px dashed blue;border-collapse:collapse;}
	</style></head><body>';
	if ($nor>0):
		$i=1;
		$html.='<table class="gen" cellpadding="4" cellspacing="4">';
		while (list($id,$pr,$pin,$jg,$dor,$na,$de,$pp,$bs,$ho,$me,$tr,$empnssf,$gs,$ns,$nh,$un,$mpr,$ta,$ad,$sac,$ris,$od,$td,$net)=mysqli_fetch_row($rsSal)):
			if ($i%2==1) $html.='</tr><tr><td>'; else $html.='<td>';
			$html.='<table cellspacing="0" class="hide"><tr><td rowspan="3" valign="middle" width="80" align="center" class="hide"><img src="img/logo.png" width="60" height="65" 
			vspace="1" hspace="1"></td><td class="hide">'.$scnm.'</td></tr><tr><td class="hide">'.$scadd.'</td></tr><tr><td class="hide">'.$mot.'</td></tr><tr><td colspan="2" 
			class="hide"><hr><b style="font-size:12px;">'.$dat[0].' - '.$dat[1].'</b> PAYSLIP &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Printed On:'.date("D d-M-Y").'<hr></td></tr></table><br>';
			$html.='<table class="pay" cellpadding="2" align="center"><tr><td class="pay">Payroll No. '.$pr.' &nbsp;&nbsp;<u>'.$na.'</u></td><td class="pay">ID No. '.$id.' &nbsp;
			&nbsp;&nbsp;&nbsp;Job Group '.$jg.'</td></tr><tr><td class="pay">Designation '.$de.' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; PIN No. '.$pin.'</td><td class="pay" align="right">
			Retires On '.$dor.'</td></tr><tr><td colspan="2" align="center" class="pay" bgcolor="#eeeeee"><b>'.$pp.'</b><hr></td></tr>';
			$html.='<tr><td class="pay"><b>Basic Salary</b></td><td class="pay" align="right"><b>'.number_format($bs,2).'</b></td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;Housing Allowance</td><td class="pay" align="right">'.number_format($ho,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Medical Allowance</td><td 
			class="pay" align="right">'.number_format($me,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Overtime Earnings</td><td class="pay" align="right">'.
			number_format($tr,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Employer NSSF Contribution</td><td class="pay" align="right">'.number_format($empnssf,2).
			'</td></tr><tr><td class="pay"><b>Gross Salary</b></td><td class="pay" align="right"><b>'.number_format($gs,2).'</b></td></tr><tr><td class="pay">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;N . S . S . F</td><td class="pay" align="right">'.number_format($ns,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			N . H . I . F</td><td class="pay" align="right">'.number_format($nh,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Union Dues</td><td class="pay" 
			align="right">'.number_format($un,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PAYE Auto (MPR = '.number_format($mpr,2).')</td><td class="pay" 
			align="right">'.number_format($ta,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Salary Advance</td><td class="pay" align="right">'.number_format($ad,2).
			'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SACCO</td><td class="pay" align="right">'.number_format($sac,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;Welfare</td><td class="pay" align="right">'.number_format($ris,2).'</td></tr><tr><td class="pay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Other Deductions</td>
			<td class="pay" align="right">'.number_format($od,2).'</td></tr><tr><td class="pay"><b>Total Deductions</b></td><td class="pay" align="right"><b>'.number_format($td,2).'</b>
			</td></tr><tr><td class="pay"><b><i>Net Salary</i></b></td><td class="pay" align="right"><b><i>'.number_format($net,2).'</i></b></td></tr></table>';
			$i++;	
		endwhile;
		$html.='</tr></table>';
	else:
		$html.='No Salary Payslip for '.$dat[0].'-'.$dat[1].'-'.$dat[2];
	endif;
	$html.='</body></html>';
	mysqli_free_result($rsSal);
	$mpdf->WriteHTML($html);
	$mpdf->Output();
	mysqli_close($conn);
?>