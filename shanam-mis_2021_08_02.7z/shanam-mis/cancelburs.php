<?php
	include_once('../conn/mysqli_connect.inc.tpl');
	$buno=isset($_REQUEST['action'])?$_REQUEST['action']:'0-0';
	$buno=preg_split('/\-/',$buno);
	if($buno[0]==0){ //cancelling bursary
		mysqli_query($conn,"UPDATE acc_burs SET markdel=1,status=1 WHERE paymentno LIKE '$buno[1]'") or die(mysqli_error($conn)." Bursary cancelling failure. Click 
		<a href=\"bursary.php?action=0-0\">here</a> to go back.");
		$i=mysqli_affected_rows($conn);
		if ($i==1) mysqli_multi_query($conn,"UPDATE acc_feerec SET markdel=1,delreason='Cancelled bursary.' WHERE pytno LIKE '$buno[1]' or admno LIKE 'BURS-$buno[1]';
		UPDATE acc_miscfeepyts SET markdel=1 WHERE bursaryno LIKE '$buno[1]';");
		header("location:bursary.php?action=2-$i");
	}elseif($buno[0]==1){ //restoring deleted bursary
		mysqli_query($conn,"UPDATE acc_burs SET markdel=0,status=0 WHERE paymentno LIKE '$buno[1]'") or die(mysqli_error($conn)." Bursary restoring failure. Click 
		<a href=\"cancelledburs.php?action=0-0\">here</a> to go back.");
		$i=mysqli_affected_rows($conn);
		if ($i==1) mysqli_multi_query($conn,"UPDATE acc_feerec SET markdel=0,delreason=null WHERE pytno LIKE '$buno[1]' or admno LIKE 'BURS-$buno[1]';UPDATE 
		acc_miscfeepyts SET markdel=0 WHERE bursaryno LIKE '$buno[1]';");
		header("location:bursary.php?action=1-$i");
	}else{ //confirming delete action
		mysqli_query($conn,"UPDATE acc_burs SET markdel=2,`status`=2 WHERE paymentno LIKE '$buno[1]'") or die(mysqli_error($conn)." Bursary cancelling failure. Click 
		<a href=\"bursary.php?action=0-0\">here</a> to go back.");
		$i=mysqli_affected_rows($conn);
		if ($i==1) mysqli_multi_query($conn,"UPDATE acc_feerec SET markdel=2 WHERE pytno LIKE '$buno[1]' or admno LIKE 'BURS-$buno[1]';UPDATE acc_miscfeepyts SET 
		markdel=2 WHERE bursaryno LIKE '$buno[1]';");
		header("location:bursary.php?action=2-$i");
	}mysqli_close($conn);
?>