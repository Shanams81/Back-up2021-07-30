<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	$admno=isset($_REQUEST['admno']) ? $_REQUEST['admno']:"0-0";
	$admno=preg_split("/\-/",$admno); //$admno[1]=1 for adding/editing new form,2 for deleting. $admno[0] is admission number of student
	$rsYr=mysqli_query($conn,"SELECT finyr FROM ss"); list($finyr)=mysqli_fetch_row($rsYr); $finyr=isset($finyr)?$finyr:date("Y"); mysqli_free_result($rsYr);
	if (isset($_POST['CmdSave'])){
		$action=strip_tags($_POST['TxtAction']); $adm=strip_tags($_POST['TxtAdmNo']); $frm=$_POST['CboForm']; $str=$_POST['CboStream']; $acyr=$_POST['TxtFinYr'];
		mysqli_query($conn,"INSERT INTO form (admno,form,stream,curr_year) VALUES ('$adm','$frm','$str','$acyr')") or die(mysqli_error($conn)." Record not saved. 
		Click <a href=\"student.php?action=0-0\">Here</a> to try again!!!!");
		$i=mysqli_affected_rows($conn);
		header("location:student.php?action=$action-$i");
	}elseif(isset($_POST['CmdClose'])){
		header("location:student.php?action=0-0");
	}
?>
<!DOCTYPE html>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>Student Editor</title>
		<script language="javascript">
			function ValidateInput(myForm){
				var dat="";
				if (myForm.CboStream.value.length==0){
					dat+="You MUST select student\'s stream before saving";
				}
				if (dat==""){
					return true;
				}else{
				 	alert(dat);
					return false;
				}
			}
		</script>
    </head>
<body background="img/bg3.gif">
	<form method="post" action="studform.php" onsubmit="return ValidateInput(this);">
		<?php
			$rsSt=mysqli_query($conn,"SELECT stud_names FROM stud WHERE admno LIKE '$admno[0]'"); list($studnames)=mysqli_fetch_row($rsSt); 
			mysqli_free_result($rsSt);
			print "<input type=\"hidden\" value=\"$admno[1]\" name=\"TxtAction\">";// 0 for adding and 1 for editing
			print "<table cellpadding=\"6\" cellspacing=\"2\" style=\"left:150px;top:150px;border:1px;align:center;border-style:groove;border-collapse:collapse;\">
			<tr><th colspan=\"4\" style=\"color:#555555;Letter-spacing:2px;word-spacing:3px;\">".strtoupper($studnames)."'S FORM EDITING INTERFACE</th></tr><tr 
			bgcolor=\"#eeeeee\"><td align=\"right\">Admission No.</td><td>$admno[0]<Input name=\"TxtAdmNo\" type=\"hidden\" value=\"$admno[0]\"></td><td 
			align=\"right\">Academic Year</td><td>$finyr<Input name=\"TxtFinYr\" type=\"hidden\" value=\"$finyr\"></td></tr>";
			print "<tr><td valign=\"top\" align=\"right\">Current Form</td><td><SELECT name=\"CboForm\" size=\"4\">";
			$rsStr=mysqli_query($conn,"SELECT cls FROM grps WHERE cls is not null or cls not like ''") or die(mysqli_error($conn).' Error in database connection'); 
			if (mysqli_num_rows($rsStr)>0) while (list($cls)=mysqli_fetch_row($rsStr)) print "<option>$cls</option>";	mysqli_free_result($rsStr);
			print "</select></td><td align=\"right\" valign=\"top\">Stream</td><td><select size=\"4\" name=\"CboStream\">";
			$rsStrm=mysqli_query($conn,"SELECT strm FROM grps WHERE strm is Not Null"); 
			if (mysqli_num_rows($rsStrm)>0) while (list($strm)=mysqli_fetch_row($rsStrm)) print "<option>$strm</option>";mysqli_free_result($rsStrm); 
			print "</select></td></tr><tr  bgcolor=\"#eeeeee\"><td align=\"center\" colspan=\"2\"><button type=\"submit\" accesskey=\"s\" name=\"CmdSave\">
			<u>S</u>ave Record</button></td><td colspan=\"2\" align=\"center\"><button type=\"submit\" accesskey=\"c\" name=\"CmdClose\">Cancel/Close</button></td>
			</tr></table>";
			mysqli_close($conn);
		?>
	</form>
</body>
</html>