<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	$rsSal=mysqli_query($conn, "SELECT saladd FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'"); 	$salad=0;
	if(mysqli_num_rows($rsSal)==1) list($salad)=mysqli_fetch_row($rsSal);	mysqli_free_result($rsSal);
	if($salad==0) header("Location:vague.php");
	$salmon=isset($_POST['CboMonth'])?$_POST['CboMonth']:date('F'); 	$salyr=isset($_POST['CboYear'])?$_POST['CboYear']:date('Y');
	if (isset($_POST['CmdProcess'])) header("Location:salprocessor.php?action=0-%-$salmon-$salyr");
	if (isset($_POST['CmdIndProcess'])){
		$grp=$_POST['CboGrp'];
		$radfind=$_POST['RadFind'];		$find=isset($_POST['TxtFind'])?$_POST['TxtFind']:'%';
		$find=(strcasecmp($find,'%')==0 || strlen($find)==0)?'%':$find;
	}
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Payroll Manager</title>
</head>
<body background="img/bg3.gif">
	<?php
		print "<form name=\"FrmSal\" method=\"post\" action=\"payrollcreator.php\">Process <SELECT name=\"CboMonth\" size=\"1\">";
		$mon=date('F'); 	$yr=date('Y');
        foreach (range(1,12,1) as $i){
            $cmon=jdmonthname(gregoriantojd($i,1,$yr),CAL_MONTH_GREGORIAN_LONG);
            print "<option ".(strcasecmp($mon,$cmon)==0?"Selected":"").">$cmon</option>";
        }
        print "</SELECT> - <SELECT name=\"CboYear\" size=\"1\">";
		for ($i=($yr-1);$i<($yr+2);$i++) print "<option ".(($i==$yr)?"selected":"").">$i</option>";
		print "</SELECT> Salary <button name=\"CmdProcess\" type=\"submit\">Process Salary</button> &nbsp;&nbsp;<b>OR</b> Find a member whose
		salary is to be processed by <input type=\"radio\" value=\"payrollno\" name=\"RadFind\"/>Payroll No.&nbsp;<input type=\"radio\" value=\"idno\"
		name=\"RadFind\"/>ID No.<input type=\"radio\" value=\"st_names\" name=\"RadFind\" checked=\"checked\" />Names <input type=\"text\" size=\"15\"
		maxlength=\"15\" name=\"TxtFind\"/>&nbsp;&nbsp;<button name=\"CmdIndProcess\" type=\"submit\">Individual's Salary</button>";
		print "<hr><h3>Salary Processing Manager</h3><hr>";
		if (isset($_POST['CmdIndProcess'])){
		 	if (strcasecmp($radfind,"idno")==0) $sql="SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.designation,((sd.bsal+sd.houseallow+
			sd.medicalallow+sd.travellallow)-(sd.nssffee+sd.nhiffee+sd.otherlevies+sd.unionfee+(sd.paye-sd.mpr)+sd.welfare+sd.saccofee)) as Netsal FROM stf s Inner
			Join acc_saldef sd USING (idno) WHERE s.idno LIKE '$find' ORDER BY s.surname,s.onames ASC";
			elseif (strcasecmp($radfind,"payrollno")==0) $sql="SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.designation,((sd.bsal+
			sd.houseallow+sd.medicalallow+sd.travellallow)-(sd.nssffee+sd.nhiffee+sd.otherlevies+sd.unionfee+(sd.paye-sd.mpr)+sd.welfare+sd.saccofee)) as Netsal
			FROM stf s Inner Join acc_saldef sd USING (idno) WHERE sd.payrollno LIKE '$find' ORDER BY s.surname,s.onames ASC";
			else $sql="SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,s.designation,((sd.bsal+sd.houseallow+sd.medicalallow+sd.travellallow)
			-(sd.nssffee+sd.nhiffee+sd.otherlevies+sd.unionfee+(sd.paye-sd.mpr)+sd.welfare+sd.saccofee)) as Netsal FROM stf s Inner Join acc_saldef sd USING (idno)
			WHERE (s.surname LIKE '%$find%' or s.onames LIKE '%$find%') ORDER BY s.surname,s.onames ASC";
			$rsSal=mysqli_query($conn,$sql); $i=mysqli_num_rows($rsSal);
			print "<table border=\"1\" cellspacing=\"2\" cellpadding=\"3\"><tr bgcolor=\"#f3f3f3\"><th colspan=\"5\">Details of the Member of
			Staff</th><th rowspan=\"2\">Processing<br>Salary</th></tr><tr><th>ID No.</th><th>Payroll No.</th><th>Names</th><th>Designation</th>
			<th>Gross Salary</th></tr>";
			if ($i>0){
			 	$row=0;
				while ($data=mysqli_fetch_array($rsSal,MYSQLI_NUM)){
					if ($row%2==0) print "<tr bgcolor=\"#fcfcfc\">"; else print "<tr>";
					$a=0;
					foreach ($data as $dat){
						if ($a<4) print "<td>$dat</td>"; else print "<td>".number_format($dat,2)."</td>";
						$a++;
					}	print "<td><a href=\"salprocessor.php?action=0-$data[1]-$salmon-$salyr\">Process</a></td></tr>";	$row++;
				}
			}else{
				print "<tr><td colspan=\"6\">$i staff member(s)' details</td></tr>";
			}
			print "</table>";
		}else{
			print "<p class=\"g\"><b>Processing All Staff Members' Salaries</b></p><ol type=\"i\"><li>Select the month and year whose salary is to
			be processed,<li>Click <b>Process Salary</b> command button</ol>";
			print "<p class=\"g\"><b>Processing Individual Member's Salary</b></p><ol type=\"i\"><li>Select the month and year whose salary is to be processed,<li>
			Select the criteria to use in searching for member by either <b>Payroll No.</b>, <b>ID No.</b> or <b>Names</b>,<li>Enter the member details to search
			for in the text box and <li>Click <b>Individual's Salary</b> command button</ol>";
		}
		mysqli_close($conn);
	?>
	</form>
</body>
</html>
