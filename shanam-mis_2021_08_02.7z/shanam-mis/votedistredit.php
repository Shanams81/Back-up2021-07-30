<?php
    include_once('shanam.php');
    class Balance{private $vno,$vote,$bal; public function __construct($v,$vna,$t){$this->vno=$v;	$this->vote=$vna;	$this->bal=$t;}
      public function valVSNo(){return $this->vno;} 	public function valBal(){return $this->bal;}	public function valVName(){return $this->vote;}
    }class VoteAmt{private $vno,$amt; public function __construct($v,$a){$this->vno=$v; $this->amt=$a;} 	public function valVSNo(){return $this->vno;} 	public function valAmt(){return $this->amt;}}
    function findBal($vamt,$v){$len=count($vamt); $found=false; $amt=$a=0; while(!$found && $a<$len){if($vamt[$a]->valVSNo()==$v){$found=true; $amt=$vamt[$a]->valAmt();} $a++;} return $amt;}
    if(isset($_POST['btnSaveFee'])){
   	  $nov=isset($_POST['txtNoV'])?sanitize($_POST['txtNoV']):0;             $tkn=isset($_POST['txtToken'])?sanitize($_POST['txtToken']):'0-0-0-0';  $tkn=explode('-',$tkn);//[0]-Token,[1]-A/C,[2]-Rec No.,[3]-Admn No.
      $amt=isset($_POST['txtDistrBal'])?sanitize($_POST['txtDistrBal']):0;   $amt=preg_replace('/[^0-9\.]/','',$amt); $action=1; $recs=0; $err=$sql='';
      if($amt==0 && $tkn[0]==$_SESSION['VoteDistrTkn']){ unset($_SESSION['VoteDistrTkn']);
        $pos=isset($_POST['txtLocked'])?sanitize($_POST['txtLocked']):'-1=-1=-1=-1=-1';  $pos=explode('=',$pos); //prepos=arrpos=medpos=burspos=xtraunipos
        for($i=0;$i<$nov;$i++){
          $v=isset($_POST['txtVote_'.$i])?intval(sanitize($_POST['txtVote_'.$i])):-1; $bal=isset($_POST['txtBal_'.$i])?sanitize($_POST['txtBal_'.$i]):0; $cur=isset($_POST['txtCurr_'.$i])?sanitize($_POST['txtCurr_'.$i]):0;
          $amt=isset($_POST['txtAmt_'.$i])?sanitize($_POST['txtAmt_'.$i]):0;  $cur=preg_replace('/[^0-9\.]/','',$cur);   $amt=preg_replace('/[^0-9\.]/','',$amt); $bal=preg_replace('/[^0-9\.]/','',$bal);
          if($v>0 && ($amt<=($bal+$cur)) && $cur!=$amt){
            if($i==$pos[0] && $tkn[1]==1){//Prepayment
              if($cur==0) $sql.="INSERT INTO acc_incovotes(recno,acc,voteno,amt,markdel) VALUES ($recno,1,$v,$amt,0); INSERT INTO acc_incoprep(recno,acc,voteno,amt,markdel) VALUES ($tkn[2],1,6,$amt,0);";
              elseif($amt==0) $sql.="DELETE FROM acc_incovotes WHERE acc LIKE '$tkn[1]' and recno LIKE '$tkn[2]' and voteno LIKE '$v'; DELETE FROM acc_incoprep WHERE acc LIKE '$tkn[1]' and recno LIKE '$tkn[2]';
              DELETE FROM acc_incovotes WHERE acc LIKE '$tkn[1]' and recno LIKE '$tkn[2]' and voteno LIKE '$v';";
              else $sql.="UPDATE acc_incovotes SET amt='$amt' WHERE acc LIKE '$tkn[1]' and recno LIKE '$tkn[2]' and voteno LIKE '$v'; UPDATE acc_incoprep SET amt=$amt WHERE acc LIKE '$tkn[1]' and recno LIKE '$tkn[2]'
              and voteno=6;";
              $sql.="UPDATE acc_incorecno0 SET prep=$amt WHERE recno LIKE '$tkn[2]' and acc LIKE '$tkn[1]';";
            }else{
              if($amt==0) $sql.="DELETE FROM acc_incovotes WHERE acc LIKE '$tkn[1]' and recno LIKE '$tkn[2]' and voteno LIKE '$v';";
              elseif($cur==0) $sql.="INSERT INTO acc_incovotes(recno,acc,voteno,amt,markdel) VALUES ($tkn[2],1,$v,$amt,0);";
              else $sql.="UPDATE acc_incovotes SET amt=$amt WHERE acc LIKE '$tkn[1]' and recno LIKE '$tkn[2]' and voteno LIKE '$v';";
            }echo $sql;
          }elseif($cur!=$amt) $err.="Vote No. $v, Amount $amt and Expected".($bal+$cur).". Data error.<br>";
        }if(strlen($err)>0){$recs=0;}elseif(strlen($sql)>0) {mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"".($tkn[4]==1?"feecollection":($tkn[4]==0?"prepayments":"votedistr")).".php>HERE
          </a> to go back"); do{$recs+=mysqli_affected_rows($conn);}while(mysqli_next_result($conn));}
      }$recs=($recs>0?1:0); header("location:".($tkn[4]==1?"feecollection":($tkn[4]==0?"prepayments":"votedistr")).".php?action=$action-$recs");
    }else{
        $info=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):"0-0-0"; 	$info=preg_split('/\-/',$info); //[0] A/C, [1] receipt no,[2] admission no.[3] -0 From Prepayment,1 - from fees
        $sql="SELECT f.recno,s.stud_names,s.cls,s.lastyr,(f.amt-f.transfer) as amt FROM acc_incofee i Inner Join ".($info[0]==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join (SELECT s.admno,
        concat(s.surname,' ',s.onames) as stud_names,concat(cn.clsname,'-',c.stream) As cls,if(l.clsno=c.clsno,1,0) as lastyr FROM stud s INNER JOIN class c USING (admno,curr_year) INNER JOIN classnames cn USING (clsno)
        Inner Join classlvl l ON (c.lvlno=l.lvlno) WHERE s.admno LIKE '$info[2]')s On (i.admno=s.admno) WHERE f.recno LIKE '$info[1]'; SELECT v.voteno,v.amt,a.descr FROM acc_incovotes v Inner Join acc_voteacs a ON
        (v.acc=a.acno) WHERE a.stud_assoc=1 and v.acc like '$info[0]' and v.markdel=0 and v.recno LIKE '$info[1]'; SELECT v.sno,v.descr,if(isnull(c.t3),0,if((c.t3-if(isnull(sum(f.ttl)),0,sum(f.ttl)))<=0,0,(c.t3-
        if(isnull(sum(f.ttl)),0,sum(f.ttl))))) as bal FROM acc_votes v LEFT JOIN (SELECT * FROM clsfee WHERE admno LIKE '$info[2]')c On (v.sno=c.voteno) LEFT JOIN (SELECT i.admno,f.acc,v.voteno,sum(v.amt) as ttl FROM
        acc_incofee i Inner Join ".($info[0]==1?"acc_incorecno0":"acc_incorecno1")." f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY i.admno,f.acc,v.voteno,i.markdel HAVING markdel=0 and f.acc LIKE
        '$info[0]' and i.admno LIKE '$info[2]')f ON (v.sno=f.voteno) GROUP BY v.acc,v.markdel,v.orderno,v.sno,v.descr,v.stud_fee HAVING v.stud_fee=1 and v.acc LIKE '$info[0]' and v.markdel=0 ORDER BY v.sno ASC;";
        mysqli_multi_query($conn,$sql);	$form_token=uniqid();  	$_SESSION['form_token']=$form_token; 	$i=$nov=0;
        do{
          if($rs=mysqli_store_result($conn)){
            if ($i==0) list($recno,$name,$cls,$lyr,$amt)=mysqli_fetch_row($rs);
            elseif($i==1){$ind=0; while (list($v,$a,$de)=mysqli_fetch_row($rs)){if($ind==0) $acc=$de; $voteamt[]=new VoteAmt($v,$a); $ind++;}}
            else{$nov=mysqli_num_rows($rs); while($d=mysqli_fetch_row($rs)) $balances[]=new Balance($d[0],$d[1],$d[2]);}
            mysqli_free_result($rs);
          }$i++;
        }while(mysqli_next_result($conn)); $form_token=$_SESSION['VoteDistrTkn']=uniqid();
    }headings('<link href="/date/tcal.css" rel="stylesheet"/><link href="tpl/css/inputsettings.css" rel="stylesheet"/>',0,0,1);
?>
<div class="container divmain"><form method="post" action="votedistredit.php" name="frmFeeRecs" onsubmit="return SaveFeeRecord(this);">
  <div class="form-row"><div class="col-md-12 divheadings"><input type="hidden" name="txtNoV" id="txtNoV" size=2 value="<?php print $nov;?>"><input type="hidden" value="<?php print "$form_token-$info[0]-$info[1]-
    $info[2]-$info[3]";?>" name="txtToken" id="txtToken"><center><h4><?php print "VOTEHEAD DISTRIBUTION OF FEE RECEIPT NO. $info[1]<br><hr\>ADM. NO. ".$info[2]." <u>".$name."</u> IN GRDADE/FORM ".$cls;?></h4></center></div>
  </div><div class="form-row"><div class="col-md-6 divsubheading">VOTEHEAD</div><div class="col-md-2 divsubheading">BALANCE</div><div class="col-md-2 divsubheading">CURRENT</div><div class="col-md-2 divsubheading">
  EDITABLE</div></div>
  <?php
      $preppos=$arrpos=$medpos=$burspos=$xtraunipos=-1; $a=0; $ttl=[0,0,0];
      foreach($balances as $bal){
          $b=findBal($voteamt,$bal->valVSNo());
          if($info[0]==1){
            if(stripos($bal->valVName(),'arrear')!==false) $arrpos=$a; 	if(stripos($bal->valVName(),'surcharg')!==false) $medpos=$a; 	if(stripos($bal->valVName(),'prepa')!==false) $preppos=$a;
            if(stripos($bal->valVName(),'extra uni')!==false)$xtraunipos=$a;
            if (($arrpos==$a || $medpos==$a || $burspos==$a || $xtraunipos==$a)) $ro="readonly style=\"color:#000;background:#eee;"; else $ro="style=\"color:#00f;font-weight:bold;"; $ro.="text-align:right;\"";
          }elseif($info[0]!=1){
              if(stripos($bal->valVName(),'arrear')!==false)$arrpos=$a; if(stripos($bal->valVName(),'extra uni')!==false) $xtraunipos=$a;
              if(($arrpos==$a || $xtraunipos==$a)) $ro="readonly style=\"color:#00f;background:#eee;"; else $ro="style=\"color:#000;"; $ro.="text-align:right;\"";
          }else $ro="style=\"color:#000;\"";
          echo "<div class=\"form-row\"><div class=\"col-md-6\" style=\"border-bottom:1px dashed #fff;\">".$bal->valVName()."</div><div class=\"col-md-2\"><input type=\"hidden\" name=\"txtVote_$a\" id=\"txtVote_$a\"
          value=\"".$bal->valVSNo()."\" size=\"3\"><input type=\"text\" name=\"txtBal_$a\" id=\"txtBal_$a\" readonly class=\"modalinput numbersinput\" value=\"".number_format($bal->valBal(),2)."\"></div><div
          class=\"col-md-2\"><input type=\"text\" name=\"txtCurr_$a\" id=\"txtCurr_$a\" class=\"modalinput numbersinput\" value=\"".number_format($b,2)."\" readonly></div><div class=\"col-md-2\"><input type=\"text\"
          name=\"txtAmt_$a\" id=\"txtAmt_$a\" class=\"modalinput numbersinput\" value=\"".(($lyr===1 && $preppos===1)?"0.00\" readonly":number_format($b,2)."\"")." onchange=\"calcVotes($a)\" $ro></div></div>";	$a++;
          $ttl[0]+=$bal->valBal();  $ttl[2]+=($lyr===1 && $preppos===1)?0:$b;
      }$ttl[1]+=$amt; echo "<hr><div class=\"form-row\"><div class=\"col-md-6\"></div>"; $i=0; foreach($ttl as $tt){echo "<div class=\"col-md-2\"><input type=\"text\" name=\"txtTtl_$i\" id=\"txtTtl_$i\" readonly
      class=\"modalinput b numbersinput\" value=\"".number_format($tt,2)."\"></div>";$i++;} echo "</div><hr><div class=\"form-row\"><div class=\"col-md-9 divsubheadings\" style=\"text-align:right;\">TOTAL AMOUNT TO BE
      DISTRIBUTED</div><div class=\"col-md-3\"><input type=\"text\" name=\"txtDistrBal\" id=\"txtDistrBal\" class=\"modalinput numbersinput b\" value=\"".number_format(($amt-$ttl[2]),2)."\" readonly><input
      name=\"txtLocked\" id=\"txtLocked\" type=\"hidden\" value=\"$preppos=$arrpos=$medpos=$burspos=$xtraunipos\"></div></div>";
  ?><br><hr>
  <div class="form-row"><div class="col-md-6" style="text-align: center;"><button type="submit" name="btnSaveFee" id="CmdSave" class="btn btn-primary btn-md btn-block"><b>Save Fee Changes Made</b></button></div>
      <div class="col-md-3"></div><div class="col-md-3" style="text-align:right;"><a href="<?php echo ($info[3]==1?"feecollection":($info[3]==0?"prepayments":"votedistr"));?>.php"><button type="button" name="btnClose"
        class="btn btn-info btn-md">Close/ Cancel</button></a></div>
  </div>
</form></div>
<script type="text/javascript" src="tpl/js/votedistredit.js"></script>
<?php mysqli_close($conn); footer(); ?>
