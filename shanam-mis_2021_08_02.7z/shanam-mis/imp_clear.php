<?php
	include_once('shanam.php');
	$usn=strtoupper($_SESSION['username'].' ('.$_SESSION['priviledge'].')');
	class Balances{
		private $vno,$acno,$vname,$budg,$income,$cost;
		public function __construct($vn,$an,$na,$bu,$inc,$cos){
			$this->vno=$vn; $this->acno=$an;	$this->vname=$na; $this->budg=$bu; $this->income=$inc; $this->cost=$cos;
		}public function valVNo(){return $this->vno;}			public function valAcNo(){return $this->acno;}			public function valVName(){return $this->vname;}
		public function valBudget(){return $this->budg;}	public function valIncome(){return $this->income;}	public function valCost(){return $this->cost;}
	}
	if (isset($_POST['CmdSave'])){
		$vono=isset($_POST['txtVNo'])?sanitize($_POST['txtVNo']):1; 							$date=isset($_POST['txtDate'])?$_POST['txtDate']:date('Y-m-d'); 	$date=preg_split("/\-/",$date);
		$idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):null; 					$impno=isset($_POST['txtImp'])?sanitize($_POST['txtImp']):'0-0'; 	$impno=preg_split('/\-/',$impno);
		$payee=isset($_POST['txtPayee'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPayee']))):''; 		$tkn=sanitize($_POST['txtToken']);
		$add=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):'';	$bankac=isset($_POST['cboBankAC'])?sanitize($_POST['cboBankAC']):0;
		$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):'';					$email=isset($_POST['txtEMail'])?sanitize($_POST['txtEMail']):'';
		$pytfrm=isset($_POST['cboPytFrm'])?sanitize($_POST['cboPytFrm']):'Cash';	$cheno=isset($_POST['txtCheNo'])?sanitize($_POST['txtCheNo']):null; $cheno=strlen($cheno)>0?$cheno:null;
		$cash=isset($_POST['txtCash'])?sanitize($_POST['txtCash']):0;							$bal=isset($_POST['txtBalance'])?sanitize($_POST['txtBalance']):0;
		$cheque=isset($_POST['txtCheque'])?sanitize($_POST['txtCheque']):0;				$cash=preg_replace("/[^0-9^\.]/","",$cash);	$bankac=$bankac>0?$bankac:null;
		$cheque=preg_replace("/[^0-9^\.]/","",$cheque);														$bal=preg_replace("/[^0-9^\.]/","",$bal);		$date="$date[2]-$date[1]-$date[0]";
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtRmks'])))):'BEING PAYMENT OF ';
		if (strlen($payee)>0 && (($cash+$cheque)>0) && (strlen($rmks)>16 || strcasecmp("being payment of ",$rmks)!=0) && ($bal==0) && ($_SESSION['form_token']==$tkn) && ((strcasecmp($pytfrm,
		"cash")!=0 && $bankac>0 && strlen($cheno)>0) || (strcasecmp($pytfrm,"cash")==0)) && strlen($idno)>5) {
			$payno=0; $rs=mysqli_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno'");
			if(mysqli_num_rows($rs)>0)list($payno)=mysqli_fetch_row($rs); mysqli_free_result($rs);
			if($payno==0){//New payee
				mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,telno,address,email,addedby) VALUES (0,'$date',".var_export($payee,true).",'$idno','$telno',".var_export($add,
				true).",'$email','$usn')");
				if(mysqli_affected_rows($conn)>0) $payno=mysqli_insert_id($conn);
			}$set=false; $i=1;
			while(!$set && ($i<8)){
				if (mysqli_query($conn,"INSERT INTO acc_exp(vono,acsno,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,addedby) VALUES ('$vono',".var_export($bankac,true).",'$date',$impno[1],
				'$pytfrm',".var_export($cheno,true).",'$cash','$cheque',".var_export($rmks,true).",$payno,'$usn')") or die(mysqli_error($conn).".	Imprest surrender details were not saved. Click
				<a	href=\"imprests.php\">Here</a> to try again.</center>")) $set=true; else $vono++;
				$i++;
			}if($set){//expenditure details were saved save votehead
				$sql="UPDATE acc_imp SET vno=$vono,status=2 WHERE impno='.$impno[0].';";
				if($cash>0) $sql.="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES(0,$acc,1,curdate(),'Petty Cash Payment',$cash,2,$vono,'$usn');";
				if($cheque>0) $sql.="INSERT acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,addedby) VALUES (0,curdate(),1,$bankac,'$cheno',$cheque,'Petty Cash Payment',
				1,$vono,'$usn');";
				for ($i=1;$i<5;$i++){
					$vote=isset($_POST["cboVote_$i"])?sanitize($_POST["cboVote_$i"]):0;	$amt=isset($_POST["txtAmount_$i"])?sanitize($_POST["txtAmount_$i"]):0;
					$amt=preg_replace('/[^0-9\.]/','',$amt);
					if($vote>0 && $amt>0) $sql.="INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,$impno[1],$vote,$amt);";
				}mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Imprest votehead details were not saved. Click <a href=\"imprests.php\">Here</a> to try again.</center>");
				while(mysqli_next_result($conn)){}
				header("location:rpts/pv.php?action=$vono-3-$payno-$impno[1]");
			}
		}else{
			print "Sorry, the imprest clearance details had errors.<br>Please ensure all details are correctly entered before saving.<br>Click <a href=\"imprests.php\">here</a> to try
			again.";
		}unset($_SESSION['form_token']);
		exit(1);
	}else{
	 	$_SESSION['form_token']=$form_token=uniqid();
	 	$impno=isset($_REQUEST['impno'])?$_REQUEST['impno']:'0-0'; $impno=preg_split('/\-/',$impno);//[0] Imprest No, [1]- Account
		mysqli_multi_query($conn,"SELECT e.voteno,v.acc,v.expdescr,e.curest,if(isnull(i.inco),0,i.inco) as income,if(isnull(p.exp),0,p.exp) as cost FROM acc_fyestimates e INNER JOIN
		acc_votes v ON (e.voteno=v.sno) LEFT JOIN (SELECT acc,voteno,sum(amt) as inco FROM ".($impno[1]<3?"acc_incovotes":"acc_fsevotes")." GROUP BY markdel,acc,voteno HAVING markdel=0
		and acc LIKE '$impno[1]')i ON (e.voteno=i.voteno) LEFT JOIN (SELECT acc,voteno,sum(amt) as exp FROM acc_pytvotes GROUP BY markdel,acc,voteno HAVING markdel=0 and
		acc LIKE '$impno[1]')p ON (e.voteno=p.voteno) WHERE v.acc LIKE '$impno[1]' Order By e.voteno ASC; SELECT concat(surname,' ',onames) as st_names,s.idno,s.address,
		s.telno,s.email,i.amt,i.rmks,v.descr FROM acc_imp i INNER JOIN stf s USING (idno) INNER JOIN acc_voteacs v ON (i.acc=v.acno) WHERE i.impno LIKE '$impno[0]';SELECT max(vono)
		as vno FROM acc_exp GROUP BY acc HAVING acc LIKE '$impno[1]'; SELECT a.sno,concat(b.abbr,' - ',a.accno) as ac FROM acc_accounts a Inner Join acc_banks b ON (a.bankno=b.sno)
		WHERE a.accacc LIKE '$impno[1]';");
		$i=$vono=0; $optVotes='<option value="0" selected>Choose Votehead</option>'; $optacs='';
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){
					if(mysqli_num_rows($rs)>0) while($da=mysqli_fetch_row($rs)){
						$optVotes.="<option value=\"$da[0]\">$da[2]</option>"; $balances[]=new Balances($da[0],$da[1],$da[2],$da[3],$da[4],$da[5]);
					}
				}elseif($i==1){
					list($names,$idno,$address,$telno,$email,$impamt,$rmks,$accname)=mysqli_fetch_row($rs);
				}elseif($i==2){
					if(mysqli_num_rows($rs)>0) list($vono)=mysqli_fetch_row($rs);
				}else{
					if(mysqli_num_rows($rs)>0) while($da=mysqli_fetch_row($rs)) $optacs.="<option value=\"$da[0]\">$da[1]</option>";
				}mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn)); $vono++;
	}
	headings('<link rel="stylesheet" href="/date/tcal.css"><link rel="stylesheet" href="tpl/css/inputsettings.css">',0,0,2)
?>
<div class="container divmain"><form method="post" action="imp_clear.php" onsubmit="return validateFormOnSubmit(this);" name="FrmPettyPyts">
	<input type="hidden" name="txtToken" value="<?php echo $form_token;?>"><input type="hidden" name="txtImp" value="<?php echo "$impno[0]-$impno[1]";?>">
	<div class="form-row"><div class="col-md-12 divsubheading">DETAILS OF THE IMPREST HOLDER</div></div>
	<div class="form-row">
		<div class="col-md-4"><label for="txtVNo">Voucher No.</label><input type="text" name="txtVNo" id="txtVNo" class="modalinput" maxlength="4" readonly value="<?php echo $vono;?>"></div>
		<div class="col-md-4"><label for="txtIDNo">ID No.</label><input type="text" name="txtIDNo" id="txtIDNo" class="modalinput" maxlength="10" value="<?php echo $idno;?>"></div>
		<div class="col-md-4"><label for="txtDate">Paid On</label><INPUT name="txtDate" id="txtDate" class="tcal modalinput" maxlength="10" readonly value="<?php
		echo date('d-m-Y');?>"></div>
	</div><div class="form-row"><div class="col-md-12 divlrborder" style="background-color:#40a8c4;">
		<div class="form-row">
			<div class="col-md-8"><label for="txtPayee">Name of Payee</label><input type="text" name="txtPayee" id="txtPayee" class="modalinput" maxlength="40"
				value="<?php echo $names;?>" readonly></div>
			<div class="col-md-4"><label for="txtTelNo">Tel. No.</label><input type="text"	name="txtTelNo" id=\"txtTelNo\" class="modalinput" maxlength="13" value="<?php echo $telno;?>"
				readonly></div>
		</div><div class="form-row">
			<div class="col-md-8"><label for="txtAddress">Address of Payee</label><input type="text" name="txtAddress" id="txtAddress" class="modalinput" maxlength="75" value="<?php
			echo$address;?>"></div>
			<div class="col-md-4"><label for="txtEMail">E - Mail Address</label><input type="text"	name="txtEMail" id=\"txtEMail\" class="modalinput" maxlength="13" value="<?php echo $email;?>"
				readonly style="text-transform:lowercase;"></div>
		</div>
	</div></div>
	<div class="form-row"><div class="col-md-12 divsubheading">DETAILS OF THE IMPREST CLEARANCE</div></div>
	<div class="form-row">
		<div class="col-md-2"><label for="cboPytFrm">Paid in</label><SELECT name="cboPytFrm" id="cboPytFrm" size="1" class="modalinput" onchange="checkMode(this)"><option selected value="Cash">
			Cash</option><option value="Cheque">Cheque</option><option value="Cash+Cheque">Cash + Cheque</option></select></div>
		<div class="col-md-2"><label for="txtCheNo">Cheque No.</label><input name="txtCheNo" id="txtCheNo" class="modalinput" maxlength="7" onkeyup="checkInput(this)" value="" readonly>
		</div>
		<div class="col-md-2"><label for="cboBankAC">Debited A/C</label><SELECT name="cboBankAC" id="cboBankAC" size="1" class="modalinput" disabled><?php echo $optacs;?></SELECT></div>
		<div class="col-md-2"><label for="txtCash">Cash Amount</label><input type="text" name="txtCash" id="txtCash" class="modalinput numbersinput" maxlength="10"
		onkeyup="checkInput(this)" onChange="sumPaid()" value="<?php echo number_format($impamt,2);?>"></div>
		<div class="col-md-2"><label for="txtCheque">Cheque Amount</label><input type="text" name="txtCheque" id="txtCheque" class="modalinput numbersinput" maxlength="10" readonly
		onkeyup="checkInput(this)" onChange="sumPaid()" value="0.00"></div>
		<div class="col-md-2 divsubheading"><label for="txtCheque">Total Amount	Spend </label><input name="txtTotal" id="txtTotal" class="modalinput numbersinput modalinputdisabled"
		maxlength="10" onkeyup="checkInput(this)" readonly value="<?php echo number_format($impamt,2);?>"></div>
	</div>
	<div class="form-row">
		<div class="col-md-12"><label for="txtCash">Narration of Imprest Clearance</label><Textarea name="txtRmks" id="txtRmks" class="modalinput" rows="2" maxlength="250"><?php
		echo "BEING PAYMENT FOR ".$rmks;?></textarea></div>
	</div><div class="form-row"><div class="col-md-12 divsubheading">DETAILS OF VOTEHEAD DISTRIBUTION</div></div>
	<div class="form-row"><div class="col-md-12 divlrborder" style="background-color:#40a8c4;">
		<div class="form-row">
			<div class="col-md-3">Votehead</div><div class="col-md-2">Amount Budgeted</div><div class="col-md-2">Total Income</div><div class="col-md-2">Total Running Cost</div>
			<div class="col-md-2">Amount Available</div><div class="col-md-1">Amount</div>
		</div>
		<?php
			for ($i=1;$i<5;$i++) print "<div class=\"form-row\"><div class=\"col-md-3\"><SELECT name=\"cboVote_$i\" id=\"cboVote_$i\" size=\"1\" onChange=\"assignAmts($i)\" ".($i==1?"":
			"disabled")." class=\"modalinput\">$optVotes</SELECT></div><div class=\"col-md-2\"><input name=\"txtBudget_$i\" Id=\"txtBudget_$i\" class=\"modalinput modalinputdisabled
			numbersinput\" maxlength=\"10\" value=\"0.00\" readonly></div><div class=\"col-md-2\"><input name=\"txtIncome_$i\" Id=\"txtIncome_$i\" class=\"modalinput numbersinput
			modalinputdisabled\" maxlength=\"10\" value=\"0.00\"></div><div class=\"col-md-2\"><input name=\"txtCost_$i\" Id=\"txtCost_$i\" class=\"modalinput numbersinput modalinputdisabled\"
			maxlength=\"10\" value=\"0.00\"></div><div class=\"col-md-2\"><input name=\"txtAvailable_$i\" Id=\"txtAvailable_$i\"  class=\"modalinput numbersinput modalinputdisabled\"
			maxlength=\"10\" value=\"0.00\"></div> <div class=\"col-md-1\"><input name=\"txtAmount_$i\" Id=\"txtAmount_$i\" maxlength=\"10\" value=\"0.00\"  class=\"modalinput numbersinput\"
			onKeyUp=\"checkInput(this)\" onChange=\"checkCompute($i)\" ".($i==1?"":"disabled")."></div></div>";
		?></div></div>
	<div class="form-row">
		<div class="col-md-4"><label for="txtCosted">Amount Distributed</label><input class="numbersinput modalnoinput" name="txtCosted" Id="txtCosted" maxlength="10"
		value="0.00" readonly></div>
		<div class="col-md-4"></div>
		<div class="col-md-4"><label>Balance to be Distributed</label><input name="txtBalance" Id="txtBalance" class="numbersinput modalnoinput" maxlength="10" value="<?php
		echo number_format($impamt,2);?>" readonly></div>
	</div><br><hr>
	<div class="form-row">
		<div class="col-md-4"><button type="submit" name="CmdSave" id="CmdSave" class="btn btn-primary btn-md btn-block">Save Imprest Clearance</button></div>
		<div class="col-md-4"></div>
		<div class="col-md-4" style="text-align:right"><button type="button" name="CmdClose" onclick="window.open('imprests.php','_self')" class="btn btn-info btn-md">Close/ Cancel</button>
		</div>
	</div>
</form></div>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/impclr.js"></script>
<?php
	if(isset($balances)){
		$lst=''; $i=0;
		foreach ($balances as $bal) {
			$lst.=($i==0?'':',')."new Balances(".$bal->valVNo().",".$bal->valBudget().",".$bal->valCost().",".$bal->valIncome().",".($bal->valCost()-$bal->valIncome()).")";
			$i++;
		}echo '<script type="text/javascript">balances.push('.$lst.');</script>';
	}
	mysqli_close($conn); footer();
?>
