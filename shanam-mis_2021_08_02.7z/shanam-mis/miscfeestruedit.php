<?php
	session_start();
	if (!(isset($_SESSION['username']) || ($_SESSION['username'] != ''))) header ("Location:../index.php"); else include_once('../conn/pri_sch_connect.inc');
	if (isset($_POST['CmdSave'])){
	 	//capture data
		$dat=isset($_POST['TxtInfo'])?$_POST['TxtInfo']:"0-0-0"; 				$dat=preg_split('/\-/',$dat);
		$mid1=isset($_POST['TxtID1'])?strip_tags($_POST['TxtID1']):0; 			$mid2=isset($_POST['TxtID2'])?strip_tags($_POST['TxtID2']):0;
		$mid3=isset($_POST['TxtID3'])?strip_tags($_POST['TxtID3']):0;			$mqa1=isset($_POST['TxtQA1'])?strip_tags($_POST['TxtQA1']):0;
		$mqa2=isset($_POST['TxtQA2'])?strip_tags($_POST['TxtQA2']):0;			$mqa3=isset($_POST['TxtQA3'])?strip_tags($_POST['TxtQA3']):0;
		$mrem1=isset($_POST['TxtRem1'])?strip_tags($_POST['TxtRem1']):0; 		$mrem2=isset($_POST['TxtRem2'])?strip_tags($_POST['TxtRem2']):0;
		$mrem3=isset($_POST['TxtRem3'])?strip_tags($_POST['TxtRem3']):0;		$mht1=isset($_POST['TxtHT1'])?strip_tags($_POST['TxtHT1']):0; 
		$mht2=isset($_POST['TxtHT2'])?strip_tags($_POST['TxtHT2']):0;			$mht3=isset($_POST['TxtHT3'])?strip_tags($_POST['TxtHT3']):0;
		$grad1=isset($_POST['TxtGrad1'])?strip_tags($_POST['TxtGrad1']):0; 		$grad2=isset($_POST['TxtGrad2'])?strip_tags($_POST['TxtGrad2']):0;
		$grad3=isset($_POST['TxtGrad3'])?strip_tags($_POST['TxtGrad3']):0;		$trip1=isset($_POST['TxtTrip1'])?strip_tags($_POST['TxtTrip1']):0; 			
		$trip2=isset($_POST['TxtTrip2'])?strip_tags($_POST['TxtTrip2']):0;		$trip3=isset($_POST['TxtTrip3'])?strip_tags($_POST['TxtTrip3']):0;
		$mole1=isset($_POST['TxtMOle1'])?strip_tags($_POST['TxtMOle1']):0;		$mole2=isset($_POST['TxtMOle2'])?strip_tags($_POST['TxtMOle2']):0;
		$mole3=isset($_POST['TxtMOle3'])?strip_tags($_POST['TxtMOle3']):0;
		//remove commas
		$mid1=preg_replace('/[^0-9^\.]/','',$mid1); 	$mid2=preg_replace('/[^0-9^\.]/','',$mid2);		$mid3=preg_replace('/[^0-9^\.]/','',$mid3);
		$mqa1=preg_replace('/[^0-9^\.]/','',$mqa1); 	$mqa2=preg_replace('/[^0-9^\.]/','',$mqa2);		$mqa3=preg_replace('/[^0-9^\.]/','',$mqa3);	
		$mrem1=preg_replace('/[^0-9^\.]/','',$mrem1); 	$mrem2=preg_replace('/[^0-9^\.]/','',$mrem2);	$mrem3=preg_replace('/[^0-9^\.]/','',$mrem3);
		$mht1=preg_replace('/[^0-9^\.]/','',$mht1); 	$mht2=preg_replace('/[^0-9^\.]/','',$mht2);		$mht3=preg_replace('/[^0-9^\.]/','',$mht3);
		$grad1=preg_replace('/[^0-9^\.]/','',$grad1);	$grad2=preg_replace('/[^0-9^\.]/','',$grad2);	$grad3=preg_replace('/[^0-9^\.]/','',$grad3);
		$trip1=preg_replace('/[^0-9^\.]/','',$trip1);	$trip2=preg_replace('/[^0-9^\.]/','',$trip2);	$trip3=preg_replace('/[^0-9^\.]/','',$trip3);
		$mole1=preg_replace('/[^0-9^\.]/','',$mole1);	$mole2=preg_replace('/[^0-9^\.]/','',$mole2);	$mole3=preg_replace('/[^0-9^\.]/','',$mole3);
		//computation
		$mid2+=$mid1;	$mid3+=$mid2; 	$mqa2+=$mqa1;	$mqa3+=$mqa2;	$mrem2+=$mrem1;	$mrem3+=$mrem2;	$mht2+=$mht1;	$mht3+=$mht2;	$grad2+=$grad1;	
		$grad3+=$grad2; $trip2+=$trip1;	$trip3+=$trip2; $mole2+=$mole1;	$mole3+=$mole2; $mt1=$mid1+$mqa1+$mrem1+$mht1+$grad1+$trip1+$mole1;	
		$mt2=$mid2+$mqa2+$mrem2+$mht2+$grad2+$trip2+$mole2;	$mt3=$mid3+$mqa3+$mrem3+$mht3+$grad3+$trip3+$mole3;
		if ($mt3<1){
			print "<font color=\"#dd0000\" size=\"+2\">YOU CANNOT DEFINE A FEE STRUCTURE WHOSE TOTAL AMOUNT IS ZERO!!!!!</FONT><BR>";
		}else{
			@mysqli_query($conn,"UPDATE Acc_Feeoutline SET t1misidcard='$mid1',t1misqa='$mqa1',t1misremedial='$mrem1',t1misht='$mht1',t1misgrad='$grad1',t1mistrip='$trip1',
			t1misole='$mole1',misct1='$mt1',t2misidcard='$mid2',t2misqa='$mqa2',t2misremedial='$mrem2',t2misht='$mht2',t2misgrad='$grad2',t2mistrip='$trip2',t2misole='$mole2',
			misct2='$mt2',misidcard='$mid3',misqa='$mqa3',misremedial='$mrem3',misht='$mht3',misgrad='$grad3',mistrip='$trip3',misole='$mole1',misct3='$mt3' WHERE (curr_year LIKE 
			'$dat[0]' and feegrp LIKE '$dat[1]' and lvl LIKE '$dat[2]')") or die(mysqli_error($conn)." Fee structure not saved. Click <a href=\"feestruct.php\">here</a> to try again.");
			$i=mysqli_affected_rows($conn); header("location:feestruct.php?action=1-$i");
		}
	}else{
	 	$dat=isset($_REQUEST['adm'])?$_REQUEST['adm']:"0-0-0"; 	$dat=preg_split('/\-/',$dat);
		$rsCo=mysqli_query($conn,"SELECT t1misidcard,t1misqa,t1misremedial,t1misht,t1misgrad,t1mistrip,t1misole,misct1,(t2misidcard-t1misidcard) as id2,(t2misqa-t1misqa) as qa2,
		(t2misremedial-t1misremedial) as rem2,(t2misht-t1misht) as ht2,(t2misgrad-t1misgrad) as grd2,(t2mistrip-t1mistrip) as trip2,(t2misole-t1misole) as mole2,(misct2-misct1) as mttl2,
		(misidcard-t2misidcard) as id3,(misqa-t2misqa) as qa3,(misremedial-t2misremedial) as rem3,(misht-t2misht) as ht3,(misgrad-t2misgrad) as grad3,(mistrip-t2mistrip) as trip3,
		(misole-t2misole) as mole3,(misct3-misct2) as mttl3,misidcard,misqa,misremedial,misht,misgrad,mistrip,misole,misct3 FROM acc_feeoutline WHERE curr_year LIKE '$dat[0]' and feegrp 
		LIKE '$dat[1]' and lvl LIKE '$dat[2]'");
		//fetch fee data from database
		if (mysqli_num_rows($rsCo)>0) list($t1id,$t1qa,$t1rem,$t1ht,$t1gra,$t1trip,$t1mole,$mt1,$t2id,$t2qa,$t2rem,$t2ht,$t2gra,$t2trip,$t2mole,$mt2,$t3id,$t3qa,$t3rem,$t3ht,$t3gra,
		$t3trip,$t3mole,$mt3,$id,$qa,$rem,$ht,$mgra,$mtrip,$mole,$myt)=mysqli_fetch_row($rsCo); mysqli_free_result($rsCo);
	}	
?>
<html>
<head>
	<link href="tpl/acc.css" rel="stylesheet" type="text/css" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="img/phone.ico"/>
	<title>Fee Structure</title>
	<script type="text/javascript" src="tpl/feestruct.js"></script>
</head>
<body background="img/bg3.gif">
	<?php
		$h= "Miscelleneous Account Fees Structure Editing";
		print "<center><h2>".strtoupper($h)."</h2></center><hr>";
		print "<form method=\"post\" action=\"MiscFeeStruEdit.php\" name=\"feestruct\"><table 
		cellspacing=\"0\" cellpadding=\"4\" border=\"1\" bordercolor=\"#cccccc\" align=\"center\"><tr><td colspan=\"5\" ALIGN=\"CENTER\"><b>MISC ACCOUNT 
		FEE STRUCTURE</b></td></tr><tr><td colspan=\"11\" align=\"left\">-<br>Fee Structure Of <input type=\"hidden\" name=\"TxtInfo\" 
		value=\"$dat[0]-$dat[1]-$dat[2]\"><select name=\"CboFeeGrp\" size=\"1\" id=\"course\" disabled>";
		$cour=mysqli_query($conn,"SELECT fee FROM grps WHERE (fee is not null and fee not like '') Order BY fee ASC"); 
		if (mysqli_num_rows($cour)>0) while (list($cona)=mysqli_fetch_row($cour)) print "<option ".(strcasecmp($cona,$dat[1])==0?"selected":"").">$cona
		</option>";
		mysqli_free_result($cour);
		print "</select>&nbsp; Level &nbsp;<select name=\"CboLvl\" size=\"1\" id=\"course\" disabled><option ".(strcasecmp($dat[2],"baby sitting")==0?
		"selected":"").">Baby Sitting</option><option ".(strcasecmp($dat[2],"ecd")==0?"selected":"").">ECD</option><option ".
		(strcasecmp($dat[2],"lower primary")==0?"selected":"").
		">Lower Primary</option><option ".(strcasecmp($dat[2],"mid primary")==0?"selected":"").">Mid Primary</option><option ".(strcasecmp($dat[2],
		"Upper primary")==0?"selected":"").">Upper Primary</option></select><br>-</td></tr>";
		print "<tr bgcolor=\"#eeeeee\"><td><b>Votehead</b></td><td align=\"center\"><b>Term I</b></td><td align=\"center\"><b>Term II</b></td><td 
		align=\"center\"><b>Term III</b></td><td align=\"center\"><b>Total</b></td></tr>";
		print "<tr><td>ID Card</td><td><input name=\"TxtID1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1id,2)."\" style=\"text-align:right;\" 
		id=\"TxtMis_1_1\" onChange=\"MisCompute(1,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtID2\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t2id,2)."\" style=\"text-align:right;\" id=\"TxtMis_1_2\" onChange=\"MisCompute(1,2)\" onkeyup=\"checkInput(this)\"></td><td><input 
		name=\"TxtID3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3id,2)."\" style=\"text-align:right;\" id=\"TxtMis_1_3\" 
		onChange=\"MisCompute(1,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtID4\" maxlength=\"9\" size=\"9\" value=\"".number_format($id,2).
		"\" style=\"text-align:right;\" id=\"TxtMis_1\" disabled  class=\"bg\"></td></tr>";
		print "<tr><td>Quality Assurance</td><td><input name=\"TxtQA1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1qa,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_2_1\" onChange=\"MisCompute(2,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtQA2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2qa,2)."\" style=\"text-align:right;\" id=\"TxtMis_2_2\" onChange=\"MisCompute(2,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtQA3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3qa,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_2_3\" onChange=\"MisCompute(2,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtQA4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($qa,2)."\" style=\"text-align:right;\" id=\"TxtMis_2\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Remedial</td><td><input name=\"TxtRem1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1rem,2)."\" style=\"text-align:right;\" 
		id=\"TxtMis_3_1\" onChange=\"MisCompute(3,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRem2\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($t2rem,2)."\" style=\"text-align:right;\" id=\"TxtMis_3_2\" onChange=\"MisCompute(3,2)\" onkeyup=\"checkInput(this)\"></td><td><input 
		name=\"TxtRem3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3rem,2)."\" style=\"text-align:right;\" id=\"TxtMis_3_3\" 
		onChange=\"MisCompute(3,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtRem4\" maxlength=\"9\" size=\"9\" value=\"".number_format($rem,
		2)."\" style=\"text-align:right;\" id=\"TxtMis_3\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Holiday Tuition</td><td><input name=\"TxtHT1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1ht,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_4_1\" onChange=\"MisCompute(4,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtHT2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2ht,2)."\" style=\"text-align:right;\" id=\"TxtMis_4_2\" onChange=\"MisCompute(4,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtHT3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3ht,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_4_3\" onChange=\"MisCompute(4,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtHT4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($ht,2)."\" style=\"text-align:right;\" id=\"TxtMis_4\" disabled  class=\"bg\"></td></tr>";
		print "<tr><td>Graduation Fee</td><td><input name=\"TxtGrad1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1grad,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_5_1\" onChange=\"MisCompute(5,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtGrad2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2grad,2)."\" style=\"text-align:right;\" id=\"TxtMis_5_2\" onChange=\"MisCompute(5,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtGrad3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3grad,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_5_3\" onChange=\"MisCompute(5,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtGrad4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($grad,2)."\" style=\"text-align:right;\" id=\"TxtMis_5\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Academic Trip</td><td><input name=\"TxtTrip1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1trip,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_6_1\" onChange=\"MisCompute(6,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTrip2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2trip,2)."\" style=\"text-align:right;\" id=\"TxtMis_6_2\" onChange=\"MisCompute(6,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTrip3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3trip,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_6_3\" onChange=\"MisCompute(6,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtTrip4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($trip,2)."\" style=\"text-align:right;\" id=\"TxtMis_6\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Other Levies</td><td><input name=\"TxtMOle1\" maxlength=\"9\" size=\"9\" value=\"".number_format($t1mole,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_7_1\" onChange=\"MisCompute(7,1)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMole2\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($t2mole,2)."\" style=\"text-align:right;\" id=\"TxtMis_7_2\" onChange=\"MisCompute(7,2)\" 
		onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMOle3\" maxlength=\"9\" size=\"9\" value=\"".number_format($t3mole,2)."\" 
		style=\"text-align:right;\" id=\"TxtMis_7_3\" onChange=\"MisCompute(7,3)\" onkeyup=\"checkInput(this)\"></td><td><input name=\"TxtMole4\" 
		maxlength=\"9\" size=\"9\" value=\"".number_format($mole,2)."\" style=\"text-align:right;\" id=\"TxtMis_7\" disabled class=\"bg\"></td></tr>";
		print "<tr><td>Total Fees</td><td><input name=\"TxtMTotal1\" maxlength=\"9\" size=\"9\" value=\"".number_format($mt1,2)."\" 
		style=\"text-align:right;\" id=\"TxtMTotal1\" disabled class=\"bg\"></td><td><input name=\"TxtMTotal2\" maxlength=\"9\" size=\"9\" value=\"".
		number_format($mt2,2)."\" style=\"text-align:right;\" id=\"TxtMTotal2\" disabled class=\"bg\"></td><td><input name=\"TxtMTotal3\" maxlength=\"9\" 
		size=\"9\" value=\"".number_format($mt3,2)."\" style=\"text-align:right;\" id=\"TxtMTotal3\" disabled class=\"bg\"></td><td><input 
		name=\"TxtMTotal\" maxlength=\"9\" size=\"9\" value=\"".number_format($myt,2)."\" style=\"text-align:right;\" id=\"TxtMTotal\" disabled 
		class=\"bg\"></td></tr>";
		mysqli_close($conn);
	?></table>
	<center><button type="submit" name="CmdSave">Save Fee Structure</button>&nbsp;&nbsp;&nbsp;<a href="feestruct.php?action=0-0"><button 
	type="button" name="CmdClose">Close</button></a></form>
</body>
</html>