<?php
	declare(strict_types=1);
	include_once('shanam.php');
	$rec=isset($_REQUEST['recno'])?sanitize($_REQUEST['recno']):"0-0-0";
	$recno=explode('-',$rec);//[0]-creditor no,[1] 0- nothing,1-additing/editing,2-deleting,[2]-No.of records added/edited/deleted
	mysqli_multi_query($conn,"SELECT finyr FROM ss; SELECT name FROM acc_creditors WHERE cred_no LIKE '$recno[0]'; SELECT credadd,crededit,creddel FROM acc_priv WHERE uname LIKE '".
	$_SESSION['username']."'; SELECT acc,sno,descr FROM acc_votes WHERE markdel=0 and pyt_defined=1 ORDER BY sno ASC; SELECT acno,descr FROM acc_voteacs WHERE markdel=0 and
	pyt_assoc=1 ORDER BY descr ASC; SELECT acc,sno,expdescr FROM acc_votes WHERE markdel=0 and expabbr LIKE 'sundry' ORDER BY descr ASC;");
	$i=$canadd=$candel=$canedit=0; $optacc=$lstvotes=$lstsundry=""; echo $recno[0];
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0) list($yr)=mysqli_fetch_row($rs);
			elseif($i==1) list($credname)=mysqli_fetch_row($rs);
			elseif($i==2) list($canadd,$canedit,$candel)=mysqli_fetch_row($rs);
			elseif($i==3){ $x=0; while ($d=mysqli_fetch_row($rs)){$lstvotes.=($x==0?"":",")."new Voteheads($d[0],$d[1],'$d[2]')"; $x++;}
			}elseif($i==4) while($dac=mysqli_fetch_row($rs)) $optacc.="<option value=\"$dac[0]\">$dac[1]</option>";
			else{ $x=0; while ($d=mysqli_fetch_row($rs)){$lstsundry.=($x==0?"":",")."new Voteheads($d[0],$d[1],'$d[2]')"; $x++;}
			}mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	headings('<link href="tpl/modalfrm.css" rel="stylesheet"/><link rel="stylesheet" href="/date/tcal.css"/><link rel="stylesheet" href="tpl/css/inputsettings.css"/>',$recno[1],$recno[2],2);
?>
<div class="container" style="width:fit-content;background-color:#e6e6f6;border-radius:10px;padding:2px;"><div class="divheadings"><H4><?php echo $credname;?>'S COMMITMENTS</H4></div>
	<ul class="nav nav-tabs" id="myTabs">
	    <li class="nav-item"><a class="nav-link active" data-toggle="tab" id="commts-tab" href="#commts">COMMITMENTS</a></li>
			<li class="nav-item active"><a class="nav-link" data-toggle="tab" id="analysis-tab" href="#analysis">ANALYSIS</a></li>
			<li class="nav-item"><a class="nav-link" data-toggle="tab" id="creditor-tab" href="#creditor">CREDITOR DETAILS</a></li>
	</ul>
	<div class="tab-content" id="myTabContent">
		<div id="analysis" class="container tab-pane fade show" role="tabpanel" aria-labelledby="analysis-tab">
			<div class="form-row"><div class="col-md-5 divsubheading">COMMITMENTS</div><div class="col-md-7 divsubheading">COMMITMENT PAYMENTS</div></DIV>
			<div class="form-row"><div class="col-md-5" style="max-height:700px;overflow-y:scroll;"><table class="table table-sm table-bordered table-striped table-hover"><thead
			class="thead-dark"><tr><th>Invoice No.</th><th>Date</th><th>Year</th><th>Commitment Narration</th><th>Votehead</th><th>Estimated Cost</th><tr></thead><tbody>
			<?php
			mysqli_multi_query($conn,"SELECT c.inv_no,c.inv_date,c.yr,c.rmks,concat(a.abbr,' (',v.descr,')') as vote, c.estimatedamt FROM acc_creditorsdet c Inner Join acc_votes v ON
			(c.voteno=v.sno) Inner Join acc_voteacs a On (c.acc=a.acno) WHERE c.markdel=0 and c.cred_no LIKE '$recno[0]' ORDER BY c.yr,c.cred_no ASC; SELECT e.vono,e.pytdate,e.cheno,e.caamt,
			e.chamt,(e.caamt+e.chamt) As amt, (@ttl:=@ttl+(e.caamt+e.chamt)) as runningttl FROM acc_exp e,(select @ttl:=0)x WHERE e.commt=1 and e.expno LIKE '$recno[0]' and e.markdel=0 ORDER
			BY e.vono ASC;");	$i=0;
			do{
				if($rs=mysqli_store_result($conn)){
					if($i==0){
						$noc=mysqli_num_rows($rs); $ttl=0;
						if ($noc>0){
							while (list($cno,$cdate,$cyr,$crmks,$cvot,$camt)=mysqli_fetch_row($rs)){
								echo "<tr><td>$cno</td><td align=\"right\">".date("d-M-Y",strtotime($cdate))."</td><td>$cyr</td><td>$crmks</td><td>$cvot</td><td align=\"right\">".
								number_format(floatval($camt),2)."</td></tr>"; $ttl+=floatval($camt);
							}
						}else echo "<tr><td colspan=\"6\">No commitments have been captured for this creditor</td></tr>";
						echo "</tbody><tfoot class=\"thead-light\"><tr><th colspan=\"4\">$noc COMMITMENT(S)</th><th align=\"right\">TOTAL</th><th align=\"right\">".
						number_format(floatval($ttl),2)."</th></tr></tfoot></table></div>";
					}else{
						?><div class="col-md-7" style="max-height:700px;overflow-y:scroll;"><table class="table table-sm table-bordered table-striped table-hover"><thead class="thead-dark"><tr><td>
						Voucher No.</td><td>Date</td><td>Cheque No.</td><td>Cash</td><td>Cheque</td><td>Amt Paid</td><td>Running Total</td></tr></thead><tbody>
						<?php $nop=mysqli_num_rows($rs); $ttlp=[0,0,0];
						if ($nop>0){
							while (list($pvno,$pdate,$pchno,$pcaamt,$pchamt,$pamt,$pttl)=mysqli_fetch_row($rs)){
								echo "<tr><td>$pvno</td><td align=\"right\">".date("d-M-Y",strtotime($pdate))."</td><td>$pchno</td><td align=\"right\">".number_format(floatval($pcaamt),2)."</td><td
								align=\"right\">".number_format(floatval($pchamt),2)."</td><td align=\"right\">".number_format(floatval($pamt),2)."</td><td align=\"right\">".
								number_format(floatval($pttl),2)."</td></tr>"; 	$ttlp[0]+=floatval($pcaamt);			$ttlp[1]+=floatval($pchamt);			$ttlp[2]+=floatval($pamt);
							}
						}else echo "<tr><td colspan=7>There are no Commitment payments made</td></tr>";
						echo "</tbody><tfoot class=\"thead-light\"><tr><th colspan=\"2\">$nop PAYMENT RECORD(S)</th><th align=\"right\">TOTALS</th>";
						foreach($ttlp as $p) echo "<th align=\"right\">".number_format(floatval($p),2)."</th>"; echo "<th></th></tr></tfoot></table></div>";
					}mysqli_free_result($rs);
				}$i++;
			}while(mysqli_next_result($conn));
			?></div><div class="form-row">
				<div class="col-md-5"><b><?php echo $noc;?> Commitment(s)	&nbsp;***** &nbsp;Total Commitments <?php echo number_format(floatval($ttl),2);?></b></div>
				<div class="col-md-7"><b><?php echo $nop;?> Payment(s) ************* Total Payments <?php echo number_format(floatval($ttlp[1]),2);?></b></div>
			</div><div class="form-row">
				<div class="col-md-12 divsubheading">CREDITOR'S BALANCE AS	ON <?php echo strtoupper(date("D d M, Y"))." IS KSHS. ".number_format((floatval($ttl)-floatval($ttlp[1])),2);?></div>
			</div>
		</div>
		<div id="commts" class="tab-pane fade show active" role="tabpanel" aria-labelledby="commts-tab">
			<div class="container divmodalmain"><form method="post" action="creditorcommtadd.php" onsubmit="return validateCommt(this)" name="frmCommt">
				<div class="form-row"><div class="col-md-12 divheadings">NEW COMMITMENT DETAILS</div></div>
				<div class="form-row"><input type="hidden" name="txtType_1" id="txtType_1" value=1>
					<div class="col-md-9">
						<div class="form-row">
							<div class="col-md-3"><label for="txtCredNo_1">Creditor's Code</label><Input Name="txtCredNo_1" id="txtCredNo_1" Type="Text" readonly value="<?php echo $recno[0];?>"
								maxlength="4" class="modalinput"></div>
							<div class="col-md-3"><label for="txtLPONo_1">LPO/LSO No.</label><input name="txtLPONo_1" id="txtLPONo_1" type="text" value="" class="modalinput modalinputdisabled"
								maxlength="10"	onkeyup="checkInput(this)" readonly></div>
								<div class="col-md-3"><label for="txtInvNo_1">Invoice No.</label><Input Name="txtInvNo_1" id="txtInvNo_1" Type="Text" value="" maxlength="7" class="modalinput
									numbersinput"></div>
							<div class="col-md-3"><label for="txtDate_1">Date of Commitment</label><input name="txtDate_1" id="txtDate_1" readonly class="tcal modalinput" value="<?php
								echo date("d-m-Y");?>"></div>
						</div><div class="form-row">
							<div class="col-md-3"><label for="txtYr_1">Year of Credit</label><input type="text" name="txtYr_1" id="txtYr_1" value="<?php echo $yr;?>" class="modalinput"
									maxlength="4"	onkeyup="checkInput(this)"></div>
							<div class="col-md-4"><label for="cboAC_1">Commitment Account</label><SELECT name="cboAC_1" id="cboAC_1" onchange="fillVotes(this,<?php echo $yr;?>)" size="1"
								class="modalinput"><option value=0>Choose Account</option><?php echo $optacc;?></SELECT></div>
							<div class="col-md-5"><label for="cboVote_1">Votehead Costed</label><SELECT name="cboVote_1" id="cboVote_1" size="1" onblur="voteSelected(<?php echo $canadd;?>)"
								class="modalinput"><option	value="0">Choose Votehead</option></SELECT></div>
						</div><div class="form-row">
							<div class="col-md-9"><label for="txtRmks_1">Commitment Narration</label><TextArea name="txtRmks_1" id="txtRmks_1" type="text" class="modalinput" rows="2" maxlength="250"
								placeholder="AUTOMATION OF ACCOUNT AND INSTALLATION OF LAN SERVICES"></textarea></div>
							<div class="col-md-3"><label for="txtAmount_1">Commitment Amount</label><input name="txtAmount_1" id="txtAmount_1" class="modalinput numbersinput" maxlength="11" value="0.00"
								onkeyup=\"checkInput(this)\" onblur=\"formatnumber(this)\"></div>
						</div>
					</div>
					<div class="col-md-3">
						<br><br><br>
						<div class="form-row"><div class="col-md-12"><button type="submit" accesskey="s" name="cmdSave_1" class="btn btn-block btn-lg btn-warning" id="cmdSave_1" disabled>
							Save<br>Commitment</button></div></div>
					</div>
				</div></form>
			</div>
			<div class="form-row"><div class="col-md-12" style="max-height:300px;overflow-y:scroll;">
				<table class="table table-hover table-bordered table-striped table-sm"><thead class="thead-dark"><tr><th colspan="5">COMMITMENT DETAILS</th><th colspan="3">
					AMOUNTS (KSHS.)</th><th rowspan="2">ADMIN<br>ACTION</th></tr><tr><th>Invoice No.</th><th>LPO No.</th><th>Registered On</th><th>Commitment Account</th><th>LPO/ LSO Narration
					</th><th>Estimate</th><th>Paid</th><th>Balance</th></tr></thead><tbody>
					<?php
					$rslpo=mysqli_query($conn,"SELECT c.detno,c.inv_no,c.lpono,c.inv_date,concat(a.abbr,' - ',v.descr) as vot,c.rmks,c.estimatedamt,(c.estimatedamt-c.amt) as paid,c.amt FROM
					acc_creditorsdet c Inner JOIN acc_votes v on (c.voteno=v.sno) Inner Join acc_voteacs a On (c.acc=a.acno) WHERE c.markdel=0 and c.cred_no LIKE '$recno[0]' ORDER BY c.yr,
					c.detno desc");		$ttlp=[0,0,0];	$bal=0; $nor=mysqli_num_rows($rslpo);
					if ($nor>0)	{
						while ($dat=mysqli_fetch_row($rslpo)){
							print "<tr><td>$dat[1]</td><td>$dat[2]</td><td>".date("d M Y",strtotime($dat[3]))."</td><td>$dat[4]</td><td>$dat[5]</td><td align=\"right\">".
							number_format(floatval($dat[6]),2)."</td><td align=\"right\">".number_format(floatval($dat[7]),2)."</td><td align=\"right\">".number_format(floatval($dat[8]),2)."</td>";
							$ttlp[0]+=$dat[6]; $ttlp[1]+=$dat[7];$ttlp[2]+=$dat[8]; $nod=(strtotime(date('Y-m-d'))-strtotime($dat[3]))/86400;
							print "<td align=\"center\" class=\"dat\">".(($dat[7]==0 && $nod<7 && $canedit==1)?"<a href=\"creditorcomtedit.php?rec=$dat[0]\" onclick=\"return canedit($canedit);\">
							Edit</a>":"")."</td></tr>";
						}
					}else  print"<tr><td colspan=\"9\" class=\"dat\">.<br>-------------NO LPO/LSO INFORMATION IS AVAILABLE---------------<br>.</td></tr>";
					?></tbody><tfoot class="thead-light"><tr><th colspan="4"><?php echo $nor;?> Creditor's LPO/LSO Details</th><th align="right">Total Amount Kshs.</th>
						<?php foreach($ttlp as $p) echo "<th align=\"right\">".number_format($p,2)."</th>";?><th></th></tr></table>
					</div>
			</div>
		</div>
		<div id="creditor" class="tab-pane fade show" role="tabpanel" aria-labelledby="creditor-tab">
			<div class="container divmodalmain"><form method="post" action="creditorcommtadd.php" onsubmit="return validateCreditor(this)" name="frmCreditor">
				<div class="form-row"><div class="col-md-12 divheadings"><br>DETAILS OF THE CREDITORS<br><input type="hidden" name="txtDat"	value="1-<?php echo $recno[0];?>"></div></div>
				<?php
				$rs=mysqli_query($conn,"SELECT c.supid,c.yr,c.idno,c.name,c.telno,c.paddress,c.email,c.regdate, if(isnull(d.noc),0,d.noc) as noco FROM acc_creditors c LEFT JOIN (SELECT cred_no,
				count(cred_no) as noc FROM acc_creditorsdet GROUP BY cred_no,markdel HAVING markdel=0 and cred_no='$recno[0]') d USING (cred_no) WHERE cred_no LIKE '$recno[0]'");
				list($supid,$cyr,$idno,$name,$telno,$padd,$email,$regdate,$nocommt)=mysqli_fetch_row($rs); mysqli_free_result($rs);
				?><div class="form-row">
					<div class="col-md-4"><label for="txtCredNo">Creditor's Code</label><Input Name="txtCredNo" id="txtCredNo" Type="Text" readonly value="<?php echo $recno[0];?>" maxlength="4"
						class="modalinput"></div>
					<div class="col-md-4"><label for="txtIDNo">Creditor's ID No.</label><input name="txtIDNo" id="txtIDNo" type="text" value="<?php echo $idno;?>" maxlength="10"
						onkeyup="checkInput(this)" class="modalinput"></div>
					<div class="col-md-4"><label for="txtDate">Registered On</label><input name="txtDate" id="txtDate" readonly class="tcal modalinput" value="<?php echo date("d-m-Y",
						strtotime($regdate));?>"></div>
				</div><div class="form-row">
					<div class="col-md-12"><label for="txtName">Name of Supplier</label><input name="txtName" id="txtName" type="text" class="modalinput" maxlength="30" value="<?php echo $name;?>">
					</div>
				</div><div class="form-row">
					<div class="col-md-6"><label for="txtAddress">Postal Address</label><input name="txtAddress" id="txtAddress" type="text" class="modalinput" maxlength="35"
						value="<?php echo $padd;?>"></div>
						<div class="col-md-6"><label for="txtEMail">E-Mail Address</label><input name="txtEMail" id="txtEMail" type="text" class="modalinput" maxlength="35"
							value="<?php echo $email;?>" style="text-transform:lowercase;" placeholder="someone@website.com"></div>
				</div><div class="form-row">
					<div class="col-md-4"><label for="txtTelNo">Telephone No.</label><input name="txtTelNo" id="txtTelNo" type="text" class="modalinput" maxlength="13"
						value="<?php echo $telno;?>"></div>
					 <div class="col-md-4"><label for="txtTelNo">Supplier Code </label><input name="txtSupCode" id="txtSupCode" type="text" class="modalinput" maxlength="4" readonly
						 value="<?php echo $supid;?>" ></div>
					 <div class="col-md-4"><label for="txtTelNo">Year of Registration</label><Input Name="txtYr" id="txtYr" Type="Text" value="<?php echo $cyr;?>" class="modalinput"
						 maxlength="4" onkeyup="checkInput(this)"></div>
				</div><hr><br>
				<div class="form-row">
					<div class="col-md-4"><button type="submit" accesskey="s" name="cmdSave" class="btn btn-primary btn-md btn-block">Save Changes</button></div>
					<div class="col-md-4" style="text-align:right;"><?php echo (($candel==1 && $nocommt==0)?"<button type=\"button\" name=\"cmdDel\" class=\"btn btn-info btn-md\"
					onclick=\"candel($candel,$nocommt)\">Delete Creditor</button>":"");?></div>
					<div class="col-md-4"></div>
				</div><br><hr></form>
			</div>
		</div>
	</div><div class="form-row"><div class="col-md-12" style="text-align:right;"><button type="button" class="btn btn-md btn-info" onclick="window.open('creditors.php','_self')"
		name="btnCloseFrm" >Close Interface</button></div>
	</div>
</div>
<div id="divDelRmks" class="modal">
	<div class="container divmodalmain"><span class="close" onclick="document.querySelector('#divDelRmks').style.display='none'">&times;</span><form method="post"
		action="creditorcommtadd.php" onsubmit="return validateCredDel(this,4);"><br>
		<div class="form-row"><div class="col-md-12 divheadings"><hr>DELETION OF CREDITORS INTERFACE<hr><input name="txtData_1" type="hidden" value="<?php echo "$recno[0]-$nocommt";?>">
			</div>
		</div><div class="form-row">
			<div class="col-md-12"><h6><?php echo "$name Tel No .$telno";?></h6></div>
		</div><div class="form-row">
			<div class="col-md-12"><label for="txtDelReason">Narration for Deleting</label><textarea name="txtDelReason" id="txtDelReason" class="modalinput" rows="3" maxlength="150"></textarea>
			</div>
		</div>
		<div class="form-row">
			<div class="col-md-6"><button name="cmdDelCred" id="cmdDelCred" disabled class="btn btn-primary btn-md btn-block">Delete Creditor</button></div>
			<div class="col-md-6" style="text-align:right;"><button name="btnClose" class="btn btn-info btn-md" onclick="document.querySelector('#divDelRmks').style.display='none'" id="btnClose"
				type="button">Cancel/ Close</button></div>
		</div></form>
	</div>
</div>
<script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/creditors.js"></script>
<script type="text/javascript" src="tpl/js/creditorsummary.js"></script>
<script type="text/javascript">
	thevotes.push(<? echo $lstvotes;?>);
	thesundry.push(<? echo $lstsundry;?>);
</script>
<?php mysqli_close($conn); footer();?>
