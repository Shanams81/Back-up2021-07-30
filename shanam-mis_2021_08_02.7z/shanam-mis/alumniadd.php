<?php
	include_once('shanam.php');
	if (isset($_POST['CmdSave'])){
            $admno=strlen(trim($_POST['txtAdmNo']))>0?sanitize($_POST['txtAdmNo']):'';			$birthno=isset($_POST['txtBirthNo'])?sanitize($_POST['txtBirthNo']):'xxxxx';
            $nemisno=isset($_POST['txtNEMISNo'])?sanitize($_POST['txtNEMISNo']):''; 				$birthno=strlen($birthno)==0?'00000':$birthno; $nemisno=strlen($nemisno)==0?null:$nemisno;
            $dob=sanitize($_POST['cboYr'])."-".sanitize($_POST['cboMon'])."-".sanitize($_POST['cboDays']);
            $surname=isset($_POST['txtSurname'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtSurname']))):'';
            $onames=isset($_POST['txtONames'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtONames']))):'';
            $admda=isset($_POST['dtpAdmDate'])?sanitize($_POST['dtpAdmDate']):date('d-m-Y','-1500 days'); 	$admda=preg_split("/\-/",$admda);  	$admdate=$admda[2].'-'.$admda[1].'-'.$admda[0];
            $lvl=isset($_POST['cboLevel'])?sanitize($_POST['cboLevel']):0; 									$form=isset($_POST['cboForm'])?sanitize($_POST['cboForm']):0;
            $strm=isset($_POST['cboStream'])?strtoupper(sanitize($_POST['cboStream'])):''; 	$acyr=isset($_POST['txtAcYr'])?sanitize($_POST['txtAcYr']):(date('Y')-1);
            $guard=isset($_POST['txtGuardian'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtGuardian']))):'xxxxxxxxx';
            $relation=isset($_POST['cboRelation'])?strtoupper(sanitize($_POST['cboRelation'])):'FATHER';	$ref=isset($_POST['txtRef'])?sanitize($_POST['txtRef']):0;
            $address=isset($_POST['txtPAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPAddress']))):'P.O Box xxxx';
            $telno=isset($_POST['txtTelNo'])?trim(strip_tags($_POST['txtTelNo'])):null;	 						$arr=isset($_POST['txtArrears'])?trim(strip_tags($_POST['txtArrears'])):0;
            $loc=isset($_POST['txtLocation'])?strtoupper(sanitize($_POST['txtLocation'])):'xxxxxx';	$sloc=isset($_POST['txtSubLocation'])?strtoupper(sanitize($_POST['txtSubLocation'])):'xxxxx';
            $vil=isset($_POST['txtVillage'])?strtoupper(sanitize($_POST['txtVillage'])):'xxxxxxx';	$occup=isset($_POST['cboOccup'])?strtoupper(sanitize($_POST['cboOccup'])):'xxxxxxx';
            $county=isset($_POST['cboCounty'])?strtoupper(sanitize($_POST['cboCounty'])):'001';	$const=isset($_POST['cboConst'])?strtoupper(sanitize($_POST['cboConst'])):'001';
            $ward=isset($_POST['cboWard'])?strtoupper(sanitize($_POST['cboWard'])):'0001';			$un=$_SESSION['username']." (".$_SESSION['priviledge'].")";
            $regdon=date("Y-m-d H:n:s");			$arr=preg_replace("/[^0-9^\.]/","",$arr);					$ref=preg_replace("/[^0-9^\.]/","",$ref);
            if(strlen($surname)==0 || strlen($onames)==0 || strlen($admno)==0 || ($arr>0 && $ref>0) || strlen($county)==0 || strlen($const)==0 || strlen($ward)==0 || $lvl==0 || $form==0 ||
            strlen($strm)==0){
                print "SERVER ERROR <font color=\"#cc0000\">Ensure student's admission number, names,level, form, stream, home details, fee arrears and refund fields are validly entered before
                trying to saving</font>. Click <a href=\"alumni.php\">HERE</a> to go back<br>";				exit(0);
            }else{
                mysqli_autocommit($conn,FALSE);	$i=0;
                if (mysqli_query($conn,"INSERT INTO stud (admno,nemisno,surname,onames,address,telno,guardian,occupation,relation,admdate,dob,addedby,curr_year,regdon,birthcertno,present,	markdel,type,
                countyno,constituencyno,wardno,location,sublocation,village) VALUES ('$admno',".var_export($nemisno,true).",'$surname','$onames','$address',".var_export($telno,true).",".
                var_export($guard,true).",'$occup','$relation','$admdate','$dob','$un','$acyr','$regdon','$birthno',0,0,1,'$county','$const','$wardno','$loc','$sloc','$vil')")===TRUE){
                    //$admno=mysqli_insert_id($conn);
                    mysqli_query($conn,"INSERT INTO class (admno,curr_year,clsno,stream,lvlno,alumniarrears,alumniref) VALUES('$admno','$acyr','$form','$strm','$lvl','$arr','$ref')") or
                    die("Student of Admission No. $admno form's details were not saved. Click <a href=\"alumni.php?action=0-0\">HERE</a> to go back.");
                    $i=mysqli_affected_rows($conn);
                    if ($i==0) mysqli_query($conn,"DELETE FROM stud WHERE admno LIKE '$admno'"); //delete if form details not saved
                }if (!mysqli_commit($conn)){}    header("location:alumni.php?action=1-$i"); exit(0);
            }
	} $act=isset($_REQUEST['admno'])?sanitize($_REQUEST['admno']):'0-0'; $act=preg_split('/\-/',$act);	//[0] 0-New, 1-Editing, [1]-AdmNo
	if($act[0]==1){//Editing alumniref
            mysqli_multi_query($conn,"SELECT s.admno,s.nemisno,s.surname,s.onames,s.address,s.telno,s.guardian,s.occupation,s.relation,s.admdate,s.dob,s.curr_year,s.birthcertno,s.countyno,
            s.constituencyno,s.wardno,s.location,s.sublocation,s.village,f.clsno,f.stream,f.lvlno,f.alumniarrears,f.alumniref FROM stud s Inner Join class f USING (admno, curr_year) WHERE s.admno
            LIKE '$act[1]'; SELECT arrrefedit from acc_priv WHERE uname LIKE '".$_SESSION['username']."';"); $i=0;
            do{
                if($rs=mysqli_store_result($conn)){
                    if($i==0) list($admno,$nemisno,$surname,$onames,$address,$telno,$guard,$occup,$relation,$admdate,$dob,$acyr,$birthno,$county,$const,$ward,$loc,$sloc,$vil,$clsno,$stream,$lvlno,$arrears,
                    $refunds)=mysqli_fetch_row($rs);
                    else list($yes)=mysqli_fetch_row($rs);
                    mysqli_free_result($rs);
                }$i++;
            }while(mysqli_next_result($conn));
	}else{
            $admno=''; $nemisno=''; $surname=''; $onames=''; $address=''; $telno=''; $guard=''; $occup='FARMER'; $relation='FATHER';$admdate=date("d-m-Y",strtotime((date('Y')-5).'-02-01'));
            $dob=(date('Y')-12).'-12-31'; $acyr=date('Y')-1; $birthno=''; $loc='xxxxxx'; $sloc='xxxxxx'; $vil='xxxxxxx'; $lvlno=1; $clsno=1; $stream=''; $arrears=0;	$refunds=0;	$yes=0;
	} $dob=preg_split('/\-/',$dob);
	headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css" />',0,0,1);
	mysqli_multi_query($conn,"SELECT county,constituency,ward FROM ss; SELECT code,name FROM county ORDER BY name ASC; SELECT code,name,codecounty FROM constituency ORDER BY codecounty,
	name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC; SELECT code,name,codeconst FROM ward ORDER BY codeconst,name ASC;"); $i=0; $optCounty=$optMP=$optMCA='';
	do{
            if($rs=mysqli_store_result($conn)){
                if($i==0){
                    if ($act[0]==0 && mysqli_num_rows($rs)>0)	list($county,$const,$ward)=mysqli_fetch_row($rs);elseif($act[0]==0 && mysqli_num_rows($rs)==0){	$county=$const='001'; $ward='0001';}
                }if($i==1) while (list($s,$n)=mysqli_fetch_row($rs)) $optCounty.="<option ".($county==$s?"selected":"")." value=\"$s\">$n</option>";
                elseif($i==2){ $mp=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
                    $mp.=($a==0?"":",")."new Consti(\"$s\",\"$n\",\"$c\")"; if($county==$c) $optMP.="<option ".($const==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
                }else{ $mca=''; $a=0; while (list($s,$n,$c)=mysqli_fetch_row($rs)){
                    $mca.=($a==0?"":",")."new MCA(\"$s\",\"$n\",\"$c\")"; if($c==$const) $optMCA.="<option ".($ward==$s?"selected":"")." value=\"$s\">$n</option>"; $a++;}
                }mysqli_free_result($rs);
            }$i++;
	}while(mysqli_next_result($conn));
?>
<form method="post" action="alumniadd.php" onsubmit="return validateFormOnSubmit(this);">
<div class="container" style="background-color:#eee;margin:auto;border-radius:10px;padding:5px;max-width:900px;"><div class="form-row"><div class="col-md-12" style="background-color:#000;
color:#fff;letter-spacing:4px;word-spacing:5px;">PERSONAL DETAILS OF ALUMNI</div></div>
    <div class="form-row"><div class="col-md-2"><label for="txtAdmNo">Admission No.</label><input type="text" name="txtAdmNo" id="txtAdmNo" maxlength="5" value="<?php echo $admno; ?>" required></div>
        <div class="col-md-2"><label for="txtNEMISNo">NEMIS No. </label><input type="text" name="txtNEMISNo" id="txtNEMISNo" maxlength="5" value="<?php echo $nemisno; ?>" placeholder="A0001"></div>
        <div class="col-md-3"><label for="txtBirthNo">Birth Certificate No.</label><Input type="text" name="txtBirthNo" id="txtBirthNo" maxlength="10" value="<?php echo $birthno; ?>"></div>
        <div class="col-md-5"><label for="cboYr">Date of Birth</label><div class="controls form-inline"><SELECT name="cboYr" id="cboYr" size="1" onchange="filldays('cboDays')" class="col-md-3">
        <?php $a=$dob[0]+3; for($i=$a; $i>($a-30);$i--) print "<option ".($dob[0]==$i?"selected":"").">$i</option>"; ?>
        </SELECT>-<SELECT name="cboMon" size="1" id="cboMon" onchange="filldays('cboDays')" class="col-md-5">
        <OPTION value="01" <?php echo ($dob[1]=='01'?'SELECTED':'');?>>January</OPTION><OPTION value="02" <?php echo ($dob[1]=='02'?'SELECTED':'');?>>February</OPTION><OPTION value="03"
        <?php echo ($dob[1]=='03'?'SELECTED':'');?>>March</OPTION><OPTION value="04" <?php echo ($dob[1]=='04'?'SELECTED':'');?>>April</OPTION><OPTION value="05" <?php echo ($dob[1]=='05'?
        'SELECTED':'');?>>May</OPTION><OPTION	value="06" <?php echo ($dob[1]=='06'?'SELECTED':'');?>>June</OPTION><OPTION value="07" <?php echo ($dob[1]=='07'?'SELECTED':'');?>>July</OPTION>
        <OPTION value="08" <?php echo ($dob[1]=='08'?'SELECTED':'');?>>August</OPTION><OPTION value="09" <?php echo ($dob[1]=='09'?'SELECTED':'');?>>September</OPTION><OPTION value="10"
        <?php echo ($dob[1]=='10'?'SELECTED':'');?>>October</OPTION><OPTION value="11" <?php echo ($dob[1]=='11'?'SELECTED':'');?>>November</OPTION><OPTION value="12"
        <?php echo ($dob[1]=='12'?'SELECTED':'');?>>December</OPTION></SELECT>-<SELECT name="cboDays" size="1" id="cboDays" class="col-md-3">
        <?php
            $a=date('t',strtotime($dob[0].'-'.$dob[1].'-01'));
            for($i=$a;$i>0;$i--) print "<option ".(($dob[2]==$i)?"selected":"").">$i</option>";
        ?></SELECT></div></div>
    </div><div class="form-row">
        <div class="col-md-3"><label for="txtSurname">Surname *</label><input type="text" name="txtSurname" id="txtSurname" value="<?php echo $surname; ?>" maxlength="12" placeholder="Surname" required></div>
        <div class="col-md-6"><label for="txtONames">Other Names *</label><input type="text" name="txtONames" id="txtONames" value="<?php echo $onames; ?>" maxlength="30" placeholder="Other Names" required></div>
        <div class="col-md-3"><label for="dtpAdmDate">Admitted On</label><input type="text" name="dtpAdmDate" id="dtpAdmDate" class="tcal" readonly <?php
        print "value=\"".$admdate."\"";?>></div>
    </div><div class="form-row">
        <div class="col-md-12" style="background-color:#000;color:#fff;	letter-spacing:4px;word-spacing:5px;">FORM AND STREAM DETAILS</DIV>
    </div><div class="form-row">
        <div class="col-md-3"><label for="cboLevel">Level *</level><SELECT name="cboLevel" id="cboLevel" size="4" onchange="loadClasses(this)" required>
        <?php
            mysqli_multi_query($conn,"SELECT lvlno,lvlname FROM classlvl ORDER BY lvlno; SELECT clsno,clsname FROM classnames WHERE lvlno LIKE '$lvlno' ORDER BY clsno; SELECT strm FROM
            grps WHERE strm is not null;") or die(mysqli_error($conn).' Error in database connection'); $i=0;
            do{
                if($rs=mysqli_store_result($conn)){
                    if($i==0){
                        if (mysqli_num_rows($rs)>0) while (list($lvl,$lvlname)=mysqli_fetch_row($rs)) echo "<option value=\"$lvl\" ".($lvlno==$lvl?"SELECTED":"").">$lvlname</option>";
                        echo '</SELECT></div>';
                    }elseif($i==1){
                        print'<div class="col-md-3"><label for="cboForm">Class/ Form *</level><span id="clsNames"><SELECT name="cboForm" id="cboForm" size="4" required>';
                        $a=0; if (mysqli_num_rows($rs)>0) while (list($cls,$clsname)=mysqli_fetch_row($rs)){
                            echo "<option ".($a==0?"selected":"")." value=\"$cls\" ".($clsno==$cls?"selected":"").">$clsname</option>";	$a++;
                        }echo '</SELECT></span></div>';
                    }else{
                        echo '<div class="col-md-3"><label for="cboStream">Stream *</level><SELECT name="cboStream" id="cboStream" size="4" required>';
                        if (mysqli_num_rows($rs)>0) while (list($strm)=mysqli_fetch_row($rs)) echo "<option value=\"$strm\" ".(strcasecmp($strm,$stream)==0?"selected":"").">$strm</option>";
                        echo "</SELECT></div>";
                    }	mysqli_free_result($rs);
                }$i++;
            }while(mysqli_next_result($conn));
            print '<div class="col-md-3"><label for="txtAcYr">Academic Year *</label><INPUT name="txtAcYr" id="txtAcYr"	type="text" value="'.$acyr.'" required></div>';
        ?>
    </DIV><div class="form-row">
        <div class="col-md-12" style="background-color:#000;color:#fff;letter-spacing:4px;word-spacing:5px;">PARENT/GUARDIAN AND CONTACT DETAILS</DIV>
    </DIV><div class="form-row">
        <div class="col-md-7"><label for="txtGuardian">Name of Parent/Guardian</LABEL><input type="text" maxlength="30" name="txtGuardian"  id="txtGuardian" style="text-transform:uppercase;"
        value="<?php echo $guard; ?>" placeholder="Names of Parent"></DIV>
        <div class="col-md-3"><label for="cboOccup">Occupation *</label><SELECT name="cboOccup" id="cboOccup" size="1"><option value="Accountant" <?php echo (strcasecmp("Accountant",
        $occup)==0?"Selected":"");?>>Accountant<option value="Administrator" <?php echo (strcasecmp("Administrator",$occup)==0?"Selected":"");?>>Administrator</option><option value="Banker"
        <?php echo (strcasecmp("Banker",$occup)==0?"Selected":"");?>>Banker</option><option value="Businessman" <?php echo (strcasecmp("Businessman",$occup)==0?"Selected":"");?>>Businessman
        </option><option value="Civil Servant" <?php echo (strcasecmp("civil servant",$occup)==0?"Selected":"");?>>Civil Servant</option><option value="Doctor" <?php echo (strcasecmp("Doctor",
        $occup)==0?"Selected":"");?>>Doctor</option><option value="driver" <?php echo (strcasecmp("driver",$occup)==0?"Selected":"");?>>Driver</option><option value="engineer" <?php
        echo (strcasecmp("engineer",$occup)==0?"Selected":"");?>>Engineer</option><option value="farmer" <?php echo (strcasecmp("farmer",$occup)==0?"Selected":"");?>>Farmer</option>
        <option value="manager" <?php echo (strcasecmp("manager",$occup)==0?"Selected":"");?>>Manager</option><option value="nurse" <?php echo (strcasecmp("nurse",$occup)==0?"Selected":"");?>>
        Nurse</option><option value="politician" <?php echo (strcasecmp("politician",$occup)==0?"Selected":"");?>>Politician</option><option value="secretary" <?php echo (strcasecmp("secretary",
        $occup)==0?"Selected":"");?>>Secretary</option><optionvalue="self-employed" <?php echo (strcasecmp("self-employed",$occup)==0?"Selected":"");?>>Self Employed</option><option value="teacher"
        <?php echo (strcasecmp("teacher",$occup)==0?"Selected":"");?>>Teacher</option><option value="Technician" <?php echo (strcasecmp("Technician",$occup)==0?"Selected":"");?>>
        Technician</option></select></div>
        <div class="col-md-2"><label for="cboRelation">Relationship</label><SELECT name="cboRelation" id="cboRelation" size="1"><option value="father" <?php echo (strcasecmp("father",$relation)==0?
        "Selected":"");?>>Father</option><option value="mother" <?php echo (strcasecmp("mother",$relation)==0?"Selected":"");?>>Mother</option><option value="brother" <?php echo (strcasecmp("brother",
        $relation)==0?"Selected":"");?>>Brother</option><option value="sister" <?php echo (strcasecmp("sister",$relation)==0?"Selected":"");?>>Sister</option><option value="Uncle" <?php echo
        (strcasecmp("uncle",$relation)==0?"Selected":"");?>>Uncle</option><option value="aunt" <?php echo (strcasecmp("aunt",$relation)==0?"Selected":"");?>>Aunt</option><option value="in-law"
        <?php echo (strcasecmp("in-law",$relation)==0?"Selected":"");?>>In-law</option><option  value="Other" <?php echo (strcasecmp("Other",$relation)==0?"Selected":"");?>>Other</option>
    </SELECT></div>
    </div><div class="form-row">
        <div class="col-md-7"><label for="txtPAddress">Postal Address</label><input type="text" maxlength="35" name="txtPAddress" id="txtPAddress" value="<?php echo $address; ?>"></div>
        <div class="col-md-5"><label for="txtTelNo">Tel No.</label><input type="text" maxlength="13" name="txtTelNo" id="txtTelNo" value="<?php echo $telno; ?>" onkeyup="checkData(this,1)"></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="cboCounty">Home County *</label><SELECT name="cboCounty" id="cboCounty" size="1" required onChange="loadConstituency(this)">
        <?php echo $optCounty; ?></SELECT></div>
        <div class="col-md-4"><label for="cboConst">Constituency *</label><SELECT name="cboConst" id="cboConst" size="1" onChange="loadWards(this)" required><?php echo $optMP; ?></SELECT></div>
        <div class="col-md-4"><label for="cboWard">County Ward *</label><SELECT name="cboWard" id="cboWard" size="1" required><?php echo $optMCA; ?></SELECT></div>
    </div><div class="form-row">
    <div class="col-md-4"><label for="txtLocation">Home Location</label><input name="txtLocation" id="txtLocation" maxlength="25" type="text" value="<?php echo $loc; ?>"
        placeholder="Kholera"></div><div class="col-md-4"><label for="txtSubLocation">Sub-Location</label><input type="text" name="txtSubLocation" id="txtSubLocation" maxlength="25"
        value="<?php echo $sloc; ?>" placeholder="Bulimbo"></div><div class="col-md-4"><label for="txtVillage">Home Area</label><Input type="text" name="txtVillage" id="txtVillage"
        maxlength="25" value="<?php echo $vil; ?>" 	placeholder="Lukusi"></div>
    </div><div class="form-row">
        <div class="col-md-12" style="background-color:#000;color:#fff;letter-spacing:4px;word-spacing:5px;">FEES ARREARS AND REFUNDS CARRIED FORWARD</div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="txtArrears">Arrears B/F</label><input type="text" size="10" maxlength="9" name="txtArrears" id="txtArrears" value="<?php echo number_format($arrears,2); ?>"
        style="text-align:center;"	onkeyup="checkData(this,0)" onblur="frmtNumber(this)" <?php echo ($act[0]==1?"readonly":"")?>></div>
        <div class="col-md-4"><label for="txtRef">Refunds C/F</label><input type="text" size="10" maxlength="8" name="txtRef" id="txtRef" value="<?php echo number_format($refunds,2); ?>"
        style="text-align:center;"	onblur="frmtNumber(this)" onkeyup="checkData(this,0)" <?php echo ($act[0]==1?"readonly":"")?>></div>
        <div class="col-md-4" style="text-align:center;vertical-align:middle;"><?php if ($act[0]==1) echo '<a href="alumniarredit.php?rec='.$admno.'-'.$acyr.'"
        onclick="return canedit_amt('.$yes.')"><button type="button" name="cmdarrref" style="font-size:11pt;font-weight:strong;background-color:#aaa;color:#fff;">EDIT ARREARS/<BR>REFUNDS
        AMOUNT</button></a>'; ?></div>
    </div><br><div class="form-row">
        <div class="col-md-6" style="text-align:center;"><button type="submit" name="CmdSave" id="save">Save Alumni Details</button></div>
        <div class="col-md-6" style="text-align:right;"><a href="alumni.php"><button type="button" name="CmdClose">Close</button></a></div>
    </div>
</div></form>
<script type="text/javascript" src="../date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/alumniadd.js"></script>
<script type="text/javascript" src="tpl/js/iebc.js"></script>
<script type="text/javascript">var mp=[<?php echo $mp.'];';
        if(strlen($mca)>0) echo 'var mca=['.$mca.'];'; echo '</script>';
        mysqli_close($conn); footer();
?>
