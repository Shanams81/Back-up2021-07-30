<!DOCTYPE html>
<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/Pri_sch_connect.inc');
	$cls = isset($_POST['CboCls'])?trim(strip_tags($_POST['CboCls'])):"%";
	$stream = isset($_POST['CboStream'])?trim(strip_tags($_POST['CboStream'])):"%";
	$selYr=isset($_POST['cboYear'])?strip_tags($_POST['cboYear']): date("Y");
	$rs=mysqli_query($conn,"SELECT finyr-1 FROM ss"); list($cuyr)=mysqli_fetch_row($rs); mysqli_free_result($rs);
	$rs=mysqli_query($conn,"SELECT min(curr_year) as yr FROM class"); list($fyr)=mysqli_fetch_row($rs); mysqli_free_result($rs);
?>
<html>
	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    	<link href="tpl/hightlight.css" rel="stylesheet" type="text/css"/><link href="tpl/headers.css" rel="stylesheet" type="text/css"/>
		<title>School Fees Defaulters</title>
		<script type="text/javascript" src="tpl/priv.js"></script>
    </head>
<body background="img/bg3.gif"><div class="head"><form method="post" action="Arch_fee_bal_status.php">
<?php 
	print "Financial Year <SELECT name=\"cboYear\" size=\"1\">";
	$rs=mysqli_query($conn,"SELECT DISTINCT yr FROM arch_feerec ORDER BY yr DESC");	
	while ($yr=mysqli_fetch_row($rs)) print "<option ".($yr[0]==$cuyr?"selected":"").">$yr[0]</option>";
	print "</select> Fee Balance Status for Class <select name=\"CboCls\" size=\"1\" id=\"Class\"><option selected value=\"%\">All</option>";
	$str=@mysqli_query($conn,"SELECT clsno,clsname FROM classnames ORDER BY clsno ASC"); 
	if (mysqli_num_rows($str)>0) while (list($cl,$cln)=mysqli_fetch_row($str)) print "<option value=\"$cl\">".$cln."</option>";	mysqli_free_result($str);
	print"</select>-<select name=\"CboStream\" size=\"1\" id=\"stream\"><option selected value=\"%\">All</option>";
	$rsStr=@mysqli_query($conn,"SELECT strm FROM grps WHERE strm is not null or strm not like ''"); 
	if (mysqli_num_rows($rsStr)>0) while (list($strm)=mysqli_fetch_row($rsStr)) print "<option>$strm</option>"; mysqli_free_result($rsStr);
	print "</select>&nbsp;&nbsp;<button type=\"submit\" accesskey=\"s\" name=\"CmdBalState\">View Fee Bal Status</button></form></font></div>";
	if (isset($_POST["CmdBalState"])){
		if ((strcasecmp($cls,"%")==0) && (strcasecmp($stream,"%")==0)) $h="All pupils' "; 
		elseif ((strcasecmp($cls,"%")==0) && (strcasecmp($str,"%")!=0)) $h="All $stream stream pupils' ";  
		elseif ((strcasecmp($cls,"%")!=0) && (strcasecmp($str,"%")==0)) $h="All class $cls pupils' "; 
		else $h="Class $cls - $stream pupils' ";
		$h.=" fees balance status as on ".date("D, d-F-Y",strtotime("$selYr-12-31"));
		print "<div id=\"print_content\"><h3>".strtoupper($h)."</h3></font>";
		print "<table cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr bgcolor=\"#eeeeee\"><th colspan=\"4\" align=\"center\">Pupils' Details</th><th colspan=3 
		align=\"center\">Total Fees Paid</th><th colspan=\"3\" align=\"center\">$selYr Total Balance</th></tr><tr><th>S/N</th><th>Adm. No.</th><th align=\"center\">
		Names</th><th align=\"center\">Class</th><th align=\"Center\">Main</th><th align=\"center\">Misc.</th><th align=\"center\">Total</th><th align=\"Center\">
		Main</th><th align=\"center\">Misc.</th><th align=\"center\">Total</th></tr>";
		$rsBal=mysqli_query($conn,"SELECT s.admno,s.names,s.cls,s.ttl,s.mttl,(f.maint3+s.specialmedical+s.bbf+s.trans-s.amtp) as bal,(f.misct3+s.miscbf+s.unifrm-s.misamtp) as misbal,
		((f.maint3+s.specialmedical+s.bbf+s.trans-s.amtp)+(f.misct3+s.miscbf+s.unifrm-s.misamtp)) as TtlBal FROM (SELECT s.admno,concat(s.surname,' ',s.onames) As names,c.clsno,
		concat(cn.clsname,'-',c.stream) As cls,c.curr_year,c.feegrp,c.lvlno,c.bbf,c.specialmedical,(c.t1trans+c.t2trans+c.t3trans) as trans,c.miscbf,c.unifrm,if(isnull(f.amtpaid),0,
		f.amtpaid) as amtp,(if(isnull(f.amtprep),0,f.amtprep)+if(isnull(f.ttlpaid),0,f.ttlpaid)) as ttl,if(isnull(m.ttlamt),0,m.ttlamt) as mttl,if(isnull(m.amtpaid),0,m.amtpaid) as 
		misamtp FROM stud s Inner Join class c USING (admno) Inner Join classnames cn USING (clsno) LEFT JOIN (SELECT admno,yr,sum(amt-arrears-refunds-spemed-transport-prep) As amtpaid,
		sum(prep) As amtprep,sum(amt+bankcharges) As ttlpaid FROM arch_feerec f GROUP BY f.admno,yr,f.markdel Having (f.markdel=0 and f.yr LIKE '$selYr'))f On (c.admno=f.admno and 
		c.curr_year=f.yr) LEFT JOIN (SELECT payeesno,yr,sum(amt-arrears-uni) as amtpaid,sum(amt+bankcharges) as ttlamt FROM arch_miscfeepyts GROUP BY payeesno,yr,markdel HAVING (markdel=0 
		and yr LIKE '$selYr'))m On (c.admno=m.payeesno and c.curr_year=m.yr) WHERE (c.`clsno` Like '$cls' and c.`stream` Like '$stream' and c.curr_year LIKE '$selYr' and c.markdel=0))s 
		INNER JOIN arch_feeoutline f USING (curr_year,lvlno,feegrp) Order By cls,names Asc");
		$a=mysqli_num_rows($rsBal); $amt=array(0,0,0,0,0,0);
		if ($a>0):
			$i=0;
			while (list($adn,$nam,$cla,$fee,$mfee,$bal,$misc,$ttl)=mysqli_fetch_row($rsBal)):
				if (($i%2)==0) print "<tr bgcolor=\"#eeeeee\" style=\"opacity:0.8;\">"; else print "<tr>";
				print "<td align=\"right\">".($i+1).".</td><td align=\"center\">$adn</td><td>$nam</td><td>$cla</td><td align=\"right\">".number_format($fee,2).
				"</td><td align=\"right\">".number_format($mfee,2)."</td><td align=\"right\"><b>".number_format(($fee+$mfee),2)."</b></td><td align=\"right\">".
				number_format($bal,2)."</td><td align=\"right\">".number_format($misc,2)."</td><td align=\"right\"><b>".number_format($ttl,2)."</b></td></tr>";
				$i++; $amt[0]+=$fee; $amt[1]+=$mfee; $amt[2]+=($fee+$mfee); $amt[3]+=$bal; $amt[4]+=$misc;  $amt[5]+=$ttl;
			endwhile;
		else:
			print "<tr><td colspan=\"10\"><br>No $selYr fees defualters have been found</td></tr>";
		endif;
		print "<tr><td colspan=\"3\">$a Pupils' Records</td><td align=\"right\">Subtotals</td>";
		foreach($amt as $am) print "<td align=\"right\"><b>".number_format($am,2)."</b></td>";
		print "</tr></table></div><br><center><button onclick=\"Clickheretoprint()\" type=\"button\">Print</button></center>";
		mysqli_free_result($rsBal);
	}else{
		print "<h3>Fee Defaulters' Manual</h3>";
		print "<font size=\"3\" color=\"#0000ee\"><p class=\"g\">This interface allows you to view a given year's  fee defualters. to view<ol type=\"i\"><li>Select 
		the Financial year<li>Select the class whose balances are to be viewed<li>Select pupils' stream and <li>Click <b>View Fee Bal Status</b> button</ol>";
	} mysqli_close($conn);
?></body></html>