<?php
	include_once('shanam.php');
	$rsDet=mysqli_query($conn,"SELECT borroview,accview,transconf FROM acc_priv WHERE uname LIKE '".$_SESSION['username']."'");	$bor=0;	$acviu=0; $conf=0;
	if (mysqli_num_rows($rsDet)>0) list($bor,$acviu,$conf)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	if($acviu==0) header("location:vague.php");
	headings('',0,0,0);
?>
<table class="table table-borderless" style="margin:100px auto;width:fit-content"><tr><td colspan="3"><p>VOTEHEAD INTERBORROWINGS &amp; BANKINGS</p></td></tr>
<tr><td><a href="accounts.php?from=0" onclick="return canvi(<?php echo $acviu;?>)"><img src="/gen_img/depts.png" id="img2" width="120" height="100" onmouseover="img_focus(this)"
	onmouseout="img_blur(this)"></a><br>Bank Accounts</td>
	<td><a onclick="return canvi(<?php echo $conf;?>)" href="confirmtrans.php"><img src="/gen_img/banking.jpg" id="img1" width="120" height="100" onmouseover="img_focus(this)"
	onmouseout="img_blur(this)"></a><br>Bank Fee</td>
	<td><a onclick="return canvi(<?php echo $acviu;?>)" href="accbalbf.php"><img src="/gen_img/refresh.jpg" id="img1" width="120" height="100" onmouseover="img_focus(this)"
	onmouseout="img_blur(this)"></a><br>A/C Balances B/F</td>
</tr><tr>
	<td><a onclick="return canvi(<?php echo $bor;?>)" href="cashflow.php"><img src="/gen_img/cashflow.jpeg" id="img1" width="120" height="100" onmouseover="img_focus(this)"
	onmouseout="img_blur(this)"></a><br>Cash at Hand Transactions</td>
	<td><a onclick="return canvi(<?php echo $bor;?>)" href="withdrawals.php"><img src="/gen_img/fundtransfer.jpg" id="img1" width="120" height="100" onmouseover="img_focus(this)"
	onmouseout="img_blur(this)"></a><br>Cash at Bank Transactions</td>
	<td><a onclick="return canvi(<?php echo $bor;?>)" href="interacborrow.php"><img src="/gen_img/acfundtransfer.jpg" id="img1" width="120" height="100" onmouseover="img_focus(this)"
	onmouseout="img_blur(this)"></a><br>Inter A/C Fund Transfer</td>
	<!--<td><a href="interb.php" onclick="return canvi(<?php echo $bor;?>)"><img src="/gen_img/money.jpg" id="img2" width="120"	height="100" onmouseover="img_focus(this)"
	onmouseout="img_blur(this)"></a><br>Inter Vote Fund Transfers</td>-->
</tr><tr>
	<td colspan="3"><p>Shanam's Digital Solutions - Bridging Digital Divide</p></td>
</tr></table>
<script type="text/javascript" src="tpl/menu.js"></script>
<?php
	mysqli_close($conn); footer();
?>
