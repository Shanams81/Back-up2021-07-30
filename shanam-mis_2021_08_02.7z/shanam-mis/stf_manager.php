<?php
	include_once("shanam.php");
	$rsDet=mysqli_query($conn,"SELECT g.stfview,g.deptview,a.advview,a.salview,a.feeview FROM gen_priv g INNER JOIN acc_priv a USING (uname) WHERE g.uname LIKE '".
	$_SESSION['username']."'");	$stfv=$depv=$salv=$feev=$advv=0;
	if (mysqli_num_rows($rsDet)>0) list($stfv,$depv,$advv,$salv,$feev)=mysqli_fetch_row($rsDet);	mysqli_free_result($rsDet);
	headings('',0,0,0);
?>
<table class="table table-responsive table-borderless"><tr><td colspan="3"><p>STAFF AND DEPARTMENT MANAGEMENT INTERFACE.<br> Log In Time:
	<?php echo $_SESSION['logintime'];?></p></td></tr>
 <tr><td width="35%" align="center"><a onclick="return canvi(<?echo $stfv;?>);" href="stf.php"><img src="/gen_img/stf.jpg" id="img1" width="120" height="100"
	 	onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Members of Staff</td><td width="35%" align="center"><a href="depts.php"
		onclick="return canvi(<?php echo $depv;?>)"><img src="/gen_img/depts.png" id="img2" width="120" height="100" onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a>
		<br>Departments</td><td width="30%" align="center"><a onclick="return canvi(<?php echo $stfv;?>)" href="staff_depts.php?act=0-0"><img src="/gen_img/stfdept.jpg" id="img3"
		width="120" height="100" onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Members of Department</td>
	</tr><tr><td align="center"><a onclick="return canvi(<?php echo $salv;?>)" href="saldet.php"><img src="/gen_img/saldef.jpg" id="img4" width="120"	height="100"
		onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Salary Definition</td><td align="center"><a onclick="return canvi(<?php echo $advv;?>)" href="advance_manager.php">
		<img src="/gen_img/saladv.jpg" id="img5" width="120" height="100"	onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Salary Advances</td><td align="center"><a
		onclick="return canvi(<?php echo $salv;?>);" href="payroll.php"><img src="/gen_img/salary.jpg" id="img5" width="120" height="100" onmouseover="img_focus(this)" onmouseout="img_blur(this)">
		</a><br>Payroll</td>
	</tr><tr>
		<td align="center"><a onclick="return canvi(<?php echo $salv;?>)" href="tenants.php"><img src="/gen_img/feestruct.jpg" id="img4" width="120"	height="100"
		onmouseover="img_focus(this)" onmouseout="img_blur(this)"></a><br>Tenants &amp; Rent</td>
		<td></td>
		<td></td>
	<tr><td colspan="3"><p>Shanam's Digital Solutions - Bridging Digital Divide</p></td></tr>
</table><script type="text/javascript" src="tpl/menu.js"></script>
<?php
	footer();mysqli_close($conn);
?>
