<?php
    include_once('shanam.php');
    $usn=strtoupper($_SESSION['username'].' ('.$_SESSION['priviledge'].')');
    if (isset($_POST['cmdSave'])){
        $info=isset($_POST['txtInfo'])?sanitize($_POST['txtInfo']):'0-0';         $info=preg_split('/\-/',$info); //[0] 0-New 1-Edit, [1]-Voucher No.[2]-AdmNo
        $vono=isset($_POST['txtVNo'])?sanitize($_POST['txtVNo']):0;               $date=isset($_POST['dtpDate'])?sanitize($_POST['dtpDate']):date('Y-m-d');   $date=preg_split("/\-/",$date);
        $idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):0;			        $date="$date[2]-$date[1]-$date[0]";
        $payee=isset($_POST['txtPayee'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPayee']))):Null;
        $add=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):null;
        $telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):null;	      $mode=isset($_POST['cboMode'])?sanitize($_POST['cboMode']):'Cash';
        $cheno=isset($_POST['txtCheNo'])?sanitize($_POST['txtCheNo']):null;	    	$cash=isset($_POST['txtCash'])?sanitize($_POST['txtCash']):0;		$cash=preg_replace("/[^0-9\.]/","",$cash);
        $cheque=isset($_POST['txtCheque'])?sanitize($_POST['txtCheque']):0;				$cheque=preg_replace("/[^0-9\.]/","",$cheque);
        $rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtRmks']))):'BEING PAYMENT OF ';
        $cash=isset($_POST['txtCash'])?sanitize($_POST['txtCash']):0;             $cash=preg_replace("/[^0-9^\.]/","",$cash);
        $cheque=isset($_POST['txtCheque'])?sanitize($_POST['txtCheque']):0;       $cheque=preg_replace("/[^0-9^\.]/","",$cheque);
        $distr=isset($_POST['txtAmt_0'])?sanitize($_POST['txtAmt_0']):0;          $distr=preg_replace("/[^0-9^\.]/","",$distr);
        $oamt=isset($_POST['txtOrig'])?sanitize($_POST['txtOrig']):0;             $oamt=preg_replace("/[^0-9^\.]/","",$distr);
        $vote=isset($_POST['txtVote_0'])?sanitize($_POST['txtVote_0']):0;         $user=$_SESSION['username'].' ('.$_SESSION['priviledge'].')';
        $bank=isset($_POST['cboBank'])?sanitize($_POST['cboBank']):0;             $bank=($bank==0?Null:$bank); $ttl=$cash+$cheque;
        $omode=isset($_POST['cboOMode'])?sanitize($_POST['cboOMode']):'Cash-0-0'; $omode=preg_split('/\-/',$omode); //[0] Original Mode, [1] - Cash, [2] - Cheque
        if(strlen($idno)<6 || $vono==0 || strlen($payee)<10 || (strcasecmp($mode,'cash')!=0 && (strlen($cheno)<2 || is_null($bank))) || ($cash+$cheque)<1 || ($cash+$cheque)>$oamt ||
        ($distr!=($cash+$cheque)) || strlen($vote)==0){
          echo "Sorry, the refund record has errors to be corrected. Click <a href=\"alumni.php\">HERE</a> to go back.<br>";
          exit(0);
        }else{
          if($info[0]==0){ //new record
            $rs=mysqli_query($conn,"SELECT payno FROM acc_exppayee WHERE idno LIKE '$idno'"); $nop=mysqli_num_rows($rs);
            if($nop>0){
              list($payno)=mysqli_fetch_row($rs);
              mysqli_query($conn,"UPDATE acc_exppayee SET payee=".var_export($payee,true).",address=".var_export($add,true).",telno=".var_export($telno,true)." WHERE payno LIKE '$payno'");
            }else{
              mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,address,telno,addedby) VALUES (0,'$date',".var_export($payee,true).",".var_export($idno,true).",".
              var_export($add,true).",".var_export($telno,true).",'$user')") or die(mysqli_error($conn).". Payee details not saved."); $payno=mysqli_insert_id($conn);
            }mysqli_free_result($rs);
            if($payno>0){
              $sql="INSERT INTO acc_exp(vono,acsno,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,commt,addedby) VALUES($vono,".var_export($bank,true).",'$date',1,'$mode',".
              var_export($cheno,true).",$cash,$cheque,'$rmks',$payno,0,'$user'); INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,1,$vote,$ttl);";
              if($cash>0) $sql.="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES (0,1,1,'$date','SCHOOL FEES REFUND',$cash,2,$vono,'$user');";
              if($cheque>0) $sql.="INSERT INTO acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno) VALUES(0,'$date',1,".var_export($bank,true).",'$cheno',$cheque,
              'SCHOOL FEE REFUND',1,$vono);";
              //clear current refunds
              $rs=mysqli_query($conn,"SELECT curr_year,alumniref FROM class WHERE markdel=0 and admno LIKE '$info[2]'");
              while($ttl>0 && list($yr,$ref)=mysqli_fetch_row($rs)){
                  if($ref>=$ttl){$sql.="UPDATE class SET alumniref=alumniref-$ttl WHERE curr_year=$yr and admno LIKE '$info[2]'; INSERT INTO acc_arrrefclr (clrno,recno,arr_year,ac,clron,
                  admno,amt,transtype) VALUES(0,$vono,$yr,1,'$date',$info[2],$ttl,1);"; $ttl=0;}
                  else{$sql.="UPDATE class SET alumniref=alumniref-$ref WHERE curr_year=$yr and admno LIKE '$info[2]'; INSERT INTO acc_arrrefclr (clrno,recno,arr_year,ac,clron,admno,amt,
                  transtype) VALUES(0,$vono,$yr,1,'$date',$info[2],$ref,1);"; $ttl-=$ref;}
              }
              mysqli_multi_query($conn , $sql) or die(mysqli_error($conn).". Payment Voucher record not saved. Click <a href=\"alumni.php\">HERE</a> to try again.");
              while(mysqli_next_result($conn)){}
              header("location:rpts/pv.php?action=$vono-5-$payno-1"); exit(0);
            }
          }else{ //Editing records
            $sql="UPDATE acc_exppayee SET payee=".var_export($payee,true).",address=".var_export($add,true).",telno=".var_export($telno,true)." WHERE payno IN (SELECT expno FROM acc_exp
            WHERE acc=1 and vono LIKE '$info[1]'); UPDATE acc_exp SET vono=$vono, acsno=".var_export($bank,true).", pytdate='$date', pytfrm='$mode', cheno=".var_export($cheno,true).",
            caamt=$cash,chamt=$cheque,rmks='$rmks' WHERE acc=1 and vono LIKE '$info[1]'; ";
            if(strcasecmp($omode[0],$mode)!=0){//there is change in mode of payment
                if($omode[1]>0 && $cash==0) $sql.="UPDATE acc_cashflow SET markdel=1, delreason='FEE REFUND PV $vono EDITED/ CHANGED' WHERE acc=1 and cftype=1 and transtype=2 and transno=$vono;";
                if($omode[2]>0 && $cheque==0) $sql.="UPDATE acc_banking SET markdel=1, delreason='FEE REFUND PV $vono EDITED/ CHANGED' WHERE bank_type=1 and transtype=1 and transno=$vono;";
                if($omode[1]==0 && $cash>0) $sql.="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES (0,1,1,'$date','SCHOOL FEES REFUND',$cash,2,$vono,'$user');";
                if($omode[2]==0 && $cheque>0) $sql.="INSERT INTO acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno) VALUES(0,'$date',1,".var_export($bank,true).",'$cheno',$cheque,
                'SCHOOL FEE REFUND',1,$vono);";
            }else{//No change in mode of payment
                if($cash>0) $sql.="UPDATE acc_cashflow SET cfdate='$date',amt=$cash WHERE acc=1 and cftype=1 and transtype=2 and transno=$vono;";
                if($cheque>0) $sql.="UPDATE acc_banking SET transdate='$date',acsno=".var_export($bank,true).",cheno='$cheno',amt=$cheque WHERE bank_type=1 and transtype=1 and transno=$vono;";
            } mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Refund PV record not saved. Click <a href=\"alumni.php\">HERE</a> to try again.");
            while(mysqli_next_result($conn)){}
            header("location:alumni.php");
          }
      }
    }else{
        $info=isset($_REQUEST['ref'])?sanitize($_REQUEST['ref']):'0-0-0';     $info=preg_split('/\-/',$info); //[0] 0-New 1-Edit, [1] admno, [2] Voucher No.
        mysqli_multi_query($conn,"SELECT sno,descr FROM acc_votes WHERE abbr LIKE 'refunds'; SELECT s.admno,concat(s.surname,' ',s.onames) as stud_names,concat(sf.clsname,'-',sf.stream,'-',
        sf.curr_year) As frm,s.telno,s.address,sf.alumniref FROM stud s Inner Join (SELECT f.admno,f.curr_year,f.stream,t.ref as alumniref,c.clsname,c.clsno FROM class f Inner
        Join classnames c USING (clsno) Inner Join (SELECT admno, sum(alumniref) as ref From class group by admno)t using (admno))sf USING (admno,curr_year) WHERE s.admno LIKE '$info[1]'; "
        . "SELECT e.pytdate,e.acsno,e.pytfrm,e.cheno,p.payee,p.idno,p.telno,p.address,e.caamt,e.chamt,(e.caamt+e.chamt) as amt,e.rmks FROM acc_exppayee p Inner Join acc_exp e ON
        (p.payno=e.expno) WHERE e.markdel=0 and e.acc='1' and e.commt=0 and e.vono LIKE '$info[2]'; SELECT max(vono) FROM acc_exp GROUP BY acc HAVING acc=1;SELECT a.sno, concat(b.abbr,
        '- A/C ',a.accno) as bank FROM acc_accounts a Inner Join acc_banks b ON (a.bankno=b.sno) WHERE a.accacc=1 ORDER BY a.sno ASC;");
        $i=$voteno=$nextvno=0; $votename=$banks='';
        do{
           if($rs=mysqli_store_result($conn)){
               if($i==0){list($voteno,$votename)=mysqli_fetch_row($rs);
               }elseif($i==1){list($admno,$aluname,$alufrm,$alutel,$aluaddr,$aluref)=mysqli_fetch_row($rs);
               }elseif($i==2){list($pdate,$acno,$pytfrm,$cheno,$payee,$idno,$tel,$addr,$cash,$cheq,$ttl,$rmks)=mysqli_fetch_row($rs);
               }elseif($i==3){if(mysqli_num_rows($rs)>0) list($nextvno)=mysqli_fetch_row($rs);
               }else{while(list($n, $nam)=mysqli_fetch_row($rs)) $banks.="<option value=\"$n\" ".($n==$acno?"selected":"").">$nam</option>";}
               mysqli_free_result($rs);
           } $i++;
        }while(mysqli_next_result($conn));
        if($info[0]==0){
            $pdate=date('Y-m-d'); $pytfrm='Cash'; $cheno=''; $payee=$aluname; $idno=''; $tel=$alutel; $addr=$aluaddr; $cash=$aluref; $cheq=0; $ttl=$aluref; $info[2]=($nextvno+1);
            $rmks=''; $acno=0;
        }else{$aluref+=($cash+$cheq);  $info[2]=$nextvno;}
    }
    headings('<link rel="stylesheet" type="text/css" href="/date/tcal.css" /><style>input.dis{text-align:right;border:0px;font-weight:bold;color:#00F;background-color:inherit;pointer-events:none}
    input,textarea{text-transform:uppercase;}</style>',0,0,1);
?>
<div class="container" style="width:fit-content;border:1px dashed #fff;border-radius:15px;padding:0 5px;margin:auto;margin-top:5px;max-width:800px;font-size:10pt;background-color:#f0ece3;">
    <form method="post" action="refunded.php" onsubmit="return validateFormOnSubmit(this);" name="frmRefund"><input name="txtInfo" type="hidden" value="<?php echo "$info[0]-$info[2]-$admno";?>">
    <input type="hidden" name="txtOMode" id="txtOMode" value="<?php echo "$pytfrm-$cash-$cheq"; ?>">
    <div class="form-row"><div class="col-md-12" style="word-spacing:7px;letter-spacing:5px;font-weight:bold;font-size:14px;background-color:#2ec1ac;border-radius:10px 10px 0 0;color:#fff;">
    REFUND - PAYMENT VOUCHER</div></div>
    <div class="form-row"><div class="col-md-3"><label for="txtVNo">Voucher No. *</label><input type="text" name="txtVNo" id="txtVNo" maxlength="4" required value="<?php echo $info[2];?>"
      style="background-color:#eee;" readonly>
    </div><div class="col-md-6"></div><div class="col-md-3"><label for="dtpDate">Paid On</LABEL><INPUT name="dtpDate" id="dtpDate" maxlength="10" readonly class="tcal"
       value="<?php print date('d-m-Y',strtotime($pdate));?>"> </div>
    </div>
    <div class="form-row"><div class="col-md-12" style="word-spacing:7px;letter-spacing:5px;font-weight:bold;font-size:14px;background-color:#2ec1ac;color:#fff;margin-top:5px;">DETAILS OF
        PAYEE</div></div>
    <div class="form-row">
      <div class="col-md-3"><label for="txtIDNo">ID No. *</label><input type="text" name="txtIDNo" id="txtIDNo" maxlength="10" value="<?php echo $idno;?>" placeholder="ID NO. of Alumni"
      onkeyup="findIDNo(this)" required></div>
      <div class="col-md-9"><label for="txtPayee">Name of Payee *</label><input type="text" name="txtPayee" id="txtPayee" maxlength="40" value="<?php echo $payee;?>" readonly
      placeholder="Name of Alumni"></div>
    </div><div class="form-row">
        <div class="col-md-3"><label for="txtTelNo">Tel. No.</label><input type="text" name="txtTelNo" id="txtTelNo" maxlength="13" value="<?php echo $tel;?>" placeholder="+25472000000"
        readonly></div>
        <div class="col-md-9"><label for="txtAddress">Address of Payee *</label><input name="txtAddress" id="txtAddress" maxlength="75" placeholder="P.O Box " value="<?php echo $addr;?>"
        readonly></div>
    </div>
    <div class="form-row"><div class="col-md-12" style="word-spacing:10px;letter-spacing:13px;font-weight:bold;font-size:13pt;color:#fff;background-color:#2ec1ac;margin-top:5px;">DETAILS OF
        PAYMENT</div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="cboMode">Paid in *</label><SELECT name="cboMode" id="cboMode" size="1" onblur="activateCashCheque(this)"><option value="Cash" <?php
        echo strcasecmp('cash',$pytfrm)==0?"selected":"";?>>Cash</option><option value="Cheque" <?php echo strcasecmp('cheque',$pytfrm)==0?"selected":"";?>>Cheque</option><option
        value="Cash + Cheque" <?php echo strcasecmp('cash + cheque',$pytfrm)==0?"selected":"";?>>Cash + Cheque</option></select></div>
        <div class="col-md-4"><label for="txtCheNO">Cheque No.</label><input name="txtCheNo" Id="txtCheNo" maxlength="7" onkeyup="checkInput(this)" value="<?php echo $cheno; ?>"
        placeholder="00001" <?php echo strcasecmp($pytfrm,'cash')==0?"readonly":""; ?>></div>
        <div class="col-md-4"><label for="cboBank">Bank (For Cheque Payment)</label><SELECT name="cboBank" id="cboBank" <?php echo (strcasecmp($pytfrm,'cash')==0?"disabled":"").
        "size=\"1\"><option value=\"0\" ".($acno==0?"selected":"").">None</option>$banks"; ?></SELECT></div>
    </div><div class="form-row">
        <div class="col-md-4"><label for="txtCash">Cash Amount</label><input name="txtCash" Id="txtCash" maxlength="10" onkeyup="checkInput(this)" onChange="sumPaid()" style="font-weight:bold;"
        value="<?php echo number_format($cash,2);?>" required></div>
        <div class="col-md-4"><label for="txtCheque">Cheque Amount</label><input name="txtCheque" Id="txtCheque" maxlength="10" onkeyup="checkInput(this)" onChange="sumPaid()"
        style="font-weight:bold;" value="<?php echo number_format($cheq,2);?>" required></div>
        <div class="col-md-4" style="background-color:#2ec1ac;color:#fff;font-weight:bold;text-align:center;border-radius:20px 20px 0 0;"><label for="txtTotal">Total Amount Spend</label><input
        name="txtTotal" Id="txtTotal" maxlength="10" onkeyup="checkInput(this)" readonly value="<?php echo number_format(($cash+$cheq),2);?>" style="color:#fff;background-color:inherit;
        text-align:center;font-weight:bold;"></div><input type="hidden" name="txtOrig" id="txtOrig" value="<?php echo "$aluref";?>">
    </div><div class="form-row">
        <div class="col-md-12"><label for="txtRmks">Reason for the Payment *</label><textarea name="txtRmks" id="txtRmks" rows="2" maxlength="250" placeholder="Being payment for"
        required><?php echo $rmks; ?></textarea></div>
    </div><div class="form-row">
        <div class="col-md-12" style="word-spacing:10px;letter-spacing:13px;font-weight:bold;font-size:14px;background-color:#2ec1ac;color:#fff;margin:3px 0;">DETAILS OF VOTEHEAD
        DISTRIBUTION</div>
    </div><div class="form-row" style="background-color:#2ec1ac;font-weight:bold;">
        <div class="col-md-2">Votehead</div><div class="col-md-2" style="text-align: right;">Budgeted</div><div class="col-md-2" style="text-align: right;">Income</div><div class="col-md-2"
        style="text-align: right;">Running Costs</div><div class="col-md-2"  style="text-align: right;">Available</div><div class="col-md-2" style="text-align: right;">Amount</div>
    </div><div class="form-row">
        <div class="col-md-2"><input type="hidden" name="txtVote_0" id="txtVote_0" <?php echo "value=\"$voteno\">$votename";?></div>
        <div class="col-md-2"><input type="text" name="txtBudg_0" id="txtBudg_0" class="dis" readonly value="0.00"></div>
        <div class="col-md-2"><input type="text" name="txtIncome_0" id="txtIncome_0" class="dis" readonly value="0.00"></div>
        <div class="col-md-2"><input type="text" name="txtCost_0" id="txtCost_0" class="dis" readonly value="0.00"></div>
        <div class="col-md-2"><input name="txtAvailable_0" id="txtAvailable_0" type="text" class="dis" value="<?php echo number_format(($cash+$cheq),2);?>"></div>
        <div class="col-md-2"><input name="txtAmt_0" id="txtAmt_0" value="<?php echo number_format(($cash+$cheq),2);?>" required style="text-align:right;" onchange="confirmAmt(this)"
        onkeyup="checkInput(this)"></div>
    </div>
    <div class="form-row" style="background-color:#2ec1ac;border-radius:8px;color:#fff;margin:5px 0;text-align:right;font-weight:bold;">
        <div class="col-md-4" style="padding:1px;">BALANCE TO BE DISTRIBUTE</div><div class="col-md-2"><input name="txtBallAmt" id="txtBalAmt" value="0.00"
        style="text-align:right;background-color:inherit;font-weight:bold;color:#fff;"></div>
        <div class="col-md-4" style="padding:1px;">TOTAL AMOUNT DISTRIBUTED</div><div class="col-md-2"><input name="txtTtlAmt" id="txtTtlAmt"
        value="<?php echo number_format(($cash+$cheq),2);?>"  style="text-align:right;background-color:inherit;font-weight:bold;color:#fff;"></div>
    </div>
    <div class="form-row">
        <div class="col-md-6" style="text-align:center;"><button type="submit" name="cmdSave" id="save">Save PV Details</button></div>
        <div class="col-md-6" style="text-align: right;"><a href="alumni.php"><button type="button" name="CmdClose">Cancel/ Close</button></a></div>
    </div>
</div></form>
<script type="text/javascript" src="/date/tcal.js"></script>
<script type="text/javascript" src="tpl/js/refunded.js"></script>
<?php
	mysqli_close($conn); footer();
?>
