<?php
	include_once('shanam.php'); include_once('tpl/functs.tpl');
	headings('<style>.colhide{display:none;}.colcenter{text-align:center}.divb{border:0;border-bottom:1px solid #f00;border-radius:4px;}.divlrborder{border:0;border-right:3px solid #f66;border-left:3px solid #f66;
	border-radius:15px;}.hborder{border:0 !important}</style>',0,0,2);
	mysqli_multi_query($conn,"SELECT acno,descr FROM acc_voteacs WHERE markdel=0; SELECT v.sno,v.acc,v.lfn,v.descr FROM acc_votes v WHERE v.markdel=0 ORDER BY v.sno ASC;");
	$i=0; $lstvotes=$optacc='';
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0) while($d=mysqli_fetch_row($rs)) $optacc.="<option value=\"$d[0]\">$d[1]</option>";
			else while($d=mysqli_fetch_row($rs)) $lstvotes.="<tr><td class=\"colhide\">$d[1]</td><td>$d[2]</td><td>$d[3]</td><td class=\"colcenter\"><img src=\"/gen_img/print.ico\" width=\"30\" height=\"30\"
				onclick=\"printLedger($d[0],$d[1])\"</td></tr>"; mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));

?><div class="container"  style="width:75%;margin:0 auto;background-color:#d6d6d6;border-radius:10px 10px 0 0;">
	<div class="form-row"><div class="col-md-4 divlrborder">
		<div class="form-row"><div class="col-md-12 divb"><label for="cboAc">Ledgerbook For</label><select class="form-control" name="cboAc" id="cboAc" onchange="filterVotes(this)"><option value="%">All Accounts</option>
			<?php echo $optacc?></SELECT></div></div><br>
		<div class="form-row"><div class="col-md-12" style="max-height:600px;overflow-y:scroll;">
			<table id="tblVotes" class="table table-sm table-bordered table-hover table-striped"><thead class="thead-dark"><tr><th class="colhide">Account</th><th title="Ledgerbook Folio No.">LFN</th><th>VOTEHEAD</th><th>
			VIEW</th></tr></thead><tbody><?php echo $lstvotes;?></tbody></table>
		</div></div>
	</div><div class="col-md-8 divlrborder" id="print_content">
			<h1>THE LEDGERBOOK
	</div></div>
</DIV>
<script type="text/javascript" src="tpl/js/printthis.js"></script><script type="text/javascript">
	function filterVotes(cbo){let ac=parseInt(cbo.value),tr=document.querySelector("#tblVotes").getElementsByTagName("tr"),td,i=1;while(i<tr.length){if(isNaN(ac)){tr[i].style.display='block';}
		else{td=parseInt(tr[i].getElementsByTagName('td')[0].innerHTML); if(td===ac)tr[i].style.display=''; else tr[i].style.display='none';}i++;}
	} function printLedger(vno,acc){
		if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest(); // code for IE7+, Firefox, Chrome, Opera, Safari
    else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); // code for IE6, IE5
		var nocache=Math.random()*10000; xmlhttp.onreadystatechange=function(){if(this.readyState==4 && this.status==200) document.getElementById("print_content").innerHTML=this.responseText;};
    xmlhttp.open('GET','ajax/showledgerbook.php?q='+acc+'-'+vno+'-'+nocache,true); xmlhttp.send();
	}
</script>
<?php mysqli_close($conn); footer();?>
