<?php
	session_start();
	if (!(isset($_SESSION['username'])) || ($_SESSION['username'] == '')) header ("Location:../index.php"); else include_once('../conn/mysqli_connect.inc.tpl');
	if (isset($_POST['CmdSave'])){
	 	$rec=isset($_REQUEST['TxtGrpNo'])?$_REQUEST['TxtGrpNo']:'0-0';	$rec=preg_split("/\-/",$rec);
		$stf=isset($_POST['TxtStf'])?trim(strip_tags($_POST['TxtStf'])):""; $stf=strlen($stf)==0?Null:$stf;
		$studgrp=isset($_POST['TxtStudGrp'])?trim(strip_tags($_POST['TxtStudGrp'])):""; $studgrp=strlen($studgrp)==0?Null:$studgrp;
	 	$fgrp=isset($_POST['TxtFGrp'])?trim(strip_tags($_POST['TxtFGrp'])):""; 		$fgrp=strlen($fgrp)==0?Null:$fgrp;
	 	$strm=isset($_POST['TxtStrm'])?trim(strip_tags($_POST['TxtStrm'])):""; 		$strm=strlen($strm)==0?Null:$strm;
	 	$pp=isset($_POST['TxtPP'])?trim(strip_tags($_POST['TxtPP'])):""; 			$pp=strlen($pp)==0?Null:$pp;
	 	$bra=isset($_POST['TxtBranch'])?trim(strip_tags($_POST['TxtBranch'])):""; 	$bra=strlen($bra)==0?Null:$bra;
	 	$cor=isset($_POST['TxtCore'])?trim(strip_tags($_POST['TxtCore'])):""; 		$cor=strlen($cor)==0?Null:$cor;
	 	$cat=isset($_POST['TxtCateg'])?trim(strip_tags($_POST['TxtCateg'])):""; 	$cat=strlen($cat)==0?Null:$cat;
	 	if ((strlen($stf)>0) || (strlen($fgrp)>0) || (strlen($strm)>0) || (strlen($pp)>0) || (strlen($bra)>0) || (strlen($cor)>0) || (strlen($cat)>0)){
			if ($rec[0]==0) $sql="INSERT INTO grps (grp_no,staff,strm,pp,bb,corevalue,categ,stud_grp) VALUES (null,".var_export($stf,true).",
			".var_export($strm,true).",".var_export($pp,true).",".var_export($bra,true).",".var_export($cor,true).",".var_export($cat,true).",".var_export($studgrp,true).")";
			else $sql="UPDATE grps SET staff=".var_export($stf,true).",strm=".var_export($strm,true).",pp=".var_export($pp,true).",
			bb=".var_export($bra,true).",corevalue=".var_export($cor,true).",categ=".var_export($cat,true).",studgrp=".var_export($studgrp,true)." WHERE grp_no LIKE '$rec[1]'";
			//execute the SQL
			mysqli_query($conn,$sql) or die(mysqli_error($conn)." Record not saved. Click <a href=\"sysgroup.php?action=0-0\">here</a> to go back.");
			$i=mysqli_affected_rows($conn);
		}else{
			$i=0;
		} header("location:sysgroup.php?action=1-$i");
	}else{
		$rec=isset($_REQUEST['rec'])?$_REQUEST['rec']:'0-0';	$rec=preg_split("/\-/",$rec);
		$stf=''; $fgrp=''; $strm=''; $pp=''; $bra=''; $cor='';	$studgrp="";
		$rsDet=mysqli_query($conn,"SELECT grpdel FROM gen_priv WHERE uname LIKE '".$_SESSION['username']."'");
		list($del)=mysqli_fetch_row($rsDet); mysqli_free_result($rsDet);
		if ($rec[0]==1){
			$rs=mysqli_query($conn,"SELECT staff,fee,strm,pp,bb,corevalue,categ,studgrp FROM grps WHERE grp_no LIKE '$rec[1]'");
			list($stf,$fgrp,$strm,$pp,$bra,$cor,$categ,$studgrp)=mysqli_fetch_row($rs); mysqli_free_result($rs);
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Groupings</title>
	<script type="text/javascript" src="tpl/grpadd.js"></script>
</head>
<body background="../gen_img/bg3.gif" style="background-size:100%;">
<hr><h2><center>SYSTEM GROUPING SETUP DETAILS</center></h2><form method="Post" action="grpadd.php" name="FrmSetup" onsubmit="return validateFormOnSubmit(this)">
<table border=0 cellspacing="3" cellpadding="6" style="text-align:left;letter-spacing:2pt;word-spacing:3pt;font-style:normal;font-size:10pt;line-height:115%"
align="center">
<?php
	if ($rec[0]==1) print "<input type=\"hidden\" name=\"TxtGrpNo\" value=\"$rec[0]-$rec[1]\">";
	print "<tr><td align=\"right\">Staff Group:</td><td><input type=\"text\" name=\"TxtStf\" id=\"TxtStf\" size=\"25\" maxlength=\"20\" value=\"$stf\"></td><td
	rowspan=\"4\" valign=\"middle\"><button name=\"CmdSave\" type=\"submit\">Save Grouping<br>Details</td><tr><tr><td align=\"right\">Student Group:</td><td><input
	type=\"text\" name=\"TxtStudGrp\" id=\"TxtStudGrp\" size=\"25\" maxlength=\"16\" value=\"$studgrp\"></td></tr>";
	print "<tr><td align=\"right\">Fees Group:</td><td><input type=\"text\" name=\"TxtFGrp\" id=\"TxtFGrp\" size=\"25\" maxlength=\"20\" value=\"$fgrp\"></td><tr>
	<tr><td align=\"right\">Stream Name:</td><td><input type=\"text\" name=\"TxtStrm\" id=\"TxtStrm\" size=\"15\" maxlength=\"8\" value=\"$strm\"></td><tr>";
	print "<tr><td align=\"right\">Salary Paypoint (Bank):</td><td><input type=\"text\" name=\"TxtPP\" id=\"TxtPP\" size=\"25\" maxlength=\"15\" value=\"$pp\">
	</td><td rowspan=\"3\" valign=\"middle\"><a href=\"grpdel.php?rec=$rec[1]\"><button name=\"CmdDel\" type=\"button\" ".(($del==0 && $rec[0]==0)?"disabled":"").">Delete Group<br>
	Details</button></a></td><tr>";
	print "<tr><td align=\"right\">Paypoint Branch:</td><td><input type=\"text\" name=\"TxtBranch\" id=\"TxtBranch\" size=\"25\" maxlength=\"15\" value=\"$bra\">
	</td><tr><tr><td align=\"right\">Item Categories:</td><td><input type=\"text\" name=\"TxtCateg\" id=\"TxtCateg\" size=\"25\" maxlength=\"25\" value=\"$categ\">
	</td><tr><tr><td align=\"right\">Institution Core Value:</td><td><input type=\"text\" name=\"TxtCore\" id=\"TxtCore\" size=\"25\" maxlength=\"20\"
	value=\"$cor\"></td><td rowspan=\"3\" valign=\"middle\"><a href=\"sysgroup.php?action=0-0\"><button name=\"CmdClose\" type=\"button\">Close Form</button></a></td><tr></table>";
?>
</form>
Enter only the field(s) you want to add. The rest of the field(s) should be left empty and click <b>Save Grouping Details</b> button or click <b>Close Form</b>
button to cancel operation.
</body>
</html>
