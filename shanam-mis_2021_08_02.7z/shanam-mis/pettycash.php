<?php
	include_once('shanam.php');
	$usn=strtoupper($_SESSION['username'].' ('.$_SESSION['priviledge'].')');
	if (isset($_POST['CmdSave'])){
		$acc=isset($_POST['cboAcc'])?sanitize($_POST['cboAcc']):0;								$payno=isset($_POST['txtPayNo'])?sanitize($_POST['txtPayNo']):0;
		$vono=isset($_POST['txtVNo'])?sanitize($_POST['txtVNo']):1; 							$date=isset($_POST['txtDate'])?$_POST['txtDate']:date('Y-m-d'); 	$date=preg_split("/\-/",$date);
		$idno=isset($_POST['txtIDNo'])?sanitize($_POST['txtIDNo']):null; 					$impno=isset($_POST['txtImp'])?sanitize($_POST['txtImp']):'0-0'; 	$impno=preg_split('/\-/',$impno);
		$payee=isset($_POST['txtPayee'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtPayee']))):''; 		$tkn=sanitize($_POST['txtToken']);
		$add=isset($_POST['txtAddress'])?mysqli_real_escape_string($conn,strtoupper(sanitize($_POST['txtAddress']))):'';	$bankac=isset($_POST['cboBankAC'])?sanitize($_POST['cboBankAC']):0;
		$telno=isset($_POST['txtTelNo'])?sanitize($_POST['txtTelNo']):'';					$email=isset($_POST['txtEMail'])?sanitize($_POST['txtEMail']):'';
		$pytfrm=isset($_POST['cboPytFrm'])?sanitize($_POST['cboPytFrm']):'Cash';	$cheno=isset($_POST['txtCheNo'])?sanitize($_POST['txtCheNo']):null; $cheno=strlen($cheno)>0?$cheno:null;
		$cash=isset($_POST['txtCash'])?sanitize($_POST['txtCash']):0;							$bal=isset($_POST['txtBalance'])?sanitize($_POST['txtBalance']):0;
		$cheque=isset($_POST['txtCheque'])?sanitize($_POST['txtCheque']):0;				$cash=preg_replace("/[^0-9^\.]/","",$cash);	$bankac=strcasecmp($pytfrm,'cash')==0?null:$bankac;
		$cheque=preg_replace("/[^0-9^\.]/","",$cheque);														$bal=preg_replace("/[^0-9^\.]/","",$bal);		$date="$date[2]-$date[1]-$date[0]";
		$rmks=isset($_POST['txtRmks'])?mysqli_real_escape_string($conn,strtoupper(trim(strip_tags($_POST['txtRmks'])))):'BEING PAYMENT OF ';
		if ($acc>0 && strlen($payee)>0 && (($cash+$cheque)>0) && (strlen($rmks)>16 || strcasecmp("being payment of ",$rmks)!=0) && ($bal==0) && ($_SESSION['form_token']==$tkn) &&
		((strcasecmp($pytfrm,"cash")!=0 && $bankac>0 && strlen($cheno)>0) || (strcasecmp($pytfrm,"cash")==0)) && strlen($idno)>5) {
			unset($_SESSION['form_token']);
			if($payno==0){//New payee
				mysqli_query($conn,"INSERT INTO acc_exppayee(payno,regdate,payee,idno,telno,address,email,addedby) VALUES (0,'$date',".var_export($payee,true).",'$idno','$telno',".
				var_export($add,true).",'$email','$usn')");
				if(mysqli_affected_rows($conn)>0) $payno=mysqli_insert_id($conn);
			}$set=false; $i=1;
			while(!$set && ($i<8)){
				if (mysqli_query($conn,"INSERT INTO acc_exp(vono,acsno,pytdate,acc,pytfrm,cheno,caamt,chamt,rmks,expno,addedby) VALUES ('$vono',".var_export($bankac,true).",'$date',$acc,
				'$pytfrm',".var_export($cheno,true).",'$cash','$cheque',".var_export($rmks,true).",$payno,'$usn')") or die(mysqli_error($conn).".	Petty Cash Payment details were not saved. Click
				<a	href=\"pettypyts.php\">Here</a> to try again.</center>")) $set=true; else $vono++;
				$i++;
			}if($set){//expenditure details were saved save votehead
				$sql='';
				if($cash>0) $sql.="INSERT INTO acc_cashflow(cfno,acc,cftype,cfdate,rmks,amt,transtype,transno,addedby) VALUES(0,$acc,1,curdate(),'Petty Cash Payment',$cash,2,$vono,'$usn');";
				if($cheque>0) $sql.="INSERT acc_banking(sno,transdate,bank_type,acsno,cheno,amt,rmks,transtype,transno,addedby) VALUES (0,curdate(),1,$bankac,'$cheno',$cheque,'Petty Cash Payment',
				1,$vono,'$usn');";
				for ($i=1;$i<5;$i++){
					$vote=isset($_POST["cboVote_$i"])?sanitize($_POST["cboVote_$i"]):0;	$amt=isset($_POST["txtAmount_$i"])?sanitize($_POST["txtAmount_$i"]):0;
					$amt=preg_replace('/[^0-9\.]/','',$amt);
					if($vote>0 && $amt>0) $sql.="INSERT INTO acc_pytvotes(vono,acc,voteno,amt) VALUES ($vono,$acc,$vote,$amt);";
				}mysqli_multi_query($conn,$sql) or die(mysqli_error($conn).". Petty Cash Payment votehead details were not saved. Click <a href=\"pettypyts.php\">Here</a> to try again.</center>");
				while(mysqli_next_result($conn)){} header("location:rpts/pv.php?action=$vono-1-$payno-$acc");
			}
		}else{
			print "Sorry, the Petty Cash Payment details had errors.<br>Please ensure all details are correctly entered before saving.<br>Click <a href=\"pettypyts.php\">here</a> to try
			again."; unset($_SESSION['form_token']);
		}exit(1);
	}else{
	 	$_SESSION['form_token']=$form_token=uniqid();
	 	mysqli_multi_query($conn,"SELECT acno,descr FROM acc_voteacs WHERE pyt_assoc=1;SELECT e.voteno,a.acno,v.expdescr,e.curest,if(isnull(p.exp),0,p.exp) as cost, if(isnull(i.inco),0,i.inco)
		as income FROM acc_fyestimates e INNER JOIN acc_votes v ON (e.voteno=v.sno) Inner Join acc_voteacs a On (v.acc=a.acno) LEFT JOIN (SELECT voteno,acc,sum(amt) as inco FROM acc_incovotes i
		GROUP BY markdel,acc,voteno HAVING markdel=0)i ON (e.voteno=i.voteno and a.acno=i.acc) LEFT JOIN (SELECT p.voteno,p.acc,sum(p.amt) as exp FROM acc_pytvotes p GROUP BY p.markdel,
    p.acc,p.voteno HAVING markdel=0)p ON (e.voteno=p.voteno and a.acno=p.acc) WHERE a.stud_assoc=1 and e.finyr IN (SELECT finyr FROM ss) UNION SELECT e.voteno,a.acno,v.expdescr,e.curest,
		if(isnull(p.exp),0,p.exp) as cost, if(isnull(i.inco),0,i.inco) as income FROM acc_fyestimates e INNER JOIN acc_votes v ON (e.voteno=v.sno) Inner Join acc_voteacs a On (v.acc=a.acno)
		LEFT JOIN (SELECT voteno,acc,sum(amt) as inco FROM acc_fsevotes i GROUP BY markdel,acc,voteno HAVING markdel=0)i ON (e.voteno=i.voteno and a.acno=i.acc) LEFT JOIN (SELECT p.voteno,
		p.acc,sum(p.amt) as exp FROM acc_pytvotes p GROUP BY p.markdel,p.acc,p.voteno HAVING markdel=0)p ON (e.voteno=p.voteno and a.acno=p.acc) WHERE a.govt_assoc=1 and e.finyr IN (SELECT
		finyr FROM ss) Order By voteno ASC; SELECT a.acsno,(a.bankbalbf+if(isnull(b.bal),0,b.bal)) as amt FROM acc_acbalbf a Left Join (SELECT acsno,sum(if(bank_type=0,amt,0)-if(bank_type=1,
		amt,0)) as bal FROM acc_banking Group By markdel,acsno HAVING markdel=0)b USING (acsno) GROUP BY a.bankbalbf,a.acsno ORDER BY a.acsno; SELECT a.acc,(a.cashbalbf+if(isnull(b.amt),0,
		b.amt)) as amt FROM acc_votebalbf a Left Join (SELECT acc,(sum(if(cftype=0,amt,0))-sum(if(cftype=1,amt,0))) as amt FROM acc_cashflow GROUP BY acc,markdel HAVING markdel=0)b USING (acc)
		GROUP BY a.acc,a.cashbalbf;"); $optacc=$lstvotes=$lstcashbal=$lstbankbal=''; $i=0;
		do{
			if($rs=mysqli_store_result($conn)){
				if($i==0){if(mysqli_num_rows($rs)>0) while($da=mysqli_fetch_row($rs)) $optacc.="<option value=\"$da[0]\">$da[1]</option>";
				}elseif($i==1){$c=0; while($d=mysqli_fetch_row($rs)){$lstvotes.=($c==0?"":",")."new Voteheads($d[0],$d[1],'$d[2]',$d[3],$d[5],$d[4])"; $c++;}
				}elseif($i==2){$c=0; while($d=mysqli_fetch_row($rs)){$lstbankbal.=($c==0?"":",")."new BankBal($d[0],$d[1])"; $c++;}
				}else{$c=0; while($d=mysqli_fetch_row($rs)){$lstcashbal.=($c==0?"":",")."new CashBal($d[0],$d[1])"; $c++;}} mysqli_free_result($rs);
			}$i++;
		}while(mysqli_next_result($conn));
	}	headings('<link rel="stylesheet" href="/date/tcal.css"><link rel="stylesheet" href="tpl/css/inputsettings.css">',0,0,2)
?>
<div class="container divmain"><form method="post" action="pettycash.php" onsubmit="return validateFormOnSubmit(this);" name="FrmPettyPyts">
	<input type="hidden" name="txtToken" value="<?php echo $form_token;?>">
	<div class="form-row"><div class="col-md-12 divheadings">DETAILS OF THE PETTY CASH PAYMENT</div></div>
	<div class="form-row">
		<div class="col-md-3"><label for="cboAcc">A/C Payment Incurred</label><SELECT name="cboAcc" id="cboAcc" size="1" class="modalinput" onchange="loadVoteBal(this)"><option
		value="0">Select A/C</option><?php echo $optacc;?></SELECT></div>
		<div class="col-md-3"><label for="txtVNo">Voucher No.</label><input type="text" name="txtVNo" id="txtVNo" class="modalinput" maxlength="4" readonly value="" placeholder="Auto"></div>
		<div class="col-md-4"></div><div class="col-md-2"><label for="txtDate">Paid On</label><INPUT name="txtDate" id="txtDate" class="tcal modalinput" maxlength="10" readonly value="<?php
		echo date('d-m-Y');?>"></div>
	</div><div class="form-row"><div class="col-md-12 divlrborder" style="background-color:#40a8c4;">
		<div class="form-row">
			<div class="col-md-3"><label for="txtIDNo">ID No.</label><input type="text" name="txtIDNo" id="txtIDNo" class="modalinput" maxlength="10" value="" placeholder="0000000"
				onchange="loadPayee(this)" onkeyup="checkInput(this)"><input name="txtPayNo" id="txtPayNo" type="hidden" value="0"></div>
			<div class="col-md-9"><label for="txtPayee">Name of Payee</label><input type="text" name="txtPayee" id="txtPayee" class="modalinput" maxlength="40" value="" placeholder="Namatsi"
				onkeyup="checkNames(this)" readOnly></div>
		</div><div class="form-row">
			<div class="col-md-3"><label for="txtTelNo">Tel. No.</label><input type="text"	name="txtTelNo" id="txtTelNo" class="modalinput" maxlength="13" value="" placeholder="0712609945"
				 onkeyup="checkInput(this)" readOnly></div>
			<div class="col-md-6"><label for="txtAddress">Address of Payee</label><input type="text" name="txtAddress" id="txtAddress" class="modalinput" maxlength="75" value="P.O Box "
	 				readOnly></div>
			<div class="col-md-3"><label for="txtEMail">E - Mail Address</label><input type="text"	name="txtEMail" id="txtEMail" class="modalinput" maxlength="50" value="" readOnly
						placeholder="someone@somewebsite.com"	style="text-transform:lowercase;"></div>
		</div></div>
	</div><div class="form-row">
		<div class="col-md-3"><label for="cboPytFrm">Mode of Payment</label><SELECT name="cboPytFrm" id="cboPytFrm" size="1" class="modalinput" onchange="checkMode(this)"><option selected
			value="Cash">Cash</option><option value="Cheque">Cheque</option><option value="Cash+Cheque">Cash + Cheque</option></select></div>
		<div class="col-md-6"><label for="cboBankAC">Bank A/C Debited</label><span id="spBanks"><SELECT name="cboBankAC" id="cboBankAC" size="1" class="modalinput" onchange="showBankBal(this)"
			disabled><option value="0" selected>Choose Bank A/C</option></SELECT></span></div>
		<div class="col-md-3"><label for="txtCheNo">Cheque Number</label><input name="txtCheNo" id="txtCheNo" class="modalinput" maxlength="7" onkeyup="checkInput(this)" value="" readonly></div>
	</div><div class="form-row">
		<div class="col-md-3 divsubheading"><label for="txtCashHand" style="border-bottom:1px solid #fff;">Current Cash at Hand</label><input type="text" name="txtCashHand" id="txtCashHand"
			class="modalinput numbersinput modalinputdisabled" maxlength="10" value="0.00" readonly></div>
		<div class="col-md-3 divsubheading"><label for="txtCashBank" style="border-bottom:1px solid #fff;">Current Cash at Bank</label><input type="text" name="txtCashBank" id="txtCashBank"
			class="modalinput numbersinput modalinputdisabled"	maxlength="10" readonly value="0.00" readonly></div>
		<div class="col-md-2"><label for="txtCash">Cash Amount</label><input type="text" name="txtCash" id="txtCash" class="modalinput numbersinput" maxlength="10"
		onkeyup="checkInput(this)" onChange="sumPaid(0,0)" value="0.00" placeholder="KShs. 0.00"></div>
		<div class="col-md-2"><label for="txtCheque">Cheque Amount</label><input type="text" name="txtCheque" id="txtCheque" class="modalinput numbersinput" maxlength="10" readonly
		onkeyup="checkInput(this)" onChange="sumPaid(0,1)" value="0.00" placeholder="KShs. 0.00"></div>
		<div class="col-md-2 divsubheading"><label for="txtTotal" style="border-bottom:1px solid #fff;">Total Amount</label><input name="txtTotal" id="txtTotal" class="modalinput
			numbersinput modalinputdisabled" maxlength="10" onkeyup="checkInput(this)" readonly value="0.00"></div>
	</div>
	<div class="form-row">
		<div class="col-md-12"><label for="txtCash">Narration of Pettycash Payment</label><Textarea name="txtRmks" id="txtRmks" class="modalinput" rows="2" maxlength="250"
			placeholder="BEING PAYMENT FOR ">BEING PAYMENT FOR </textarea></div>
	</div><div class="form-row"><div class="col-md-12 divheadings">DETAILS OF VOTEHEAD DISTRIBUTION</div></div>
	<div class="form-row"><div class="col-md-12 divlrborder" style="background-color:#40a8c4;">
		<div class="form-row">
			<div class="col-md-3 divsubheading">Votehead Description</div><div class="col-md-2 divsubheading">Budget</div><div class="col-md-2 divsubheading">Vote's Income</div><div
			class="col-md-2 divsubheading">Running Cost</div><div class="col-md-2 divsubheading">Amount Available</div><div class="col-md-1 divsubheading">Vote Amt</div>
		</div>
		<?php
			for ($i=1;$i<5;$i++) print "<div class=\"form-row\"><div class=\"col-md-3\"><SELECT name=\"cboVote_$i\" id=\"cboVote_$i\" size=\"1\" onchange=\"assignAmts($i)\" ".
			($i==1?"":"disabled")." class=\"modalinput\"></SELECT></div><div class=\"col-md-2\"><input name=\"txtBudget_$i\" Id=\"txtBudget_$i\" class=\"modalinput modalinputdisabled
			numbersinput\" maxlength=\"10\" value=\"0.00\" readonly></div><div class=\"col-md-2\"><input name=\"txtIncome_$i\" Id=\"txtIncome_$i\" class=\"modalinput numbersinput
			modalinputdisabled\" maxlength=\"10\" value=\"0.00\"></div><div class=\"col-md-2\"><input name=\"txtCost_$i\" Id=\"txtCost_$i\" class=\"modalinput numbersinput modalinputdisabled\"
			maxlength=\"10\" value=\"0.00\"></div><div class=\"col-md-2\"><input name=\"txtAvailable_$i\" Id=\"txtAvailable_$i\"  class=\"modalinput numbersinput modalinputdisabled\"
			maxlength=\"10\" value=\"0.00\"></div> <div class=\"col-md-1\"><input name=\"txtAmount_$i\" Id=\"txtAmount_$i\" maxlength=\"10\" value=\"0.00\"  class=\"modalinput numbersinput\"
			onKeyUp=\"checkInput(this)\" onChange=\"checkCompute($i)\" ".($i==1?"":"disabled")."></div></div>";
		?></div></div>
	<div class="form-row">
		<div class="col-md-4"><label for="txtCosted">Amount Distributed</label><input class="numbersinput modalnoinput" name="txtCosted" id="txtCosted" maxlength="10"
		value="0.00" readonly></div><div class="col-md-4"></div>
		<div class="col-md-4"><label>Balance to be Distributed</label><input name="txtBalance" id="txtBalance" class="numbersinput modalnoinput" maxlength="10" value="0.00" readonly></div>
	</div><hr>
	<div class="form-row">
		<div class="col-md-4"><button type="submit" name="CmdSave" id="CmdSave" class="btn btn-primary btn-md btn-block">Save Pettycash PV</button></div><div class="col-md-4"></div>
		<div class="col-md-4" style="text-align:right"><button type="button" name="cmdClose" onclick="window.open('pettypyts.php','_self')" class="btn btn-info btn-md">Close/ Cancel</button>
		</div>
	</div>
</form></div>
<script type="text/javascript" src="/date/tcal.js"></script><script type="text/javascript" src="tpl/js/pettycash.js"></script>
<script type="text/javascript"><?php
	if(strlen($lstvotes)>0) echo "voteheads.push($lstvotes);";		if(strlen($lstbankbal)>0) echo "bankbal.push($lstbankbal);";
	if(strlen($lstcashbal)>0) echo "cashbal.push($lstcashbal);";
?></script>
<?php mysqli_close($conn); footer();?>
