<?php
	/** Error reporting */
	error_reporting(E_ALL);
	ini_set('display_errors', true);
	ini_set('display_startup_errors', TRUE);
	define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');
	/** Include PHPExcel */
	require_once '../../classes/PHPExcel.php';
	require_once '../../classes/PHPExcel/IOFactory.php';
	include_once('../../conn/pri_sch_connect.inc');
	$salno=isset($_REQUEST['salno'])?trim($_REQUEST['salno']):'0-0'; 		$salno=preg_split('/\-/',$salno);
	$rs=mysqli_query($conn,"SELECT sal_month,sal_year FROM acc_salaries WHERE salno LIKE '$salno[0]'");  list($mon,$yr)=mysqli_fetch_row($rs); mysqli_free_result($rs);
	$rs=mysqli_query($conn,"SELECT scnm,scadd,principal,nssfno,nhifno,emppin FROM ss;"); $sch=mysqli_fetch_row($rs);	mysqli_free_result($rs);
	// Create new PHPExcel object
	$objPHPExcel = new PHPExcel();
	// Set document properties
	$objPHPExcel->getProperties()	->setCreator("Accounts MIS")		->setLastModifiedBy("Shanam Digital Solutions")		->setTitle($mon." ".$yr." $salno[1] Monthly Remmitance")
									->setSubject("Remmitance")	->setDescription("Salary Remmitance")
								 	->setKeywords("Remmitance")		->setCategory("Remmitance");
	$cols=1; $code='';//number of columns with amount fields
	if (strcasecmp("nssf",$salno[1])==0) {
		$dedname="N . S . S . F"; $code=$sch[3];
		$dedno="s.idno,sd.nssfno";
		$sql="(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1) as gsal,(sp.nssffee1+sp.empnssf) as std, sp.nssfvol1, (sp.nssfvol1+
		sp.nssffee1+sp.empnssf) as amt";		$cols=4;
	}elseif (strcasecmp("nhif",$salno[1])==0) {
		$dedname="N . H . I . F";  $code=$sch[4]; $cols=2;
		$dedno="s.idno,sd.nhifno";
		$sql="(sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1) as gsal,sp.nhiffee1 as amt";
	}elseif (strcasecmp("tax",$salno[1])==0) {
		$dedname="P . A . Y . E";  $code=$sch[5]; $cols=5;
		$dedno="s.idno, s.pin";
		$sql="sp.empnssf, (sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1) as gsal, sp.paye1, sp.mpr1, (sp.paye1-sp.mpr1) as amt";
	}elseif (strcasecmp("union",$salno[1])==0) {
		$dedname="Worker's Union";
		$dedno="s.idno,sd.unionno";
		$sql="sp.union1 as amt";
	}elseif (strcasecmp("advance",$salno[1])==0) {
		$dedname="Salary Advance";
		$dedno="sd.idno,s.pin";
		$sql="sp.advance as amt";
	}elseif (strcasecmp("sacco",$salno[1])==0) {
		$dedname="S.A.C.C.O";
		$dedno="s.idno,sd.saccono";
		$sql="sp.sacco1 as amt";
	}elseif (strcasecmp("helb",$salno[1])==0) {
		$dedname="H . E . L . B";
		$dedno="s.idno,s.pin";
		$sql="sp.helb1 as amt";
	}elseif (strcasecmp("welfare",$salno[1])==0) {
		$dedname="Workers's Welfare";
		$dedno="s.idno,sd.welfareno";
		$sql="sp.welfare1 as amt";
	}else {
		$dedname="Other Deductions";
		$dedno="s.idno,s.pin";
		$sql="sp.otherlevies1 as amt";
	}
	$sql="SELECT (@row_num:=@row_num+1) As Nos, s.* FROM (SELECT DISTINCT $dedno,sd.payrollno,concat(s.surname,' ',s.onames) as nam,s.dob,$sql FROM stf s Inner Join acc_saldef sd USING
	(idno) Inner Join acc_salpyt sp ON (sd.payrollno=sp.payrollno) Inner Join acc_salaries sa On sp.salno=sa.salno WHERE (sa.salno LIKE '$salno[0]') ORDER BY s.surname,s.onames)s,(SELECT
	@row_num :=0)x WHERE amt>0";
	$rsSalPay=mysqli_query($conn,$sql);
	// Add some data
	$styleArray=array('borders'=>array('allborders'=>array('style'=>PHPExcel_Style_Border::BORDER_THIN)));
	$objPHPExcel->getActiveSheet()->mergeCells('A5:A6') ->mergeCells('B5:F5');
		if (strcasecmp("nhif",$salno[1])==0) $objPHPExcel->getActiveSheet()->mergeCells('G5:H5');
		elseif (strcasecmp("PAYE",$salno[1])==0) $objPHPExcel->getActiveSheet()->mergeCells('G5:K5');
		elseif (strcasecmp("nssf",$salno[1])==0) $objPHPExcel->getActiveSheet()->mergeCells('G5:J5');
		else $objPHPExcel->getActiveSheet()->mergeCells('G5:G5');
	$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A1', $sch[0])   ->setCellValue('A2', $sch[1]) ->setCellValue('F5', 'DATE :'.date("D d M, Y"))
				->setCellValue('A3', "EMPLOYERS' ".strtoupper($dedname)." CODE: $code")   ->setCellValue('A4', "MONTH OF REMMITANCE: ".strtoupper($mon." ".$yr))
				->setCellValue('A5', 'S/N')				->setCellValue('B5', 'STAFF MEMBERS DETAILS')	->setCellValue('G5', 'AMOUNTS')
	            ->setCellValue('B6',  'ID NO.')			->setCellValue('C6',  ((strcasecmp("tax",$salno[1])==0 || strcasecmp("advance",$salno[1])==0 || strcasecmp("helb",$salno[1])==0 ||
				strcasecmp("ole",$salno[1])==0)?"PIN No.":($dedname." No.")))    ->setCellValue('D6',  'P/F NO.')	->setCellValue('E6',  'NAMES')	->setCellValue('F6',  'DATE OF BIRTH');
	if (strcasecmp("welfare",$salno[1])==0 || strcasecmp("advance",$salno[1])==0 || strcasecmp("helb",$salno[1])==0 || strcasecmp("ole",$salno[1])==0 || strcasecmp("union",$salno[1])==0
	|| strcasecmp("sacco",$salno[1])==0){
	 	$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G6',  'AMOUNT REMITTED');
	 	$tamt[0]=0; $objPHPExcel->setActiveSheetIndex(0)->getStyle('A5:G6')->getFont()->getColor()->setARGB('0000FF');
	 	$objPHPExcel->getActiveSheet()->getStyle('A5:G6')->applyFromArray(array('fill' => array('type'=>PHPExcel_Style_Fill::FILL_SOLID,'color'=>array('argb'=>'FFCCFFCC'))));
	}elseif (strcasecmp("nhif",$salno[1])==0){
	 	$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G6',  'GROSS SALARY')->setCellValue('H6',  'AMOUNT REMITTED');
	 	$objPHPExcel->setActiveSheetIndex(0)->getStyle('A5:H6')->getFont()->getColor()->setARGB('0000FF');$tamt=array(0,0,0);
		$objPHPExcel->getActiveSheet()->getStyle('A5:H6')->applyFromArray(array('fill' => array('type'=>PHPExcel_Style_Fill::FILL_SOLID,'color'=>array('argb'=>'FFCCFFCC'))));
	}elseif (strcasecmp("nssf",$salno[1])==0){
	 	$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G6','GROSS SALARY')->setCellValue('H6','STANDARD')->setCellValue('I6','VOLUNTARY')->setCellValue('J6','AMOUNT REMITTED');
	 	$objPHPExcel->setActiveSheetIndex(0)->getStyle('A5:J6')->getFont()->getColor()->setARGB('0000FF'); $tamt=array(0,0,0,0);
	 	$objPHPExcel->getActiveSheet()->getStyle('A5:J6')->applyFromArray(array('fill' => array('type'=>PHPExcel_Style_Fill::FILL_SOLID,'color'=>array('argb'=>'FFCCFFCC'))));
	}else{
	 	$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G6','N.S.S.F') ->setCellValue('H6','GROSS SALARY')->setCellValue('I6','PAYABLE PAYE')->setCellValue('J6','MPR')
		->setCellValue('K6',  'AMOUNT REMITTED');
	 	$objPHPExcel->setActiveSheetIndex(0)->getStyle('A5:K6')->getFont()->getColor()->setARGB('0000FF'); $tamt=array(0,0,0,0,0);
	 	$objPHPExcel->getActiveSheet()->getStyle('A5:K6')->applyFromArray(array('fill' => array('type'=>PHPExcel_Style_Fill::FILL_SOLID,'color'=>array('argb'=>'FFCCFFCC'))));
	} 	$i=0;
	$rsSal=mysqli_query($conn,"SELECT (@rowno:=@rowno+1)as nos,s.* FROM (SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,sd.ACCOUNTNO,substring(sp.paypoint,
	(locate('-',sp.paypoint)+1)) as bb,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1+sp.empnssf)-(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-
	sp.mpr1)+sp.welfare1+sp.otherlevies1+sp.union1+sp.empnssf+sp.sacco1+sp.nssfvol1+sp.helb1)) AS NetSalary FROM stf s INNER JOIN acc_saldef sd USING (idno) INNER JOIN acc_salpyt sp
	On (sd.payrollno=sp.payrollno) INNER JOIN acc_salaries sa ON (sp.salno=sa.SalNo) WHERE (sp.markdel=0 and sp.salno LIKE '$salno[0]' AND sp.paypoint LIKE '$salno[1]%') ORDER BY
	s.SurName,s.onames ASC)s,(SELECT @rowno:=0)X");
	//Load data into cells
	$ro=7;
	if (mysqli_num_rows($rsSalPay)>0){
		if (strcasecmp("welfare",$salno[1])==0 || strcasecmp("advance",$salno[1])==0 || strcasecmp("helb",$salno[1])==0 || strcasecmp("ole",$salno[1])==0 ||
		strcasecmp("union",$salno[1])==0 || strcasecmp("sacco",$salno[1])==0){
			while (list($sn,$id,$dno,$pr,$na,$dob,$net)=mysqli_fetch_row($rsSalPay)):
				$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$ro, $sn)	->setCellValue('B'.$ro, $id)	->setCellValue('C'.$ro, $dno) ->setCellValue('D'.$ro, $pr)	->setCellValue('E'.$ro, $na)
					->setCellValue('F'.$ro, date("d-m-Y",strtotime($dob)))		->setCellValue('G'.$ro, $net);
				$tamt[0]+=$net;  $ro++;
			endwhile;
		}elseif (strcasecmp("nssf",$salno[1])==0){
			while (list($sn,$id,$dno,$pr,$na,$dob,$gs,$std,$vol,$amt)=mysqli_fetch_row($rsSalPay)):
				$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$ro, $sn)	->setCellValue('B'.$ro, $id)	->setCellValue('C'.$ro, $dno) ->setCellValue('D'.$ro, $pr)	->setCellValue('E'.$ro, $na)
					->setCellValue('F'.$ro, date("d-m-Y",strtotime($dob)))		->setCellValue('G'.$ro, $gs)  ->setCellValue('H'.$ro, $std) ->setCellValue('I'.$ro, $vol)
					->setCellValue('J'.$ro, $amt);
				$tamt[0]+=$gs;  $tamt[1]+=$std;  $tamt[2]+=$vol;  $tamt[3]+=$amt;  $ro++;
			endwhile;
		}elseif (strcasecmp("nhif",$salno[1])==0){
			while (list($sn,$id,$dno,$pr,$na,$dob,$gs,$amt)=mysqli_fetch_row($rsSalPay)):
				if (($i%2)==0) print "<tr>"; else print "<tr bgcolor=\"#eeeeee\">";
				$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$ro, $sn)	->setCellValue('B'.$ro, $id)	->setCellValue('C'.$ro, $dno) ->setCellValue('D'.$ro, $pr)	->setCellValue('E'.$ro, $na)
					->setCellValue('F'.$ro, date("d-m-Y",strtotime($dob)))		->setCellValue('G'.$ro, $gs)  ->setCellValue('H'.$ro, $amt);
				$tamt[0]+=$gs;  $tamt[1]+=$amt;  $ro++;
			endwhile;
		}else{
			while (list($sn,$id,$dno,$pr,$na,$dob,$nss,$gs,$paye,$mpr,$amt)=mysqli_fetch_row($rsSalPay)):
				$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$ro, $sn)	->setCellValue('B'.$ro, $id)	->setCellValue('C'.$ro, $dno) ->setCellValue('D'.$ro, $pr)	->setCellValue('E'.$ro, $na)
					->setCellValue('F'.$ro, date("d-m-Y",strtotime($dob)))		->setCellValue('G'.$ro, $nss)  ->setCellValue('H'.$ro, $gs) ->setCellValue('I'.$ro, $paye)
					->setCellValue('J'.$ro, $mpr)	->setCellValue('K'.$ro, $amt);
				$tamt[0]+=$nss;  $tamt[1]+=$gs;  $tamt[2]+=$paye;  $tamt[3]+=$mpr;  $tamt[4]+=$amt;  $ro++;
			endwhile;
		}
	}else{
		$objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro, 'No Remmitence submitted during this month'); $ro++;
	}
	$objPHPExcel->getActiveSheet()->mergeCells('A'.$ro.':F'.$ro)
				->getStyle('G7:K'.$ro)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
	$objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro, 'Total');
	if (strcasecmp("nhif",$salno[1])==0) $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$ro, $tamt[0]) ->setCellValue('H'.$ro, $tamt[1]);
	elseif (strcasecmp("tax",$salno[1])==0) $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$ro, $tamt[0])->setCellValue('H'.$ro, $tamt[1]) ->setCellValue('I'.$ro, $tamt[2])
	->setCellValue('J'.$ro, $tamt[3]) ->setCellValue('K'.$ro, $tamt[4]);
	elseif (strcasecmp("nssf",$salno[1])==0) $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$ro, $tamt[0])->setCellValue('H'.$ro, $tamt[1]) ->setCellValue('I'.$ro, $tamt[2])
	->setCellValue('J'.$ro, $tamt[3]);
	else $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$ro, $tamt[0]);
	if (strcasecmp("nhif",$salno[1])==0) $objPHPExcel->getActiveSheet()->getStyle('A5:H'.$ro)->applyFromArray($styleArray);
	elseif (strcasecmp("tax",$salno[1])==0) $objPHPExcel->getActiveSheet()->getStyle('A5:K'.$ro)->applyFromArray($styleArray);
	elseif (strcasecmp("nssf",$salno[1])==0) $objPHPExcel->getActiveSheet()->getStyle('A5:J'.$ro)->applyFromArray($styleArray);
	else $objPHPExcel->getActiveSheet()->getStyle('A5:G'.$ro)->applyFromArray($styleArray);
	$objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.($ro+2), 'Thank You.')	->setCellValue('A'.($ro+3), 'Yours Faithfully,')	->setCellValue('A'.($ro+6), $sch[2]);
	$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B Shanam\'s Digital Solutions ' . '&RPage &P of &N');
	// Set active sheet index to the first sheet, so Excel opens this as the first sheet
	$objPHPExcel->setActiveSheetIndex(0);
	// Save Excel 2007 file
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save($mon.'_'.$yr.'_'.$salno[1].'_Ded.xlsx');
	//$objWriter->save('php://output');
	print "Successfully saved to the server. Click <a href=\"$mon"."_"."$yr"."_"."$salno[1]"."_"."Ded.xlsx\" download=\"$mon"."_"."$yr"."_"."$salno[1]"."_"."Ded.xlsx\">Here</a> to download.
	<br> Click <a href=\"../rpts/payrolldedrpts.php?salno=$salno[0]-$salno[1]\">here</a> to go back.";
?>
