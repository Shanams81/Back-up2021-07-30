<?php
	/** Error reporting */
	error_reporting(E_ALL); ini_set('display_errors', TRUE);	ini_set('display_startup_errors', TRUE);	define('EOL',(PHP_SAPI == 'cli')?PHP_EOL:'<br/>');
	/** Include PHPExcel */
	require_once('../../classes/PHPExcel.php');	require_once('../../classes/PHPExcel/IOFactory.php');	include_once('../../conn/mysqli_connect.inc.tpl');
	function addressbyrowcol($row,$col){return PHPExcel_Cell::stringFromColumnIndex($col).$row;}
	$objPHPExcel = new PHPExcel();
	// Set document properties
	$objPHPExcel->getProperties()->setCreator("Accounts MIS")->setLastModifiedBy("Shanam's Digital Solutions")	 ->setTitle("Fee Register")		 ->setSubject("Fee Register")
							->setDescription("Fee Register")			 ->setKeywords("Fee Register")						 ->setCategory("Fee Register");
	$recno=isset($_REQUEST['rec'])?strip_tags($_REQUEST['rec']):'0-0-0-0'; $recno=explode('-',$recno); //[0]- Class, [1]-Stream, [2]- Adm. No.,[3]-acc
	mysqli_multi_query($conn,"SELECT finyr,scnm FROM ss; SELECT clsname FROM classnames WHERE clsno LIKE '$recno[0]'; SELECT strm FROM grps WHERE strm strm not like '$recno[1]'; SELECT abbr
	FROM acc_voteacs WHERE stud_assoc=1 and markdel=0 and acno LIKE '$recno[3]'");
	$i=0; $scnm=$clsname=$strmname=$accname="";
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0){if(mysqli_num_rows($rs)==1) list($finyr,$scnm)=mysqli_fetch_row($rs); else $yr=date('Y');} elseif($i==1)	list($clsname)=mysqli_fetch_row($rs);
			elseif($i==2) list($strmname)=mysqli_fetch_row($rs); else list($accname)=mysqli_fetch_row($rs); mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	$sql="SELECT s.admno,concat(s.surname,' ',s.onames) As names,concat(cn.clsname,'-',c.stream) As cls,";
	if ($recno[3]==1) $sql.="(c.bbf+if(isnull(f.arr),0,f.arr)) as arr,if(x.acspemed=1,(c.spemed+if(isnull(f.smed),0,f.smed)),0) as spemed,if(x.acunifrm=1,(c.unifrm+if(isnull(f.suni),0,f.suni)),
		0) as uni FROM stud s Inner Join class c USING (admno,curr_year) Inner	Join classnames cn USING (clsno) Inner Join ss ON (s.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,
		sum(f.arrears) as arr,sum(f.spemed) as smed,sum(f.unifrm) as suni FROM acc_incofee i Inner Join acc_incorecno0 f ";
	else $sql.="(c.miscbf+if(isnull(f.arr),0,f.arr)) as arr,if(x.acspemed!=1,(c.spemed+if(isnull(f.smed),0,f.smed)),0) as spemed,if(x.acunifrm!=1,(c.unifrm+if(isnull(f.suni),0,f.suni)),0)
		as uni FROM stud s Inner Join class c USING (admno,curr_year) Inner Join classnames cn USING (clsno) Inner Join ss ON (s.curr_year=ss.finyr) LEFT JOIN (SELECT i.admno,sum(f.arrears)
		as arr,sum(f.spemed) as smed, sum(f.unifrm)	as suni FROM acc_incofee i Inner Join acc_incorecno1 f ";
	if(strcasecmp($recno[2],"%")==0)$sql.="USING (sno) GROUP BY i.admno,f.markdel Having f.markdel LIKE '0')f USING (admno),(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,
	sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM acc_votesassigned)x WHERE c.clsno LIKE '$recno[0]' and c.stream LIKE '$recno[1]' and s.present=1";
	else $sql.="USING (sno) GROUP BY i.admno,f.markdel Having i.admno LIKE '$recno[2]' and f.markdel LIKE '0')f USING (admno),(SELECT sum(case when name='spemed' then acc else 0 end) as acspemed,
	sum(case when name='unifrm' then acc else 0 end) as acunifrm FROM acc_votesassigned)x WHERE s.admno LIKE '$recno[2]' and s.present=1";
	$rsStud=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"home.php\">HERE</a> to go back."); $nostud=mysqli_num_rows($rsStud);
	if (mysqli_num_rows($rsStud)>0){ $ro=0; $ncols=5;
		while (list($admno,$names,$cls,$arr,$spemed,$uni)=mysqli_fetch_row($rsStud)){if($spemed>0) $ncols++; if($uni>0) $ncols++; $start=$ro;
			$rs=mysqli_query($conn,"SELECT v.sno,v.abbr FROM clsfee f Inner Join acc_votes v ON (f.voteno=v.sno) Inner Join ss s ON (f.curr_year=s.finyr) WHERE f.admno='$admno' and v.acc='$recno[3]' ORDER BY v.sno ASC;");
			$f=$paid=''; $novotes=0;
			while ($row=mysqli_fetch_row($rs)){$f.=",sum(if(voteno='$row[0]', f.t3, 0)) as `$row[1]`"; $paid.=",sum(if(v.voteno='$row[0]',v.amt,0)) as `$row[1]`"; $cols[]=$row[1];	$ttl[]=0; $bal[]=0; $novotes++; $ncols++;}
			mysqli_free_result($rs); $rs=mysqli_query($conn,"SELECT admno $f FROM clsfee f Inner Join ss s ON (f.curr_year=s.finyr) GROUP BY admno,curr_year HAVING f.admno LIKE '$admno'");
			$fee=mysqli_fetch_row($rs); mysqli_free_result($rs);
			$styleArray=array('borders'=>array('allborders'=>array('style'=>PHPExcel_Style_Border::BORDER_THIN)));
			$ro++; $start=$ro+1;
			$objPHPExcel->getActiveSheet()->mergeCells('A'.$ro.':B'.$ro) 	->mergeCells('C'.$ro.':H'.$ro) ->mergeCells('I'.$ro.':M'.$ro);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$ro,'ADM. NO. '.$admno) ->setCellValue('C'.$ro,$names) 	->setCellValue('I'.$ro,"FORM/GRADE: ".$cls);
			$ro++; //data
			$objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro, "RECEIPT")	->setCellValue('B'.$ro, "DATE")	->setCellValue('C'.$ro, "MODE") ->setCellValue('D'.$ro, "MODE NO.")
					->setCellValue('E'.$ro, 'ARREARS'); $curcol=5;
			if($spemed>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),"S/ MEDICAL"); $curcol++;}
			if($uni>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),"EXTRA UNIFORM"); $curcol++;}
			foreach($cols as $c){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol), $c); $curcol++;}
		  if($recno[3]==1){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),'PREPAID') ->setCellValue(addressbyrowcol($ro,($curcol+1)), 'REFUND'); $curcol+=2;}
			$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),'BANK CHARGES') ->setCellValue(addressbyrowcol($ro,($curcol+1)), 'TOTAL')
									->setCellValue(addressbyrowcol($ro,($curcol+2)), 'BALANCE'); $curcol+=2;
			$objPHPExcel->setActiveSheetIndex(0) ->getStyle('A'.$ro.':'.addressbyrowcol($ro,($curcol))) ->getFont() ->getColor() ->setARGB('0000FF');
			$objPHPExcel->getActiveSheet()->getStyle('A'.$ro.':'.addressbyrowcol($ro,($curcol)))->applyFromArray(array('fill'=>array('type'=>PHPExcel_Style_Fill::FILL_SOLID,'color'=>array('argb'=>'FFCCFFCC'))));
			$ro++;
			$objPHPExcel->getActiveSheet()->mergeCells('A'.$ro.':D'.$ro) ->getStyle('E'.$ro.':'.addressbyrowcol($ro,($curcol))) ->getNumberFormat() ->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$ro.':'.addressbyrowcol($ro,($curcol)))->applyFromArray(array('fill'=>array('type'=>PHPExcel_Style_Fill::FILL_SOLID,	'color'=>array('argb'=>'FFCCFFCC'))));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$ro,"Fees Expected As On 01, January $finyr") ->setCellValue('E'.$ro,$arr); $curcol=5;
			if($spemed>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol), $spemed); $curcol++;} 	$ttlfee=$arr+$spemed+$uni;
			if($uni>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol), $uni); $curcol++;} $i=0;
			foreach($cols as $c){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$fee[$i+1]); $curcol++; $bal[$i]=$fee[$i+1]; $ttlfee+=$fee[$i+1]; $i++;}
			if($recno[3]==1){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),0)->setCellValue(addressbyrowcol($ro,($curcol+1)),0); $curcol+=2;}
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue(addressbyrowcol($ro,$curcol),0)->setCellValue(addressbyrowcol($ro,($curcol+1)),$ttlfee)->setCellValue(addressbyrowcol($ro,($curcol+2)),$ttlfee); $curcol+=3;
			//data for cells
			$ro++; $sql="SELECT f.recno,i.pytdate,i.pytfrm,i.cheno,f.arrears,f.spemed,f.unifrm $paid,";
			if($recno[3]==1) $sql.="f.prep,f.refunds,f.bc,(f.amt+f.bc-f.transfer) as ttl FROM acc_incofee i Inner Join acc_incorecno0 f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY
			f.recno,i.pytdate,i.pytfrm,i.cheno,f.arrears,f.spemed,f.unifrm,f.amt,f.transfer,f.prep,f.refunds,i.markdel,i.admno ";
			else $sql="f.bc,(f.amt-f.transfer) as ttl FROM acc_incofee i Inner Join acc_incorecno1 f USING (sno) Inner Join acc_incovotes v USING (recno,acc) GROUP BY f.recno,i.pytdate,i.pytfrm,
			i.cheno,f.arrears,f.spemed,f.unifrm,f.amt,f.transfer,i.markdel,i.admno ";
			$sql.="HAVING i.markdel=0 and i.admno LIKE '$admno' ORDER BY f.recno ASC"; $rs=mysqli_query($conn,$sql); $tarr=$tprep=$tref=$tuni=$tsmed=$tpaid=$tbc=0; $nof=mysqli_num_rows($rs);
			if($nof>0){while($da=mysqli_fetch_row($rs)){$i=$a=$b=0;
				$objPHPExcel->setActiveSheetIndex(0)	->setCellValue('A'.$ro, $da[0])	->setCellValue('B'.$ro, date('d-m-Y',strtotime($da[1])))	->setCellValue('C'.$ro, $da[2])
							->setCellValue('D'.$ro, $da[3])	->setCellValue('E'.$ro, $da[4]); $arr-=$da[4]; $tarr+=$da[4]; $curcol=5; $count=2;
				if($spemed>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol), $da[$curcol]); $spemed-=$da[$curcol]; $tsmed+=$da[$curcol]; $curcol++; $count--;}
				if($uni>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$da[$curcol]); $uni-=$da[$curcol]; $tuni+=$da[$curcol]; $curcol++; $count--;} $i=0;
				foreach($cols as $c){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$da[$curcol+$count]); $bal[$i]-=$da[$curcol+$count]; $ttl[$i]+=$da[$curcol+$count]; $curcol++; $i++;}
				if($recno[3]==1){$objPHPExcel->setActiveSheetIndex(0)->setCellValue(addressbyrowcol($ro,$curcol),$da[$curcol+$count])->setCellValue(addressbyrowcol($ro,($curcol+1)),$da[$curcol+1+$count]);
					 $tprep+=$da[$curcol+$count]; $tref+=$da[$curcol+1+$count]; $curcol+=2;// $count+=2;
				}$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$da[$curcol+$count]); $tbc-=$da[$curcol+$count]; $curcol++; $ttlfee-=$da[$curcol+$count]; $tpaid+=$da[$curcol+$count];
				$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$tpaid)->setCellValue(addressbyrowcol($ro,($curcol+1)),$ttlfee);
			}}else{$objPHPExcel->getActiveSheet()->mergeCells('A'.$ro.':K'.$ro); $objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro,'NO FEE PAYMENT FROM THE STUDENT');}mysqli_free_result($rs);
			$ro++; //Total paid
			$objPHPExcel->getActiveSheet()->mergeCells('A'.$ro.':C'.$ro); $objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro, $nof.' Fee Payment Installment(s)')
				->setCellValue('D'.$ro,'Total Paid') ->setCellValue('E'.$ro,$tarr);	$curcol=5;
			if($tsmed>0 || $spemed>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol), $tsmed); $curcol++;}
			if($uni>0 || $tuni>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$tuni); $curcol++;}$i=0;
			foreach($cols as $c){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$ttl[$i]); $curcol++; $i++;}
			if($recno[3]==1){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$tprep) ->setCellValue(addressbyrowcol($ro,($curcol+1)),$tref); $curcol+=2;}
			$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$tbc) ->setCellValue(addressbyrowcol($ro,($curcol+1)),$tpaid) ->setCellValue(addressbyrowcol($ro,($curcol+2)),$ttlfee);
			$ro++; //BALANCE
			$objPHPExcel->getActiveSheet()->mergeCells('A'.$ro.':D'.$ro); $objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro,'Fee Balance') ->setCellValue('E'.$ro,$arr);	$curcol=5;
			if($spemed>0 || $tsmed>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol), $spemed); $curcol++;}
			if($uni>0 || $tuni>0){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$uni); $curcol++;}$i=0;
			foreach($cols as $c){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),$bal[$i]); $curcol++; $i++;}
			if($recno[3]==1){$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),0) ->setCellValue(addressbyrowcol($ro,($curcol+1)),0); $curcol+=2;}
			$objPHPExcel->setActiveSheetIndex(0) ->setCellValue(addressbyrowcol($ro,$curcol),0) ->setCellValue(addressbyrowcol($ro,($curcol+1)),'') ->setCellValue(addressbyrowcol($ro,($curcol+2)),''); $curcol+=2;
			$objPHPExcel->getActiveSheet()->getStyle('A'.$start.':'.addressbyrowcol($ro,$curcol))->applyFromArray($styleArray);
			$objPHPExcel->getActiveSheet()->getStyle('E'.$start.':'.addressbyrowcol($ro,$curcol))->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
			$ro++;	unset($styleArray); unset($ttl); unset($bal); unset($cols);
		}
		$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&B '.$scnm.' &R FY'.$finyr.' - Form '.$clsname.'-'.$strmname.' Fees Register');
		$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B Shanam\'s Digital Solutions ' . '&RPage &P of &N');
		// Set page orientation and size
		$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
		$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
		$objPHPExcel->getActiveSheet()->setTitle('FY'.$finyr.$accname.' Register');
		// Set active sheet index to the first sheet, so Excel opens this as the first sheet
		$objPHPExcel->setActiveSheetIndex(0);
		// Save Excel 2007 file
		$objWriter=PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007'); $objWriter->save('Form'.$clsname.'FY'.$finyr.$accname.'Register.xlsx');
	}if($nostud>0){
		print "Successfully exported $nostud form $clsname-$strmname registers for FY$finyr to the server. <br>Click <a href=\"Form$clsname"."FY$finyr"."$accname"."Register.xlsx\"
		download=\"Form$clsname"."FY$finyr"."$accname"."Register.xlsx\">here</a> download the file,or <br>Click <a href=\"/shanam-mis/feeregister.php\">here</a> to go back ";
	}else print "Sorry, there is no form $clsname-$strmname $accname FY$finyr fee registers. Click <a href=\"/shanam-mis/feeregister.php\">here</a> to go back.";
	mysqli_close($conn);
?>
