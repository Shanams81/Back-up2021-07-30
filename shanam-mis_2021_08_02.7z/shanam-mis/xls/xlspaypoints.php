<?php
	/** Error reporting */
	error_reporting(E_ALL);
	ini_set('display_errors', true);
	ini_set('display_startup_errors', TRUE);
	define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');
	/** Include PHPExcel */
	require_once '../../classes/PHPExcel.php';
	require_once '../../classes/PHPExcel/IOFactory.php';
	include_once('../../conn/pri_sch_connect.inc');
	$salno=isset($_REQUEST['salno'])?trim($_REQUEST['salno']):'0-0'; 		$salno=preg_split('/\-/',$salno);
	mysqli_multi_query($conn,"SELECT sal_month,sal_year FROM acc_salaries WHERE salno LIKE '$salno[0]';SELECT scnm,scadd,principal FROM ss;");  $i=0;
	do{
		if($rs=mysqli_store_result($conn)){
			if($i==0) list($mon,$yr)=mysqli_fetch_row($rs); else $sch=mysqli_fetch_row($rs); mysqli_free_result($rs);
		}$i++;
	}while(mysqli_next_result($conn));
	// Create new PHPExcel object
	$objPHPExcel = new PHPExcel();
	// Set document properties
	$objPHPExcel->getProperties()	->setCreator("Accounts MIS")		->setLastModifiedBy("Shanam Digital Solutions")		->setTitle($mon." ".$yr." $salno[1] Bank Payroll")
							->setSubject("Paypoints")	->setDescription("Salary Paypoint") ->setKeywords("paypoint")	->setCategory("Paypoint");
	// Add some data
	$styleArray=array('borders'=>array('allborders'=>array('style'=>PHPExcel_Style_Border::BORDER_THIN)));
	$objPHPExcel->getActiveSheet()->mergeCells('A5:A6') ->mergeCells('B5:D5')  ->mergeCells('E5:F5')	->mergeCells('G5:G6');
	$objPHPExcel->setActiveSheetIndex(0) 	->setCellValue('A1', $sch[0])   ->setCellValue('A2', $sch[1]) ->setCellValue('A3', strtoupper($mon." ".$yr)." STAFF SALARY")
				->setCellValue('A4',$salno[1]." BANK") ->setCellValue('A5', 'S/N') ->setCellValue('B5', 'STAFF MEMBERS DETAILS')	->setCellValue('E5', 'BANK DETAILS')
	      ->setCellValue('G5','AMOUNT')	->setCellValue('B6','ID NO.')	->setCellValue('C6','PF NO.') ->setCellValue('D6','NAMES')	->setCellValue('E6','A/C NO.')
				->setCellValue('F6','BRANCH');
	$objPHPExcel->setActiveSheetIndex(0)->getStyle('A5:G6')->getFont()->getColor()->setARGB('0000FF');
	$objPHPExcel->getActiveSheet()->getStyle('A5:G6')->applyFromArray(array('fill' => array('type'	=> PHPExcel_Style_Fill::FILL_SOLID,'color'	=> array('argb' => 'FFCCFFCC'))));
	$rsSal=mysqli_query($conn,"SELECT (@rowno:=@rowno+1)as nos,s.* FROM (SELECT s.idno,sd.payrollno,concat(s.surname,' ',s.onames) as st_names,sd.ACCOUNTNO,substring(sp.paypoint,
	(locate('-',sp.paypoint)+1)) as bb,((sp.bsalary+sp.housingallow1+sp.medicalallow1+sp.travelallow1+sp.responsallow1+sp.empnssf)-(sp.nssffee1+sp.nhiffee1+sp.advance+(sp.paye1-
	sp.mpr1)+sp.welfare1+sp.otherlevies1+sp.union1+sp.empnssf+sp.sacco1+sp.nssfvol1+sp.helb1)) AS NetSalary FROM stf s INNER JOIN acc_saldef sd USING (idno) INNER JOIN acc_salpyt sp
	On (sd.payrollno=sp.payrollno) INNER JOIN acc_salaries sa ON (sp.salno=sa.SalNo) WHERE (sp.markdel=0 and sp.salno LIKE '$salno[0]' AND sp.paypoint LIKE '$salno[1]%') ORDER BY
	s.SurName,s.onames ASC)s,(SELECT @rowno:=0)X");
	//Load data into cells
	$ro=7;
	if (mysqli_num_rows($rsSal)>0){
	 	$ttl=0;
		while ($data=mysqli_fetch_row($rsSal)){
			$objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro, $data[0])	->setCellValue('B'.$ro, $data[1])	->setCellValue('C'.$ro, $data[2])
	            ->setCellValue('D'.$ro, $data[3])	->setCellValue('E'.$ro, $data[4])	->setCellValue('F'.$ro, $data[5]) ->setCellValue('G'.$ro, $data[6]);
			$ro++; $ttl+=$data[6];
		}
		$objPHPExcel->getActiveSheet()->mergeCells('A'.$ro.':F'.$ro) ->getStyle('G7:G'.$ro)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
		$objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.$ro, 'Total')	->setCellValue('G'.$ro, $ttl);
	}
	$objPHPExcel->getActiveSheet()->getStyle('A5:G'.$ro)->applyFromArray($styleArray);
	$objPHPExcel->setActiveSheetIndex(0) ->setCellValue('A'.($ro+2), 'Thank You.')	->setCellValue('A'.($ro+3), 'Yours Faithfully,')	->setCellValue('A'.($ro+6), $sch[2]);
	$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B Shanam\'s Digital Solutions ' . '&RPage &P of &N');

	// Set active sheet index to the first sheet, so Excel opens this as the first sheet
	$objPHPExcel->setActiveSheetIndex(0);
	// Save Excel 2007 file
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save($mon.'-'.$yr.'-'.$salno[1].'-PP.xlsx');
	//$objWriter->save('php://output');
	print "Successfully saved to the server. Click <a href=\"$mon-$yr-$salno[1]-PP.xlsx\" download=\"$mon-$yr-$salno[1]-PP.xlsx\">Here</a> to download.<br> Click <a
	href=\"../rpts/payrollpp.php?salno=$salno[0]-$salno[1]\">here</a> to go back.";
?>
