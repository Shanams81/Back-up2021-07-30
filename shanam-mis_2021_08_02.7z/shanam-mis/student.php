<?php
    include_once('shanam.php');
    if (isset($_POST['CmdAddStud'])){header ("location:studadd.php"); exit(0);
    }else{
        $action=isset($_REQUEST['action'])?$_REQUEST['action']:"0-0"; $action=preg_split('/\-/',$action);
        //feedbacks
        $cls=isset($_POST['cboClass']) ? strip_tags($_POST['cboClass']):"%";  $st=isset($_POST['cboStream']) ? strip_tags($_POST['cboStream']):"%"; $lvl=isset($_POST['cboLvl']) ? strip_tags($_POST['cboLvl']):"%";
        $sortby=isset($_POST['radSort']) ? $_POST['radSort']:"admno";	         $sortby=strcasecmp($sortby,"stud_names")==0?"s.surname,s.onames":$sortby;
        mysqli_multi_query($conn,"SELECT finyr FROM ss;SELECT g.studadd,g.studedit,g.studdel,g.studview,p.struedit,p.feeedit FROM gen_priv g Inner Join acc_priv p USING (uname) WHERE uname LIKE '".$_SESSION['username']."';
        SELECT count(s.admno) as nos FROM stud s Inner Join ss ON (s.curr_year=ss.finyr) GROUP BY s.present,s.markdel,s.type,s.curr_year HAVING s.present=1 and s.markdel=0 and s.type=0; SELECT lvlno,lvlname FROM classlvl
        ORDER BY lvlno ASC; SELECT clsno,clsname,lvlno FROM classnames ORDER BY clsno ASC; SELECT strm FROM grps WHERE strm is not null or strm not like '';") or die(mysqli_error($conn).'. Click <a
        href=\"pupil_manager.php\">HERE</a> to go back.'); $canadd=$canedit=$fee=$candel=$canviu=$stredit=$fee=$i=$nos=0; $optcls=$optstrm=$optlvl='<option value="%" selected>All</option>'; $lvlname=$lstcls='';
        do{
          if($rs=mysqli_store_result($conn)){
            if($i==0){if(mysqli_num_rows($rs)>0)list($yr)=mysqli_fetch_row($rs); else $yr=date('Y');
            }elseif($i==1){if(mysqli_num_rows($rs)>0) list($canadd,$canedit,$candel,$canviu,$stredit,$fee)=mysqli_fetch_row($rs);
            }elseif($i==2){if(mysqli_num_rows($rs)>0) list($nos)=mysqli_fetch_row($rs);
            }elseif($i==3){while($d=mysqli_fetch_row($rs)){$optlvl.="<option value=\"$d[0]\" ".(strcasecmp($d[0],$lvl)==0?"selected":"").">$d[1]</option>"; if(strcasecmp($d[0],$lvl)==0) $lvlname=$d[1];}
            }elseif($i==4){$c=0; while($d=mysqli_fetch_row($rs)){$optcls.=(($d[2]==$lvl || $lvl=="%")?"<option value=\"$d[0]\" ".(strcasecmp($d[0],$cls)==0?"selected":"").">$d[1]</option>":"");
              $lstcls.=($c==0?"":",")."new ClassName($d[0],'$d[1]',$d[2])"; $c++;}
            }else{while($d=mysqli_fetch_row($rs)) $optstrm.="<option value=\"$d[0]\" ".(strcasecmp($d[0],$st)==0?"selected":"").">$d[0]</option>";} mysqli_free_result($rs);
          }$i++;
        }while(mysqli_next_result($conn));  if($canviu==0){header("Location:vague.php"); exit(0);}
    } headings('<link href="tpl/css/headers.css" rel="stylesheet" />',$action[0],$action[1],2);
?><div class="head"><form method="post" action="student.php"><a href="pupil_manager.php"><img src="img/ani_back.gif" hspace="1" width="45" height="20" align="left"></a>&nbsp;<label for="cboLvl">Show </label><SELECT
  name="cboLvl" id="cboLvl" size="1" onchange="showClass(this)"><?php echo $optlvl;?></SELECT> <label  for="form"> Grade/Form </label>&nbsp;&nbsp;<select name="cboClass" id="cboClass" size="1" id="form">
  <?php echo $optcls;?></select> - <select name="cboStream" size="1" id="stream"><?php echo $optstrm;?></select> Students and Sort By: <input type="radio" name="radSort" id="radSort" value="admno">Adm. No. OR &nbsp;
  <input type="radio" name="radSort" value="stud_names" checked>Names&nbsp; <button type="submit" name="Stud" class="btn btn-warning btn-md">Show Students</button>&nbsp;&nbsp; <button type="submit" name="CmdAddStud"
  class="btn btn-warning btn-md" <?php echo ((($canadd==0) || $nos>499)?"Disabled":"");?>">Admit a Student</button></form></div>
  <?php
    if (isset($_POST['Stud'])):
        if (strcasecmp($cls,"%")==0 && strcasecmp($st,"%")==0) $h="All $lvlname Students in the academic Year $yr - As on ".date("D d M, Y");
        elseif (strcasecmp($cls,"%")!=0 && strcasecmp($st,"%")==0) $h="All $lvlname Students in Form/Grade $cls of academic Year $yr - As on ".date("D d M, Y");
        elseif (strcasecmp($cls,"%")==0 && strcasecmp($st,"%")!=0) $h="All $lvlname Students in stream $st of academic Year $yr - As on ".date("D d M, Y");
        else $h="Form/Grade $cls - $st $lvlname students in the academic Year $yr - As on ".date("D d M, Y");
        $sql="SELECT s.`admno`,s.nemisno,concat(s.surname,' ',s.onames) as `stud_names`,concat(c.`clsname`,'-',sf.`stream`) As frm,s.dob,s.admdate,s.guardian,s.relation,s.telno FROM stud s Left Join class sf USING
        (admno,curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) WHERE sf.lvlno LIKE '$lvl' and s.type=0 and (sf.clsno LIKE '$cls' or sf.clsno is null) and (sf.stream LIKE '$st' or sf.stream is null) and
        s.markdel=0 And s.curr_year LIKE '$yr' and s.present=1 Order By $sortby Asc";
    else:
        $h='List of students registered in the system';
        $sql="SELECT s.admno,s.nemisno,concat(s.surname,' ',s.onames) as stud_names,concat(c.`clsname`,'-',sf.`stream`) As frm,s.dob,s.admdate,s.guardian,s.relation,s.`telno` FROM stud s Inner Join class sf USING
        (admno,curr_year) Inner Join classnames c ON (sf.clsno=c.clsno) WHERE sf.lvlno LIKE '$lvl' and s.type=0 and s.markdel=0 And s.curr_year IN (SELECT finyr FROM ss) and s.present=1 Order By s.surname,s.onames Asc";
    endif;
    $rsStud=mysqli_query($conn,$sql) or die(mysqli_error($conn).". Click <a href=\"pupil_manager.php\">HERE</a> to go back");
?>
<h4 style="letter-spacing:2px;word-spacing:4px;color:#fff;text-decoration:underline overline double #fff;text-align:center;"><?php echo strtoupper($h);?></h4>
<div style="background-color:#e6e6e6;border:0.5px groove #007;width:fit-content;margin:10px auto;border-radius:15px 15px 0 0;padding:0 5px;" class="container">
  <div style="background:inherit;border:0.5px dotted green;border-radius:10px;padding:6px;"><form name="frmFind" action="student.php" method="post">Find Student By &nbsp;<input type="radio" name="radFind" id="radAdmNo"
    value="admno" onclick="clrText()">Adm. No.&nbsp;<input type="radio" name="radFind" id="radNEMISNo" value="nemisno" onclick="clrText()">NEMIS No.&nbsp; <input type="radio" name="radFind" id="radName" value="st_names"
    checked onclick="clrText()">Names &nbsp;&nbsp; <input type="text" maxlength="17" size="30" name="txtFind" id="txtFind" value="" onkeyup="myFunction()" placeholder="Type/ Enter what to Find" style="border:0px;
    border-bottom:1px solid blue;color:#00d;"></form>
  </div><div style="min-height:100px;max-height:550px;max-width:1050px;min-width:100px;overflow-y:scroll;">
    <table class="table table-striped table-hover table-bordered table-sm" id="myTable" style="font-size:0.7rem;"><thead class="thead-dark"><tr><th rowspan="2">Adm.<br/>No.</th><th colspan="5" style="letter-spacing:4px;
    word-spacing:8px;">STUDENTS' DETAILS</th><th colspan="3" style="letter-spacing:4px;word-spacing:8px;">GUARDIAN'S DETAILS</th><th colspan="2">ADMIN ACTIONS</th></tr><tr><th>NEMIS No.</th><th>Names</th><th>Grade/Form
    </th><th>Date of Birth</th><th>Admitted On</th><th>Names</th><th>Relationship</th><th>Tel. No.</th><th>Record</th><th>Fees</th></tr></thead><tbody>
    <?php
        $i=0; $no=mysqli_num_rows($rsStud);
        if ($no>0){
          while ($rsS=mysqli_fetch_row($rsStud)){
            print "<tr>"; $a=0;
            foreach($rsS as $sr){
                if ($a==0) $admno=$sr; if (($a==4)||($a==5)) print "<td>".date("D d M, Y",strtotime($sr))."</td>"; else print "<td>$sr</td>";   $a++;
            }print "<td align=\"center\" valign=\"middle\">".((strlen($admno)!=0 && $canedit==1)?"<span onclick=\"window.open('studedit.php?admno=$admno-1','_self')\" class=\"spedit\" "
            . "title=\"Edit student details\">&#x270d;</span>":"")."</td><td align=\"center\" valign=\"middle\">".($stredit==1?"<span class=\"spedit\" title=\"Edit Fee Stucture\"
            onclick=\"window.open('studexpectedfee.php?admno=$admno-$yr','_self')\" >&#x270d;</span>":"")."</td></tr>";
            $i++;
          }
        }
    ?>
    </tbody></table></div><br><span style="background:#eaa;border-bottom:2px groove #ddd;font-weight:bold;" id="spTotal"><?php echo $no." Out Of ".$nos;?> Students(s)' Records</span><span id="divAmt" style="display:none;">
</span></div><script type="text/javascript" src="tpl/js/stud-find.js"></script><script type="text/javascript"><?php if(strlen($lstcls)>0) echo "classname.push($lstcls);";?></script>
<?php   mysqli_free_result($rsStud); mysqli_close($conn); 	footer(); ?>
